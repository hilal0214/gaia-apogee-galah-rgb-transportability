# Interpretation limits

- The catalogue is not volume complete and is not corrected to represent a universal Milky Way census.
- Common-footprint comparisons are conditional on shared APOGEE–GALAH support and are not independent replications.
- Survey-associated differences are not interpreted causally.
- Anonymous mixture components are not assigned physical Galactic-population names.
- Indeterminate morphology outcomes do not demonstrate equality between surveys.
- Failure to recover radial transitions with adequate power does not establish that a physical transition is absent.
- The measurement-precision audit does not determine which survey is closer to the underlying astrophysical distribution.
- The prospective forecast varies star count, target precision, and radial coverage while retaining the available spatial-block structure; it does not establish a universal minimum sample size.
