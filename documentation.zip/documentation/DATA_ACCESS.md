# Upstream data access

The analysis uses public survey releases: Gaia Data Release 3, APOGEE Data Release 17 (`allStarLite`), and GALAH Data Release 4. Upstream catalogues remain governed by their original licences and acknowledgement requirements and are not included here.

Reconstruction requires the exact survey releases, Gaia DR3 source identifiers, original quality flags, atmospheric parameters, radial velocities where used, native signal-to-noise measures, and elemental-abundance columns. Cross-survey joins must preserve the Gaia source identifier and survey origin. Result-table denominators must not be inferred from the compact release alone: label-specific finite-value and quality filters produce different sample sizes.

This release supports verification of reported results and prospective-simulation summaries. Full row-level reconstruction requires the upstream catalogues and the archived project analysis environment maintained by the author.
