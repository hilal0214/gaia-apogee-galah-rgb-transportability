# Methods and provenance

The Gaia DR3 source identifier is the cross-survey key. APOGEE DR17 and GALAH DR4 abundances are placed on a common empirical scale using overlap stars. Global gradients are estimated with a frozen Huber robust-regression contract. Common-footprint tests restrict the analysis to shared HEALPix NSIDE=16 cells and use outcome-independent survey-balance weights. Uncertainty is propagated with 4096 spatial-cluster multiplier draws where specified.

Alpha-sequence morphology is evaluated at fixed metallicity anchors using two-component mixture summaries. Valley location, sequence separation, and high-alpha fraction are assessed separately. Mixture identifiability and component resolution are retained as interpretation limits.

The prospective survey-design calculation uses 36 combinations of usable sample size, abundance precision, and radial coverage. Each design is calibrated with 256 null replicates and evaluated with four 256-replicate injected scenarios at transition radii 6.0 and 6.5 kpc and slope changes of ±0.05 dex kpc⁻¹. No real-data alternative transition model is evaluated in that calculation.

Release version: 2.1.0. Release date: 2026-08-18. Authors: Hilola Arslonova, Salakhutdin Nuritdinov, and Sobir Turaev. Coordinate convention: Galactocentric cylindrical radius R and absolute height |Z|. Gradient unit: dex kpc⁻¹.
