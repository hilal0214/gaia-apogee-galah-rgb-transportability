# Execution guide

## Release-level verification

From the release root:

```bash
python scripts/validate_release.py
python scripts/recompute_forecast_summary.py
```

These commands require only the files in this archive.

## Full analysis pipeline

The full pipeline requires the public Gaia DR3, APOGEE DR17, and GALAH DR4 products described in `DATA_ACCESS.md`. On Windows, create the Conda environment from `environment.yml`, place the extracted `code/pipeline` contents in a writable project directory, and follow the numbered launchers beginning with catalogue download and ingest. Frozen configuration and protocol files must retain their relative paths.

Large upstream catalogues and intermediate Parquet products are not bundled. Consequently, the full pipeline cannot complete until those inputs are retrieved or reconstructed. This is an intentional data-licensing and archive-size boundary, not a missing-code substitution.

The numbered stage-1 through stage-5 launchers construct and validate the base catalogue, calibration layers, design layer, gradients, and latent diagnostics. The later `run_stage6d*`, `run_stage7*`, and `run_stage8*` launchers reproduce the transport, power, morphology, and identifiability analyses. Each scientific fit has an accompanying configuration or protocol freeze and validation path.
