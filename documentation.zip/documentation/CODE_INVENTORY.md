# Code inventory

The collected pipeline snapshot contains 579 files: 161 Python source files, 166 Windows launchers, 120 JSON files, 15 YAML files, 63 requirements or diagnostic text files, and 54 Markdown documents. One local failure traceback and one superseded pre-hotfix Python copy were excluded.

The main functional groups are:

- catalogue ingest, Gaia identifier audit, source matching, and census construction;
- atmospheric-label calibration and validation;
- analysis-design-layer construction and quality filtering;
- robust radial and vertical gradient estimation;
- common-footprint construction and survey balancing;
- predictive transportability diagnostics and numerical audits;
- practical-equivalence and survey-interaction classification;
- null and injected radial-transition simulations;
- alpha-sequence morphology power calibration, inference, and identifiability checks;
- self-tests, validators, configuration freezes, protocols, and Windows launchers.

The historical stage identifiers are retained because launchers, configuration files, output contracts, and validation checks reference them directly. They should not be interpreted as scientific classifications. Manuscript source and compiled manuscript files are absent.

Important entry points include:

- `code/pipeline/01_download_catalogues.bat` and `code/pipeline/run_stage1_all.bat`;
- `code/pipeline/run_stage4a_all.bat` and `code/pipeline/run_stage4b_all.bat`;
- `code/pipeline/src/stage6d4b_exact_production_fits.py`;
- `code/pipeline/src/stage6d4c_practical_equivalence_classification.py`;
- `code/pipeline/src/stage7b2_full_signed_injection_recovery.py`;
- `code/pipeline/src/stage7r1_fixed_window_transition_power.py`;
- `code/pipeline/src/stage8b2_formal_synthetic_morphology_power.py`;
- `code/pipeline/src/stage8d_real_alpha_morphology_inference.py`;
- `code/pipeline/src/stage8f_identifiability_claim_closure.py`.
