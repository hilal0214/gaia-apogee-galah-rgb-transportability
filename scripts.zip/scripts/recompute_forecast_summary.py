#!/usr/bin/env python3
import csv
from pathlib import Path

root = Path(__file__).resolve().parents[1]
rows = list(csv.DictReader((root / "tables/future_survey_forecast_replicates.csv").open(newline="", encoding="utf-8")))
null = [r for r in rows if r["kind"] == "NULL"]
injected = [r for r in rows if r["kind"] == "INJECTED"]
fpr = sum(r["detected"] == "True" for r in null) / len(null)
groups = {}
for r in injected:
    key = (r["design_id"], r["R_break"], r["delta_beta"])
    groups.setdefault(key, []).append(r["detected"] == "True")
powers = {k: sum(v) / len(v) for k, v in groups.items()}
by_design = {}
for (design, _, _), power in powers.items():
    by_design.setdefault(design, []).append(power)
best_worst = max(min(v) for v in by_design.values())
print(f"replicates={len(rows)}")
print(f"pooled_null_fpr={fpr:.8f}")
print(f"best_worst_case_power={best_worst:.8f}")
print(f"maximum_scenario_power={max(powers.values()):.8f}")
