#!/usr/bin/env python3
import csv, hashlib, json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = root / "MANIFEST.sha256"
for line in manifest.read_text(encoding="utf-8").splitlines():
    if not line.strip(): continue
    digest, rel = line.split("  ", 1)
    path = root / rel
    assert path.is_file(), rel
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, rel
meta = json.loads((root / ".zenodo.json").read_text(encoding="utf-8"))
assert [x["name"] for x in meta["creators"]] == ["Arslonova, Hilola", "Nuritdinov, Salakhutdin", "Turaev, Sobir"]
assert meta["version"] == "2.1.0"
v = json.loads((root / "validation/future_survey_forecast_validation.json").read_text(encoding="utf-8"))
assert v["design_cells_completed"] == 36
assert v["null_design_cells"] == 36
assert v["maximum_null_fpr"] <= 0.05
assert v["real_transition_fit_performed"] is False
with (root / "tables/future_survey_forecast_replicates.csv").open(newline="", encoding="utf-8") as f:
    assert sum(1 for _ in csv.DictReader(f)) == 44840
assert not any(p.name in {"main.tex", "main.pdf"} for p in root.rglob("*"))
pipeline = root / "code/pipeline"
assert sum(1 for p in pipeline.rglob("*.py")) == 161
assert sum(1 for p in pipeline.rglob("*.bat")) == 166
assert (pipeline / "scripts/28_fit_stage4b.py").is_file()
assert (pipeline / "src/stage6d4b_exact_production_fits.py").is_file()
assert (pipeline / "src/stage7b2_full_signed_injection_recovery.py").is_file()
assert (pipeline / "src/stage8d_real_alpha_morphology_inference.py").is_file()
print("RELEASE_VALIDATION_PASS")
