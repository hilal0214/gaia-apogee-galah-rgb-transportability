@echo off
setlocal
python scripts\selftest_stage2c.py
if errorlevel 1 exit /b %errorlevel%
endlocal
