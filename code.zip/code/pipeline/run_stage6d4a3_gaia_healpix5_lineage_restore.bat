@echo off
setlocal
cd /d "%~dp0"
python src\stage6d4a3_gaia_healpix5_lineage_restore.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D4A3 gaia_healpix5 lineage restoration completed.
echo Inspect outputs\stage6d4a3_gaia_healpix5_lineage_restore\validation\stage6d4a3_validation.json
endlocal
