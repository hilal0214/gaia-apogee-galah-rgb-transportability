@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d6_semantic_localid_multihop_crosswalk.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2D6 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2D6 semantic local-ID and multihop crosswalk completed.
echo Inspect outputs\stage6d3a2d6_semantic_localid_multihop_crosswalk\validation\stage6d3a2d6_validation.json
endlocal
