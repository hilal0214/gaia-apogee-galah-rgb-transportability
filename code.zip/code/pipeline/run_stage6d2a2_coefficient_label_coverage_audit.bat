@echo off
setlocal
cd /d "%~dp0"
python src\stage6d2a2_coefficient_label_coverage_audit.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D2A2 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D2A2 coefficient and label-coverage audit completed.
echo Inspect outputs\stage6d2a2_coefficient_label_coverage_audit\validation\stage6d2a2_validation.json
endlocal
