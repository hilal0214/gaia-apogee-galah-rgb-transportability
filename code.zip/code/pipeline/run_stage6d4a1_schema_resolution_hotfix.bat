@echo off
setlocal
cd /d "%~dp0"
python src\stage6d4a1_schema_resolution_hotfix.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D4A1 schema-resolution hotfix completed.
echo Inspect outputs\stage6d4a1_schema_resolution_hotfix\validation\stage6d4a1_validation.json
endlocal
