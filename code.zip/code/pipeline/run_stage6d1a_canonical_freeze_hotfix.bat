@echo off
setlocal
cd /d "%~dp0"
python src\stage6d1a_freeze_predictive_transportability.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D1A failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D1A canonical protocol freeze completed.
echo Inspect outputs\stage6d1a_canonical_freeze_hotfix\validation\stage6d1a_validation.json
endlocal
