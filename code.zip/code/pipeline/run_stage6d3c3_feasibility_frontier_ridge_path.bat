@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c3_feasibility_frontier_ridge_path.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C3 feasibility frontier completed.
echo Inspect outputs\stage6d3c3_feasibility_frontier_ridge_path\validation\stage6d3c3_validation.json
endlocal
