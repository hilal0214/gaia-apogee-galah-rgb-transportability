# Stage-6C2E protocol

Inspection only. Generic mixture components may not be assigned physical population names without a frozen semantic map. T06 is audited separately because survey-subset gradients do not require population membership.
