@echo off
setlocal
python scripts\16_build_stage3a.py --config config\stage3a.yml
exit /b %ERRORLEVEL%
