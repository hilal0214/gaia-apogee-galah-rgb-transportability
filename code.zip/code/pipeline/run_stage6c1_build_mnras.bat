@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is unavailable in the active environment.
  exit /b 1
)
python src\stage6c1_build_mnras.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C1 failed. Inspect outputs\stage6c1_mnras_source\validation\stage6c1_validation.json
  exit /b 1
)
echo.
echo [OK] Stage-6C1 MNRAS source reconstruction completed.
echo Output: outputs\stage6c1_mnras_source
endlocal
