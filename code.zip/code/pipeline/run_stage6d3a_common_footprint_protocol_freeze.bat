@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a_common_footprint_protocol_freeze.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A common-footprint protocol frozen.
echo Inspect outputs\stage6d3a_common_footprint_protocol_freeze\validation\stage6d3a_validation.json
endlocal
