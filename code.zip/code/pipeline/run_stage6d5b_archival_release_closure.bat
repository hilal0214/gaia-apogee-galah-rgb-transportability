@echo off
setlocal
cd /d "%~dp0"
python src\stage6d5b_archival_release_closure.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D5B archival release closure completed.
echo Inspect outputs\stage6d5b_archival_release_closure\validation\stage6d5b_validation.json
endlocal
