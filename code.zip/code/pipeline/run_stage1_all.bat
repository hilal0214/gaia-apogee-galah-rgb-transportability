@echo off
setlocal
call 00_create_env.bat
if errorlevel 1 exit /b 1
call 01_download_catalogues.bat
if errorlevel 1 exit /b 1
call 02_ingest_catalogues.bat
if errorlevel 1 exit /b 1
call 03_audit_gaia_identifiers.bat
if errorlevel 1 exit /b 1
call 04_build_full_census.bat
if errorlevel 1 exit /b 1
call 05a_query_gaia_pilot.bat
if errorlevel 1 exit /b 1
call 05b_validate_gaia_pilot.bat
if errorlevel 1 exit /b 1
call 05c_package_gaia_pilot.bat
if errorlevel 1 exit /b 1
call 05_query_gaia_dr3.bat
if errorlevel 1 exit /b 1
call 06_validate_and_pack.bat
