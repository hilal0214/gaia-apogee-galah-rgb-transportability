@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is unavailable in the active environment.
  exit /b 1
)
python src\stage6c2f_claimsafe_pivot.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C2F execution failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6C2F claim-safe manuscript pivot completed.
echo Inspect outputs\stage6c2f_claimsafe_pivot\validation\stage6c2f_validation.json
endlocal
