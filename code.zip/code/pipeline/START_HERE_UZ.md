# Ishni boshlash

Bu paket eski `RGB_ATLAS_Q1_REAL_200K` natijalarini o‘chirmaydi va ularning
ustiga yozmaydi. Yangi natijalar alohida `outputs/stage1` katalogiga tushadi.

## Disk va vaqt

- Raw yuklama taxminan 2.5 GB.
- Oraliq va Gaia cache bilan kamida 10 GB bo‘sh joy tavsiya etiladi.
- Gaia DR3 query bosqichi internet va Archive yuklanishiga qarab uzoq davom
  etishi mumkin. Har bir chunk saqlanadi; uzilishdan keyin shu `.bat` faylni
  qayta ishga tushirish kifoya.
- APOGEE `synspec_rev1` katalogi `GAIAEDR3_SOURCE_ID` beradi. EDR3 va DR3
  source listlari bir xil bo‘lgani sabab mapping query bajarilmaydi.

## Anaconda Prompt buyruqlari

Paket katalogiga kiring va ketma-ket bajaring:

```bat
00_create_env.bat
01_download_catalogues.bat
02_ingest_catalogues.bat
03_audit_gaia_identifiers.bat
04_build_full_census.bat
05a_query_gaia_pilot.bat
05b_validate_gaia_pilot.bat
05c_package_gaia_pilot.bat
05_query_gaia_dr3.bat
06_validate_and_pack.bat
```

Yoki barcha bosqichni:

```bat
run_stage1_all.bat
```

Yangi production run’da 20,000-source pilot PASS bo‘lmasdan full Gaia query
boshlanmaydi. Pilot archive/schema auditi bo‘lib, ilmiy subsample emas.

## Birinchi tekshiruv uchun

Avval faqat raw kataloglar va census boshlanishini tekshirmoqchi bo‘lsangiz:

```bat
01_download_catalogues.bat
02_ingest_catalogues.bat
```

Shundan keyin quyidagi fayl paydo bo‘lishi kerak:

```text
outputs\stage1\catalogue_ingest_summary.json
```

## Bizga qaytariladigan fayl

To‘liq ish tugagach, paket ildizida:

```text
RGB_transportability_stage1_outputs_v0_1_1.zip
```

yaratiladi. Keyingi cross-fitted calibration bosqichini aynan shu output
asosida quramiz.
