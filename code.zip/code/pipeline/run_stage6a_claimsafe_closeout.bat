@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is not available in the active environment.
  exit /b 1
)
python src\stage6a_claimsafe_closeout.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6A failed. Inspect the traceback above.
  exit /b 1
)
echo.
echo [OK] Stage-6A claim-safe closeout completed.
echo Output: outputs\stage6a_claimsafe_closeout
endlocal
