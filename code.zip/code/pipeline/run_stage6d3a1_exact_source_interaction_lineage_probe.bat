@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a1_exact_source_interaction_lineage_probe.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A1 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A1 exact source/interactions lineage probe completed.
echo Inspect outputs\stage6d3a1_exact_source_interaction_lineage_probe\validation\stage6d3a1_validation.json
endlocal
