@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c1_balance_gate_failure_localization.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C1 balance-gate failure localization completed.
echo Inspect outputs\stage6d3c1_balance_gate_failure_localization\validation\stage6d3c1_validation.json
endlocal
