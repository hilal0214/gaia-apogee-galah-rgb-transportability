@echo off
setlocal
cd /d "%~dp0"
python src\stage8e_claimsafe_morphology_integration.py --project-root "%CD%"
exit /b %ERRORLEVEL%
