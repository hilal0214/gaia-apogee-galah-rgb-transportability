@echo off
call 99_stage4a_selftest.bat || exit /b %errorlevel%
call 25_build_stage4a.bat || exit /b %errorlevel%
call 26_validate_stage4a.bat || exit /b %errorlevel%
call 27_package_stage4a.bat || exit /b %errorlevel%

