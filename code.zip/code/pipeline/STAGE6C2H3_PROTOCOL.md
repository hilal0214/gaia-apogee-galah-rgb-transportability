Use copy.deepcopy for YAML-native values. Preserve paths.stage4a_output_dir and paths.log_dir exactly. Redirect only paths.output_dir. Hash frozen inputs before and after replay.
