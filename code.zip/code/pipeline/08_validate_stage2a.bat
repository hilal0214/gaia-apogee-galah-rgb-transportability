@echo off
setlocal
call conda activate rgb-transport-stage1
if errorlevel 1 exit /b 1
python scripts\08_validate_stage2a.py --config config\stage2a.yml
