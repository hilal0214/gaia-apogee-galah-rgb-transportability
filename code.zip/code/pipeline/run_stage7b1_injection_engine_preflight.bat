@echo off
setlocal
cd /d "%~dp0"
python src\stage7b1_injection_engine_preflight.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-7B1 injection-engine preflight completed.
echo Inspect outputs\stage7b1_injection_engine_preflight\validation\stage7b1_validation.json
endlocal
