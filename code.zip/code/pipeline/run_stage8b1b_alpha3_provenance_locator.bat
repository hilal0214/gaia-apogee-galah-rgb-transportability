@echo off
setlocal
cd /d "%~dp0"
python src\stage8b1b_alpha3_provenance_locator.py --project-root "%CD%"
exit /b %ERRORLEVEL%
