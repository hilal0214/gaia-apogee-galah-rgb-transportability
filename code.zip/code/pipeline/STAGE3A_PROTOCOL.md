# Stage 3A frozen protocol

Version: 0.5.0  
Date: 2026-08-01

## Scope

Stage 3A verifies and consolidates the 76 restartable Gaia DR3 plus Bailer-Jones cache chunks already accepted in Stage 1, selects the Stage 2C spectroscopic RGB-quality candidate layer, and freezes astrometric, distance, and radial-velocity eligibility before any coordinate transformation or scientific fit.

The output is a compact Gaia-quality layer for every Stage 2C row satisfying `spectroscopic_rgb_quality_any`. The complete 1,509,277-source cache identity is nevertheless verified before that candidate restriction is applied. No Gaia query is issued.

## Accepted upstream identity

- Stage 1 v0.1.2 release SHA-256: `620ec1151aea23ff649ef198c437c9355852f1c6d2733830f905635728f54bee`.
- Stage 2C v0.4.0 production release SHA-256: `b029c8e0c8e247fdafc14fb52893fb6035a8073b161af0afb571562fbc804bbb`.
- Stage 2C atlas SHA-256: `b09e2aa54c858829b79ff92407f1bd27409fc77ffc4bbc364f5d24550fcace0c`.
- Ordered Gaia source-ID SHA-256: `51cbe5349c8bb36d7db473cce7164778a9cc17ed1b24c2f83b0b3c2920d5d60a`.

All 76 metadata records must carry the same full-run selection hash, query signature, protocol version, and exact requested-ID hash. Each joined Parquet chunk is independently hashed in Stage 3A, and the reconstructed ordered source-ID vector must equal the Stage 2C atlas vector exactly.

## Candidate boundary

The Stage 3A candidate layer contains all and only Stage 2C sources satisfying the frozen `spectroscopic_rgb_quality_any` flag. This is expected to retain 393,834 rows. `spectroscopic_primary_ok` and `spectroscopic_sensitivity_ok` remain separate and are never inferred from Gaia outcome.

## Astrometric eligibility

Both primary and sensitivity layers require:

- an accepted five- or six-parameter Gaia solution (`astrometric_params_solved` 31 or 95);
- finite position, parallax, proper motions, positive formal errors, and a finite valid five-parameter covariance representation;
- a non-duplicated Gaia source.

The primary layer additionally requires `ruwe < 1.4`, at least nine visibility periods, and `ipd_frac_multi_peak <= 2`. The sensitivity layer uses `ruwe < 2.0`, at least eight visibility periods, and `ipd_frac_multi_peak <= 10`. The primary gate is therefore a strict subset of the sensitivity gate.

These fixed diagnostics follow the Gaia EDR3 astrometric-solution and catalogue-validation framework of Lindegren et al. (2021) and Fabricius et al. (2021). They are quality controls, not a claim that any single Gaia diagnostic is a universal fidelity probability.

## Distance policy

The primary distance is the Bailer-Jones et al. (2021) photogeometric posterior median. Its 16th, 50th, and 84th percentiles must be finite, positive, and ordered. Define the conservative fractional half-width

`f_d = max(r_med-r_lo, r_hi-r_med) / r_med`.

Primary distance eligibility requires `f_d <= 0.20`; sensitivity eligibility requires `f_d <= 0.30`. The geometric posterior is retained as a separately flagged alternative estimator with the same 0.30 sensitivity width limit. Direct inverse parallax is never used, and no parallax signal-to-noise cut is imposed on top of the Bayesian posterior-width gate.

Bailer-Jones et al. show that the photogeometric estimator uses parallax, sky position, colour, and apparent magnitude and is generally more precise for weak parallaxes. Because it adds an astrophysical prior, the purely geometric solution is frozen as an estimator-sensitivity layer for later phase-space and gradient replication.

## Radial-velocity policy

High-resolution APOGEE/GALAH radial velocity is preferred when its Stage 2C spectroscopic gate and formal error pass. Gaia DR3 radial velocity is the fallback. Primary limits are 5 km/s for the spectroscopic formal error, 10 km/s and at least five transits for Gaia. Sensitivity limits are 20 km/s and at least three Gaia transits.

When both sensitivity-valid sources exist, a disagreement larger than `max(20 km/s, 5 sigma_combined)` is flagged. Such a row is excluded from the primary 6D gate but retained in sensitivity; this treats possible binaries or catalogue failures transparently without erasing them.

## Frozen outputs and boundary

Stage 3A writes Gaia cache provenance, exact Gaia columns for the candidate set, distance and RV hierarchy fields, nested 5D/6D quality flags, and label-specific eligibility for [Fe/H], [Mg/Fe], [Si/Fe], [Ca/Fe], [Ni/Fe], and alpha3.

It does not construct Galactocentric coordinates, select solar parameters, reject stars by derived speed, fit gradients, or classify populations. Those operations begin only after this quality gate is audited and frozen.

## Primary references

- Lindegren et al. 2021, *Gaia EDR3: The astrometric solution*: https://doi.org/10.1051/0004-6361/202039709
- Fabricius et al. 2021, *Gaia EDR3: Catalogue validation*: https://doi.org/10.1051/0004-6361/202039834
- Bailer-Jones et al. 2021, *Geometric and photogeometric distances*: https://doi.org/10.3847/1538-3881/abd806
- Katz et al. 2023, *Gaia DR3 radial velocities*: https://doi.org/10.1051/0004-6361/202244220
