@echo off
setlocal
cd /d "%~dp0"
python src\stage6d4a3a_survey_identity_audit.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D4A3A survey-identity audit completed.
echo Inspect outputs\stage6d4a3a_survey_identity_audit\validation\stage6d4a3a_validation.json
endlocal
