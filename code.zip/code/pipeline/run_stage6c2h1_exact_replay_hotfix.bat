@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is unavailable in the active environment.
  exit /b 1
)
python src\stage6c2h1_exact_replay_hotfix.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C2H1 execution failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6C2H1 exact replay hotfix completed.
echo Inspect outputs\stage6c2h1_exact_replay_hotfix\validation\stage6c2h1_validation.json
endlocal
