@echo off
setlocal
cd /d "%~dp0"
python src\stage6d2a3_protocol_amendment_lineage_audit.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D2A3 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D2A3 protocol amendment and lineage audit completed.
echo Inspect outputs\stage6d2a3_protocol_amendment_lineage_audit\validation\stage6d2a3_validation.json
endlocal
