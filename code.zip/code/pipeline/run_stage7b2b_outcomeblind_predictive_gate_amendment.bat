@echo off
setlocal
cd /d "%~dp0"
python src\stage7b2b_outcomeblind_predictive_gate_amendment.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-7B2B outcome-blind predictive-gate amendment completed.
echo Inspect outputs\stage7b2b_outcomeblind_predictive_gate_amendment\validation\stage7b2b_validation.json
endlocal
