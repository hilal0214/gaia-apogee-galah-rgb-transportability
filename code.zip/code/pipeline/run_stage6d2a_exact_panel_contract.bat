@echo off
setlocal
cd /d "%~dp0"
python src\stage6d2a_exact_panel_contract.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D2A failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D2A exact panel contract completed.
echo Inspect outputs\stage6d2a_exact_panel_contract\validation\stage6d2a_validation.json
endlocal
