@echo off
setlocal
cd /d "%~dp0"
python src\stage6d6c_manuscript_science_integration.py --project-root "%CD%"
exit /b %ERRORLEVEL%
