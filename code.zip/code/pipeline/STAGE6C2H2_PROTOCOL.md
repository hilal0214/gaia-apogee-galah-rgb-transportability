Preserve paths.stage4a_output_dir and paths.log_dir exactly. Redirect only paths.output_dir. Hash protected frozen files before and after execution. Authorize Stage-6D only after exact row identity.
