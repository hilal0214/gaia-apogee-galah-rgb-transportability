# Stage 4A protocol: analysis fusion and transportability contract

Version: 0.8.1  
Date: 2026-08-03

## Purpose

Stage 4A creates an outcome-free analysis-design layer before any Galactic
gradient or population model is fitted. It joins the byte-frozen Stage 2C
abundance-transport atlas, Stage 3B nominal Galactocentric phase space, and
Stage 3C formal-random uncertainty/stress layer by the exact Gaia DR3 source-ID
vector. The join must cover all 393,834 spectroscopic candidates one to one.

## Label contract

The only analysis labels are homogenised [Fe/H], [Mg/Fe], [Si/Fe], [Ca/Fe],
[Ni/Fe], and the fixed three-element alpha3 mean. C/N, C, N, Al, Ti, and other
unvalidated transports remain forbidden. Native APOGEE and corrected GALAH
provenance, formal error, empirical transport-error proxy, and calibration
support tier are retained. The empirical proxy is not an inverse-variance
regression weight.

## Nominal and sensitivity cohorts

The nominal gradient domain is the pre-existing manuscript window
`3 < R_GC < 15 kpc`, applied separately to every label's frozen Stage 3B
primary phase-space set. A core-calibration subset, a `|Z| <= 5 kpc` disc-height
subset, a paired geometric-distance subset, and a Stage 3B sensitivity subset
are recorded without replacing the nominal cohort.

Every stored gradient cohort additionally requires a finite label value and a
finite, non-negative empirical error proxy. This downstream guard is important
for alpha3: Stage 2C intentionally stores alpha3 only when all three component
labels are primary, while its component-level sensitivity flag can be true for
rows with no stored alpha3 outcome. Stage 4A does not mutate that frozen
upstream flag; it simply prevents outcome-free rows from entering a gradient
cohort.

For survey-transport diagnostics, an outcome-free rectangular common-support
domain is calculated separately for every label. For APOGEE-native and
GALAH-corrected stars in the nominal cohort, the 1st--99th percentile ranges of
`R_GC`, `|Z|`, `T_eff`, and `log g` are computed. The sensitivity domain is the
intersection of the two source-specific ranges in all four covariates. It is a
descriptive overlap restriction, not a volume-completeness or selection-
function correction.

## Spatial resampling contract

The Gaia source identifier encodes a nested HEALPix level-12 index. Stage 4A
stores the coarsened level-5 index for later spatial block resampling. This
identifier is not a Galactic population label and does not define a weight.

## Population-feature boundary

Stage 4A only records whether a star has primary [Fe/H], alpha3, and 6D phase
space, plus a separate frame-sign-stable sensitivity flag. It does not assign
thin-disc, thick-disc, extended-disc, halo, or intermediate labels. A later
stage must define and validate any probabilistic population model before
population-resolved gradients are considered.

The intersection of the [Fe/H] and alpha3 common-support flags is retained only
as an explicitly radial-gradient-domain sensitivity flag. It is not presented
as a general population-selection rule.

## Frozen boundary

No abundance-gradient coefficient, bootstrap interval, population probability,
selection weight, or astrophysical result is produced in Stage 4A. The output
is a prespecified design and provenance layer only.
