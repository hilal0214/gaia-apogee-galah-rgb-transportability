@echo off
setlocal
cd /d "%~dp0"
python src\stage6c2h3_yaml_datesafe_replay.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C2H3 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6C2H3 completed.
echo Inspect outputs\stage6c2h3_yaml_datesafe_replay\validation\stage6c2h3_validation.json
endlocal
