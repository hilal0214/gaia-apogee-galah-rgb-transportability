@echo off
setlocal
cd /d "%~dp0"
python src\stage6d2a4_five_label_oof_reconstruction.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D2A4 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D2A4 five-label OOF reconstruction completed.
echo Inspect outputs\stage6d2a4_five_label_oof_reconstruction\validation\stage6d2a4_validation.json
endlocal
