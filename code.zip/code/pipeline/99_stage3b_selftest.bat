@echo off
python scripts\selftest_stage3b.py

