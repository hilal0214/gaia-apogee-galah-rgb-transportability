@echo off
setlocal
echo INFO: synspec_rev1 supplies Gaia EDR3 IDs; DR2-to-DR3 mapping is not required.
echo INFO: Running the direct EDR3/DR3 identifier audit instead.
call 03_audit_gaia_identifiers.bat
