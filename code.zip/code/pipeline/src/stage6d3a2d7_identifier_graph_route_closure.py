from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


UINT64_MAX = 18446744073709551615
FLOAT_EXACT_INTEGER_MAX = 9007199254740991


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def normalise_name(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def read_columns(path: Path) -> tuple[list[str], int]:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        import pyarrow.parquet as pq
        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    if suffix == ".feather":
        import pyarrow.feather as feather
        table = feather.read_table(path)
        return list(table.column_names), int(table.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def read_table(
    path: Path,
    columns: list[str] | None = None,
    string_columns: list[str] | None = None,
) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path, columns=columns)
    if suffix == ".feather":
        return pd.read_feather(path, columns=columns)
    dtype = (
        {column: "string" for column in string_columns}
        if string_columns else None
    )
    return pd.read_csv(path, usecols=columns, dtype=dtype)


def resolve_with_fallback(path: Path) -> Path | None:
    for candidate in [
        path,
        path.with_suffix(".csv"),
        path.with_suffix(".feather"),
    ]:
        if candidate.exists():
            return candidate
    return None


def path_excluded(path: Path, root: Path, cfg: dict[str, Any]) -> bool:
    text = safe_rel(path, root).lower().replace("\\", "/")
    return any(token.lower() in text for token in cfg["excluded_path_tokens"])


def path_is_galah(path: Path, cfg: dict[str, Any]) -> bool:
    token = normalise_name(str(path))
    return any(
        normalise_name(value) in token
        for value in cfg["galah_path_tokens"]
    )


def find_alias(columns: list[str], aliases: list[str]) -> str | None:
    lookup = {normalise_name(column): column for column in columns}
    for alias in aliases:
        token = normalise_name(alias)
        if token in lookup:
            return lookup[token]
    return None


def identify_columns(
    columns: list[str],
    cfg: dict[str, Any],
) -> list[str]:
    output = []
    for column in columns:
        token = normalise_name(column)
        if any(name in token for name in cfg["identifier_name_tokens"]):
            output.append(column)
            continue
        if token.endswith("_id") or token.endswith("id"):
            if not any(
                blocked in token
                for blocked in [
                    "healpix", "field_id", "fold_id",
                    "row_id", "chunk_id", "bootstrap_id",
                    "run_id", "release_id"
                ]
            ):
                output.append(column)
    return list(dict.fromkeys(output))


def family_for_column(column: str) -> str:
    token = normalise_name(column)
    token = re.sub(r"_(?:1|2|3|4|dr2|dr3|dr4)$", "", token)
    if "sobject" in token:
        return "sobject"
    if "tmass" in token or "twomass" in token or token.startswith("2mass"):
        return "tmass"
    if "galah" in token and ("object" in token or token.endswith("_id")):
        return "galah_object"
    if "dr2" in token:
        return "gaia_dr2"
    if "dr3" in token or "edr3" in token:
        return "gaia_dr3"
    if "gaia" in token and "source" in token:
        return "gaia_generic"
    if token in {"source_id", "sourceid"}:
        return "source_generic"
    if "object" in token or "star_id" in token or "target_id" in token:
        return "object_generic"
    stem = re.sub(r"(?:_source)?_?id$", "", token)
    return f"opaque:{stem or token}"


def clean_uint64(series: pd.Series) -> pd.Series:
    output = pd.Series(pd.NA, index=series.index, dtype="UInt64")
    if pd.api.types.is_unsigned_integer_dtype(series.dtype):
        return series.astype("UInt64")
    if pd.api.types.is_integer_dtype(series.dtype):
        numeric = series.astype("Int64")
        valid = numeric.notna() & (numeric >= 0)
        if valid.any():
            output.loc[valid] = pd.array(
                numeric.loc[valid].astype("string"), dtype="UInt64"
            )
        return output
    if pd.api.types.is_float_dtype(series.dtype):
        numeric = pd.to_numeric(series, errors="coerce")
        valid = (
            numeric.notna()
            & np.isfinite(numeric)
            & (numeric >= 0)
            & (numeric <= FLOAT_EXACT_INTEGER_MAX)
            & (numeric == np.floor(numeric))
        )
        if valid.any():
            output.loc[valid] = pd.array(
                numeric.loc[valid].astype("uint64").astype("string"),
                dtype="UInt64",
            )
        return output

    text = series.astype("string").str.strip()
    text = text.str.replace(r"^\+", "", regex=True)
    valid = text.str.fullmatch(r"[0-9]+", na=False)
    if valid.any():
        values = text.loc[valid].str.lstrip("0").mask(lambda x: x == "", "0")
        within_length = values.str.len() <= len(str(UINT64_MAX))
        bounded = values[within_length]
        if not bounded.empty:
            same_length = bounded.str.len() == len(str(UINT64_MAX))
            within_max = (~same_length) | (bounded <= str(UINT64_MAX))
            bounded = bounded[within_max]
            if not bounded.empty:
                output.loc[bounded.index] = pd.array(
                    bounded, dtype="UInt64"
                )
    return output


def normalise_identifier(series: pd.Series, family: str) -> pd.Series:
    if family in {"gaia_dr2", "gaia_dr3", "gaia_generic", "source_generic"}:
        exact = clean_uint64(series)
        return exact.astype("string")

    if pd.api.types.is_integer_dtype(series.dtype):
        text = series.astype("Int64").astype("string")
    elif pd.api.types.is_float_dtype(series.dtype):
        numeric = pd.to_numeric(series, errors="coerce")
        safe = (
            numeric.notna()
            & np.isfinite(numeric)
            & (np.abs(numeric) <= FLOAT_EXACT_INTEGER_MAX)
            & (numeric == np.floor(numeric))
        )
        text = pd.Series(pd.NA, index=series.index, dtype="string")
        text.loc[safe] = numeric.loc[safe].astype("int64").astype("string")
    else:
        text = series.astype("string").str.strip()
        numeric_decimal = text.str.fullmatch(r"[+]?[0-9]+(?:\.0+)?", na=False)
        if numeric_decimal.any():
            canonical = (
                text.loc[numeric_decimal]
                .str.replace(r"^\+", "", regex=True)
                .str.replace(r"\.0+$", "", regex=True)
                .str.lstrip("0")
                .mask(lambda x: x == "", "0")
            )
            text.loc[numeric_decimal] = canonical

    text = text.str.strip().replace(
        {"": pd.NA, "nan": pd.NA, "None": pd.NA, "<NA>": pd.NA}
    )
    if family == "tmass":
        text = (
            text.str.upper()
            .str.replace(r"^2MASS", "", regex=True)
            .str.replace(r"^J", "", regex=True)
            .str.replace(r"[\s_-]+", "", regex=True)
        )
    else:
        text = text.str.upper().str.replace(r"\s+", "", regex=True)
    return text


def detect_snr_contract(
    columns: list[str],
    cfg: dict[str, Any],
) -> tuple[str | None, list[str]]:
    scalar = find_alias(columns, cfg["snr_scalar_aliases"])
    if scalar:
        return "scalar_native_snr", [scalar]
    channels = []
    for aliases in cfg["snr_channel_alias_groups"].values():
        column = find_alias(columns, aliases)
        if column and column not in channels:
            channels.append(column)
    if len(channels) >= int(cfg["minimum_finite_snr_channels"]):
        return "galah_channel_median", channels
    return None, []


def build_snr(
    frame: pd.DataFrame,
    contract: str,
    columns: list[str],
    cfg: dict[str, Any],
) -> pd.Series:
    if contract == "scalar_native_snr":
        snr = pd.to_numeric(frame[columns[0]], errors="coerce")
    else:
        channels = pd.DataFrame({
            column: pd.to_numeric(frame[column], errors="coerce")
            for column in columns
        })
        finite = channels.notna().sum(axis=1)
        snr = channels.median(axis=1, skipna=True)
        snr.loc[
            finite < int(cfg["minimum_finite_snr_channels"])
        ] = np.nan
    snr = pd.to_numeric(snr, errors="coerce")
    snr.loc[
        ~np.isfinite(snr)
        | (snr <= float(cfg["snr_minimum_exclusive"]))
        | (snr > float(cfg["snr_maximum"]))
    ] = np.nan
    return snr


def functional_edge(
    left: pd.Series,
    right: pd.Series,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    frame = pd.DataFrame({
        "left_value": left,
        "right_value": right,
    }).dropna()
    frame = frame.drop_duplicates()
    conflicts = (
        frame.groupby("left_value")["right_value"].nunique() > 1
        if not frame.empty else pd.Series(dtype=bool)
    )
    ready = bool(not conflicts.any())
    if ready:
        frame = frame.drop_duplicates("left_value")
    return frame, {
        "rows": len(frame),
        "left_unique": int(frame["left_value"].nunique()) if not frame.empty else 0,
        "right_unique": int(frame["right_value"].nunique()) if not frame.empty else 0,
        "conflicting_left_ids": int(conflicts.sum()) if len(conflicts) else 0,
        "functional_ready": ready,
    }


def aggregate_product(
    source_ids: pd.Series,
    snr: pd.Series,
    contract: str,
    route: str,
) -> pd.DataFrame:
    work = pd.DataFrame({
        "source_id": clean_uint64(source_ids),
        "snr_native": snr,
    }).dropna(subset=["source_id"])
    work["source_id"] = work["source_id"].astype("uint64")
    rows = []
    for source_id, group in work.groupby("source_id", sort=False):
        values = group["snr_native"].dropna().to_numpy(dtype=float)
        rows.append({
            "source_id": source_id,
            "survey": "GALAH_CORRECTED",
            "snr_native": float(np.median(values)) if len(values) else np.nan,
            "snr_measurement_count": int(len(values)),
            "snr_input_row_count": int(len(group)),
            "snr_contract": contract,
            "snr_id_route": route,
        })
    return pd.DataFrame(rows)


def product_fingerprint(product: pd.DataFrame, decimals: int) -> str:
    if product.empty:
        return hashlib.sha256(b"empty").hexdigest()
    work = product[["source_id", "snr_native"]].copy()
    work["source_id"] = work["source_id"].astype("uint64")
    work["snr_native"] = pd.to_numeric(
        work["snr_native"], errors="coerce"
    ).round(decimals)
    work = work.sort_values("source_id")
    return hashlib.sha256(
        work.to_csv(index=False, na_rep="NA").encode("utf-8")
    ).hexdigest()


def complete_mask(frame: pd.DataFrame) -> pd.Series:
    required = [
        "R", "abs_Z", "teff", "logg",
        "snr_native", "g_mag", "bp_rp"
    ]
    mask = pd.Series(True, index=frame.index)
    for field in required:
        if field not in frame.columns:
            return pd.Series(False, index=frame.index)
        mask &= frame[field].notna()
    sky = (
        (
            frame.get("l", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("b", pd.Series(pd.NA, index=frame.index)).notna()
        )
        |
        (
            frame.get("ra", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("dec", pd.Series(pd.NA, index=frame.index)).notna()
        )
    )
    return mask & sky


def percentile_transform(series: pd.Series) -> pd.Series:
    output = pd.Series(np.nan, index=series.index, dtype=float)
    valid = series.notna()
    if valid.any():
        output.loc[valid] = series.loc[valid].rank(
            method="average", pct=True
        )
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2d7_config.json").read_text(
            encoding="utf-8"
        )
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables",
        "assembled", "reports", "diagnostics"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg["prerequisite_validation"]
    prereq = (
        json.loads(prereq_path.read_text(encoding="utf-8"))
        if prereq_path.exists() else {}
    )
    prereq_ready = bool(
        prereq.get("STAGE6D3A2D5_PREREQUISITE_READY", False)
        and prereq.get("CANONICAL_D5_ANCHOR_READY", False)
        and prereq.get("FINAL_ROW_CONSERVATION_READY", False)
    )

    anchor_path = resolve_with_fallback(root / cfg["canonical_anchor"])
    anchor = (
        read_table(
            anchor_path,
            None,
            string_columns=["source_id"],
        )
        if anchor_path else pd.DataFrame()
    )
    if "source_id" in anchor.columns:
        anchor["source_id"] = clean_uint64(anchor["source_id"])
        anchor = anchor[anchor["source_id"].notna()].copy()
        anchor["source_id"] = anchor["source_id"].astype("uint64")
    anchor_ready = bool(
        not anchor.empty
        and {"source_id", "survey", "snr_native"}.issubset(anchor.columns)
        and not anchor.duplicated(["source_id", "survey"]).any()
        and set(anchor["survey"].dropna().astype(str))
        >= {"APOGEE_NATIVE", "GALAH_CORRECTED"}
    )
    galah_anchor_ids = set(
        anchor.loc[
            anchor["survey"] == "GALAH_CORRECTED", "source_id"
        ].astype("uint64")
    ) if anchor_ready else set()
    galah_anchor_text = {str(value) for value in galah_anchor_ids}

    suffixes = set(cfg["tabular_suffixes"])
    inventory = []
    schema_files = []

    for rel_root in cfg["scan_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if (
                not path.is_file()
                or path.suffix.lower() not in suffixes
                or path_excluded(path, root, cfg)
            ):
                continue
            try:
                columns, row_count = read_columns(path)
            except Exception as exc:
                inventory.append({
                    "path": safe_rel(path, root),
                    "row_count": "",
                    "identifier_columns": "",
                    "identifier_families": "",
                    "snr_contract": "",
                    "snr_columns": "",
                    "path_is_galah": str(path_is_galah(path, cfg)).lower(),
                    "read_error": f"{type(exc).__name__}: {exc}",
                })
                continue
            identifiers = identify_columns(columns, cfg)
            families = {
                column: family_for_column(column)
                for column in identifiers
            }
            contract, snr_columns = detect_snr_contract(columns, cfg)
            inventory.append({
                "path": safe_rel(path, root),
                "row_count": row_count,
                "identifier_columns": "|".join(identifiers),
                "identifier_families": json.dumps(
                    families, sort_keys=True
                ),
                "snr_contract": contract or "",
                "snr_columns": "|".join(snr_columns),
                "path_is_galah": str(path_is_galah(path, cfg)).lower(),
                "read_error": "",
            })
            if identifiers:
                schema_files.append({
                    "path": path,
                    "row_count": row_count,
                    "identifiers": identifiers,
                    "families": families,
                    "contract": contract,
                    "snr_columns": snr_columns,
                })

    write_csv(
        out / "tables/stage6d3a2d7_schema_inventory.csv",
        [
            "path", "row_count", "identifier_columns",
            "identifier_families", "snr_contract",
            "snr_columns", "path_is_galah", "read_error"
        ],
        inventory,
    )

    schema_files = sorted(
        schema_files,
        key=lambda item: (
            0 if path_is_galah(item["path"], cfg) else 1,
            -max(item["row_count"], 0),
            str(item["path"]),
        ),
    )[: int(cfg["maximum_schema_files"])]

    edges = []
    edge_rows = []
    node_profile_rows = []
    candidate_records = []

    for item in schema_files:
        path = item["path"]
        id_columns = item["identifiers"]
        required = sorted(
            set(id_columns + (item["snr_columns"] or []))
        )
        try:
            frame = read_table(
                path,
                required,
                string_columns=id_columns,
            )
        except Exception as exc:
            edge_rows.append({
                "edge_id": "",
                "path": safe_rel(path, root),
                "left_column": "",
                "left_family": "",
                "right_column": "",
                "right_family": "",
                "mapping_rows": 0,
                "conflicting_left_ids": "",
                "functional_ready": "false",
                "load_error": f"{type(exc).__name__}: {exc}",
            })
            continue

        normalized = {}
        for column in id_columns:
            family = item["families"][column]
            series = normalise_identifier(frame[column], family)
            normalized[column] = series
            finite = series.dropna().astype(str)
            direct_overlap = len(set(finite).intersection(galah_anchor_text))
            lengths = finite.str.len()
            node_profile_rows.append({
                "node_id": f"{safe_rel(path, root)}::{column}",
                "path": safe_rel(path, root),
                "column": column,
                "family": family,
                "non_null_rows": int(series.notna().sum()),
                "unique_values": int(series.nunique(dropna=True)),
                "minimum_length": int(lengths.min()) if len(lengths) else "",
                "median_length": float(lengths.median()) if len(lengths) else "",
                "maximum_length": int(lengths.max()) if len(lengths) else "",
                "direct_anchor_overlap_rows": direct_overlap,
                "sample_hash": hashlib.sha256(
                    "|".join(sorted(set(finite))[:100]).encode("utf-8")
                ).hexdigest()[:16],
            })

        for left_column in id_columns:
            for right_column in id_columns:
                if left_column == right_column:
                    continue
                left_family = item["families"][left_column]
                right_family = item["families"][right_column]
                if left_family == right_family:
                    continue
                mapping, diag = functional_edge(
                    normalized[left_column],
                    normalized[right_column],
                )
                edge_id = hashlib.sha256(
                    (
                        safe_rel(path, root)
                        + "::" + left_column + "->" + right_column
                    ).encode("utf-8")
                ).hexdigest()[:16]
                edge_rows.append({
                    "edge_id": edge_id,
                    "path": safe_rel(path, root),
                    "left_column": left_column,
                    "left_family": left_family,
                    "right_column": right_column,
                    "right_family": right_family,
                    "mapping_rows": diag["rows"],
                    "conflicting_left_ids": diag[
                        "conflicting_left_ids"
                    ],
                    "functional_ready": str(
                        diag["functional_ready"]
                    ).lower(),
                    "load_error": "",
                })
                if (
                    diag["functional_ready"]
                    and len(mapping) >= int(cfg["minimum_bridge_rows"])
                    and len(edges) < int(cfg["maximum_bridge_edges"])
                ):
                    edges.append({
                        "edge_id": edge_id,
                        "path": path,
                        "left_column": left_column,
                        "left_family": left_family,
                        "right_column": right_column,
                        "right_family": right_family,
                        "mapping": mapping,
                    })

        if item["contract"] and (
            path_is_galah(path, cfg)
            or any(
                family in {
                    "sobject", "galah_object", "object_generic",
                    "tmass", "gaia_dr2", "gaia_dr3",
                    "gaia_generic", "source_generic"
                }
                for family in item["families"].values()
            )
        ):
            snr = build_snr(
                frame,
                item["contract"],
                item["snr_columns"],
                cfg,
            )
            for column in id_columns:
                candidate_records.append({
                    "path": path,
                    "column": column,
                    "family": item["families"][column],
                    "values": normalized[column],
                    "snr": snr,
                    "contract": item["contract"],
                })

    write_csv(
        out / "tables/stage6d3a2d7_identifier_node_profiles.csv",
        [
            "node_id", "path", "column", "family",
            "non_null_rows", "unique_values",
            "minimum_length", "median_length", "maximum_length",
            "direct_anchor_overlap_rows", "sample_hash"
        ],
        node_profile_rows,
    )
    write_csv(
        out / "tables/stage6d3a2d7_functional_edge_audit.csv",
        [
            "edge_id", "path", "left_column", "left_family",
            "right_column", "right_family", "mapping_rows",
            "conflicting_left_ids", "functional_ready", "load_error"
        ],
        edge_rows,
    )

    adjacency: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for edge in edges:
        adjacency[edge["left_family"]].append(edge)

    graph_component_rows = []
    families = sorted(
        set(adjacency)
        | {edge["right_family"] for edge in edges}
        | {record["family"] for record in candidate_records}
    )
    undirected = defaultdict(set)
    for edge in edges:
        undirected[edge["left_family"]].add(edge["right_family"])
        undirected[edge["right_family"]].add(edge["left_family"])
    visited = set()
    component_index = 0
    for family in families:
        if family in visited:
            continue
        component_index += 1
        queue = [family]
        members = []
        visited.add(family)
        while queue:
            current = queue.pop()
            members.append(current)
            for neighbor in undirected[current]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        graph_component_rows.append({
            "component_id": component_index,
            "families": "|".join(sorted(members)),
            "contains_candidate_family": str(
                any(record["family"] in members for record in candidate_records)
            ).lower(),
            "contains_gaia_like_family": str(
                any(
                    member in {
                        "gaia_dr3", "gaia_generic", "source_generic"
                    }
                    for member in members
                )
            ).lower(),
        })
    write_csv(
        out / "tables/stage6d3a2d7_identifier_graph_components.csv",
        [
            "component_id", "families",
            "contains_candidate_family", "contains_gaia_like_family"
        ],
        graph_component_rows,
    )

    routes = []
    route_rows = []
    evaluated = 0

    for candidate_index, candidate in enumerate(candidate_records):
        start_family = candidate["family"]
        initial = pd.DataFrame({
            "current_value": candidate["values"],
            "snr_native": candidate["snr"],
        }).dropna(subset=["current_value"])
        queue = deque()
        queue.append((
            start_family,
            initial,
            [],
            {start_family},
        ))

        while queue and evaluated < int(cfg["maximum_routes_to_evaluate"]):
            current_family, current_frame, path_edges, seen_families = queue.popleft()

            parsed = clean_uint64(current_frame["current_value"])
            terminal = pd.DataFrame({
                "source_id": parsed,
                "snr_native": current_frame["snr_native"],
            }).dropna(subset=["source_id"])
            if not terminal.empty:
                product = aggregate_product(
                    terminal["source_id"],
                    terminal["snr_native"],
                    candidate["contract"],
                    (
                        "direct_terminal"
                        if not path_edges
                        else "identifier_graph:"
                        + "->".join(
                            [start_family]
                            + [edge["right_family"] for edge in path_edges]
                        )
                    ),
                )
                finite_ids = set(
                    product.loc[
                        product["snr_native"].notna(), "source_id"
                    ].astype("uint64")
                )
                overlap = galah_anchor_ids.intersection(finite_ids)
                overlap_fraction = (
                    len(overlap) / max(len(galah_anchor_ids), 1)
                )
                fingerprint = product_fingerprint(
                    product,
                    int(cfg["route_equivalence_round_decimals"]),
                )
                score = (
                    1_000_000_000 * len(overlap)
                    + 1_000_000 * len(finite_ids)
                    - 1000 * len(path_edges)
                )
                route_id = hashlib.sha256(
                    (
                        safe_rel(candidate["path"], root)
                        + "::" + candidate["column"]
                        + "::"
                        + "|".join(edge["edge_id"] for edge in path_edges)
                    ).encode("utf-8")
                ).hexdigest()[:16]
                route_row = {
                    "route_id": route_id,
                    "candidate_path": safe_rel(candidate["path"], root),
                    "candidate_column": candidate["column"],
                    "candidate_family": start_family,
                    "contract": candidate["contract"],
                    "route_depth": len(path_edges),
                    "route_families": "->".join(
                        [start_family]
                        + [edge["right_family"] for edge in path_edges]
                    ),
                    "edge_ids": "|".join(
                        edge["edge_id"] for edge in path_edges
                    ),
                    "finite_source_rows": len(finite_ids),
                    "anchor_overlap_rows": len(overlap),
                    "anchor_overlap_fraction": overlap_fraction,
                    "product_fingerprint": fingerprint,
                    "selection_score": score,
                }
                route_rows.append(route_row)
                routes.append({
                    "row": route_row,
                    "product": product,
                })
                evaluated += 1

            if len(path_edges) >= int(cfg["maximum_route_depth"]):
                continue

            for edge in adjacency.get(current_family, []):
                next_family = edge["right_family"]
                if next_family in seen_families:
                    continue
                mapped = current_frame.merge(
                    edge["mapping"],
                    left_on="current_value",
                    right_on="left_value",
                    how="inner",
                    validate="many_to_one",
                )
                if mapped.empty:
                    continue
                next_frame = pd.DataFrame({
                    "current_value": mapped["right_value"],
                    "snr_native": mapped["snr_native"],
                })
                queue.append((
                    next_family,
                    next_frame,
                    path_edges + [edge],
                    seen_families | {next_family},
                ))

    write_csv(
        out / "tables/stage6d3a2d7_route_evaluation.csv",
        [
            "route_id", "candidate_path", "candidate_column",
            "candidate_family", "contract", "route_depth",
            "route_families", "edge_ids", "finite_source_rows",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "product_fingerprint", "selection_score"
        ],
        sorted(
            route_rows,
            key=lambda row: (
                -float(row["selection_score"]),
                row["route_id"],
            ),
        ),
    )

    eligible = [
        item for item in routes
        if (
            item["row"]["anchor_overlap_rows"]
            >= int(cfg["minimum_anchor_overlap_rows"])
            and item["row"]["anchor_overlap_fraction"]
            >= float(cfg["minimum_anchor_overlap_fraction"])
        )
    ]
    eligible.sort(
        key=lambda item: (
            -item["row"]["selection_score"],
            item["row"]["route_depth"],
            item["row"]["route_id"],
        )
    )

    selected = None
    equivalent_tie_collapsed = False
    selection_error = ""
    if not eligible:
        selection_error = (
            "no opaque identifier-graph route meets the finite "
            "GALAH-anchor overlap gate"
        )
    else:
        top_score = eligible[0]["row"]["selection_score"]
        tied = [
            item for item in eligible
            if item["row"]["selection_score"] == top_score
        ]
        fingerprints = {
            item["row"]["product_fingerprint"] for item in tied
        }
        if len(tied) > 1 and len(fingerprints) > 1:
            selection_error = (
                "top identifier-graph routes are tied but produce "
                "non-equivalent source-level S/N products"
            )
        else:
            selected = tied[0]
            equivalent_tie_collapsed = len(tied) > 1

    selected_rows = []
    if selected:
        selected_rows.append({
            **selected["row"],
            "equivalent_tie_collapsed": str(
                equivalent_tie_collapsed
            ).lower(),
            "selection_reason": (
                "unique maximum finite anchor overlap, or an equivalent "
                "same-product tie collapsed deterministically"
            ),
        })
    write_csv(
        out / "tables/stage6d3a2d7_selected_galah_route.csv",
        [
            "route_id", "candidate_path", "candidate_column",
            "candidate_family", "contract", "route_depth",
            "route_families", "edge_ids", "finite_source_rows",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "product_fingerprint", "selection_score",
            "equivalent_tie_collapsed", "selection_reason"
        ],
        selected_rows,
    )

    final = anchor.copy()
    final["_anchor_row_id"] = np.arange(len(final), dtype=np.int64)
    if selected:
        galah_mask = final["survey"] == "GALAH_CORRECTED"
        replace_fields = [
            "snr_native", "snr_measurement_count",
            "snr_input_row_count", "snr_contract", "snr_id_route"
        ]
        for field in replace_fields:
            if field not in final.columns:
                final[field] = np.nan if field == "snr_native" else pd.NA
            final.loc[galah_mask, field] = (
                np.nan if field == "snr_native" else pd.NA
            )

        product = selected["product"].copy()
        product["source_id"] = clean_uint64(product["source_id"])
        product = product[product["source_id"].notna()].copy()
        product["source_id"] = product["source_id"].astype("uint64")
        if product.duplicated(["source_id", "survey"]).any():
            raise RuntimeError(
                "selected GALAH product is not unique in "
                "(source_id, survey)"
            )
        joined = final.merge(
            product[
                ["source_id", "survey"]
                + [
                    field for field in replace_fields
                    if field in product.columns
                ]
            ],
            on=["source_id", "survey"],
            how="left",
            suffixes=("", "__galah"),
            validate="one_to_one",
        )
        for field in replace_fields:
            candidate_field = field + "__galah"
            if candidate_field not in joined.columns:
                continue
            replace = joined["survey"] == "GALAH_CORRECTED"
            joined.loc[replace, field] = joined.loc[
                replace, candidate_field
            ].to_numpy()
            joined.drop(columns=[candidate_field], inplace=True)
        final = joined

    final = final.sort_values(
        "_anchor_row_id", kind="stable"
    ).reset_index(drop=True)
    row_conservation_ready = bool(
        len(final) == len(anchor)
        and final["_anchor_row_id"].is_unique
        and final["_anchor_row_id"].tolist() == list(range(len(anchor)))
        and not final.duplicated(["source_id", "survey"]).any()
        and final["source_id"].astype("uint64").tolist()
        == anchor["source_id"].astype("uint64").tolist()
        and final["survey"].astype(str).tolist()
        == anchor["survey"].astype(str).tolist()
    )

    if "snr_native" not in final.columns:
        final["snr_native"] = np.nan
    final["snr_log1p_native"] = np.log1p(
        pd.to_numeric(final["snr_native"], errors="coerce").clip(lower=0)
    )
    final["snr_within_survey_percentile"] = np.nan
    final["snr_support_half"] = pd.Series(
        pd.NA, index=final.index, dtype="string"
    )
    medians = {}
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        mask = final["survey"] == survey
        series = pd.to_numeric(
            final.loc[mask, "snr_native"], errors="coerce"
        )
        final.loc[
            mask, "snr_within_survey_percentile"
        ] = percentile_transform(series)
        median = float(series.median()) if series.notna().any() else np.nan
        medians[survey] = median
        if np.isfinite(median):
            final.loc[
                mask & final["snr_native"].notna()
                & (final["snr_native"] <= median),
                "snr_support_half"
            ] = "LOW_NATIVE_SNR_HALF"
            final.loc[
                mask & final["snr_native"].notna()
                & (final["snr_native"] > median),
                "snr_support_half"
            ] = "HIGH_NATIVE_SNR_HALF"

    support = complete_mask(final)
    complete_counts = {
        survey: int(
            ((final["survey"] == survey) & support).sum()
        )
        for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]
    }
    galah_ready = selected is not None
    complete_ready = all(
        complete_counts[survey]
        >= int(cfg["minimum_complete_rows_per_survey"])
        for survey in complete_counts
    )
    source_ready = bool(
        prereq_ready
        and anchor_ready
        and galah_ready
        and row_conservation_ready
        and complete_ready
    )

    coverage_rows = []
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        subset = final[final["survey"] == survey]
        coverage_rows.append({
            "survey": survey,
            "anchor_rows": len(subset),
            "finite_snr_rows": int(
                subset["snr_native"].notna().sum()
            ),
            "finite_snr_fraction": (
                float(subset["snr_native"].notna().mean())
                if len(subset) else 0.0
            ),
            "support_complete_rows": complete_counts[survey],
        })
    write_csv(
        out / "tables/stage6d3a2d7_final_join_coverage.csv",
        [
            "survey", "anchor_rows", "finite_snr_rows",
            "finite_snr_fraction", "support_complete_rows"
        ],
        coverage_rows,
    )

    final_path = (
        out
        / "assembled/stage6d3a2d7_production_source_with_snr.parquet"
    )
    try:
        final.drop(columns=["_anchor_row_id"]).to_parquet(
            final_path, index=False
        )
    except Exception:
        final_path = (
            out
            / "assembled/stage6d3a2d7_production_source_with_snr.csv"
        )
        final.drop(columns=["_anchor_row_id"]).to_csv(
            final_path, index=False
        )

    remaining = []
    if not prereq_ready:
        remaining.append({
            "gate": "STAGE6D3A2D6_PREREQUISITE_READY",
            "required_action": (
                "Restore PASS D5 canonical anchor and D6 audit prerequisites."
            ),
        })
    if not anchor_ready:
        remaining.append({
            "gate": "CANONICAL_ANCHOR_READY",
            "required_action": (
                "Canonical anchor must preserve unique source×survey rows "
                "and validated APOGEE S/N."
            ),
        })
    if not galah_ready:
        remaining.append({
            "gate": "GALAH_IDENTIFIER_GRAPH_ROUTE_READY",
            "required_action": selection_error,
        })
    if not row_conservation_ready:
        remaining.append({
            "gate": "FINAL_ROW_CONSERVATION_READY",
            "required_action": (
                "Final table must preserve the exact ordered canonical "
                "(source_id, survey) row universe."
            ),
        })
    if galah_ready and row_conservation_ready and not complete_ready:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_COMPLETE_ROWS_READY",
            "required_action": (
                f"Need at least {cfg['minimum_complete_rows_per_survey']} "
                "support-complete rows per survey. Observed: "
                + json.dumps(complete_counts, sort_keys=True)
            ),
        })
    write_csv(
        out / "tables/stage6d3a2d7_remaining_items.csv",
        ["gate", "required_action"],
        remaining,
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "canonical_anchor": safe_rel(anchor_path, root) if anchor_path else "",
        "canonical_anchor_rows": len(anchor),
        "schema_file_count": len(schema_files),
        "functional_edge_count": len(edges),
        "candidate_identifier_count": len(candidate_records),
        "evaluated_route_count": len(route_rows),
        "selected_route_id": (
            selected["row"]["route_id"] if selected else ""
        ),
        "selected_candidate_path": (
            selected["row"]["candidate_path"] if selected else ""
        ),
        "selected_candidate_column": (
            selected["row"]["candidate_column"] if selected else ""
        ),
        "selected_route_families": (
            selected["row"]["route_families"] if selected else ""
        ),
        "selected_route_depth": (
            selected["row"]["route_depth"] if selected else ""
        ),
        "selected_edge_ids": (
            selected["row"]["edge_ids"] if selected else ""
        ),
        "equivalent_route_tie_collapsed": equivalent_tie_collapsed,
        "survey_native_snr_medians": medians,
        "assembled_source_table": safe_rel(final_path, root),
        "assembled_rows": len(final),
        "support_complete_rows_by_survey": complete_counts,
        "prior_stage_outputs_modified": False,
        "STAGE6D3A2D6_PREREQUISITE_READY": prereq_ready,
        "CANONICAL_ANCHOR_READY": anchor_ready,
        "OPAQUE_IDENTIFIER_NAMESPACE_READY": True,
        "IDENTIFIER_VALUE_PROFILE_READY": True,
        "FUNCTIONAL_MAPPING_EDGE_GRAPH_READY": len(edges) > 0,
        "MAXIMUM_ROUTE_DEPTH_FROZEN": int(cfg["maximum_route_depth"]),
        "GALAH_IDENTIFIER_GRAPH_ROUTE_READY": galah_ready,
        "FINAL_ROW_CONSERVATION_READY": row_conservation_ready,
        "NATIVE_SNR_PRESERVED": galah_ready,
        "WITHIN_SURVEY_SNR_PERCENTILE_READY": galah_ready,
        "SURVEY_SPECIFIC_SNR_SUPPORT_READY": galah_ready,
        "PRODUCTION_SOURCE_COMPLETE_ROWS_READY": complete_ready,
        "PRODUCTION_SOURCE_ASSEMBLY_READY": source_ready,
        "TARGET_ABUNDANCE_MATCHING_FORBIDDEN": True,
        "SURVEY_NEUTRAL_SNR_PROXY_FORBIDDEN": True,
        "STAGE6D3A2D7_LINEAGE_READY": bool(
            prereq_ready
            and anchor_ready
            and galah_ready
            and row_conservation_ready
        ),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": source_ready,
    }
    write_json(
        out / "validation/stage6d3a2d7_validation.json",
        validation,
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "identifier_graph": {
            "schema_files": len(schema_files),
            "functional_edges": len(edges),
            "candidate_identifiers": len(candidate_records),
            "evaluated_routes": len(route_rows),
        },
        "selected_route": {
            "route_id": validation["selected_route_id"],
            "candidate_path": validation["selected_candidate_path"],
            "candidate_column": validation["selected_candidate_column"],
            "families": validation["selected_route_families"],
            "depth": validation["selected_route_depth"],
            "ready": galah_ready,
        },
        "source_assembly": {
            "rows": len(final),
            "support_complete_rows_by_survey": complete_counts,
            "row_conservation_ready": row_conservation_ready,
            "ready": source_ready,
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "An outcome-blind opaque identifier graph closes the GALAH S/N "
            "route while preserving the canonical source×survey row universe. "
            "Stage-6D3B is authorized."
            if source_ready else
            "The identifier value-space and every functional bridge route are "
            "audited. D3B remains blocked only by the listed disconnected "
            "identifier component or support-complete-row gap."
        ),
    }
    write_json(
        out / "summaries/stage6d3a2d7_summary.json",
        summary,
    )

    report = [
        "# Stage-6D3A2D7 opaque identifier-graph route closure",
        "",
        f"- Canonical anchor rows: `{len(anchor)}`",
        f"- Schema files: `{len(schema_files)}`",
        f"- Functional mapping edges: `{len(edges)}`",
        f"- Candidate identifier columns: `{len(candidate_records)}`",
        f"- Evaluated routes: `{len(route_rows)}`",
        f"- Selected route: `{validation['selected_route_families'] or 'not resolved'}`",
        f"- Selected depth: `{validation['selected_route_depth'] or 'not resolved'}`",
        f"- Final row conservation: `{row_conservation_ready}`",
        f"- APOGEE support-complete rows: `{complete_counts['APOGEE_NATIVE']}`",
        f"- GALAH support-complete rows: `{complete_counts['GALAH_CORRECTED']}`",
        f"- Stage-6D3B ready: `{source_ready}`",
        "",
        "Identifier columns are represented as opaque namespaces. Within-file "
        "left-to-right mappings are accepted only when functional. Route search "
        "does not assume in advance that a generic `source_id` is DR2, DR3, or "
        "a local catalogue identifier.",
        "",
        "No abundance, gradient, residual, or scientific outcome participates "
        "in graph construction or route selection.",
        "",
    ]
    (
        out
        / "reports/stage6d3a2d7_identifier_graph_route_closure.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
