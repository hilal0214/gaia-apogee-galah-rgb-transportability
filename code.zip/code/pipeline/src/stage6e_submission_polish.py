from __future__ import annotations
import argparse, csv, hashlib, json, os, re, shutil, subprocess, sys, zipfile
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

LABEL_LATEX = {
    "fe_h": r"$[\mathrm{Fe/H}]$",
    "mg_fe": r"$[\mathrm{Mg/Fe}]$",
    "si_fe": r"$[\mathrm{Si/Fe}]$",
    "ca_fe": r"$[\mathrm{Ca/Fe}]$",
    "ni_fe": r"$[\mathrm{Ni/Fe}]$",
}
LABEL_ORDER = ["fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe"]


def now():
    return datetime.now(timezone.utc).isoformat()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")


def canonical_sha(obj) -> str:
    b = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
    return hashlib.sha256(b).hexdigest()


def replace_exact(text: str, old: str, new: str, label: str) -> str:
    n = text.count(old)
    if n != 1:
        raise RuntimeError(f"{label}: expected one exact anchor, found {n}")
    return text.replace(old, new, 1)


def replace_regex(text: str, pattern: str, new: str, label: str, flags=re.S) -> str:
    out, n = re.subn(pattern, lambda _m: new, text, count=1, flags=flags)
    if n != 1:
        raise RuntimeError(f"{label}: expected one regex anchor, found {n}")
    return out


def locate_science_release(root: Path, cfg: dict, explicit: str | None):
    candidates = []
    if explicit:
        candidates.append(Path(explicit).resolve())
    candidates += [
        root / "outputs/stage6d5b1_windows_pathlength_hotfix/RGB_transportability_science_release_v0_26_1.zip",
        root / "outputs/stage6d5b1_windows_pathlength_hotfix/RGB_transportability_science_release_v0_26_1/RGB_transportability_science_release_v0_26_1.zip",
    ]
    downloads = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Downloads"
    if downloads.exists():
        candidates += list(downloads.glob("RGB_transportability_science_release_v0_26_1*.zip"))
    seen = set()
    checked = []
    for p in candidates:
        try:
            rp = p.resolve()
        except Exception:
            rp = p
        if rp in seen or not p.exists() or not p.is_file():
            continue
        seen.add(rp)
        got = sha_file(p)
        checked.append({"path": str(p), "sha256": got})
        if got == cfg["science_release_zip_sha256"]:
            return p, checked
    return None, checked


def extract_exact_evidence(root: Path, cfg: dict, explicit_release: str | None):
    # First allow exact unpacked project outputs.
    direct = {
        "comparisons": root / "outputs/stage6d4c1_practical_equivalence_path_hotfix/tables/gradient_required_comparisons.csv",
        "coordinate": root / "outputs/stage6d4c1_practical_equivalence_path_hotfix/tables/gradient_transport_coordinate_classification.csv",
    }
    direct_ok = (
        direct["comparisons"].exists()
        and direct["coordinate"].exists()
        and sha_file(direct["comparisons"]) == cfg["comparisons_sha256"]
        and sha_file(direct["coordinate"]) == cfg["coordinate_sha256"]
    )
    if direct_ok:
        return direct["comparisons"], direct["coordinate"], {"route": "direct_exact_project_outputs"}

    release, checked = locate_science_release(root, cfg, explicit_release)
    if release is None:
        write_json(
            root / cfg["output_dir"] / "validation/evidence_locator_failure.json",
            {
                "required_science_release_sha256": cfg["science_release_zip_sha256"],
                "checked": checked,
                "next_action": "Restore the exact Stage-6 science release ZIP under project outputs or place it in %USERPROFILE%\\Downloads. No CI endpoint will be guessed."
            },
        )
        raise RuntimeError("Exact Stage-6 science release not found; see evidence_locator_failure.json")

    evdir = root / cfg["output_dir"] / "evidence"
    evdir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(release, "r") as z:
        for key, member_key, sha_key, outname in [
            ("comparisons", "comparisons_member", "comparisons_sha256", "gradient_required_comparisons.csv"),
            ("coordinate", "coordinate_member", "coordinate_sha256", "gradient_transport_coordinate_classification.csv"),
        ]:
            member = cfg[member_key]
            if member not in z.namelist():
                raise RuntimeError(f"Science release missing required member: {member}")
            b = z.read(member)
            got = hashlib.sha256(b).hexdigest()
            if got != cfg[sha_key]:
                raise RuntimeError(f"Science release member SHA mismatch for {member}: {got}")
            (evdir / outname).write_bytes(b)
    return (
        evdir / "gradient_required_comparisons.csv",
        evdir / "gradient_transport_coordinate_classification.csv",
        {"route": "exact_science_release", "release": str(release), "release_sha256": sha_file(release)},
    )


def build_table5(comp_path: Path, coord_path: Path):
    comp = pd.read_csv(comp_path)
    coord = pd.read_csv(coord_path)
    required_comp = {
        "label", "coordinate", "comparison_id", "point_difference", "interval_low", "interval_high", "practical_margin"
    }
    required_coord = {
        "label", "coordinate", "full_support_slope", "balanced_slope", "survey_interaction_delta",
        "balanced_minus_full_low", "balanced_minus_full_high", "survey_interaction_low", "survey_interaction_high",
        "coordinate_classification"
    }
    if not required_comp.issubset(comp.columns):
        raise RuntimeError(f"comparison CSV schema mismatch: {sorted(comp.columns)}")
    if not required_coord.issubset(coord.columns):
        raise RuntimeError(f"coordinate CSV schema mismatch: {sorted(coord.columns)}")

    rows = []
    for label in LABEL_ORDER:
        for coordinate in ["R", "Z"]:
            cr = coord[(coord["label"] == label) & (coord["coordinate"] == coordinate)]
            if len(cr) != 1:
                raise RuntimeError(f"Expected one coordinate row for {label}/{coordinate}, found {len(cr)}")
            cr = cr.iloc[0]
            bf = comp[(comp["label"] == label) & (comp["coordinate"] == coordinate) & (comp["comparison_id"] == "FULL_TO_BALANCED")]
            si = comp[(comp["label"] == label) & (comp["coordinate"] == coordinate) & (comp["comparison_id"] == "SURVEY_INTERACTION_DELTA")]
            if len(bf) != 1 or len(si) != 1:
                raise RuntimeError(f"Missing comparison rows for {label}/{coordinate}")
            bf, si = bf.iloc[0], si.iloc[0]
            # Cross-file identity checks: these must be the same frozen results.
            checks = [
                abs(float(bf["interval_low"]) - float(cr["balanced_minus_full_low"])) < 1e-12,
                abs(float(bf["interval_high"]) - float(cr["balanced_minus_full_high"])) < 1e-12,
                abs(float(si["point_difference"]) - float(cr["survey_interaction_delta"])) < 1e-12,
                abs(float(si["interval_low"]) - float(cr["survey_interaction_low"])) < 1e-12,
                abs(float(si["interval_high"]) - float(cr["survey_interaction_high"])) < 1e-12,
                abs(float(bf["practical_margin"]) - float(cr["practical_margin"])) < 1e-12,
            ]
            if not all(checks):
                raise RuntimeError(f"Frozen comparison/coordinate identity mismatch for {label}/{coordinate}")
            rows.append({
                "label": label,
                "coordinate": coordinate,
                "beta_full": float(cr["full_support_slope"]),
                "beta_bal": float(cr["balanced_slope"]),
                "delta_foot": float(bf["point_difference"]),
                "delta_foot_lo": float(bf["interval_low"]),
                "delta_foot_hi": float(bf["interval_high"]),
                "delta_survey": float(si["point_difference"]),
                "delta_survey_lo": float(si["interval_low"]),
                "delta_survey_hi": float(si["interval_high"]),
                "margin": float(cr["practical_margin"]),
                "class": str(cr["coordinate_classification"]),
            })
    tab = pd.DataFrame(rows)
    expected = {
        ("fe_h", "R"): "INDETERMINATE", ("fe_h", "Z"): "INDETERMINATE",
        ("mg_fe", "R"): "INDETERMINATE", ("mg_fe", "Z"): "INDETERMINATE",
        ("si_fe", "R"): "INDETERMINATE", ("si_fe", "Z"): "TRANSPORT_STABLE",
        ("ca_fe", "R"): "INDETERMINATE", ("ca_fe", "Z"): "TRANSPORT_STABLE",
        ("ni_fe", "R"): "TRANSPORT_STABLE", ("ni_fe", "Z"): "TRANSPORT_STABLE",
    }
    got = {(r.label, r.coordinate): r["class"] for _, r in tab.iterrows()}
    if got != expected:
        raise RuntimeError(f"Frozen coordinate classification changed: {got}")
    return tab


def fs(x, n=4):
    return f"{float(x):+.{n}f}"


def fi(lo, hi, n=4):
    return f"[{float(lo):+.{n}f},{float(hi):+.{n}f}]"


def table5_tex(tab: pd.DataFrame) -> str:
    lines = []
    for label in LABEL_ORDER:
        for coordinate in ["R", "Z"]:
            r = tab[(tab.label == label) & (tab.coordinate == coordinate)].iloc[0]
            cls = "Stable" if r["class"] == "TRANSPORT_STABLE" else "Indet."
            foot = r"\shortstack{%s\\[-0.35ex]\scriptsize %s}" % (fs(r.delta_foot), fi(r.delta_foot_lo, r.delta_foot_hi))
            surv = r"\shortstack{%s\\[-0.35ex]\scriptsize %s}" % (fs(r.delta_survey), fi(r.delta_survey_lo, r.delta_survey_hi))
            lines.append(
                f"{LABEL_LATEX[label]} & {coordinate} & {fs(r.beta_full)} & {fs(r.beta_bal)} & {foot} & {surv} & {r.margin:.4f} & {cls} \\\\"
            )
    body = "\n".join(lines)
    return r"""\begin{table*}
\centering
\scriptsize
\setlength{\tabcolsep}{2.6pt}
\caption{Coordinate-level common-footprint transport audit for the five primary labels.  The footprint contrast is
$\Delta_{\rm foot}=\beta_{\rm bal}-\beta_{\rm full}$; its 95 per cent interval is the frozen dependence-robust
Bonferroni interval from the marginal bootstrap distributions.  $\Delta_{\rm surv}$ is the fitted GALAH-minus-APOGEE
interaction contrast on balanced common support and uses its direct 2.5--97.5 per cent bootstrap interval.  $\epsilon$
is the pre-specified practical-equivalence margin.  ``Stable'' means that the complete coordinate-level equivalence
rule is satisfied; ``Indet.'' means that neither practical equivalence nor a sensitivity class is established.}
\label{tab:transport_classification}
\begin{tabular}{@{}llrrllrl@{}}
\toprule
Label & Coord. & $\beta_{\rm full}$ & $\beta_{\rm bal}$ &
$\Delta_{\rm foot}$ (95\% CI) & $\Delta_{\rm surv}$ (95\% CI) & $\epsilon$ & Class\\
\midrule
""" + body + r"""
\bottomrule
\end{tabular}
\end{table*}"""


def add_bibitems(text: str) -> str:
    if "]{Jin2024}" in text:
        return text
    block = r"""
\bibitem[\protect\citeauthoryear{Cirasuolo et al.}{2020}]{Cirasuolo2020}
Cirasuolo M. et al., 2020, The Messenger, 180, 10

\bibitem[\protect\citeauthoryear{de Jong et al.}{2019}]{deJong2019}
de Jong R. S. et al., 2019, The Messenger, 175, 3

\bibitem[\protect\citeauthoryear{Jin et al.}{2024}]{Jin2024}
Jin S. et al., 2024, MNRAS, 530, 2688

"""
    anchor = r"\bibitem[\protect\citeauthoryear{Gaia Collaboration et al.}{2016}]{Gaia2016}"
    idx = text.find(anchor)
    if idx < 0:
        raise RuntimeError("Bibliography insertion anchor not found")
    return text[:idx] + block + text[idx:]


def polish(text: str, cfg: dict, tab: pd.DataFrame) -> str:
    # 1. Title: remove overclaiming 'Predicting'.
    text = replace_exact(
        text,
        r"{Predicting cross-survey chemical-label transportability in a Gaia--APOGEE--GALAH red-giant atlas}",
        "{" + cfg["title"] + "}",
        "title",
    )

    # 2. Abstract: denominator clarity + why this matters for the multi-survey era.
    old_abs = re.search(r"\\begin\{abstract\}.*?\\end\{abstract\}", text, re.S)
    if not old_abs:
        raise RuntimeError("Abstract not found")
    abstract = r"""\begin{abstract}
Putting heterogeneous spectroscopic surveys on a common mean abundance scale does not guarantee that the downstream
science is transportable.  We construct a claim-bounded Gaia--APOGEE--GALAH red-giant atlas and test cross-survey
chemical-label transportability at four levels: common-star calibration, a held-out atmospheric-sensitivity diagnostic,
common-footprint gradients, and alpha-sequence morphology.  Common-star calibration uses 45,040--57,883 overlap stars.
The authoritative full-support gradient fits are a separate analysis product, using 315,818--323,324 stars per label from
the 393,834-row frozen design layer; the 89,323-star Gaia-limited product is instead a capped end-to-end validation run.
In an amended five-label exploratory pilot, held-out transport difficulty is positively associated with a pre-defined
atmospheric-sensitivity burden (pooled coefficient 0.410; bootstrap $P(\beta>0)=1.000$; 95 per cent interval
$[0.246,0.520]$; permutation $p=0.0014$).  On an outcome-blind common footprint of 34,177 stars in 208 HEALPix cells,
$[\mathrm{Ni/Fe}]$ is transport-stable in both radial and vertical gradients; $[\mathrm{Si/Fe}]$ and $[\mathrm{Ca/Fe}]$
are vertically stable but radially indeterminate, while $[\mathrm{Fe/H}]$ and $[\mathrm{Mg/Fe}]$ are indeterminate in both
coordinates.  A separately pre-registered radial-transition branch is closed as not adequately powered before real
alternative-model interpretation.  Finally, a power-calibrated morphology audit on 26,180 eligible common-support RGB
stars is indeterminate for valley location, sequence separation, and high-$\alpha$ fraction; the cleanest descriptive
survey-scale difference is a smaller fitted GALAH sequence separation at $[\mathrm{Fe/H}]=-0.6$ and $-0.4$.  The central
lesson for the increasingly multi-survey era represented by WEAVE, 4MOST, and MOONS is that calibration is only the first
step: transportability must be demonstrated for the specific scientific estimand and support set being combined.
\end{abstract}"""
    text = text[:old_abs.start()] + abstract + text[old_abs.end():]

    # 3. Introduction: unify the four-question framing and remove duplicated 3+1 structure.
    pattern = r"The analysis is organised around three transport questions\..*?A separate radial-break experiment is retained only as a power-calibration result because its pre-specified synthetic recovery gate failed before the real break model was opened\."
    intro = r"""The analysis is organised around four deliberately separated transport questions.  First, how strongly does empirical
APOGEE--GALAH calibration quality vary from label to label?  Second, within the labels supported by the frozen archive,
is held-out transport quality associated with a pre-defined atmospheric-sensitivity burden?  Third, do the authoritative
global chemical gradients survive restriction to an outcome-blind common footprint and subsequent survey balancing?
Fourth, does the \emph{shape} of the low-$\alpha$/high-$\alpha$ structure survive transfer between surveys on a fixed
homogenised abundance coordinate?  These questions have different denominators and different evidential targets, so overlap
calibration, predictive diagnostics, global gradients, common-footprint robustness, and morphology are not collapsed into
a single ``combined-survey'' claim.

The distinction is increasingly important as Galactic spectroscopy moves into a high-multiplex, multi-survey regime.
WEAVE is designed to complement Gaia with large stellar spectroscopic samples and detailed abundances \citep{Jin2024};
4MOST is likewise a wide-field, high-multiplex spectroscopic survey facility \citep{deJong2019}; and MOONS extends
multi-object spectroscopy into the optical/near-infrared on the VLT \citep{Cirasuolo2020}.  Their wavelength coverage,
resolution modes, target selection, and survey footprints are not interchangeable by construction.  A transferable
abundance zero-point is therefore necessary but not sufficient: the relevant question is whether a stated downstream
estimand remains practically equivalent after the support on which it is evaluated has been made explicit.

The resulting framework is neither a universal abundance-scale model nor a volume-complete Galactic census.  The five-label
atmospheric-burden analysis remains exploratory, the common-footprint experiment is a conditional robustness test on shared
APOGEE--GALAH support, and the Stage-5B latent-component family remains an anonymous secondary diagnostic.  The morphology
audit uses pre-specified power and equivalence rules and is interpreted with an explicit mixture-identifiability caveat.  A
separate radial-transition experiment is retained only as a power-calibration result because its synthetic recovery gate
failed before either real alternative model was opened."""
    text = replace_regex(text, pattern, intro, "introduction-four-question")

    # 4. Sample denominator ladder + parent arithmetic.
    old_sample = "Survey-specific quality flags are then applied. Gaia records are queried in restartable cached chunks and transformed to a Galactocentric cylindrical frame. The merged parent layer contains 1,591,571 entries. The 200,000-source Gaia-limited production run yields 89,323 clean RGB stars after the full spectroscopic, astrometric, phase-space, and plausibility gates. This clean sample is a quality-gated analysis set, not a volume-complete census."
    new_sample = r"""Survey-specific quality flags are then applied.  The raw survey inputs contain 1,651,489 rows in total
(733,901 APOGEE plus 917,588 GALAH).  Exactly 59,918 Gaia source identifiers occur in both inputs; representing those
shared sources once gives the 1,591,571-record merged cross-survey parent layer.

The workflow then branches into different analysis products rather than one nested ``clean sample''.  A deliberately capped
200,000-source Gaia query is used as an end-to-end atlas and quality-validation run, of which 89,323 stars survive the full
spectroscopic, astrometric, phase-space, and plausibility gates.  This 89,323-star validation product is \emph{not} the
denominator of the authoritative Stage-4B gradients in Table~\ref{tab:global_gradients}.  Those fits start from the full
393,834-row frozen Stage-4A analysis-design layer and retain 315,818--323,324 stars after label-specific finite-value and
quality gates.  The later support-restricted products are narrower by design: 34,177 stars enter the balanced common-footprint
analysis and 26,180 eligible stars enter the alpha-morphology audit.  Each denominator therefore belongs to a distinct
estimand and is kept explicit throughout the manuscript."""
    text = replace_exact(text, old_sample, new_sample, "sample-ladder")

    # Replace Table 1 with an explicit denominator ladder while preserving its label/number.
    table1_pattern = r"\\begin\{table\}\s*\\centering\s*\\caption\{Spectroscopic sample flow before final Gaia-clean atlas construction\..*?\\end\{table\}"
    table1 = r"""\begin{table*}
\centering
\caption{Sample and denominator ladder. Survey-specific rows describe input availability before cross-survey de-duplication and are not strictly nested because the signal-to-noise and parameter gates are evaluated independently. Joint rows identify the distinct downstream analysis sets. The 89,323-star capped validation product is not the denominator of the authoritative Stage-4B gradients.}
\label{tab:sample_flow}
\begin{tabular}{lrrl}
\toprule
Layer & APOGEE & GALAH & Joint count / role\\
\midrule
Initial read & 733,901 & 917,588 & ---\\
Has Gaia source identifier & 733,901 & 917,588 & ---\\
RGB parameter gate & 380,094 & 283,471 & ---\\
Signal-to-noise gate & 664,646 & 813,743 & ---\\
Clean spectroscopic gate & 362,486 & 199,974 & ---\\
\midrule
Shared Gaia source IDs & --- & --- & 59,918 (represented once after merge)\\
Unique merged parent & --- & --- & 1,591,571\\
Capped Gaia validation input & --- & --- & 200,000\\
Capped validation survivors & --- & --- & 89,323\\
Stage-4A full design layer & --- & --- & 393,834\\
Stage-4B label denominators & --- & --- & 315,818--323,324\\
Balanced common footprint & --- & --- & 34,177\\
Stage-8 morphology eligible & --- & --- & 26,180\\
\bottomrule
\end{tabular}
\end{table*}"""
    text = replace_regex(text, table1_pattern, table1, "table1-denominator-ladder")

    # Table 4 caption becomes denominator-aware.
    text = replace_exact(
        text,
        r"\caption{Authoritative Stage-4B global gradients. Intervals are the frozen 95 per cent draw intervals. Coefficients are in ${\rm dex~kpc^{-1}}$.}",
        r"\caption{Authoritative Stage-4B global gradients. Fits start from the 393,834-row Stage-4A design layer; $N$ is the label-specific denominator after finite-value and quality gates and therefore differs among labels. The separate 89,323-star capped validation run is not used as the Table-4 denominator. Intervals are the frozen 95 per cent draw intervals; coefficients are in ${\rm dex~kpc^{-1}}$.}",
        "table4-caption",
    )

    # Global-gradient method paragraph.
    old_method = "The frozen implementation uses a Huber robust loss \\citep{Huber1964}, label-specific residual scale, deterministic convergence rules, and spatial-block uncertainty propagation. The Stage-4B estimate table stores the point estimates, cluster standard errors, draw dispersion, 2.5/16/50/84/97.5 percentiles, sign stability, and interval-exclusion flags."
    new_method = "The frozen implementation uses a Huber robust loss \\citep{Huber1964}, label-specific residual scale, deterministic convergence rules, and spatial-block uncertainty propagation. The fit is evaluated on the full 393,834-row Stage-4A design layer rather than on the separate 89,323-star capped validation product; label-specific finite-value and quality gates produce the Table~\\ref{tab:global_gradients} denominators of 315,818--323,324 stars. The Stage-4B estimate table stores the point estimates, cluster standard errors, draw dispersion, 2.5/16/50/84/97.5 percentiles, sign stability, and interval-exclusion flags."
    text = replace_exact(text, old_method, new_method, "stage4b-denominator-method")

    # 5. Methods: explain the two frozen CI constructions.
    anchor = r"The pre-specified outcome classes are \textsc{transport-stable}, \textsc{footprint-sensitive}, \textsc{survey-sensitive}, and \textsc{indeterminate}."
    addition = r"""

The two transport contrasts use different frozen uncertainty constructions.  For the balanced-minus-full footprint contrast,
the full-support and common-footprint fits do not have a natural paired bootstrap because their resampling populations and
block systems differ.  We therefore use the pre-specified dependence-robust Bonferroni interval
$[q_{0.0125}(\beta_{\rm bal})-q_{0.9875}(\beta_{\rm full}),\,
q_{0.9875}(\beta_{\rm bal})-q_{0.0125}(\beta_{\rm full})]$.  The GALAH-minus-APOGEE survey interaction is a directly
fitted parameter on balanced common support and uses its own 2.5--97.5 per cent bootstrap interval.  Both interval families
are reported explicitly in Table~\ref{tab:transport_classification}."""
    text = replace_exact(text, anchor, anchor + addition, "ci-methods")

    # 6. Table 5 exact frozen CIs.
    table_pattern = r"\\begin\{table\*\}\s*\\centering\s*\\scriptsize\s*\\caption\{Common-footprint transport summary for the five primary labels\..*?\\end\{table\*\}"
    text = replace_regex(text, table_pattern, table5_tex(tab), "table5")
    text = replace_exact(
        text,
        "Table~\\ref{tab:transport_classification} compares the frozen full-support gradients with the outcome-blind survey-balanced common-footprint fits and reports the fitted GALAH--APOGEE interaction contrasts. The common-footprint analysis does not classify any primary label as footprint-sensitive or survey-sensitive.",
        "Table~\\ref{tab:transport_classification} makes the common-footprint decision path directly auditable for each coordinate. It reports the authoritative full-support and balanced slopes, the balanced-minus-full footprint contrast with its conservative frozen 95 per cent interval, and the GALAH-minus-APOGEE interaction with its direct frozen 95 per cent interval. No primary label is classified as footprint-sensitive or survey-sensitive.",
        "table5-results-prose",
    )

    # Clean up denominator-risk prose.
    text = text.replace(
        "The full-support coefficients remain the authoritative measurements for the frozen clean sample, but they are no longer the only quantitative statement about survey support.",
        "The full-support coefficients remain the authoritative measurements for their label-specific Stage-4B support, but they are no longer the only quantitative statement about survey dependence.",
    )
    text = text.replace(
        "These coefficients describe the quality-gated spectroscopic sample and should not be interpreted as selection-function-corrected gradients of the entire Milky Way.",
        "These coefficients describe the label-specific full-support Stage-4B samples and should not be interpreted as selection-function-corrected gradients of the entire Milky Way.",
    )
    old_sel = "The atlas is not volume complete. APOGEE and GALAH have different target selections, footprints, wavelength ranges, magnitude limits, and abundance systematics. The Gaia-limited production query adds an additional practical source-list restriction. The measured gradients must be interpreted within the clean cross-survey RGB sample and its frozen gates."
    new_sel = "The atlas is not volume complete. APOGEE and GALAH have different target selections, footprints, wavelength ranges, magnitude limits, and abundance systematics. The relevant support also changes with the estimand: Stage-4B gradients use label-specific subsets of the 393,834-row full design layer, common-footprint transport uses 34,177 stars, and morphology uses 26,180 eligible stars. The 89,323-star Gaia-limited product is a separate capped end-to-end validation run. None of these denominators is interpreted as a selection-function-corrected Milky Way census."
    text = replace_exact(text, old_sel, new_sel, "selection-denominators")

    # 7. Discussion: explicit why-astronomers-should-care section.
    marker = r"\subsection{Exploratory predictability and its limit}"
    why = r"""\subsection{Why this matters for the next multi-survey era}

The practical problem addressed here is becoming more rather than less important.  WEAVE, 4MOST, and MOONS are designed
to deliver large spectroscopic samples with different wavelength ranges, resolution modes, target-selection functions, and
sky footprints \citep{Jin2024,deJong2019,Cirasuolo2020}.  Combining those data with Gaia and with legacy surveys will
create enormous statistical leverage, but it will also make formally tiny random errors compatible with non-negligible
cross-survey systematics.  In that regime, matching abundance zero-points is only the first layer of validation.

The transferable object is the \emph{scientific estimand}, not the catalogue label in isolation.  A chemical label may show
a small common-star residual and yet yield a footprint-sensitive spatial gradient; a gradient may be stable while a
population-morphology decomposition remains weakly identifiable; and an apparently interesting transition may be
scientifically undecidable because the design lacks power.  The workflow developed here turns those possibilities into
separate, pre-declared outcomes.  This is directly scalable to future survey combinations: define common support without
using the abundance outcome, preserve one estimator contract, specify practical-equivalence margins before interpretation,
and report \textsc{indeterminate} when the data establish neither equivalence nor a coherent sensitivity signal.

"""
    idx = text.find(marker)
    if idx < 0:
        raise RuntimeError("Discussion insertion marker not found")
    text = text[:idx] + why + text[idx:]
    text = replace_exact(
        text,
        r"\subsection{Exploratory predictability and its limit}",
        r"\subsection{Exploratory atmospheric-sensitivity association and its limit}",
        "exploratory-subsection-title",
    )
    text = text.replace(
        "The positive $B_{\rm atmos}$ association suggests that transport difficulty contains predictable structure tied to the same atmospheric sensitivities that enter the empirical cross-survey calibration. This provides a useful diagnostic for prioritising labels and designing future survey-combination tests.",
        "The positive $B_{\rm atmos}$ association shows that held-out transport difficulty covaries with the same atmospheric sensitivities that enter the empirical cross-survey calibration. This provides an exploratory diagnostic for prioritising labels and designing future survey-combination tests.",
    )

    # 8. Conclusions: explicit denominator ladder and future-survey relevance.
    old_item1 = r"\item The merged spectroscopic parent layer contains 1,591,571 catalogue entries, and the Gaia-limited production run contains 89,323 clean RGB stars after frozen quality and phase-space gates."
    new_item1 = r"\item The two survey inputs contain 1,651,489 rows; 59,918 shared Gaia source identifiers are represented once, giving 1,591,571 unique merged parent records. The 89,323-star Gaia-limited product is a capped end-to-end validation run, whereas the authoritative Stage-4B gradients use 315,818--323,324 stars per label from the 393,834-row full analysis-design layer."
    text = replace_exact(text, old_item1, new_item1, "conclusion-denominator")
    old_item4 = r"\item The authoritative Stage-4B gradients remain the frozen full-support reference. The common-footprint extension uses 34,177 stars in 208 primary HEALPix cells, outcome-blind survey balancing, the same Huber estimator contract, and 4096 spatial-cluster multiplier draws. $[\mathrm{Ni/Fe}]$ is transport-stable in both radial and vertical gradients; no primary label is classified as footprint-sensitive or survey-sensitive."
    new_item4 = r"\item The authoritative Stage-4B gradients remain the full-support reference. The common-footprint extension uses 34,177 stars in 208 primary HEALPix cells, outcome-blind survey balancing, the same Huber estimator contract, and 4096 spatial-cluster multiplier draws. Coordinate-level footprint and survey-interaction 95 per cent intervals are reported explicitly; $[\mathrm{Ni/Fe}]$ is transport-stable in both coordinates, while no primary label is footprint-sensitive or survey-sensitive."
    text = replace_exact(text, old_item4, new_item4, "conclusion-table5")

    # Add one final broad implication before Data and Code Availability.
    conclusion_tail = r"""
The broader implication is methodological: as WEAVE, 4MOST, MOONS, Gaia, and legacy spectroscopic surveys are combined,
claim strength should follow the transportability of the downstream estimand rather than the apparent precision of a
cross-calibrated catalogue.  The framework used here provides a reproducible route for making that distinction explicit.

"""
    marker2 = r"\section*{Data and Code Availability}"
    idx2 = text.find(marker2)
    if idx2 < 0:
        raise RuntimeError("Data/Code marker not found")
    text = text[:idx2] + conclusion_tail + text[idx2:]

    text = add_bibitems(text)
    return text


def compile_three(mdir: Path):
    pdflatex = shutil.which("pdflatex")
    if not pdflatex:
        raise RuntimeError("pdflatex not found")
    runs = []
    for i in range(3):
        cp = subprocess.run([pdflatex, "-interaction=nonstopmode", "-halt-on-error", "main.tex"], cwd=mdir, capture_output=True, text=True)
        runs.append({"pass": i + 1, "returncode": cp.returncode, "stdout_tail": cp.stdout[-5000:], "stderr_tail": cp.stderr[-1200:]})
        if cp.returncode != 0:
            break
    log = (mdir / "main.log").read_text(encoding="utf-8", errors="ignore") if (mdir / "main.log").exists() else ""
    overfull = [x for x in log.splitlines() if "Overfull \\hbox" in x]
    undefined = [x for x in log.splitlines() if "undefined" in x.lower() and ("citation" in x.lower() or "reference" in x.lower())]
    pages = None
    mm = re.findall(r"Output written on main\.pdf \((\d+) pages?", log)
    if mm:
        pages = int(mm[-1])
    clean = len(runs) == 3 and all(r["returncode"] == 0 for r in runs) and (mdir / "main.pdf").exists() and not overfull and not undefined
    return clean, runs, overfull, undefined, pages


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    ap.add_argument("--science-release", default=None)
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    cfg = json.loads((root / "config/stage6e_config.json").read_text(encoding="utf-8"))
    protocol = json.loads((root / "protocol/stage6e_protocol.json").read_text(encoding="utf-8"))

    sc = cfg["sample_counts"]
    arithmetic = sc["apogee_raw"] + sc["galah_raw"] - sc["shared_gaia_ids"] == sc["merged_unique_parent"]
    if not arithmetic:
        raise RuntimeError("Merged-parent arithmetic guard failed")

    baseline = root / cfg["embedded_baseline_zip"]
    if not baseline.exists() or sha_file(baseline) != cfg["embedded_baseline_zip_sha256"]:
        raise RuntimeError("Embedded D6C baseline ZIP identity failed")

    comp_path, coord_path, evidence_route = extract_exact_evidence(root, cfg, args.science_release)
    if sha_file(comp_path) != cfg["comparisons_sha256"] or sha_file(coord_path) != cfg["coordinate_sha256"]:
        raise RuntimeError("Exact Table-5 evidence SHA guard failed")
    tab = build_table5(comp_path, coord_path)

    out = root / cfg["output_dir"]
    mdir = out / "manuscript"
    if mdir.exists():
        shutil.rmtree(mdir)
    mdir.mkdir(parents=True)
    with zipfile.ZipFile(baseline, "r") as z:
        z.extractall(mdir)
    if sha_file(mdir / "main.tex") != cfg["baseline_main_tex_sha256"]:
        raise RuntimeError("Baseline main.tex identity failed")

    text = (mdir / "main.tex").read_text(encoding="utf-8")
    text = polish(text, cfg, tab)
    if re.search(r"\\(?:input|include)\s*\{", text):
        raise RuntimeError("Flat-main guard failed")
    for forbidden in [
        "Predicting cross-survey chemical-label transportability",
        "The analysis is organised around three transport questions",
        "The measured gradients must be interpreted within the clean cross-survey RGB sample",
    ]:
        if forbidden in text:
            raise RuntimeError(f"Stale reviewer-risk wording remains: {forbidden}")
    (mdir / "main.tex").write_text(text, encoding="utf-8")

    # Machine-readable audit tables.
    (out / "tables").mkdir(parents=True, exist_ok=True)
    tab.to_csv(out / "tables/table5_exact_frozen_ci_audit.csv", index=False)
    pd.DataFrame([
        ["APOGEE raw input rows", sc["apogee_raw"], "survey input"],
        ["GALAH raw input rows", sc["galah_raw"], "survey input"],
        ["Shared Gaia source IDs", sc["shared_gaia_ids"], "cross-survey overlap represented once"],
        ["Unique merged parent records", sc["merged_unique_parent"], "deduplicated parent"],
        ["Capped Gaia query input", sc["gaia_capped_input"], "end-to-end validation run"],
        ["Capped validation survivors", sc["gaia_capped_clean"], "not Table-4 denominator"],
        ["Stage-4A design rows", sc["stage4a_design_rows"], "full gradient design before label gates"],
        ["Stage-4B label N range", "315818--323324", "authoritative gradients"],
        ["Balanced common footprint", sc["common_footprint_rows"], "transport robustness"],
        ["Stage-8 morphology eligible", sc["morphology_rows"], "morphology audit"],
    ], columns=["layer", "rows", "role"]).to_csv(out / "tables/sample_denominator_ladder.csv", index=False)

    # Copy machine-readable audit into manuscript release.
    mr = mdir / "machine_readable"
    mr.mkdir(exist_ok=True)
    shutil.copy2(out / "tables/table5_exact_frozen_ci_audit.csv", mr / "table5_exact_frozen_ci_audit.csv")
    shutil.copy2(out / "tables/sample_denominator_ladder.csv", mr / "sample_denominator_ladder.csv")

    clean, runs, overfull, undefined, pages = compile_three(mdir)

    reviewer = f"""# Stage-6E reviewer-facing closure\n\n- TITLE_SHARPENED=true\n- SAMPLE_DENOMINATOR_LADDER_CLOSED=true\n- MERGED_PARENT_ARITHMETIC_CLOSED={str(arithmetic).lower()}\n- TABLE5_EXACT_FROZEN_CI_READY=true\n- WEAVE_4MOST_MOONS_MOTIVATION_INTEGRATED=true\n- NEW_REAL_FIT=false\n- NEW_BOOTSTRAP=false\n- STAGE8_CLASSIFICATION_CHANGED=false\n- PDF_COMPILED_CLEANLY={str(clean).lower()}\n- PDF_PAGES={pages}\n- OVERFULL_HBOX_COUNT={len(overfull)}\n- UNDEFINED_REFERENCE_OR_CITATION_COUNT={len(undefined)}\n\nTable-5 evidence:\n- comparisons SHA256: {cfg['comparisons_sha256']}\n- coordinate classification SHA256: {cfg['coordinate_sha256']}\n\nHuman metadata placeholders remain unresolved.\n"""
    (mdir / "STAGE6E_REVIEWER_AUDIT.md").write_text(reviewer, encoding="utf-8")

    validation = {
        "stage": cfg["stage"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "BASELINE_D6C_IDENTITY_READY": True,
        "EXACT_TABLE5_COMPARISON_EVIDENCE_READY": True,
        "EXACT_TABLE5_COORDINATE_CLASSIFICATION_READY": True,
        "TABLE5_COMPARISON_SHA256": sha_file(comp_path),
        "TABLE5_COORDINATE_SHA256": sha_file(coord_path),
        "EVIDENCE_ROUTE": evidence_route,
        "TITLE_SHARPENED_TO_TESTING": True,
        "SAMPLE_DENOMINATOR_LADDER_CLOSED": True,
        "MERGED_PARENT_ARITHMETIC_CLOSED": arithmetic,
        "TABLE5_EXACT_FROZEN_CI_READY": True,
        "WEAVE_4MOST_MOONS_MOTIVATION_INTEGRATED": True,
        "NEW_REAL_SCIENCE_FIT_PERFORMED": False,
        "NEW_BOOTSTRAP_PERFORMED": False,
        "FROZEN_SCIENCE_GATE_CHANGED": False,
        "STAGE8_OVERALL_CLASSIFICATION": "INDETERMINATE",
        "THREE_PASS_COMPILE_READY": len(runs) == 3 and all(r["returncode"] == 0 for r in runs),
        "NO_UNDEFINED_CITATIONS_OR_REFERENCES": not undefined,
        "NO_OVERFULL_HBOX": not overfull,
        "PDF_PAGES": pages,
        "PDF_COMPILED_CLEANLY": clean,
        "MAIN_TEX_SHA256": sha_file(mdir / "main.tex"),
        "MAIN_PDF_SHA256": sha_file(mdir / "main.pdf") if (mdir / "main.pdf").exists() else None,
        "SCIENTIFIC_EDITORIAL_SUBMISSION_READY": clean,
        "HUMAN_METADATA_READY": False,
        "MNRAS_PUBLIC_SUBMISSION_READY": False,
        "PROTOCOL_CANONICAL_SHA256": canonical_sha(protocol),
        "COMPILE_RUNS": runs,
    }
    write_json(mdir / "STAGE6E_VALIDATION.json", validation)
    write_json(mdir / "PROVENANCE_MANIFEST_STAGE6E.json", {
        "baseline_zip_sha256": cfg["embedded_baseline_zip_sha256"],
        "baseline_main_tex_sha256": cfg["baseline_main_tex_sha256"],
        "comparison_evidence_sha256": cfg["comparisons_sha256"],
        "coordinate_classification_sha256": cfg["coordinate_sha256"],
        "science_mutation": False,
        "created_utc": now(),
    })

    # Remove stale validation / compile intermediates from copied D6C package.
    for name in [
        "PDF_PREFLIGHT_D6C.json", "PROVENANCE_MANIFEST_D6C.json", "SHA256SUMS_STAGE6D6C.csv", "STAGE6D6C5_VALIDATION.json",
        "main.aux", "main.log", "main.out"
    ]:
        p = mdir / name
        if p.exists():
            p.unlink()

    # New checksum manifest.
    rows = []
    for p in sorted(mdir.rglob("*")):
        if p.is_file() and p.name != "SHA256SUMS_STAGE6E.csv":
            rows.append((p.relative_to(mdir).as_posix(), p.stat().st_size, sha_file(p)))
    with (mdir / "SHA256SUMS_STAGE6E.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["path", "size_bytes", "sha256"])
        w.writerows(rows)

    release = out / cfg["release_name"]
    if release.exists():
        release.unlink()
    with zipfile.ZipFile(release, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(mdir.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(mdir))

    final = dict(validation)
    final["RELEASE_ZIP_RELATIVE_PATH"] = str(release.relative_to(root))
    final["RELEASE_ZIP_SHA256"] = sha_file(release)
    write_json(out / "validation/stage6e_validation.json", final)
    print(json.dumps(final, indent=2, ensure_ascii=False))
    return 0 if clean else 2


if __name__ == "__main__":
    raise SystemExit(main())
