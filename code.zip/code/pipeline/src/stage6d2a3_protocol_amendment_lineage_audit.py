from __future__ import annotations
import argparse,csv,hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
from typing import Any
import pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def rel(p,r):
    try:return str(p.resolve().relative_to(r.resolve())).replace('\\','/')
    except:return str(p).replace('\\','/')
def csha(v): return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def wjson(p,v): p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False,default=str)+'\n').encode())
def wcsv(p,fields,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); w.writeheader(); w.writerows(rows)
def read(p): return pd.read_parquet(p) if p.suffix.lower()=='.parquet' else pd.read_csv(p)
def alias(cols,opts):
    d={c.lower():c for c in cols}
    for x in opts:
        if x.lower() in d:return d[x.lower()]
    return None
def tscore(text,pos,neg):
    s=str(text).lower(); return 10*sum(x in s for x in pos)-10*sum(x in s for x in neg)

def audit(coeff_path,fold_path,cfg):
    cf=read(coeff_path); mp={k:alias(list(cf.columns),v) for k,v in cfg['column_aliases'].items()}
    req=['label','fold','analysis_set','model_role']; miss=[k for k in req if not mp.get(k)]
    if miss: raise RuntimeError('Missing coefficient lineage columns: '+', '.join(miss))
    cf=cf.rename(columns={v:k for k,v in mp.items() if v}).copy()
    cf['label']=cf['label'].astype(str).str.lower(); cf['fold']=pd.to_numeric(cf['fold'],errors='coerce')
    cf=cf[cf['label'].isin(cfg['available_labels'])]
    ff=read(fold_path); fc=alias(list(ff.columns),['heldout_fold','crossfit_fold','fold'])
    if not fc: raise RuntimeError('Fold assignment table lacks fold column')
    counts=pd.to_numeric(ff[fc],errors='coerce').value_counts().to_dict()
    pref=cfg['semantic_preferences']; exp=set(cfg['expected_folds']); rows=[]
    for (aset,role),g in cf.groupby(['analysis_set','model_role'],dropna=False):
        g=g[g['fold'].isin(cfg['expected_folds'])]
        complete=[]; dup=0; missing=0; ne_checks=[]; hash_checks=[]
        for lab in cfg['available_labels']:
            sub=g[g['label']==lab]; vc=sub.groupby('fold').size().to_dict(); obs={int(x) for x in vc}
            dup += sum(max(int(n)-1,0) for n in vc.values()); missing += len(exp-obs)
            if obs==exp and all(int(n)==1 for n in vc.values()): complete.append(lab)
            if 'n_eval' in sub.columns:
                for _,it in sub.iterrows():
                    try: ne_checks.append(int(it['n_eval'])>0 and int(it['n_eval'])<=int(counts.get(int(it['fold']),-1)))
                    except: ne_checks.append(False)
        if 'evaluation_hash' in g.columns:
            for _,sub in g.groupby('fold'):
                vals=set(sub['evaluation_hash'].dropna().astype(str)); hash_checks.append(len(vals)==1)
        structural=1000*len(complete)-5000*dup-100*missing
        semantic=tscore(aset,pref['analysis_set_positive'],pref['analysis_set_negative'])+tscore(role,pref['model_role_positive'],pref['model_role_negative'])
        support=5*sum(ne_checks)+2*sum(hash_checks)
        rows.append({'analysis_set':str(aset),'model_role':str(role),'heldout_rows':len(g),'complete_label_count':len(complete),'complete_labels':'|'.join(sorted(complete)),'duplicate_cells':dup,'missing_cells':missing,'n_eval_checks':len(ne_checks),'n_eval_checks_passed':sum(ne_checks),'hash_fold_checks':len(hash_checks),'hash_fold_checks_passed':sum(hash_checks),'structural_score':structural,'semantic_score':semantic,'support_score':support,'total_score':structural+semantic+support})
    rows.sort(key=lambda x:(-x['total_score'],-x['complete_label_count'],x['duplicate_cells'],x['missing_cells'],x['analysis_set'],x['model_role']))
    eligible=[x for x in rows if x['complete_label_count']==len(cfg['available_labels']) and x['duplicate_cells']==0 and x['missing_cells']==0]
    selection={'selected':False,'analysis_set':'','model_role':'','reason':''}; selected=[]
    if eligible:
        top=eligible[0]['total_score']; winners=[x for x in eligible if x['total_score']==top]
        if len(winners)==1:
            w=winners[0]; selection={'selected':True,'analysis_set':w['analysis_set'],'model_role':w['model_role'],'reason':'unique outcome-blind maximum from structural completeness, semantic lineage, and split-support diagnostics'}
            chosen=cf[(cf['analysis_set'].astype(str)==w['analysis_set'])&(cf['model_role'].astype(str)==w['model_role'])&cf['fold'].isin(cfg['expected_folds'])]
            for _,it in chosen.iterrows(): selected.append({k:it.get(k,'') for k in ['label','fold','analysis_set','model_role','n_train','n_eval','training_hash','evaluation_hash']})
        else: selection['reason']='multiple contracts remain exactly tied after outcome-blind lineage diagnostics'
    else: selection['reason']='no complete five-label held-out-fold coefficient contract'
    return rows,selection,selected

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--project-root',default='.'); a=ap.parse_args(); root=Path(a.project_root).resolve()
    cfg=json.loads((root/'config/stage6d2a3_config.json').read_text(encoding='utf-8')); amend=json.loads((root/cfg['amendment_file']).read_text(encoding='utf-8'))
    out=root/cfg['output_dir']; shutil.rmtree(out,ignore_errors=True)
    for d in ['validation','summaries','tables','freeze','reports']:(out/d).mkdir(parents=True,exist_ok=True)
    svp=root/cfg['source_validation']; sv=json.loads(svp.read_text(encoding='utf-8')) if svp.exists() else {}
    trigger=[]; trigger_ready=True
    for gate,req in amend['trigger']['required_state'].items():
        obs=sv.get(gate); passed=(obs is req); trigger_ready &= passed; trigger.append({'gate':gate,'required_value':str(req).lower(),'observed_value':str(obs).lower(),'passed':str(passed).lower()})
    wcsv(out/'tables/stage6d2a3_amendment_trigger.csv',['gate','required_value','observed_value','passed'],trigger)
    availability=(sv.get('supported_primary_labels',[])==amend['data_available_panel'] and sv.get('unsupported_primary_labels',[])==amend['data_unavailable_panel'])
    frozen=out/'freeze/stage6d2a3_frozen_amendment.json'; wjson(frozen,amend); semantic=(csha(amend)==csha(json.loads(frozen.read_text(encoding='utf-8'))))
    lineage=[]; selection={'selected':False,'analysis_set':'','model_role':'','reason':''}; selected=[]; err=''
    try: lineage,selection,selected=audit(root/cfg['coefficient_file'],root/cfg['fold_assignments_file'],cfg)
    except Exception as e: err=f'{type(e).__name__}: {e}'
    wcsv(out/'tables/stage6d2a3_coefficient_lineage_candidates.csv',['analysis_set','model_role','heldout_rows','complete_label_count','complete_labels','duplicate_cells','missing_cells','n_eval_checks','n_eval_checks_passed','hash_fold_checks','hash_fold_checks_passed','structural_score','semantic_score','support_score','total_score'],lineage)
    wcsv(out/'tables/stage6d2a3_selected_lineage_rows.csv',['label','fold','analysis_set','model_role','n_train','n_eval','training_hash','evaluation_hash'],selected)
    wjson(out/'summaries/stage6d2a3_lineage_selection.json',{'selection':selection,'lineage_error':err})
    amendment_ready=trigger_ready and availability and semantic; lineage_ready=selection['selected'] and not err; pilot=amendment_ready and lineage_ready
    rem=[]
    if not trigger_ready: rem.append({'gate':'AMENDMENT_TRIGGER_READY','required_action':'Restore exact Stage-6D2A2 audited state.'})
    if not availability: rem.append({'gate':'LABEL_AVAILABILITY_IDENTITY_READY','required_action':'Source label availability does not match the frozen amendment.'})
    if err: rem.append({'gate':'COEFFICIENT_LINEAGE_AUDIT_READY','required_action':err})
    elif not lineage_ready: rem.append({'gate':'UNIQUE_COEFFICIENT_LINEAGE_READY','required_action':selection['reason']})
    wcsv(out/'tables/stage6d2a3_remaining_items.csv',['gate','required_action'],rem)
    val={'stage':cfg['stage'],'protocol_version':cfg['protocol_version'],'implementation_version':cfg['implementation_version'],'timestamp_utc':now(),'project_root':str(root),'available_labels':amend['data_available_panel'],'unavailable_labels':amend['data_unavailable_panel'],'original_seven_of_nine_gate_status':amend['original_gate_disposition']['status'],'amended_analysis_class':amend['amended_analysis_class'],'selected_coefficient_lineage':selection,'lineage_error':err,'frozen_amendment':rel(frozen,root),'frozen_amendment_canonical_sha256':csha(amend),'prior_stage_outputs_modified':False,'AMENDMENT_TRIGGER_READY':trigger_ready,'LABEL_AVAILABILITY_IDENTITY_READY':availability,'AMENDMENT_SEMANTIC_IDENTITY_READY':semantic,'SEVEN_OF_NINE_GATE_PRESERVED_AS_NOT_TESTABLE':True,'PREDICTIVE_LAW_CLAIM_FORBIDDEN':True,'FIVE_LABEL_PILOT_BOUNDARY_FROZEN':True,'UNIQUE_COEFFICIENT_LINEAGE_READY':lineage_ready,'STAGE6D2A3_AMENDMENT_READY':amendment_ready,'STAGE6D2A4_PILOT_RECONSTRUCTION_READY':pilot,'STAGE6D2B_PREDICTIVE_LAW_READY':False}
    wjson(out/'validation/stage6d2a3_validation.json',val)
    summary={'stage':cfg['stage'],'timestamp_utc':now(),'lineage_selection':selection,'remaining_items':rem,'scientific_disposition':('Five-label exploratory boundary and unique coefficient lineage are frozen; Stage-6D2A4 pilot reconstruction is authorized, while predictive-law fitting remains forbidden.' if pilot else ('Five-label amendment is frozen, but coefficient lineage remains unresolved.' if amendment_ready else 'Data-availability amendment is not yet valid.'))}
    wjson(out/'summaries/stage6d2a3_summary.json',summary)
    (out/'reports/stage6d2a3_protocol_amendment_lineage_audit.md').write_text('\n'.join(['# Stage-6D2A3 protocol amendment and lineage audit','',f'- Amendment trigger ready: `{trigger_ready}`',f'- Label availability identity: `{availability}`',f'- Unique coefficient lineage: `{lineage_ready}`',f'- Selected analysis set: `{selection["analysis_set"] or "none"}`',f'- Selected model role: `{selection["model_role"] or "none"}`','','The seven-of-nine predictive gate remains not testable and is not weakened.','A five-label analysis is exploratory only.','']),encoding='utf-8')
    print(json.dumps({'validation':val,'summary':summary},indent=2,ensure_ascii=False)); return 0
if __name__=='__main__': raise SystemExit(main())
