from __future__ import annotations
import argparse, json, math, os, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd

G=None
C=None

def now(): return datetime.now(timezone.utc).isoformat()

def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def as_bool(s):
    if pd.api.types.is_bool_dtype(s.dtype): return s.to_numpy(bool)
    return s.astype(str).str.strip().str.lower().isin(["true","1","yes","y"]).to_numpy(bool)

def init_worker(arrays,cfg):
    global G,C
    G=arrays; C=cfg

def em2(y,w,maxiter=250,tol=1e-9):
    y=np.asarray(y,float); w=np.asarray(w,float)
    if len(y)<20 or not np.isfinite(y).all() or not np.isfinite(w).all() or w.sum()<=0:
        return None
    q=np.quantile(y,[.30,.70]); mu=np.array(q,float)
    sd=max(float(np.std(y)),0.02)
    sig=np.array([sd*.55,sd*.55],float); pi=np.array([.5,.5],float)
    last=None
    for _ in range(maxiter):
        D=np.empty((len(y),2),float)
        for k in range(2):
            sk=max(sig[k],0.008)
            z=(y-mu[k])/sk
            D[:,k]=pi[k]*np.exp(-.5*z*z)/(sk*np.sqrt(2*np.pi))
        den=np.maximum(D.sum(axis=1),1e-300)
        r=D/den[:,None]; rw=r*w[:,None]; nk=rw.sum(axis=0)
        if np.any(nk<=1e-8): return None
        pi=nk/nk.sum()
        mu=(rw*y[:,None]).sum(axis=0)/nk
        var=(rw*np.square(y[:,None]-mu)).sum(axis=0)/nk
        sig=np.sqrt(np.maximum(var,0.008**2))
        order=np.argsort(mu); mu,sig,pi=mu[order],sig[order],pi[order]
        ll=float(np.sum(w*np.log(den)))
        if last is not None and abs(ll-last)<=tol*(1+abs(last)): break
        last=ll
    if not(mu[0]<mu[1]): return None
    return float(mu[0]),float(mu[1]),float(sig[0]),float(sig[1]),float(pi[1])

def valley_from_fit(f):
    ml,mh,sl,sh,ph=f
    grid=np.linspace(ml,mh,401)
    pl=1-ph
    dl=pl*np.exp(-.5*((grid-ml)/sl)**2)/(sl*np.sqrt(2*np.pi))
    dh=ph*np.exp(-.5*((grid-mh)/sh)**2)/(sh*np.sqrt(2*np.pi))
    # exclude endpoints: valley is an interior minimum.
    z=dl+dh
    if len(z)<=2: return float((ml+mh)/2)
    j=1+int(np.argmin(z[1:-1]))
    return float(grid[j])

def baseline_params(feh):
    b=C["synthetic_baseline"]
    ml=b["mu_low_intercept"]+b["mu_low_feh_slope"]*(feh-b["feh_pivot"])
    mh=b["mu_high_intercept"]+b["mu_high_feh_slope"]*(feh-b["feh_pivot"])
    eta=b["pi_logit_intercept"]+b["pi_logit_feh_slope"]*(feh-b["pi_logit_pivot"])
    ph=1/(1+np.exp(-eta))
    return ml,mh,ph

def seed_for(kind,effect,delta,sign,rep):
    # deterministic integer namespace independent of Python hash randomization
    emap={"null":0,"valley":1,"separation":2,"fraction":3}
    mag=int(round(float(delta)*1000))
    return int(C["seed_namespace"] + emap[effect]*1000000 + (1 if sign>0 else 2)*100000 + mag*100 + rep)

def simulate_one(task):
    kind,effect,delta,sign,rep=task
    feh=G["feh"]; survey=G["survey"]; cell=G["cell"]; w=G["weight"]
    rng=np.random.Generator(np.random.PCG64DXSM(seed_for(kind,effect,delta,sign,rep)))
    ml,mh,ph=baseline_params(feh)

    if kind!="null":
        gm=(survey=="GALAH_CORRECTED")
        sd=float(sign)*float(delta)
        if effect=="valley":
            ml=ml.copy(); mh=mh.copy()
            ml[gm]+=sd; mh[gm]+=sd
        elif effect=="separation":
            ml=ml.copy(); mh=mh.copy()
            ml[gm]-=sd/2; mh[gm]+=sd/2
        elif effect=="fraction":
            ph=ph.copy()
            ph[gm]=np.clip(ph[gm]+sd,0.055,0.945)

    cells=np.unique(cell)
    common_offsets=dict(zip(cells,rng.normal(0,C["synthetic_baseline"]["common_cell_sigma"],len(cells))))
    # survey-cell differential offsets
    sc_keys=np.array([str(s)+"|"+str(int(c)) for s,c in zip(survey,cell)],object)
    uniq_sc=np.unique(sc_keys)
    sc_offsets=dict(zip(uniq_sc,rng.normal(0,C["synthetic_baseline"]["survey_cell_sigma"],len(uniq_sc))))
    off=np.array([common_offsets[int(c)]+sc_offsets[k] for c,k in zip(cell,sc_keys)],float)

    z=rng.random(len(feh))<ph
    sig=np.where(z,C["synthetic_baseline"]["sigma_high"],C["synthetic_baseline"]["sigma_low"])
    mu=np.where(z,mh,ml)
    y=mu+off+rng.normal(0,sig,len(feh))

    knots=C["knots"]; hw=float(C["knot_halfwidth"])
    est={"valley":[],"separation":[],"fraction":[]}
    ok=True
    for knot in knots:
        vals={}
        for s in C["survey_values"]:
            q=(np.abs(feh-float(knot))<=hw)&(survey==s)
            f=em2(y[q],w[q])
            if f is None:
                ok=False; break
            vals[s]={
                "valley":valley_from_fit(f),
                "separation":f[1]-f[0],
                "fraction":f[4]
            }
        if not ok: break
        for e in est:
            est[e].append(vals["GALAH_CORRECTED"][e]-vals["APOGEE_NATIVE"][e])

    rec={"kind":kind,"effect":effect,"delta":float(delta),"sign":int(sign),"rep":int(rep),"fit_ok":bool(ok)}
    if ok:
        for e in est:
            d=np.asarray(est[e],float)
            med=float(np.median(d))
            sgn=1 if med>=0 else -1
            concord=float(np.mean(np.sign(d)==sgn))
            margin=float(C["margins"][e])
            good=(np.sign(d)==sgn)&(np.abs(d)>=margin)
            maxadj=0; cur=0
            for q in good:
                cur=cur+1 if q else 0
                maxadj=max(maxadj,cur)
            rec[f"{e}_median_diff"]=med
            rec[f"{e}_sign_concordance"]=concord
            rec[f"{e}_max_adjacent_practical"]=int(maxadj)
        rec["T_family"]=max(
            abs(rec["valley_median_diff"])/C["margins"]["valley"],
            abs(rec["separation_median_diff"])/C["margins"]["separation"],
            abs(rec["fraction_median_diff"])/C["margins"]["fraction"]
        )
    return rec

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",default=".")
    ap.add_argument("--workers",type=int,default=None)
    a=ap.parse_args()
    root=Path(a.project_root).resolve()
    global C
    C=json.loads((root/"config/stage8b2a_config.json").read_text(encoding="utf-8"))
    pv=json.loads((root/C["parent_validation"]).read_text(encoding="utf-8"))
    parent_ready=bool(
        pv.get("STAGE8B1E_SUPPORT_DOMAIN_AMENDMENT_FROZEN") is True and
        pv.get("STAGE8B2_SYNTHETIC_POWER_READY") is True and
        pv.get("REAL_ALPHA3_MIXTURE_FIT_PERFORMED") is False and
        pv.get("REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED") is False and
        pv.get("AMENDED_PRIMARY_KNOTS")==C["knots"]
    )
    if not parent_ready: raise RuntimeError("Stage-8B1E parent identity failed")

    src=root/C["source"]; cc=C["columns"]
    use=[cc[x] for x in ["source_id","survey","R","absZ","fe_h","alpha3","alpha3_flag","feh_flag","cell","weight"]]
    df=pd.read_parquet(src,columns=use)
    if pd.api.types.is_float_dtype(df[cc["source_id"]].dtype):
        raise RuntimeError("source_id float coercion forbidden")
    R=pd.to_numeric(df[cc["R"]],errors="coerce").to_numpy(float)
    Z=pd.to_numeric(df[cc["absZ"]],errors="coerce").to_numpy(float)
    feh=pd.to_numeric(df[cc["fe_h"]],errors="coerce").to_numpy(float)
    # real alpha3 is used only as a finite eligibility mask, never as simulated outcome.
    alpha_finite=np.isfinite(pd.to_numeric(df[cc["alpha3"]],errors="coerce").to_numpy(float))
    af=as_bool(df[cc["alpha3_flag"]]); ff=as_bool(df[cc["feh_flag"]])
    w=pd.to_numeric(df[cc["weight"]],errors="coerce").to_numpy(float)
    cell=pd.to_numeric(df[cc["cell"]],errors="raise").to_numpy(np.int64)
    survey=df[cc["survey"]].astype(str).to_numpy()
    d=C["domain"]
    m=(np.isfinite(R)&np.isfinite(Z)&np.isfinite(feh)&alpha_finite&np.isfinite(w)&(w>0)&af&ff&
       (R>=d["R_min"])&(R<=d["R_max"])&(Z>=d["absZ_min"])&(Z<=d["absZ_max"])&
       (feh>=d["feh_min"])&(feh<=d["feh_max"]))
    arrays={"feh":feh[m],"survey":survey[m],"cell":cell[m],"weight":w[m]}
    if len(arrays["feh"])==0: raise RuntimeError("No eligible rows")

    tasks=[]
    nnull=int(C["pilot"]["null_replicates"])
    for r in range(nnull):
        tasks.append(("null","null",0.0,1,r))
    nrep=int(C["pilot"]["replicates_per_signed_target"])
    for effect,mags in C["all_targets"].items():
        for delta in mags:
            for sign in (-1,1):
                for r in range(nrep):
                    tasks.append(("target",effect,float(delta),sign,r))

    workers=a.workers or int(C["pilot"]["workers_default"])
    print(f"[8B2A] total={len(tasks)} null={nnull} target={len(tasks)-nnull} workers={workers}")
    print("[8B2A] Real alpha3 values are NOT used to generate synthetic outcomes or fit real morphology.")
    t0=time.time()
    recs=[]
    with ProcessPoolExecutor(max_workers=workers,initializer=init_worker,initargs=(arrays,C)) as ex:
        fut=[ex.submit(simulate_one,t) for t in tasks]
        done=0
        for f in as_completed(fut):
            recs.append(f.result()); done+=1
            if done%16==0 or done==len(tasks):
                print(f"[8B2A] completed={done}/{len(tasks)} elapsed_s={time.time()-t0:.1f}")

    rr=pd.DataFrame(recs)
    if not rr["fit_ok"].all():
        raise RuntimeError(f"synthetic mixture fit failures={int((~rr['fit_ok']).sum())}")

    null=rr[rr["kind"]=="null"].copy()
    Tnull=null["T_family"].to_numpy(float)

    # leave-one-out family p for null false-positive rate
    minconc=float(C["detector"]["minimum_sign_concordance_fraction"])
    minadj=int(C["detector"]["minimum_adjacent_practical_knots"])
    alpha=float(C["detector"]["family_alpha"])
    null_detect=[]
    for _,row in null.iterrows():
        tn=float(row["T_family"])
        others=Tnull[Tnull!=tn] if False else None
        # exact leave-one-out by row index, not by value
        idx=row.name
        arr=null.drop(index=idx)["T_family"].to_numpy(float)
        p=(1+int(np.sum(arr>=tn)))/len(null)
        any_practical=False
        for e in ["valley","separation","fraction"]:
            if row[f"{e}_sign_concordance"]>=minconc and row[f"{e}_max_adjacent_practical"]>=minadj:
                any_practical=True
        null_detect.append(bool(p<=alpha and any_practical))
    null_fpr=float(np.mean(null_detect))

    target_rows=rr[rr["kind"]=="target"].copy()
    outsum=[]
    detect_col=[]
    for idx,row in target_rows.iterrows():
        p=(1+int(np.sum(Tnull>=float(row["T_family"]))))/(len(Tnull)+1)
        e=row["effect"]; expected=int(row["sign"])
        med=float(row[f"{e}_median_diff"])
        correct=(1 if med>=0 else -1)==expected
        detected=bool(
            p<=alpha and
            row[f"{e}_sign_concordance"]>=minconc and
            row[f"{e}_max_adjacent_practical"]>=minadj and
            correct
        )
        target_rows.loc[idx,"family_p"]=p
        target_rows.loc[idx,"correct_sign"]=correct
        target_rows.loc[idx,"detected"]=detected

    for (e,dlt,sgn),g in target_rows.groupby(["effect","delta","sign"]):
        outsum.append({
          "effect":e,"delta":float(dlt),"sign":int(sgn),"replicates":len(g),
          "detection_power":float(g["detected"].mean()),
          "family_p_le_0p05_fraction":float((g["family_p"]<=alpha).mean()),
          "correct_sign_fraction":float(g["correct_sign"].mean()),
          "median_sign_concordance":float(g[f"{e}_sign_concordance"].median()),
          "practical_adjacent_gate_fraction":float((g[f"{e}_max_adjacent_practical"]>=minadj).mean()),
          "median_estimated_effect":float(g[f"{e}_median_diff"].median())
        })
    summ=pd.DataFrame(outsum).sort_values(["effect","delta","sign"]).reset_index(drop=True)

    strong=C["strong_targets"]
    strong_rows=summ[summ.apply(lambda r: abs(float(r["delta"])-float(strong[r["effect"]]))<1e-12,axis=1)]
    strong_all_ge_80=bool((strong_rows["detection_power"]>=0.80).all()) if len(strong_rows)==6 else False

    out=root/C["output_dir"]
    for q in ["tables","validation","freeze"]: (out/q).mkdir(parents=True,exist_ok=True)
    rr.to_csv(out/"tables/stage8b2a_all_pilot_replicates.csv",index=False)
    summ.to_csv(out/"tables/stage8b2a_target_power_summary.csv",index=False)
    (out/"freeze/stage8b2a_protocol_frozen.json").write_text(
        (root/"protocol/stage8b2a_protocol.json").read_text(encoding="utf-8"),encoding="utf-8"
    )
    val={
      "stage":C["stage"],"implementation_version":C["implementation_version"],"timestamp_utc":now(),
      "STAGE8B1E_PARENT_READY":parent_ready,
      "ELIGIBLE_SYNTHETIC_SUPPORT_ROWS":int(len(arrays["feh"])),
      "PRIMARY_KNOTS":C["knots"],
      "PILOT_NULL_REPLICATES_COMPLETED":int(len(null)),
      "PILOT_TARGET_REPLICATES_COMPLETED":int(len(target_rows)),
      "PILOT_NULL_FAMILYWISE_FALSE_POSITIVE_RATE":null_fpr,
      "PILOT_NULL_FPR_LE_0P05":bool(null_fpr<=0.05),
      "PILOT_ALL_SIX_STRONG_SIGNED_TARGETS_POWER_GE_0P80":strong_all_ge_80,
      "REAL_ALPHA3_VALUES_USED_FOR_SYNTHETIC_GENERATION":False,
      "REAL_ALPHA3_FINITE_MASK_USED_FOR_ELIGIBILITY":True,
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":False,
      "REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED":False,
      "STAGE8B2A_PILOT_COMPLETE":True,
      "STAGE8B2_FORMAL_CALIBRATION_AUTHORIZED":False,
      "STAGE8_REAL_MIXTURE_INTERPRETATION_AUTHORIZED":False,
      "NOTE":"Pilot is diagnostic only. Full Stage-8B2 protocol must be frozen before formal calibration."
    }
    write_json(out/"validation/stage8b2a_validation.json",val)
    print(json.dumps({"validation":val,"target_summary":outsum},indent=2,ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
