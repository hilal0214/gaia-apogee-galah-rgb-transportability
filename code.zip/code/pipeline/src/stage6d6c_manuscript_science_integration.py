from __future__ import annotations
import argparse, hashlib, json, re, shutil, subprocess, zipfile
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def sha_file(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+'\n',encoding='utf-8')
def canon(o): return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def find_exact_main(root,wanted_sha):
    hits=[]
    for p in root.rglob('main.tex'):
        if 'stage6d6c_manuscript_science_integration' in str(p).lower(): continue
        try:
            if sha_file(p)==wanted_sha: hits.append(p)
        except Exception: pass
    if len(hits)!=1: raise RuntimeError(f'Expected exactly one D6B main.tex; found {len(hits)}: {hits}')
    return hits[0]

def find_stage7_closure(root):
    cand=[]
    for p in root.rglob('*.json'):
        if 'stage7' not in str(p).lower(): continue
        try: o=json.loads(p.read_text(encoding='utf-8'))
        except Exception: continue
        if o.get('RADIAL_BREAK_BRANCH_CLOSED_NOT_POWERED') is True or o.get('STAGE7B2_FREE_BREAK_BRANCH_CLOSED_NOT_POWERED') is True:
            cand.append((p,o))
    if not cand: raise RuntimeError('No Stage-7 radial branch closure JSON found')
    cand.sort(key=lambda x:(0 if 'stage7r2' in str(x[0]).lower() else 1 if 'stage7r1' in str(x[0]).lower() else 2,str(x[0])))
    return cand[0]

def replace_once(text,pattern,repl,label):
    out,n=re.subn(pattern,lambda _m: repl,text,count=1,flags=re.S)
    if n!=1: raise RuntimeError(f'{label}: replacement count={n}')
    return out

def insert_before(text,anchor,insertion,label):
    m=re.search(anchor,text)
    if not m: raise RuntimeError(f'{label}: anchor not found')
    return text[:m.start()]+insertion+'\n\n'+text[m.start():]

def maxrun(x):
    b=c=0
    for q in x:
        c=c+1 if bool(q) else 0; b=max(b,c)
    return b

def make_figure(intervals,resolution,pdf,png):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    margins={'valley':0.03,'separation':0.04,'fraction':0.08}
    yl={'valley':r'$\Delta\,\alpha_{\rm valley}$ [dex]','separation':r'$\Delta\,(\mu_{\rm high}-\mu_{\rm low})$ [dex]','fraction':r'$\Delta\,\pi_{\rm high}$'}
    fig,axs=plt.subplots(3,1,figsize=(7.3,8.8),sharex=True)
    for ax,e in zip(axs,['valley','separation','fraction']):
        q=intervals[intervals.estimand==e].sort_values('feh_knot')
        x=q.feh_knot.to_numpy(float); y=q.point_difference.to_numpy(float); lo=q.ci_low.to_numpy(float); hi=q.ci_high.to_numpy(float)
        ax.errorbar(x,y,yerr=np.vstack([y-lo,hi-y]),fmt='o',capsize=3,linewidth=1.1)
        ax.axhline(0,linewidth=.8); ax.axhline(margins[e],linewidth=.8,linestyle='--'); ax.axhline(-margins[e],linewidth=.8,linestyle='--')
        ax.set_ylabel(yl[e]); ax.grid(alpha=.18)
        if e=='separation':
            rr=resolution.set_index('feh_knot')
            for xx,yy in zip(x,y):
                if xx in rr.index and bool(rr.loc[xx,'descriptive_both_Dres_ge_2']): ax.annotate('better-resolved',(xx,yy),xytext=(0,9),textcoords='offset points',ha='center',fontsize=7)
    axs[-1].set_xlabel(r'$[\mathrm{Fe/H}]$ knot'); axs[-1].set_xticks([-0.6,-0.4,-0.2,0,0.2,0.4])
    fig.suptitle('APOGEE--GALAH alpha-sequence morphology differences on frozen common support',fontsize=11)
    fig.tight_layout(rect=(0,0,1,.97)); pdf.parent.mkdir(parents=True,exist_ok=True); fig.savefig(pdf,bbox_inches='tight'); fig.savefig(png,dpi=240,bbox_inches='tight'); plt.close(fig)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--project-root',default='.'); a=ap.parse_args(); root=Path(a.project_root).resolve()
    c=json.loads((root/'config/stage6d6c_config.json').read_text(encoding='utf-8')); p=json.loads((root/'protocol/stage6d6c_protocol.json').read_text(encoding='utf-8'))
    s8=json.loads((root/c['stage8f_validation']).read_text(encoding='utf-8'))
    stage8_ready=bool(s8.get('STAGE8F_IDENTIFIABILITY_CLAIM_CLOSURE_COMPLETE') is True and s8.get('D6C_MANUSCRIPT_SCIENCE_INTEGRATION_READY') is True and s8.get('FROZEN_OVERALL_CLASSIFICATION')=='INDETERMINATE' and s8.get('REAL_MIXTURE_REFIT_PERFORMED') is False and s8.get('NEW_BOOTSTRAP_PERFORMED') is False and s8.get('NEW_CLASSIFICATION_GATE_INTRODUCED') is False and s8.get('PRACTICAL_MARGINS_CHANGED') is False and s8.get('FROZEN_CLASSIFICATION_CHANGED') is False and s8.get('PROTOCOL_CANONICAL_SHA256')==c['expected_stage8f_protocol_sha256'])
    if not stage8_ready: raise RuntimeError('Stage-8F parent guards failed')
    s7path,s7=find_stage7_closure(root); stage7_ready=bool(s7.get('RADIAL_BREAK_BRANCH_CLOSED_NOT_POWERED') is True or s7.get('STAGE7B2_FREE_BREAK_BRANCH_CLOSED_NOT_POWERED') is True)
    intervals=pd.read_csv(root/c['stage8d_intervals']); points=pd.read_csv(root/c['stage8d_points']); elig=pd.read_csv(root/c['stage8d_eligibility']); resolution=pd.read_csv(root/c['stage8f_resolution'])
    sep=intervals[intervals.estimand=='separation'].sort_values('feh_knot'); val=intervals[intervals.estimand=='valley']; fra=intervals[intervals.estimand=='fraction']
    result_identity=bool(int((sep.ci_high<0).sum())==4 and maxrun((sep.ci_high<0).tolist())==4 and int(((val.ci_low>0)|(val.ci_high<0)).sum())==1 and int(((fra.ci_low>0)|(fra.ci_high<0)).sum())==0 and set(np.round(resolution.loc[resolution.descriptive_both_Dres_ge_2 & resolution.zero_excluded_negative,'feh_knot'],1))=={-0.6,-0.4})
    if not result_identity: raise RuntimeError('Stage-8 result identity mismatch')
    out=root/c['output_dir']; mdir=out/'manuscript'; baseline=find_exact_main(root,c['baseline_main_tex_sha256'])
    if mdir.exists(): shutil.rmtree(mdir)
    shutil.copytree(baseline.parent,mdir,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache','*.pyc'))
    maintex=mdir/'main.tex'
    if sha_file(maintex)!=c['baseline_main_tex_sha256']: raise RuntimeError('Copied D6B byte identity failed')
    make_figure(intervals,resolution,mdir/'figures/figure05_alpha_morphology_transport.pdf',mdir/'figures/figure05_alpha_morphology_transport.png')
    text=maintex.read_text(encoding='utf-8')

    abstract='''\\begin{abstract}
Combining large spectroscopic surveys requires more than removing mean abundance offsets: label-specific calibration residuals, stellar-parameter sensitivity, unequal sky footprints, and population-morphology identifiability can all limit transport across surveys. We construct a claim-bounded Gaia--APOGEE--GALAH red-giant atlas and test cross-survey chemical-label transportability at four levels. Common-star calibration uses 45,040--57,883 overlap stars. In an amended five-label exploratory pilot, held-out transport difficulty is positively associated with a pre-defined atmospheric-sensitivity burden, with pooled coefficient 0.410, bootstrap $P(\\beta>0)=1.000$, 95 per cent interval $[0.246,0.520]$, and permutation $p=0.0014$. On an outcome-blind common footprint of 34,177 stars in 208 primary HEALPix cells, $[\\mathrm{Ni/Fe}]$ is transport-stable in both radial and vertical gradients; $[\\mathrm{Si/Fe}]$ and $[\\mathrm{Ca/Fe}]$ are vertically stable but radially indeterminate; $[\\mathrm{Fe/H}]$ and $[\\mathrm{Mg/Fe}]$ are indeterminate in both coordinates. A separately pre-registered radial-break branch is closed as not adequately powered before real break-model interpretation. Finally, we test the morphology of the frozen homogenised $\\alpha_3$ coordinate on 26,180 eligible common-support RGB stars using power-calibrated two-component fits and 4096 paired-NSIDE16 cell bootstrap draws. The frozen morphology classification is indeterminate for valley location, sequence separation, and high-$\\alpha$ fraction. The cleanest descriptive difference is a smaller fitted GALAH sequence separation at $[\\mathrm{Fe/H}]=-0.6$ and $-0.4$, where both survey mixtures remain comparatively well resolved; apparent continuation toward solar metallicity is treated cautiously because component overlap increases strongly. The resulting hierarchy separates positive transport-stability evidence, statistically resolved survey-scale differences, power-limited tests, and failures to establish practical equivalence without converting them into unsupported non-transportability claims.
\\end{abstract}'''
    text=replace_once(text,r'\\begin\{abstract\}.*?\\end\{abstract\}',abstract,'abstract')

    intro='''The final analysis therefore asks a fourth transport question in addition to calibration quality, exploratory atmospheric-sensitivity burden, and common-footprint gradients: does the \\emph{shape} of the low-$\\alpha$/high-$\\alpha$ structure survive transfer between surveys on a fixed homogenised abundance coordinate? This question is framed as morphology transport rather than a new Galactic-population decomposition. Its estimands are the fitted valley location, component separation, and high-$\\alpha$ mixture fraction on common support, with power calibration, practical margins, and identifiability caveats frozen before interpretation. A separate radial-break experiment is retained only as a power-calibration result because its pre-specified synthetic recovery gate failed before the real break model was opened.'''
    text=insert_before(text,r'\\section\{Data\}',intro,'Data')

    methods='''\\subsection{Power-limited radial-transition adjudication}
\\label{sec:radial_power}
Before interpreting a free radial metallicity transition, we froze a synthetic injection--recovery experiment over candidate break radii. The null false-positive rate was controlled, but the pre-specified localization and detection-power requirements were not met for the target injected breaks. A subsequent fixed-window transition reframe also failed its frozen power gate. We therefore closed the radial-transition branch as \\textsc{not powered} before opening either the real free-break or real fixed-window alternative model. This closure is a design result, not evidence that the Milky Way lacks a radial metallicity transition.

\\subsection{Power-calibrated $\\alpha$-sequence morphology transport}
\\label{sec:alpha_morph_method}
The morphology audit uses the frozen homogenised $\\alpha_3$ coordinate on the outcome-blind balanced common footprint. After support calibration, the primary metallicity knots are $[\\mathrm{Fe/H}]=(-0.6,-0.4,-0.2,0.0,0.2,0.4)$; the $-0.8$ knot is retained only as \\textsc{low-support--not-testable}. The primary spatial domain is $5<R/{\\rm kpc}<11$ and $0<|Z|/{\\rm kpc}<2$, with 26,180 eligible rows over 208 retained NSIDE16 cells.

At each fixed metallicity knot and in each survey we fit the same weighted two-component heteroscedastic Gaussian mixture calibrated in the synthetic power experiment. Components are ordered only by $\\mu_{\\rm low}<\\mu_{\\rm high}$. We record the density valley between the fitted means, the sequence separation $\\Delta\\alpha_{\\rm seq}=\\mu_{\\rm high}-\\mu_{\\rm low}$, and the fitted high-$\\alpha$ mixture fraction $\\pi_{\\rm high}$. Survey differences are always GALAH minus APOGEE. Uncertainty uses 4096 paired common-footprint NSIDE16-cell bootstrap draws, applying the same cell multiplicity to both surveys while retaining the frozen balancing weights.

The practical margins were fixed before the real mixture was opened: 0.03 dex for valley location, 0.04 dex for sequence separation, and 0.08 for high-$\\alpha$ fraction. An estimand is transport-stable only if at least five of six knot intervals lie wholly inside its margin and no survey-sensitive run is present. Survey sensitivity requires at least three adjacent knots with 95 per cent intervals wholly beyond the same margin in one direction; all other cases are \\textsc{indeterminate}. Formal synthetic calibration comprised 256 null and 1536 injected replicates. Its family-wise null false-positive rate was zero, and all six signed strong-target scenarios passed the pre-specified 80 per cent power gate.'''
    text=insert_before(text,r'\\section\{Results\}',methods,'Results')

    rows=[]
    for e,label in [('valley','Valley location'),('separation','Sequence separation'),('fraction','High-$\\alpha$ fraction')]:
        q=intervals[intervals.estimand==e]
        zero=int(((q.ci_low>0)|(q.ci_high<0)).sum()); equiv=int(((q.ci_low>-q.margin)&(q.ci_high<q.margin)).sum()); sens=int(((q.ci_low>q.margin)|(q.ci_high<-q.margin)).sum())
        rows.append(f'{label} & {zero} & {equiv} & {sens} & Indeterminate\\\\')
    table_rows='\n'.join(rows)

    results=f'''\\subsection{{Radial-transition power closure}}
\\label{{sec:radial_power_result}}
The radial-transition branch never reached real alternative-model interpretation. In the formal free-break injection experiment the null false-positive rate was 0.035, but the target 0.05-dex break scenarios had detection powers of only 0.289--0.508 and failed the frozen localization-error requirements. A stronger diagnostic envelope still did not make the design reliably powered across break location and sign, and the fixed-window reframe likewise failed its power gate. The claim-safe result is therefore that the present design is not sufficiently powered for radial-break localization; no real-data ``no break'' conclusion is drawn.

\\subsection{{Alpha-sequence morphology on common survey support}}
\\label{{sec:alpha_morph_result}}
All 12 survey--knot point fits and all 4096 paired-cell bootstrap draws completed without technical failure. Table~\\ref{{tab:alpha_morph_class}} gives the frozen decision summary, while Fig.~\\ref{{fig:alpha_morph_transport}} shows the point differences and 95 per cent intervals relative to the pre-specified practical margins.

\\begin{{table}}
\\centering
\\caption{{Frozen alpha-sequence morphology transport decisions over the six supported primary metallicity knots. ``Zero-excl.'' counts 95 per cent intervals excluding zero; ``Equiv.'' counts intervals wholly inside the practical margin; ``Sensitive'' counts intervals wholly beyond the margin.}}
\\label{{tab:alpha_morph_class}}
\\begin{{tabular}}{{lrrrr}}
\\toprule
Estimand & Zero-excl. & Equiv. & Sensitive & Class\\\\
\\midrule
{table_rows}
\\bottomrule
\\end{{tabular}}
\\end{{table}}

\\begin{{figure*}}
\\centering
\\includegraphics[width=0.78\\textwidth]{{figures/figure05_alpha_morphology_transport.pdf}}
\\caption{{GALAH-minus-APOGEE differences in the fitted alpha-sequence valley location (top), low-/high-alpha sequence separation (middle), and high-alpha mixture fraction (bottom) on the frozen common-support sample. Points are production estimates and bars are 95 per cent paired-NSIDE16-cell bootstrap intervals. Dashed horizontal lines mark the pre-specified practical margins. ``Better-resolved'' annotations in the separation panel are post-hoc descriptive identifiability diagnostics only and do not enter the transport classification.}}
\\label{{fig:alpha_morph_transport}}
\\end{{figure*}}

The frozen overall morphology class is \\textsc{{indeterminate}}. Valley location excludes zero only at $[\\mathrm{{Fe/H}}]=0.0$, where the GALAH-minus-APOGEE offset is $-0.0324$ dex with 95 per cent interval $[-0.0459,-0.0197]$ dex, but the interval does not lie wholly beyond the $-0.03$ dex practical margin. High-$\\alpha$ fraction excludes zero at no primary knot and is uncertainty dominated.

Sequence separation shows the clearest structured survey difference. The GALAH-minus-APOGEE difference is negative and excludes zero at four adjacent knots from $[\\mathrm{{Fe/H}}]=-0.6$ through $0.0$. At $-0.6$ and $-0.4$, where both fitted survey mixtures are comparatively well separated, the differences are respectively $-0.0410$ dex (95 per cent interval $[-0.0868,-0.0274]$) and $-0.0385$ dex ($[-0.0503,-0.0319]$). The fitted components become substantially more overlapping toward $-0.2$ and solar metallicity, especially in GALAH, so the apparent four-knot continuation is not promoted to a precise physical sequence-contraction claim. No primary knot is classified as practically equivalent or as wholly beyond its practical margin, and the frozen survey-sensitive adjacency criterion is not triggered.'''
    text=insert_before(text,r'\\section\{Discussion\}',results,'Discussion')

    discussion='''\\subsection{What the morphology audit adds to transportability}
\\label{sec:alpha_morph_disc}
The morphology experiment extends the transport problem beyond single regression coefficients. A label can have a calibrated mean scale and still encode population structure differently when the two surveys have different line information, precision, target selection, and residual parameter sensitivity. The alpha-sequence result illustrates why transportability should be treated as an estimand-specific property rather than a binary survey-level attribute.

The strongest descriptive evidence is confined to the metal-poor end of the supported morphology grid. At $[\\mathrm{Fe/H}]=-0.6$ and $-0.4$, both surveys retain comparatively well separated two-component fits, yet GALAH yields a smaller fitted sequence separation. This is a resolved survey-scale difference on the homogenised $\\alpha_3$ coordinate. It does not satisfy the pre-specified practical survey-sensitivity rule, and it is not an independent replication because the two surveys were explicitly cross-calibrated and balanced on common support.

Toward solar metallicity, the mixture components overlap strongly. In that regime the fitted separation and high-$\\alpha$ fraction become weakly identified summaries of the chosen two-component representation rather than precise measurements of two physical Galactic populations. We therefore retain the continuous component-resolution diagnostic only as a post-hoc interpretive aid. It neither changes the frozen practical margins nor reclassifies the overall \\textsc{indeterminate} morphology result.

The radial-transition branch provides a complementary methodological lesson. Power calibration can close an attractive physical question before real-data interpretation when the design cannot recover the target effect reliably. This is preferable to reporting a visually plausible break or a null alternative-model comparison that the frozen data geometry was not capable of adjudicating.'''
    text=insert_before(text,r'\\section\{Conclusions\}',discussion,'Conclusions')

    conclusions='''\\section{Conclusions}
\\label{sec:conclusions}
We have constructed a claim-bounded Gaia--APOGEE--GALAH RGB atlas and used it to test chemical-label transportability across calibration, gradients, and population morphology.
\\begin{enumerate}[leftmargin=*]
\\item The merged spectroscopic parent layer contains 1,591,571 catalogue entries, and the Gaia-limited production run contains 89,323 clean RGB stars after frozen quality and phase-space gates.
\\item APOGEE--GALAH calibration is empirical and label specific. Common-star support ranges from 45,040 to 57,883 stars, and the post-calibration residual scale varies substantially among labels.
\\item In the amended five-label exploratory pilot, held-out transport difficulty is positively associated with the atmospheric-sensitivity burden: the pooled coefficient is 0.40993, its bootstrap 95 per cent interval is $[0.24589,0.52037]$, and the permutation test gives $p=0.0014$. This is not promoted to a universal predictive law.
\\item The authoritative Stage-4B gradients remain the frozen full-support reference. The common-footprint extension uses 34,177 stars in 208 primary HEALPix cells, outcome-blind survey balancing, the same Huber estimator contract, and 4096 spatial-cluster multiplier draws. $[\\mathrm{Ni/Fe}]$ is transport-stable in both radial and vertical gradients; no primary label is classified as footprint-sensitive or survey-sensitive.
\\item A pre-registered radial-transition branch was closed before real break-model interpretation because the frozen synthetic detection/localization experiment was not adequately powered. This is a design limitation, not evidence that the Galaxy lacks a radial metallicity transition.
\\item The alpha-sequence morphology audit uses 26,180 eligible common-support RGB stars, six frozen metallicity knots, power-calibrated two-component fits, and 4096 paired-NSIDE16-cell bootstrap draws. Valley location, sequence separation, and high-$\\alpha$ fraction are all classified as \\textsc{indeterminate}; failure to establish practical equivalence is not evidence of non-transportability.
\\item The cleanest morphology difference occurs at $[\\mathrm{Fe/H}]=-0.6$ and $-0.4$, where both survey mixtures remain comparatively well resolved and GALAH yields a smaller fitted low-$\\alpha$/high-$\\alpha$ separation. The apparent continuation toward solar metallicity is not promoted to a four-knot physical contraction because mixture identifiability deteriorates strongly.
\\item The Stage-5B latent-component family remains anonymous. The release does not support physically named latent populations, component-resolved gradients, volume-complete inference, causal footprint effects, independent-survey replication, or universal high-$\\alpha$ population fractions.
\\end{enumerate}
'''
    text=replace_once(text,r'\\section\{Conclusions\}.*?(?=\\section\*\{Data and Code Availability\})',conclusions,'Conclusions section')

    datacode='''\\section*{Data and Code Availability}
The frozen Stage-6 technical reproducibility archive remains \\texttt{RGB\\_transportability\\_science\\_release\\_v0\\_26\\_1.zip} (SHA-256 \\texttt{6519cd827bd2d01c5b4fe0c300690d4de5ffd6db665e7350a6a934eacf872b63}). It contains the common-footprint production estimates, 4096-draw gradient bootstrap products, practical-equivalence classifications, claim ledgers, exact analysis code/configuration, and SHA-256 manifests used by the D6B baseline.

The Stage-7 power-calibration closure and Stage-8 alpha-morphology products are a later, versioned science extension and are not silently folded into that frozen Stage-6 archive. The next public reproducibility release will include their protocol freezes, synthetic-power products, real paired-cell bootstrap intervals, identifiability audit, claim-safe integration tables, and exact hashes. Large upstream Gaia, APOGEE, and GALAH catalogues and the row-level balanced production table are not redistributed. The manuscript itself is maintained separately from the science archive.

The public repository and DOI metadata will be inserted after verification of the final human metadata:
\\begin{description}[leftmargin=2.5cm,style=nextline]
\\item[Repository] \\textbf{REPOSITORY\\_URL}
\\item[Exact release DOI] \\textbf{EXACT\\_VERSION\\_DOI}
\\item[Concept DOI] \\textbf{CONCEPT\\_DOI}
\\end{description}
'''
    text=replace_once(text,r'\\section\*\{Data and Code Availability\}.*?(?=\\section\*\{Acknowledgements\})',datacode,'Data/code section')

    if re.search(r'\\(?:input|include)\\s*\{',text): raise RuntimeError('Flat main.tex guard failed')
    for phrase in ['alpha morphology is transport stable','alpha morphology is non-transportable','no galactic radial metallicity break exists','galah independently replicates apogee']:
        if phrase in text.lower(): raise RuntimeError(f'Forbidden phrase: {phrase}')
    maintex.write_text(text,encoding='utf-8')

    # Compile 3 passes if pdflatex exists.
    runs=[]; pdf_ready=False; unresolved=[]; over=[]; pdflatex=shutil.which('pdflatex')
    if pdflatex:
        for i in range(3):
            cp=subprocess.run([pdflatex,'-interaction=nonstopmode','-halt-on-error','main.tex'],cwd=mdir,capture_output=True,text=True)
            runs.append({'pass':i+1,'returncode':cp.returncode,'stdout_tail':cp.stdout[-4000:],'stderr_tail':cp.stderr[-1000:]})
            if cp.returncode!=0: break
        log=mdir/'main.log'; lt=log.read_text(encoding='utf-8',errors='ignore') if log.exists() else ''
        unresolved=[x for x in lt.splitlines() if 'undefined' in x.lower() and ('reference' in x.lower() or 'citation' in x.lower())]
        over=[x for x in lt.splitlines() if 'Overfull \\hbox' in x]
        pdf_ready=bool(len(runs)==3 and all(x['returncode']==0 for x in runs) and (mdir/'main.pdf').exists() and not unresolved and not over)

    (out/'freeze').mkdir(parents=True,exist_ok=True); shutil.copy2(root/'protocol/stage6d6c_protocol.json',out/'freeze/stage6d6c_protocol_frozen.json')
    (out/'tables').mkdir(parents=True,exist_ok=True); intervals.to_csv(out/'tables/stage6d6c_stage8_intervals_used.csv',index=False); resolution.to_csv(out/'tables/stage6d6c_stage8_identifiability_used.csv',index=False)
    release=out/c['release_name']; release.unlink(missing_ok=True)
    with zipfile.ZipFile(release,'w',zipfile.ZIP_DEFLATED) as z:
        for fp in sorted(mdir.rglob('*')):
            if fp.is_file() and '__pycache__' not in fp.parts and fp.suffix!='.pyc': z.write(fp,fp.relative_to(mdir))
    v={'stage':c['stage'],'implementation_version':c['implementation_version'],'timestamp_utc':now(),'D6B_BASELINE_MAIN_EXACT_SHA_READY':True,'D6B_BASELINE_MAIN_PATH':str(baseline.relative_to(root)),'D6B_BASELINE_WAS_MODIFIED_IN_PLACE':False,'STAGE7_RADIAL_BRANCH_CLOSURE_READY':stage7_ready,'STAGE7_VALIDATION_PATH_USED':str(s7path.relative_to(root)),'STAGE8F_PARENT_READY':stage8_ready,'STAGE8_FROZEN_RESULT_IDENTITY_READY':result_identity,'FROZEN_STAGE8_OVERALL_CLASSIFICATION':'INDETERMINATE','CLEANEST_DESCRIPTIVE_ALPHA_KNOTS':[-0.6,-0.4],'OVERLAP_CAUTION_ALPHA_KNOTS':[-0.2,0.0],'NEW_REAL_SCIENCE_FIT_PERFORMED_BY_D6C':False,'NEW_BOOTSTRAP_PERFORMED_BY_D6C':False,'FROZEN_SCIENCE_GATE_CHANGED_BY_D6C':False,'FLAT_MAIN_TEX_READY':True,'FIGURE05_ALPHA_MORPHOLOGY_READY':(mdir/'figures/figure05_alpha_morphology_transport.pdf').exists(),'MANUSCRIPT_MAIN_TEX_SHA256':sha_file(maintex),'PDF_COMPILE_ATTEMPTED':bool(pdflatex),'PDF_COMPILED_CLEANLY':pdf_ready,'UNRESOLVED_REFERENCE_OR_CITATION_LINES':unresolved,'OVERFULL_HBOX_LINES':over,'HUMAN_METADATA_READY':False,'PUBLIC_SUBMISSION_READY':False,'D6C_SCIENCE_INTEGRATION_READY':True,'RELEASE_ZIP_RELATIVE_PATH':str(release.relative_to(root)),'RELEASE_ZIP_SHA256':sha_file(release),'PROTOCOL_CANONICAL_SHA256':canon(p),'COMPILE_RUNS':runs}
    write_json(out/'validation/stage6d6c_validation.json',v); print(json.dumps(v,indent=2,ensure_ascii=False)); return 0

if __name__=='__main__': raise SystemExit(main())
