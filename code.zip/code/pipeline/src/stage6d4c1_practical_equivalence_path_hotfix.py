from __future__ import annotations
import argparse,hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
from typing import Any
import numpy as np,pandas as pd

def now():return datetime.now(timezone.utc).isoformat()
def canonical_bytes(o:Any)->bytes:
    return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode("utf-8")
def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
def wj(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def rt(p):
    return pd.read_parquet(p) if p.suffix.lower()==".parquet" else pd.read_csv(p)

def walk_dicts(obj,path="$"):
    if isinstance(obj,dict):
        yield path,obj
        for k,v in obj.items():
            yield from walk_dicts(v,f"{path}.{k}")
    elif isinstance(obj,list):
        for i,v in enumerate(obj):
            yield from walk_dicts(v,f"{path}[{i}]")

def resolve_practical_equivalence_block(protocol):
    required={"radial_margin_rule","vertical_margin_rule","confidence_level","classification"}
    hits=[]
    for path,d in walk_dicts(protocol):
        if required.issubset(d.keys()):
            hits.append((path,d))
    if len(hits)==1:
        return hits[0][0],hits[0][1],"UNIQUE_EXACT_KEYSET"
    if len(hits)>1:
        exact=[]
        for path,d in hits:
            r=str(d.get("radial_margin_rule",""))
            z=str(d.get("vertical_margin_rule",""))
            if "0.005" in r and "0.25" in r and "0.030" in z and "0.25" in z:
                exact.append((path,d))
        if len(exact)==1:return exact[0][0],exact[0][1],"UNIQUE_RULE_LITERAL_MATCH"
        raise RuntimeError(f"ambiguous practical-equivalence blocks: {[x[0] for x in hits]}")
    # diagnostic fallback: locate dicts carrying both margin rules, even if confidence/classification are elsewhere
    partial=[]
    for path,d in walk_dicts(protocol):
        if "radial_margin_rule" in d and "vertical_margin_rule" in d:
            partial.append((path,d))
    raise RuntimeError(f"practical-equivalence block unresolved; partial candidates={[x[0] for x in partial]}")

def model_row(est,label,model):
    x=est[(est["label"]==label)&(est["model_id"]==model)]
    if len(x)!=1:raise RuntimeError(f"{label}/{model}: expected one row, found {len(x)}")
    return x.iloc[0]
def draw_array(draws,label,model,col):
    x=draws[(draws["label"]==label)&(draws["model_id"]==model)]
    if len(x)==0:raise RuntimeError(f"{label}/{model}: no draws")
    a=pd.to_numeric(x[col],errors="coerce").to_numpy(float)
    if not np.all(np.isfinite(a)):raise RuntimeError(f"{label}/{model}/{col}: nonfinite draws")
    return a
def conservative_difference_interval(b,a,qlo=.0125,qhi=.9875):
    return float(np.quantile(b,qlo)-np.quantile(a,qhi)),float(np.quantile(b,qhi)-np.quantile(a,qlo))
def direct_interval(x):return float(np.quantile(x,.025)),float(np.quantile(x,.975))
def beyond(lo,hi,m):return bool(lo>m or hi<-m)
def inside(lo,hi,m):return bool(lo>=-m and hi<=m)
def same_nonzero_sign(v):
    s=np.sign(np.asarray(v,float));return bool(np.all(s!=0) and np.all(s==s[0]))
def coord_class(blo,bhi,ilo,ihi,m,sign):
    stable=inside(blo,bhi,m) and inside(ilo,ihi,m) and sign
    foot=beyond(blo,bhi,m);survey=beyond(ilo,ihi,m);conflict=foot and survey
    if conflict:return "INDETERMINATE",stable,foot,survey,conflict
    if foot:return "FOOTPRINT_SENSITIVE",stable,foot,survey,conflict
    if survey:return "SURVEY_SENSITIVE",stable,foot,survey,conflict
    if stable:return "TRANSPORT_STABLE",stable,foot,survey,conflict
    return "INDETERMINATE",stable,foot,survey,conflict
def overall(rows):
    f=any(r["footprint_sensitive_flag"] for r in rows);s=any(r["survey_sensitive_flag"] for r in rows)
    if f and s:return "INDETERMINATE"
    if f:return "FOOTPRINT_SENSITIVE"
    if s:return "SURVEY_SENSITIVE"
    if all(r["coordinate_classification"]=="TRANSPORT_STABLE" for r in rows):return "TRANSPORT_STABLE"
    return "INDETERMINATE"

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");a=ap.parse_args()
    root=Path(a.project_root).resolve();c=json.loads((root/"config/stage6d4c1_config.json").read_text())
    out=root/c["output_dir"]
    if out.exists():shutil.rmtree(out)
    for d in ["validation","tables","freeze","summaries","reports","manifest"]:(out/d).mkdir(parents=True,exist_ok=True)

    v=json.loads((root/c["d4b_validation"]).read_text())
    prereq=bool(v.get("STAGE6D4B_PRODUCTION_FITS_READY") and v.get("STAGE6D4C_PRACTICAL_EQUIVALENCE_CLASSIFICATION_READY"))
    d3a=json.loads((root/c["d3a_protocol"]).read_text())
    d3a_sha=hashlib.sha256(canonical_bytes(d3a)).hexdigest()

    pe_path,pe,status=resolve_practical_equivalence_block(d3a)
    protocol_ready=bool(
        d3a_sha==c["expected_d3a_sha256"]
        and pe["radial_margin_rule"]==c["expected_radial_rule"]
        and pe["vertical_margin_rule"]==c["expected_vertical_rule"]
        and float(pe["confidence_level"])==float(c["expected_confidence_level"])
        and set(pe["classification"])==set(c["expected_classification"])
    )
    wj(out/"freeze/stage6d4c1_resolved_practical_equivalence_block.json",{
        "resolved_json_path":pe_path,"resolution_status":status,"block":pe,
        "d3a_protocol_canonical_sha256":d3a_sha
    })

    est=pd.read_csv(root/c["d4b_estimates"]);draws=rt(root/c["d4b_draws"])
    models={"FULL_SUPPORT_FROZEN","COMMON_FOOTPRINT_POOLED","COMMON_FOOTPRINT_BALANCED","COMMON_FOOTPRINT_INTERACTION"}
    schema=bool(set(c["primary_labels"])<=set(est["label"]) and models<=set(est["model_id"]) and set(c["primary_labels"])<=set(draws["label"]) and models<=set(draws["model_id"]))
    if not schema:raise RuntimeError("D4B estimate/draw schema incomplete")

    comps=[];coords=[];labels=[]
    for lab in c["primary_labels"]:
        full=model_row(est,lab,"FULL_SUPPORT_FROZEN");pool=model_row(est,lab,"COMMON_FOOTPRINT_POOLED");bal=model_row(est,lab,"COMMON_FOOTPRINT_BALANCED");inter=model_row(est,lab,"COMMON_FOOTPRINT_INTERACTION")
        per=[]
        for coord,spec in c["coordinates"].items():
            sc=spec["slope_column"];dc=spec["interaction_delta_column"];gc=spec["galah_slope_column"]
            fp=float(full[sc]);pp=float(pool[sc]);bp=float(bal[sc]);ap=float(inter[sc]);gp=float(inter[gc]);dp=float(inter[dc])
            margin=max(float(spec["margin_floor"]),.25*abs(fp))
            fd=draw_array(draws,lab,"FULL_SUPPORT_FROZEN",sc);pd_=draw_array(draws,lab,"COMMON_FOOTPRINT_POOLED",sc);bd=draw_array(draws,lab,"COMMON_FOOTPRINT_BALANCED",sc);dd=draw_array(draws,lab,"COMMON_FOOTPRINT_INTERACTION",dc)
            fplo,fphi=conservative_difference_interval(pd_,fd);pblo,pbhi=conservative_difference_interval(bd,pd_);bflo,bfhi=conservative_difference_interval(bd,fd);ilo,ihi=direct_interval(dd)
            for cid,ref,cmp,pt,lo,hi,method in [
                ("FULL_TO_POOLED","FULL_SUPPORT_FROZEN","COMMON_FOOTPRINT_POOLED",pp-fp,fplo,fphi,"bonferroni_dependence_robust_marginal_difference"),
                ("POOLED_TO_BALANCED","COMMON_FOOTPRINT_POOLED","COMMON_FOOTPRINT_BALANCED",bp-pp,pblo,pbhi,"bonferroni_dependence_robust_marginal_difference"),
                ("FULL_TO_BALANCED","FULL_SUPPORT_FROZEN","COMMON_FOOTPRINT_BALANCED",bp-fp,bflo,bfhi,"bonferroni_dependence_robust_marginal_difference"),
                ("SURVEY_INTERACTION_DELTA","APOGEE_NATIVE","GALAH_CORRECTED",dp,ilo,ihi,"direct_4096_interaction_draw_quantiles")
            ]:
                comps.append({"label":lab,"coordinate":coord,"comparison_id":cid,"reference":ref,"comparison":cmp,"point_difference":pt,"interval_low":lo,"interval_high":hi,"practical_margin":margin,"interval_excludes_zero":bool(lo>0 or hi<0),"interval_inside_practical_margin":inside(lo,hi,margin),"interval_beyond_practical_margin":beyond(lo,hi,margin),"interval_method":method})
            sign=same_nonzero_sign([fp,bp,ap,gp]);cls,stable,foot,survey,conflict=coord_class(bflo,bfhi,ilo,ihi,margin,sign)
            rr={"label":lab,"coordinate":coord,"full_support_slope":fp,"pooled_slope":pp,"balanced_slope":bp,"interaction_APOGEE_slope":ap,"interaction_GALAH_slope":gp,"survey_interaction_delta":dp,"practical_margin":margin,"balanced_minus_full_low":bflo,"balanced_minus_full_high":bfhi,"survey_interaction_low":ilo,"survey_interaction_high":ihi,"sign_preserved":sign,"transport_stable_flag":stable,"footprint_sensitive_flag":foot,"survey_sensitive_flag":survey,"sensitivity_conflict_flag":conflict,"coordinate_classification":cls}
            coords.append(rr);per.append(rr)
        labels.append({"label":lab,"radial_classification":next(x["coordinate_classification"] for x in per if x["coordinate"]=="R"),"vertical_classification":next(x["coordinate_classification"] for x in per if x["coordinate"]=="Z"),"overall_classification":overall(per),"any_footprint_sensitive":any(x["footprint_sensitive_flag"] for x in per),"any_survey_sensitive":any(x["survey_sensitive_flag"] for x in per),"all_coordinates_transport_stable":all(x["coordinate_classification"]=="TRANSPORT_STABLE" for x in per),"classification_claim_safe":True})

    comp=pd.DataFrame(comps);coord=pd.DataFrame(coords);labdf=pd.DataFrame(labels)
    comp.to_csv(out/"tables/gradient_required_comparisons.csv",index=False)
    coord.to_csv(out/"tables/gradient_transport_coordinate_classification.csv",index=False)
    labdf.to_csv(out/"tables/gradient_transport_classification.csv",index=False)

    ledger=[]
    for _,r in labdf.iterrows():
        cls=r["overall_classification"]
        claim={
            "TRANSPORT_STABLE":"Within the tested shared support, balanced gradients and APOGEE-GALAH interaction slopes are practically equivalent to the frozen full-support slopes with preserved sign.",
            "FOOTPRINT_SENSITIVE":"At least one gradient coordinate shows a balanced-minus-full contrast beyond the frozen practical-equivalence margin; interpret as footprint sensitivity within tested shared support.",
            "SURVEY_SENSITIVE":"At least one gradient coordinate shows an APOGEE-GALAH interaction contrast beyond the frozen practical-equivalence margin within the balanced common footprint.",
            "INDETERMINATE":"The frozen practical-equivalence rules do not support a unique stable/footprint-sensitive/survey-sensitive classification."
        }[cls]
        ledger.append({"label":r["label"],"classification":cls,"allowed_claim":claim,"forbidden_claims":"volume-complete Milky Way gradient | independent GALAH replication | target-abundance matching | causal footprint effect | general five-label predictive law | component-resolved gradients"})
    pd.DataFrame(ledger).to_csv(out/"tables/footprint_claim_ledger.csv",index=False)

    closure={"stage":"Stage-6D4C1 practical-equivalence implementation closure","resolved_d3a_practical_equivalence_json_path":pe_path,"d3a_protocol_sha256":d3a_sha,"frozen_rules":pe,"cross_model_contrast_interval":{"method":"Bonferroni dependence-robust marginal-quantile difference interval","formula":"[q0.0125(B)-q0.9875(A), q0.9875(B)-q0.0125(A)]","no_cross_model_independence_assumption":True},"sign_preservation_rule":"sign(full)=sign(balanced)=sign(interaction APOGEE)=sign(interaction GALAH), all nonzero","outcome_blind_method_choice":True}
    wj(out/"freeze/stage6d4c1_classification_contract.json",closure);closure_sha=hashlib.sha256(canonical_bytes(closure)).hexdigest()

    comparison_ready=bool(len(comp)==len(c["primary_labels"])*2*4 and not comp.isna().any().any())
    coord_ready=bool(len(coord)==len(c["primary_labels"])*2 and set(coord["coordinate_classification"])<=set(c["expected_classification"]))
    label_ready=bool(len(labdf)==len(c["primary_labels"]) and set(labdf["overall_classification"])<=set(c["expected_classification"]))
    counts=labdf["overall_classification"].value_counts().to_dict()
    ready=bool(prereq and protocol_ready and schema and comparison_ready and coord_ready and label_ready)

    val={"stage":c["stage"],"protocol_version":c["protocol_version"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),"d3a_protocol_canonical_sha256":d3a_sha,"resolved_practical_equivalence_json_path":pe_path,"practical_equivalence_resolution_status":status,"classification_contract_canonical_sha256":closure_sha,"D4B_PRODUCTION_PREREQUISITE_READY":prereq,"D3A_PRACTICAL_EQUIVALENCE_BLOCK_RESOLVED":True,"D3A_PRACTICAL_EQUIVALENCE_PROTOCOL_IDENTITY_READY":protocol_ready,"D4B_ESTIMATE_DRAW_SCHEMA_READY":schema,"ALL_REQUIRED_COMPARISONS_READY":comparison_ready,"DEPENDENCE_ROBUST_CONTRAST_INTERVAL_CLOSURE_READY":True,"NO_CROSS_MODEL_INDEPENDENCE_ASSUMPTION_USED":True,"RADIAL_MARGIN_RULE_FROZEN_READY":True,"VERTICAL_MARGIN_RULE_FROZEN_READY":True,"SIGN_PRESERVATION_RULE_READY":True,"ALL_COORDINATE_CLASSIFICATIONS_READY":coord_ready,"ALL_FIVE_LABEL_CLASSIFICATIONS_READY":label_ready,"classification_counts":counts,"CLAIM_BOUNDARIES_PRESERVED":True,"NO_NEW_OUTCOME_DEPENDENT_THRESHOLD":True,"STAGE6D4C1_CLASSIFICATION_READY":ready,"STAGE6D4_SCIENCE_CLOSURE_READY":ready,"STAGE6D5_MANUSCRIPT_INTEGRATION_READY":ready}
    wj(out/"validation/stage6d4c1_validation.json",val)
    wj(out/"summaries/stage6d4c1_summary.json",{"ready":ready,"classification_counts":counts,"label_classifications":labdf[["label","overall_classification"]].to_dict("records"),"next_action":"Integrate D4 common-footprint results into manuscript/claim ledger and archival release." if ready else "Inspect failed D4C1 gate."})
    (out/"reports/stage6d4c1_report.md").write_text("# Stage-6D4C1 classification\n\n"+f"Resolved D3A path: `{pe_path}`\n\n"+f"Science closure ready: `{ready}`\n\n"+labdf.to_string(index=False)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and "manifest" not in p.parts:
            manifest.append({"path":str(p.relative_to(root)).replace("\\","/"),"size_bytes":p.stat().st_size,"sha256":sha_file(p)})
    pd.DataFrame(manifest).to_csv(out/"manifest/stage6d4c1_output_manifest_sha256.csv",index=False)
    print(json.dumps({"validation":val,"classifications":labdf.to_dict("records")},indent=2,ensure_ascii=False))
    return 0
if __name__=="__main__":raise SystemExit(main())
