from __future__ import annotations
import argparse, ast, csv, json, re, shutil
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import pandas as pd


def now():
    return datetime.now(timezone.utc).isoformat()


def norm(x: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(x).strip().lower()).strip("_")


def rel(p: Path, root: Path) -> str:
    try:
        return str(p.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(p).replace("\\", "/")


def wjson(p: Path, obj: Any):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def wcsv(p: Path, fields: list[str], rows: list[dict[str, Any]]):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", newline="", encoding="utf-8") as h:
        w = csv.DictWriter(h, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def canonical(column: str, cfg: dict[str, Any]) -> str:
    token = norm(column)
    changed = True
    while changed:
        changed = False
        for suffix in cfg["merge_suffixes"]:
            s = norm(suffix)
            if token.endswith(s) and len(token) > len(s):
                token = token[:-len(s)].rstrip("_")
                changed = True
                break
    return token


def role_for(base: str, cfg: dict[str, Any]):
    if base in {norm(x) for x in cfg["approved_scalar_bases"]}:
        return "scalar"
    for role, aliases in cfg["approved_channel_bases"].items():
        if base in {norm(x) for x in aliases}:
            return role
    return ""


def all_text_files(root: Path, cfg: dict[str, Any]):
    seen = set()
    for rr in cfg["reference_scan_roots"]:
        b = root / rr
        if not b.exists():
            continue
        items = [b] if b.is_file() else b.rglob("*")
        for p in items:
            if (
                p.is_file()
                and p.suffix.lower() in set(cfg["text_suffixes"])
                and p.stat().st_size <= int(cfg["maximum_text_file_bytes"])
            ):
                key = str(p.resolve())
                if key not in seen:
                    seen.add(key)
                    yield p


def evidence_type(line: str, cfg: dict[str, Any]):
    low = line.lower()
    derived = any(t in low for t in cfg["derived_tokens"])
    raw_read = any(t in low for t in cfg["raw_read_tokens"])
    selection = any(t in low for t in cfg["selection_tokens"])
    rename = any(t in low for t in cfg["rename_tokens"])
    raw_context = any(t in low for t in cfg["raw_source_tokens"])
    if derived:
        return "DERIVED_TRANSFORM"
    if raw_read and raw_context:
        return "RAW_READ_CONTEXT"
    if rename:
        return "RENAME_CONTEXT"
    if selection:
        return "COLUMN_SELECTION_CONTEXT"
    if raw_context:
        return "RAW_SOURCE_CONTEXT"
    return "REFERENCE_ONLY"


def extract_rename_pairs(line: str):
    # Conservative extraction of quoted old:new pairs from dict-like code.
    pairs = []
    for old, new in re.findall(
        r"""['"]([^'"]+)['"]\s*:\s*['"]([^'"]+)['"]""",
        line
    ):
        pairs.append((old, new))
    return pairs


def line_mentions(line: str, column: str, base: str):
    low = line.lower()
    return column.lower() in low or base in norm(line)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2d8e_config.json").read_text(encoding="utf-8")
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in ["validation", "tables", "summaries", "reports"]:
        (out / d).mkdir(parents=True, exist_ok=True)

    pp = root / cfg["prerequisite_validation"]
    pre = json.loads(pp.read_text(encoding="utf-8")) if pp.exists() else {}
    prereq = bool(
        pre.get("STAGE6D3A2D8D_ADJUDICATION_READY", False)
        and pre.get("SNR_COLUMN_DISTRIBUTION_AUDIT_READY", False)
        and pre.get("SNR_PROVENANCE_REFERENCE_AUDIT_READY", False)
        and pre.get("EXACT_GAIA_DR3_IDENTITY_ALREADY_CLOSED", False)
        and not pre.get("DOCUMENTED_NATIVE_SNR_CANDIDATE_READY", True)
    )

    audit_path = root / cfg["semantic_audit"]
    audit = pd.read_csv(audit_path) if audit_path.exists() else pd.DataFrame()
    audit_ready = bool(
        not audit.empty
        and {"companion_path", "snr_column", "canonical_base"}.issubset(audit.columns)
    )

    text_cache = []
    for path in all_text_files(root, cfg):
        try:
            lines = path.read_text(
                encoding="utf-8", errors="replace"
            ).splitlines()
            text_cache.append((path, lines))
        except Exception:
            pass

    evidence_rows = []
    decision_rows = []

    for _, row in audit.iterrows() if audit_ready else []:
        companion = str(row.get("companion_path", "")).strip()
        column = str(row.get("snr_column", "")).strip()
        base = str(row.get("canonical_base", "")).strip() or canonical(column, cfg)
        role = str(row.get("approved_role", "")).strip() or role_for(base, cfg)

        hits = []
        rename_sources = set()
        exact_raw_hits = 0
        selection_hits = 0
        rename_hits = 0
        derived_hits = 0
        raw_context_hits = 0

        for path, lines in text_cache:
            max_hits = int(cfg["maximum_hits_per_column"])
            for i, line in enumerate(lines, 1):
                if not line_mentions(line, column, base):
                    continue
                et = evidence_type(line, cfg)
                if et == "RAW_READ_CONTEXT":
                    exact_raw_hits += 1
                elif et == "COLUMN_SELECTION_CONTEXT":
                    selection_hits += 1
                elif et == "RENAME_CONTEXT":
                    rename_hits += 1
                elif et == "DERIVED_TRANSFORM":
                    derived_hits += 1
                elif et == "RAW_SOURCE_CONTEXT":
                    raw_context_hits += 1

                pairs = extract_rename_pairs(line)
                relevant_pairs = []
                for old, new in pairs:
                    if canonical(new, cfg) == base or canonical(old, cfg) == base:
                        relevant_pairs.append((old, new))
                        rename_sources.add(old)

                rec = {
                    "companion_path": companion,
                    "snr_column": column,
                    "canonical_base": base,
                    "approved_role": role,
                    "reference_path": rel(path, root),
                    "line_number": i,
                    "evidence_type": et,
                    "rename_pairs": "|".join(
                        f"{a}->{b}" for a, b in relevant_pairs
                    ),
                    "excerpt": line.strip()[:1500],
                }
                hits.append(rec)
                evidence_rows.append(rec)
                if len(hits) >= max_hits:
                    break
            if len(hits) >= int(cfg["maximum_hits_per_column"]):
                break

        # Second pass for rename source names, to establish raw provenance of old names.
        rename_source_raw_hits = 0
        for source_name in sorted(rename_sources):
            source_base = canonical(source_name, cfg)
            for path, lines in text_cache:
                for i, line in enumerate(lines, 1):
                    if not line_mentions(line, source_name, source_base):
                        continue
                    et = evidence_type(line, cfg)
                    if et == "RAW_READ_CONTEXT":
                        rename_source_raw_hits += 1
                        rec = {
                            "companion_path": companion,
                            "snr_column": column,
                            "canonical_base": base,
                            "approved_role": role,
                            "reference_path": rel(path, root),
                            "line_number": i,
                            "evidence_type": "RAW_READ_OF_RENAME_SOURCE",
                            "rename_pairs": f"{source_name}->{column}",
                            "excerpt": line.strip()[:1500],
                        }
                        evidence_rows.append(rec)

        direct_authorized = bool(
            role and exact_raw_hits > 0 and derived_hits == 0
        )
        rename_authorized = bool(
            role and rename_hits > 0 and rename_source_raw_hits > 0 and derived_hits == 0
        )
        preserved_selection = bool(
            role and selection_hits > 0 and raw_context_hits > 0 and derived_hits == 0
        )

        if direct_authorized:
            tier = "A_DIRECT_RAW_READ"
            authorize = True
        elif rename_authorized:
            tier = "A_RAW_TO_RENAME"
            authorize = True
        elif preserved_selection:
            tier = "B_PRESERVED_SELECTION_CONTEXT"
            authorize = False
        elif role and derived_hits > 0:
            tier = "D_DERIVED_OR_TRANSFORMED"
            authorize = False
        elif role:
            tier = "C_NAME_COMPATIBLE_UNPROVEN"
            authorize = False
        else:
            tier = "D_SCHEMA_UNRESOLVED"
            authorize = False

        decision_rows.append({
            "companion_path": companion,
            "snr_column": column,
            "canonical_base": base,
            "approved_role": role,
            "finite_rows": row.get("finite_rows", ""),
            "median": row.get("median", ""),
            "q95": row.get("q95", ""),
            "q99": row.get("q99", ""),
            "exact_raw_read_hits": exact_raw_hits,
            "rename_context_hits": rename_hits,
            "rename_source_raw_hits": rename_source_raw_hits,
            "selection_context_hits": selection_hits,
            "raw_source_context_hits": raw_context_hits,
            "derived_transform_hits": derived_hits,
            "evidence_tier": tier,
            "authorizable_native_contract": authorize,
        })

    decision_rows.sort(
        key=lambda r: (
            0 if r["authorizable_native_contract"] else 1,
            r["approved_role"],
            r["companion_path"],
            r["snr_column"],
        )
    )

    wcsv(
        out / "tables/stage6d3a2d8e_static_lineage_evidence.csv",
        [
            "companion_path", "snr_column", "canonical_base", "approved_role",
            "reference_path", "line_number", "evidence_type",
            "rename_pairs", "excerpt"
        ],
        evidence_rows,
    )
    wcsv(
        out / "tables/stage6d3a2d8e_native_contract_decisions.csv",
        [
            "companion_path", "snr_column", "canonical_base", "approved_role",
            "finite_rows", "median", "q95", "q99",
            "exact_raw_read_hits", "rename_context_hits",
            "rename_source_raw_hits", "selection_context_hits",
            "raw_source_context_hits", "derived_transform_hits",
            "evidence_tier", "authorizable_native_contract"
        ],
        decision_rows,
    )

    authorized = [
        r for r in decision_rows
        if bool(r["authorizable_native_contract"])
    ]
    scalar = [r for r in authorized if r["approved_role"] == "scalar"]
    channel_roles = defaultdict(list)
    for r in authorized:
        if r["approved_role"] in {"c1", "c2", "c3", "c4"}:
            channel_roles[r["approved_role"]].append(r)

    coherent_channels = [
        role for role in ["c1", "c2", "c3", "c4"]
        if len(channel_roles.get(role, [])) == 1
    ]
    channel_candidate_ready = len(coherent_channels) >= 2
    scalar_candidate_ready = len(scalar) == 1
    ambiguous_scalar = len(scalar) > 1
    duplicate_channel_role = any(
        len(channel_roles.get(role, [])) > 1
        for role in ["c1", "c2", "c3", "c4"]
    )

    if scalar_candidate_ready and not channel_candidate_ready:
        diagnosis = "ONE_STATICALLY_PROVEN_NATIVE_SCALAR_SNR"
        freeze_rows = scalar
    elif channel_candidate_ready and not scalar_candidate_ready and not duplicate_channel_role:
        diagnosis = "COHERENT_STATICALLY_PROVEN_NATIVE_CHANNEL_SET"
        freeze_rows = [
            channel_roles[role][0] for role in coherent_channels
        ]
    elif scalar_candidate_ready and channel_candidate_ready:
        diagnosis = "MULTIPLE_NATIVE_CONTRACT_FORMS_REQUIRE_SOURCE_SEMANTIC_CHOICE"
        freeze_rows = []
    elif ambiguous_scalar or duplicate_channel_role:
        diagnosis = "MULTIPLE_NON_EQUIVALENT_NATIVE_CANDIDATES_REQUIRE_ADJUDICATION"
        freeze_rows = []
    elif authorized:
        diagnosis = "PARTIAL_NATIVE_CHANNEL_EVIDENCE_INSUFFICIENT_FOR_CONTRACT"
        freeze_rows = []
    else:
        diagnosis = "NO_STATIC_RAW_NATIVE_LINEAGE_PROVEN"
        freeze_rows = []

    wcsv(
        out / "tables/stage6d3a2d8e_freeze_candidate.csv",
        [
            "companion_path", "snr_column", "canonical_base",
            "approved_role", "evidence_tier",
            "authorizable_native_contract"
        ],
        freeze_rows,
    )

    freeze_ready = bool(freeze_rows) and diagnosis in {
        "ONE_STATICALLY_PROVEN_NATIVE_SCALAR_SNR",
        "COHERENT_STATICALLY_PROVEN_NATIVE_CHANNEL_SET",
    }

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "diagnosis": diagnosis,
        "audited_column_count": len(decision_rows),
        "authorizable_native_column_count": len(authorized),
        "scalar_native_candidate_count": len(scalar),
        "coherent_native_channel_roles": coherent_channels,
        "freeze_candidate_row_count": len(freeze_rows),
        "STAGE6D3A2D8D_PREREQUISITE_READY": prereq,
        "D8D_SEMANTIC_AUDIT_READY": audit_ready,
        "STATIC_SOURCE_LINEAGE_EVIDENCE_READY": True,
        "RAW_READ_OR_RAW_RENAME_REQUIRED": True,
        "DERIVED_TRANSFORM_REJECTED_AS_NATIVE": True,
        "NATIVE_SNR_CONTRACT_FREEZE_CANDIDATE_READY": freeze_ready,
        "EXACT_GAIA_DR3_IDENTITY_ALREADY_CLOSED": True,
        "EXTERNAL_GAIA_ID_BRIDGE_ACQUISITION_REQUIRED": False,
        "FROZEN_OVERLAP_GATES_UNCHANGED": True,
        "TARGET_ABUNDANCE_MATCHING_FORBIDDEN": True,
        "STAGE6D3A2D8E_LINEAGE_TRACE_READY": bool(prereq and audit_ready),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": False,
    }
    wjson(
        out / "validation/stage6d3a2d8e_validation.json",
        validation,
    )

    next_action = (
        "Run D8F exact native-S/N contract freeze and canonical source assembly "
        "using only stage6d3a2d8e_freeze_candidate.csv."
        if freeze_ready else
        "Inspect native_contract_decisions.csv and static_lineage_evidence.csv. "
        "No S/N contract may be frozen until one scalar field or a coherent "
        "multi-channel set has raw-read/raw-rename evidence."
    )
    wjson(
        out / "summaries/stage6d3a2d8e_summary.json",
        {
            "diagnosis": diagnosis,
            "next_action": next_action,
            "freeze_candidate": freeze_rows,
            "scientific_disposition": (
                "Static source provenance is separated from column-name plausibility. "
                "No new Gaia identity work is permitted."
            ),
        },
    )

    report = [
        "# Stage-6D3A2D8E GALAH S/N static source-lineage trace",
        "",
        f"- Diagnosis: `{diagnosis}`",
        f"- Audited columns: `{len(decision_rows)}`",
        f"- Authorizable native columns: `{len(authorized)}`",
        f"- Coherent channel roles: `{','.join(coherent_channels) or 'none'}`",
        f"- Freeze candidate ready: `{freeze_ready}`",
        "- Exact Gaia DR3 identity: `already closed`",
        "- Stage-6D3B authorized: `False`",
        "",
        "Authorization requires Tier-A evidence: either a direct raw-read context "
        "for the candidate field or a raw-read source field followed by a documented "
        "rename. Name compatibility or plausible numerical distribution alone is "
        "not sufficient.",
        "",
        next_action,
        "",
    ]
    (out / "reports/stage6d3a2d8e_report.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    print(json.dumps(
        {"validation": validation, "summary": {"diagnosis": diagnosis, "next_action": next_action}},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
