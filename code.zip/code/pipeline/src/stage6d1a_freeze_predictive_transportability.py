from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def canonical_json_bytes(value: Any) -> bytes:
    """Return a platform-independent canonical JSON representation."""
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")

def canonical_json_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8"
    )

def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

def read_columns(path: Path) -> tuple[list[str], int | None, str]:
    try:
        if path.suffix.lower() == ".csv":
            frame = pd.read_csv(path, nrows=5)
            return list(frame.columns), None, ""
        if path.suffix.lower() == ".parquet":
            import pyarrow.parquet as pq
            metadata = pq.ParquetFile(path).metadata
            schema = pq.ParquetFile(path).schema_arrow
            return list(schema.names), int(metadata.num_rows), ""
        if path.suffix.lower() == ".json":
            value = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(value, list) and value and isinstance(value[0], dict):
                return sorted(value[0].keys()), len(value), ""
            if isinstance(value, dict):
                return sorted(value.keys()), None, ""
            return [], None, ""
        if path.suffix.lower() in {".yaml", ".yml"}:
            value = yaml.safe_load(path.read_text(encoding="utf-8"))
            if isinstance(value, dict):
                return sorted(value.keys()), None, ""
            return [], None, ""
    except Exception as exc:
        return [], None, f"{type(exc).__name__}: {exc}"
    return [], None, ""

def logical_hits(path_text: str, columns: list[str], config: dict[str, Any]) -> list[str]:
    haystack = (path_text + " " + " ".join(columns)).lower()
    hits = []
    for logical_name, tokens in config["required_logical_products"].items():
        if any(token.lower() in haystack for token in tokens):
            hits.append(logical_name)
    return hits

def alias_coverage(columns: list[str], aliases: dict[str, list[str]]) -> list[str]:
    normalized = {column.lower() for column in columns}
    covered = []
    for logical, options in aliases.items():
        if any(option.lower() in normalized for option in options):
            covered.append(logical)
    return covered

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    config = json.loads(
        (root / "config/stage6d1a_config.json").read_text(encoding="utf-8")
    )
    protocol_path = root / config["protocol_file"]
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))

    output = root / config["output_dir"]
    if output.exists():
        import shutil
        shutil.rmtree(output)
    for directory in ["validation", "summaries", "tables", "freeze"]:
        (output / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / protocol["prerequisite"]["validation_file"]
    prereq = {}
    if prereq_path.exists():
        prereq = json.loads(prereq_path.read_text(encoding="utf-8"))
    prereq_rows = []
    prereq_ready = True
    for gate in protocol["prerequisite"]["required_gates"]:
        value = bool(prereq.get(gate, False))
        prereq_ready &= value
        prereq_rows.append({
            "gate": gate,
            "value": str(value).lower(),
            "passed": str(value).lower()
        })
    write_csv(
        output / "tables/stage6d1a_prerequisite_gates.csv",
        ["gate", "value", "passed"],
        prereq_rows
    )

    candidates = []
    suffixes = set(config["candidate_suffixes"])
    tokens = [token.lower() for token in config["candidate_tokens"]]
    for root_name in config["scan_roots"]:
        scan_root = root / root_name
        if not scan_root.exists():
            continue
        for path in scan_root.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in suffixes:
                continue
            rel = safe_rel(path, root)
            if not any(token in rel.lower() for token in tokens):
                # Keep Stage-2B machine-readable products even if generically named.
                if "stage2b" not in rel.lower():
                    continue
            columns, row_count, error = read_columns(path)
            logical = logical_hits(rel, columns, config)
            aliases = alias_coverage(columns, config["column_aliases"])
            candidates.append({
                "path": rel,
                "suffix": path.suffix.lower(),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
                "row_count_if_known": "" if row_count is None else row_count,
                "column_count": len(columns),
                "columns": "|".join(columns),
                "logical_product_hits": "|".join(logical),
                "alias_coverage": "|".join(aliases),
                "read_error": error
            })

    candidates.sort(
        key=lambda row: (
            -len(row["logical_product_hits"].split("|"))
            if row["logical_product_hits"] else 0,
            row["path"]
        )
    )
    write_csv(
        output / "tables/stage6d1a_candidate_data_inventory.csv",
        [
            "path", "suffix", "size_bytes", "sha256",
            "row_count_if_known", "column_count", "columns",
            "logical_product_hits", "alias_coverage", "read_error"
        ],
        candidates
    )

    product_rows = []
    all_products_ready = True
    for logical_name in config["required_logical_products"]:
        matching = [
            row for row in candidates
            if logical_name in row["logical_product_hits"].split("|")
        ]
        ready = len(matching) > 0
        all_products_ready &= ready
        product_rows.append({
            "logical_product": logical_name,
            "ready": str(ready).lower(),
            "candidate_count": len(matching),
            "best_candidate": matching[0]["path"] if matching else "",
            "required_action": (
                "" if ready else
                f"Locate or regenerate a frozen machine-readable {logical_name} product."
            )
        })
    write_csv(
        output / "tables/stage6d1a_data_readiness_ledger.csv",
        [
            "logical_product", "ready", "candidate_count",
            "best_candidate", "required_action"
        ],
        product_rows
    )

    source_protocol_raw_sha = sha256_file(protocol_path)
    source_protocol_semantic_sha = canonical_json_sha256(protocol)

    frozen_copy = output / "freeze/stage6d1a_frozen_protocol.json"
    # Binary write preserves LF bytes on Windows instead of translating them to CRLF.
    frozen_copy.write_bytes(
        (json.dumps(protocol, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    )
    frozen_protocol = json.loads(frozen_copy.read_text(encoding="utf-8"))
    frozen_protocol_raw_sha = sha256_file(frozen_copy)
    frozen_protocol_semantic_sha = canonical_json_sha256(frozen_protocol)

    raw_byte_identity = source_protocol_raw_sha == frozen_protocol_raw_sha
    semantic_identity = (
        source_protocol_semantic_sha == frozen_protocol_semantic_sha
        and protocol == frozen_protocol
    )
    protocol_identity = semantic_identity

    claim_ledger = [
        {
            "claim_id": "D1-C1",
            "status": "FROZEN_PROTOCOL",
            "claim": (
                "Held-out transportability will be evaluated out of sample at the "
                "label-fold-support-cell level."
            )
        },
        {
            "claim_id": "D1-C2",
            "status": "HYPOTHESIS_NOT_YET_TESTED",
            "claim": (
                "Higher atmospheric-sensitivity burden predicts larger normalized "
                "held-out transport error."
            )
        },
        {
            "claim_id": "D1-C3",
            "status": "FORBIDDEN_BEFORE_STAGE6D2",
            "claim": "Any elemental label is predictably transportable."
        },
        {
            "claim_id": "D1-C4",
            "status": "FORBIDDEN",
            "claim": (
                "Transportability tiers define intrinsic astrophysical quality or "
                "a universal abundance scale."
            )
        }
    ]
    write_csv(
        output / "tables/stage6d1a_claim_ledger.csv",
        ["claim_id", "status", "claim"],
        claim_ledger
    )

    protocol_ready = bool(prereq_ready and protocol_identity)
    stage6d2_ready = bool(protocol_ready and all_products_ready)

    remaining = []
    if not prereq_ready:
        remaining.append({
            "gate": "EXACT_REPLAY_PREREQUISITE_READY",
            "required_action": "Restore a PASS Stage-6C2H3 validation before any predictive analysis."
        })
    if not all_products_ready:
        for row in product_rows:
            if row["ready"] != "true":
                remaining.append({
                    "gate": f"DATA_{row['logical_product'].upper()}_READY",
                    "required_action": row["required_action"]
                })
    write_csv(
        output / "tables/stage6d1a_remaining_items.csv",
        ["gate", "required_action"],
        remaining
    )

    validation = {
        "stage": config["stage"],
        "protocol_version": config["protocol_version"],
        "implementation_version": config["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "prerequisite_validation": safe_rel(prereq_path, root),
        "candidate_file_count": len(candidates),
        "logical_product_count": len(product_rows),
        "logical_products_ready": sum(row["ready"] == "true" for row in product_rows),
        "frozen_protocol": safe_rel(frozen_copy, root),
        "source_protocol_raw_sha256": source_protocol_raw_sha,
        "frozen_protocol_raw_sha256": frozen_protocol_raw_sha,
        "source_protocol_canonical_sha256": source_protocol_semantic_sha,
        "frozen_protocol_canonical_sha256": frozen_protocol_semantic_sha,
        "PROTOCOL_RAW_BYTE_IDENTITY_READY": raw_byte_identity,
        "prior_stage_outputs_modified": False,
        "EXACT_REPLAY_PREREQUISITE_READY": prereq_ready,
        "PROTOCOL_COPY_IDENTITY_READY": protocol_identity,
        "LABEL_PANEL_FROZEN": True,
        "RESPONSE_DEFINITION_FROZEN": True,
        "SUPPORT_CELL_DEFINITION_FROZEN": True,
        "PREDICTOR_DEFINITION_FROZEN": True,
        "LOLO_VALIDATION_FROZEN": True,
        "SUCCESS_NULL_GATES_FROZEN": True,
        "CLAIM_BOUNDARY_FROZEN": True,
        "STAGE6D1_PROTOCOL_FROZEN": protocol_ready,
        "STAGE6D2_DATA_READY": stage6d2_ready
    }
    write_json(
        output / "validation/stage6d1a_validation.json",
        validation
    )

    summary = {
        "stage": config["stage"],
        "timestamp_utc": utc_now(),
        "primary_question": protocol["scientific_question"],
        "primary_labels": protocol["label_panels"]["primary_elemental_labels"],
        "primary_response": protocol["responses"]["primary"],
        "primary_predictor": protocol["predictors"]["primary_sensitivity_burden"],
        "decision_gates": protocol["decision_gates"],
        "data_readiness": product_rows,
        "remaining_items": remaining,
        "scientific_disposition": (
            "Predictive-transportability protocol is canonically frozen and all machine-readable inputs were located. Stage-6D2 is authorized."
            if stage6d2_ready else
            (
                "Protocol is canonically frozen, but Stage-6D2 remains blocked by the listed machine-readable input gaps."
                if protocol_ready else
                "Protocol freeze is blocked by the prerequisite or canonical semantic-identity gate."
            )
        )
    }
    write_json(
        output / "summaries/stage6d1a_summary.json",
        summary
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False
    ))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
