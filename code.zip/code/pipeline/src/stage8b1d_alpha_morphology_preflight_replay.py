from __future__ import annotations
import argparse, hashlib, json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

def now(): return datetime.now(timezone.utc).isoformat()

def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def resolve(schema, aliases, logical, required=True):
    hits=[x for x in aliases if x in schema]
    if len(hits)==1: return hits[0]
    if len(hits)>1:
        # If multiple aliases exist, fail rather than silently choose.
        raise RuntimeError(f"Ambiguous schema aliases for {logical}: {hits}")
    if required:
        raise RuntimeError(f"No schema alias found for {logical}; candidates={aliases}")
    return None

def ess(w):
    w=np.asarray(w,float)
    s=float(w.sum()); ss=float(np.square(w).sum())
    return s*s/ss if ss>0 else 0.0

def em2(y,w,maxiter=500,tol=1e-10):
    y=np.asarray(y,float); w=np.asarray(w,float)
    q=np.quantile(y,[.30,.70]); mu=np.array(q,float)
    sd=max(float(np.std(y)),1e-3)
    sig=np.array([sd*.55,sd*.55],float); pi=np.array([.5,.5],float)
    last=None
    for _ in range(maxiter):
        dens=[]
        for k in range(2):
            z=(y-mu[k])/sig[k]
            dens.append(pi[k]*np.exp(-.5*z*z)/(sig[k]*np.sqrt(2*np.pi)))
        D=np.column_stack(dens); den=np.maximum(D.sum(axis=1),1e-300)
        r=D/den[:,None]
        rw=r*w[:,None]; nk=rw.sum(axis=0)
        pi=nk/nk.sum()
        mu=(rw*y[:,None]).sum(axis=0)/nk
        var=(rw*np.square(y[:,None]-mu)).sum(axis=0)/nk
        sig=np.sqrt(np.maximum(var,1e-6))
        order=np.argsort(mu); mu,sig,pi=mu[order],sig[order],pi[order]
        ll=float(np.sum(w*np.log(den)))
        if last is not None and abs(ll-last)<=tol*(1+abs(last)): break
        last=ll
    return {"mu_low":float(mu[0]),"mu_high":float(mu[1]),
            "sigma_low":float(sig[0]),"sigma_high":float(sig[1]),
            "pi_high":float(pi[1])}

def as_bool(s):
    if pd.api.types.is_bool_dtype(s.dtype): return s.to_numpy(bool)
    x=s.astype(str).str.strip().str.lower()
    return x.isin(["true","1","yes","y"]).to_numpy(bool)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",default=".")
    a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage8b1d_config.json").read_text(encoding="utf-8"))

    pv=root/c["parent_validation"]; src=root/c["attached_source"]
    if not pv.exists(): raise FileNotFoundError(pv)
    if not src.exists(): raise FileNotFoundError(src)

    parent=json.loads(pv.read_text(encoding="utf-8"))
    parent_ready=bool(
        parent.get("STAGE8B1C1_PROVENANCE_JOIN_READY") is True and
        parent.get("STAGE8B1_REPLAY_WITH_ALPHA3_HOM_READY") is True and
        parent.get("MATCHED_ROWS")==int(c["expected_parent_balanced_rows"]) and
        parent.get("UNMATCHED_ROWS")==0 and
        parent.get("REAL_ALPHA3_MIXTURE_FIT_PERFORMED") is False and
        parent.get("REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED") is False
    )
    if not parent_ready: raise RuntimeError("Stage-8B1C1 parent identity not ready")

    schema=pq.ParquetFile(src).schema_arrow.names
    A=c["science_columns"]
    resolved={}
    for logical in ["source_id","survey","R","absZ","fe_h","alpha3","alpha3_flag","cell","weight"]:
        resolved[logical]=resolve(schema,A[logical],logical,required=True)
    resolved["feh_flag"]=resolve(schema,A["feh_flag"],"feh_flag",required=False)

    cols=list(dict.fromkeys([x for x in resolved.values() if x is not None]))
    df=pd.read_parquet(src,columns=cols)

    if pd.api.types.is_float_dtype(df[resolved["source_id"]].dtype):
        raise RuntimeError("source_id float coercion forbidden")

    # Numeric views only for scientific coordinates/weights; source_id remains untouched.
    R=pd.to_numeric(df[resolved["R"]],errors="coerce").to_numpy(float)
    Z=pd.to_numeric(df[resolved["absZ"]],errors="coerce").to_numpy(float)
    feh=pd.to_numeric(df[resolved["fe_h"]],errors="coerce").to_numpy(float)
    alp=pd.to_numeric(df[resolved["alpha3"]],errors="coerce").to_numpy(float)
    w=pd.to_numeric(df[resolved["weight"]],errors="coerce").to_numpy(float)
    cell=pd.to_numeric(df[resolved["cell"]],errors="raise").to_numpy(np.int64)
    survey=df[resolved["survey"]].astype(str).to_numpy()

    aflag=as_bool(df[resolved["alpha3_flag"]])
    fflag=np.ones(len(df),dtype=bool)
    if resolved["feh_flag"] is not None:
        fflag=as_bool(df[resolved["feh_flag"]])

    d=c["domain"]
    m=(np.isfinite(R)&np.isfinite(Z)&np.isfinite(feh)&np.isfinite(alp)&np.isfinite(w)&(w>0)&
       aflag&fflag&
       (R>=d["R_min"])&(R<=d["R_max"])&
       (Z>=d["absZ_min"])&(Z<=d["absZ_max"])&
       (feh>=d["feh_min"])&(feh<=d["feh_max"]))

    Rm,Zm,fehm,alpm,wm,cellm,surm=R[m],Z[m],feh[m],alp[m],w[m],cell[m],survey[m]
    both_surveys=bool(all(np.any(surm==s) for s in c["survey_values"]))
    total_blocks=int(np.unique(cellm).size)
    block_ready=total_blocks>=int(c["minimum_total_nside16_blocks"])

    rows=[]; hw=float(c["knot_halfwidth_dex"])
    for knot in c["fixed_feh_knots"]:
        km=np.abs(fehm-float(knot))<=hw
        for s in c["survey_values"]:
            q=km&(surm==s)
            rows.append({
                "feh_knot":float(knot),"survey":s,
                "rows":int(q.sum()),"effective_n":ess(wm[q]),
                "nside16_cells":int(np.unique(cellm[q]).size),
                "weight_sum":float(wm[q].sum())
            })
    sup=pd.DataFrame(rows)
    support_ready=bool(
        (sup["effective_n"]>=float(c["minimum_bin_effective_n"])).all() and
        (sup["nside16_cells"]>=int(c["minimum_cells_per_survey_per_knot"])).all()
    )

    # Synthetic-only estimator smoke; no observed alpha3 distribution enters.
    sm=c["synthetic_smoke"]
    rng=np.random.Generator(np.random.PCG64DXSM(int(sm["seed"])))
    n=int(sm["n"]); z=rng.random(n)<float(sm["pi_high"])
    y=np.where(z,
               rng.normal(sm["mu_high"],sm["sigma_high"],n),
               rng.normal(sm["mu_low"],sm["sigma_low"],n))
    ws=np.exp(rng.normal(0,.25,n))
    fit=em2(y,ws)
    smoke_ready=bool(
        abs(fit["mu_low"]-sm["mu_low"])<=sm["max_abs_mu_error"] and
        abs(fit["mu_high"]-sm["mu_high"])<=sm["max_abs_mu_error"] and
        abs(fit["pi_high"]-sm["pi_high"])<=sm["max_abs_pi_error"] and
        fit["mu_low"]<fit["mu_high"]
    )

    ready=bool(parent_ready and both_surveys and block_ready and support_ready and smoke_ready)

    out=root/c["output_dir"]
    for q in ["tables","validation","freeze"]: (out/q).mkdir(parents=True,exist_ok=True)
    sup.to_csv(out/"tables/stage8b1d_knot_support.csv",index=False)
    pd.DataFrame([{
        "eligible_rows":int(m.sum()),
        "total_blocks":total_blocks,
        "APOGEE_NATIVE_rows":int(np.sum(surm=="APOGEE_NATIVE")),
        "GALAH_CORRECTED_rows":int(np.sum(surm=="GALAH_CORRECTED"))
    }]).to_csv(out/"tables/stage8b1d_sample_summary.csv",index=False)
    (out/"freeze/stage8b1d_protocol_frozen.json").write_text(
        (root/"protocol/stage8b1d_protocol.json").read_text(encoding="utf-8"),
        encoding="utf-8"
    )

    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "STAGE8B1C1_PARENT_READY":parent_ready,
      "RESOLVED_SCHEMA_COLUMNS":resolved,
      "SOURCE_ID_FLOAT_COERCION_USED":False,
      "ALPHA3_PRIMARY_FLAG_REQUIRED":True,
      "FE_H_PRIMARY_FLAG_REQUIRED":resolved["feh_flag"] is not None,
      "ELIGIBLE_ROWS":int(m.sum()),
      "ELIGIBLE_SURVEY_COUNTS":{s:int(np.sum(surm==s)) for s in c["survey_values"]},
      "PRIMARY_NSIDE16_BLOCKS":total_blocks,
      "BOTH_SURVEYS_PRESENT":both_surveys,
      "PRIMARY_BLOCK_COUNT_READY":block_ready,
      "ALL_7_KNOTS_BOTH_SURVEYS_SUPPORT_READY":support_ready,
      "SYNTHETIC_EM_SMOKE_READY":smoke_ready,
      "SYNTHETIC_EM_SMOKE_FIT":fit,
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":False,
      "REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED":False,
      "STAGE8B1D_PREFLIGHT_REPLAY_READY":ready,
      "STAGE8B2_SYNTHETIC_POWER_READY":ready,
      "STAGE8_REAL_MIXTURE_INTERPRETATION_AUTHORIZED":False
    }
    write_json(out/"validation/stage8b1d_validation.json",val)
    print(json.dumps(val,indent=2,ensure_ascii=False))
    return 0 if ready else 2

if __name__=="__main__":
    raise SystemExit(main())
