from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8"
    )

def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

def read_columns(path: Path) -> tuple[list[str], int]:
    if path.suffix.lower() == ".parquet":
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(path)
        return list(pf.schema_arrow.names), int(pf.metadata.num_rows)
    frame = pd.read_csv(path, nrows=5)
    return list(frame.columns), -1

def read_table(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    return pd.read_csv(path)

def find_alias(columns: list[str], options: list[str]) -> str | None:
    lookup = {column.lower(): column for column in columns}
    for option in options:
        if option.lower() in lookup:
            return lookup[option.lower()]
    return None

def normalized_token(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")

def contains_token(column: str, token: str) -> bool:
    text = normalized_token(column)
    target = normalized_token(token)
    return (
        text == target
        or text.startswith(target + "_")
        or text.endswith("_" + target)
        or ("_" + target + "_") in ("_" + text + "_")
    )

def detect_wide_pairs(columns: list[str], cfg: dict[str, Any]) -> dict[str, dict[str, list[str]]]:
    pairs: dict[str, dict[str, list[str]]] = {}
    for label in cfg["primary_labels"]:
        label_variants = cfg["label_token_variants"][label]
        survey_hits: dict[str, list[str]] = {"apogee": [], "galah": []}
        for column in columns:
            low = normalized_token(column)
            label_hit = any(
                contains_token(low, variant)
                for variant in label_variants
            )
            if not label_hit:
                continue
            for survey, survey_tokens in cfg["survey_tokens"].items():
                if any(contains_token(low, token) for token in survey_tokens):
                    survey_hits[survey].append(column)
        if survey_hits["apogee"] and survey_hits["galah"]:
            pairs[label] = {
                "apogee": sorted(set(survey_hits["apogee"])),
                "galah": sorted(set(survey_hits["galah"]))
            }
    return pairs

def detect_long_contract(columns: list[str], cfg: dict[str, Any]) -> dict[str, Any]:
    aliases = cfg["long_pair_aliases"]
    mapping = {
        key: find_alias(columns, options)
        for key, options in aliases.items()
    }
    paired_long = bool(
        mapping["label"]
        and mapping["apogee_value"]
        and mapping["galah_value"]
    )
    residual_long = bool(
        mapping["label"] and mapping["residual"]
    )
    heldout_long = bool(
        mapping["fold"] and (paired_long or residual_long)
    )
    return {
        "mapping": mapping,
        "paired_long": paired_long,
        "residual_long": residual_long,
        "heldout_long": heldout_long
    }

def coefficient_mapping(columns: list[str], cfg: dict[str, Any]) -> dict[str, str | None]:
    return {
        key: find_alias(columns, options)
        for key, options in cfg["coefficient_aliases"].items()
    }

def coefficient_contract_ready(mapping: dict[str, str | None]) -> bool:
    required = [
        "label", "fold", "analysis_set", "model_role",
        "intercept", "a_t", "a_g", "a_fe"
    ]
    return all(mapping.get(key) for key in required)

def audit_coefficients(
    coefficient_path: Path,
    cfg: dict[str, Any]
) -> tuple[
    dict[str, Any],
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]]
]:
    columns, _ = read_columns(coefficient_path)
    mapping = coefficient_mapping(columns, cfg)
    if not coefficient_contract_ready(mapping):
        return (
            {
                "contract_ready": False,
                "mapping": mapping,
                "reason": "required coefficient columns are missing"
            },
            [],
            [],
            []
        )

    frame = read_table(coefficient_path).rename(columns={
        source: target
        for target, source in mapping.items()
        if source
    })
    frame["label"] = frame["label"].astype(str).str.lower()
    frame["fold"] = pd.to_numeric(frame["fold"], errors="coerce")
    frame = frame[frame["label"].isin(cfg["primary_labels"])].copy()

    row_inventory = []
    for _, row in frame.iterrows():
        row_inventory.append({
            "label": row["label"],
            "fold": row["fold"],
            "analysis_set": str(row["analysis_set"]),
            "model_role": str(row["model_role"]),
            "n_train": row.get("n_train", ""),
            "n_eval": row.get("n_eval", ""),
            "training_hash": row.get("training_hash", ""),
            "evaluation_hash": row.get("evaluation_hash", ""),
            "intercept": row["intercept"],
            "a_t": row["a_t"],
            "a_g": row["a_g"],
            "a_fe": row["a_fe"]
        })

    grouped_rows = []
    expected_folds = set(cfg["expected_heldout_folds"])
    for (analysis_set, model_role), group in frame.groupby(
        ["analysis_set", "model_role"], dropna=False
    ):
        label_details = []
        labels_complete = 0
        duplicate_cells = 0
        for label in cfg["primary_labels"]:
            subset = group[
                (group["label"] == label)
                & (group["fold"].isin(cfg["expected_heldout_folds"]))
            ]
            fold_counts = subset.groupby("fold").size().to_dict()
            observed_folds = set(int(value) for value in fold_counts)
            duplicates = sum(max(int(count) - 1, 0) for count in fold_counts.values())
            complete = observed_folds == expected_folds and duplicates == 0
            labels_complete += int(complete)
            duplicate_cells += duplicates
            label_details.append({
                "label": label,
                "observed_folds": sorted(observed_folds),
                "missing_folds": sorted(expected_folds - observed_folds),
                "duplicate_rows": duplicates,
                "complete": complete
            })

        fold_minus_one_rows = int((group["fold"] == -1).sum())
        heldout_rows = group[group["fold"].isin(cfg["expected_heldout_folds"])]
        structural_score = (
            labels_complete * 100
            - duplicate_cells * 1000
            - abs(len(heldout_rows) - labels_complete * len(expected_folds))
        )
        grouped_rows.append({
            "analysis_set": str(analysis_set),
            "model_role": str(model_role),
            "total_rows": len(group),
            "heldout_fold_rows": len(heldout_rows),
            "fold_minus_one_rows": fold_minus_one_rows,
            "labels_complete": labels_complete,
            "duplicate_cells": duplicate_cells,
            "structural_score": structural_score,
            "label_details": json.dumps(label_details, sort_keys=True)
        })

    grouped_rows.sort(
        key=lambda row: (
            -int(row["structural_score"]),
            -int(row["labels_complete"]),
            int(row["duplicate_cells"]),
            row["analysis_set"],
            row["model_role"]
        )
    )

    best_score = grouped_rows[0]["structural_score"] if grouped_rows else None
    winners = [
        row for row in grouped_rows
        if row["structural_score"] == best_score
        and row["labels_complete"] > 0
        and row["duplicate_cells"] == 0
    ]

    selected_rows = []
    selected_contract = {}
    if len(winners) == 1:
        winner = winners[0]
        selected_contract = {
            "analysis_set": winner["analysis_set"],
            "model_role": winner["model_role"],
            "labels_complete": winner["labels_complete"],
            "structural_score": winner["structural_score"]
        }
        selected_frame = frame[
            (frame["analysis_set"].astype(str) == winner["analysis_set"])
            & (frame["model_role"].astype(str) == winner["model_role"])
            & (frame["fold"].isin(cfg["expected_heldout_folds"]))
        ].copy()
        for _, row in selected_frame.iterrows():
            selected_rows.append({
                "label": row["label"],
                "fold": int(row["fold"]),
                "analysis_set": str(row["analysis_set"]),
                "model_role": str(row["model_role"]),
                "intercept": row["intercept"],
                "a_t": row["a_t"],
                "a_g": row["a_g"],
                "a_fe": row["a_fe"],
                "n_train": row.get("n_train", ""),
                "n_eval": row.get("n_eval", ""),
                "training_hash": row.get("training_hash", ""),
                "evaluation_hash": row.get("evaluation_hash", "")
            })

    summary = {
        "contract_ready": True,
        "mapping": mapping,
        "rows": len(frame),
        "labels": sorted(frame["label"].dropna().unique().tolist()),
        "folds": sorted(
            int(value)
            for value in frame["fold"].dropna().unique()
        ),
        "candidate_contract_count": len(grouped_rows),
        "unique_structural_winner": len(winners) == 1,
        "selected_contract": selected_contract,
        "winner_count": len(winners)
    }
    return summary, row_inventory, grouped_rows, selected_rows

def scan_label_coverage(
    root: Path,
    cfg: dict[str, Any]
) -> tuple[list[dict[str, Any]], dict[str, list[str]]]:
    rows = []
    union: dict[str, list[str]] = {
        label: [] for label in cfg["primary_labels"]
    }
    suffixes = set(cfg["suffixes"])

    for rel_root in cfg["search_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in suffixes:
                continue
            try:
                columns, row_count = read_columns(path)
                pairs = detect_wide_pairs(columns, cfg)
                long_contract = detect_long_contract(columns, cfg)
                long_labels: list[str] = []

                if long_contract["mapping"]["label"] and (
                    long_contract["paired_long"]
                    or long_contract["residual_long"]
                ):
                    try:
                        label_column = long_contract["mapping"]["label"]
                        if path.suffix.lower() == ".parquet":
                            labels = pd.read_parquet(
                                path, columns=[label_column]
                            )[label_column]
                        else:
                            labels = pd.read_csv(
                                path, usecols=[label_column]
                            )[label_column]
                        long_labels = sorted(
                            set(
                                labels.dropna().astype(str).str.lower()
                            ).intersection(cfg["primary_labels"])
                        )
                    except Exception:
                        long_labels = []

                file_labels = sorted(set(pairs).union(long_labels))
                for label in file_labels:
                    union[label].append(safe_rel(path, root))

                rows.append({
                    "path": safe_rel(path, root),
                    "suffix": path.suffix.lower(),
                    "row_count": row_count,
                    "column_count": len(columns),
                    "wide_paired_labels": "|".join(sorted(pairs)),
                    "wide_pair_detail": json.dumps(pairs, sort_keys=True),
                    "long_labels": "|".join(long_labels),
                    "long_paired_contract": str(
                        long_contract["paired_long"]
                    ).lower(),
                    "long_residual_contract": str(
                        long_contract["residual_long"]
                    ).lower(),
                    "heldout_long_contract": str(
                        long_contract["heldout_long"]
                    ).lower(),
                    "long_mapping": json.dumps(
                        long_contract["mapping"], sort_keys=True
                    ),
                    "all_supported_labels": "|".join(file_labels),
                    "sha256": sha256_file(path),
                    "read_error": ""
                })
            except Exception as exc:
                rows.append({
                    "path": safe_rel(path, root),
                    "suffix": path.suffix.lower(),
                    "row_count": "",
                    "column_count": "",
                    "wide_paired_labels": "",
                    "wide_pair_detail": "",
                    "long_labels": "",
                    "long_paired_contract": "false",
                    "long_residual_contract": "false",
                    "heldout_long_contract": "false",
                    "long_mapping": "",
                    "all_supported_labels": "",
                    "sha256": sha256_file(path),
                    "read_error": f"{type(exc).__name__}: {exc}"
                })

    rows.sort(
        key=lambda row: (
            -len(
                [
                    value for value
                    in row["all_supported_labels"].split("|")
                    if value
                ]
            ),
            row["path"]
        )
    )
    return rows, union

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d2a2_config.json").read_text(
            encoding="utf-8"
        )
    )

    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables", "reports", "freeze"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg["prerequisite_validation"]
    prereq = (
        json.loads(prereq_path.read_text(encoding="utf-8"))
        if prereq_path.exists() else {}
    )
    prereq_ready = bool(
        prereq.get("STAGE6D1_PROTOCOL_FROZEN", False)
        and prereq.get("STAGE6D2_DATA_READY", False)
    )

    coefficient_path = root / cfg["coefficient_file"]
    coefficient_exists = coefficient_path.exists()
    if coefficient_exists:
        (
            coefficient_summary,
            coefficient_rows,
            candidate_contract_rows,
            selected_coefficient_rows
        ) = audit_coefficients(coefficient_path, cfg)
    else:
        coefficient_summary = {
            "contract_ready": False,
            "reason": "coefficient file missing"
        }
        coefficient_rows = []
        candidate_contract_rows = []
        selected_coefficient_rows = []

    write_csv(
        out / "tables/stage6d2a2_coefficient_row_inventory.csv",
        [
            "label", "fold", "analysis_set", "model_role",
            "n_train", "n_eval", "training_hash", "evaluation_hash",
            "intercept", "a_t", "a_g", "a_fe"
        ],
        coefficient_rows
    )
    write_csv(
        out / "tables/stage6d2a2_coefficient_contract_candidates.csv",
        [
            "analysis_set", "model_role", "total_rows",
            "heldout_fold_rows", "fold_minus_one_rows",
            "labels_complete", "duplicate_cells",
            "structural_score", "label_details"
        ],
        candidate_contract_rows
    )
    write_csv(
        out / "tables/stage6d2a2_selected_coefficient_rows.csv",
        [
            "label", "fold", "analysis_set", "model_role",
            "intercept", "a_t", "a_g", "a_fe",
            "n_train", "n_eval", "training_hash", "evaluation_hash"
        ],
        selected_coefficient_rows
    )
    write_json(
        out / "summaries/stage6d2a2_coefficient_adjudication.json",
        coefficient_summary
    )

    coverage_rows, union = scan_label_coverage(root, cfg)
    write_csv(
        out / "tables/stage6d2a2_label_product_inventory.csv",
        [
            "path", "suffix", "row_count", "column_count",
            "wide_paired_labels", "wide_pair_detail",
            "long_labels", "long_paired_contract",
            "long_residual_contract", "heldout_long_contract",
            "long_mapping", "all_supported_labels",
            "sha256", "read_error"
        ],
        coverage_rows
    )

    union_rows = []
    for label in cfg["primary_labels"]:
        files = sorted(set(union[label]))
        union_rows.append({
            "label": label,
            "supported": str(bool(files)).lower(),
            "candidate_file_count": len(files),
            "candidate_files": "|".join(files),
            "gradient_label": str(
                label in cfg["gradient_labels"]
            ).lower()
        })
    write_csv(
        out / "tables/stage6d2a2_label_coverage_union.csv",
        [
            "label", "supported", "candidate_file_count",
            "candidate_files", "gradient_label"
        ],
        union_rows
    )

    supported_labels = [
        row["label"]
        for row in union_rows
        if row["supported"] == "true"
    ]
    unsupported_labels = [
        row["label"]
        for row in union_rows
        if row["supported"] != "true"
    ]
    gradient_coverage_ready = all(
        label in supported_labels
        for label in cfg["gradient_labels"]
    )
    predictive_label_count_ready = (
        len(supported_labels)
        >= cfg["minimum_labels_for_predictive_panel"]
    )
    coefficient_selection_ready = bool(
        coefficient_summary.get(
            "unique_structural_winner", False
        )
        and selected_coefficient_rows
    )

    remaining = []
    if not coefficient_exists:
        remaining.append({
            "gate": "COEFFICIENT_FILE_READY",
            "required_action": (
                f"Restore {cfg['coefficient_file']}."
            )
        })
    elif not coefficient_summary.get("contract_ready", False):
        remaining.append({
            "gate": "COEFFICIENT_SCHEMA_READY",
            "required_action": coefficient_summary.get(
                "reason", "Repair coefficient schema."
            )
        })
    elif not coefficient_selection_ready:
        remaining.append({
            "gate": "UNIQUE_COEFFICIENT_CONTRACT_READY",
            "required_action": (
                "Inspect coefficient-contract candidates and identify the "
                "single structurally complete cross-fit (analysis_set, "
                "model_role) combination without using coefficient values."
            )
        })

    if not predictive_label_count_ready:
        remaining.append({
            "gate": "PREDICTIVE_LABEL_COVERAGE_READY",
            "required_action": (
                f"Only {len(supported_labels)} primary labels have a paired "
                f"or long residual product; the frozen gate requires at least "
                f"{cfg['minimum_labels_for_predictive_panel']}. Missing: "
                + ", ".join(unsupported_labels)
            )
        })

    if not gradient_coverage_ready:
        missing_gradient = [
            label for label in cfg["gradient_labels"]
            if label not in supported_labels
        ]
        remaining.append({
            "gate": "GRADIENT_LABEL_COVERAGE_READY",
            "required_action": (
                "Missing paired products for gradient labels: "
                + ", ".join(missing_gradient)
            )
        })

    write_csv(
        out / "tables/stage6d2a2_remaining_items.csv",
        ["gate", "required_action"],
        remaining
    )

    protocol_amendment_needed = bool(
        not predictive_label_count_ready
        and gradient_coverage_ready
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "coefficient_file": safe_rel(coefficient_path, root),
        "coefficient_file_sha256": (
            sha256_file(coefficient_path)
            if coefficient_exists else ""
        ),
        "supported_primary_labels": supported_labels,
        "unsupported_primary_labels": unsupported_labels,
        "supported_primary_label_count": len(supported_labels),
        "required_primary_label_count": (
            cfg["minimum_labels_for_predictive_panel"]
        ),
        "selected_coefficient_contract": (
            coefficient_summary.get("selected_contract", {})
        ),
        "selected_coefficient_row_count": len(
            selected_coefficient_rows
        ),
        "prior_stage_outputs_modified": False,
        "STAGE6D1A_PREREQUISITE_READY": prereq_ready,
        "COEFFICIENT_SCHEMA_READY": bool(
            coefficient_summary.get("contract_ready", False)
        ),
        "UNIQUE_COEFFICIENT_CONTRACT_READY": (
            coefficient_selection_ready
        ),
        "FOLD_MINUS_ONE_EXCLUDED_FROM_OOF_SELECTION": True,
        "LABEL_PRODUCT_INVENTORY_READY": True,
        "GRADIENT_LABEL_COVERAGE_READY": gradient_coverage_ready,
        "PREDICTIVE_LABEL_COVERAGE_READY": (
            predictive_label_count_ready
        ),
        "PROTOCOL_AMENDMENT_NEEDED": protocol_amendment_needed,
        "STAGE6D2A2_AUDIT_READY": bool(
            prereq_ready
            and coefficient_summary.get("contract_ready", False)
        ),
        "STAGE6D2A_RECONSTRUCTION_READY": bool(
            prereq_ready
            and coefficient_selection_ready
            and predictive_label_count_ready
        )
    }
    write_json(
        out / "validation/stage6d2a2_validation.json",
        validation
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "coefficient_adjudication": coefficient_summary,
        "label_coverage": {
            "supported": supported_labels,
            "unsupported": unsupported_labels,
            "gradient_coverage_ready": gradient_coverage_ready,
            "predictive_label_count_ready": (
                predictive_label_count_ready
            )
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "A unique structural coefficient contract and sufficient label "
            "coverage are available. Exact OOF reconstruction may proceed."
            if validation["STAGE6D2A_RECONSTRUCTION_READY"] else
            (
                "The five frozen gradient labels are covered, but the "
                "prespecified seven-of-nine predictive panel is unavailable. "
                "A transparent data-availability protocol amendment is required "
                "before fitting."
                if protocol_amendment_needed else
                "Exact coefficient or label-product closure remains incomplete."
            )
        )
    }
    write_json(
        out / "summaries/stage6d2a2_summary.json",
        summary
    )

    report = [
        "# Stage-6D2A2 coefficient-role and label-coverage adjudication",
        "",
        f"- Coefficient schema ready: `{validation['COEFFICIENT_SCHEMA_READY']}`",
        f"- Unique structural coefficient contract: `{validation['UNIQUE_COEFFICIENT_CONTRACT_READY']}`",
        f"- Supported primary labels: `{', '.join(supported_labels) or 'none'}`",
        f"- Unsupported primary labels: `{', '.join(unsupported_labels) or 'none'}`",
        f"- Gradient-label coverage: `{gradient_coverage_ready}`",
        f"- Seven-of-nine predictive coverage: `{predictive_label_count_ready}`",
        f"- Protocol amendment needed: `{protocol_amendment_needed}`",
        "",
        "No coefficient magnitude, Q value, predictive accuracy, or outcome-based "
        "selection is used in this audit.",
        ""
    ]
    (
        out
        / "reports/stage6d2a2_coefficient_label_coverage_audit.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False
    ))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
