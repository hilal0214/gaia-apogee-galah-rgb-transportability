from __future__ import annotations
import argparse,hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
import numpy as np,pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()
def wj(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def rt(p):
    if p.suffix.lower()==".parquet": return pd.read_parquet(p)
    if p.suffix.lower()==".feather": return pd.read_feather(p)
    return pd.read_csv(p)
def resolve(cols,cands):
    return next((x for x in cands if x in cols),None)
def exact_uint64_series(s,name):
    vals=[]
    for i,v in enumerate(s):
        if pd.isna(v):
            vals.append(pd.NA); continue
        if isinstance(v,(int,np.integer)):
            if int(v)<0: raise ValueError(f"{name}: negative id at row {i}")
            vals.append(str(int(v))); continue
        if isinstance(v,(float,np.floating)):
            if not np.isfinite(v) or not float(v).is_integer():
                raise ValueError(f"{name}: non-integral float id at row {i}: {v!r}")
            if abs(float(v))>2**53:
                raise ValueError(f"{name}: unsafe float id >2^53 at row {i}: {v!r}")
            vals.append(str(int(v))); continue
        t=str(v).strip()
        if not t.isdigit():
            raise ValueError(f"{name}: non-digit id at row {i}: {v!r}")
        vals.append(str(int(t)))
    return pd.Series(vals,dtype="string")
def canonical_survey(s):
    return s.astype(str).replace({"APOGEE":"APOGEE_NATIVE","GALAH":"GALAH_CORRECTED"})
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage6d4a3_config.json").read_text())
    out=root/c["output_dir"]
    if out.exists(): shutil.rmtree(out)
    for d in ["validation","augmented","tables","lineage","summaries"]:(out/d).mkdir(parents=True,exist_ok=True)

    pre=json.loads((root/c["d4a2_validation"]).read_text())
    prereq=bool(
        pre.get("D4A1_PREREQUISITE_READY",False)
        and pre.get("STAGE4B_COMMON_MODULE_READY",False)
        and pre.get("STAGE4B_IMPORTED_API_RESOLVED",False)
        and pre.get("FROZEN_METHOD_CONFIG_IDENTITY_READY",False)
        and pre.get("ORIGINAL_GAIA_HEALPIX5_BLOCK_PRESENT",True) is False
        and pre.get("NO_BOOTSTRAP_BLOCK_SUBSTITUTION_USED",False)
    )

    bp=root/c["balanced_source"];sp=root/c["authoritative_stage4a_source"]
    if not bp.exists(): raise FileNotFoundError(str(bp))
    if not sp.exists(): raise FileNotFoundError(str(sp))
    b=rt(bp).reset_index(drop=True)
    s=rt(sp)

    bid=resolve(b.columns,c["balanced_source_id_candidates"])
    sid=resolve(s.columns,c["stage4a_source_id_candidates"])
    ssur=resolve(s.columns,c["survey_column_stage4a_candidates"])
    if not bid or not sid: raise RuntimeError("source-id column unresolved")
    if c["block_column"] not in s.columns: raise RuntimeError("authoritative Stage4A gaia_healpix5 missing")
    if c["survey_column_balanced"] not in b.columns: raise RuntimeError("balanced survey column missing")
    if not ssur: raise RuntimeError("Stage4A survey column unresolved")
    if c["weight_column"] not in b.columns: raise RuntimeError("balanced weight column missing")

    b["_join_id"]=exact_uint64_series(b[bid],"balanced_id")
    s2=s[[sid,ssur,c["block_column"]]].copy()
    s2["_join_id"]=exact_uint64_series(s2[sid],"stage4a_id")
    s2["_survey_stage4a"]=canonical_survey(s2[ssur])
    s2[c["block_column"]]=pd.to_numeric(s2[c["block_column"]],errors="coerce")

    # Stage4A can contain duplicate source rows only if perfectly consistent.
    grp=s2.groupby("_join_id",sort=False,dropna=False)
    conflict_rows=[]
    dedup=[]
    for key,g in grp:
        blocks=g[c["block_column"]].dropna().unique()
        surveys=g["_survey_stage4a"].dropna().unique()
        if len(blocks)>1 or len(surveys)>1:
            conflict_rows.append({"join_id":key,"n_rows":len(g),"block_values":"|".join(map(str,blocks[:10])),"survey_values":"|".join(map(str,surveys[:10]))})
        else:
            dedup.append(g.iloc[0])
    if conflict_rows:
        pd.DataFrame(conflict_rows).to_csv(out/"tables/stage6d4a3_stage4a_conflicts.csv",index=False)
    stage4a_consistent=(len(conflict_rows)==0)
    suniq=pd.DataFrame(dedup) if dedup else s2.iloc[0:0].copy()

    before_cols=list(b.columns)
    before_rows=len(b)
    before_order=b["_join_id"].tolist()
    before_weights=pd.to_numeric(b[c["weight_column"]],errors="coerce").to_numpy(float).copy()

    m=b.merge(
        suniq[["_join_id","_survey_stage4a",c["block_column"]]],
        on="_join_id",how="left",validate="many_to_one",sort=False
    )
    m["_survey_balanced"]=canonical_survey(m[c["survey_column_balanced"]])
    m["_survey_identity"]=(m["_survey_balanced"]==m["_survey_stage4a"])
    block_finite=np.isfinite(pd.to_numeric(m[c["block_column"]],errors="coerce"))
    survey_identity=bool(m.loc[block_finite,"_survey_identity"].all())
    complete_block=bool(block_finite.all())
    block_count=int(pd.to_numeric(m.loc[block_finite,c["block_column"]],errors="coerce").nunique())

    row_conservation=(len(m)==before_rows)
    order_conservation=(m["_join_id"].tolist()==before_order)
    weights_after=pd.to_numeric(m[c["weight_column"]],errors="coerce").to_numpy(float)
    weight_identity=bool(np.array_equal(before_weights,weights_after,equal_nan=True))

    exact_input_rows=(len(m)==c["expected_rows"])
    survey_set=set(m[c["survey_column_balanced"]].astype(str).unique())==set(c["expected_surveys"])
    min_blocks_ready=block_count>=c["expected_min_blocks"]

    outcols=[x for x in m.columns if not x.startswith("_")]
    aug=m[outcols].copy()
    apath=out/"augmented/stage6d4a3_balanced_sources_with_gaia_healpix5.parquet"
    aug.to_parquet(apath,index=False)

    block_summary=aug.groupby(c["block_column"],dropna=False).agg(
        rows=(bid,"size"),
        APOGEE_NATIVE_rows=(c["survey_column_balanced"],lambda x:int((x=="APOGEE_NATIVE").sum())),
        GALAH_CORRECTED_rows=(c["survey_column_balanced"],lambda x:int((x=="GALAH_CORRECTED").sum()))
    ).reset_index()
    block_summary.to_csv(out/"tables/stage6d4a3_gaia_healpix5_block_summary.csv",index=False)

    ready=bool(
        prereq and stage4a_consistent and complete_block and survey_identity
        and row_conservation and order_conservation and weight_identity
        and exact_input_rows and survey_set and min_blocks_ready
    )

    lineage={
        "balanced_source":str(bp.relative_to(root)).replace("\\","/"),
        "balanced_source_sha256":sha(bp),
        "authoritative_stage4a_source":str(sp.relative_to(root)).replace("\\","/"),
        "authoritative_stage4a_source_sha256":sha(sp),
        "balanced_source_id_column":bid,
        "stage4a_source_id_column":sid,
        "stage4a_survey_column":ssur,
        "restored_block_column":c["block_column"],
        "join_contract":"exact integer-safe source-id identity; many-to-one only after consistency deduplication",
        "science_outcomes_used":False
    }
    wj(out/"lineage/stage6d4a3_lineage.json",lineage)
    val={
        "stage":c["stage"],"protocol_version":c["protocol_version"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
        "D4A2_PREREQUISITE_READY":prereq,
        "STAGE4A_AUTHORITATIVE_SOURCE_READY":True,
        "EXACT_INTEGER_SAFE_SOURCE_JOIN_READY":True,
        "STAGE4A_SOURCE_BLOCK_SURVEY_CONSISTENCY_READY":stage4a_consistent,
        "ROW_COUNT_CONSERVATION_READY":row_conservation,
        "ROW_ORDER_CONSERVATION_READY":order_conservation,
        "FINAL_BALANCE_WEIGHT_IDENTITY_READY":weight_identity,
        "SURVEY_IDENTITY_READY":survey_identity,
        "GAIA_HEALPIX5_COMPLETE_READY":complete_block,
        "GAIA_HEALPIX5_BLOCK_COUNT":block_count,
        "MINIMUM_100_SPATIAL_BLOCKS_READY":min_blocks_ready,
        "NO_OUTCOME_ABUNDANCE_R_ABSZ_USED_FOR_JOIN":True,
        "NO_BOOTSTRAP_BLOCK_SUBSTITUTION_USED":True,
        "AUGMENTED_SOURCE":str(apath.relative_to(root)).replace("\\","/"),
        "STAGE6D4A3_BLOCK_LINEAGE_READY":ready,
        "STAGE6D4B_EXACT_PRODUCTION_FITS_READY":ready
    }
    wj(out/"validation/stage6d4a3_validation.json",val)
    wj(out/"summaries/stage6d4a3_summary.json",{
        "ready":ready,"block_count":block_count,
        "next_action":"Run D4B exact production fits from the augmented source." if ready else "Inspect failed block-lineage gate; D4B remains blocked."
    })
    print(json.dumps({"validation":val},indent=2))
    return 0

if __name__=="__main__": raise SystemExit(main())
