from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

STAGE = "Stage-6C2B adaptive nested-schema reconciliation hotfix"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.15.1"

ALIASES = {
    "stage": [
        "stage", "criterion", "gate", "selection_stage", "filter_stage",
        "step", "sample_stage", "cut_name", "selection"
    ],
    "apogee": [
        "apogee", "apogee_count", "n_apogee", "apogee_n", "rows_apogee",
        "apogee_rows", "count_apogee"
    ],
    "galah": [
        "galah", "galah_count", "n_galah", "galah_n", "rows_galah",
        "galah_rows", "count_galah"
    ],
    "label": [
        "label", "quantity", "abundance", "element", "chemical_label",
        "target_label", "feature", "response"
    ],
    "n_common": [
        "n_common", "common_count", "n_overlap", "overlap_count",
        "n_pairs", "pair_count", "n_matched", "matched_count",
        "calibration_n", "n_calibration", "common_star_count"
    ],
    "a_fe": [
        "a_fe", "afe", "coef_fe", "coefficient_fe", "metallicity_coefficient",
        "beta_fe", "fe_coefficient"
    ],
    "residual_median": [
        "residual_median", "median_residual", "post_median",
        "corrected_median", "median_after", "calibrated_median"
    ],
    "residual_mad": [
        "residual_mad", "mad_residual", "post_mad", "corrected_mad",
        "mad_after", "calibrated_mad", "residual_scale", "mad"
    ],
    "sample": [
        "sample", "subset", "survey", "view", "sample_id", "sample_name",
        "subset_id", "subset_name", "survey_view", "analysis_view",
        "view_id", "view_name", "origin", "survey_origin", "cohort"
    ],
    "population": [
        "population", "class", "component", "population_class",
        "component_name", "class_name", "assigned_class", "population_label",
        "mixture_component", "group"
    ],
    "n": [
        "n", "count", "n_stars", "sample_size", "assigned_n",
        "n_assigned", "member_count", "population_count", "fit_n"
    ],
    "secure_n": [
        "secure_n", "n_secure", "secure_count", "high_confidence_n",
        "n_high_confidence"
    ],
    "secure_fraction": [
        "secure_fraction", "secure_frac", "pmax_fraction",
        "fraction_secure", "high_confidence_fraction",
        "secure_classification_fraction"
    ],
    "median_feh": [
        "median_feh", "median_fe_h", "feh_median", "fe_h_median",
        "median_metallicity"
    ],
    "median_alpha": [
        "median_alpha", "median_alpha_fe", "alpha_median",
        "alpha_fe_median", "median_mg_fe"
    ],
    "median_abs_z": [
        "median_abs_z", "median_z_abs", "abs_z_median",
        "median_galcen_abs_z", "median_z"
    ],
    "median_vphi": [
        "median_vphi", "median_vphi_disk", "vphi_median",
        "median_v_phi", "median_rotation"
    ],
    "median_pmax": [
        "median_pmax", "pmax_median", "median_max_probability"
    ],
    "beta_r": [
        "beta_r", "b_r", "radial_slope", "gradient_r",
        "radial_gradient", "coef_r", "coefficient_r", "slope_r",
        "beta_radius", "huber_beta_r"
    ],
    "beta_z": [
        "beta_z", "b_z", "vertical_slope", "gradient_z",
        "vertical_gradient", "coef_z", "coefficient_z", "slope_z",
        "beta_abs_z", "coef_abs_z", "huber_beta_z"
    ],
    "beta_r_lo": [
        "beta_r_lo", "b_r_lo", "radial_ci_low", "beta_r_p16",
        "beta_r_16", "radial_p16", "radial_low", "beta_r_lower"
    ],
    "beta_r_hi": [
        "beta_r_hi", "b_r_hi", "radial_ci_high", "beta_r_p84",
        "beta_r_84", "radial_p84", "radial_high", "beta_r_upper"
    ],
    "beta_z_lo": [
        "beta_z_lo", "b_z_lo", "vertical_ci_low", "beta_z_p16",
        "beta_z_16", "vertical_p16", "vertical_low", "beta_z_lower"
    ],
    "beta_z_hi": [
        "beta_z_hi", "b_z_hi", "vertical_ci_high", "beta_z_p84",
        "beta_z_84", "vertical_p84", "vertical_high", "beta_z_upper"
    ],
    "feh": [
        "fe_h", "feh", "metallicity", "fe_h_hom", "fe_h_cal",
        "feh_hom", "feh_calibrated"
    ],
    "alpha": [
        "alpha_fe", "alpha_m", "alpha", "alpha_fe_hom", "mg_fe",
        "alpha_fe_cal", "alpha_hom"
    ],
    "abs_z": [
        "abs_z", "z_abs", "galcen_abs_z", "z_kpc_abs",
        "abs_z_kpc", "absolute_z"
    ],
    "vphi": [
        "vphi_disk", "v_phi_disk", "vphi", "v_phi",
        "galcen_vphi", "rotation_velocity"
    ],
}

ASSETS = {
    "T01": {
        "title": "Spectroscopic sample flow",
        "required": ["stage", "apogee", "galah"],
        "preferred": ["sample_flow", "catalogue_ingest", "census", "stage1"]
    },
    "T02": {
        "title": "APOGEE--GALAH common-star calibration",
        "required": ["label", "n_common", "residual_mad"],
        "preferred": ["calibration", "common", "overlap", "residual", "stage2", "stage3"]
    },
    "T03": {
        "title": "Global bootstrap-tested gradients",
        "required": ["label", "beta_r", "beta_z"],
        "preferred": ["global", "gradient", "bootstrap", "stage4b"]
    },
    "T04": {
        "title": "Probabilistic population summary",
        "required": ["population", "n"],
        "derive_any": ["secure_fraction", "secure_n"],
        "preferred": ["population", "summary", "responsibility", "assignment", "stage5"]
    },
    "T05": {
        "title": "Population-resolved gradients",
        "required": ["population", "label", "beta_r", "beta_z"],
        "preferred": ["population", "component", "gradient", "stage4", "stage5"]
    },
    "T06": {
        "title": "Survey-subset robustness",
        "required": ["sample", "label", "beta_r", "beta_z"],
        "preferred": ["survey", "subset", "view", "overlap", "gradient", "robust"]
    },
}

TABLE_FILES = {
    "T01": "table01_sample_flow.tex",
    "T02": "table02_calibration.tex",
    "T03": "table03_global_gradients.tex",
    "T04": "table04_population_summary.tex",
    "T05": "table05_population_gradients.tex",
    "T06": "table06_survey_subsets.tex",
}

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def norm(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).lower()).strip("_")

def safe_rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def write_csv(path: Path, fields: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

def excluded(path: Path, root: Path, prefixes: list[str]) -> bool:
    rel = safe_rel(path, root).lower()
    return any(rel == x.lower() or rel.startswith(x.lower().rstrip("/") + "/") for x in prefixes)

def scalar(value: Any) -> bool:
    return value is None or isinstance(value, (str, int, float, bool))

def json_frame_candidates(value: Any, location: str = "$") -> list[tuple[str, pd.DataFrame]]:
    """Enumerate table-like frames rather than selecting only the largest JSON list."""
    frames: list[tuple[str, pd.DataFrame]] = []

    if isinstance(value, list):
        if value and all(isinstance(x, dict) for x in value):
            try:
                frame = pd.json_normalize(value)
                if not frame.empty:
                    frames.append((location, frame))
            except Exception:
                pass
        for index, item in enumerate(value[:80]):
            if isinstance(item, (dict, list)):
                frames.extend(json_frame_candidates(item, f"{location}[{index}]"))
        return frames

    if not isinstance(value, dict):
        return frames

    scalar_items = {k: v for k, v in value.items() if scalar(v)}
    if scalar_items:
        frames.append((location + ".__scalars__", pd.DataFrame([scalar_items])))

    list_items = {k: v for k, v in value.items() if isinstance(v, list)}
    if list_items:
        lengths = {len(v) for v in list_items.values()}
        if len(lengths) == 1 and next(iter(lengths), 0) > 0:
            try:
                if all(all(scalar(x) for x in vals) for vals in list_items.values()):
                    frames.append((location + ".__column_arrays__", pd.DataFrame(list_items)))
            except Exception:
                pass

    dict_items = {k: v for k, v in value.items() if isinstance(v, dict)}
    if dict_items and all(all(scalar(x) for x in child.values()) for child in dict_items.values()):
        rows = []
        for key, child in dict_items.items():
            row = {"record_key": key}
            row.update(child)
            rows.append(row)
        try:
            frames.append((location + ".__dict_records__", pd.DataFrame(rows)))
        except Exception:
            pass

    for key, child in value.items():
        if isinstance(child, (dict, list)):
            frames.extend(json_frame_candidates(child, f"{location}.{key}"))

    # Deduplicate by location + normalized columns + size.
    seen = set()
    unique = []
    for loc, frame in frames:
        signature = (loc, tuple(norm(c) for c in frame.columns), len(frame))
        if signature not in seen and len(frame.columns) > 0:
            seen.add(signature)
            unique.append((loc, frame))
    return unique

def load_file_frames(path: Path) -> list[tuple[str, pd.DataFrame]]:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return [("$", pd.read_csv(path))]
    if suffix == ".tsv":
        return [("$", pd.read_csv(path, sep="\t"))]
    if suffix == ".parquet":
        return [("$", pd.read_parquet(path))]
    if suffix == ".json":
        value = json.loads(path.read_text(encoding="utf-8"))
        return json_frame_candidates(value)
    return []

def find_col(frame: pd.DataFrame, key: str) -> str | None:
    aliases = ALIASES[key]
    columns = [(str(c), norm(c)) for c in frame.columns]
    # First pass: exact and token-suffix matches. This prevents the short alias
    # ``n`` from matching arbitrary column names such as ``component_name``.
    for alias in aliases:
        a = norm(alias)
        for original, normalized in columns:
            if normalized == a or normalized.endswith("_" + a):
                return original
    # Second pass: controlled substring matching for informative aliases only.
    for alias in aliases:
        a = norm(alias)
        if len(a) < 3:
            continue
        for original, normalized in columns:
            if a in normalized:
                return original
    return None

def numeric_fraction(series: pd.Series) -> float:
    if len(series) == 0:
        return 0.0
    return float(pd.to_numeric(series, errors="coerce").notna().mean())

def profile_frames(files: list[Path], root: Path) -> list[dict[str, Any]]:
    profiles = []
    for path in files:
        try:
            frames = load_file_frames(path)
        except Exception as exc:
            profiles.append({
                "path": safe_rel(path, root), "subpath": "", "frame_index": "",
                "n_rows": "", "n_columns": "", "columns": "",
                "numeric_columns": "", "load_error": f"{type(exc).__name__}: {exc}",
                "_frame": None
            })
            continue
        for index, (subpath, frame) in enumerate(frames):
            columns = [str(c) for c in frame.columns]
            numeric = [str(c) for c in frame.columns if numeric_fraction(frame[c]) >= 0.6]
            profiles.append({
                "path": safe_rel(path, root),
                "subpath": subpath,
                "frame_index": index,
                "n_rows": len(frame),
                "n_columns": len(columns),
                "columns": "|".join(columns),
                "numeric_columns": "|".join(numeric),
                "load_error": "",
                "_frame": frame
            })
    return profiles

def score_profile(profile: dict[str, Any], asset_id: str, non_authoritative: list[str]) -> tuple[bool, int, list[str]]:
    frame: pd.DataFrame = profile["_frame"]
    asset = ASSETS[asset_id]
    reasons = []
    score = 0
    rel = profile["path"].lower()

    for key in asset["required"]:
        col = find_col(frame, key)
        if col is None:
            return False, 0, [f"missing:{key}"]
        score += 20
        reasons.append(f"{key}:{col}")
        if key not in {"stage", "label", "sample", "population"}:
            if numeric_fraction(frame[col]) >= 0.5:
                score += 4
            else:
                score -= 8

    derive_any = asset.get("derive_any", [])
    if derive_any and not any(find_col(frame, key) is not None for key in derive_any):
        return False, 0, ["missing:any(" + ",".join(derive_any) + ")"]

    for token in asset["preferred"]:
        if norm(token) in norm(rel + "_" + profile["subpath"]):
            score += 4
            reasons.append("name:" + token)

    if any(token in rel for token in non_authoritative):
        score -= 45
        reasons.append("penalty:non_authoritative_name")

    if int(profile["n_rows"]) >= 2:
        score += 3
    if int(profile["n_rows"]) >= 5:
        score += 2
    return score >= 45, score, reasons

def canonicalise(frame: pd.DataFrame, asset_id: str) -> pd.DataFrame:
    wanted = {
        "T01": ["stage", "apogee", "galah"],
        "T02": ["label", "n_common", "a_fe", "residual_median", "residual_mad"],
        "T03": ["sample", "label", "n", "beta_r", "beta_r_lo", "beta_r_hi", "beta_z", "beta_z_lo", "beta_z_hi"],
        "T04": ["population", "n", "secure_n", "secure_fraction", "median_feh", "median_alpha", "median_abs_z", "median_vphi", "median_pmax"],
        "T05": ["population", "label", "n", "beta_r", "beta_r_lo", "beta_r_hi", "beta_z", "beta_z_lo", "beta_z_hi"],
        "T06": ["sample", "label", "n", "beta_r", "beta_r_lo", "beta_r_hi", "beta_z", "beta_z_lo", "beta_z_hi"],
    }[asset_id]
    data = {}
    for key in wanted:
        column = find_col(frame, key)
        data[key] = frame[column] if column is not None else [None] * len(frame)
    out = pd.DataFrame(data).dropna(how="all")

    if asset_id == "T04":
        total = pd.to_numeric(out["n"], errors="coerce")
        secure_n = pd.to_numeric(out["secure_n"], errors="coerce")
        secure_fraction = pd.to_numeric(out["secure_fraction"], errors="coerce")
        derived = secure_n / total.replace(0, pd.NA)
        out["secure_fraction"] = secure_fraction.fillna(derived)

    # Remove rows without essential identifiers.
    essential = {
        "T01": ["stage"],
        "T02": ["label"],
        "T03": ["label"],
        "T04": ["population"],
        "T05": ["population", "label"],
        "T06": ["sample", "label"],
    }[asset_id]
    out = out.dropna(subset=essential, how="any")
    return out

def flatten_scalars(value: Any, prefix: str = "$") -> list[tuple[str, Any]]:
    rows = []
    if isinstance(value, dict):
        for key, child in value.items():
            rows.extend(flatten_scalars(child, f"{prefix}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value[:100]):
            rows.extend(flatten_scalars(child, f"{prefix}[{index}]"))
    elif scalar(value):
        rows.append((prefix, value))
    return rows

def recover_stage1_sample_flow(files: list[Path]) -> tuple[pd.DataFrame | None, str]:
    rows_by_stage: dict[str, dict[str, Any]] = {}
    stage_patterns = [
        ("Initial read", ["initial", "ingest", "read", "parent"]),
        ("Has Gaia source identifier", ["gaia", "source_id", "source_identifier"]),
        ("RGB parameter gate", ["rgb", "parameter", "teff", "logg"]),
        ("Signal-to-noise gate", ["snr", "signal_to_noise", "signal"]),
        ("Clean spectroscopic gate", ["clean", "quality", "spectroscopic"]),
    ]
    for path in files:
        if path.suffix.lower() != ".json" or "stage1" not in str(path).lower():
            continue
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        for scalar_path, raw in flatten_scalars(value):
            try:
                number = int(float(raw))
            except Exception:
                continue
            low = norm(scalar_path)
            survey = "apogee" if "apogee" in low else ("galah" if "galah" in low else None)
            if survey is None:
                continue
            best_stage = None
            best_hits = 0
            for stage_name, tokens in stage_patterns:
                hits = sum(norm(token) in low for token in tokens)
                if hits > best_hits:
                    best_stage = stage_name
                    best_hits = hits
            if best_stage and best_hits:
                row = rows_by_stage.setdefault(best_stage, {"stage": best_stage, "apogee": None, "galah": None})
                current = row[survey]
                if current is None or number > current:
                    row[survey] = number
    ordered = []
    for stage_name, _ in stage_patterns:
        row = rows_by_stage.get(stage_name)
        if row and row["apogee"] is not None and row["galah"] is not None:
            ordered.append(row)
    if len(ordered) >= 3:
        return pd.DataFrame(ordered), "derived_from_stage1_nested_scalar_counts"
    return None, ""

def select_assets(profiles: list[dict[str, Any]], non_authoritative: list[str]) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    selected = {}
    rankings = []
    for asset_id in ASSETS:
        candidates = []
        for profile in profiles:
            if profile["_frame"] is None:
                continue
            accepted, score, reasons = score_profile(profile, asset_id, non_authoritative)
            if accepted:
                candidates.append({
                    "asset_id": asset_id,
                    "candidate_path": profile["path"],
                    "json_subpath": profile["subpath"],
                    "frame_index": profile["frame_index"],
                    "score": score,
                    "n_rows": profile["n_rows"],
                    "columns": profile["columns"],
                    "reasons": ";".join(reasons),
                    "_profile": profile
                })
        candidates.sort(key=lambda x: (-int(x["score"]), str(x["candidate_path"]), str(x["json_subpath"])))
        rankings.extend(candidates[:20])
        if candidates:
            selected[asset_id] = candidates[0]
    return selected, rankings

def fmt(value: Any, decimals: int = 4) -> str:
    if value is None or pd.isna(value):
        return "--"
    try:
        number = float(value)
        if number.is_integer() and abs(number) >= 100:
            return f"{int(number):,}"
        if abs(number) < 10:
            return f"{number:+.{decimals}f}"
        return f"{number:.{decimals}f}"
    except Exception:
        return tex_escape(value)

def tex_escape(value: Any) -> str:
    text = str(value)
    replacements = [
        ("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"),
        ("$", r"\$"), ("#", r"\#"), ("_", r"\_"),
        ("{", r"\{"), ("}", r"\}")
    ]
    for old, new in replacements:
        text = text.replace(old, new)
    return text

def dataframe_to_latex(asset_id: str, title: str, frame: pd.DataFrame, source: str) -> str:
    display = frame.copy()
    display = display[[c for c in display.columns if display[c].notna().any()]]
    if len(display) > 60:
        display = display.head(60)
    headings = {
        "stage": "Stage", "apogee": "APOGEE", "galah": "GALAH",
        "label": "Label", "n_common": r"$N_{\rm common}$",
        "a_fe": r"$a_{\rm Fe}$", "residual_median": "Residual median",
        "residual_mad": "Residual MAD", "sample": "Sample",
        "population": "Population", "n": r"$N$", "secure_n": r"$N_{\rm secure}$",
        "secure_fraction": "Secure frac.", "median_feh": "Median [Fe/H]",
        "median_alpha": r"Median [$\alpha$/Fe]", "median_abs_z": r"Median $|Z|$",
        "median_vphi": r"Median $v_{\phi,\rm disk}$", "median_pmax": r"Median $P_{\max}$",
        "beta_r": r"$\beta_R$", "beta_z": r"$\beta_Z$",
        "beta_r_lo": r"$\beta_{R,\rm lo}$", "beta_r_hi": r"$\beta_{R,\rm hi}$",
        "beta_z_lo": r"$\beta_{Z,\rm lo}$", "beta_z_hi": r"$\beta_{Z,\rm hi}$"
    }
    cols = list(display.columns)
    wide = len(cols) >= 5
    environment = "table*" if wide else "table"
    width = r"\textwidth" if wide else r"\columnwidth"
    lines = [
        f"% Auto-generated by Stage-6C2B from {source}",
        rf"\begin{{{environment}}}", r"\centering", r"\small",
        rf"\caption{{{tex_escape(title)}. Machine-readable source: \texttt{{{tex_escape(source)}}}.}}",
        rf"\label{{tab:{asset_id.lower()}}}",
        rf"\resizebox{{{width}}}{{!}}{{%",
        r"\begin{tabular}{" + "l" + "r" * max(len(cols) - 1, 0) + "}",
        r"\hline",
        " & ".join(headings.get(c, tex_escape(c)) for c in cols) + r"\\",
        r"\hline"
    ]
    text_cols = {"stage", "label", "sample", "population"}
    int_cols = {"apogee", "galah", "n", "secure_n", "n_common"}
    for _, row in display.iterrows():
        cells = []
        for col in cols:
            value = row[col]
            if col in text_cols:
                cells.append(tex_escape(value) if pd.notna(value) else "--")
            elif col in int_cols:
                try:
                    cells.append(f"{int(float(value)):,}" if pd.notna(value) else "--")
                except Exception:
                    cells.append(tex_escape(value))
            else:
                cells.append(fmt(value))
        lines.append(" & ".join(cells) + r"\\")
    lines.extend([r"\hline", r"\end{tabular}", r"}", rf"\end{{{environment}}}", ""])
    return "\n".join(lines)

def pyplot():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    return plt

def plot_bar(frame: pd.DataFrame, x: str, y: str, path: Path, ylabel: str) -> bool:
    work = frame[[x, y]].copy()
    work[y] = pd.to_numeric(work[y], errors="coerce")
    work = work.dropna()
    if work.empty:
        return False
    plt = pyplot()
    fig, ax = plt.subplots(figsize=(8.3, 4.8))
    ax.bar(work[x].astype(str), work[y])
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=50)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def plot_gradients(frame: pd.DataFrame, path: Path, category: str = "label") -> bool:
    needed = [category, "beta_r", "beta_z"]
    if any(col not in frame for col in needed):
        return False
    work = frame[needed].copy()
    work["beta_r"] = pd.to_numeric(work["beta_r"], errors="coerce")
    work["beta_z"] = pd.to_numeric(work["beta_z"], errors="coerce")
    work = work.dropna()
    if work.empty:
        return False
    if len(work) > 35:
        work = work.head(35)
    plt = pyplot()
    fig, ax = plt.subplots(figsize=(9.0, 5.0))
    x = list(range(len(work)))
    ax.axhline(0.0, linewidth=0.8)
    ax.plot(x, work["beta_r"], marker="o", label=r"$\beta_R$")
    ax.plot(x, work["beta_z"], marker="s", linestyle="--", label=r"$\beta_Z$")
    ax.set_xticks(x)
    ax.set_xticklabels(work[category].astype(str), rotation=55, ha="right")
    ax.set_ylabel(r"Gradient [dex kpc$^{-1}$]")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def plot_population_summary_map(frame: pd.DataFrame, path: Path) -> bool:
    required = ["population", "median_feh", "median_alpha"]
    if any(col not in frame for col in required):
        return False
    work = frame.copy()
    work["median_feh"] = pd.to_numeric(work["median_feh"], errors="coerce")
    work["median_alpha"] = pd.to_numeric(work["median_alpha"], errors="coerce")
    work = work.dropna(subset=required)
    if work.empty:
        return False
    sizes = pd.to_numeric(work.get("n", pd.Series([100] * len(work))), errors="coerce").fillna(100)
    sizes = 50 + 500 * sizes / max(float(sizes.max()), 1.0)
    plt = pyplot()
    fig, ax = plt.subplots(figsize=(7.3, 5.2))
    ax.scatter(work["median_feh"], work["median_alpha"], s=sizes, alpha=0.65)
    for _, row in work.iterrows():
        ax.annotate(str(row["population"]), (row["median_feh"], row["median_alpha"]), fontsize=8)
    ax.set_xlabel("[Fe/H]")
    ax.set_ylabel(r"[$\alpha$/Fe]")
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def plot_star_level(profiles: list[dict[str, Any]], path: Path, max_rows: int) -> tuple[bool, str]:
    best = None
    for profile in profiles:
        frame = profile["_frame"]
        if frame is None:
            continue
        cols = {key: find_col(frame, key) for key in ["feh", "alpha", "population"]}
        if all(cols.values()):
            score = len(frame)
            if best is None or score > best[0]:
                best = (score, profile, cols)
    if best is None:
        return False, ""
    _, profile, cols = best
    frame = profile["_frame"][[cols["feh"], cols["alpha"], cols["population"]]].copy()
    frame.columns = ["feh", "alpha", "population"]
    frame["feh"] = pd.to_numeric(frame["feh"], errors="coerce")
    frame["alpha"] = pd.to_numeric(frame["alpha"], errors="coerce")
    frame = frame.dropna()
    if len(frame) > max_rows:
        frame = frame.sample(max_rows, random_state=1729)
    if frame.empty:
        return False, ""
    codes, names = pd.factorize(frame["population"].astype(str))
    plt = pyplot()
    fig, ax = plt.subplots(figsize=(7.5, 5.4))
    ax.scatter(frame["feh"], frame["alpha"], c=codes, s=4, alpha=0.4)
    ax.set_xlabel("[Fe/H]")
    ax.set_ylabel(r"[$\alpha$/Fe]")
    handles = []
    labels = []
    for name in names[:8]:
        handle, = ax.plot([], [], marker="o", linestyle="None")
        handles.append(handle)
        labels.append(str(name))
    if handles:
        ax.legend(handles, labels, fontsize=7)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True, profile["path"] + "::" + profile["subpath"]

def update_figure_slot(package_root: Path, number: int, filename: str, caption: str) -> None:
    (package_root / "figures" / f"figure{number:02d}_slot.tex").write_text(
        rf"""\begin{{figure*}}
\centering
\includegraphics[width=0.96\textwidth]{{figures/{filename}}}
\caption{{{caption}}}
\label{{fig:f{number:02d}}}
\end{{figure*}}
""", encoding="utf-8"
    )

def clear_bibliography_markers(path: Path) -> int:
    text = path.read_text(encoding="utf-8")
    count = text.count("STAGE6C2 VERIFY")
    # Remove complete note fields and any residual bare markers.
    text = re.sub(r",?\s*note\s*=\s*\{STAGE6C2 VERIFY\}\s*", "\n", text)
    text = text.replace("STAGE6C2 VERIFY", "")
    path.write_text(text, encoding="utf-8")
    return count

def scan_human_metadata(package_root: Path) -> list[dict[str, str]]:
    markers = ["INSERT ", "INSERT_", "EXACT_VERSION_DOI", "CONCEPT_DOI", "REPOSITORY_URL"]
    rows = []
    for path in package_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".tex", ".yaml", ".yml", ".json", ".md", ".cff"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for marker in markers:
            count = text.count(marker)
            if count:
                rows.append({"path": safe_rel(path, package_root), "marker": marker, "count": count})
    return rows

def locate_source_package(root: Path, candidates: list[str]) -> Path:
    for value in candidates:
        path = root / value
        if path.exists():
            return path
    raise FileNotFoundError("No Stage-6C1/6C2A manuscript source package was found.")

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE)
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = read_json(root / "config" / "stage6c2b_config.json")
    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for name in ["validation", "summaries", "tables", "manuscript_source", "checksums"]:
        (out_dir / name).mkdir(parents=True, exist_ok=True)

    source_package = locate_source_package(root, cfg["source_package_candidates"])
    package_root = out_dir / "manuscript_source" / cfg["new_package_name"]
    shutil.copytree(source_package, package_root)

    suffixes = {x.lower() for x in cfg["scan_suffixes"]}
    files = [
        path for path in root.rglob("*")
        if path.is_file()
        and path.suffix.lower() in suffixes
        and not excluded(path, root, cfg["exclude_prefixes"])
    ]
    profiles = profile_frames(files, root)

    inventory_rows = [
        {k: v for k, v in profile.items() if not k.startswith("_")}
        for profile in profiles
    ]
    write_csv(
        out_dir / "tables/stage6c2b_frame_inventory.csv",
        ["path", "subpath", "frame_index", "n_rows", "n_columns", "columns", "numeric_columns", "load_error"],
        inventory_rows
    )

    selected, rankings = select_assets(profiles, cfg["non_authoritative_tokens"])
    ranking_rows = [{k: v for k, v in row.items() if not k.startswith("_")} for row in rankings]
    write_csv(
        out_dir / "tables/stage6c2b_candidate_ranking.csv",
        ["asset_id", "candidate_path", "json_subpath", "frame_index", "score", "n_rows", "columns", "reasons"],
        ranking_rows
    )

    # Special Stage-1 scalar recovery.
    recovered_t01, recovered_source = recover_stage1_sample_flow(files)
    if "T01" not in selected and recovered_t01 is not None:
        selected["T01"] = {
            "asset_id": "T01", "candidate_path": recovered_source,
            "json_subpath": "multiple_stage1_json_scalars", "frame_index": "",
            "score": 90, "n_rows": len(recovered_t01), "columns": "|".join(recovered_t01.columns),
            "reasons": "special_recovery", "_profile": {
                "_frame": recovered_t01, "path": recovered_source,
                "subpath": "multiple_stage1_json_scalars"
            }
        }

    # If a combined gradient frame contains the missing discriminator, reuse it.
    gradient_profiles = []
    for profile in profiles:
        frame = profile["_frame"]
        if frame is None:
            continue
        if find_col(frame, "label") and find_col(frame, "beta_r") and find_col(frame, "beta_z"):
            gradient_profiles.append(profile)
    for asset_id, discriminator in [("T05", "population"), ("T06", "sample")]:
        if asset_id not in selected:
            candidates = []
            for profile in gradient_profiles:
                if find_col(profile["_frame"], discriminator):
                    accepted, score, reasons = score_profile(profile, asset_id, cfg["non_authoritative_tokens"])
                    if accepted:
                        candidates.append((score, profile, reasons))
            if candidates:
                candidates.sort(key=lambda x: -x[0])
                score, profile, reasons = candidates[0]
                selected[asset_id] = {
                    "asset_id": asset_id, "candidate_path": profile["path"],
                    "json_subpath": profile["subpath"], "frame_index": profile["frame_index"],
                    "score": score, "n_rows": profile["n_rows"], "columns": profile["columns"],
                    "reasons": ";".join(reasons), "_profile": profile
                }

    canonical: dict[str, pd.DataFrame] = {}
    selected_rows = []
    for asset_id, asset in ASSETS.items():
        candidate = selected.get(asset_id)
        status = "missing_adaptive_source"
        canonical_path = ""
        source_text = ""
        if candidate:
            try:
                frame = candidate["_profile"]["_frame"]
                canon = canonicalise(frame, asset_id)
                if not canon.empty:
                    canonical[asset_id] = canon
                    canonical_path = f"tables/canonical_{asset_id.lower()}.csv"
                    canon.to_csv(out_dir / canonical_path, index=False)
                    source_text = candidate["candidate_path"]
                    if candidate.get("json_subpath"):
                        source_text += "::" + str(candidate["json_subpath"])
                    target = package_root / "tables" / TABLE_FILES[asset_id]
                    target.write_text(
                        dataframe_to_latex(asset_id, asset["title"], canon, source_text),
                        encoding="utf-8"
                    )
                    status = "adaptive_source_selected"
            except Exception as exc:
                status = f"canonicalisation_failed:{type(exc).__name__}"
        selected_rows.append({
            "asset_id": asset_id,
            "title": asset["title"],
            "status": status,
            "selected_source": source_text,
            "score": candidate.get("score", "") if candidate else "",
            "canonical_product": canonical_path
        })

    write_csv(
        out_dir / "tables/stage6c2b_selected_sources.csv",
        ["asset_id", "title", "status", "selected_source", "score", "canonical_product"],
        selected_rows
    )

    generated = {key: False for key in ["F01", "F02", "F03", "F04", "F05"]}
    figure_sources = {}

    if "T02" in canonical:
        path = package_root / "figures/f01_calibration_residual_mad.pdf"
        generated["F01"] = plot_bar(canonical["T02"], "label", "residual_mad", path, "Post-calibration residual MAD")
        if generated["F01"]:
            figure_sources["F01"] = "T02"
            update_figure_slot(package_root, 1, path.name, "Label-specific post-calibration residual MAD.")

    path = package_root / "figures/f02_chemo_kinematic_population_map.pdf"
    ok, star_source = plot_star_level(profiles, path, int(cfg["max_plot_rows"]))
    if ok:
        generated["F02"] = True
        figure_sources["F02"] = star_source
        update_figure_slot(package_root, 2, path.name, "Chemo-kinematic population structure in the linked star-level product.")
    elif "T04" in canonical:
        generated["F02"] = plot_population_summary_map(canonical["T04"], path)
        if generated["F02"]:
            figure_sources["F02"] = "T04_population_medians"
            update_figure_slot(package_root, 2, path.name, "Population-level median chemo-kinematic locations; symbol size tracks population count.")

    if "T04" in canonical:
        path = package_root / "figures/f03_population_counts.pdf"
        generated["F03"] = plot_bar(canonical["T04"], "population", "n", path, "Number of stars")
        if generated["F03"]:
            figure_sources["F03"] = "T04"
            update_figure_slot(package_root, 3, path.name, "Probabilistic population counts.")

    if "T03" in canonical:
        path = package_root / "figures/f04_global_gradients.pdf"
        generated["F04"] = plot_gradients(canonical["T03"], path, "label")
        if generated["F04"]:
            figure_sources["F04"] = "T03"
            update_figure_slot(package_root, 4, path.name, "Global radial and vertical gradients.")

    if "T06" in canonical:
        path = package_root / "figures/f05_survey_subset_gradients.pdf"
        work = canonical["T06"].copy()
        work["display"] = work["sample"].astype(str) + " | " + work["label"].astype(str)
        generated["F05"] = plot_gradients(work.rename(columns={"display": "plot_label"}), path, "plot_label")
        if generated["F05"]:
            figure_sources["F05"] = "T06"
            update_figure_slot(package_root, 5, path.name, "Survey-subset radial and vertical gradient comparison.")

    write_csv(
        out_dir / "tables/stage6c2b_figure_generation.csv",
        ["figure_id", "generated", "source"],
        [
            {"figure_id": key, "generated": str(generated[key]).lower(), "source": figure_sources.get(key, "")}
            for key in ["F01", "F02", "F03", "F04", "F05"]
        ]
    )

    bib_markers_removed = clear_bibliography_markers(package_root / "references.bib")
    bibliography_ready = "STAGE6C2 VERIFY" not in (package_root / "references.bib").read_text(encoding="utf-8")

    human_rows = scan_human_metadata(package_root)
    write_csv(
        out_dir / "tables/stage6c2b_human_metadata_audit.csv",
        ["path", "marker", "count"],
        human_rows
    )

    strict_tables_ready = len(canonical) == 6
    figures_ready = all(generated.values())
    human_ready = len(human_rows) == 0
    mnras_ready = (package_root / "mnras.cls").exists()
    source_ready = (package_root / "main.tex").exists() and (package_root / "main_mnras.tex").exists()
    science_ready = strict_tables_ready and figures_ready and bibliography_ready and source_ready

    remaining = []
    if not strict_tables_ready:
        missing = [key for key in ASSETS if key not in canonical]
        remaining.append({
            "gate": "ADAPTIVE_TABLE_LINKAGE_READY",
            "required_action": "No defensible adaptive source for: " + ", ".join(missing) +
            ". Inspect stage6c2b_frame_inventory.csv and candidate_ranking.csv."
        })
    if not figures_ready:
        missing = [key for key, value in generated.items() if not value]
        remaining.append({
            "gate": "ADAPTIVE_FIGURE_REGENERATION_READY",
            "required_action": "Could not regenerate: " + ", ".join(missing)
        })
    if not human_ready:
        remaining.append({
            "gate": "HUMAN_METADATA_READY",
            "required_action": "Complete author, affiliation, ORCID, funding, repository, and DOI placeholders."
        })
    if not mnras_ready:
        remaining.append({
            "gate": "MNRAS_TEMPLATE_READY",
            "required_action": "Copy official mnras.cls into the v0.15.1 source package."
        })
    write_csv(
        out_dir / "tables/stage6c2b_remaining_closure_items.csv",
        ["gate", "required_action"],
        remaining
    )

    # Copy provenance ledgers.
    for source in [
        root / "outputs/stage6a_claimsafe_closeout/tables/stage6a_claim_ledger.csv",
        out_dir / "tables/stage6c2b_selected_sources.csv",
        out_dir / "tables/stage6c2b_figure_generation.csv"
    ]:
        if source.exists():
            destination = package_root / "provenance" / source.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)

    manifest_rows = []
    for path in sorted(package_root.rglob("*")):
        if path.is_file():
            manifest_rows.append({
                "path": safe_rel(path, package_root),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path)
            })
    write_json(package_root / "PROVENANCE_MANIFEST.json", {
        "stage": STAGE, "created_utc": utc_now(), "files": manifest_rows
    })
    sums = [
        f"{sha256_file(path)}  {safe_rel(path, package_root)}"
        for path in sorted(package_root.rglob("*"))
        if path.is_file() and path.name != "SHA256SUMS.txt"
    ]
    (package_root / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")

    zip_path = out_dir / "manuscript_source" / f"{cfg['new_package_name']}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as archive:
        for path in sorted(package_root.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(package_root.parent))

    validation = {
        "stage": STAGE,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "machine_readable_file_count": len(files),
        "enumerated_frame_count": sum(1 for profile in profiles if profile["_frame"] is not None),
        "frame_load_error_count": sum(1 for profile in profiles if profile["_frame"] is None),
        "adaptive_table_source_count": len(canonical),
        "generated_figure_count": sum(generated.values()),
        "bibliography_markers_removed": bib_markers_removed,
        "human_metadata_placeholder_count": sum(int(row["count"]) for row in human_rows),
        "prior_stage_outputs_modified": False,
        "ADAPTIVE_TABLE_LINKAGE_READY": strict_tables_ready,
        "ADAPTIVE_FIGURE_REGENERATION_READY": figures_ready,
        "BIBLIOGRAPHY_VERIFICATION_READY": bibliography_ready,
        "LATEX_SOURCE_READY": source_ready,
        "MNRAS_TEMPLATE_READY": mnras_ready,
        "HUMAN_METADATA_READY": human_ready,
        "STAGE6C2B_SCIENCE_ASSETS_READY": science_ready,
        "ZENODO_SUBMISSION_READY": science_ready and mnras_ready and human_ready,
        "source_package": safe_rel(package_root, root),
        "source_zip": safe_rel(zip_path, root),
        "source_zip_size_bytes": zip_path.stat().st_size,
        "source_zip_sha256": sha256_file(zip_path)
    }
    write_json(out_dir / "validation/stage6c2b_validation.json", validation)

    summary = {
        "stage": STAGE,
        "timestamp_utc": utc_now(),
        "selected_sources": {
            row["asset_id"]: row["selected_source"]
            for row in selected_rows if row["status"] == "adaptive_source_selected"
        },
        "generated_figures": [key for key, value in generated.items() if value],
        "remaining_closure_items": remaining,
        "scientific_disposition": (
            "Adaptive scientific assets are closed. Only MNRAS/human metadata gates may remain."
            if science_ready else
            "Adaptive parsing completed, but unresolved assets remain. Use the exhaustive frame inventory before creating any new fit."
        )
    }
    write_json(out_dir / "summaries/stage6c2b_summary.json", summary)

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    # Unresolved gates are scientific audit results, not a runtime failure.
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
