from __future__ import annotations

import argparse
import copy
import csv
import json
import os
import re
import shutil
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import yaml


PACKAGE_ROOT = Path(__file__).resolve().parents[1]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8"
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def tree_manifest(root: Path, paths: list[str]) -> list[dict[str, Any]]:
    rows = []
    for rel in paths:
        base = root / rel
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file():
                continue
            stat = path.stat()
            rows.append({
                "path": safe_rel(path, root),
                "size_bytes": stat.st_size,
                "mtime_ns": stat.st_mtime_ns,
            })
    rows.sort(key=lambda row: row["path"])
    return rows


def patch_shadow_config(
    original: Any,
    shadow_output: str,
    shadow_log: str,
) -> tuple[Any, list[dict[str, Any]]]:
    patched = copy.deepcopy(original)
    audit = []

    def walk(value: Any, path: list[str]) -> None:
        if isinstance(value, dict):
            for key in list(value):
                current = path + [str(key)]
                lower = str(key).lower()
                if lower == "stage4a_output_dir":
                    audit.append({
                        "json_path": ".".join(current),
                        "action": "preserved",
                        "old_value": str(value[key]),
                        "new_value": str(value[key]),
                    })
                elif lower == "output_dir":
                    old = value[key]
                    value[key] = shadow_output
                    audit.append({
                        "json_path": ".".join(current),
                        "action": "redirected",
                        "old_value": str(old),
                        "new_value": shadow_output,
                    })
                elif lower == "log_dir":
                    old = value[key]
                    value[key] = shadow_log
                    audit.append({
                        "json_path": ".".join(current),
                        "action": "redirected",
                        "old_value": str(old),
                        "new_value": shadow_log,
                    })
                else:
                    walk(value[key], current)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, path + [str(index)])

    walk(patched, [])
    return patched, audit


def parse_trace(path: Path, root: Path) -> list[dict[str, Any]]:
    rows = []
    if not path.exists():
        return rows
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except Exception:
            continue
        raw = item.get("path", "")
        target = None
        if raw and raw not in {"__TARGET__", "__TRACE__"}:
            try:
                target = Path(raw)
            except Exception:
                target = None
        rows.append({
            "timestamp_utc": item.get("timestamp_utc", ""),
            "operation": item.get("operation", ""),
            "path": safe_rel(target, root) if target else raw,
            "absolute_path": raw if target else "",
            "exists_after_run": (
                str(target.exists()).lower() if target else ""
            ),
            "status": item.get("status", ""),
            "error": item.get("error", ""),
        })
    return rows


def expand_data_paths(
    paths: list[Path],
    suffixes: set[str],
) -> list[Path]:
    expanded = []
    for path in paths:
        if path.is_file() and path.suffix.lower() in suffixes:
            expanded.append(path.resolve())
        elif path.is_dir():
            for child in path.rglob("*"):
                if child.is_file() and child.suffix.lower() in suffixes:
                    expanded.append(child.resolve())
    return list(dict.fromkeys(expanded))


def read_columns(path: Path) -> tuple[list[str], int]:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        import pyarrow.parquet as pq
        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    if suffix == ".feather":
        import pyarrow.feather as feather
        table = feather.read_table(path)
        return list(table.column_names), int(table.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def read_table(path: Path, columns: list[str] | None = None) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path, columns=columns)
    if suffix == ".feather":
        return pd.read_feather(path, columns=columns)
    return pd.read_csv(path, usecols=columns)


def find_alias(columns: list[str], options: list[str]) -> str | None:
    lookup = {column.lower(): column for column in columns}
    for option in options:
        if option.lower() in lookup:
            return lookup[option.lower()]
    return None


def normalise_token(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def find_label_column(
    columns: list[str],
    label: str,
    variants: dict[str, list[str]],
) -> str | None:
    lookup = {normalise_token(column): column for column in columns}
    for candidate in variants[label]:
        token = normalise_token(candidate)
        if token in lookup:
            return lookup[token]
    approved_suffixes = {
        "corrected", "calibrated", "transported", "transport",
        "final", "common", "harmonized", "primary", "value"
    }
    bases = {
        normalise_token(value)
        for value in variants[label][:2]
    }
    for token, original in lookup.items():
        for base in bases:
            if token.startswith(base + "_"):
                suffix = token[len(base) + 1 :]
                if suffix in approved_suffixes:
                    return original
            if token.endswith("_" + base):
                prefix = token[: -(len(base) + 1)]
                if prefix in {"corrected", "calibrated", "final", "common"}:
                    return original
    return None


def infer_survey_from_path(
    path: Path,
    cfg: dict[str, Any],
) -> str | None:
    text = str(path).lower()
    apogee = any(
        token in text
        for token in cfg["survey_normalization"]["APOGEE_NATIVE"]
    )
    galah = any(
        token in text
        for token in cfg["survey_normalization"]["GALAH_CORRECTED"]
    )
    if apogee and not galah:
        return "APOGEE_NATIVE"
    if galah and not apogee:
        return "GALAH_CORRECTED"
    return None


def normalise_survey(
    series: pd.Series,
    cfg: dict[str, Any],
) -> pd.Series:
    result = pd.Series(pd.NA, index=series.index, dtype="string")
    lower = series.astype("string").str.lower()
    for canonical, tokens in cfg["survey_normalization"].items():
        mask = pd.Series(False, index=series.index)
        for token in tokens:
            mask |= lower.str.contains(
                token.lower(), na=False, regex=False
            )
        result.loc[mask] = canonical
    return result


def profile(path: Path, cfg: dict[str, Any]) -> dict[str, Any]:
    columns, row_count = read_columns(path)
    mapping = {
        field: find_alias(columns, aliases)
        for field, aliases in cfg["aliases"].items()
    }
    label_mapping = {
        label: find_label_column(
            columns, label, cfg["label_variants"]
        )
        for label in cfg["labels"]
    }
    return {
        "columns": columns,
        "row_count": row_count,
        "mapping": mapping,
        "label_mapping": label_mapping,
        "labels": [
            label for label, column in label_mapping.items()
            if column is not None
        ],
        "inferred_survey": infer_survey_from_path(path, cfg),
    }


def canonical_frame(
    path: Path,
    item: dict[str, Any],
    cfg: dict[str, Any],
) -> pd.DataFrame:
    mapping = item["mapping"]
    label_mapping = item["label_mapping"]
    needed = [
        mapping[field]
        for field in cfg["required_fields"] + ["distance_quality"]
        if mapping.get(field)
    ]
    needed += [
        label_mapping[label]
        for label in cfg["labels"]
        if label_mapping.get(label)
    ]
    needed = sorted(set(needed))
    frame = read_table(path, needed).copy()

    for field in cfg["required_fields"] + ["distance_quality"]:
        source = mapping.get(field)
        if source:
            frame[field] = frame[source]
    for label in cfg["labels"]:
        source = label_mapping.get(label)
        if source:
            frame[label] = pd.to_numeric(
                frame[source], errors="coerce"
            )

    if "survey" in frame.columns:
        frame["survey"] = normalise_survey(frame["survey"], cfg)
    elif item["inferred_survey"]:
        frame["survey"] = item["inferred_survey"]
    return frame


def collapse(
    frame: pd.DataFrame,
    survey_aware: bool,
) -> tuple[pd.DataFrame, int, list[str]]:
    work = frame.copy()
    work["source_id"] = pd.to_numeric(
        work["source_id"], errors="coerce"
    )
    work = work[work["source_id"].notna()].copy()
    work["source_id"] = work["source_id"].astype("uint64")
    keys = ["source_id"]
    if (
        survey_aware
        and "survey" in work.columns
        and work["survey"].notna().any()
    ):
        keys.append("survey")
    duplicates = int(work.duplicated(keys).sum())
    if duplicates:
        values = [column for column in work.columns if column not in keys]
        work = work.groupby(keys, as_index=False).agg({
            column: "first" for column in values
        })
    return work, duplicates, keys


def candidate_score(
    path: Path,
    frame: pd.DataFrame,
    traced: bool,
    cfg: dict[str, Any],
) -> float:
    path_text = str(path).lower()
    fields = sum(
        field in frame.columns and frame[field].notna().any()
        for field in cfg["required_fields"]
    )
    labels = sum(
        label in frame.columns and frame[label].notna().any()
        for label in cfg["labels"]
    )
    has_survey = (
        "survey" in frame.columns and frame["survey"].notna().any()
    )
    has_rz = all(
        field in frame.columns and frame[field].notna().any()
        for field in ["R", "Z"]
    )
    both_surveys = (
        has_survey
        and set(frame["survey"].dropna().astype(str))
        >= {"APOGEE_NATIVE", "GALAH_CORRECTED"}
    )
    return (
        5000 * int(traced)
        + 4000 * int("stage4a" in path_text)
        + 2500 * int(has_rz)
        + 1500 * int(has_survey)
        + 1000 * int(both_surveys)
        + 500 * int("production" in path_text)
        + 300 * labels
        + 30 * fields
        + min(len(frame), 2_000_000) / 2_000_000
    )


def coalesce(
    base: pd.DataFrame,
    addition: pd.DataFrame,
    fields: list[str],
    join_keys: list[str],
) -> tuple[pd.DataFrame, dict[str, int]]:
    candidate_fields = [
        field for field in fields
        if field not in join_keys and field in addition.columns
    ]
    before = {
        field: (
            int(base[field].notna().sum())
            if field in base.columns else 0
        )
        for field in fields
    }
    validate = (
        "one_to_one"
        if join_keys == ["source_id", "survey"]
        else "many_to_one"
    )
    joined = base.merge(
        addition[join_keys + candidate_fields],
        on=join_keys,
        how="left",
        suffixes=("", "__candidate"),
        validate=validate,
    )
    for field in candidate_fields:
        candidate = field + "__candidate"
        if field not in joined.columns:
            joined[field] = joined[candidate]
        else:
            joined[field] = joined[field].where(
                joined[field].notna(), joined[candidate]
            )
        joined.drop(columns=[candidate], inplace=True)
    after = {
        field: (
            int(joined[field].notna().sum())
            if field in joined.columns else 0
        )
        for field in fields
    }
    return joined, {
        field: after[field] - before[field]
        for field in fields
    }


def complete_mask(
    frame: pd.DataFrame,
    cfg: dict[str, Any],
) -> pd.Series:
    required = [
        field for field in cfg["required_fields"]
        if field != "source_id"
    ] + cfg["labels"]
    mask = pd.Series(True, index=frame.index)
    for field in required:
        if field not in frame.columns:
            return pd.Series(False, index=frame.index)
        mask &= frame[field].notna()
    return mask


def traced_row_universe(
    candidates: list[dict[str, Any]],
    cfg: dict[str, Any],
) -> list[dict[str, Any]]:
    combined = []
    single = {"APOGEE_NATIVE": [], "GALAH_CORRECTED": []}
    for row in candidates:
        frame = row["frame"]
        if len(frame) < cfg["minimum_base_rows"]:
            continue
        has_survey = (
            "survey" in frame.columns and frame["survey"].notna().any()
        )
        if not has_survey:
            continue
        has_science = (
            (
                "R" in frame.columns and frame["R"].notna().any()
                and "Z" in frame.columns and frame["Z"].notna().any()
            )
            or sum(
                label in frame.columns and frame[label].notna().any()
                for label in cfg["labels"]
            ) >= 3
        )
        if not has_science:
            continue
        surveys = set(frame["survey"].dropna().astype(str))
        if surveys >= {"APOGEE_NATIVE", "GALAH_CORRECTED"}:
            combined.append(row)
        elif surveys == {"APOGEE_NATIVE"}:
            single["APOGEE_NATIVE"].append(row)
        elif surveys == {"GALAH_CORRECTED"}:
            single["GALAH_CORRECTED"].append(row)

    if combined:
        combined.sort(key=lambda row: (-row["score"], str(row["path"])))
        return [combined[0]]

    selected = []
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        single[survey].sort(
            key=lambda row: (-row["score"], str(row["path"]))
        )
        if single[survey]:
            selected.append(single[survey][0])
    return selected if len(selected) == 2 else []


def interaction_schema(
    path: Path,
    cfg: dict[str, Any],
) -> tuple[bool, dict[str, Any]]:
    path_text = str(path).lower()
    if any(
        token in path_text
        for token in cfg["interaction_excluded_tokens"]
    ):
        return False, {"reason": "excluded_path_token"}
    columns, rows = read_columns(path)
    label_column = find_alias(columns, cfg["aliases"]["label"])
    wide = [
        column for column in columns
        if any(
            token in column.lower()
            for token in cfg["interaction_tokens"]
        )
    ]
    ready = bool(label_column and wide)
    return ready, {
        "row_count": rows,
        "label_column": label_column,
        "wide_interaction_columns": wide,
        "reason": "" if ready else "science_interaction_schema_not_found",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2c_config.json").read_text(
            encoding="utf-8"
        )
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables",
        "trace", "shadow", "assembled", "reports"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    d3a_path = root / cfg["prerequisite_stage6d3a"]
    d3a = (
        json.loads(d3a_path.read_text(encoding="utf-8"))
        if d3a_path.exists() else {}
    )
    protocol_ready = bool(
        d3a.get("STAGE6D3A_PROTOCOL_READY", False)
        and d3a.get("PROTOCOL_SEMANTIC_IDENTITY_READY", False)
        and d3a.get("FROZEN_FULL_SUPPORT_GRADIENTS_READY", False)
        and d3a.get("FROZEN_FULL_SUPPORT_BOOTSTRAP_READY", False)
    )

    d3a2b_path = root / cfg["prerequisite_stage6d3a2b"]
    d3a2b = (
        json.loads(d3a2b_path.read_text(encoding="utf-8"))
        if d3a2b_path.exists() else {}
    )
    prior_state_ready = bool(
        d3a2b.get("TRACE_BOOTSTRAP_READY", False)
        and d3a2b.get("SCRIPT_DIRECTORY_INSERTED_IN_SYS_PATH", False)
        and d3a2b.get("execution_returncode") == 0
    )

    before_manifest = tree_manifest(root, cfg["protected_roots"])

    stage4b_config_path = root / cfg["stage4b_config"]
    stage4b_script_path = root / cfg["stage4b_script"]
    original_config = yaml.safe_load(
        stage4b_config_path.read_text(encoding="utf-8")
    )
    shadow_config, patch_rows = patch_shadow_config(
        original_config,
        cfg["shadow_output_dir"],
        cfg["shadow_log_dir"],
    )
    shadow_config_path = root / cfg["shadow_config"]
    shadow_config_path.write_text(
        yaml.safe_dump(
            shadow_config, sort_keys=False, allow_unicode=True
        ),
        encoding="utf-8",
    )
    write_csv(
        out / "tables/stage6d3a2c_shadow_config_audit.csv",
        ["json_path", "action", "old_value", "new_value"],
        patch_rows,
    )

    trace_path = root / cfg["trace_log"]
    if trace_path.exists():
        trace_path.unlink()
    wrapper_path = PACKAGE_ROOT / "trace_hook/run_with_universal_trace.py"
    env = os.environ.copy()
    env["RGB_STAGE6D3_TRACE_LOG"] = str(trace_path.resolve())
    env["RGB_STAGE6D3_PROJECT_ROOT"] = str(root)
    env["RGB_STAGE6D3_DATA_SUFFIXES"] = ";".join(
        cfg["data_suffixes"]
    )
    command = [
        sys.executable,
        str(wrapper_path),
        str(stage4b_script_path.resolve()),
        "--config",
        str(shadow_config_path.resolve()),
    ]
    completed = subprocess.run(
        command,
        cwd=root,
        env=env,
        capture_output=True,
        text=True,
    )
    (out / "trace/stage4b_stdout.txt").write_text(
        completed.stdout, encoding="utf-8"
    )
    (out / "trace/stage4b_stderr.txt").write_text(
        completed.stderr, encoding="utf-8"
    )

    after_manifest = tree_manifest(root, cfg["protected_roots"])
    prior_outputs_modified = before_manifest != after_manifest
    write_json(
        out / "trace/protected_manifest_before.json",
        before_manifest,
    )
    write_json(
        out / "trace/protected_manifest_after.json",
        after_manifest,
    )

    trace_rows = parse_trace(trace_path, root)
    write_csv(
        out / "tables/stage6d3a2c_universal_io_trace.csv",
        [
            "timestamp_utc", "operation", "path",
            "absolute_path", "exists_after_run",
            "status", "error"
        ],
        trace_rows,
    )
    bootstrap_ready = any(
        row["operation"] == "trace_bootstrap"
        and row["status"] == "called"
        for row in trace_rows
    )
    completion_ready = any(
        row["operation"] == "trace_complete"
        and row["status"] == "ok"
        for row in trace_rows
    )
    normal_system_exit = any(
        row["operation"] == "target_system_exit"
        and row["status"] == "ok"
        for row in trace_rows
    )

    read_operations = {
        "builtin_open_read", "path_open_read",
        "pandas_read_csv", "pandas_read_parquet",
        "pandas_read_feather", "pandas_read_pickle",
        "pyarrow_read_table", "pyarrow_parquet_file",
        "pyarrow_dataset", "numpy_load", "numpy_loadtxt",
        "numpy_genfromtxt", "polars_read_csv",
        "polars_read_parquet", "polars_scan_csv",
        "polars_scan_parquet",
    }
    write_operations = {
        "builtin_open_write", "path_open_write",
        "pandas_write_csv", "pandas_write_parquet",
        "pandas_write_feather", "pandas_write_pickle",
        "pyarrow_write_table", "numpy_save",
        "numpy_savez", "numpy_savez_compressed",
        "numpy_savetxt",
    }

    raw_reads = []
    raw_writes = []
    for row in trace_rows:
        if not row["absolute_path"] or row["status"] == "error":
            continue
        path = Path(row["absolute_path"])
        if row["operation"] in read_operations:
            raw_reads.append(path)
        if row["operation"] in write_operations:
            raw_writes.append(path)

    tabular_suffixes = set(cfg["tabular_suffixes"])
    read_paths = expand_data_paths(raw_reads, tabular_suffixes)
    write_paths = expand_data_paths(raw_writes, tabular_suffixes)
    trace_ready = bool(bootstrap_ready and completion_ready and read_paths)

    traced_candidates = []
    for path in read_paths:
        try:
            item = profile(path, cfg)
            if not item["mapping"].get("source_id"):
                continue
            frame = canonical_frame(path, item, cfg)
            if "source_id" not in frame.columns:
                continue
            frame, duplicates, join_keys = collapse(
                frame, survey_aware=True
            )
            traced_candidates.append({
                "path": path,
                "profile": item,
                "frame": frame,
                "duplicates": duplicates,
                "join_keys": join_keys,
                "score": candidate_score(
                    path, frame, traced=True, cfg=cfg
                ),
                "traced": True,
            })
        except Exception:
            continue

    base_rows = traced_row_universe(traced_candidates, cfg)
    selected_bundle = []
    greedy_rows = []
    assembled = pd.DataFrame()
    assembled_path = None
    assembly_error = ""
    complete_counts = {
        "APOGEE_NATIVE": 0,
        "GALAH_CORRECTED": 0,
    }

    if base_rows:
        try:
            all_fields = (
                cfg["required_fields"]
                + ["distance_quality"]
                + cfg["labels"]
            )
            base_frames = []
            for row in base_rows:
                frame = row["frame"].copy()
                for field in all_fields:
                    if field not in frame.columns:
                        frame[field] = pd.NA
                base_frames.append(frame[all_fields])
                selected_bundle.append({
                    "role": "exact_traced_row_universe",
                    "path": row["path"],
                    "join_keys": row["join_keys"],
                    "duplicates": row["duplicates"],
                    "traced": True,
                    "score": row["score"],
                })
            assembled = pd.concat(base_frames, ignore_index=True)
            assembled, _, _ = collapse(assembled, survey_aware=True)

            base_paths = {row["path"].resolve() for row in base_rows}
            anchor_ids = set(assembled["source_id"].astype("uint64"))

            pool = []
            for row in traced_candidates:
                if row["path"].resolve() not in base_paths:
                    row["overlap_fraction"] = (
                        len(
                            anchor_ids.intersection(
                                set(row["frame"]["source_id"].astype("uint64"))
                            )
                        )
                        / max(len(anchor_ids), 1)
                    )
                    if (
                        row["overlap_fraction"]
                        >= cfg["minimum_anchor_overlap_fraction"]
                    ):
                        pool.append(row)

            schema_candidates = []
            traced_set = {path.resolve() for path in read_paths}
            for rel_root in cfg["scan_roots"]:
                base = root / rel_root
                if not base.exists():
                    continue
                for path in base.rglob("*"):
                    if (
                        not path.is_file()
                        or path.suffix.lower() not in tabular_suffixes
                        or path.resolve() in traced_set
                    ):
                        continue
                    try:
                        item = profile(path, cfg)
                    except Exception:
                        continue
                    if not item["mapping"].get("source_id"):
                        continue
                    coverage = sum(
                        item["mapping"].get(field) is not None
                        for field in cfg["required_fields"]
                    ) + len(item["labels"])
                    priority = (
                        500 if "stage4a" in str(path).lower()
                        else 300 if "stage3" in str(path).lower()
                        else 200 if "stage2" in str(path).lower()
                        else 100
                    )
                    schema_candidates.append({
                        "path": path,
                        "profile": item,
                        "rank": 100 * coverage + priority,
                    })
            schema_candidates.sort(
                key=lambda row: (-row["rank"], str(row["path"]))
            )
            for item_row in schema_candidates[
                : cfg["maximum_upstream_candidates_to_load"]
            ]:
                try:
                    frame = canonical_frame(
                        item_row["path"], item_row["profile"], cfg
                    )
                    if "source_id" not in frame.columns:
                        continue
                    frame, duplicates, join_keys = collapse(
                        frame, survey_aware=True
                    )
                    overlap = (
                        len(
                            anchor_ids.intersection(
                                set(frame["source_id"].astype("uint64"))
                            )
                        )
                        / max(len(anchor_ids), 1)
                    )
                    if overlap < cfg["minimum_anchor_overlap_fraction"]:
                        continue
                    pool.append({
                        "path": item_row["path"].resolve(),
                        "profile": item_row["profile"],
                        "frame": frame,
                        "duplicates": duplicates,
                        "join_keys": join_keys,
                        "score": candidate_score(
                            item_row["path"], frame,
                            traced=False, cfg=cfg
                        ),
                        "traced": False,
                        "overlap_fraction": overlap,
                    })
                except Exception:
                    continue

            used = set(base_paths)
            max_files = (
                cfg["maximum_traced_enrichment_files"]
                + cfg["maximum_upstream_enrichment_files"]
            )
            for _ in range(max_files):
                current_complete = int(
                    complete_mask(assembled, cfg).sum()
                )
                best = None
                for row in pool:
                    key = row["path"].resolve()
                    if key in used:
                        continue
                    join_keys = (
                        ["source_id", "survey"]
                        if (
                            "survey" in row["frame"].columns
                            and row["frame"]["survey"].notna().any()
                        )
                        else ["source_id"]
                    )
                    addition = row["frame"]
                    if join_keys == ["source_id"]:
                        addition, _, _ = collapse(
                            addition, survey_aware=False
                        )
                    try:
                        trial, gains = coalesce(
                            assembled, addition, all_fields, join_keys
                        )
                    except Exception:
                        continue
                    after_complete = int(
                        complete_mask(trial, cfg).sum()
                    )
                    complete_gain = after_complete - current_complete
                    total_gain = sum(
                        max(int(value), 0)
                        for value in gains.values()
                    )
                    score = (
                        10000 * complete_gain
                        + total_gain
                        + 2000 * int(row["traced"])
                        + int(100 * row["overlap_fraction"])
                    )
                    if (
                        (complete_gain > 0 or total_gain > 0)
                        and (best is None or score > best["score"])
                    ):
                        best = {
                            "row": row,
                            "trial": trial,
                            "gains": gains,
                            "complete_gain": complete_gain,
                            "score": score,
                            "join_keys": join_keys,
                        }
                if best is None:
                    break
                row = best["row"]
                assembled = best["trial"]
                used.add(row["path"].resolve())
                role = (
                    "traced_enrichment"
                    if row["traced"]
                    else "frozen_upstream_enrichment"
                )
                selected_bundle.append({
                    "role": role,
                    "path": row["path"],
                    "join_keys": best["join_keys"],
                    "duplicates": row["duplicates"],
                    "traced": row["traced"],
                    "score": best["score"],
                })
                greedy_rows.append({
                    "path": safe_rel(row["path"], root),
                    "role": role,
                    "score": best["score"],
                    "join_keys": "|".join(best["join_keys"]),
                    "complete_row_gain": best["complete_gain"],
                    "anchor_overlap_fraction": row["overlap_fraction"],
                    "field_gains": json.dumps(
                        best["gains"], sort_keys=True
                    ),
                })

            complete = complete_mask(assembled, cfg)
            for survey in complete_counts:
                complete_counts[survey] = int(
                    (
                        complete
                        & (assembled["survey"] == survey)
                    ).sum()
                )

            assembled_path = (
                out
                / "assembled/stage6d3a2c_production_source_assembled.parquet"
            )
            try:
                assembled.to_parquet(assembled_path, index=False)
            except Exception:
                assembled_path = (
                    out
                    / "assembled/stage6d3a2c_production_source_assembled.csv"
                )
                assembled.to_csv(assembled_path, index=False)
        except Exception as exc:
            assembly_error = (
                f"{type(exc).__name__}: {exc}\n"
                + traceback.format_exc()
            )
    else:
        assembly_error = (
            "Universal trace did not identify either one combined two-survey "
            "production row universe or one traced source table for each survey."
        )

    write_csv(
        out / "tables/stage6d3a2c_selected_source_bundle.csv",
        [
            "bundle_order", "role", "path",
            "join_keys", "duplicate_keys", "traced", "score"
        ],
        [
            {
                "bundle_order": index + 1,
                "role": row["role"],
                "path": safe_rel(row["path"], root),
                "join_keys": "|".join(row["join_keys"]),
                "duplicate_keys": row["duplicates"],
                "traced": str(row["traced"]).lower(),
                "score": row["score"],
            }
            for index, row in enumerate(selected_bundle)
        ],
    )
    write_csv(
        out / "tables/stage6d3a2c_greedy_enrichment_audit.csv",
        [
            "path", "role", "score", "join_keys",
            "complete_row_gain", "anchor_overlap_fraction",
            "field_gains"
        ],
        greedy_rows,
    )

    coverage_rows = []
    if not assembled.empty:
        for field in (
            cfg["required_fields"]
            + ["distance_quality"]
            + cfg["labels"]
        ):
            coverage_rows.append({
                "field": field,
                "non_null_rows": (
                    int(assembled[field].notna().sum())
                    if field in assembled.columns else 0
                ),
                "coverage_fraction": (
                    float(assembled[field].notna().mean())
                    if field in assembled.columns else 0.0
                ),
            })
    write_csv(
        out / "tables/stage6d3a2c_assembled_field_coverage.csv",
        ["field", "non_null_rows", "coverage_fraction"],
        coverage_rows,
    )

    interaction_paths = []
    for directory in [
        root / "outputs/stage4b",
        root / cfg["shadow_output_dir"],
    ]:
        for name in cfg["interaction_preferred_names"]:
            path = directory / name
            if path.exists():
                interaction_paths.append(path)
    interaction_rows = []
    interaction = None
    for path in list(dict.fromkeys(interaction_paths)):
        ready, schema = interaction_schema(path, cfg)
        interaction_rows.append({
            "path": safe_rel(path, root),
            "ready": str(ready).lower(),
            "traced_write": str(
                path.resolve() in write_paths
            ).lower(),
            "label_column": schema.get("label_column", ""),
            "wide_interaction_columns": "|".join(
                schema.get("wide_interaction_columns", [])
            ),
            "reason": schema.get("reason", ""),
        })
        if ready and interaction is None:
            interaction = path
    write_csv(
        out / "tables/stage6d3a2c_interaction_context_audit.csv",
        [
            "path", "ready", "traced_write", "label_column",
            "wide_interaction_columns", "reason"
        ],
        interaction_rows,
    )

    source_ready = bool(
        not assembly_error
        and assembled_path is not None
        and all(
            complete_counts[survey]
            >= cfg["minimum_complete_rows_per_survey"]
            for survey in complete_counts
        )
    )

    remaining = []
    if not protocol_ready:
        remaining.append({
            "gate": "STAGE6D3A_BASELINE_PROTOCOL_READY",
            "required_action": "Restore PASS Stage-6D3A baseline protocol.",
        })
    if prior_outputs_modified:
        remaining.append({
            "gate": "PRIOR_STAGE_OUTPUTS_UNMODIFIED",
            "required_action": (
                "Protected Stage-4A/4B tree changed during shadow execution; "
                "inspect before/after manifests."
            ),
        })
    if not trace_ready:
        remaining.append({
            "gate": "UNIVERSAL_RUNTIME_TRACE_READY",
            "required_action": (
                f"Universal trace lacks a complete read lineage. "
                f"returncode={completed.returncode}; "
                f"bootstrap={bootstrap_ready}; completion={completion_ready}; "
                f"tabular_reads={len(read_paths)}."
            ),
        })
    if assembly_error:
        remaining.append({
            "gate": "TRACED_PRODUCTION_ROW_UNIVERSE_READY",
            "required_action": assembly_error,
        })
    elif not source_ready:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_COMPLETE_ROWS_READY",
            "required_action": (
                f"Need at least {cfg['minimum_complete_rows_per_survey']} "
                "complete rows per survey. Observed: "
                + json.dumps(complete_counts, sort_keys=True)
            ),
        })
    if interaction is None:
        remaining.append({
            "gate": "EXISTING_INTERACTION_CONTEXT_READY",
            "required_action": (
                "Optional context absent; this does not block D3B because "
                "Stage-6D4 refits balanced-footprint interactions."
            ),
        })
    write_csv(
        out / "tables/stage6d3a2c_remaining_items.csv",
        ["gate", "required_action"],
        remaining,
    )

    d3b_ready = bool(
        protocol_ready
        and not prior_outputs_modified
        and trace_ready
        and source_ready
    )
    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "exact_command": " ".join(command),
        "execution_returncode": completed.returncode,
        "trace_event_count": len(trace_rows),
        "trace_bootstrap_ready": bootstrap_ready,
        "trace_completion_ready": completion_ready,
        "normal_system_exit_captured": normal_system_exit,
        "tabular_read_path_count": len(read_paths),
        "tabular_write_path_count": len(write_paths),
        "traced_read_paths": [
            safe_rel(path, root) for path in read_paths
        ],
        "traced_write_paths": [
            safe_rel(path, root) for path in write_paths
        ],
        "selected_source_bundle": [
            safe_rel(row["path"], root)
            for row in selected_bundle
        ],
        "assembled_source_table": (
            safe_rel(assembled_path, root)
            if assembled_path else ""
        ),
        "assembled_rows": len(assembled),
        "complete_rows_by_survey": complete_counts,
        "selected_interaction_context": (
            safe_rel(interaction, root) if interaction else ""
        ),
        "assembly_error": assembly_error,
        "prior_stage_outputs_modified": prior_outputs_modified,
        "STAGE6D3A_BASELINE_PROTOCOL_READY": protocol_ready,
        "PRIOR_ZERO_READ_TRACE_STATE_CONFIRMED": prior_state_ready,
        "LOW_LEVEL_OPEN_TRACE_ENABLED": True,
        "PYARROW_TRACE_ENABLED": True,
        "NUMPY_TRACE_ENABLED": True,
        "POLARS_TRACE_ENABLED": True,
        "NORMAL_SYSTEM_EXIT_HANDLED": completion_ready,
        "PROTECTED_STAGE4A_STAGE4B_UNMODIFIED": (
            not prior_outputs_modified
        ),
        "UNIVERSAL_RUNTIME_TRACE_READY": trace_ready,
        "TRACED_PRODUCTION_ROW_UNIVERSE_READY": bool(base_rows),
        "SURVEY_AWARE_SOURCE_ID_JOIN_READY": bool(selected_bundle),
        "PRODUCTION_SOURCE_ASSEMBLY_READY": source_ready,
        "CLAIM_LEDGER_EXCLUDED_FROM_INTERACTION_ROLE": True,
        "EXISTING_INTERACTION_CONTEXT_READY": interaction is not None,
        "INTERACTION_CONTEXT_REQUIRED_FOR_D3B": False,
        "STAGE6D3A2C_LINEAGE_READY": bool(
            protocol_ready and trace_ready
        ),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": d3b_ready,
    }
    write_json(
        out / "validation/stage6d3a2c_validation.json",
        validation,
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "runtime_trace": {
            "returncode": completed.returncode,
            "bootstrap_ready": bootstrap_ready,
            "completion_ready": completion_ready,
            "normal_system_exit_captured": normal_system_exit,
            "tabular_reads": validation["traced_read_paths"],
            "tabular_writes": validation["traced_write_paths"],
        },
        "source_assembly": {
            "bundle": validation["selected_source_bundle"],
            "assembled_rows": len(assembled),
            "complete_rows_by_survey": complete_counts,
            "ready": source_ready,
        },
        "interaction_context": {
            "path": validation["selected_interaction_context"],
            "ready": interaction is not None,
            "required_for_d3b": False,
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "Universal runtime lineage and the exact production row universe "
            "are closed. Stage-6D3B common-footprint construction is authorized."
            if d3b_ready else
            "Universal tracing is complete, but D3B remains blocked by the "
            "listed lineage, protected-output, or complete-row gap."
        ),
    }
    write_json(
        out / "summaries/stage6d3a2c_summary.json",
        summary,
    )

    report = [
        "# Stage-6D3A2C universal I/O trace and row-universe assembly",
        "",
        f"- Return code: `{completed.returncode}`",
        f"- Trace bootstrap: `{bootstrap_ready}`",
        f"- Trace completion: `{completion_ready}`",
        f"- Normal SystemExit captured: `{normal_system_exit}`",
        f"- Tabular reads: `{len(read_paths)}`",
        f"- Tabular writes: `{len(write_paths)}`",
        f"- Protected Stage-4A/4B unchanged: `{not prior_outputs_modified}`",
        f"- Base row-universe files: `{len(base_rows)}`",
        f"- Selected bundle files: `{len(selected_bundle)}`",
        f"- Assembled rows: `{len(assembled)}`",
        f"- Complete APOGEE rows: `{complete_counts['APOGEE_NATIVE']}`",
        f"- Complete GALAH rows: `{complete_counts['GALAH_CORRECTED']}`",
        f"- Interaction context required for D3B: `False`",
        f"- Stage-6D3B ready: `{d3b_ready}`",
        "",
        "The trace covers low-level open/pathlib I/O plus pandas, PyArrow, "
        "NumPy, and Polars. Source assembly uses the exact traced production "
        "row universe and source-ID enrichment without outcome-based matching.",
        "",
    ]
    (
        out / "reports/stage6d3a2c_universal_io_trace_bundle.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
