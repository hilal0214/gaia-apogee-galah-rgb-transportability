from __future__ import annotations
import argparse, hashlib, json, re, shutil, subprocess, zipfile
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()
def wj(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def replace_once(text,old,new,label):
    n=text.count(old)
    if n!=1: raise RuntimeError(f"{label}: expected exactly one occurrence, found {n}")
    return text.replace(old,new,1)
def replace_section(text,start_marker,end_marker,new_block,label):
    i=text.find(start_marker)
    if i<0: raise RuntimeError(f"{label}: start marker missing")
    j=text.find(end_marker,i+len(start_marker))
    if j<0: raise RuntimeError(f"{label}: end marker missing")
    return text[:i]+new_block.rstrip()+"\n\n"+text[j:]
def locate_baseline(root,prefix):
    candidates=[]
    for parent in [root,Path.home()/"Downloads"]:
        if parent.exists():
            candidates += [p for p in parent.glob(prefix+"*") if p.is_dir()]
            candidates += [p for p in parent.glob(prefix+"*.zip") if p.is_file()]
    candidates=sorted(set(candidates), key=lambda p:(p.suffix.lower()==".zip",-p.stat().st_mtime))
    return candidates[0] if candidates else None
def latex_label(name):
    return {
        "fe_h":r"$[\mathrm{Fe/H}]$",
        "mg_fe":r"$[\mathrm{Mg/Fe}]$",
        "si_fe":r"$[\mathrm{Si/Fe}]$",
        "ca_fe":r"$[\mathrm{Ca/Fe}]$",
        "ni_fe":r"$[\mathrm{Ni/Fe}]$",
    }[name]
def cls_short(s):
    return {"TRANSPORT_STABLE":"Stable","INDETERMINATE":"Indet.",
            "FOOTPRINT_SENSITIVE":"Footprint","SURVEY_SENSITIVE":"Survey"}[s]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",default=".")
    ap.add_argument("--baseline",default=None)
    args=ap.parse_args()
    root=Path(args.project_root).resolve()
    cfg=json.loads((root/"config/stage6d6a_config.json").read_text(encoding="utf-8"))
    out=root/cfg["output_dir"]
    if out.exists(): shutil.rmtree(out)
    out.mkdir(parents=True,exist_ok=True)

    vpath=root/cfg["d5a_validation"]; spath=root/cfg["d5a_summary"]
    if not vpath.exists() or not spath.exists(): raise FileNotFoundError("Stage-6D5A outputs missing")
    v=json.loads(vpath.read_text(encoding="utf-8"))
    d5_ready=bool(v.get("STAGE6D5A_MANUSCRIPT_CLAIM_INTEGRATION_READY") and
                  v.get("STAGE6D5B_ARCHIVAL_RELEASE_READY") and
                  v.get("INDETERMINATE_NOT_RELABELED_AS_SENSITIVE"))
    s=pd.read_csv(spath)
    if set(s["label"])!={"fe_h","mg_fe","si_fe","ca_fe","ni_fe"} or len(s)!=5:
        raise RuntimeError("D5A five-label publication summary identity failed")
    class_map=dict(zip(s["label"],s["overall_classification"]))
    expected={"fe_h":"INDETERMINATE","mg_fe":"INDETERMINATE","si_fe":"INDETERMINATE","ca_fe":"INDETERMINATE","ni_fe":"TRANSPORT_STABLE"}
    if class_map!=expected: raise RuntimeError(f"Unexpected frozen D5A classifications: {class_map}")

    baseline=Path(args.baseline).resolve() if args.baseline else locate_baseline(root,cfg["baseline_package_prefix"])
    if baseline is None: raise RuntimeError(
        "Baseline MNRAS package not found. Place RGB_atlas_MNRAS_complete_flat_v1_0_0 "
        "directory or ZIP in Downloads, or run with --baseline <path>."
    )
    staging=out/"_baseline_extract"
    if baseline.is_file():
        staging.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(baseline,"r") as z:z.extractall(staging)
        roots=[p for p in staging.rglob("main.tex")]
        if len(roots)!=1: raise RuntimeError(f"ZIP baseline must contain exactly one main.tex, found {len(roots)}")
        srcroot=roots[0].parent
    else:
        srcroot=baseline
    main_src=srcroot/"main.tex"
    if not main_src.exists(): raise FileNotFoundError(str(main_src))
    baseline_sha=sha(main_src)
    if baseline_sha!=cfg["baseline_main_tex_sha256"]:
        raise RuntimeError(
            f"Baseline main.tex identity mismatch: got {baseline_sha}; "
            f"expected {cfg['baseline_main_tex_sha256']}. Refusing to patch a different manuscript."
        )

    dst=out/cfg["output_package_name"]
    shutil.copytree(srcroot,dst)
    for name in ["main.pdf","main.aux","main.log","main.out","main.toc"]:
        p=dst/name
        if p.exists():p.unlink()

    p=dst/"main.tex"
    text=p.read_text(encoding="utf-8")

    old_title = "\\title[A support-aware Gaia--APOGEE--GALAH RGB atlas]\n{A support-aware Gaia--APOGEE--GALAH red-giant chemo-kinematic atlas of the Milky Way}"
    new_title = "\\title[Cross-survey chemical-label transportability]\n{Predicting cross-survey chemical-label transportability in a Gaia--APOGEE--GALAH red-giant atlas}"
    text=replace_once(text,old_title,new_title,"title")

    a0=text.index(r"\begin{abstract}")
    a1=text.index(r"\end{abstract}",a0)+len(r"\end{abstract}")
    abstract=r'''\begin{abstract}
Combining large spectroscopic surveys requires more than removing mean abundance offsets: label-specific calibration residuals, stellar-parameter sensitivity, and unequal sky footprints can determine whether an inferred chemical trend is transportable across surveys. We construct a claim-bounded Gaia--APOGEE--GALAH red-giant atlas and use it to test cross-survey chemical-label transportability. The merged spectroscopic parent layer contains 1,591,571 catalogue entries, while the Gaia-limited production run yields 89,323 clean RGB stars. Common-star calibration is performed label by label using 45,040--57,883 overlap stars. In an amended five-label exploratory pilot restricted to $[\mathrm{Fe/H}]$, $[\mathrm{Mg/Fe}]$, $[\mathrm{Si/Fe}]$, $[\mathrm{Ca/Fe}]$, and $[\mathrm{Ni/Fe}]$, held-out transport quality is positively associated with a pre-defined atmospheric-sensitivity burden: the pooled burden coefficient is $0.410$, with bootstrap $P(\beta>0)=1.000$, a 95 per cent interval $[0.246,0.520]$, and permutation $p=0.0014$. This association is descriptive and is not promoted to a universal predictive law. We then test the frozen Stage-4B radial and vertical gradients on a common APOGEE--GALAH footprint containing 34,177 stars in 208 primary HEALPix cells, with outcome-blind overlap weighting and the same robust Huber inference contract. Under pre-specified practical-equivalence rules, $[\mathrm{Ni/Fe}]$ is transport-stable in both radial and vertical gradients; $[\mathrm{Si/Fe}]$ and $[\mathrm{Ca/Fe}]$ are transport-stable vertically but remain indeterminate radially; $[\mathrm{Fe/H}]$ and $[\mathrm{Mg/Fe}]$ are indeterminate in both coordinates. No primary label is classified as footprint-sensitive or survey-sensitive. The resulting framework distinguishes positive evidence of transport stability from failure to establish equivalence, while avoiding volume-complete, causal, independent-replication, or component-resolved claims.
\end{abstract}'''
    text=text[:a0]+abstract+text[a1:]

    old_kw="Galaxy: abundances -- Galaxy: disc -- Galaxy: kinematics and dynamics --\nstars: late-type -- surveys -- methods: statistical"
    new_kw="Galaxy: abundances -- Galaxy: disc -- stars: late-type -- surveys --\nmethods: statistical -- methods: data analysis"
    text=replace_once(text,old_kw,new_kw,"keywords")

    old_intro='''This work uses four linked layers. First, the two spectroscopic catalogues are transformed to a common schema and joined to Gaia DR3. Second, common APOGEE--GALAH stars define empirical, label-specific transport models. Third, a frozen robust regression layer measures radial and vertical gradients with explicit quality and spatial-domain gates. Fourth, an anonymous latent-component model family measures whether the chemo-kinematic feature space contains stable low-entropy structure. The component layer is deliberately diagnostic: the final archive does not select one physical decomposition or retain star-level component memberships.

The resulting claim hierarchy is narrower than that of the earlier rendered draft. We retain the authoritative global Stage-4B gradients and direct Stage-5B model-family diagnostics. We remove physically named latent populations, component-resolved gradients, and newly reconstructed survey-origin coefficients because those claims are not reproducible from the frozen release. The paper therefore focuses on label-specific transportability, global chemo-kinematic structure, and explicit limits imposed by survey support.'''
    new_intro='''The analysis is organised around three transport questions. First, how strongly does empirical APOGEE--GALAH calibration quality vary from label to label? Second, within the labels supported by the frozen archive, is held-out transport quality associated with a pre-defined burden constructed from the calibration model's sensitivity to atmospheric parameters? Third, do the authoritative global chemical gradients survive restriction to an outcome-blind common footprint and subsequent survey balancing? These questions are separated deliberately: overlap calibration, exploratory transport diagnostics, and common-footprint gradient inference have different support and therefore different claim boundaries.

The resulting framework is not a universal abundance-scale model or a volume-complete Galactic census. The transportability diagnostic is an amended five-label exploratory pilot, while the common-footprint analysis is a conditional robustness test on shared APOGEE--GALAH support. The Stage-5B latent-component family is retained only as an anonymous secondary diagnostic and is not used to assign physical Galactic populations. The main contribution is consequently a reproducible hierarchy that distinguishes direct calibration, exploratory predictability, practical-equivalence evidence, survey/footprint sensitivity, and indeterminate cases without silently promoting unsupported extrapolations.'''
    text=replace_once(text,old_intro,new_intro,"intro framing")

    marker=r"\subsection{Anonymous latent-component diagnostics}"
    transport_methods=r'''\subsection{Held-out transport-quality diagnostic}

For each supported chemical label, the held-out transport-quality response is
\begin{equation}
Q_{\rm heldout}=
\frac{{\rm MAD}(\mathrm{held\!-\!out\ residual})}
{{\rm IQR}(\mathrm{common\!-\!sample\ label})},
\label{eq:qheldout}
\end{equation}
with a minimum denominator of 0.01. Lower values therefore indicate tighter held-out transport relative to the intrinsic label width in the overlap sample.

The pre-defined atmospheric-sensitivity burden is
\begin{equation}
B_{\rm atmos}=
\left[
(a_T w_T)^2+(a_g w_g)^2+(a_{\rm Fe} w_{\rm Fe})^2
\right]^{1/2},
\label{eq:batmos}
\end{equation}
where the $a$ coefficients are the frozen transport sensitivities and the $w$ terms are robust overlap widths. The original nine-label predictive law cannot be tested from the frozen archive because source-level coefficient support is complete only for $[\mathrm{Fe/H}]$, $[\mathrm{Mg/Fe}]$, $[\mathrm{Si/Fe}]$, $[\mathrm{Ca/Fe}]$, and $[\mathrm{Ni/Fe}]$. We therefore treat the reconstructed five-label analysis as an exploratory pilot. It may support descriptive association statements, but not a universal predictive law, an intrinsic label-quality ranking, or an independent replication.

\subsection{Common-footprint and survey-balance protocol}

The footprint analysis is frozen before gradient interpretation. The primary shared footprint uses Galactic HEALPix cells at ${\rm NSIDE}=16$ and requires both surveys to contribute within each retained cell before and after overlap trimming. Trimming is performed on non-outcome covariates only. The production common footprint contains 34,177 stars in 208 cells, comprising 10,853 APOGEE and 23,324 GALAH rows.

Survey balance uses a cross-fitted propensity model with cell fixed effects, standard overlap weights, a within-survey 99th-percentile cap, and positive calibration to equalise survey totals within each retained cell. The final balance reaches a maximum absolute standardised mean difference of 0.099 and an effective-sample-size fraction of 0.351 in each survey. No abundance outcome, $R$, $|Z|$, residual, or latent-component label is used to construct the weights.

The common-footprint gradient models reuse the frozen Stage-4B Huber IRLS contract. The pooled model uses unity weights; the balanced and survey-interaction models use the frozen outcome-blind survey-balance weights. Uncertainty is propagated with 4096 antithetic Rademacher spatial-cluster multiplier draws over the retained primary-NSIDE16 cells. Practical-equivalence margins are
\begin{equation}
\epsilon_R=\max(0.005,0.25|\beta_{R,\rm full}|),
\qquad
\epsilon_Z=\max(0.030,0.25|\beta_{Z,\rm full}|).
\label{eq:equiv_margins}
\end{equation}
The pre-specified outcome classes are \textsc{transport-stable}, \textsc{footprint-sensitive}, \textsc{survey-sensitive}, and \textsc{indeterminate}.'''
    text=replace_once(text,marker,transport_methods+"\n\n"+marker,"method insertion")

    old_support_start=r"\subsection{Survey support and exact-replay gate}"
    old_support_end=r"\section{Results}"
    new_support=r'''\subsection{Estimator lineage and claim boundary}

The exact Stage-4B Huber API and spatial-cluster inference machinery are recovered and regression-tested. For the weighted common-footprint extension, setting every analysis weight to unity reproduces the original Stage-4B coefficients, robust scale, Huber score function, covariance, and standard errors with zero numerical discrepancy in the frozen regression audit. The new survey-balanced models are therefore treated as a protocol-declared extension of the same estimator rather than as a separately tuned regression family.

The common-footprint survey-interaction coefficients are conditional contrasts on tested shared support. They are not interpreted as an independent GALAH replication, a selection-function-corrected census, or a causal effect of footprint membership.'''
    text=replace_section(text,old_support_start,old_support_end,new_support,"support section")

    marker2=r"\subsection{Interpretation of radial structure}"
    rows=[]
    for _,r in s.iterrows():
        rows.append(
            f"{latex_label(r['label'])} & {float(r['full_beta_R']):+.4f} & {float(r['balanced_beta_R']):+.4f} & "
            f"{float(r['full_beta_Z']):+.4f} & {float(r['balanced_beta_Z']):+.4f} & "
            f"{float(r['delta_beta_R']):+.4f} & {float(r['delta_beta_Z']):+.4f} & "
            f"{cls_short(r['overall_classification'])} \\\\"
        )
    table_rows="\n".join(rows)
    d2=cfg["d2_exploratory"]
    new_results = r'''\subsection{Exploratory transportability association}

The five-label exploratory pilot shows a stable positive association between the atmospheric-sensitivity burden and held-out transport difficulty. Across 25 label--fold groups, the median within-group Spearman coefficient is %.4f, and %.0f per cent of groups have a positive association. In the pooled diagnostic, the coefficient of $B_{\rm atmos}$ is %.5f; the bootstrap probability of a positive coefficient is %.3f, with a 95 per cent interval [%.5f,%.5f]. A permutation test gives $p=%.4f$.

This result is deliberately scoped as a stable positive exploratory association. The frozen archive does not support the original nine-label predictive-law test, so these five labels cannot establish a universal ranking of chemical labels or an intrinsic notion of label quality.

\subsection{Common-footprint gradient transport}

Table~\ref{tab:transport_classification} compares the frozen full-support gradients with the outcome-blind survey-balanced common-footprint fits and reports the fitted GALAH--APOGEE interaction contrasts. The common-footprint analysis does not classify any primary label as footprint-sensitive or survey-sensitive.

\begin{table*}
\centering
\scriptsize
\caption{Common-footprint transport summary for the five primary labels. Full and balanced slopes are in $\rm dex\,kpc^{-1}$; $\Delta\beta$ denotes the fitted GALAH--APOGEE interaction contrast on balanced common support. ``Stable'' means that the complete pre-specified practical-equivalence rule is satisfied in both coordinates; ``Indet.'' means that neither full stability nor a sensitivity class is established.}
\label{tab:transport_classification}
\begin{tabular}{lrrrrrrl}
\toprule
Label & $\beta_{R,\rm full}$ & $\beta_{R,\rm bal}$ &
$\beta_{Z,\rm full}$ & $\beta_{Z,\rm bal}$ &
$\Delta\beta_R$ & $\Delta\beta_Z$ & Overall\\
\midrule
%s
\bottomrule
\end{tabular}
\end{table*}

$[\mathrm{Ni/Fe}]$ is the only label that satisfies the complete transport-stability rule in both radial and vertical gradients. $[\mathrm{Si/Fe}]$ and $[\mathrm{Ca/Fe}]$ satisfy the vertical equivalence criterion but remain indeterminate radially. $[\mathrm{Fe/H}]$ and $[\mathrm{Mg/Fe}]$ are indeterminate in both coordinates. Here \textsc{indeterminate} does not mean unstable: the conservative equivalence interval is insufficient to establish full practical equivalence, while the pre-specified footprint- and survey-sensitivity criteria are also not triggered.''' % (
        d2["median_within_label_fold_spearman"],
        100*d2["positive_group_fraction"],
        d2["pooled_beta_B_atmos"],
        d2["bootstrap_probability_beta_positive"],
        d2["bootstrap_ci95"][0],
        d2["bootstrap_ci95"][1],
        d2["permutation_p"],
        table_rows
    )
    text=replace_once(text,marker2,new_results+"\n\n"+marker2,"results insertion")

    fig4_re=re.compile(
        r"\n\\begin\{figure\*\}\n\\centering\n\\includegraphics\[width=0\.92\\textwidth\]\{figures/figure04_claim_hierarchy\.pdf\}\n"
        r"\\caption\{Final claim hierarchy\..*?\}\n\\label\{fig:claim_hierarchy\}\n\\end\{figure\*\}\n",
        flags=re.S
    )
    text,n=fig4_re.subn("\n",text,count=1)
    if n!=1: raise RuntimeError(f"obsolete Figure 4 block removal failed; matches={n}")

    old_disc_start=r"\subsection{Global gradients and survey footprint}"
    old_disc_end=r"\subsection{Why physical component names are excluded}"
    new_disc=r'''\subsection{From calibration precision to transport stability}

The common-footprint experiment changes the interpretation of the global gradients. The full-support coefficients remain the authoritative measurements for the frozen clean sample, but they are no longer the only quantitative statement about survey support. Restricting both surveys to shared HEALPix cells and balancing them with outcome-blind overlap weights provides a direct robustness test of the gradient slopes under substantially more comparable support.

The result is asymmetric across labels. Nickel provides positive evidence of transport stability in both coordinates. Silicon and calcium pass the vertical equivalence rule but not the radial rule. Iron and magnesium do not satisfy the complete equivalence criterion. However, none of these four indeterminate labels crosses the pre-specified footprint- or survey-sensitivity boundary. It would therefore be incorrect to translate \textsc{indeterminate} into ``unstable'', ``non-transportable'', or ``survey-discrepant''. The strict decision rule distinguishes absence of an equivalence proof from positive evidence of sensitivity.

The survey-interaction terms are also conditional contrasts rather than independent replications. APOGEE and GALAH retain different parent target selections, wavelength ranges, and selection functions even after common-footprint trimming and covariate balancing. The analysis therefore tests practical stability within observed shared support; it does not reconstruct a volume-complete selection function or identify a causal footprint effect.

\subsection{Exploratory predictability and its limit}

The positive $B_{\rm atmos}$ association suggests that transport difficulty contains predictable structure tied to the same atmospheric sensitivities that enter the empirical cross-survey calibration. This provides a useful diagnostic for prioritising labels and designing future survey-combination tests. The evidence is nevertheless restricted to five labels because the archived coefficient support is incomplete for carbon, nitrogen, aluminium, and titanium. The appropriate claim is therefore an exploratory association, not a general law of spectroscopic-label transportability.'''
    text=replace_section(text,old_disc_start,old_disc_end,new_disc+"\n\n"+old_disc_end,"discussion survey section")

    cstart=r"\section{Conclusions}"
    cend=r"\section*{Data and Code Availability}"
    concl=r'''\section{Conclusions}
\label{sec:conclusions}

We have constructed a claim-bounded Gaia--APOGEE--GALAH RGB atlas and used it to test when chemical-label inference remains transportable across heterogeneous survey support.

\begin{enumerate}[leftmargin=*]
\item The merged spectroscopic parent layer contains 1,591,571 catalogue entries, and the Gaia-limited production run contains 89,323 clean RGB stars after frozen quality and phase-space gates.
\item APOGEE--GALAH calibration is empirical and label specific. Common-star support ranges from 45,040 to 57,883 stars, and the post-calibration residual scale varies substantially among labels.
\item In the amended five-label exploratory pilot, held-out transport difficulty is positively associated with the atmospheric-sensitivity burden: the pooled coefficient is $0.40993$, its bootstrap 95 per cent interval is $[0.24589,0.52037]$, and the permutation test gives $p=0.0014$. This is not promoted to a universal predictive law.
\item The authoritative Stage-4B gradients remain the frozen full-support reference. The common-footprint extension uses 34,177 stars in 208 primary HEALPix cells, outcome-blind survey balancing, the same Huber estimator contract, and 4096 spatial-cluster multiplier draws.
\item $[\mathrm{Ni/Fe}]$ is transport-stable in both radial and vertical gradients. $[\mathrm{Si/Fe}]$ and $[\mathrm{Ca/Fe}]$ are vertically stable but overall indeterminate, while $[\mathrm{Fe/H}]$ and $[\mathrm{Mg/Fe}]$ are indeterminate in both coordinates. No primary label is classified as footprint-sensitive or survey-sensitive.
\item The Stage-5B mixture layer remains an anonymous model-family diagnostic. The release does not support physically named latent populations, component-resolved gradients, volume-complete inference, causal footprint effects, or independent-survey replication claims.
\end{enumerate}'''
    text=replace_section(text,cstart,cend,concl,"conclusions")

    dstart=r"\section*{Data and Code Availability}"
    dend=r"\section*{Acknowledgements}"
    dataavail = r'''\section*{Data and Code Availability}

The frozen technical reproducibility archive is \texttt{%s}, with SHA-256
\begin{quote}
\texttt{%s}.
\end{quote}
It contains the frozen protocol definitions, common-footprint production estimates, 4096-draw bootstrap products, practical-equivalence classifications, claim ledgers, exact analysis code/configuration, and SHA-256 manifests. Large upstream Gaia, APOGEE, and GALAH catalogues and the row-level balanced production table are not redistributed. The manuscript itself is maintained separately from the science archive.

The public repository and DOI metadata will be inserted after verification of the final human metadata:
\begin{description}[leftmargin=2.5cm,style=nextline]
\item[Repository] \textbf{REPOSITORY\_URL}
\item[Exact release DOI] \textbf{EXACT\_VERSION\_DOI}
\item[Concept DOI] \textbf{CONCEPT\_DOI}
\end{description}''' % (cfg["technical_release_name"],cfg["technical_release_sha256"])
    text=replace_section(text,dstart,dend,dataavail,"data availability")

    p.write_text(text,encoding="utf-8")

    checks={
        "baseline_main_tex_identity_ready": baseline_sha==cfg["baseline_main_tex_sha256"],
        "d5a_prerequisite_ready": d5_ready,
        "new_title_ready": "Predicting cross-survey chemical-label transportability" in text,
        "old_exact_replay_failure_claim_removed": "exact survey-origin replay could not be reconstructed" not in text,
        "old_runner_incomplete_claim_removed": "archived production runner lineage is incomplete" not in text,
        "d2_exploratory_result_integrated": "0.40993" in text and "0.0014" in text,
        "d4_common_footprint_integrated": "34,177 stars in 208" in text,
        "ni_transport_stable_integrated": r"$[\mathrm{Ni/Fe}]$ is the only label" in text,
        "no_sensitive_claim_integrated": "does not classify any primary label as footprint-sensitive or survey-sensitive" in text,
        "indeterminate_boundary_integrated": "does not mean unstable" in text,
        "obsolete_claim_hierarchy_figure_removed": "figure04_claim_hierarchy.pdf" not in text,
        "input_command_count_zero": text.count(r"\input{")==0 and text.count(r"\include{")==0,
        "bibliography_embedded": r"\begin{thebibliography}" in text,
    }
    if not all(checks.values()):
        raise RuntimeError(f"Static manuscript reconciliation failed: {checks}")

    compile_runs=[]
    pdflatex=shutil.which("pdflatex")
    compile_ready=False
    undefined_citations=None
    undefined_references=None
    if pdflatex:
        for i in range(3):
            pr=subprocess.run(
                [pdflatex,"-interaction=nonstopmode","-halt-on-error","main.tex"],
                cwd=dst,capture_output=True,text=True
            )
            compile_runs.append({
                "run":i+1,"returncode":pr.returncode,
                "stdout_tail":pr.stdout[-3000:],
                "stderr_tail":pr.stderr[-1000:]
            })
            if pr.returncode!=0: break
        log=(dst/"main.log").read_text(encoding="utf-8",errors="ignore") if (dst/"main.log").exists() else ""
        undefined_citations=("undefined citations" in log.lower())
        undefined_references=("undefined references" in log.lower())
        compile_ready=bool(
            len(compile_runs)==3 and all(x["returncode"]==0 for x in compile_runs)
            and (dst/"main.pdf").exists()
            and not undefined_citations and not undefined_references
        )

    report=[
        "# Stage-6D6A manuscript reconciliation",
        "",
        f"- Baseline: `{baseline}`",
        f"- Baseline main.tex SHA-256: `{baseline_sha}`",
        f"- Output package: `{dst.name}`",
        f"- D5A prerequisite ready: `{d5_ready}`",
        f"- Static reconciliation: `{all(checks.values())}`",
        f"- pdflatex available: `{bool(pdflatex)}`",
        f"- Compile ready: `{compile_ready}`",
        "",
        "Key changes:",
        "- reframed title/abstract around cross-survey chemical-label transportability;",
        "- added the five-label B_atmos exploratory association;",
        "- replaced the obsolete exact-replay-failure narrative with the closed common-footprint/balance protocol;",
        "- integrated frozen D4B/D4C classifications;",
        "- removed the obsolete claim-hierarchy figure;",
        "- updated Discussion, Conclusions, and Data/Code Availability.",
    ]
    (dst/"STAGE6D6A_RECONCILIATION_REPORT.md").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for fp in sorted(dst.rglob("*")):
        if fp.is_file():
            manifest.append({
                "path":str(fp.relative_to(dst)).replace("\\","/"),
                "size_bytes":fp.stat().st_size,
                "sha256":sha(fp)
            })
    pd.DataFrame(manifest).to_csv(dst/"SHA256SUMS_STAGE6D6A.csv",index=False)

    validation={
        "stage":cfg["stage"],
        "implementation_version":cfg["implementation_version"],
        "timestamp_utc":now(),
        "BASELINE_PACKAGE":str(baseline),
        "BASELINE_MAIN_TEX_SHA256":baseline_sha,
        "BASELINE_MAIN_TEX_IDENTITY_READY":checks["baseline_main_tex_identity_ready"],
        "D5A_PREREQUISITE_READY":d5_ready,
        **{k.upper():v for k,v in checks.items() if k not in ["baseline_main_tex_identity_ready","d5a_prerequisite_ready"]},
        "PDLATEX_AVAILABLE":bool(pdflatex),
        "COMPILE_RUNS":compile_runs,
        "COMPILE_READY":compile_ready,
        "UNDEFINED_CITATIONS_PRESENT":undefined_citations,
        "UNDEFINED_REFERENCES_PRESENT":undefined_references,
        "HUMAN_AUTHOR_METADATA_READY":False,
        "DOI_METADATA_READY":False,
        "STAGE6D6A_MANUSCRIPT_RECONCILIATION_READY":bool(all(checks.values())),
        "STAGE6D6B_FINAL_POLISH_READY":bool(all(checks.values()))
    }
    (out/"validation").mkdir(exist_ok=True)
    wj(out/"validation/stage6d6a_validation.json",validation)

    zpath=out/(dst.name+".zip")
    with zipfile.ZipFile(zpath,"w",zipfile.ZIP_DEFLATED) as z:
        for fp in sorted(dst.rglob("*")):
            if fp.is_file():
                z.write(fp,fp.relative_to(dst))
    validation["OUTPUT_MANUSCRIPT_ZIP"]=str(zpath.relative_to(root)).replace("\\","/")
    validation["OUTPUT_MANUSCRIPT_ZIP_SHA256"]=sha(zpath)
    wj(out/"validation/stage6d6a_validation.json",validation)

    print(json.dumps({"validation":validation},indent=2,ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
