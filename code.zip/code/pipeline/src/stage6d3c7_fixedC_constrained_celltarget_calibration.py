from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.optimize import minimize
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def now():
    return datetime.now(timezone.utc).isoformat()


def rel(path: Path, root: Path):
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def wjson(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def wcsv(path: Path, fields, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as h:
        w = csv.DictWriter(h, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def resolve(path: Path):
    for q in [path, path.with_suffix(".csv"), path.with_suffix(".feather")]:
        if q.exists():
            return q
    return None


def read_table(path: Path):
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower() == ".feather":
        return pd.read_feather(path)
    return pd.read_csv(path)


def fold_of(source_id, k):
    digest = hashlib.sha256(str(source_id).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") % int(k)


def crossfit_cellfixed(frame, cfg):
    X_cont = frame[cfg["feature_fields"]].apply(
        pd.to_numeric, errors="coerce"
    ).to_numpy(float)
    if not np.all(np.isfinite(X_cont)):
        raise RuntimeError("non-finite balancing feature")

    cells = frame[[cfg["cell_field"]]].astype(str).to_numpy()
    y = (frame["survey"] == cfg["galah_label"]).astype(int).to_numpy()
    folds = np.array(
        [fold_of(x, cfg["n_folds"]) for x in frame["source_id"]],
        dtype=int,
    )
    propensity = np.full(len(frame), np.nan)
    fold_rows = []

    for fold in range(int(cfg["n_folds"])):
        test = folds == fold
        train = ~test
        if set(np.unique(y[train]).tolist()) != {0, 1}:
            raise RuntimeError(f"fold {fold} training lacks both surveys")

        scaler = StandardScaler()
        xtr = scaler.fit_transform(X_cont[train])
        xte = scaler.transform(X_cont[test])

        encoder = OneHotEncoder(
            handle_unknown="ignore",
            sparse_output=True,
        )
        ctr = encoder.fit_transform(cells[train])
        cte = encoder.transform(cells[test])

        Xtr = sparse.hstack([sparse.csr_matrix(xtr), ctr], format="csr")
        Xte = sparse.hstack([sparse.csr_matrix(xte), cte], format="csr")

        model = LogisticRegression(
            C=float(cfg["fixed_ridge_C"]),
            solver="lbfgs",
            max_iter=int(cfg["logistic_max_iter"]),
            fit_intercept=True,
            random_state=0,
        )
        model.fit(Xtr, y[train])
        propensity[test] = model.predict_proba(Xte)[:, 1]

        fold_rows.append({
            "fold": fold,
            "train_rows": int(train.sum()),
            "heldout_rows": int(test.sum()),
            "cell_levels": int(len(encoder.categories_[0])),
            "design_columns": int(Xtr.shape[1]),
        })

    if not np.all(np.isfinite(propensity)):
        raise RuntimeError("non-finite OOF propensity")
    return propensity, folds, fold_rows


def standard_overlap_weights(frame, propensity, cfg):
    galah = (frame["survey"] == cfg["galah_label"]).to_numpy()
    raw = np.where(galah, 1.0 - propensity, propensity)
    if np.any(~np.isfinite(raw)) or np.any(raw <= 0):
        raise RuntimeError("invalid overlap weights")

    capped = raw.copy()
    caps = {}
    for survey in cfg["surveys"]:
        mask = (frame["survey"] == survey).to_numpy()
        cap = float(
            np.quantile(
                raw[mask],
                float(cfg["weight_cap_quantile"]),
            )
        )
        capped[mask] = np.minimum(raw[mask], cap)
        caps[survey] = cap

    return raw, capped, caps


def build_cell_stats(frame, capped, cfg):
    stats = []
    for cell, idx0 in frame.groupby(cfg["cell_field"], sort=True).groups.items():
        idx = np.asarray(list(idx0), dtype=int)
        survey_arr = frame.loc[idx, "survey"].astype(str).to_numpy()

        rec = {"cell": cell, "idx": idx}
        totals = {}
        valid = True

        for survey in cfg["surveys"]:
            mask = survey_arr == survey
            sub = frame.loc[
                idx[mask], cfg["feature_fields"]
            ].apply(pd.to_numeric, errors="coerce").to_numpy(float)
            w = np.asarray(capped[idx][mask], float)
            total = float(np.sum(w))
            totals[survey] = total

            if (
                not np.any(mask)
                or total <= 0
                or not np.all(np.isfinite(sub))
            ):
                valid = False
                break

            a = w / total
            rec[survey] = {
                "n": int(mask.sum()),
                "a": a,
                "mu": np.sum(a[:, None] * sub, axis=0),
                "m2": np.sum(a[:, None] * (sub ** 2), axis=0),
                "q": float(np.sum(a ** 2)),
                "pre_total": total,
            }

        if not valid:
            continue

        rec["baseline_target"] = 0.5 * (
            totals[cfg["apogee_label"]]
            + totals[cfg["galah_label"]]
        )
        stats.append(rec)

    return stats


def metrics_from_targets(targets, stats, cfg):
    t = np.asarray(targets, float)
    total = float(np.sum(t))
    if total <= 0:
        raise RuntimeError("non-positive total target mass")

    moments = {}
    ess_ratios = {}

    for survey in cfg["surveys"]:
        MU = np.vstack([c[survey]["mu"] for c in stats])
        M2 = np.vstack([c[survey]["m2"] for c in stats])
        mean = np.sum(t[:, None] * MU, axis=0) / total
        second = np.sum(t[:, None] * M2, axis=0) / total
        var = np.maximum(second - mean ** 2, 0.0)
        moments[survey] = (mean, var)

        q = np.array([c[survey]["q"] for c in stats], float)
        survey_ess = (total ** 2) / np.sum((t ** 2) * q)
        raw_n = sum(c[survey]["n"] for c in stats)
        ess_ratios[survey] = float(survey_ess / raw_n)

    ma, va = moments[cfg["apogee_label"]]
    mg, vg = moments[cfg["galah_label"]]
    pooled = np.sqrt(0.5 * (va + vg))
    smd = np.divide(
        mg - ma,
        pooled,
        out=np.full_like(mg, np.nan),
        where=pooled > 0,
    )

    return {
        "smd": smd,
        "max_abs_smd": float(np.nanmax(np.abs(smd))),
        "ess_ratios": ess_ratios,
    }


def independent_row_basis(A, rtol=1e-10):
    """
    Return an orthonormal basis for row(A). Enforcing B @ t = 0 is
    equivalent to enforcing A @ t = 0, without redundant constraints.
    """
    A = np.asarray(A, float)
    if A.size == 0:
        return np.empty((0, A.shape[1]), float)
    _, s, vh = np.linalg.svd(A, full_matrices=False)
    if len(s) == 0:
        return np.empty((0, A.shape[1]), float)
    tol = max(A.shape) * s[0] * rtol
    rank = int(np.sum(s > tol))
    return vh[:rank, :]


def zero_moment_reference(stats, cfg):
    t0 = np.array([c["baseline_target"] for c in stats], float)
    total0 = float(np.sum(t0))

    D = np.vstack([
        c[cfg["galah_label"]]["mu"]
        - c[cfg["apogee_label"]]["mu"]
        for c in stats
    ])
    scale = np.nanstd(D, axis=0)
    scale[~np.isfinite(scale) | (scale <= 0)] = 1.0
    Ds = D / scale

    # A @ t = 0 where A = Ds.T. Replace with an independent row-space basis.
    A = Ds.T
    B = independent_row_basis(A)

    lower = np.maximum(
        t0 * float(cfg["target_ratio_lower_bound"]),
        1e-12,
    )
    upper = t0 * float(cfg["target_ratio_upper_bound"])

    def objective(t):
        ratio = t / t0
        return float(np.sum(t * np.log(ratio) - t + t0))

    def gradient(t):
        return np.log(t / t0)

    constraints = [{
        "type": "eq",
        "fun": lambda t: np.array([np.sum(t) - total0]),
    }]
    for j in range(B.shape[0]):
        constraints.append({
            "type": "eq",
            "fun": lambda t, j=j: np.array([np.dot(B[j], t)]),
        })

    result = minimize(
        objective,
        t0.copy(),
        jac=gradient,
        method="SLSQP",
        bounds=[
            (float(lo), float(hi))
            for lo, hi in zip(lower, upper)
        ],
        constraints=constraints,
        options={
            "maxiter": int(cfg["optimizer_maxiter"]),
            "ftol": float(cfg["optimizer_ftol"]),
            "disp": False,
        },
    )

    metrics = metrics_from_targets(result.x, stats, cfg)
    return result, result.x, t0, metrics, int(B.shape[0])


def continuation_frontier(t0, t1, stats, cfg):
    rows = []
    first_feasible = None
    grid = np.linspace(
        0.0,
        1.0,
        int(cfg["continuation_grid_size"]),
    )

    for alpha in grid:
        t = (1.0 - alpha) * t0 + alpha * t1
        met = metrics_from_targets(t, stats, cfg)

        smd_pass = (
            met["max_abs_smd"]
            <= float(cfg["maximum_absolute_smd_gate"])
        )
        ess_pass = all(
            x >= float(cfg["minimum_ess_raw_ratio_gate"])
            for x in met["ess_ratios"].values()
        )
        feasible = bool(smd_pass and ess_pass)

        row = {
            "alpha": float(alpha),
            "maximum_absolute_smd": met["max_abs_smd"],
            "APOGEE_ESS_raw_ratio":
                met["ess_ratios"][cfg["apogee_label"]],
            "GALAH_ESS_raw_ratio":
                met["ess_ratios"][cfg["galah_label"]],
            "smd_gate_pass": smd_pass,
            "ess_gate_pass": ess_pass,
            "joint_gate_pass": feasible,
        }
        rows.append(row)

        if feasible and first_feasible is None:
            first_feasible = (float(alpha), t.copy(), met)

    return rows, first_feasible


def constrained_min_kl(stats, start, cfg):
    t0 = np.array([c["baseline_target"] for c in stats], float)
    total0 = float(np.sum(t0))
    lower = np.maximum(
        t0 * float(cfg["target_ratio_lower_bound"]),
        1e-12,
    )
    upper = t0 * float(cfg["target_ratio_upper_bound"])

    def objective(t):
        ratio = t / t0
        return float(np.sum(t * np.log(ratio) - t + t0))

    def gradient(t):
        return np.log(t / t0)

    constraints = [{
        "type": "eq",
        "fun": lambda t: np.array([np.sum(t) - total0]),
    }]

    gate = float(cfg["maximum_absolute_smd_gate"])
    for j in range(len(cfg["feature_fields"])):
        constraints.append({
            "type": "ineq",
            "fun": lambda t, j=j: (
                gate - metrics_from_targets(t, stats, cfg)["smd"][j]
            ),
        })
        constraints.append({
            "type": "ineq",
            "fun": lambda t, j=j: (
                gate + metrics_from_targets(t, stats, cfg)["smd"][j]
            ),
        })

    for survey in cfg["surveys"]:
        constraints.append({
            "type": "ineq",
            "fun": lambda t, survey=survey: (
                metrics_from_targets(t, stats, cfg)["ess_ratios"][survey]
                - float(cfg["minimum_ess_raw_ratio_gate"])
            ),
        })

    result = minimize(
        objective,
        np.asarray(start, float),
        jac=gradient,
        method="SLSQP",
        bounds=[
            (float(lo), float(hi))
            for lo, hi in zip(lower, upper)
        ],
        constraints=constraints,
        options={
            "maxiter": int(cfg["optimizer_maxiter"]),
            "ftol": float(cfg["optimizer_ftol"]),
            "disp": False,
        },
    )

    metrics = metrics_from_targets(result.x, stats, cfg)
    tol = float(cfg["constraint_tolerance"])
    feasible = bool(
        result.success
        and np.all(np.isfinite(result.x))
        and np.all(result.x > 0)
        and abs(np.sum(result.x) - total0)
        <= tol * max(1.0, total0)
        and metrics["max_abs_smd"]
        <= float(cfg["maximum_absolute_smd_gate"]) + tol
        and all(
            x >= float(cfg["minimum_ess_raw_ratio_gate"]) - tol
            for x in metrics["ess_ratios"].values()
        )
    )

    return result, result.x, metrics, feasible


def apply_targets(frame, capped, stats, targets, cfg):
    final = np.full(len(frame), np.nan)
    ledger = []

    for c, target in zip(stats, targets):
        idx = c["idx"]
        survey_arr = frame.loc[idx, "survey"].astype(str).to_numpy()

        row = {
            "cell": c["cell"],
            "baseline_target": c["baseline_target"],
            "calibrated_target": float(target),
            "target_ratio": float(target / c["baseline_target"]),
        }

        for survey in cfg["surveys"]:
            mask = survey_arr == survey
            pre_total = c[survey]["pre_total"]
            factor = float(target / pre_total)
            final[idx[mask]] = capped[idx][mask] * factor
            prefix = (
                "APOGEE"
                if survey == cfg["apogee_label"]
                else "GALAH"
            )
            row[f"{prefix}_factor"] = factor
            row[f"{prefix}_final_total"] = float(
                np.sum(final[idx][mask])
            )

        row["absolute_survey_total_difference"] = abs(
            row["APOGEE_final_total"] - row["GALAH_final_total"]
        )
        ledger.append(row)

    return final, ledger


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3c7_config.json").read_text(
            encoding="utf-8"
        )
    )

    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in [
        "validation", "tables", "diagnostic", "candidate",
        "summaries", "reports"
    ]:
        (out / d).mkdir(parents=True, exist_ok=True)

    prepath = root / cfg["prerequisite_validation"]
    pre = json.loads(prepath.read_text()) if prepath.exists() else {}
    prereq = bool(
        pre.get("STAGE6D3C6_FRONTIER_LOCALIZATION_READY", False)
        and pre.get("classification")
        == "PROPENSITY_RECOVERY_TRADES_OFF_AGAINST_SMD"
        and pre.get("first_propensity_passing_blockers") == ["SMD"]
        and not pre.get("STAGE6D4_SCIENCE_MODELS_READY", True)
    )

    source_path = resolve(root / cfg["common_footprint_source"])
    if not source_path:
        raise FileNotFoundError("D3B1 common-footprint source missing")

    frame = read_table(source_path).reset_index(drop=True)
    required = {
        "source_id", "survey", cfg["cell_field"], *cfg["feature_fields"]
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise RuntimeError(f"missing fields: {missing}")

    propensity, folds, fold_rows = crossfit_cellfixed(frame, cfg)
    frame["d3c7_balance_fold"] = folds
    frame["d3c7_propensity_GALAH_oof"] = propensity

    prop_min = float(np.min(propensity))
    prop_max = float(np.max(propensity))
    propensity_gate_pass = bool(
        prop_min >= float(cfg["propensity_lower_gate"])
        and prop_max <= float(cfg["propensity_upper_gate"])
    )

    raw, capped, caps = standard_overlap_weights(frame, propensity, cfg)
    frame["d3c7_overlap_weight_raw"] = raw
    frame["d3c7_overlap_weight_p99_capped"] = capped

    stats = build_cell_stats(frame, capped, cfg)
    if len(stats) != int(frame[cfg["cell_field"]].nunique()):
        raise RuntimeError(
            "not all retained cells yielded valid two-survey statistics"
        )

    t0 = np.array([c["baseline_target"] for c in stats], float)
    baseline_metrics = metrics_from_targets(t0, stats, cfg)

    zero_res, zero_t, _, zero_metrics, zero_rank = zero_moment_reference(
        stats, cfg
    )

    continuation_rows, first_feasible = continuation_frontier(
        t0, zero_t, stats, cfg
    )

    if first_feasible is not None:
        first_alpha, feasible_start, _ = first_feasible
    else:
        first_alpha = None
        feasible_start = zero_t

    constrained_res, constrained_t, constrained_metrics, constrained_feasible = (
        constrained_min_kl(stats, feasible_start, cfg)
    )

    final_weights, cell_ledger = apply_targets(
        frame, capped, stats, constrained_t, cfg
    )
    frame["d3c7_candidate_balance_weight"] = final_weights

    max_cell_total_diff = max(
        r["absolute_survey_total_difference"] for r in cell_ledger
    )

    final_smd_rows = []
    for feature, value in zip(
        cfg["feature_fields"], constrained_metrics["smd"]
    ):
        final_smd_rows.append({
            "feature": feature,
            "signed_smd": float(value),
            "absolute_smd": float(abs(value)),
            "gate": cfg["maximum_absolute_smd_gate"],
            "gate_passed": bool(
                abs(value)
                <= float(cfg["maximum_absolute_smd_gate"])
                + float(cfg["constraint_tolerance"])
            ),
        })

    all_numeric_gates_pass = bool(
        propensity_gate_pass and constrained_feasible
    )

    wcsv(
        out / "tables/stage6d3c7_crossfit_fold_ledger.csv",
        ["fold", "train_rows", "heldout_rows", "cell_levels", "design_columns"],
        fold_rows,
    )
    wcsv(
        out / "diagnostic/stage6d3c7_continuation_frontier.csv",
        [
            "alpha", "maximum_absolute_smd",
            "APOGEE_ESS_raw_ratio", "GALAH_ESS_raw_ratio",
            "smd_gate_pass", "ess_gate_pass", "joint_gate_pass"
        ],
        continuation_rows,
    )
    wcsv(
        out / "tables/stage6d3c7_final_smd.csv",
        ["feature", "signed_smd", "absolute_smd", "gate", "gate_passed"],
        final_smd_rows,
    )
    wcsv(
        out / "tables/stage6d3c7_cell_target_ledger.csv",
        [
            "cell", "baseline_target", "calibrated_target", "target_ratio",
            "APOGEE_factor", "GALAH_factor",
            "APOGEE_final_total", "GALAH_final_total",
            "absolute_survey_total_difference"
        ],
        cell_ledger,
    )

    candidate_path = (
        out / "candidate/stage6d3c7_diagnostic_balanced_candidate.parquet"
    )
    try:
        frame.to_parquet(candidate_path, index=False)
    except Exception:
        candidate_path = candidate_path.with_suffix(".csv")
        frame.to_csv(candidate_path, index=False)

    if all_numeric_gates_pass:
        classification = (
            "FIXED_C_CONSTRAINED_CELL_TARGET_CALIBRATION_NUMERICALLY_FEASIBLE"
        )
        next_action = (
            "All frozen numeric gates are jointly feasible at C=0.0002 with "
            "standard overlap weights and positive minimal-KL cell-target "
            "calibration. Do not begin D4 yet. Create a formal protocol-closure "
            "stage that explicitly freezes C, overlap-weight semantics, and "
            "the constrained cell-target rule, then rerun once as production."
        )
    else:
        classification = (
            "FIXED_C_CONSTRAINED_CELL_TARGET_CALIBRATION_INFEASIBLE"
        )
        next_action = (
            "Even with the propensity-passing C fixed and substantial ESS "
            "headroom, constrained positive cell-target calibration cannot "
            "simultaneously meet SMD and ESS. Keep D4 blocked and escalate "
            "to a balancing-design protocol revision."
        )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "classification": classification,
        "input_rows": len(frame),
        "cell_count": len(stats),
        "fixed_ridge_C": cfg["fixed_ridge_C"],
        "weight_formula": cfg["weight_formula"],
        "propensity_min": prop_min,
        "propensity_max": prop_max,
        "propensity_gate_pass": propensity_gate_pass,
        "APOGEE_p99_cap": caps[cfg["apogee_label"]],
        "GALAH_p99_cap": caps[cfg["galah_label"]],
        "baseline_maximum_absolute_smd": baseline_metrics["max_abs_smd"],
        "baseline_ess_raw_ratio_by_survey": baseline_metrics["ess_ratios"],
        "zero_moment_reference_optimizer_success": bool(zero_res.success),
        "zero_moment_reference_independent_constraint_rank": zero_rank,
        "zero_moment_reference_maximum_absolute_smd": zero_metrics["max_abs_smd"],
        "zero_moment_reference_ess_raw_ratio_by_survey": zero_metrics["ess_ratios"],
        "continuation_first_jointly_feasible_alpha": first_alpha,
        "constrained_optimizer_success": bool(constrained_res.success),
        "constrained_optimizer_message": str(constrained_res.message),
        "constrained_maximum_absolute_smd": constrained_metrics["max_abs_smd"],
        "constrained_ess_raw_ratio_by_survey": constrained_metrics["ess_ratios"],
        "maximum_cell_equal_total_difference": max_cell_total_diff,
        "minimum_cell_target_ratio": float(np.min(constrained_t / t0)),
        "maximum_cell_target_ratio": float(np.max(constrained_t / t0)),
        "candidate_source": rel(candidate_path, root),
        "STAGE6D3C6_PREREQUISITE_READY": prereq,
        "CORRECTED_CELL_FIXED_EFFECT_PROPENSITY_READY": True,
        "WITHIN_SURVEY_P99_READY": True,
        "STANDARD_OVERLAP_WEIGHTS_READY": True,
        "PROPENSITY_GATE_READY": propensity_gate_pass,
        "EQUAL_SURVEY_TOTAL_PER_CELL_PRESERVED": bool(
            max_cell_total_diff <= 1e-8
        ),
        "MAX_ABS_SMD_LE_0P10_READY": bool(
            constrained_metrics["max_abs_smd"]
            <= float(cfg["maximum_absolute_smd_gate"])
            + float(cfg["constraint_tolerance"])
        ),
        "ESS_RAW_GE_0P35_READY": all(
            x >= float(cfg["minimum_ess_raw_ratio_gate"])
            - float(cfg["constraint_tolerance"])
            for x in constrained_metrics["ess_ratios"].values()
        ),
        "ALL_FROZEN_NUMERIC_GATES_PASS_DIAGNOSTICALLY": all_numeric_gates_pass,
        "NO_FROZEN_THRESHOLD_WEAKENED": True,
        "NO_BALANCING_FEATURE_CHANGED": True,
        "NO_OUTCOME_ABUNDANCE_R_ABSZ_USED": True,
        "FORMAL_PROTOCOL_CLOSURE_REQUIRED": True,
        "DIAGNOSTIC_ONLY": True,
        "PRODUCTION_BALANCED_WEIGHTS_READY": False,
        "STAGE6D3C7_CALIBRATION_AUDIT_READY": prereq,
        "STAGE6D4_SCIENCE_MODELS_READY": False,
    }
    wjson(out / "validation/stage6d3c7_validation.json", validation)

    summary = {
        "classification": classification,
        "baseline": {
            "max_abs_smd": baseline_metrics["max_abs_smd"],
            "ess_raw_ratio_by_survey": baseline_metrics["ess_ratios"],
        },
        "constrained_candidate": {
            "propensity_range": [prop_min, prop_max],
            "max_abs_smd": constrained_metrics["max_abs_smd"],
            "ess_raw_ratio_by_survey": constrained_metrics["ess_ratios"],
            "first_feasible_continuation_alpha": first_alpha,
            "cell_target_ratio_range": [
                float(np.min(constrained_t / t0)),
                float(np.max(constrained_t / t0)),
            ],
            "all_numeric_gates_pass": all_numeric_gates_pass,
            "production_authorized": False,
        },
        "next_action": next_action,
        "scientific_disposition": (
            "This stage tests the exact remaining D3C6 trade-off at fixed "
            "propensity-passing C. It is diagnostic and does not itself amend "
            "the frozen protocol."
        ),
    }
    wjson(out / "summaries/stage6d3c7_summary.json", summary)

    (out / "reports/stage6d3c7_report.md").write_text(
        "\n".join([
            "# Stage-6D3C7 fixed-C constrained cell-target calibration",
            "",
            f"- Classification: `{classification}`",
            f"- Fixed ridge C: `{cfg['fixed_ridge_C']}`",
            f"- Propensity range: `[{prop_min}, {prop_max}]`",
            f"- Baseline max |SMD|: `{baseline_metrics['max_abs_smd']}`",
            f"- Constrained max |SMD|: `{constrained_metrics['max_abs_smd']}`",
            f"- Constrained APOGEE ESS/raw: "
            f"`{constrained_metrics['ess_ratios'][cfg['apogee_label']]}`",
            f"- Constrained GALAH ESS/raw: "
            f"`{constrained_metrics['ess_ratios'][cfg['galah_label']]}`",
            f"- First feasible continuation alpha: `{first_alpha}`",
            f"- All frozen numeric gates pass: `{all_numeric_gates_pass}`",
            "- Production weights authorized: `False`",
            "- Stage-6D4 authorized: `False`",
            "",
            next_action,
            "",
        ]),
        encoding="utf-8",
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
