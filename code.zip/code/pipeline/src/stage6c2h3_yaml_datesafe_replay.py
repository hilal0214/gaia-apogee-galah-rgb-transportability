from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import math
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

def snapshot(paths: list[Path], root: Path, phase: str) -> list[dict[str, Any]]:
    return [{
        "phase": phase,
        "path": safe_rel(path, root),
        "exists": str(path.exists()).lower(),
        "size_bytes": path.stat().st_size if path.exists() else "",
        "sha256": sha256_file(path) if path.exists() else ""
    } for path in paths]

def locate_replay_csv(shadow_output: Path) -> Path | None:
    hits = list(shadow_output.rglob("stage4b_global_gradient_estimates.csv"))
    if not hits:
        hits = list(shadow_output.rglob("*global*gradient*estimate*.csv"))
    if not hits:
        return None
    return sorted(hits, key=lambda p: (p.stat().st_mtime, p.stat().st_size), reverse=True)[0]

def compare_tables(authoritative_path: Path, replay_path: Path, abs_tol: float, rel_tol: float):
    a = pd.read_csv(authoritative_path)
    b = pd.read_csv(replay_path)
    schema_identity = list(a.columns) == list(b.columns)
    row_count_identity = len(a) == len(b)

    keys = [c for c in ["label", "model_id"] if c in a.columns and c in b.columns]
    if keys:
        a = a.sort_values(keys).reset_index(drop=True)
        b = b.sort_values(keys).reset_index(drop=True)
    else:
        a = a.reset_index(drop=True)
        b = b.reset_index(drop=True)

    common = [c for c in a.columns if c in b.columns]
    column_rows = []
    numeric_identity = True
    non_numeric_identity = True

    for col in common:
        if not row_count_identity:
            column_rows.append({
                "column": col, "type": "uncompared",
                "max_abs_difference": "", "max_relative_difference": "",
                "passed": "false"
            })
            numeric_identity = False
            non_numeric_identity = False
            continue

        sa, sb = a[col], b[col]
        is_bool = pd.api.types.is_bool_dtype(sa.dtype) or pd.api.types.is_bool_dtype(sb.dtype)
        na = pd.to_numeric(sa, errors="coerce")
        nb = pd.to_numeric(sb, errors="coerce")
        is_numeric = (
            not is_bool
            and na.notna().sum() == sa.notna().sum()
            and nb.notna().sum() == sb.notna().sum()
            and (sa.notna().sum() > 0 or sb.notna().sum() > 0)
        )

        if is_numeric:
            finite = na.notna() & nb.notna()
            nan_identity = na.isna().equals(nb.isna())
            if finite.any():
                av = na[finite].astype(float)
                bv = nb[finite].astype(float)
                diff = (av - bv).abs()
                max_abs = float(diff.max())
                denom = av.abs().clip(lower=abs_tol)
                max_rel = float((diff / denom).max())
            else:
                max_abs = max_rel = 0.0
            passed = nan_identity and max_abs <= abs_tol and max_rel <= rel_tol
            numeric_identity &= passed
            column_rows.append({
                "column": col, "type": "numeric",
                "max_abs_difference": max_abs,
                "max_relative_difference": max_rel,
                "passed": str(bool(passed)).lower()
            })
        else:
            passed = sa.fillna("<NA>").astype(str).equals(sb.fillna("<NA>").astype(str))
            non_numeric_identity &= passed
            column_rows.append({
                "column": col, "type": "string_or_bool",
                "max_abs_difference": "", "max_relative_difference": "",
                "passed": str(bool(passed)).lower()
            })

    row_rows = []
    for i in range(max(len(a), len(b))):
        ar = a.iloc[i] if i < len(a) else None
        br = b.iloc[i] if i < len(b) else None
        key = ""
        if keys and ar is not None:
            key = "|".join(str(ar[k]) for k in keys)
        elif keys and br is not None:
            key = "|".join(str(br[k]) for k in keys)

        mismatches = []
        if ar is None or br is None:
            mismatches = ["__row_presence__"]
        else:
            for col in common:
                av, bv = ar[col], br[col]
                if pd.isna(av) and pd.isna(bv):
                    continue
                if pd.api.types.is_bool_dtype(a[col].dtype) or pd.api.types.is_bool_dtype(b[col].dtype):
                    if bool(av) != bool(bv):
                        mismatches.append(col)
                    continue
                try:
                    if not math.isclose(float(av), float(bv), rel_tol=rel_tol, abs_tol=abs_tol):
                        mismatches.append(col)
                except Exception:
                    if str(av) != str(bv):
                        mismatches.append(col)

        row_rows.append({
            "row_index": i,
            "key": key,
            "mismatch_count": len(mismatches),
            "mismatch_columns": "|".join(mismatches),
            "passed": str(len(mismatches) == 0).lower()
        })

    row_identity = all(r["passed"] == "true" for r in row_rows)
    scientific_identity = (
        schema_identity and row_count_identity and numeric_identity
        and non_numeric_identity and row_identity
    )
    comparison = {
        "authoritative_path": str(authoritative_path),
        "replay_path": str(replay_path),
        "authoritative_sha256": sha256_file(authoritative_path),
        "replay_sha256": sha256_file(replay_path),
        "bitwise_identity": sha256_file(authoritative_path) == sha256_file(replay_path),
        "authoritative_rows": len(a),
        "replay_rows": len(b),
        "schema_identity": schema_identity,
        "row_count_identity": row_count_identity,
        "numeric_identity": numeric_identity,
        "non_numeric_identity": non_numeric_identity,
        "row_identity": row_identity,
        "scientific_identity": scientific_identity
    }
    return comparison, column_rows, row_rows

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads((root / "config/stage6c2h3_config.json").read_text(encoding="utf-8"))
    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for d in ["validation", "summaries", "tables", "reports", "shadow/config"]:
        (out_dir / d).mkdir(parents=True, exist_ok=True)

    exact_script = root / cfg["exact_script"]
    original_config = root / cfg["original_config"]
    temporary_config = root / cfg["temporary_config"]
    authoritative = root / cfg["authoritative_estimates"]
    draws = root / cfg["authoritative_draws"]
    shadow_output = out_dir / cfg["shadow_output_subdir"]
    shadow_output.mkdir(parents=True, exist_ok=True)

    required = [exact_script, original_config, authoritative]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing required files: " + "; ".join(missing))

    protected = [original_config, authoritative] + ([draws] if draws.exists() else [])
    integrity_rows = snapshot(protected, root, "before")

    original = yaml.safe_load(original_config.read_text(encoding="utf-8"))
    if not isinstance(original, dict) or not isinstance(original.get("paths"), dict):
        raise RuntimeError("Invalid Stage-4B config paths mapping.")
    for key in ["stage4a_output_dir", "output_dir", "log_dir"]:
        if key not in original["paths"]:
            raise RuntimeError(f"Missing paths.{key}")

    # Preserve YAML-native scalar types (for example datetime.date) while
    # making an independent mutable copy of the frozen configuration.
    patched = copy.deepcopy(original)
    old_output = patched["paths"]["output_dir"]
    patched["paths"]["output_dir"] = str(shadow_output).replace("\\", "/")

    config_rows = [
        {
            "config_path": "$.paths.stage4a_output_dir",
            "original_value": original["paths"]["stage4a_output_dir"],
            "shadow_value": patched["paths"]["stage4a_output_dir"],
            "expected_to_change": "false",
            "passed": str(
                original["paths"]["stage4a_output_dir"]
                == patched["paths"]["stage4a_output_dir"]
            ).lower()
        },
        {
            "config_path": "$.paths.output_dir",
            "original_value": old_output,
            "shadow_value": patched["paths"]["output_dir"],
            "expected_to_change": "true",
            "passed": str(old_output != patched["paths"]["output_dir"]).lower()
        },
        {
            "config_path": "$.paths.log_dir",
            "original_value": original["paths"]["log_dir"],
            "shadow_value": patched["paths"]["log_dir"],
            "expected_to_change": "false",
            "passed": str(
                original["paths"]["log_dir"]
                == patched["paths"]["log_dir"]
            ).lower()
        }
    ]
    strict_config_ready = all(r["passed"] == "true" for r in config_rows)
    write_csv(
        out_dir / "tables/stage6c2h3_config_identity.csv",
        ["config_path", "original_value", "shadow_value", "expected_to_change", "passed"],
        config_rows
    )
    if not strict_config_ready:
        raise RuntimeError("Strict input/output path policy failed.")

    if temporary_config.exists():
        temporary_config.unlink()
    temporary_config.write_text(
        yaml.safe_dump(patched, sort_keys=False, allow_unicode=True),
        encoding="utf-8"
    )
    shutil.copy2(temporary_config, out_dir / "shadow/config" / temporary_config.name)

    command = [sys.executable, str(exact_script), "--config", str(temporary_config)]
    execution = {
        "command": subprocess.list2cmdline(command),
        "cwd": str(root),
        "returncode": -1,
        "stdout": "",
        "stderr": ""
    }
    try:
        completed = subprocess.run(
            command,
            cwd=root,
            capture_output=True,
            text=True,
            timeout=int(cfg["execution_timeout_seconds"])
        )
        execution.update({
            "returncode": completed.returncode,
            "stdout": completed.stdout,
            "stderr": completed.stderr
        })
    except Exception as exc:
        execution["stderr"] = f"{type(exc).__name__}: {exc}"
    finally:
        temporary_config.unlink(missing_ok=True)

    write_csv(
        out_dir / "tables/stage6c2h3_execution_audit.csv",
        ["command", "cwd", "returncode", "stdout", "stderr"],
        [execution]
    )

    integrity_rows += snapshot(protected, root, "after")
    write_csv(
        out_dir / "tables/stage6c2h3_integrity_audit.csv",
        ["phase", "path", "exists", "size_bytes", "sha256"],
        integrity_rows
    )
    before = {r["path"]: r["sha256"] for r in integrity_rows if r["phase"] == "before"}
    after = {r["path"]: r["sha256"] for r in integrity_rows if r["phase"] == "after"}
    frozen_integrity_ready = before == after

    execution_ready = execution["returncode"] == 0
    replay_path = locate_replay_csv(shadow_output) if execution_ready else None
    replay_generated = replay_path is not None

    comparison = {
        "schema_identity": False,
        "row_count_identity": False,
        "numeric_identity": False,
        "non_numeric_identity": False,
        "row_identity": False,
        "scientific_identity": False,
        "reason": "replay_table_not_generated"
    }
    column_rows = []
    row_rows = []
    if replay_path is not None:
        comparison, column_rows, row_rows = compare_tables(
            authoritative,
            replay_path,
            float(cfg["absolute_numeric_tolerance"]),
            float(cfg["relative_numeric_tolerance"])
        )

    write_json(out_dir / "summaries/stage6c2h3_replay_comparison.json", comparison)
    write_csv(
        out_dir / "tables/stage6c2h3_column_identity.csv",
        ["column", "type", "max_abs_difference", "max_relative_difference", "passed"],
        column_rows
    )
    write_csv(
        out_dir / "tables/stage6c2h3_row_identity.csv",
        ["row_index", "key", "mismatch_count", "mismatch_columns", "passed"],
        row_rows
    )

    identity_ready = bool(comparison.get("scientific_identity", False))
    exact_ready = (
        strict_config_ready and execution_ready and replay_generated
        and frozen_integrity_ready and identity_ready
    )

    remaining = []
    if not execution_ready:
        remaining.append({
            "gate": "EXACT_STAGE4B_COMMAND_EXECUTED",
            "required_action": "Inspect stage6c2h3_execution_audit.csv."
        })
    if not replay_generated:
        remaining.append({
            "gate": "SHADOW_REPLAY_TABLE_GENERATED",
            "required_action": "Inspect the execution audit and output convention."
        })
    if not frozen_integrity_ready:
        remaining.append({
            "gate": "FROZEN_STAGE4B_INTEGRITY_READY",
            "required_action": "Restore changed protected files."
        })
    if replay_generated and not identity_ready:
        remaining.append({
            "gate": "GLOBAL_REPLAY_IDENTITY_READY",
            "required_action": "Inspect column and row identity tables."
        })
    write_csv(
        out_dir / "tables/stage6c2h3_remaining_closure_items.csv",
        ["gate", "required_action"],
        remaining
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "exact_script": safe_rel(exact_script, root),
        "original_config": safe_rel(original_config, root),
        "shadow_config_copy": safe_rel(out_dir / "shadow/config" / temporary_config.name, root),
        "shadow_output": safe_rel(shadow_output, root),
        "execution_returncode": execution["returncode"],
        "replay_table": safe_rel(replay_path, root) if replay_path else "",
        "prior_stage_outputs_modified": not frozen_integrity_ready,
        "STAGE4A_INPUT_PATH_PRESERVED": config_rows[0]["passed"] == "true",
        "ONLY_STAGE4B_OUTPUT_PATH_REDIRECTED": strict_config_ready,
        "EXACT_STAGE4B_COMMAND_EXECUTED": execution_ready,
        "SHADOW_REPLAY_TABLE_GENERATED": replay_generated,
        "FROZEN_STAGE4B_INTEGRITY_READY": frozen_integrity_ready,
        "GLOBAL_REPLAY_SCHEMA_IDENTITY_READY": bool(comparison.get("schema_identity", False)),
        "GLOBAL_REPLAY_NUMERICAL_IDENTITY_READY": bool(comparison.get("numeric_identity", False)),
        "GLOBAL_REPLAY_ROW_IDENTITY_READY": bool(comparison.get("row_identity", False)),
        "GLOBAL_REPLAY_IDENTITY_READY": identity_ready,
        "EXACT_REPLAY_SPEC_READY": exact_ready,
        "T06_EXACT_REPLAY_READY": exact_ready
    }
    write_json(out_dir / "validation/stage6c2h3_validation.json", validation)

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "command": execution["command"],
        "replay_comparison": comparison,
        "remaining_closure_items": remaining,
        "scientific_disposition": (
            "Exact Stage-4B replay identity is closed. Stage-6D1 is authorized."
            if exact_ready else
            "Exact replay remains blocked; do not start matched-footprint inference."
        )
    }
    write_json(out_dir / "summaries/stage6c2h3_summary.json", summary)

    report = [
        "# Stage-6C2H3 YAML date-safe exact replay",
        "",
        f"- Stage-4A input path preserved: `{validation['STAGE4A_INPUT_PATH_PRESERVED']}`",
        f"- Only Stage-4B output redirected: `{validation['ONLY_STAGE4B_OUTPUT_PATH_REDIRECTED']}`",
        f"- Command return code: `{execution['returncode']}`",
        f"- Replay generated: `{replay_generated}`",
        f"- Frozen integrity: `{frozen_integrity_ready}`",
        f"- Scientific identity: `{identity_ready}`",
        "",
        "Stage-6D work is authorized only when GLOBAL_REPLAY_IDENTITY_READY is true.",
        ""
    ]
    (out_dir / "reports/stage6c2h3_yaml_datesafe_replay.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
