from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8"
    )

def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

def read_columns(path: Path) -> tuple[list[str], int]:
    if path.suffix.lower() == ".parquet":
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(path)
        return list(pf.schema_arrow.names), int(pf.metadata.num_rows)
    frame = pd.read_csv(path, nrows=5)
    return list(frame.columns), -1

def read_table(path: Path, columns: list[str] | None = None) -> pd.DataFrame:
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path, columns=columns)
    return pd.read_csv(path, usecols=columns)

def find_alias(columns: list[str], options: list[str]) -> str | None:
    lookup = {column.lower(): column for column in columns}
    for option in options:
        if option.lower() in lookup:
            return lookup[option.lower()]
    return None

def pair_map(columns: list[str], cfg: dict[str, Any]) -> dict[str, dict[str, str]]:
    lookup = {column.lower(): column for column in columns}
    result: dict[str, dict[str, str]] = {}
    for label in cfg["primary_labels"]:
        row = {}
        for survey in ["apogee", "galah"]:
            for pattern in cfg["pair_patterns"][survey]:
                candidate = pattern.format(label=label).lower()
                if candidate in lookup:
                    row[survey] = lookup[candidate]
                    break
        if set(row) == {"apogee", "galah"}:
            result[label] = row
    return result

def classify(path: Path, columns: list[str], cfg: dict[str, Any]) -> dict[str, Any]:
    aliases = cfg["aliases"]
    mapping = {
        key: find_alias(columns, values)
        for key, values in aliases.items()
    }
    pairs = pair_map(columns, cfg)
    path_text = safe_rel(path, path.anchor and Path(path.anchor) or path.parent).lower()

    mandatory = {
        "fold_assignments": bool(mapping["source_id"] and mapping["fold"]),
        "coefficients": bool(
            mapping["label"] and mapping["fold"] and mapping["intercept"]
            and mapping["a_t"] and mapping["a_g"] and mapping["a_fe"]
        ),
        "direct_heldout": bool(
            mapping["label"] and mapping["fold"]
            and (
                mapping["direct_residual"]
                or (mapping["direct_observed"] and mapping["direct_predicted"])
            )
        ),
        "paired_overlap": bool(
            mapping["source_id"] and mapping["teff"] and mapping["logg"]
            and mapping["feh"] and len(pairs) >= 1
        )
    }

    filename_bonus = {
        "fold_assignments": 20 if "fold" in path_text else 0,
        "coefficients": 20 if "coefficient" in path_text or "calibration" in path_text else 0,
        "direct_heldout": 20 if any(token in path_text for token in ["heldout", "oof", "residual"]) else 0,
        "paired_overlap": 20 if any(token in path_text for token in ["overlap", "common"]) else 0
    }

    scores = {
        role: (100 + filename_bonus[role]) if mandatory[role] else -1
        for role in mandatory
    }
    if mandatory["paired_overlap"]:
        scores["paired_overlap"] += 5 * len(pairs)

    return {
        "mapping": mapping,
        "pairs": pairs,
        "mandatory": mandatory,
        "scores": scores
    }

def flatten_mapping(value: Any, prefix: str = "$") -> list[tuple[str, Any]]:
    rows: list[tuple[str, Any]] = []
    if isinstance(value, dict):
        for key, child in value.items():
            rows.extend(flatten_mapping(child, f"{prefix}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            rows.extend(flatten_mapping(child, f"{prefix}[{index}]"))
    else:
        rows.append((prefix, value))
    return rows

def load_any(path: Path) -> Any:
    if path.suffix.lower() == ".json":
        return json.loads(path.read_text(encoding="utf-8"))
    return yaml.safe_load(path.read_text(encoding="utf-8"))

def resolve_model_contract(root: Path, cfg: dict[str, Any]) -> tuple[dict[str, float], str, list[dict[str, Any]]]:
    evidence = []
    found: dict[str, float] = {}
    aliases = cfg["model_contract_aliases"]
    for rel in cfg["model_contract_search"]:
        path = root / rel
        if not path.exists():
            continue
        try:
            value = load_any(path)
        except Exception as exc:
            evidence.append({
                "path": rel, "json_path": "", "key": "",
                "value": "", "accepted": "false",
                "note": f"{type(exc).__name__}: {exc}"
            })
            continue
        for json_path, item in flatten_mapping(value):
            key_text = json_path.lower()
            for target, names in aliases.items():
                if any(name.lower() in key_text for name in names):
                    try:
                        number = float(item)
                    except Exception:
                        continue
                    evidence.append({
                        "path": rel, "json_path": json_path, "key": target,
                        "value": number, "accepted": "true", "note": ""
                    })
                    found.setdefault(target, number)

    required = set(aliases)
    if required.issubset(found):
        return {key: float(found[key]) for key in required}, "project_metadata", evidence

    fallback = cfg["explicit_frozen_model_contract_fallback"]
    contract = {
        "teff_center_k": float(fallback["teff_center_k"]),
        "teff_scale_k": float(fallback["teff_scale_k"]),
        "logg_center_dex": float(fallback["logg_center_dex"]),
        "feh_center_dex": float(fallback["feh_center_dex"])
    }
    evidence.append({
        "path": "config/stage6d2a1_config.json",
        "json_path": "$.explicit_frozen_model_contract_fallback",
        "key": "all",
        "value": json.dumps(contract, sort_keys=True),
        "accepted": "true",
        "note": fallback["origin"]
    })
    return contract, fallback["origin"], evidence

def choose_role(candidates: list[dict[str, Any]], role: str) -> dict[str, Any] | None:
    eligible = [
        row for row in candidates
        if row["mandatory"][role]
    ]
    if not eligible:
        return None
    eligible.sort(
        key=lambda row: (
            -int(row["scores"][role]),
            -int(row["row_count"] if row["row_count"] not in ("", -1) else 0),
            row["path"]
        )
    )
    return eligible[0]

def robust_iqr(series: pd.Series) -> float:
    clean = pd.to_numeric(series, errors="coerce").dropna()
    if clean.empty:
        return float("nan")
    return float(clean.quantile(0.75) - clean.quantile(0.25))

def robust_mad(series: pd.Series) -> float:
    clean = pd.to_numeric(series, errors="coerce").dropna()
    if clean.empty:
        return float("nan")
    median = clean.median()
    return float((clean - median).abs().median())

def select_coefficients(
    frame: pd.DataFrame,
    mapping: dict[str, str | None],
    primary_labels: list[str]
) -> tuple[pd.DataFrame, list[dict[str, Any]], str]:
    rename = {
        source: target for target, source in mapping.items()
        if source and target in {
            "label", "fold", "analysis_set", "model_role",
            "intercept", "a_t", "a_g", "a_fe"
        }
    }
    coefficients = frame.rename(columns=rename).copy()
    coefficients["label"] = coefficients["label"].astype(str).str.lower()
    coefficients = coefficients[coefficients["label"].isin(primary_labels)].copy()
    coefficients["fold"] = pd.to_numeric(coefficients["fold"], errors="coerce")

    adjudication = []
    selected_rows = []
    ambiguity = []
    for (label, fold), group in coefficients.groupby(["label", "fold"], dropna=False):
        scored = group.copy()
        score = pd.Series(0, index=scored.index, dtype=float)
        if "model_role" in scored:
            text = scored["model_role"].fillna("").astype(str).str.lower()
            score += text.str.contains("cross|held|oof", regex=True).astype(int) * 4
            score += text.str.contains("primary|production", regex=True).astype(int)
            score -= text.str.contains("full|all", regex=True).astype(int)
        if "analysis_set" in scored:
            text = scored["analysis_set"].fillna("").astype(str).str.lower()
            score += text.str.contains("common|overlap|calibration", regex=True).astype(int) * 2

        maximum = float(score.max()) if len(score) else 0.0
        winners = scored.loc[score == maximum]
        adjudication.append({
            "label": label,
            "fold": fold,
            "candidate_rows": len(group),
            "maximum_score": maximum,
            "winner_rows": len(winners),
            "selected": str(len(winners) == 1).lower(),
            "model_roles": "|".join(sorted(set(group.get("model_role", pd.Series(dtype=str)).dropna().astype(str)))),
            "analysis_sets": "|".join(sorted(set(group.get("analysis_set", pd.Series(dtype=str)).dropna().astype(str))))
        })
        if len(winners) == 1:
            selected_rows.append(winners.iloc[0])
        else:
            ambiguity.append(f"{label}/fold={fold}")

    if ambiguity:
        return pd.DataFrame(), adjudication, "Ambiguous coefficient rows: " + ", ".join(ambiguity[:20])
    if not selected_rows:
        return pd.DataFrame(), adjudication, "No usable fold-specific coefficient rows."
    selected = pd.DataFrame(selected_rows).reset_index(drop=True)
    return selected, adjudication, ""

def make_support_cell(frame: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    teff_bin = pd.cut(
        pd.to_numeric(frame["teff"], errors="coerce"),
        bins=cfg["support_cells"]["teff_edges"],
        labels=["cool", "warm"], include_lowest=True
    )
    logg_bin = pd.cut(
        pd.to_numeric(frame["logg"], errors="coerce"),
        bins=cfg["support_cells"]["logg_edges"],
        labels=["lowg", "highg"], include_lowest=True
    )
    feh_bin = pd.cut(
        pd.to_numeric(frame["feh"], errors="coerce"),
        bins=cfg["support_cells"]["feh_edges"],
        labels=["metalpoor", "intermediate", "metalrich"], include_lowest=True
    )
    if "snr" in frame:
        snr = pd.to_numeric(frame["snr"], errors="coerce")
        threshold = float(snr.median()) if snr.notna().any() else float("nan")
        snr_bin = pd.Series(np.where(snr >= threshold, "highsnr", "lowsnr"), index=frame.index)
    else:
        snr_bin = pd.Series("snr_na", index=frame.index)
    return (
        teff_bin.astype("string").fillna("teff_na")
        + "__" + logg_bin.astype("string").fillna("logg_na")
        + "__" + feh_bin.astype("string").fillna("feh_na")
        + "__" + snr_bin.astype("string")
    )

def reconstruct_oof_panel(
    root: Path,
    fold_row: dict[str, Any],
    coefficient_row: dict[str, Any],
    overlap_row: dict[str, Any],
    cfg: dict[str, Any],
    contract: dict[str, float]
) -> tuple[pd.DataFrame, pd.DataFrame, list[dict[str, Any]], str]:
    fold_path = root / fold_row["path"]
    coefficient_path = root / coefficient_row["path"]
    overlap_path = root / overlap_row["path"]

    fold_mapping = fold_row["mapping"]
    coefficient_mapping = coefficient_row["mapping"]
    overlap_mapping = overlap_row["mapping"]
    pairs = overlap_row["pairs"]

    fold_columns = sorted(set(
        value for key, value in fold_mapping.items()
        if key in {"source_id", "fold"} and value
    ))
    fold_frame = read_table(fold_path, fold_columns).rename(columns={
        fold_mapping["source_id"]: "source_id",
        fold_mapping["fold"]: "fold"
    })
    fold_frame["source_id"] = pd.to_numeric(fold_frame["source_id"], errors="raise").astype("uint64")
    fold_frame["fold"] = pd.to_numeric(fold_frame["fold"], errors="raise").astype(int)
    if fold_frame["source_id"].duplicated().any():
        return pd.DataFrame(), pd.DataFrame(), [], "Fold assignment source IDs are not unique."

    coefficient_frame = read_table(coefficient_path)
    selected_coefficients, adjudication, coefficient_error = select_coefficients(
        coefficient_frame, coefficient_mapping, cfg["primary_labels"]
    )
    if coefficient_error:
        return pd.DataFrame(), pd.DataFrame(), adjudication, coefficient_error

    overlap_columns = [
        overlap_mapping[key] for key in ["source_id", "teff", "logg", "feh", "snr"]
        if overlap_mapping.get(key)
    ]
    for pair in pairs.values():
        overlap_columns.extend(pair.values())
    overlap_columns = sorted(set(overlap_columns))

    # Preserve original paired abundance columns. A column such as
    # ``apogee_fe_h`` may simultaneously be the Fe/H response value and the
    # atmospheric-metallicity predictor. Renaming it would destroy the pair.
    overlap_raw = read_table(overlap_path, overlap_columns)
    overlap = overlap_raw.copy()
    overlap["source_id"] = pd.to_numeric(
        overlap_raw[overlap_mapping["source_id"]], errors="raise"
    ).astype("uint64")
    overlap["teff"] = pd.to_numeric(
        overlap_raw[overlap_mapping["teff"]], errors="coerce"
    )
    overlap["logg"] = pd.to_numeric(
        overlap_raw[overlap_mapping["logg"]], errors="coerce"
    )
    overlap["feh"] = pd.to_numeric(
        overlap_raw[overlap_mapping["feh"]], errors="coerce"
    )
    if overlap_mapping.get("snr"):
        overlap["snr"] = pd.to_numeric(
            overlap_raw[overlap_mapping["snr"]], errors="coerce"
        )
    if overlap["source_id"].duplicated().any():
        return pd.DataFrame(), pd.DataFrame(), adjudication, "Overlap source IDs are not unique."

    merged = overlap.merge(fold_frame, on="source_id", how="inner", validate="one_to_one")
    if merged.empty:
        return pd.DataFrame(), pd.DataFrame(), adjudication, "Fold assignments and overlap source have zero joined rows."

    merged["support_cell"] = make_support_cell(merged, cfg)
    long_rows = []
    coefficient_lookup = {
        (str(row["label"]).lower(), int(row["fold"])): row
        for _, row in selected_coefficients.iterrows()
    }

    for label, pair in pairs.items():
        if label not in cfg["primary_labels"]:
            continue
        apogee = pd.to_numeric(merged[pair["apogee"]], errors="coerce")
        galah = pd.to_numeric(merged[pair["galah"]], errors="coerce")
        teff = pd.to_numeric(merged["teff"], errors="coerce")
        logg = pd.to_numeric(merged["logg"], errors="coerce")
        feh = pd.to_numeric(merged["feh"], errors="coerce")
        for fold in sorted(merged["fold"].dropna().astype(int).unique()):
            key = (label, int(fold))
            if key not in coefficient_lookup:
                continue
            coefficient = coefficient_lookup[key]
            mask = merged["fold"].astype(int) == int(fold)
            predicted_delta = (
                float(coefficient["intercept"])
                + float(coefficient["a_t"])
                * ((teff[mask] - contract["teff_center_k"]) / contract["teff_scale_k"])
                + float(coefficient["a_g"])
                * (logg[mask] - contract["logg_center_dex"])
                + float(coefficient["a_fe"])
                * (feh[mask] - contract["feh_center_dex"])
            )
            residual = (galah[mask] - apogee[mask]) - predicted_delta
            block = pd.DataFrame({
                "source_id": merged.loc[mask, "source_id"].to_numpy(),
                "label": label,
                "fold": int(fold),
                "support_cell": merged.loc[mask, "support_cell"].astype(str).to_numpy(),
                "apogee_value": apogee[mask].to_numpy(),
                "galah_value": galah[mask].to_numpy(),
                "predicted_delta": predicted_delta.to_numpy(),
                "heldout_residual": residual.to_numpy(),
                "teff": teff[mask].to_numpy(),
                "logg": logg[mask].to_numpy(),
                "feh": feh[mask].to_numpy()
            })
            long_rows.append(block)

    if not long_rows:
        return pd.DataFrame(), pd.DataFrame(), adjudication, "No label-fold OOF rows could be reconstructed."

    long_frame = pd.concat(long_rows, ignore_index=True)
    aggregate_rows = []
    for (label, fold, cell), group in long_frame.groupby(
        ["label", "fold", "support_cell"], dropna=False
    ):
        residual_mad = robust_mad(group["heldout_residual"])
        denominator = robust_iqr(group["apogee_value"])
        q_value = (
            residual_mad / denominator
            if math.isfinite(denominator) and denominator >= cfg["minimum_iqr"]
            else float("nan")
        )
        aggregate_rows.append({
            "label": label,
            "fold": int(fold),
            "support_cell": str(cell),
            "n_rows": len(group),
            "heldout_residual_mad": residual_mad,
            "heldout_residual_median": float(
                pd.to_numeric(group["heldout_residual"], errors="coerce").median()
            ),
            "common_sample_iqr": denominator,
            "Q_heldout": q_value,
            "valid_min_rows": len(group) >= cfg["minimum_rows_per_label_fold_cell"],
            "valid_iqr": math.isfinite(denominator) and denominator >= cfg["minimum_iqr"],
            "reconstruction_origin": "fold_assignments_plus_fold_specific_coefficients_plus_paired_overlap"
        })
    aggregate = pd.DataFrame(aggregate_rows)
    return long_frame, aggregate, adjudication, ""

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    cfg = json.loads((root / "config/stage6d2a1_config.json").read_text(encoding="utf-8"))

    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in ["validation", "summaries", "tables", "panel", "reports"]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg["prerequisite_validation"]
    prereq = json.loads(prereq_path.read_text(encoding="utf-8")) if prereq_path.exists() else {}
    prereq_ready = bool(
        prereq.get("STAGE6D1_PROTOCOL_FROZEN", False)
        and prereq.get("STAGE6D2_DATA_READY", False)
    )

    candidates = []
    suffixes = set(cfg["suffixes"])
    for rel_root in cfg["search_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in suffixes:
                continue
            try:
                columns, row_count = read_columns(path)
                profile = classify(path, columns, cfg)
                candidates.append({
                    "path": safe_rel(path, root),
                    "suffix": path.suffix.lower(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                    "row_count": row_count,
                    "column_count": len(columns),
                    "columns": "|".join(columns),
                    "mapping": profile["mapping"],
                    "pairs": profile["pairs"],
                    "mandatory": profile["mandatory"],
                    "scores": profile["scores"],
                    "read_error": ""
                })
            except Exception as exc:
                candidates.append({
                    "path": safe_rel(path, root),
                    "suffix": path.suffix.lower(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                    "row_count": "",
                    "column_count": "",
                    "columns": "",
                    "mapping": {},
                    "pairs": {},
                    "mandatory": {
                        "fold_assignments": False, "coefficients": False,
                        "direct_heldout": False, "paired_overlap": False
                    },
                    "scores": {
                        "fold_assignments": -1, "coefficients": -1,
                        "direct_heldout": -1, "paired_overlap": -1
                    },
                    "read_error": f"{type(exc).__name__}: {exc}"
                })

    inventory_rows = []
    for row in candidates:
        inventory_rows.append({
            "path": row["path"],
            "suffix": row["suffix"],
            "size_bytes": row["size_bytes"],
            "sha256": row["sha256"],
            "row_count": row["row_count"],
            "column_count": row["column_count"],
            "columns": row["columns"],
            "fold_assignments_ready": str(row["mandatory"]["fold_assignments"]).lower(),
            "coefficients_ready": str(row["mandatory"]["coefficients"]).lower(),
            "direct_heldout_ready": str(row["mandatory"]["direct_heldout"]).lower(),
            "paired_overlap_ready": str(row["mandatory"]["paired_overlap"]).lower(),
            "paired_label_count": len(row["pairs"]),
            "paired_labels": "|".join(sorted(row["pairs"])),
            "mapping": json.dumps(row["mapping"], sort_keys=True),
            "scores": json.dumps(row["scores"], sort_keys=True),
            "read_error": row["read_error"]
        })
    inventory_rows.sort(key=lambda row: row["path"])
    write_csv(
        out / "tables/stage6d2a1_strict_schema_inventory.csv",
        [
            "path", "suffix", "size_bytes", "sha256", "row_count",
            "column_count", "columns", "fold_assignments_ready",
            "coefficients_ready", "direct_heldout_ready",
            "paired_overlap_ready", "paired_label_count", "paired_labels",
            "mapping", "scores", "read_error"
        ],
        inventory_rows
    )

    selected = {
        role: choose_role(candidates, role)
        for role in ["fold_assignments", "coefficients", "direct_heldout", "paired_overlap"]
    }

    selected_rows = []
    for role, row in selected.items():
        selected_rows.append({
            "role": role,
            "selected": str(row is not None).lower(),
            "path": row["path"] if row else "",
            "mandatory_schema_passed": str(row is not None).lower(),
            "score": row["scores"][role] if row else "",
            "paired_label_count": len(row["pairs"]) if row else 0,
            "mapping": json.dumps(row["mapping"], sort_keys=True) if row else ""
        })
    write_csv(
        out / "tables/stage6d2a1_selected_inputs.csv",
        [
            "role", "selected", "path", "mandatory_schema_passed",
            "score", "paired_label_count", "mapping"
        ],
        selected_rows
    )

    contract, contract_origin, contract_evidence = resolve_model_contract(root, cfg)
    write_csv(
        out / "tables/stage6d2a1_model_contract_evidence.csv",
        ["path", "json_path", "key", "value", "accepted", "note"],
        contract_evidence
    )
    write_json(
        out / "summaries/stage6d2a1_model_contract.json",
        {"contract": contract, "origin": contract_origin}
    )

    long_frame = pd.DataFrame()
    aggregate = pd.DataFrame()
    coefficient_adjudication: list[dict[str, Any]] = []
    reconstruction_error = ""
    reconstruction_mode = ""

    if selected["direct_heldout"] is not None:
        reconstruction_mode = "direct_heldout_product_detected_but_not_automatically_preferred"
    elif (
        selected["fold_assignments"] is not None
        and selected["coefficients"] is not None
        and selected["paired_overlap"] is not None
    ):
        reconstruction_mode = "reconstructed_from_frozen_products"
        long_frame, aggregate, coefficient_adjudication, reconstruction_error = reconstruct_oof_panel(
            root,
            selected["fold_assignments"],
            selected["coefficients"],
            selected["paired_overlap"],
            cfg,
            contract
        )
    else:
        reconstruction_error = "One or more mandatory reconstruction roles are missing."

    write_csv(
        out / "tables/stage6d2a1_coefficient_adjudication.csv",
        [
            "label", "fold", "candidate_rows", "maximum_score",
            "winner_rows", "selected", "model_roles", "analysis_sets"
        ],
        coefficient_adjudication
    )

    panel_file = ""
    long_file = ""
    if not long_frame.empty:
        long_csv = out / "panel/stage6d2a1_oof_residual_rows.csv"
        long_frame.to_csv(long_csv, index=False)
        long_file = safe_rel(long_csv, root)
        try:
            long_parquet = out / "panel/stage6d2a1_oof_residual_rows.parquet"
            long_frame.to_parquet(long_parquet, index=False)
        except Exception:
            pass

    if not aggregate.empty:
        panel_csv = out / "panel/label_transportability_panel.csv"
        aggregate.to_csv(panel_csv, index=False)
        panel_file = safe_rel(panel_csv, root)
        try:
            panel_parquet = out / "panel/label_transportability_panel.parquet"
            aggregate.to_parquet(panel_parquet, index=False)
            panel_file = safe_rel(panel_parquet, root)
        except Exception:
            pass

    coverage_rows = []
    for label in cfg["primary_labels"]:
        subset = aggregate[aggregate["label"] == label] if not aggregate.empty else pd.DataFrame()
        if subset.empty:
            valid = pd.DataFrame()
        else:
            valid = subset[
                subset["valid_min_rows"].astype(bool)
                & subset["valid_iqr"].astype(bool)
                & pd.to_numeric(subset["Q_heldout"], errors="coerce").notna()
            ]
        coverage_rows.append({
            "label": label,
            "paired_columns_available": str(
                selected["paired_overlap"] is not None
                and label in selected["paired_overlap"]["pairs"]
            ).lower(),
            "panel_rows": len(subset),
            "valid_panel_rows": len(valid),
            "valid_folds": int(valid["fold"].nunique()) if not valid.empty else 0,
            "ready": str(
                not valid.empty
                and int(valid["fold"].nunique()) >= cfg["minimum_folds"]
            ).lower()
        })
    write_csv(
        out / "tables/stage6d2a1_label_coverage.csv",
        [
            "label", "paired_columns_available", "panel_rows",
            "valid_panel_rows", "valid_folds", "ready"
        ],
        coverage_rows
    )

    valid_labels = sum(row["ready"] == "true" for row in coverage_rows)
    fold_ready = selected["fold_assignments"] is not None
    coefficient_ready = selected["coefficients"] is not None
    overlap_ready = (
        selected["paired_overlap"] is not None
        and len(selected["paired_overlap"]["pairs"]) >= cfg["minimum_labels_for_reconstruction"]
    )
    panel_ready = (
        not aggregate.empty
        and valid_labels >= cfg["minimum_labels_for_reconstruction"]
        and not reconstruction_error
    )

    remaining = []
    if not fold_ready:
        remaining.append({
            "gate": "FOLD_ASSIGNMENT_PRODUCT_READY",
            "required_action": "Locate a source-ID keyed held-out-fold assignment table."
        })
    if not coefficient_ready:
        remaining.append({
            "gate": "FOLD_SPECIFIC_COEFFICIENT_PRODUCT_READY",
            "required_action": (
                "Locate a table containing element, heldout_fold, intercept_dex, "
                "coef_teff_per_1000k, coef_logg_per_dex, and coef_feh_per_dex."
            )
        })
    if not overlap_ready:
        remaining.append({
            "gate": "PAIRED_OVERLAP_SOURCE_READY",
            "required_action": (
                f"Locate a source-level overlap table with atmospheric predictors and paired "
                f"APOGEE/GALAH values for at least {cfg['minimum_labels_for_reconstruction']} labels."
            )
        })
    if reconstruction_error:
        remaining.append({
            "gate": "OOF_RECONSTRUCTION_READY",
            "required_action": reconstruction_error
        })
    if not panel_ready and not reconstruction_error:
        remaining.append({
            "gate": "Q_HELDOUT_LABEL_COVERAGE_READY",
            "required_action": (
                f"At least {cfg['minimum_labels_for_reconstruction']} labels must retain "
                f"{cfg['minimum_folds']} valid folds after support-cell gates."
            )
        })
    write_csv(
        out / "tables/stage6d2a1_remaining_items.csv",
        ["gate", "required_action"],
        remaining
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "candidate_file_count": len(candidates),
        "selected_fold_assignments": selected["fold_assignments"]["path"] if selected["fold_assignments"] else "",
        "selected_coefficients": selected["coefficients"]["path"] if selected["coefficients"] else "",
        "selected_direct_heldout": selected["direct_heldout"]["path"] if selected["direct_heldout"] else "",
        "selected_paired_overlap": selected["paired_overlap"]["path"] if selected["paired_overlap"] else "",
        "paired_label_count": len(selected["paired_overlap"]["pairs"]) if selected["paired_overlap"] else 0,
        "paired_labels": sorted(selected["paired_overlap"]["pairs"]) if selected["paired_overlap"] else [],
        "model_contract": contract,
        "model_contract_origin": contract_origin,
        "reconstruction_mode": reconstruction_mode,
        "reconstruction_error": reconstruction_error,
        "long_oof_file": long_file,
        "panel_file": panel_file,
        "panel_rows": len(aggregate),
        "valid_primary_labels": valid_labels,
        "prior_stage_outputs_modified": False,
        "STAGE6D1A_PREREQUISITE_READY": prereq_ready,
        "STRICT_ROLE_PREDICATES_READY": True,
        "FOLD_ASSIGNMENT_PRODUCT_READY": fold_ready,
        "FOLD_SPECIFIC_COEFFICIENT_PRODUCT_READY": coefficient_ready,
        "PAIRED_OVERLAP_SOURCE_READY": overlap_ready,
        "MODEL_CONTRACT_READY": bool(contract),
        "OOF_RECONSTRUCTION_READY": bool(not long_frame.empty and not reconstruction_error),
        "Q_HELDOUT_PANEL_READY": panel_ready,
        "STAGE6D2A1_CONTRACT_READY": bool(
            prereq_ready and fold_ready and coefficient_ready
            and overlap_ready and panel_ready
        ),
        "STAGE6D2B_MODEL_READY": bool(
            prereq_ready and fold_ready and coefficient_ready
            and overlap_ready and panel_ready
        )
    }
    write_json(
        out / "validation/stage6d2a1_validation.json",
        validation
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "selected_inputs": {
            role: row["path"] if row else ""
            for role, row in selected.items()
        },
        "paired_labels": validation["paired_labels"],
        "model_contract": {
            "values": contract,
            "origin": contract_origin
        },
        "label_coverage": coverage_rows,
        "remaining_items": remaining,
        "scientific_disposition": (
            "Strict OOF reconstruction and Q_heldout panel are closed. Stage-6D2B is authorized."
            if validation["STAGE6D2B_MODEL_READY"] else
            "Strict schema adjudication is complete, but the predictive fit remains blocked by the listed exact-data gap."
        )
    }
    write_json(
        out / "summaries/stage6d2a1_summary.json",
        summary
    )

    report = [
        "# Stage-6D2A1 strict schema adjudication",
        "",
        f"- Fold assignments: `{validation['selected_fold_assignments'] or 'not found'}`",
        f"- Coefficients: `{validation['selected_coefficients'] or 'not found'}`",
        f"- Paired overlap: `{validation['selected_paired_overlap'] or 'not found'}`",
        f"- Paired labels: `{validation['paired_label_count']}`",
        f"- OOF reconstruction: `{validation['OOF_RECONSTRUCTION_READY']}`",
        f"- Q panel ready: `{validation['Q_HELDOUT_PANEL_READY']}`",
        "",
        "Filename evidence never substitutes for a mandatory column predicate.",
        ""
    ]
    (out / "reports/stage6d2a1_strict_schema_adjudication.md").write_text(
        "\n".join(report),
        encoding="utf-8"
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False
    ))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
