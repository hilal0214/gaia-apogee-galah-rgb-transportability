from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

STAGE = "Stage-6B archival release-candidate assembly and manuscript integration audit"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.13.1"

def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()

def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        obj = json.load(f)
    if not isinstance(obj, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return obj

def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def write_csv(path: Path, fieldnames: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)

def safe_rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")

def should_exclude(path: Path, root: Path, out_dir: Path, exclude_names: set[str]) -> bool:
    if path == out_dir or out_dir in path.parents:
        return True
    try:
        rel = path.relative_to(root)
    except ValueError:
        return True
    return any(part.lower() in exclude_names for part in rel.parts)

def discover_includable_files(
    root: Path,
    out_dir: Path,
    include_suffixes: set[str],
    exclude_names: set[str],
    max_bytes: int,
) -> tuple[list[Path], list[dict[str, Any]]]:
    included: list[Path] = []
    excluded: list[dict[str, Any]] = []

    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        if should_exclude(p, root, out_dir, exclude_names):
            continue

        rel = safe_rel(p, root)
        suffix = p.suffix.lower()
        size = p.stat().st_size

        if suffix not in include_suffixes:
            excluded.append({"path": rel, "reason": "suffix_not_allowlisted", "size_bytes": size})
            continue
        if size > max_bytes:
            excluded.append({"path": rel, "reason": "exceeds_size_limit", "size_bytes": size})
            continue

        # Explicitly exclude likely secrets and local artefacts.
        lower_name = p.name.lower()
        if lower_name in {".env", "credentials.json", "token.json", "secrets.json"}:
            excluded.append({"path": rel, "reason": "possible_secret", "size_bytes": size})
            continue
        if any(token in lower_name for token in ["credential", "secret", "apikey", "api_key"]):
            excluded.append({"path": rel, "reason": "possible_secret", "size_bytes": size})
            continue

        included.append(p)

    return included, excluded

def _sanitise_component(value: str, max_chars: int = 36) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._")
    return (cleaned or "file")[:max_chars]

def _short_destination(src: Path, rel: Path, release_root: Path) -> Path:
    digest = hashlib.sha256(str(rel).replace("\\", "/").encode("utf-8")).hexdigest()[:16]
    stem = _sanitise_component(src.stem)
    suffix = src.suffix.lower()
    return release_root / "workflow_long" / f"{digest}_{stem}{suffix}"

def _stream_copy(src: Path, dst: Path, chunk_size: int = 1024 * 1024) -> None:
    """Copy bytes without CopyFile2 metadata handling, which is fragile near MAX_PATH."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    with src.open("rb") as fsrc, dst.open("wb") as fdst:
        while True:
            chunk = fsrc.read(chunk_size)
            if not chunk:
                break
            fdst.write(chunk)

def copy_release_files(
    files: list[Path],
    root: Path,
    release_root: Path,
    preserved_path_limit: int = 210,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    inventory: list[dict[str, Any]] = []
    copy_errors: list[dict[str, Any]] = []

    for src in files:
        rel = src.relative_to(root)
        preserved_dst = release_root / "workflow" / rel
        dst = preserved_dst
        mapping_mode = "preserved"

        # Keep the physical Windows path comfortably below legacy MAX_PATH.
        if len(str(preserved_dst.resolve(strict=False))) > preserved_path_limit:
            dst = _short_destination(src, rel, release_root)
            mapping_mode = "hashed_long_path"

        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        except FileNotFoundError:
            # WinError 3 is commonly raised by CopyFile2 when the destination
            # path exceeds the effective Windows path limit. Retry using both
            # a compact destination and a byte-stream copy.
            dst = _short_destination(src, rel, release_root)
            mapping_mode = "hashed_retry_after_winerror3"
            try:
                _stream_copy(src, dst)
            except OSError as exc:
                copy_errors.append({
                    "source_path": safe_rel(src, root),
                    "attempted_release_path": safe_rel(dst, release_root),
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                })
                continue
        except OSError as exc:
            # Retry any path-related Windows copy error through the compact
            # stream-copy route; record a hard error if the retry also fails.
            dst = _short_destination(src, rel, release_root)
            mapping_mode = "hashed_retry_after_oserror"
            try:
                _stream_copy(src, dst)
            except OSError as retry_exc:
                copy_errors.append({
                    "source_path": safe_rel(src, root),
                    "attempted_release_path": safe_rel(dst, release_root),
                    "error_type": type(retry_exc).__name__,
                    "error": str(retry_exc),
                })
                continue

        inventory.append({
            "source_path": safe_rel(src, root),
            "release_path": safe_rel(dst, release_root),
            "mapping_mode": mapping_mode,
            "size_bytes": dst.stat().st_size,
            "sha256": sha256_file(dst),
        })

    return inventory, copy_errors

def find_manuscript_sources(files: list[Path], root: Path) -> tuple[list[Path], list[Path]]:
    tex_files: list[Path] = []
    bib_files: list[Path] = []
    for p in files:
        rel_lower = safe_rel(p, root).lower()
        if "outputs/" in rel_lower and "manuscript/" not in rel_lower:
            continue
        if p.suffix.lower() == ".tex":
            tex_files.append(p)
        elif p.suffix.lower() == ".bib":
            bib_files.append(p)
    return tex_files, bib_files

def detect_main_tex(tex_files: list[Path]) -> Path | None:
    preferred = [
        p for p in tex_files
        if p.name.lower() in {"main.tex", "manuscript.tex", "paper.tex", "rgb_transportability.tex"}
    ]
    if preferred:
        return sorted(preferred, key=lambda p: (len(p.parts), str(p)))[0]
    for p in tex_files:
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if r"\documentclass" in text and r"\begin{document}" in text:
            return p
    return None

def manuscript_source_map(
    root: Path,
    main_tex: Path | None,
    all_files: list[Path],
) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    if main_tex is None:
        return rows

    text = main_tex.read_text(encoding="utf-8", errors="ignore")
    refs = set()

    patterns = [
        ("input", re.compile(r"\\(?:input|include)\{([^}]+)\}")),
        ("figure", re.compile(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}")),
        ("bibliography", re.compile(r"\\bibliography\{([^}]+)\}")),
        ("resource", re.compile(r"\\addbibresource\{([^}]+)\}")),
    ]

    file_index = {p.name.lower(): p for p in all_files}
    for kind, pattern in patterns:
        for match in pattern.findall(text):
            for token in str(match).split(","):
                token = token.strip()
                if not token:
                    continue
                refs.add((kind, token))

    for kind, token in sorted(refs):
        candidate = (main_tex.parent / token)
        candidates = [candidate]
        if not candidate.suffix:
            if kind in {"input"}:
                candidates.append(candidate.with_suffix(".tex"))
            elif kind in {"bibliography", "resource"}:
                candidates.append(candidate.with_suffix(".bib"))
            elif kind == "figure":
                candidates.extend(candidate.with_suffix(s) for s in [".pdf", ".png", ".jpg", ".jpeg", ".eps"])

        resolved = next((p.resolve() for p in candidates if p.exists()), None)
        if resolved is None:
            resolved = file_index.get(Path(token).name.lower())

        rows.append({
            "reference_type": kind,
            "reference_token": token,
            "resolved_path": safe_rel(resolved, root) if resolved and resolved.exists() and root in resolved.parents else "",
            "exists": "true" if resolved and resolved.exists() else "false",
        })
    return rows

def read_claim_register(stage6a_claims: Path) -> list[dict[str, str]]:
    if not stage6a_claims.exists():
        return []
    with stage6a_claims.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def citation_cff(metadata: dict[str, Any]) -> str:
    creators = metadata.get("creators", [])
    authors = []
    for creator in creators:
        name = str(creator.get("name", "INSERT AUTHOR NAME"))
        orcid = str(creator.get("orcid", "")).strip()
        block = [
            "  - name: " + json.dumps(name, ensure_ascii=False),
        ]
        if orcid and not orcid.upper().startswith("INSERT"):
            block.append("    orcid: " + json.dumps(orcid))
        authors.extend(block)
    if not authors:
        authors = ['  - name: "INSERT AUTHOR NAME"']

    keywords = metadata.get("keywords", [])
    lines = [
        "cff-version: 1.2.0",
        'message: "If you use this workflow, please cite the archived release and the associated paper."',
        "title: " + json.dumps(metadata.get("title", ""), ensure_ascii=False),
        "version: " + json.dumps(metadata.get("version", IMPLEMENTATION_VERSION)),
        "type: software",
        "authors:",
        *authors,
        "keywords:",
        *["  - " + json.dumps(str(k), ensure_ascii=False) for k in keywords],
        "license: " + json.dumps(metadata.get("license", "MIT")),
        "date-released: " + datetime.now(timezone.utc).date().isoformat(),
        "repository-code: INSERT_REPOSITORY_URL",
        "doi: INSERT_EXACT_VERSION_DOI",
        "",
    ]
    return "\n".join(lines)

def codemeta(metadata: dict[str, Any]) -> dict[str, Any]:
    authors = []
    for c in metadata.get("creators", []):
        person = {
            "@type": "Person",
            "name": c.get("name", "INSERT AUTHOR NAME"),
        }
        orcid = str(c.get("orcid", "")).strip()
        if orcid and not orcid.upper().startswith("INSERT"):
            person["@id"] = orcid
        authors.append(person)
    return {
        "@context": "https://doi.org/10.5063/schema/codemeta-2.0",
        "@type": "SoftwareSourceCode",
        "name": metadata.get("title", ""),
        "version": metadata.get("version", IMPLEMENTATION_VERSION),
        "description": (
            "Reproducibility release for a support-aware Gaia–APOGEE–GALAH "
            "red-giant-branch cross-survey calibration and transportability workflow."
        ),
        "license": metadata.get("license", "MIT"),
        "author": authors,
        "keywords": metadata.get("keywords", []),
        "codeRepository": "INSERT_REPOSITORY_URL",
        "identifier": "INSERT_EXACT_VERSION_DOI",
        "datePublished": datetime.now(timezone.utc).date().isoformat(),
        "programmingLanguage": "Python",
        "operatingSystem": ["Windows", "Linux", "macOS"],
    }

def zip_tree(source_dir: Path, zip_path: Path) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        for p in sorted(source_dir.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(source_dir.parent))

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE)
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg_path = root / "config" / "stage6b_config.json"
    if not cfg_path.exists():
        raise FileNotFoundError(f"Missing Stage-6B configuration: {cfg_path}")
    cfg = read_json(cfg_path)

    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for sub in ["validation", "summaries", "tables", "manuscript", "release_candidate", "checksums"]:
        (out_dir / sub).mkdir(parents=True, exist_ok=True)

    stage6a_validation_path = (
        root / "outputs" / "stage6a_claimsafe_closeout" / "validation" / "stage6a_validation.json"
    )
    stage6a_claims_path = (
        root / "outputs" / "stage6a_claimsafe_closeout" / "tables" / "stage6a_claim_ledger.csv"
    )

    stage6a_exists = stage6a_validation_path.exists()
    stage6a = read_json(stage6a_validation_path) if stage6a_exists else {}
    stage6a_ready = bool(stage6a.get("STAGE6A_CLOSEOUT_READY", False))

    include_suffixes = {s.lower() for s in cfg["include_suffixes"]}
    exclude_names = {s.lower() for s in cfg["exclude_dir_names"]}
    max_bytes = int(cfg["max_file_size_mb"]) * 1024 * 1024

    files, excluded = discover_includable_files(
        root=root,
        out_dir=out_dir,
        include_suffixes=include_suffixes,
        exclude_names=exclude_names,
        max_bytes=max_bytes,
    )

    release_name = cfg["release_name"]
    release_root = out_dir / "_rc" / "rgb_rc_v0_13_1"
    release_root.mkdir(parents=True, exist_ok=True)

    inventory, copy_errors = copy_release_files(files, root, release_root)

    metadata = cfg.get("metadata", {})
    (release_root / "CITATION.cff").write_text(citation_cff(metadata), encoding="utf-8")
    write_json(release_root / "codemeta.json", codemeta(metadata))

    release_readme = f"""# {metadata.get('title', release_name)}

Release candidate: **{metadata.get('version', IMPLEMENTATION_VERSION)}**

This compact archive contains code, configuration, protocols, machine-readable validation products,
claim boundaries, and provenance for the Gaia–APOGEE–GALAH RGB transportability workflow.

## Scientific boundary

The archive supports survey- and label-bounded transportability claims only. It does not assert a
universal abundance-scale identity, a selection-function-complete Milky Way abundance atlas, or
fully survey-independent replication.

## Upstream data

Large upstream Gaia, APOGEE, and GALAH catalogues are not redistributed. Use the source identifiers,
query/cache manifests, and workflow documentation retained under `workflow/`.

## DOI placeholders

Replace `INSERT_EXACT_VERSION_DOI` and `INSERT_REPOSITORY_URL` after the release is deposited.
"""
    (release_root / "README.md").write_text(release_readme, encoding="utf-8")

    claim_rows = read_claim_register(stage6a_claims_path)
    write_csv(
        out_dir / "tables" / "stage6b_claim_register.csv",
        ["claim_id", "claim", "status", "evidence_boundary", "prohibited_overstatement"],
        claim_rows,
    )

    tex_files, bib_files = find_manuscript_sources(files, root)
    main_tex = detect_main_tex(tex_files)
    source_map = manuscript_source_map(root, main_tex, files)
    write_csv(
        out_dir / "tables" / "stage6b_manuscript_source_map.csv",
        ["reference_type", "reference_token", "resolved_path", "exists"],
        source_map,
    )

    write_csv(
        out_dir / "tables" / "stage6b_release_inventory.csv",
        ["source_path", "release_path", "mapping_mode", "size_bytes", "sha256"],
        inventory,
    )
    write_csv(
        out_dir / "tables" / "stage6b_exclusion_audit.csv",
        ["path", "reason", "size_bytes"],
        excluded,
    )
    write_csv(
        out_dir / "tables" / "stage6b_copy_error_audit.csv",
        ["source_path", "attempted_release_path", "error_type", "error"],
        copy_errors,
    )

    missing_refs = [r for r in source_map if r["exists"] != "true"]
    manuscript_linkage_ready = bool(main_tex and bib_files and not missing_refs)

    checklist = [
        "# Stage-6B manuscript integration audit",
        "",
        f"- Stage-6A closeout ready: **{stage6a_ready}**",
        f"- Main manuscript source detected: **{bool(main_tex)}**",
        f"- Bibliography file detected: **{bool(bib_files)}**",
        f"- Parsed manuscript references: **{len(source_map)}**",
        f"- Missing referenced sources: **{len(missing_refs)}**",
        f"- Manuscript linkage ready: **{manuscript_linkage_ready}**",
        "",
        "## Required before journal submission",
        "",
        "1. Insert the exact-version Zenodo DOI in the Data and Code Availability statement and release citation.",
        "2. Replace author, ORCID, repository, funding, and licence placeholders.",
        "3. Confirm that every numerical claim in the abstract and conclusions is allowed by the Stage-6A claim ledger.",
        "4. Confirm that every table and figure has a machine-readable source product in the release candidate.",
        "5. Compile the clean manuscript from a fresh directory and inspect all references, figures, tables, and bibliography.",
        "6. Retain the exact release ZIP SHA-256 in the archival record.",
        "",
        "## Gate interpretation",
        "",
        "`STAGE6B_ARCHIVAL_RC_READY` validates the computational archive. "
        "`MANUSCRIPT_LINKAGE_READY` is a separate manuscript-source gate.",
        "",
    ]
    (out_dir / "manuscript" / "STAGE6B_MANUSCRIPT_INTEGRATION.md").write_text(
        "\n".join(checklist), encoding="utf-8"
    )

    # Release-level manifest and internal checksums.
    release_files = [p for p in sorted(release_root.rglob("*")) if p.is_file()]
    release_manifest = {
        "release_name": release_name,
        "version": metadata.get("version", IMPLEMENTATION_VERSION),
        "created_utc": now_utc(),
        "file_count": len(release_files),
        "files": [
            {
                "path": safe_rel(p, release_root),
                "size_bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            }
            for p in release_files
        ],
    }
    write_json(release_root / "RELEASE_MANIFEST.json", release_manifest)

    release_files = [p for p in sorted(release_root.rglob("*")) if p.is_file()]
    internal_sums = [
        f"{sha256_file(p)}  {safe_rel(p, release_root)}"
        for p in release_files
        if p.name != "SHA256SUMS.txt"
    ]
    (release_root / "SHA256SUMS.txt").write_text("\n".join(internal_sums) + "\n", encoding="utf-8")

    zip_path = out_dir / "release_candidate" / f"{release_name}.zip"
    zip_tree(release_root, zip_path)

    unresolved_metadata = any(
        "INSERT_" in p.read_text(encoding="utf-8", errors="ignore")
        for p in [release_root / "CITATION.cff", release_root / "codemeta.json"]
    )

    archival_ready = bool(
        stage6a_ready
        and inventory
        and claim_rows
        and not copy_errors
        and zip_path.exists()
        and zip_path.stat().st_size > 0
    )

    validation = {
        "stage": STAGE,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": now_utc(),
        "project_root": str(root),
        "stage6a_validation_present": stage6a_exists,
        "stage6a_closeout_ready": stage6a_ready,
        "release_inventory_created": bool(inventory),
        "release_inventory_file_count": len(inventory),
        "excluded_file_count": len(excluded),
        "copy_error_count": len(copy_errors),
        "long_path_mapped_file_count": sum(
            row.get("mapping_mode", "") != "preserved" for row in inventory
        ),
        "claim_register_present": bool(claim_rows),
        "release_zip_created": zip_path.exists(),
        "release_zip_size_bytes": zip_path.stat().st_size if zip_path.exists() else 0,
        "release_zip_sha256": sha256_file(zip_path) if zip_path.exists() else "",
        "main_tex_detected": bool(main_tex),
        "bib_detected": bool(bib_files),
        "manuscript_reference_count": len(source_map),
        "missing_manuscript_reference_count": len(missing_refs),
        "metadata_placeholders_remaining": unresolved_metadata,
        "prior_stage_outputs_modified": False,
        "STAGE6B_ARCHIVAL_RC_READY": archival_ready,
        "MANUSCRIPT_LINKAGE_READY": manuscript_linkage_ready,
        "ZENODO_DEPOSIT_READY": bool(archival_ready and manuscript_linkage_ready and not unresolved_metadata),
    }
    write_json(out_dir / "validation" / "stage6b_validation.json", validation)

    summary = {
        "stage": STAGE,
        "timestamp_utc": now_utc(),
        "release_name": release_name,
        "release_zip": safe_rel(zip_path, root),
        "release_file_count": len(inventory),
        "release_zip_size_bytes": validation["release_zip_size_bytes"],
        "release_zip_sha256": validation["release_zip_sha256"],
        "claim_status_counts": {
            status: sum(r.get("status") == status for r in claim_rows)
            for status in ["SUPPORTED", "QUALIFIED", "NOT_CLAIMED"]
        },
        "manuscript": {
            "main_tex": safe_rel(main_tex, root) if main_tex else None,
            "bib_files": [safe_rel(p, root) for p in bib_files],
            "missing_references": missing_refs,
        },
        "scientific_disposition": (
            "Computational release candidate assembled. Resolve metadata placeholders and manuscript linkage before Zenodo deposit."
            if archival_ready
            else "Release candidate is not ready; inspect the Stage-6B validation gates."
        ),
    }
    write_json(out_dir / "summaries" / "stage6b_summary.json", summary)

    # Outer output checksums, excluding the checksum file itself.
    outer_files = [
        p for p in sorted(out_dir.rglob("*"))
        if p.is_file() and p != out_dir / "checksums" / "SHA256SUMS.txt"
    ]
    outer_sums = [
        f"{sha256_file(p)}  {safe_rel(p, out_dir)}"
        for p in outer_files
    ]
    (out_dir / "checksums" / "SHA256SUMS.txt").write_text(
        "\n".join(outer_sums) + "\n", encoding="utf-8"
    )

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    return 0 if archival_ready else 2

if __name__ == "__main__":
    raise SystemExit(main())
