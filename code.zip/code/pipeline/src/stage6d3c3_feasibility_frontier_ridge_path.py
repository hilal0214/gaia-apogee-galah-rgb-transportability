from __future__ import annotations
import argparse,csv,hashlib,json,math,re,shutil
from datetime import datetime,timezone
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

def now(): return datetime.now(timezone.utc).isoformat()
def rel(p,r):
    try:return str(p.resolve().relative_to(r.resolve())).replace("\\","/")
    except:return str(p).replace("\\","/")
def wjson(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def wcsv(p,fields,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("w",newline="",encoding="utf-8") as h:
        w=csv.DictWriter(h,fieldnames=fields,extrasaction="ignore");w.writeheader();w.writerows(rows)
def resolve(p):
    for q in [p,p.with_suffix(".csv"),p.with_suffix(".feather")]:
        if q.exists():return q
    return None
def read_table(p):
    if p.suffix.lower()==".parquet":return pd.read_parquet(p)
    if p.suffix.lower()==".feather":return pd.read_feather(p)
    return pd.read_csv(p)
def fold_of(x,k):
    d=hashlib.sha256(str(x).encode("utf-8")).digest()
    return int.from_bytes(d[:8],"big")%int(k)

def protocol_C_semantics(root,cfg):
    rows=[]; explicit=[]
    patterns=[
        re.compile(r"\b(?:ridge[_ -]?logistic[_ -]?)?C\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)",re.I),
        re.compile(r"\bregulari[sz]ation[^\\n]{0,80}\bC\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)",re.I),
    ]
    for rr in cfg["protocol_search_roots"]:
        b=root/rr
        if not b.exists():continue
        items=[b] if b.is_file() else b.rglob("*")
        for p in items:
            if not p.is_file() or p.suffix.lower() not in set(cfg["protocol_text_suffixes"]) or p.stat().st_size>int(cfg["maximum_protocol_file_bytes"]):continue
            # Exclude this D3C3 package/config and post-D3C diagnostics from governing evidence.
            rp=rel(p,root)
            if "stage6d3c3" in rp.lower():continue
            try:lines=p.read_text(encoding="utf-8",errors="replace").splitlines()
            except:continue
            for i,line in enumerate(lines,1):
                low=line.lower()
                if "ridge" not in low and "logistic" not in low and "regular" not in low and " c" not in low:
                    continue
                vals=[]
                for pat in patterns:
                    vals += pat.findall(line)
                if vals:
                    for val in vals:
                        try:v=float(val)
                        except:continue
                        explicit.append(v)
                        rows.append({"path":rp,"line_number":i,"explicit_C":v,"excerpt":line.strip()[:1400]})
    uniq=sorted(set(explicit))
    if len(uniq)==1:
        semantics="EXPLICIT_SINGLE_RIDGE_C_FOUND"
        frozen_C=uniq[0]
    elif len(uniq)>1:
        semantics="CONFLICTING_EXPLICIT_RIDGE_C_VALUES_FOUND"
        frozen_C=None
    else:
        semantics="NO_EXPLICIT_RIDGE_C_FOUND_IN_FROZEN_MATERIAL"
        frozen_C=None
    return semantics,frozen_C,rows

def crossfit_propensity(frame,C,cfg):
    X=frame[cfg["feature_fields"]].apply(pd.to_numeric,errors="coerce").to_numpy(float)
    if not np.all(np.isfinite(X)):raise RuntimeError("non-finite balancing features")
    y=(frame["survey"]==cfg["galah_label"]).astype(int).to_numpy()
    folds=np.array([fold_of(x,cfg["n_folds"]) for x in frame["source_id"]],int)
    p=np.full(len(frame),np.nan)
    for fold in range(int(cfg["n_folds"])):
        test=folds==fold;train=~test
        if set(np.unique(y[train]).tolist())!={0,1}:raise RuntimeError(f"fold {fold} lacks both surveys")
        sc=StandardScaler();Xt=sc.fit_transform(X[train]);Xh=sc.transform(X[test])
        model=LogisticRegression(
            C=float(C),solver=cfg["logistic_solver"],
            max_iter=int(cfg["logistic_max_iter"]),fit_intercept=True,random_state=0
        )
        model.fit(Xt,y[train]);p[test]=model.predict_proba(Xh)[:,1]
    if not np.all(np.isfinite(p)):raise RuntimeError("non-finite propensity")
    return p,folds

def raw_capped_weights(frame,p,cfg):
    gal=(frame["survey"]==cfg["galah_label"]).to_numpy()
    raw=np.where(gal,1-p,p)
    if np.any(raw<=0) or np.any(~np.isfinite(raw)):raise RuntimeError("invalid overlap weights")
    cap=float(np.quantile(raw,float(cfg["p99_cap_quantile"])))
    return raw,np.minimum(raw,cap),cap

def cell_stats(frame,capped,cfg):
    """
    For each cell/survey, normalize capped row weights to sum 1.
    Store feature first/second moments and concentration q=sum(a_i^2).
    With common cell target t_c, final row weights are t_c*a_i.
    """
    stats=[]
    for cell,idx0 in frame.groupby(cfg["cell_field"],sort=True).groups.items():
        idx=np.asarray(list(idx0),int)
        survey=frame.loc[idx,"survey"].astype(str).to_numpy()
        rec={"cell":cell,"idx":idx}
        valid=True
        totals={}
        for s in cfg["surveys"]:
            m=survey==s
            w=np.asarray(capped[idx][m],float)
            total=float(w.sum());totals[s]=total
            if total<=0 or not np.any(m):valid=False;break
            a=w/total
            sub=frame.loc[idx[m],cfg["feature_fields"]].apply(pd.to_numeric,errors="coerce").to_numpy(float)
            if not np.all(np.isfinite(sub)):valid=False;break
            rec[s]={
                "n":int(m.sum()),
                "total":total,
                "a":a,
                "mu":np.sum(a[:,None]*sub,axis=0),
                "m2":np.sum(a[:,None]*(sub**2),axis=0),
                "q":float(np.sum(a*a)),
            }
        if not valid:continue
        rec["baseline"]=.5*(totals[cfg["apogee_label"]]+totals[cfg["galah_label"]])
        stats.append(rec)
    return stats

def metrics_from_targets(t,stats,cfg):
    t=np.asarray(t,float);T=float(t.sum())
    out={"smd":[],"ess_ratio":{}}
    moments={}
    for s in cfg["surveys"]:
        MU=np.vstack([c[s]["mu"] for c in stats])
        M2=np.vstack([c[s]["m2"] for c in stats])
        mu=(t[:,None]*MU).sum(axis=0)/T
        m2=(t[:,None]*M2).sum(axis=0)/T
        var=np.maximum(m2-mu**2,0)
        moments[s]=(mu,var)
        q=np.array([c[s]["q"] for c in stats],float)
        ess=(T*T)/float(np.sum((t*t)*q))
        raw_n=sum(c[s]["n"] for c in stats)
        out["ess_ratio"][s]=float(ess/raw_n)
    ma,va=moments[cfg["apogee_label"]];mg,vg=moments[cfg["galah_label"]]
    pooled=np.sqrt(.5*(va+vg))
    smd=np.divide(mg-ma,pooled,out=np.full_like(mg,np.nan),where=pooled>0)
    out["smd"]=smd
    out["max_abs_smd"]=float(np.nanmax(np.abs(smd)))
    return out

def optimize_targets(stats,cfg):
    t0=np.array([c["baseline"] for c in stats],float)
    total0=float(t0.sum())
    lo=t0*float(cfg["target_ratio_lower_bound"])
    hi=t0*float(cfg["target_ratio_upper_bound"])
    gate=float(cfg["maximum_absolute_smd_gate"])
    ess_gate=float(cfg["minimum_ess_raw_ratio_gate"])
    def obj(t):
        r=t/t0
        return float(np.sum(t*np.log(r)-t+t0))
    def jac(t):return np.log(t/t0)
    cons=[{"type":"eq","fun":lambda t:np.array([t.sum()-total0])}]
    # Exact frozen SMD constraints (nonlinear because pooled SD changes with t).
    for j in range(len(cfg["feature_fields"])):
        cons.append({"type":"ineq","fun":lambda t,j=j:gate-abs(metrics_from_targets(t,stats,cfg)["smd"][j])})
    for s in cfg["surveys"]:
        cons.append({"type":"ineq","fun":lambda t,s=s:metrics_from_targets(t,stats,cfg)["ess_ratio"][s]-ess_gate})
    res=minimize(
        obj,t0.copy(),jac=jac,method="SLSQP",
        bounds=[(float(a),float(b)) for a,b in zip(lo,hi)],
        constraints=cons,
        options={"maxiter":int(cfg["optimizer_maxiter"]),"ftol":float(cfg["optimizer_ftol"]),"disp":False}
    )
    met=metrics_from_targets(res.x,stats,cfg)
    tol=float(cfg["constraint_tolerance"])
    feasible=bool(
        res.success and np.all(np.isfinite(res.x)) and np.all(res.x>0)
        and abs(res.x.sum()-total0)<=tol*max(1,total0)
        and met["max_abs_smd"]<=gate+tol
        and all(v>=ess_gate-tol for v in met["ess_ratio"].values())
    )
    return res,res.x,t0,met,feasible

def apply_targets(frame,capped,stats,t,cfg):
    out=np.full(len(frame),np.nan)
    ledger=[]
    for c,target in zip(stats,t):
        idx=c["idx"];survey=frame.loc[idx,"survey"].astype(str).to_numpy()
        for s in cfg["surveys"]:
            m=survey==s
            base=capped[idx][m]
            fac=float(target/base.sum())
            out[idx[m]]=base*fac
        ledger.append({
            "cell":c["cell"],"baseline_target":c["baseline"],
            "optimized_target":float(target),
            "target_ratio":float(target/c["baseline"]),
            "APOGEE_final_total":float(out[idx][survey==cfg["apogee_label"]].sum()),
            "GALAH_final_total":float(out[idx][survey==cfg["galah_label"]].sum()),
        })
    return out,ledger

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");args=ap.parse_args()
    root=Path(args.project_root).resolve();cfg=json.loads((root/"config/stage6d3c3_config.json").read_text())
    out=root/cfg["output_dir"]
    if out.exists():shutil.rmtree(out)
    for d in ["validation","tables","diagnostic","summaries","reports"]:(out/d).mkdir(parents=True,exist_ok=True)

    pp=root/cfg["prerequisite_validation"];pre=json.loads(pp.read_text()) if pp.exists() else {}
    prereq=bool(
        pre.get("STAGE6D3C2_RECONCILIATION_READY",False)
        and pre.get("NO_FROZEN_THRESHOLD_WEAKENED",False)
        and not pre.get("STAGE6D4_SCIENCE_MODELS_READY",True)
    )
    sp=resolve(root/cfg["common_footprint_source"])
    if not sp:raise FileNotFoundError("D3B1 common footprint source missing")
    frame=read_table(sp).reset_index(drop=True)

    semantics,frozen_C,protocol_rows=protocol_C_semantics(root,cfg)
    wcsv(out/"tables/stage6d3c3_ridge_C_protocol_evidence.csv",
         ["path","line_number","explicit_C","excerpt"],protocol_rows)

    frontier=[];candidate_payloads=[]
    for C in cfg["ridge_C_grid_descending"]:
        p,folds=crossfit_propensity(frame,C,cfg)
        raw,capped,cap=raw_capped_weights(frame,p,cfg)
        stats=cell_stats(frame,capped,cfg)
        res,t,t0,met,feasible=optimize_targets(stats,cfg)
        prop_min=float(p.min());prop_max=float(p.max())
        prop_pass=bool(prop_min>=float(cfg["propensity_lower_gate"]) and prop_max<=float(cfg["propensity_upper_gate"]))
        all_pass=bool(prop_pass and feasible)
        row={
            "C":float(C),"propensity_min":prop_min,"propensity_max":prop_max,
            "propensity_gate_pass":prop_pass,"p99_cap":cap,
            "cell_count":len(stats),"optimizer_success":bool(res.success),
            "optimizer_message":str(res.message),
            "maximum_absolute_smd":met["max_abs_smd"],
            "APOGEE_ESS_raw_ratio":met["ess_ratio"][cfg["apogee_label"]],
            "GALAH_ESS_raw_ratio":met["ess_ratio"][cfg["galah_label"]],
            "SMD_ESS_cell_target_feasible":feasible,
            "all_frozen_numeric_gates_pass":all_pass,
            "KL_objective":float(res.fun),
            "max_target_ratio":float(np.max(t/t0)),
            "min_target_ratio":float(np.min(t/t0)),
        }
        frontier.append(row)
        if all_pass:
            candidate_payloads.append((float(C),p,capped,stats,t,met,row))

    wcsv(out/"diagnostic/stage6d3c3_ridge_feasibility_frontier.csv",
         ["C","propensity_min","propensity_max","propensity_gate_pass","p99_cap","cell_count",
          "optimizer_success","optimizer_message","maximum_absolute_smd",
          "APOGEE_ESS_raw_ratio","GALAH_ESS_raw_ratio","SMD_ESS_cell_target_feasible",
          "all_frozen_numeric_gates_pass","KL_objective","max_target_ratio","min_target_ratio"],frontier)

    candidate_payloads.sort(key=lambda x:-x[0])
    selected=candidate_payloads[0] if candidate_payloads else None
    if selected:
        C,p,capped,stats,t,met,row=selected
        weights,cell_ledger=apply_targets(frame,capped,stats,t,cfg)
        diag=frame.copy()
        diag["d3c3_candidate_propensity_GALAH_oof"]=p
        diag["d3c3_candidate_balance_weight"]=weights
        path=out/"diagnostic/stage6d3c3_best_numeric_candidate.parquet"
        try:diag.to_parquet(path,index=False)
        except Exception:path=path.with_suffix(".csv");diag.to_csv(path,index=False)
        wcsv(out/"diagnostic/stage6d3c3_best_candidate_cell_targets.csv",
             ["cell","baseline_target","optimized_target","target_ratio","APOGEE_final_total","GALAH_final_total"],cell_ledger)
        selected_summary={"C":C,**row,"diagnostic_source":rel(path,root)}
    else:
        selected_summary={}

    numeric_candidate_ready=selected is not None
    # Changing C is production-eligible only if the protocol does not explicitly fix a different C.
    if semantics=="EXPLICIT_SINGLE_RIDGE_C_FOUND":
        C_change_allowed=bool(
            selected is not None and abs(selected[0]-float(frozen_C))<1e-12
        )
    else:
        C_change_allowed=False

    if numeric_candidate_ready and semantics=="NO_EXPLICIT_RIDGE_C_FOUND_IN_FROZEN_MATERIAL":
        classification="NUMERIC_FEASIBILITY_PROVEN_BUT_RIDGE_HYPERPARAMETER_NOT_FROZEN"
        next_action=(
            "A fully gate-satisfying outcome-blind ridge/weight solution exists, but the "
            "frozen protocol does not specify C. Create a formal protocol clarification/amendment "
            "that freezes the deterministic C-selection rule before any production rerun."
        )
    elif numeric_candidate_ready and semantics=="EXPLICIT_SINGLE_RIDGE_C_FOUND" and C_change_allowed:
        classification="FROZEN_C_NUMERIC_FEASIBILITY_PROVEN"
        next_action=(
            "The explicitly frozen ridge C itself admits a constrained cell-target solution. "
            "Create a narrow production-freeze stage for the optimized positive cell targets."
        )
    elif numeric_candidate_ready and semantics=="EXPLICIT_SINGLE_RIDGE_C_FOUND":
        classification="NUMERIC_CANDIDATE_CONFLICTS_WITH_EXPLICIT_FROZEN_C"
        next_action=(
            "A numeric solution exists only at a C different from the explicitly frozen value. "
            "Do not use it without a formal protocol amendment."
        )
    elif numeric_candidate_ready:
        classification="NUMERIC_FEASIBILITY_PROVEN_BUT_PROTOCOL_C_SEMANTICS_CONFLICT"
        next_action="Resolve conflicting ridge-C protocol evidence before production."
    else:
        classification="NO_FULLY_FEASIBLE_FROZEN_GATE_SOLUTION_ON_RIDGE_PATH"
        next_action=(
            "No tested ridge C plus minimal-KL equal-cell-total calibration satisfies all frozen "
            "numeric gates. Keep D4 blocked and escalate to a higher-level protocol review."
        )

    production_candidate_ready=bool(
        numeric_candidate_ready
        and semantics=="EXPLICIT_SINGLE_RIDGE_C_FOUND"
        and C_change_allowed
    )

    validation={
        "stage":cfg["stage"],"protocol_version":cfg["protocol_version"],
        "implementation_version":cfg["implementation_version"],"timestamp_utc":now(),
        "STAGE6D3C2_PREREQUISITE_READY":prereq,
        "ridge_C_protocol_semantics":semantics,"explicit_frozen_C":frozen_C,
        "tested_C_grid":cfg["ridge_C_grid_descending"],
        "fully_feasible_numeric_candidate_count":len(candidate_payloads),
        "best_numeric_candidate":selected_summary,
        "classification":classification,
        "CELL_TOTAL_EQUALITY_PRESERVED_BY_CONSTRUCTION":True,
        "SMD_GATE_EXACTLY_ENFORCED_NOT_ZERO_FORCED":True,
        "ESS_GATE_EXACTLY_ENFORCED":True,
        "PROPENSITY_GATE_UNCHANGED":True,
        "NO_FROZEN_THRESHOLD_WEAKENED":True,
        "NO_BALANCING_FEATURE_CHANGED":True,
        "NO_OUTCOME_ABUNDANCE_R_ABSZ_USED":True,
        "NUMERIC_FEASIBILITY_FRONTIER_READY":True,
        "PRODUCTION_CANDIDATE_READY_WITHOUT_PROTOCOL_AMENDMENT":production_candidate_ready,
        "DIAGNOSTIC_ONLY":True,
        "STAGE6D3C3_FEASIBILITY_AUDIT_READY":prereq,
        "STAGE6D4_SCIENCE_MODELS_READY":False,
    }
    wjson(out/"validation/stage6d3c3_validation.json",validation)
    summary={
        "classification":classification,
        "best_numeric_candidate":selected_summary,
        "next_action":next_action,
        "scientific_disposition":(
            "This audit asks whether the original frozen numerical gates are jointly feasible "
            "without exact-zero overbalancing. It does not authorize D4."
        )
    }
    wjson(out/"summaries/stage6d3c3_summary.json",summary)
    (out/"reports/stage6d3c3_report.md").write_text(
        "\n".join([
            "# Stage-6D3C3 feasibility frontier / ridge path",
            "",
            f"- Classification: `{classification}`",
            f"- Ridge-C protocol semantics: `{semantics}`",
            f"- Explicit frozen C: `{frozen_C}`",
            f"- Fully feasible numeric candidates: `{len(candidate_payloads)}`",
            f"- Best numeric candidate: `{selected_summary}`",
            "- Stage-6D4 authorized: `False`",
            "",
            next_action,
            "",
        ]),encoding="utf-8"
    )
    print(json.dumps({"validation":validation,"summary":summary},indent=2))
    return 0

if __name__=="__main__":raise SystemExit(main())
