from __future__ import annotations
import argparse,csv,json,math,shutil,re
from datetime import datetime,timezone
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd
from scipy.optimize import minimize

def now(): return datetime.now(timezone.utc).isoformat()
def rel(p,r):
    try:return str(p.resolve().relative_to(r.resolve())).replace("\\","/")
    except:return str(p).replace("\\","/")
def wjson(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def wcsv(p,fields,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("w",newline="",encoding="utf-8") as h:
        w=csv.DictWriter(h,fieldnames=fields,extrasaction="ignore");w.writeheader();w.writerows(rows)
def resolve(p):
    for q in [p,p.with_suffix(".csv"),p.with_suffix(".feather")]:
        if q.exists():return q
    return None
def read_table(p):
    if p.suffix.lower()==".parquet":return pd.read_parquet(p)
    if p.suffix.lower()==".feather":return pd.read_feather(p)
    return pd.read_csv(p)

def normalize_cell_key(value):
    """
    Normalize HEALPix cell identifiers without lossy numeric coercion.

    Handles int, NumPy integer, digit strings, and CSV float-like strings
    such as '596.0' only when they represent an exact integer.
    """
    if value is None:
        raise ValueError("missing cell identifier")
    if isinstance(value, (int, np.integer)):
        return str(int(value))
    if isinstance(value, (float, np.floating)):
        if not np.isfinite(value) or not float(value).is_integer():
            raise ValueError(f"non-integral cell identifier: {value!r}")
        return str(int(value))
    text = str(value).strip()
    if text == "":
        raise ValueError("empty cell identifier")
    if re.fullmatch(r"[+-]?\d+", text):
        return str(int(text))
    if re.fullmatch(r"[+-]?\d+\.0+", text):
        return str(int(text.split(".", 1)[0]))
    raise ValueError(f"unsupported cell identifier representation: {value!r}")
def wmean(x,w):
    x=np.asarray(x,float);w=np.asarray(w,float);ok=np.isfinite(x)&np.isfinite(w)&(w>0)
    return float(np.sum(x[ok]*w[ok])/np.sum(w[ok]))
def wvar(x,w):
    x=np.asarray(x,float);w=np.asarray(w,float);ok=np.isfinite(x)&np.isfinite(w)&(w>0)
    x=x[ok];w=w[ok];m=np.sum(x*w)/np.sum(w)
    return float(np.sum(w*(x-m)**2)/np.sum(w))
def ess(w):
    w=np.asarray(w,float);w=w[np.isfinite(w)&(w>0)]
    d=np.sum(w*w);return float((np.sum(w)**2)/d)
def direct_metrics(frame,weight,cfg):
    rows=[];mx=0.0
    for f in cfg["feature_fields"]:
        x=pd.to_numeric(frame[f],errors="coerce").to_numpy(float);w=pd.to_numeric(frame[weight],errors="coerce").to_numpy(float)
        a=(frame["survey"]==cfg["apogee_label"]).to_numpy();g=(frame["survey"]==cfg["galah_label"]).to_numpy()
        ma=wmean(x[a],w[a]);mg=wmean(x[g],w[g]);va=wvar(x[a],w[a]);vg=wvar(x[g],w[g]);psd=math.sqrt(.5*(va+vg))
        s=(mg-ma)/psd;mx=max(mx,abs(s));rows.append({"feature":f,"signed_smd":s,"absolute_smd":abs(s)})
    ratios={}
    for s in cfg["surveys"]:
        m=frame["survey"]==s;ratios[s]=ess(frame.loc[m,weight].to_numpy(float))/int(m.sum())
    return mx,ratios,rows
def build_stats(frame,cfg):
    out=[]
    for cell,idx0 in frame.groupby(cfg["cell_field"],sort=True).groups.items():
        idx=np.asarray(list(idx0),int);sv=frame.loc[idx,"survey"].astype(str).to_numpy();rec={"cell":cell}
        totals={}
        for s in cfg["surveys"]:
            m=sv==s;w=pd.to_numeric(frame.loc[idx[m],cfg["capped_weight_field"]],errors="coerce").to_numpy(float)
            X=frame.loc[idx[m],cfg["feature_fields"]].apply(pd.to_numeric,errors="coerce").to_numpy(float)
            total=float(w.sum());a=w/total;totals[s]=total
            rec[s]={"n":int(m.sum()),"q":float(np.sum(a*a)),"mu":np.sum(a[:,None]*X,axis=0),"m2":np.sum(a[:,None]*(X**2),axis=0)}
        rec["baseline_target"]=.5*(totals[cfg["apogee_label"]]+totals[cfg["galah_label"]]);out.append(rec)
    return out
def metrics(t,stats,cfg):
    t=np.asarray(t,float);T=float(t.sum());mom={};rat={}
    for s in cfg["surveys"]:
        MU=np.vstack([c[s]["mu"] for c in stats]);M2=np.vstack([c[s]["m2"] for c in stats])
        mu=np.sum(t[:,None]*MU,axis=0)/T;m2=np.sum(t[:,None]*M2,axis=0)/T;var=np.maximum(m2-mu**2,0);mom[s]=(mu,var)
        q=np.array([c[s]["q"] for c in stats],float);e=(T*T)/np.sum((t*t)*q);n=sum(c[s]["n"] for c in stats);rat[s]=float(e/n)
    ma,va=mom[cfg["apogee_label"]];mg,vg=mom[cfg["galah_label"]];pooled=np.sqrt(.5*(va+vg));smd=(mg-ma)/pooled
    return {"smd":smd,"max_abs_smd":float(np.max(np.abs(smd))),"ess_ratios":rat}
def optimize_margin(stats,t0,start,margin,cfg):
    total=float(t0.sum());lo=np.maximum(t0*cfg["target_ratio_lower_bound"],1e-14);hi=t0*cfg["target_ratio_upper_bound"]
    smd_lim=cfg["frozen_smd_gate"]-margin;ess_lim=cfg["frozen_ess_gate"]+margin
    def obj(t):
        r=t/t0;return float(np.sum(t*np.log(r)-t+t0))
    def jac(t):return np.log(t/t0)
    cons=[{"type":"eq","fun":lambda t:np.array([t.sum()-total])}]
    for j in range(len(cfg["feature_fields"])):
        cons.append({"type":"ineq","fun":lambda t,j=j:smd_lim-metrics(t,stats,cfg)["smd"][j]})
        cons.append({"type":"ineq","fun":lambda t,j=j:smd_lim+metrics(t,stats,cfg)["smd"][j]})
    for s in cfg["surveys"]:
        cons.append({"type":"ineq","fun":lambda t,s=s:metrics(t,stats,cfg)["ess_ratios"][s]-ess_lim})
    res=minimize(obj,np.asarray(start,float),jac=jac,method="SLSQP",bounds=[(float(a),float(b)) for a,b in zip(lo,hi)],constraints=cons,
                 options={"maxiter":cfg["optimizer_maxiter"],"ftol":cfg["optimizer_ftol"],"disp":False})
    met=metrics(res.x,stats,cfg);tol=cfg["constraint_tolerance"]
    feasible=bool(res.success and met["max_abs_smd"]<=smd_lim+tol and all(v>=ess_lim-tol for v in met["ess_ratios"].values()))
    return res,res.x,met,feasible,smd_lim,ess_lim
def concentration(t):
    t=np.asarray(t,float);sh=np.sort(t/t.sum())[::-1];n=len(t);eff=float((t.sum()**2)/np.sum(t*t))
    def top(frac):return float(sh[:max(1,int(np.ceil(n*frac)))].sum())
    return {"effective_cell_count":eff,"effective_cell_fraction":eff/n,"top_1pct_target_mass_fraction":top(.01),"top_5pct_target_mass_fraction":top(.05),"top_10pct_target_mass_fraction":top(.10)}
def perturb(stats,t,cfg):
    rng=np.random.default_rng(cfg["perturbation_seed"]);rows=[];total=float(t.sum());n=len(t)
    for eps in cfg["perturbation_log_epsilons"]:
        for d in range(cfg["perturbation_direction_count"]):
            z=rng.normal(size=n);z-=z.mean();z/=max(np.linalg.norm(z),1e-30);p=t*np.exp(eps*z);p*=total/p.sum();m=metrics(p,stats,cfg)
            ok=bool(m["max_abs_smd"]<=cfg["frozen_smd_gate"] and all(v>=cfg["frozen_ess_gate"] for v in m["ess_ratios"].values()))
            rows.append({"log_epsilon":eps,"direction":d,"maximum_absolute_smd":m["max_abs_smd"],"APOGEE_ESS_raw_ratio":m["ess_ratios"][cfg["apogee_label"]],"GALAH_ESS_raw_ratio":m["ess_ratios"][cfg["galah_label"]],"all_frozen_balance_gates_pass":ok})
    return rows
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");args=ap.parse_args();root=Path(args.project_root).resolve()
    cfg=json.loads((root/"config/stage6d3c7a_config.json").read_text());out=root/cfg["output_dir"]
    if out.exists():shutil.rmtree(out)
    for d in ["validation","tables","diagnostic","summaries","reports"]:(out/d).mkdir(parents=True,exist_ok=True)
    prepath=root/cfg["prerequisite_validation"];pre=json.loads(prepath.read_text()) if prepath.exists() else {}
    prereq=bool(pre.get("STAGE6D3C7_CALIBRATION_AUDIT_READY",False) and pre.get("ALL_FROZEN_NUMERIC_GATES_PASS_DIAGNOSTICALLY",False) and not pre.get("STAGE6D4_SCIENCE_MODELS_READY",True))
    cp=resolve(root/cfg["candidate_source"]);lp=root/cfg["cell_target_ledger"]
    if not cp or not lp.exists():raise FileNotFoundError("D3C7 candidate/ledger missing")
    frame=read_table(cp).reset_index(drop=True);ledger=pd.read_csv(lp)
    mx,rat,smdrows=direct_metrics(frame,cfg["candidate_weight_field"],cfg)
    repro=bool(abs(mx-pre["constrained_maximum_absolute_smd"])<=1e-10 and all(abs(rat[s]-pre["constrained_ess_raw_ratio_by_survey"][s])<=1e-10 for s in cfg["surveys"]))
    stats=build_stats(frame,cfg)
    order=[normalize_cell_key(c["cell"]) for c in stats]
    lm={}
    duplicate_cell_keys=[]
    for _,r in ledger.iterrows():
        key=normalize_cell_key(r["cell"])
        value=float(r["calibrated_target"])
        if key in lm and not np.isclose(lm[key], value, rtol=0, atol=0):
            duplicate_cell_keys.append(key)
        lm[key]=value
    missing_cell_keys=[key for key in order if key not in lm]
    extra_cell_keys=sorted(set(lm).difference(order), key=lambda x:int(x))
    if duplicate_cell_keys:
        raise RuntimeError(f"Conflicting duplicate cell keys in D3C7 ledger: {sorted(set(duplicate_cell_keys))[:20]}")
    if missing_cell_keys:
        raise RuntimeError(
            "D3C7 ledger is missing normalized HEALPix cells: "
            + ",".join(missing_cell_keys[:20])
        )
    tc=np.array([lm[x] for x in order],float)
    t0=np.array([c["baseline_target"] for c in stats],float)
    margin_rows=[];best_margin=None;start=tc.copy()
    for margin in cfg["interior_margin_grid"]:
        best=None
        for sid,s0 in enumerate([start,tc,t0]):
            res,t,met,ok,sl,el=optimize_margin(stats,t0,s0,float(margin),cfg)
            if ok and (best is None or res.fun<best[0].fun):best=(res,t,met,ok,sl,el,sid)
        chosen=best if best else optimize_margin(stats,t0,tc,float(margin),cfg)+(0,)
        res,t,met,ok,sl,el,sid=chosen
        margin_rows.append({"margin":margin,"smd_limit":sl,"ess_limit":el,"optimizer_success":bool(res.success),"optimizer_message":str(res.message),"feasible":bool(ok),"maximum_absolute_smd":met["max_abs_smd"],"APOGEE_ESS_raw_ratio":met["ess_ratios"][cfg["apogee_label"]],"GALAH_ESS_raw_ratio":met["ess_ratios"][cfg["galah_label"]],"objective":float(res.fun),"minimum_target_ratio":float(np.min(t/t0)),"maximum_target_ratio":float(np.max(t/t0)),"selected_start_id":sid})
        if ok:best_margin=float(margin);start=t.copy()
    wcsv(out/"tables/stage6d3c7a_interior_margin_frontier.csv",list(margin_rows[0].keys()),margin_rows)
    conc=concentration(tc);ratio=tc/t0;conc.update({"minimum_target_ratio":float(ratio.min()),"q01_target_ratio":float(np.quantile(ratio,.01)),"q05_target_ratio":float(np.quantile(ratio,.05)),"median_target_ratio":float(np.quantile(ratio,.5)),"q95_target_ratio":float(np.quantile(ratio,.95)),"q99_target_ratio":float(np.quantile(ratio,.99)),"maximum_target_ratio":float(ratio.max()),"fraction_target_ratio_lt_0p01":float(np.mean(ratio<.01)),"fraction_target_ratio_lt_0p1":float(np.mean(ratio<.1)),"fraction_target_ratio_gt_2":float(np.mean(ratio>2)),"fraction_target_ratio_gt_5":float(np.mean(ratio>5))})
    wjson(out/"tables/stage6d3c7a_target_concentration.json",conc)
    prows=perturb(stats,tc,cfg);wcsv(out/"diagnostic/stage6d3c7a_local_target_perturbation_audit.csv",list(prows[0].keys()),prows)
    pf=pd.DataFrame(prows);psum=[]
    for eps,g in pf.groupby("log_epsilon",sort=True):
        psum.append({"log_epsilon":float(eps),"directions":len(g),"pass_fraction":float(g["all_frozen_balance_gates_pass"].mean()),"max_smd_min":float(g["maximum_absolute_smd"].min()),"max_smd_max":float(g["maximum_absolute_smd"].max()),"APOGEE_ESS_min":float(g["APOGEE_ESS_raw_ratio"].min()),"GALAH_ESS_min":float(g["GALAH_ESS_raw_ratio"].min())})
    wcsv(out/"diagnostic/stage6d3c7a_local_perturbation_summary.csv",list(psum[0].keys()),psum)
    ref=cfg["robust_interior_margin_reference"]
    if best_margin is None or best_margin==0:cls="BOUNDARY_ONLY_NUMERIC_FEASIBILITY"
    elif best_margin<ref:cls="NARROW_INTERIOR_NUMERIC_FEASIBILITY"
    else:cls="ROBUST_INTERIOR_NUMERIC_FEASIBILITY"
    next_action=("Proceed to formal D3C8 protocol closure, then one production rerun." if cls=="ROBUST_INTERIOR_NUMERIC_FEASIBILITY"
                 else "Do not freeze production yet; feasibility is too narrow/boundary-like for a claim-critical weight set.")
    val={"stage":cfg["stage"],"protocol_version":cfg["protocol_version"],"implementation_version":cfg["implementation_version"],"timestamp_utc":now(),"classification":cls,"input_rows":len(frame),"cell_count":len(stats),"independent_candidate_maximum_absolute_smd":mx,"independent_candidate_ess_raw_ratio_by_survey":rat,"candidate_metrics_reproduced_to_1e_10":repro,"normalized_cell_key_count":len(order),"ledger_normalized_cell_key_count":len(lm),"ledger_extra_normalized_cell_key_count":len(extra_cell_keys),"CELL_ID_NORMALIZATION_READY":True,"CELL_ID_LOOKUP_COMPLETE":len(missing_cell_keys)==0,"maximum_certified_interior_margin":best_margin,"robust_interior_margin_reference":ref,"target_concentration":conc,"STAGE6D3C7_PREREQUISITE_READY":prereq,"INDEPENDENT_CANDIDATE_RECALCULATION_READY":True,"INTERIOR_MARGIN_FRONTIER_READY":True,"TARGET_CONCENTRATION_AUDIT_READY":True,"LOCAL_PERTURBATION_AUDIT_READY":True,"NO_FROZEN_GATE_WEAKENED":True,"NO_NEW_BALANCING_FEATURE_ADDED":True,"NO_OUTCOME_ABUNDANCE_R_ABSZ_USED":True,"FORMAL_PROTOCOL_CLOSURE_RECOMMENDED":cls=="ROBUST_INTERIOR_NUMERIC_FEASIBILITY","DIAGNOSTIC_ONLY":True,"PRODUCTION_BALANCED_WEIGHTS_READY":False,"STAGE6D3C7A_STABILITY_CERTIFICATION_READY":prereq,"STAGE6D4_SCIENCE_MODELS_READY":False}
    wjson(out/"validation/stage6d3c7a_validation.json",val);wjson(out/"summaries/stage6d3c7a_summary.json",{"classification":cls,"maximum_certified_interior_margin":best_margin,"next_action":next_action,"scientific_disposition":"D3C7A distinguishes robust interior feasibility from knife-edge feasibility."})
    print(json.dumps({"validation":val},indent=2));return 0
if __name__=="__main__":raise SystemExit(main())
