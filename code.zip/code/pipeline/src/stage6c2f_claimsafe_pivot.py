from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

STAGE = "Stage-6C2F claim-safe manuscript pivot and survey-origin closure"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.15.5"

LABELS = ["fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe", "alpha3"]

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def norm(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).lower()).strip("_")

def safe_rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def write_csv(path: Path, fields: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

def first_existing(root: Path, values: list[str]) -> Path | None:
    for value in values:
        path = root / value
        if path.exists():
            return path
    return None

def derive_t04(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    required = [
        "view", "k", "model_valid", "rows", "mean_max_responsibility",
        "mean_normalized_entropy", "secure70_fraction"
    ]
    missing = [c for c in required if c not in frame.columns]
    if missing:
        raise ValueError("Missing T04 columns: " + ", ".join(missing))
    work = frame[required].copy()
    work = work[work["model_valid"].astype(bool)]
    grouped = work.groupby(["view", "k"], as_index=False).agg({
        "model_valid": "all",
        "rows": "max",
        "mean_max_responsibility": "median",
        "mean_normalized_entropy": "median",
        "secure70_fraction": "median"
    })
    grouped = grouped.sort_values(["view", "k"]).reset_index(drop=True)
    return grouped

def semantic_claim_audit(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    frame = pd.read_csv(path)
    rows = []
    text_columns = [
        c for c in frame.columns
        if pd.api.types.is_object_dtype(frame[c]) or pd.api.types.is_string_dtype(frame[c])
    ]
    for index, row in frame.iterrows():
        blob = " | ".join(str(row[c]) for c in text_columns if pd.notna(row[c]))
        low = norm(blob)
        if any(token in low for token in [
            "thin_disc", "thick_disc", "halo", "accreted",
            "named_population", "physical_population"
        ]):
            status_col = next(
                (c for c in frame.columns if norm(c) in {
                    "status", "claim_status", "disposition", "support_status"
                }), None
            )
            rows.append({
                "row_index": index,
                "status": row[status_col] if status_col else "",
                "text": blob
            })
    return rows

def discover_huber_tuning(root: Path, cfg: dict[str, Any]) -> tuple[list[dict[str, Any]], list[float]]:
    evidence = []
    values = set()
    patterns = [
        re.compile(r"(?:huber_(?:tuning|delta|epsilon|c|k)|epsilon)\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)", re.I),
        re.compile(r"HuberRegressor\s*\([^)]*epsilon\s*=\s*([0-9]+(?:\.[0-9]+)?)", re.I)
    ]
    allowed_suffixes = {".py", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".md"}
    for rel_dir in cfg["stage4b_source_dirs"]:
        directory = root / rel_dir
        if not directory.exists():
            continue
        for path in directory.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in allowed_suffixes:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            for pattern in patterns:
                for match in pattern.finditer(text):
                    value = float(match.group(1))
                    if 0.5 <= value <= 5.0:
                        values.add(value)
                        evidence.append({
                            "path": safe_rel(path, root),
                            "pattern": pattern.pattern,
                            "value": value,
                            "excerpt": text[max(0, match.start()-80):match.end()+80].replace("\n", " ")
                        })
    candidates = sorted(values)
    for value in cfg["candidate_huber_tunings"]:
        if float(value) not in candidates:
            candidates.append(float(value))
    return evidence, candidates

def huber_irls_fixed_scale(
    X: np.ndarray,
    y: np.ndarray,
    scale: float,
    tuning: float,
    max_iter: int,
    tol: float
) -> tuple[np.ndarray, bool, int]:
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    if not np.isfinite(scale) or scale <= 0:
        residual = y - X @ beta
        scale = 1.4826 * np.median(np.abs(residual - np.median(residual)))
    if not np.isfinite(scale) or scale <= 0:
        raise ValueError("Non-positive robust scale")
    for iteration in range(max_iter):
        residual = y - X @ beta
        u = residual / (tuning * scale)
        weights = np.ones_like(u)
        mask = np.abs(u) > 1.0
        weights[mask] = 1.0 / np.abs(u[mask])
        WX = X * np.sqrt(weights)[:, None]
        Wy = y * np.sqrt(weights)
        new_beta, *_ = np.linalg.lstsq(WX, Wy, rcond=None)
        if np.max(np.abs(new_beta - beta)) < tol:
            return new_beta, True, iteration + 1
        beta = new_beta
    return beta, False, max_iter

def load_design(path: Path) -> tuple[pd.DataFrame, dict[str, Any]]:
    import pyarrow.parquet as pq
    pf = pq.ParquetFile(path)
    columns = pf.schema.names
    required = [
        "survey_origin", "r_cyl_gc_kpc", "abs_z_gc_kpc", "gaia_healpix5",
        "radial_domain_primary"
    ]
    for label in LABELS:
        required += [f"{label}_hom", f"{label}_gradient_primary_ok"]
    missing = [c for c in required if c not in columns]
    if missing:
        raise ValueError("Missing explicit design columns: " + ", ".join(missing))
    frame = pd.read_parquet(path, columns=required)
    audit = {
        "rows": len(frame),
        "columns_read": required,
        "parquet_rows": pf.metadata.num_rows,
        "row_groups": pf.metadata.num_row_groups
    }
    return frame, audit

def prepare_label_sample(
    design: pd.DataFrame,
    label: str,
    subset_mask: pd.Series,
    radial_min: float,
    radial_max: float
) -> pd.DataFrame:
    ok_col = f"{label}_gradient_primary_ok"
    value_col = f"{label}_hom"
    mask = (
        subset_mask
        & design["radial_domain_primary"].astype(bool)
        & design[ok_col].astype(bool)
        & pd.to_numeric(design["r_cyl_gc_kpc"], errors="coerce").between(radial_min, radial_max)
    )
    work = design.loc[mask, [
        value_col, "r_cyl_gc_kpc", "abs_z_gc_kpc", "gaia_healpix5"
    ]].copy()
    for c in [value_col, "r_cyl_gc_kpc", "abs_z_gc_kpc"]:
        work[c] = pd.to_numeric(work[c], errors="coerce")
    return work.dropna()

def fit_point(
    work: pd.DataFrame,
    label: str,
    pivot: float,
    scale: float,
    tuning: float,
    cfg: dict[str, Any]
) -> dict[str, Any]:
    value_col = f"{label}_hom"
    X = np.column_stack([
        np.ones(len(work)),
        work["r_cyl_gc_kpc"].to_numpy() - pivot,
        work["abs_z_gc_kpc"].to_numpy()
    ])
    y = work[value_col].to_numpy()
    beta, converged, iterations = huber_irls_fixed_scale(
        X, y, scale, tuning,
        int(cfg["maximum_solver_iterations"]),
        float(cfg["solver_tolerance"])
    )
    return {
        "n": len(work),
        "spatial_blocks": int(work["gaia_healpix5"].nunique()),
        "beta_intercept": beta[0],
        "beta_r": beta[1],
        "beta_z": beta[2],
        "converged": converged,
        "iterations": iterations
    }

def replay_global(
    design: pd.DataFrame,
    estimates: pd.DataFrame,
    tunings: list[float],
    cfg: dict[str, Any]
) -> tuple[list[dict[str, Any]], float | None]:
    rows = []
    radial_min, radial_max = cfg["radial_window_kpc"]
    all_mask = pd.Series(True, index=design.index)
    for tuning in tunings:
        for _, ref in estimates.iterrows():
            label = str(ref["label"])
            work = prepare_label_sample(design, label, all_mask, radial_min, radial_max)
            if len(work) < int(cfg["minimum_subset_rows"]):
                rows.append({
                    "tuning": tuning, "label": label, "status": "insufficient_rows",
                    "n": len(work)
                })
                continue
            result = fit_point(
                work, label, float(ref["radial_pivot_kpc"]),
                float(ref["residual_mad"]), tuning, cfg
            )
            dr = result["beta_r"] - float(ref["beta_R"])
            dz = result["beta_z"] - float(ref["beta_Z"])
            rows.append({
                "tuning": tuning, "label": label, "status": "fit",
                **result,
                "reference_beta_r": float(ref["beta_R"]),
                "reference_beta_z": float(ref["beta_Z"]),
                "delta_beta_r": dr,
                "delta_beta_z": dz,
                "max_abs_delta": max(abs(dr), abs(dz))
            })
    candidates = []
    for tuning in tunings:
        group = [r for r in rows if r.get("tuning") == tuning and r.get("status") == "fit"]
        if len(group) == len(estimates):
            candidates.append((
                max(float(r["max_abs_delta"]) for r in group),
                float(tuning)
            ))
    if not candidates:
        return rows, None
    candidates.sort()
    return rows, candidates[0][1]

def identity_pass(rows: list[dict[str, Any]], tuning: float | None, cfg: dict[str, Any]) -> bool:
    if tuning is None:
        return False
    selected = [r for r in rows if r.get("tuning") == tuning and r.get("status") == "fit"]
    if len(selected) != len(LABELS):
        return False
    abs_tol = float(cfg["identity_absolute_tolerance"])
    rel_tol = float(cfg["identity_relative_tolerance"])
    for row in selected:
        for key, ref_key in [("delta_beta_r", "reference_beta_r"), ("delta_beta_z", "reference_beta_z")]:
            delta = abs(float(row[key]))
            ref = abs(float(row[ref_key]))
            if delta > max(abs_tol, rel_tol * max(ref, abs_tol)):
                return False
    return True

def derive_t06(
    design: pd.DataFrame,
    estimates: pd.DataFrame,
    tuning: float,
    cfg: dict[str, Any]
) -> pd.DataFrame:
    radial_min, radial_max = cfg["radial_window_kpc"]
    origin = design["survey_origin"].astype(str).map(norm)
    masks = {
        "all_clean": pd.Series(True, index=design.index),
        "origin_apogee": origin.str.contains("apogee"),
        "origin_galah": origin.str.contains("galah")
    }
    rows = []
    for sample, mask in masks.items():
        for _, ref in estimates.iterrows():
            label = str(ref["label"])
            work = prepare_label_sample(design, label, mask, radial_min, radial_max)
            if len(work) < int(cfg["minimum_subset_rows"]):
                continue
            result = fit_point(
                work, label, float(ref["radial_pivot_kpc"]),
                float(ref["residual_mad"]), tuning, cfg
            )
            rows.append({"sample": sample, "label": label, **result})
    return pd.DataFrame(rows)

def tex_escape(value: Any) -> str:
    text = str(value)
    for old, new in [
        ("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"),
        ("$", r"\$"), ("#", r"\#"), ("_", r"\_"),
        ("{", r"\{"), ("}", r"\}")
    ]:
        text = text.replace(old, new)
    return text

def fmt(value: Any, decimals: int = 4) -> str:
    if value is None or pd.isna(value):
        return "--"
    try:
        number = float(value)
        if number.is_integer() and abs(number) >= 100:
            return f"{int(number):,}"
        if abs(number) < 10:
            return f"{number:+.{decimals}f}"
        return f"{number:.{decimals}f}"
    except Exception:
        return tex_escape(value)

def dataframe_to_latex(asset_id: str, title: str, frame: pd.DataFrame, source: str) -> str:
    display = frame.copy()
    cols = list(display.columns)
    wide = len(cols) >= 5
    environment = "table*" if wide else "table"
    width = r"\textwidth" if wide else r"\columnwidth"
    headings = {
        "view": "View", "k": r"$k$", "model_valid": "Valid",
        "rows": r"$N$", "mean_max_responsibility": r"Mean $P_{\max}$",
        "mean_normalized_entropy": "Mean norm. entropy",
        "secure70_fraction": r"$P_{\max}>0.70$ frac.",
        "sample": "Sample", "label": "Label", "n": r"$N$",
        "spatial_blocks": "Blocks", "beta_r": r"$\beta_R$",
        "beta_z": r"$\beta_Z$", "converged": "Converged"
    }
    lines = [
        f"% Auto-generated by Stage-6C2F from {source}",
        rf"\begin{{{environment}}}", r"\centering", r"\small",
        rf"\caption{{{tex_escape(title)}. Source/closure: \texttt{{{tex_escape(source)}}}.}}",
        rf"\label{{tab:{asset_id.lower()}}}",
        rf"\resizebox{{{width}}}{{!}}{{%",
        r"\begin{tabular}{" + "l" + "r" * max(len(cols)-1, 0) + "}",
        r"\hline",
        " & ".join(headings.get(c, tex_escape(c)) for c in cols) + r"\\",
        r"\hline"
    ]
    text_cols = {"view", "sample", "label"}
    int_cols = {"k", "rows", "n", "spatial_blocks", "iterations"}
    for _, row in display.iterrows():
        cells = []
        for col in cols:
            value = row[col]
            if col in text_cols:
                cells.append(tex_escape(value))
            elif col in int_cols:
                cells.append(f"{int(float(value)):,}" if pd.notna(value) else "--")
            elif isinstance(value, (bool, np.bool_)):
                cells.append("yes" if bool(value) else "no")
            else:
                cells.append(fmt(value))
        lines.append(" & ".join(cells) + r"\\")
    lines.extend([r"\hline", r"\end{tabular}", r"}", rf"\end{{{environment}}}", ""])
    return "\n".join(lines)

def pyplot():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    return plt

def plot_metric_by_view(frame: pd.DataFrame, metric: str, path: Path, ylabel: str) -> bool:
    if frame.empty:
        return False
    plt = pyplot()
    fig, ax = plt.subplots(figsize=(8.5, 5.0))
    for view, group in frame.groupby("view"):
        group = group.sort_values("k")
        ax.plot(group["k"], group[metric], marker="o", label=str(view))
    ax.set_xlabel("Number of mixture components, k")
    ax.set_ylabel(ylabel)
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def plot_t06(frame: pd.DataFrame, path: Path) -> bool:
    if frame.empty:
        return False
    fe = frame[frame["label"].astype(str) == "fe_h"].copy()
    work = fe if not fe.empty else frame.copy()
    work["display"] = work["sample"].astype(str) + " | " + work["label"].astype(str)
    plt = pyplot()
    fig, ax = plt.subplots(figsize=(8.8, 5.0))
    x = np.arange(len(work))
    ax.axhline(0.0, linewidth=0.8)
    ax.plot(x, work["beta_r"], marker="o", label=r"$\beta_R$")
    ax.plot(x, work["beta_z"], marker="s", linestyle="--", label=r"$\beta_Z$")
    ax.set_xticks(x)
    ax.set_xticklabels(work["display"], rotation=50, ha="right")
    ax.set_ylabel(r"Gradient [dex kpc$^{-1}$]")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def update_figure_slot(package_root: Path, number: int, filename: str, caption: str) -> None:
    (package_root / "figures" / f"figure{number:02d}_slot.tex").write_text(
        rf"""\begin{{figure*}}
\centering
\includegraphics[width=0.96\textwidth]{{figures/{filename}}}
\caption{{{caption}}}
\label{{fig:f{number:02d}}}
\end{{figure*}}
""", encoding="utf-8"
    )

def patch_manuscript(package_root: Path) -> None:
    title = "A support-aware Gaia--APOGEE--GALAH red-giant chemo-kinematic atlas of the Milky Way"
    for main_name in ["main.tex", "main_mnras.tex"]:
        path = package_root / main_name
        text = path.read_text(encoding="utf-8")
        text = re.sub(r"\\title\{.*?\}", r"\\title{" + title + "}", text, count=1, flags=re.S)
        path.write_text(text, encoding="utf-8")

    abstract = r"""
\begin{abstract}
Combining large spectroscopic surveys requires more than concatenating catalogues: label zero-points,
overlap support, target selection, and footprint differences can dominate formal uncertainties. We
construct a support-aware Gaia--APOGEE--GALAH red-giant-branch atlas using Gaia DR3 phase-space
information and empirically transported APOGEE DR17 and GALAH labels. Common-star calibration is
evaluated label by label, and robust radial and vertical gradients are measured with explicit frozen
support gates. The global clean sample is APOGEE dominated; GALAH-origin results are therefore
interpreted as smaller-footprint consistency tests rather than independent replication. A family of
anonymous latent-component models is used only as a diagnostic of chemo-kinematic structure across
feature views and component counts. The frozen release does not select one unique physical population
decomposition, archive star-level component memberships, or support automatic assignment of standard physical Galactic-population names to mixture
components. We consequently report model-space
responsibility and entropy diagnostics rather than named-population gradients. The resulting release
emphasises label-specific transportability, claim-bounded survey comparisons, and full provenance from
machine-readable products to manuscript tables and figures.
\end{abstract}
\begin{keywords}
Galaxy: abundances -- Galaxy: disc -- Galaxy: kinematics and dynamics --
stars: late-type -- surveys -- methods: statistical
\end{keywords}
"""
    (package_root / "sections/00_abstract.tex").write_text(abstract.strip() + "\n", encoding="utf-8")

    methodology = package_root / "sections/05_methodology.tex"
    text = methodology.read_text(encoding="utf-8")
    start = text.find(r"\subsection{Semi-probabilistic populations}")
    end = text.find(r"\subsection{Survey-subset stress tests}")
    replacement = r"""\subsection{Anonymous latent-component diagnostics}
The frozen Stage-5B layer evaluates Gaussian-mixture responsibility diagnostics across predefined
feature views and component counts. Components are ordered and labelled only as
\(\mathrm{C1},\ldots,\mathrm{C}k\). The release records the mean maximum responsibility, normalized
entropy, and fractions above fixed responsibility thresholds. It does not freeze one unique physical
population decomposition or a source-ID keyed assignment catalogue. Accordingly, these models are
used to assess whether the chemo-kinematic feature space exhibits reproducible low-entropy structure,
not to define membership in standard physically interpreted Galactic components.

"""
    if start >= 0 and end > start:
        text = text[:start] + replacement + text[end:]
    methodology.write_text(text, encoding="utf-8")

    results = r"""
\section{Results}
\label{sec:results}

\subsection{Global gradients}
The authoritative Stage-4B summary reports robust radial and vertical gradients for six homogenised
labels. The global sample is dominated by APOGEE-origin stars, so these estimates describe the
support of the combined clean atlas rather than a selection-function-corrected Milky Way census.

\input{tables/table03_global_gradients}
\input{figures/figure04_slot}

\subsection{Latent-component model-space diagnostics}
Stage-5B evaluates ten valid \((\mathrm{view},k)\) combinations rather than selecting a single physical
population model. Table~\ref{tab:t04} therefore reports model-level responsibility and entropy
diagnostics. Figures~\ref{fig:f02} and \ref{fig:f03} show how confidence and entropy vary with feature
view and component count. The component identifiers are deliberately anonymous.

\input{tables/table04_population_summary}
\input{figures/figure02_slot}
\input{figures/figure03_slot}

\subsection{Survey-origin support test}
The frozen global estimator is replayed on the Stage-4A design layer as an identity check. Survey-origin
closures are generated only when the replay reproduces the authoritative all-clean slopes within the
predefined tolerance. The APOGEE-origin and GALAH-origin fits remain footprint-specific descriptive
checks and are not interpreted as fully independent replications.

\input{tables/table06_survey_subsets}
\input{figures/figure05_slot}

\subsection{Calibration diagnostic}
\input{figures/figure01_slot}
"""
    (package_root / "sections/06_results.tex").write_text(results.strip() + "\n", encoding="utf-8")

    discussion = r"""
\section{Discussion}
\label{sec:discussion}

\subsection{Label-specific transportability}
The overlap calibration improves the comparability of APOGEE and GALAH labels within the common-star
support, but the residual scale remains label dependent. Transportability must therefore be reported for
each label rather than asserted for the catalogue as a whole.

\subsection{Global gradients and survey support}
The combined global gradients are precise because the clean catalogue is large, but precision does not
remove footprint dependence. The APOGEE-origin subset largely controls the all-clean result. The
GALAH-origin closure probes a smaller and different region of the selection support. Differences between
these fits should be interpreted as support sensitivity, not automatically as abundance-scale failure.

\subsection{Why the latent components remain anonymous}
The frozen Stage-5B release explores multiple feature views and values of \(k\). It does not identify one
unique primary physical decomposition, and no source-ID keyed membership catalogue is archived.
Although some anonymous components may occupy regions commonly associated with Galactic
substructures, assigning them standard physical Galactic-population names would add a semantic
claim not supported by the frozen products. We therefore retain \(\mathrm{C1},\ldots,\mathrm{C}k\) only
as model diagnostics and do not report component-resolved gradients.

\subsection{Limitations}
The atlas is not volume complete. APOGEE and GALAH have different target selections, footprints,
magnitude limits, and residual label systematics. A fully survey-independent gradient comparison would
require explicit footprint matching, common colour and magnitude cuts, and selection-function modelling.
The release supports empirical overlap transport and support-bounded robustness tests; it does not support
a universal abundance scale or a selection-corrected Galactic census.
"""
    (package_root / "sections/07_discussion.tex").write_text(discussion.strip() + "\n", encoding="utf-8")

    conclusions = r"""
\section{Conclusions}
\label{sec:conclusions}

We present a support-aware Gaia--APOGEE--GALAH RGB chemo-kinematic atlas with explicit provenance
from frozen analysis products to manuscript claims.

\begin{enumerate}
\item APOGEE and GALAH are harmonised through label-specific common-star transport models rather
than direct concatenation of native abundance scales.
\item Six homogenised labels show robust global radial and vertical structure within the frozen clean
sample and spatial support.
\item The global result is APOGEE dominated. GALAH-origin estimates are smaller-footprint consistency
tests, not fully independent replications.
\item Stage-5B supports anonymous latent-component diagnostics across several feature views and
component counts. It does not support one uniquely selected, physically named population catalogue.
\item Named-population gradients are therefore not claimed. Responsibility confidence and entropy are
reported instead as model-space diagnostics.
\item The archival release records all source checksums, model gates, table mappings, and manuscript
transformations required to reproduce the claim boundary.
\end{enumerate}
"""
    (package_root / "sections/08_conclusions.tex").write_text(conclusions.strip() + "\n", encoding="utf-8")

    # Ensure no live reference to the old T05 input remains.
    for path in package_root.rglob("*.tex"):
        text = path.read_text(encoding="utf-8")
        text = text.replace(r"\input{tables/table05_population_gradients}", "")
        path.write_text(text, encoding="utf-8")

def scan_named_claims(package_root: Path) -> list[dict[str, Any]]:
    patterns = [
        "Low-alpha thin disc", "High-alpha disc", "Halo-like",
        "Vertically extended rotating disc", "population-resolved gradients",
        "thin-disc, thick-disc, halo"
    ]
    rows = []
    for path in package_root.rglob("*.tex"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        for pattern in patterns:
            count = text.lower().count(pattern.lower())
            if count:
                rows.append({
                    "path": safe_rel(path, package_root),
                    "pattern": pattern,
                    "count": count
                })
    return rows

def scan_human_metadata(package_root: Path, markers: list[str]) -> list[dict[str, Any]]:
    rows = []
    for path in package_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".tex", ".yaml", ".yml", ".json", ".md", ".cff"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for marker in markers:
            count = text.count(marker)
            if count:
                rows.append({"path": safe_rel(path, package_root), "marker": marker, "count": count})
    return rows

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE)
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads((root / "config/stage6c2f_config.json").read_text(encoding="utf-8"))
    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for name in ["validation", "summaries", "tables", "figures", "manuscript_source", "checksums"]:
        (out_dir / name).mkdir(parents=True, exist_ok=True)

    source_package = first_existing(root, cfg["source_package_candidates"])
    if source_package is None:
        raise FileNotFoundError("No prior manuscript source package found.")
    package_root = out_dir / "manuscript_source" / cfg["new_package_name"]
    shutil.copytree(source_package, package_root)

    # T04 direct model-space diagnostics.
    t04_path = root / cfg["responsibility_summary"]
    t04 = derive_t04(t04_path)
    t04.to_csv(out_dir / "tables/canonical_t04_model_space_diagnostics.csv", index=False)
    (package_root / "tables/table04_population_summary.tex").write_text(
        dataframe_to_latex(
            "T04", "Anonymous latent-component model-space diagnostics",
            t04, cfg["responsibility_summary"]
        ),
        encoding="utf-8"
    )

    # Semantic claim audit.
    semantic_rows = semantic_claim_audit(root / cfg["stage5b_claim_ledger"])
    write_csv(
        out_dir / "tables/stage6c2f_claim_ledger_semantic_audit.csv",
        ["row_index", "status", "text"], semantic_rows
    )

    # Explicit design and global replay.
    design, design_audit = load_design(root / cfg["design_layer"])
    write_json(out_dir / "summaries/stage6c2f_design_resolution.json", design_audit)

    estimates = pd.read_csv(root / cfg["global_estimates"])
    required_global = [
        "label", "radial_pivot_kpc", "residual_mad", "beta_R", "beta_Z"
    ]
    missing_global = [c for c in required_global if c not in estimates.columns]
    if missing_global:
        raise ValueError("Missing global estimate columns: " + ", ".join(missing_global))
    estimates = estimates[estimates["label"].isin(LABELS)].copy()

    solver_evidence, tuning_candidates = discover_huber_tuning(root, cfg)
    write_csv(
        out_dir / "tables/stage6c2f_solver_discovery.csv",
        ["path", "pattern", "value", "excerpt"], solver_evidence
    )
    replay_rows, selected_tuning = replay_global(design, estimates, tuning_candidates, cfg)
    replay_fields = sorted({k for row in replay_rows for k in row.keys()})
    write_csv(
        out_dir / "tables/stage6c2f_global_replay_identity.csv",
        replay_fields, replay_rows
    )
    replay_ready = identity_pass(replay_rows, selected_tuning, cfg)

    t06 = pd.DataFrame()
    if replay_ready and selected_tuning is not None:
        t06 = derive_t06(design, estimates, selected_tuning, cfg)
        t06.to_csv(out_dir / "tables/canonical_t06_survey_origin_gradients.csv", index=False)
        (package_root / "tables/table06_survey_subsets.tex").write_text(
            dataframe_to_latex(
                "T06", "Survey-origin gradient closure",
                t06[["sample", "label", "n", "spatial_blocks", "beta_r", "beta_z", "converged"]],
                f"{cfg['design_layer']} with frozen Stage-4B replay"
            ),
            encoding="utf-8"
        )

    # Figures.
    generated = {}
    f02 = package_root / "figures/f02_secure70_by_view.pdf"
    generated["F02"] = plot_metric_by_view(
        t04, "secure70_fraction", f02, r"Fraction with $P_{\max}>0.70$"
    )
    if generated["F02"]:
        update_figure_slot(
            package_root, 2, f02.name,
            "Secure-responsibility fraction across anonymous latent-component views and component counts."
        )

    f03 = package_root / "figures/f03_entropy_by_view.pdf"
    generated["F03"] = plot_metric_by_view(
        t04, "mean_normalized_entropy", f03, "Mean normalized responsibility entropy"
    )
    if generated["F03"]:
        update_figure_slot(
            package_root, 3, f03.name,
            "Mean normalized responsibility entropy across anonymous latent-component models."
        )

    f05 = package_root / "figures/f05_survey_origin_gradients.pdf"
    generated["F05"] = replay_ready and plot_t06(t06, f05)
    if generated["F05"]:
        update_figure_slot(
            package_root, 5, f05.name,
            "Survey-origin radial and vertical gradient closure; support-specific and not a fully independent replication."
        )

    write_csv(
        out_dir / "tables/stage6c2f_figure_generation.csv",
        ["figure_id", "generated"],
        [{"figure_id": k, "generated": str(v).lower()} for k, v in generated.items()]
    )

    patch_manuscript(package_root)
    named_claim_rows = scan_named_claims(package_root)
    write_csv(
        out_dir / "tables/stage6c2f_named_claim_audit.csv",
        ["path", "pattern", "count"], named_claim_rows
    )
    human_rows = scan_human_metadata(package_root, cfg["human_metadata_markers"])
    write_csv(
        out_dir / "tables/stage6c2f_human_metadata_audit.csv",
        ["path", "marker", "count"], human_rows
    )

    t04_ready = not t04.empty
    anonymous_policy = len(named_claim_rows) == 0
    t05_removed = not any(
        "table05_population_gradients" in p.read_text(encoding="utf-8", errors="ignore")
        for p in package_root.rglob("*.tex")
    )
    t06_ready = replay_ready and not t06.empty
    figures_ready = all(generated.values())
    human_ready = len(human_rows) == 0
    mnras_ready = (package_root / "mnras.cls").exists()
    claimsafe_ready = (
        t04_ready and anonymous_policy and t05_removed
        and replay_ready and t06_ready and figures_ready
    )

    remaining = []
    if not replay_ready:
        remaining.append({
            "gate": "GLOBAL_REPLAY_IDENTITY_READY",
            "required_action": (
                "The candidate Huber replay did not reproduce the authoritative Stage-4B global slopes. "
                "Inspect stage6c2f_global_replay_identity.csv and Stage-4B solver source."
            )
        })
    if not anonymous_policy:
        remaining.append({
            "gate": "NAMED_POPULATION_CLAIMS_REMOVED",
            "required_action": "Named-population text remains in the manuscript; inspect stage6c2f_named_claim_audit.csv."
        })
    if not figures_ready:
        remaining.append({
            "gate": "FIGURES_READY",
            "required_action": "One or more claim-safe replacement figures failed."
        })
    if not human_ready:
        remaining.append({
            "gate": "HUMAN_METADATA_READY",
            "required_action": "Complete author, affiliation, ORCID, funding, repository, and DOI placeholders."
        })
    write_csv(
        out_dir / "tables/stage6c2f_remaining_closure_items.csv",
        ["gate", "required_action"], remaining
    )

    # Provenance and package.
    provenance = package_root / "provenance"
    provenance.mkdir(parents=True, exist_ok=True)
    for source in [
        out_dir / "tables/canonical_t04_model_space_diagnostics.csv",
        out_dir / "tables/stage6c2f_global_replay_identity.csv",
        out_dir / "tables/stage6c2f_claim_ledger_semantic_audit.csv",
        out_dir / "tables/stage6c2f_named_claim_audit.csv"
    ]:
        shutil.copy2(source, provenance / source.name)
    if (out_dir / "tables/canonical_t06_survey_origin_gradients.csv").exists():
        shutil.copy2(
            out_dir / "tables/canonical_t06_survey_origin_gradients.csv",
            provenance / "canonical_t06_survey_origin_gradients.csv"
        )

    manifest_rows = []
    for path in sorted(package_root.rglob("*")):
        if path.is_file():
            manifest_rows.append({
                "path": safe_rel(path, package_root),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path)
            })
    write_json(package_root / "PROVENANCE_MANIFEST.json", {
        "stage": STAGE, "created_utc": utc_now(), "files": manifest_rows
    })
    sums = [
        f"{sha256_file(path)}  {safe_rel(path, package_root)}"
        for path in sorted(package_root.rglob("*"))
        if path.is_file() and path.name != "SHA256SUMS.txt"
    ]
    (package_root / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")

    zip_path = out_dir / "manuscript_source" / f"{cfg['new_package_name']}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as archive:
        for path in sorted(package_root.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(package_root.parent))

    validation = {
        "stage": STAGE,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "selected_huber_tuning": selected_tuning,
        "semantic_claim_ledger_row_count": len(semantic_rows),
        "named_population_claim_residual_count": sum(int(r["count"]) for r in named_claim_rows),
        "human_metadata_placeholder_count": sum(int(r["count"]) for r in human_rows),
        "prior_stage_outputs_modified": False,
        "T04_MODEL_SPACE_DIAGNOSTICS_READY": t04_ready,
        "ANONYMOUS_COMPONENT_POLICY_ENFORCED": anonymous_policy,
        "NAMED_POPULATION_CLAIMS_REMOVED": t05_removed and anonymous_policy,
        "GLOBAL_REPLAY_IDENTITY_READY": replay_ready,
        "T06_SURVEY_ORIGIN_CLOSURE_READY": t06_ready,
        "CLAIMSAFE_REPLACEMENT_FIGURES_READY": figures_ready,
        "CLAIMSAFE_MANUSCRIPT_READY": claimsafe_ready,
        "MNRAS_TEMPLATE_READY": mnras_ready,
        "HUMAN_METADATA_READY": human_ready,
        "ZENODO_SUBMISSION_READY": claimsafe_ready and mnras_ready and human_ready,
        "source_package": safe_rel(package_root, root),
        "source_zip": safe_rel(zip_path, root),
        "source_zip_size_bytes": zip_path.stat().st_size,
        "source_zip_sha256": sha256_file(zip_path)
    }
    write_json(out_dir / "validation/stage6c2f_validation.json", validation)

    summary = {
        "stage": STAGE,
        "timestamp_utc": utc_now(),
        "t04_model_count": len(t04),
        "t06_row_count": len(t06),
        "selected_huber_tuning": selected_tuning,
        "remaining_closure_items": remaining,
        "scientific_disposition": (
            "Claim-safe manuscript pivot completed. Anonymous component diagnostics replace unsupported named-population claims."
            if claimsafe_ready else
            "Manuscript pivot completed, but the frozen global replay or another claim-safe gate remains unresolved."
        )
    }
    write_json(out_dir / "summaries/stage6c2f_summary.json", summary)

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
