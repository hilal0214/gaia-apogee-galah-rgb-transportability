from __future__ import annotations
import argparse,csv,hashlib,json,os,re
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq

def now(): return datetime.now(timezone.utc).isoformat()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def excluded(p, names):
    return any(part in names for part in p.parts)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage8b1b_config.json").read_text(encoding="utf-8"))
    out=root/c["output_dir"]
    for d in ["tables","validation","reports"]:
        (out/d).mkdir(parents=True,exist_ok=True)

    exact=[]
    schema_hits=[]
    schema_errors=[]
    text_hits=[]
    aliases=set(x.lower() for x in c["reference_tokens"])
    exactcols=set(x.lower() for x in c["exact_column_candidates"])

    # Parquet schema-only scan. No row data are read.
    for p in root.rglob("*.parquet"):
        rel=p.relative_to(root)
        if excluded(rel,c["exclude_dirs"]): continue
        try:
            names=pq.ParquetFile(p).schema_arrow.names
            low=[str(x).lower() for x in names]
            hits=[names[i] for i,x in enumerate(low) if ("alpha3" in x or "alpha_3" in x)]
            if hits:
                rec={"path":str(rel).replace("\\","/"),
                     "columns":"|".join(hits),
                     "n_columns":len(names),
                     "file_size_bytes":p.stat().st_size}
                schema_hits.append(rec)
            for i,x in enumerate(low):
                if x in exactcols:
                    exact.append({"path":str(rel).replace("\\","/"),
                                  "exact_column":names[i],
                                  "n_columns":len(names),
                                  "file_size_bytes":p.stat().st_size})
        except Exception as e:
            schema_errors.append({"path":str(rel).replace("\\","/"),"error":repr(e)})

    # Text/config/code reference scan, bounded by size. This is provenance text only.
    for ext in c["text_extensions"]:
        for p in root.rglob("*"+ext):
            rel=p.relative_to(root)
            if excluded(rel,c["exclude_dirs"]): continue
            try:
                if p.stat().st_size>int(c["maximum_text_file_bytes"]): continue
                s=p.read_text(encoding="utf-8",errors="ignore")
            except Exception:
                continue
            lines=s.splitlines()
            for i,line in enumerate(lines,1):
                ll=line.lower()
                if any(tok in ll for tok in aliases):
                    text_hits.append({
                        "path":str(rel).replace("\\","/"),
                        "line":i,
                        "context":line[:500]
                    })

    pd.DataFrame(exact).to_csv(out/"tables/stage8b1b_exact_alpha3_schema_hits.csv",index=False)
    pd.DataFrame(schema_hits).to_csv(out/"tables/stage8b1b_alpha3_like_schema_hits.csv",index=False)
    pd.DataFrame(text_hits).to_csv(out/"tables/stage8b1b_alpha3_text_references.csv",index=False)
    pd.DataFrame(schema_errors).to_csv(out/"tables/stage8b1b_schema_scan_errors.csv",index=False)

    # Prioritize likely frozen/production candidates without claiming correctness.
    def score(path):
        q=path.lower()
        s=0
        for token,w in [("freeze",5),("frozen",5),("production",4),("stage6d",4),
                        ("stage5",3),("stage4",2),("output",1),("archive",2)]:
            if token in q: s+=w
        for token,w in [("test",-8),("smoke",-5),("checkpoint",-8),("backup",-3)]:
            if token in q: s+=w
        return s
    ranked=sorted(exact,key=lambda r:(-score(r["path"]),r["path"]))
    pd.DataFrame([{**r,"priority_score":score(r["path"])} for r in ranked]).to_csv(
        out/"tables/stage8b1b_ranked_exact_alpha3_candidates.csv",index=False)

    exact_ready=len(exact)>0
    refs_ready=len(text_hits)>0
    val={
      "stage":c["stage"],
      "implementation_version":c["implementation_version"],
      "timestamp_utc":now(),
      "PARQUET_SCHEMA_FILES_WITH_EXACT_ALPHA3":len(exact),
      "PARQUET_SCHEMA_FILES_WITH_ALPHA3_LIKE_COLUMNS":len(schema_hits),
      "TEXT_CONFIG_CODE_ALPHA3_REFERENCES":len(text_hits),
      "SCHEMA_SCAN_ERRORS":len(schema_errors),
      "ALPHA3_EXACT_COLUMN_LOCATED":exact_ready,
      "ALPHA3_PROVENANCE_REFERENCES_LOCATED":refs_ready,
      "ROW_VALUES_READ_FOR_ALPHA3_PROVENANCE_SCAN":False,
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":False,
      "ALPHA3_RECOMPUTED_FROM_MG_SI_CA":False,
      "STAGE8B1_PROVENANCE_SOURCE_AUTHORIZED":False,
      "NEXT_ACTION":"Inspect ranked exact schema candidates and text references; authorize one frozen provenance source only after lineage identity is demonstrated."
    }
    write_json(out/"validation/stage8b1b_validation.json",val)

    rep=["# Stage-8B1B alpha3 provenance locator","",
         f"Exact alpha3 parquet-schema hits: **{len(exact)}**",
         f"Alpha3-like schema hits: **{len(schema_hits)}**",
         f"Text/config/code references: **{len(text_hits)}**","",
         "No alpha3 row values were read and no alpha3 quantity was recomputed.","",
         "Top exact candidates:"]
    for r in ranked[:20]:
        rep.append(f"- `{r['path']}`")
    (out/"reports/stage8b1b_report.md").write_text("\n".join(rep)+"\n",encoding="utf-8")
    print(json.dumps(val,indent=2,ensure_ascii=False))
    if ranked:
        print("\nTOP_EXACT_ALPHA3_CANDIDATES")
        for r in ranked[:20]:
            print(r["path"])
    return 0

if __name__=="__main__":
    raise SystemExit(main())
