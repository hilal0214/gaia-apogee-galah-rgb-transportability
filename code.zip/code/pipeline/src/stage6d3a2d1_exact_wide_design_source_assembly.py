from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def normalise(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def canonical_survey(value: Any, cfg: dict[str, Any]) -> str | None:
    token = normalise(value)
    for canonical, variants in cfg["survey_values"].items():
        for variant in variants:
            candidate = normalise(variant)
            if token == candidate or candidate in token:
                return canonical
    return None


def read_columns(path: Path) -> tuple[list[str], int]:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        import pyarrow.parquet as pq

        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    if suffix == ".feather":
        import pyarrow.feather as feather

        table = feather.read_table(path)
        return list(table.column_names), int(table.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def read_table(path: Path, columns: list[str] | None = None) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path, columns=columns)
    if suffix == ".feather":
        return pd.read_feather(path, columns=columns)
    return pd.read_csv(path, usecols=columns)


def find_alias(columns: list[str], aliases: list[str]) -> str | None:
    lookup = {column.lower(): column for column in columns}
    for alias in aliases:
        if alias.lower() in lookup:
            return lookup[alias.lower()]
    return None


def choose_survey_column(
    frame: pd.DataFrame, cfg: dict[str, Any]
) -> tuple[str | None, pd.Series, list[dict[str, Any]]]:
    audit = []
    best = None
    for column in cfg["survey_candidates"]:
        if column not in frame.columns:
            continue
        mapped = frame[column].map(lambda value: canonical_survey(value, cfg)).astype("string")
        counts = mapped.value_counts(dropna=True).to_dict()
        ready = counts.get("APOGEE_NATIVE", 0) > 0 and counts.get("GALAH_CORRECTED", 0) > 0
        audit.append({
            "column": column,
            "apogee_count": int(counts.get("APOGEE_NATIVE", 0)),
            "galah_count": int(counts.get("GALAH_CORRECTED", 0)),
            "unmapped_count": int(mapped.isna().sum()),
            "both_surveys_ready": str(ready).lower(),
            "raw_values": "|".join(sorted(set(frame[column].dropna().astype(str)))[:40]),
        })
        score = int(counts.get("APOGEE_NATIVE", 0)) + int(counts.get("GALAH_CORRECTED", 0))
        if ready and (best is None or score > best[0]):
            best = (score, column, mapped)
    if best is None:
        return None, pd.Series(pd.NA, index=frame.index, dtype="string"), audit
    return best[1], best[2], audit


def load_anchor(
    path: Path, cfg: dict[str, Any]
) -> tuple[pd.DataFrame, dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    exact = cfg["exact_columns"]
    labels = cfg["label_columns"]
    eligibility = cfg["eligibility_columns"]
    required = list(exact.values()) + list(labels.values()) + list(eligibility.values()) + cfg["survey_candidates"]
    columns, row_count = read_columns(path)
    missing = sorted(set(required) - set(columns))
    if missing:
        raise RuntimeError("exact design-layer columns missing: " + ", ".join(missing))

    frame = read_table(path, sorted(set(required))).copy()
    survey_column, survey, survey_audit = choose_survey_column(frame, cfg)
    if survey_column is None:
        raise RuntimeError("neither survey_origin nor preferred_spectroscopic_survey contains both APOGEE and GALAH identities")

    output = pd.DataFrame({
        "source_id": pd.to_numeric(frame[exact["source_id"]], errors="coerce"),
        "survey": survey,
        "R": pd.to_numeric(frame[exact["R"]], errors="coerce"),
        "Z": pd.to_numeric(frame[exact["Z"]], errors="coerce"),
        "abs_Z": pd.to_numeric(frame[exact["abs_Z"]], errors="coerce"),
        "teff": pd.to_numeric(frame[exact["teff"]], errors="coerce"),
        "logg": pd.to_numeric(frame[exact["logg"]], errors="coerce"),
        "spatial_block_stage4a": frame[exact["spatial_block"]],
    })
    for label, column in labels.items():
        output[label] = pd.to_numeric(frame[column], errors="coerce")
    for label, column in eligibility.items():
        output[f"{label}_gradient_primary_ok"] = frame[column].fillna(False).astype(bool)

    output = output[output["source_id"].notna() & output["survey"].notna()].copy()
    output["source_id"] = output["source_id"].astype("uint64")

    compare_columns = [
        column for column in output.columns
        if column not in ["source_id", "survey"]
    ]
    tolerance = float(cfg["numeric_conflict_tolerance"])
    duplicate_rows = []
    conflicts = False
    for keys, group in output.groupby(["source_id", "survey"], sort=False):
        if len(group) <= 1:
            continue
        conflict_columns = []
        for column in compare_columns:
            series = group[column]
            if pd.api.types.is_numeric_dtype(series):
                values = pd.to_numeric(series, errors="coerce").dropna().to_numpy(dtype=float)
                conflict = bool(
                    len(values) > 1
                    and np.nanmax(values) - np.nanmin(values) > tolerance
                )
            else:
                conflict = series.dropna().astype(str).nunique() > 1
            if conflict:
                conflict_columns.append(column)
        conflicts |= bool(conflict_columns)
        duplicate_rows.append({
            "source_id": int(keys[0]),
            "survey": str(keys[1]),
            "row_count": len(group),
            "conflict": str(bool(conflict_columns)).lower(),
            "conflict_columns": "|".join(conflict_columns),
        })

    if conflicts:
        collapsed = pd.DataFrame()
    else:
        collapsed = output.groupby(["source_id", "survey"], as_index=False).first()

    diagnostics = {
        "input_rows": row_count,
        "usable_rows_before_collapse": len(output),
        "collapsed_rows": len(collapsed),
        "survey_column": survey_column,
        "duplicate_group_count": len(duplicate_rows),
        "conflicting_duplicate_group_count": sum(row["conflict"] == "true" for row in duplicate_rows),
        "duplicate_identity_ready": not conflicts,
    }
    return collapsed, diagnostics, survey_audit, duplicate_rows


def profile_candidate(path: Path, cfg: dict[str, Any]) -> dict[str, Any] | None:
    columns, row_count = read_columns(path)
    aliases = cfg["enrichment_aliases"]
    mapping = {field: find_alias(columns, options) for field, options in aliases.items()}
    wide_snr = {
        survey: find_alias(columns, options)
        for survey, options in cfg["wide_snr_aliases"].items()
    }
    if not mapping["source_id"]:
        return None
    covered = [field for field in ["l", "b", "ra", "dec", "g_mag", "bp_rp", "snr", "distance_quality"] if mapping.get(field)]
    if any(wide_snr.values()):
        covered.append("wide_snr")
    if not covered:
        return None
    priority = (
        500 * int("stage4a" in str(path).lower())
        + 300 * int("stage3" in str(path).lower())
        + 200 * int("stage2" in str(path).lower())
        + 100 * len(covered)
        + max(row_count, 0) / 1_000_000
    )
    return {
        "path": path,
        "columns": columns,
        "row_count": row_count,
        "mapping": mapping,
        "wide_snr": wide_snr,
        "covered": covered,
        "priority": priority,
    }


def load_candidate(item: dict[str, Any], cfg: dict[str, Any]) -> pd.DataFrame:
    mapping = item["mapping"]
    wide_snr = item["wide_snr"]
    needed = [value for value in mapping.values() if value] + [value for value in wide_snr.values() if value]
    frame = read_table(item["path"], sorted(set(needed))).copy()
    base = pd.DataFrame({
        "source_id": pd.to_numeric(frame[mapping["source_id"]], errors="coerce")
    })
    if mapping.get("survey"):
        base["survey"] = frame[mapping["survey"]].map(lambda value: canonical_survey(value, cfg)).astype("string")
    for field in ["l", "b", "ra", "dec", "g_mag", "bp_rp", "snr", "distance_quality"]:
        column = mapping.get(field)
        if column:
            base[field] = pd.to_numeric(frame[column], errors="coerce")
    base = base[base["source_id"].notna()].copy()
    base["source_id"] = base["source_id"].astype("uint64")

    if not mapping.get("survey") and any(wide_snr.values()):
        pieces = []
        neutral = [column for column in ["l", "b", "ra", "dec", "g_mag", "bp_rp", "distance_quality"] if column in base.columns]
        for survey, snr_column in wide_snr.items():
            if not snr_column:
                continue
            part = base[["source_id"] + neutral].copy()
            part["survey"] = survey
            part["snr"] = pd.to_numeric(frame.loc[part.index, snr_column], errors="coerce")
            pieces.append(part)
        if pieces:
            base = pd.concat(pieces, ignore_index=True)

    keys = ["source_id"]
    if "survey" in base.columns and base["survey"].notna().any():
        keys.append("survey")
    if base.duplicated(keys).any():
        value_columns = [column for column in base.columns if column not in keys]
        # Identity-safe collapse: conflict blocks this candidate.
        for _, group in base.groupby(keys, sort=False):
            if len(group) <= 1:
                continue
            for column in value_columns:
                values = pd.to_numeric(group[column], errors="coerce").dropna().to_numpy(dtype=float)
                if len(values) > 1 and np.nanmax(values) - np.nanmin(values) > float(cfg["numeric_conflict_tolerance"]):
                    raise RuntimeError(f"conflicting duplicate candidate values in {item['path']} column {column}")
        base = base.groupby(keys, as_index=False).first()
    return base


def coalesce(
    base: pd.DataFrame,
    addition: pd.DataFrame,
    fields: list[str],
    join_keys: list[str],
) -> tuple[pd.DataFrame, dict[str, int]]:
    candidate_fields = [field for field in fields if field not in join_keys and field in addition.columns]
    before = {field: int(base[field].notna().sum()) if field in base.columns else 0 for field in fields}
    validate = "one_to_one" if join_keys == ["source_id", "survey"] else "many_to_one"
    joined = base.merge(
        addition[join_keys + candidate_fields],
        on=join_keys,
        how="left",
        suffixes=("", "__candidate"),
        validate=validate,
    )
    for field in candidate_fields:
        candidate = field + "__candidate"
        if field not in joined.columns:
            joined[field] = joined[candidate]
        else:
            joined[field] = joined[field].where(joined[field].notna(), joined[candidate])
        joined.drop(columns=[candidate], inplace=True)
    after = {field: int(joined[field].notna().sum()) if field in joined.columns else 0 for field in fields}
    return joined, {field: after[field] - before[field] for field in fields}


def support_complete_mask(frame: pd.DataFrame) -> pd.Series:
    scalar_required = ["R", "abs_Z", "teff", "logg", "snr", "g_mag", "bp_rp"]
    mask = pd.Series(True, index=frame.index)
    for field in scalar_required:
        if field not in frame.columns:
            return pd.Series(False, index=frame.index)
        mask &= frame[field].notna()
    sky_ready = (
        (frame.get("l", pd.Series(pd.NA, index=frame.index)).notna() & frame.get("b", pd.Series(pd.NA, index=frame.index)).notna())
        | (frame.get("ra", pd.Series(pd.NA, index=frame.index)).notna() & frame.get("dec", pd.Series(pd.NA, index=frame.index)).notna())
    )
    return mask & sky_ready


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads((root / "config/stage6d3a2d1_config.json").read_text(encoding="utf-8"))
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in ["validation", "summaries", "tables", "assembled", "reports", "diagnostics"]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg["prerequisite_validation"]
    prereq = json.loads(prereq_path.read_text(encoding="utf-8")) if prereq_path.exists() else {}
    prereq_ready = bool(
        prereq.get("UNIVERSAL_RUNTIME_TRACE_READY", False)
        and prereq.get("PROTECTED_STAGE4A_STAGE4B_UNMODIFIED", False)
        and prereq.get("NORMAL_SYSTEM_EXIT_HANDLED", False)
    )

    design_path = root / cfg["design_layer"]
    anchor = pd.DataFrame()
    anchor_diag: dict[str, Any] = {}
    survey_audit: list[dict[str, Any]] = []
    duplicate_audit: list[dict[str, Any]] = []
    anchor_error = ""
    if design_path.exists():
        try:
            anchor, anchor_diag, survey_audit, duplicate_audit = load_anchor(design_path, cfg)
        except Exception as exc:
            anchor_error = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
    else:
        anchor_error = f"design layer not found: {design_path}"

    write_csv(
        out / "tables/stage6d3a2d1_survey_identity_audit.csv",
        ["column", "apogee_count", "galah_count", "unmapped_count", "both_surveys_ready", "raw_values"],
        survey_audit,
    )
    write_csv(
        out / "tables/stage6d3a2d1_duplicate_key_audit.csv",
        ["source_id", "survey", "row_count", "conflict", "conflict_columns"],
        duplicate_audit,
    )
    write_json(
        out / "diagnostics/stage6d3a2d1_anchor_contract.json",
        {
            "design_layer": safe_rel(design_path, root),
            "design_layer_sha256": sha256_file(design_path) if design_path.exists() else "",
            "anchor_diagnostics": anchor_diag,
            "anchor_error": anchor_error,
            "exact_columns": cfg["exact_columns"],
            "label_columns": cfg["label_columns"],
            "eligibility_columns": cfg["eligibility_columns"],
        },
    )

    assembled = anchor.copy()
    for field in ["l", "b", "ra", "dec", "g_mag", "bp_rp", "snr", "distance_quality"]:
        if field not in assembled.columns:
            assembled[field] = pd.NA

    candidate_inventory = []
    candidate_items = []
    suffixes = set(cfg["tabular_suffixes"])
    if not anchor.empty:
        for rel_root in cfg["scan_roots"]:
            base = root / rel_root
            if not base.exists():
                continue
            for path in base.rglob("*"):
                if (
                    not path.is_file()
                    or path.suffix.lower() not in suffixes
                    or path.resolve() == design_path.resolve()
                ):
                    continue
                try:
                    item = profile_candidate(path, cfg)
                except Exception as exc:
                    candidate_inventory.append({
                        "path": safe_rel(path, root), "row_count": "", "covered_fields": "",
                        "source_id_column": "", "survey_column": "", "wide_snr_mapping": "",
                        "priority": -1, "read_error": f"{type(exc).__name__}: {exc}"
                    })
                    continue
                if item is None:
                    continue
                candidate_items.append(item)
                candidate_inventory.append({
                    "path": safe_rel(path, root),
                    "row_count": item["row_count"],
                    "covered_fields": "|".join(item["covered"]),
                    "source_id_column": item["mapping"]["source_id"],
                    "survey_column": item["mapping"].get("survey") or "",
                    "wide_snr_mapping": json.dumps(item["wide_snr"], sort_keys=True),
                    "priority": item["priority"],
                    "read_error": "",
                })
    candidate_inventory.sort(key=lambda row: (-float(row["priority"]), row["path"]))
    write_csv(
        out / "tables/stage6d3a2d1_enrichment_candidate_inventory.csv",
        ["path", "row_count", "covered_fields", "source_id_column", "survey_column", "wide_snr_mapping", "priority", "read_error"],
        candidate_inventory,
    )

    selected_bundle = []
    enrichment_audit = []
    loaded = []
    assembly_error = anchor_error
    if not anchor_error and not anchor.empty:
        try:
            anchor_ids = set(anchor["source_id"].astype("uint64"))
            candidate_items.sort(key=lambda item: (-item["priority"], str(item["path"])))
            for item in candidate_items[: int(cfg["maximum_candidates_to_load"])]:
                try:
                    frame = load_candidate(item, cfg)
                    overlap = len(anchor_ids.intersection(set(frame["source_id"].astype("uint64")))) / max(len(anchor_ids), 1)
                    if overlap < float(cfg["minimum_anchor_overlap_fraction"]):
                        continue
                    loaded.append({"item": item, "frame": frame, "overlap": overlap})
                except Exception:
                    continue

            fields = ["l", "b", "ra", "dec", "g_mag", "bp_rp", "snr", "distance_quality"]
            used = set()
            for _ in range(int(cfg["maximum_enrichment_files"])):
                before_complete = int(support_complete_mask(assembled).sum())
                best = None
                for row in loaded:
                    path_key = row["item"]["path"].resolve()
                    if path_key in used:
                        continue
                    frame = row["frame"]
                    join_keys = ["source_id", "survey"] if "survey" in frame.columns and frame["survey"].notna().any() else ["source_id"]
                    addition = frame.copy()
                    if join_keys == ["source_id"] and addition.duplicated(["source_id"]).any():
                        value_columns = [column for column in addition.columns if column != "source_id"]
                        addition = addition.groupby(["source_id"], as_index=False).first()
                    try:
                        trial, gains = coalesce(assembled, addition, fields, join_keys)
                    except Exception:
                        continue
                    after_complete = int(support_complete_mask(trial).sum())
                    complete_gain = after_complete - before_complete
                    total_gain = sum(max(int(value), 0) for value in gains.values())
                    score = 10000 * complete_gain + total_gain + int(100 * row["overlap"])
                    if (complete_gain > 0 or total_gain > 0) and (best is None or score > best["score"]):
                        best = {
                            "row": row, "trial": trial, "gains": gains,
                            "complete_gain": complete_gain, "score": score,
                            "join_keys": join_keys,
                        }
                if best is None:
                    break
                row = best["row"]
                assembled = best["trial"]
                used.add(row["item"]["path"].resolve())
                selected_bundle.append({
                    "path": row["item"]["path"],
                    "join_keys": best["join_keys"],
                    "score": best["score"],
                    "overlap": row["overlap"],
                })
                enrichment_audit.append({
                    "path": safe_rel(row["item"]["path"], root),
                    "join_keys": "|".join(best["join_keys"]),
                    "score": best["score"],
                    "complete_row_gain": best["complete_gain"],
                    "anchor_overlap_fraction": row["overlap"],
                    "field_gains": json.dumps(best["gains"], sort_keys=True),
                })
            assembly_error = ""
        except Exception as exc:
            assembly_error = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"

    write_csv(
        out / "tables/stage6d3a2d1_selected_enrichment_bundle.csv",
        ["bundle_order", "path", "join_keys", "score", "anchor_overlap_fraction"],
        [
            {
                "bundle_order": index + 1,
                "path": safe_rel(row["path"], root),
                "join_keys": "|".join(row["join_keys"]),
                "score": row["score"],
                "anchor_overlap_fraction": row["overlap"],
            }
            for index, row in enumerate(selected_bundle)
        ],
    )
    write_csv(
        out / "tables/stage6d3a2d1_enrichment_gain_audit.csv",
        ["path", "join_keys", "score", "complete_row_gain", "anchor_overlap_fraction", "field_gains"],
        enrichment_audit,
    )

    coverage_rows = []
    for field in [
        "source_id", "survey", "R", "Z", "abs_Z", "teff", "logg", "spatial_block_stage4a",
        "l", "b", "ra", "dec", "g_mag", "bp_rp", "snr", "distance_quality"
    ] + list(cfg["label_columns"].keys()) + [f"{label}_gradient_primary_ok" for label in cfg["label_columns"]]:
        coverage_rows.append({
            "field": field,
            "non_null_rows": int(assembled[field].notna().sum()) if field in assembled.columns else 0,
            "coverage_fraction": float(assembled[field].notna().mean()) if field in assembled.columns and len(assembled) else 0.0,
        })
    write_csv(
        out / "tables/stage6d3a2d1_assembled_field_coverage.csv",
        ["field", "non_null_rows", "coverage_fraction"],
        coverage_rows,
    )

    support_mask = support_complete_mask(assembled) if not assembled.empty else pd.Series(dtype=bool)
    complete_counts = {
        survey: int((support_mask & (assembled["survey"] == survey)).sum()) if not assembled.empty else 0
        for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]
    }
    label_counts = []
    if not assembled.empty:
        for label in cfg["label_columns"]:
            eligible = (
                assembled[label].notna()
                & assembled[f"{label}_gradient_primary_ok"].fillna(False).astype(bool)
                & support_mask
            )
            for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
                label_counts.append({
                    "label": label,
                    "survey": survey,
                    "eligible_complete_rows": int((eligible & (assembled["survey"] == survey)).sum()),
                })
    write_csv(
        out / "tables/stage6d3a2d1_label_survey_eligibility.csv",
        ["label", "survey", "eligible_complete_rows"],
        label_counts,
    )

    sky_ready = bool(
        not assembled.empty
        and (
            (assembled["l"].notna() & assembled["b"].notna()).any()
            or (assembled["ra"].notna() & assembled["dec"].notna()).any()
        )
    )
    snr_ready = bool(not assembled.empty and assembled["snr"].notna().any())
    photometry_ready = bool(
        not assembled.empty
        and assembled["g_mag"].notna().any()
        and assembled["bp_rp"].notna().any()
    )
    duplicate_ready = bool(anchor_diag.get("duplicate_identity_ready", False))
    exact_schema_ready = bool(not anchor_error and not anchor.empty)
    complete_ready = all(
        complete_counts[survey] >= int(cfg["minimum_complete_rows_per_survey"])
        for survey in complete_counts
    )
    source_ready = bool(
        exact_schema_ready
        and duplicate_ready
        and sky_ready
        and snr_ready
        and photometry_ready
        and complete_ready
        and not assembly_error
    )

    assembled_path = None
    if not assembled.empty:
        assembled_path = out / "assembled/stage6d3a2d1_production_source_assembled.parquet"
        try:
            assembled.to_parquet(assembled_path, index=False)
        except Exception:
            assembled_path = out / "assembled/stage6d3a2d1_production_source_assembled.csv"
            assembled.to_csv(assembled_path, index=False)

    remaining = []
    if anchor_error:
        remaining.append({"gate": "EXACT_WIDE_DESIGN_SCHEMA_READY", "required_action": anchor_error})
    if exact_schema_ready and not duplicate_ready:
        remaining.append({
            "gate": "SOURCE_SURVEY_DUPLICATE_IDENTITY_READY",
            "required_action": "Conflicting duplicate rows exist within (source_id, survey); inspect duplicate-key audit."
        })
    if exact_schema_ready and not sky_ready:
        remaining.append({
            "gate": "SKY_COORDINATE_SUPPORT_READY",
            "required_action": "No source-ID enrichment product supplied either Galactic l/b or equatorial ra/dec."
        })
    if exact_schema_ready and not snr_ready:
        remaining.append({
            "gate": "SURVEY_SPECIFIC_SNR_SUPPORT_READY",
            "required_action": "No defensible source×survey S/N product was joined. Do not substitute snr_na or a survey-neutral proxy."
        })
    if exact_schema_ready and not photometry_ready:
        remaining.append({
            "gate": "GAIA_PHOTOMETRY_SUPPORT_READY",
            "required_action": "Gaia G and BP-RP were not both recovered from a source-ID keyed frozen product."
        })
    if exact_schema_ready and sky_ready and snr_ready and photometry_ready and not complete_ready:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_COMPLETE_ROWS_READY",
            "required_action": (
                f"Need at least {cfg['minimum_complete_rows_per_survey']} support-complete rows per survey. "
                + json.dumps(complete_counts, sort_keys=True)
            )
        })
    write_csv(
        out / "tables/stage6d3a2d1_remaining_items.csv",
        ["gate", "required_action"],
        remaining,
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "design_layer": safe_rel(design_path, root),
        "design_layer_sha256": sha256_file(design_path) if design_path.exists() else "",
        "design_layer_input_rows": anchor_diag.get("input_rows", 0),
        "source_survey_rows": len(anchor),
        "survey_column": anchor_diag.get("survey_column", ""),
        "duplicate_group_count": anchor_diag.get("duplicate_group_count", 0),
        "conflicting_duplicate_group_count": anchor_diag.get("conflicting_duplicate_group_count", 0),
        "selected_enrichment_bundle": [safe_rel(row["path"], root) for row in selected_bundle],
        "assembled_source_table": safe_rel(assembled_path, root) if assembled_path else "",
        "assembled_rows": len(assembled),
        "support_complete_rows_by_survey": complete_counts,
        "anchor_error": anchor_error,
        "assembly_error": assembly_error,
        "prior_stage_outputs_modified": False,
        "STAGE6D3A2C_PREREQUISITE_READY": prereq_ready,
        "EXACT_WIDE_DESIGN_SCHEMA_READY": exact_schema_ready,
        "SOURCE_SURVEY_KEY_READY": exact_schema_ready,
        "SOURCE_SURVEY_DUPLICATE_IDENTITY_READY": duplicate_ready,
        "PRIMARY_LABEL_COLUMNS_READY": exact_schema_ready,
        "GRADIENT_ELIGIBILITY_FLAGS_READY": exact_schema_ready,
        "R_Z_STAGE4A_BLOCK_READY": exact_schema_ready,
        "TEFF_LOGG_READY": exact_schema_ready,
        "SKY_COORDINATE_SUPPORT_READY": sky_ready,
        "SURVEY_SPECIFIC_SNR_SUPPORT_READY": snr_ready,
        "GAIA_PHOTOMETRY_SUPPORT_READY": photometry_ready,
        "SOURCE_ID_ENRICHMENT_BUNDLE_READY": bool(selected_bundle),
        "PRODUCTION_SOURCE_COMPLETE_ROWS_READY": complete_ready,
        "PRODUCTION_SOURCE_ASSEMBLY_READY": source_ready,
        "TARGET_ABUNDANCE_MATCHING_FORBIDDEN": True,
        "STAGE6D3A2D1_LINEAGE_READY": bool(prereq_ready and exact_schema_ready and duplicate_ready),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": bool(prereq_ready and source_ready),
    }
    write_json(out / "validation/stage6d3a2d1_validation.json", validation)

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "exact_schema": {
            "source_id": cfg["exact_columns"]["source_id"],
            "survey_column": validation["survey_column"],
            "labels": cfg["label_columns"],
            "eligibility": cfg["eligibility_columns"],
            "R": cfg["exact_columns"]["R"],
            "abs_Z": cfg["exact_columns"]["abs_Z"],
            "spatial_block": cfg["exact_columns"]["spatial_block"],
        },
        "source_assembly": {
            "rows": len(assembled),
            "support_complete_rows_by_survey": complete_counts,
            "ready": source_ready,
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "The exact wide Stage-4A design layer and required support covariates are closed. Stage-6D3B construction is authorized."
            if validation["STAGE6D3B_COMMON_FOOTPRINT_READY"]
            else "The exact wide design-layer lineage is closed; D3B remains blocked only by the listed sky, S/N, photometry, duplicate, or complete-row gap."
        ),
    }
    write_json(out / "summaries/stage6d3a2d1_summary.json", summary)

    report = [
        "# Stage-6D3A2D1 exact wide design source assembly",
        "",
        f"- Design rows: `{validation['design_layer_input_rows']}`",
        f"- Source×survey rows: `{validation['source_survey_rows']}`",
        f"- Survey column: `{validation['survey_column']}`",
        f"- Conflicting duplicate groups: `{validation['conflicting_duplicate_group_count']}`",
        f"- Selected enrichment files: `{len(selected_bundle)}`",
        f"- APOGEE support-complete rows: `{complete_counts['APOGEE_NATIVE']}`",
        f"- GALAH support-complete rows: `{complete_counts['GALAH_CORRECTED']}`",
        f"- Stage-6D3B ready: `{validation['STAGE6D3B_COMMON_FOOTPRINT_READY']}`",
        "",
        "The anchor uses the exact Stage-4A `_hom`, `r_cyl_gc_kpc`, `abs_z_gc_kpc`, and label-specific gradient-primary flag columns.",
        "",
        "No target abundance is used as a matching or weighting covariate.",
        "",
    ]
    (out / "reports/stage6d3a2d1_exact_wide_design_source_assembly.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
