from __future__ import annotations
import argparse,hashlib,json
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def canon(o):
    return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage8b1e_config.json").read_text(encoding="utf-8"))
    prot=json.loads((root/"protocol/stage8b1e_protocol.json").read_text(encoding="utf-8"))
    pv=root/c["parent_validation"]; pt=root/c["parent_support_table"]
    if not pv.exists(): raise FileNotFoundError(pv)
    if not pt.exists(): raise FileNotFoundError(pt)

    v=json.loads(pv.read_text(encoding="utf-8"))
    t=pd.read_csv(pt)

    parent_guard=bool(
        v.get("STAGE8B1C1_PARENT_READY") is True and
        v.get("BOTH_SURVEYS_PRESENT") is True and
        v.get("PRIMARY_BLOCK_COUNT_READY") is True and
        v.get("SYNTHETIC_EM_SMOKE_READY") is True and
        v.get("ALL_7_KNOTS_BOTH_SURVEYS_SUPPORT_READY") is False and
        v.get("REAL_ALPHA3_MIXTURE_FIT_PERFORMED") is False and
        v.get("REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED") is False and
        v.get("REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED") is False
    )
    if not parent_guard:
        raise RuntimeError("Stage-8B1D parent guards failed")

    req_cols={"feh_knot","survey","effective_n","nside16_cells"}
    if not req_cols.issubset(t.columns):
        raise RuntimeError(f"support table missing columns: {sorted(req_cols-set(t.columns))}")

    original=sorted(float(x) for x in c["original_knots"])
    got=sorted(float(x) for x in t["feh_knot"].unique())
    if got!=original:
        raise RuntimeError(f"original knot identity mismatch: got={got}")

    miness=float(c["minimum_effective_n"]); mincells=int(c["minimum_cells"])
    t["support_pass"]=(t["effective_n"]>=miness)&(t["nside16_cells"]>=mincells)

    fail=t.loc[~t["support_pass"]].copy()
    expected_fail=bool(
        len(fail)==1 and
        float(fail.iloc[0]["feh_knot"])==-0.8 and
        str(fail.iloc[0]["survey"])=="APOGEE_NATIVE" and
        float(fail.iloc[0]["effective_n"])<miness
    )

    primary=set(float(x) for x in c["amended_primary_knots"])
    tp=t[t["feh_knot"].astype(float).isin(primary)].copy()
    primary_ready=bool(
        len(tp)==2*len(primary) and
        tp["support_pass"].all()
    )

    audit=set(float(x) for x in c["audit_only_low_support_knots"])
    disjoint=primary.isdisjoint(audit)
    union_ok=(primary|audit)==set(original)

    ready=bool(parent_guard and expected_fail and primary_ready and disjoint and union_ok)

    out=root/c["output_dir"]
    for q in ["validation","tables","freeze"]: (out/q).mkdir(parents=True,exist_ok=True)
    t.to_csv(out/"tables/stage8b1e_support_audit.csv",index=False)
    fail.to_csv(out/"tables/stage8b1e_failed_original_support_rows.csv",index=False)
    (out/"freeze/stage8b1e_protocol_frozen.json").write_text(
        (root/"protocol/stage8b1e_protocol.json").read_text(encoding="utf-8"),encoding="utf-8"
    )

    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "STAGE8B1D_PARENT_GUARDS_READY":parent_guard,
      "ORIGINAL_SUPPORT_FAILURE_EXACTLY_MINUS0P8_APOGEE":expected_fail,
      "ORIGINAL_FAILED_SUPPORT_ROWS":int(len(fail)),
      "AMENDED_PRIMARY_KNOTS":c["amended_primary_knots"],
      "AMENDED_PRIMARY_FEH_DOMAIN":c["amended_primary_feh_domain"],
      "AUDIT_ONLY_LOW_SUPPORT_KNOTS":c["audit_only_low_support_knots"],
      "ALL_6_AMENDED_PRIMARY_KNOTS_BOTH_SURVEYS_SUPPORT_READY":primary_ready,
      "ESS_THRESHOLD_UNCHANGED":True,
      "CELL_THRESHOLD_UNCHANGED":True,
      "PRACTICAL_MARGINS_UNCHANGED":True,
      "SYNTHETIC_POWER_AND_FPR_GATES_UNCHANGED":True,
      "ALPHA3_VALUES_USED_TO_SELECT_SUPPORTED_KNOTS":False,
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":False,
      "REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED":False,
      "MINUS0P8_PRIMARY_TRANSPORT_CLASSIFICATION_AUTHORIZED":False,
      "MINUS0P8_DISPOSITION":"LOW_SUPPORT_NOT_TESTABLE",
      "STAGE8B1E_SUPPORT_DOMAIN_AMENDMENT_FROZEN":ready,
      "STAGE8B2_SYNTHETIC_POWER_READY":ready,
      "STAGE8_REAL_MIXTURE_INTERPRETATION_AUTHORIZED":False,
      "PROTOCOL_CANONICAL_SHA256":canon(prot)
    }
    write_json(out/"validation/stage8b1e_validation.json",val)
    print(json.dumps(val,indent=2,ensure_ascii=False))
    return 0 if ready else 2

if __name__=="__main__":
    raise SystemExit(main())
