from __future__ import annotations
import argparse, csv, json, shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd


def now():
    return datetime.now(timezone.utc).isoformat()


def wjson(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def wcsv(path: Path, fields, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as h:
        w = csv.DictWriter(h, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3c6_config.json").read_text(encoding="utf-8")
    )

    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in ["validation", "tables", "summaries", "reports"]:
        (out / d).mkdir(parents=True, exist_ok=True)

    prepath = root / cfg["prerequisite_validation"]
    pre = json.loads(prepath.read_text()) if prepath.exists() else {}
    prereq = bool(
        pre.get("STAGE6D3C5_RIDGE_PATH_READY", False)
        and pre.get("RIDGE_C_PATH_OUTCOME_BLIND", False)
        and not pre.get("STAGE6D4_SCIENCE_MODELS_READY", True)
        and pre.get("classification")
        == "PROPENSITY_GATE_RECOVERABLE_BUT_OTHER_BALANCE_GATE_FAILS"
    )

    matrix_path = root / cfg["ridge_matrix"]
    smd_path = root / cfg["feature_smd"]
    matrix = pd.read_csv(matrix_path)
    feature_smd = pd.read_csv(smd_path)

    focus = matrix[
        (matrix["weight_formula_branch"] == cfg["focus_weight_formula"])
        & (matrix["normalization_branch"] == cfg["focus_normalization"])
    ].copy()

    focus["C"] = pd.to_numeric(focus["C"], errors="coerce")
    focus = focus.sort_values("C", ascending=False).reset_index(drop=True)

    numeric_cols = [
        "propensity_min", "propensity_max",
        "maximum_absolute_smd",
        "APOGEE_ESS_raw_ratio", "GALAH_ESS_raw_ratio"
    ]
    for col in numeric_cols:
        focus[col] = pd.to_numeric(focus[col], errors="coerce")

    focus["propensity_margin_low"] = (
        focus["propensity_min"] - float(cfg["propensity_lower_gate"])
    )
    focus["propensity_margin_high"] = (
        float(cfg["propensity_upper_gate"]) - focus["propensity_max"]
    )
    focus["smd_margin"] = (
        float(cfg["maximum_absolute_smd_gate"])
        - focus["maximum_absolute_smd"]
    )
    focus["APOGEE_ESS_margin"] = (
        focus["APOGEE_ESS_raw_ratio"]
        - float(cfg["minimum_ess_raw_ratio_gate"])
    )
    focus["GALAH_ESS_margin"] = (
        focus["GALAH_ESS_raw_ratio"]
        - float(cfg["minimum_ess_raw_ratio_gate"])
    )

    def failed_gates(row):
        failed = []
        if not bool(row["propensity_gate_pass"]):
            failed.append("PROPENSITY")
        if not bool(row["smd_gate_pass"]):
            failed.append("SMD")
        if not bool(row["ess_gate_pass"]):
            failed.append("ESS")
        return "|".join(failed) if failed else "NONE"

    focus["failed_gates"] = focus.apply(failed_gates, axis=1)

    focus.to_csv(
        out / "tables/stage6d3c6_focus_branch_frontier.csv",
        index=False,
    )

    first_prop_idx = focus.index[focus["propensity_gate_pass"] == True].tolist()
    first_prop_row = (
        focus.loc[first_prop_idx[0]].to_dict()
        if first_prop_idx else None
    )

    # Neighbor rows around first propensity-passing C.
    neighbor_rows = []
    if first_prop_idx:
        i = first_prop_idx[0]
        for j in range(max(0, i-2), min(len(focus), i+3)):
            neighbor_rows.append(focus.loc[j].to_dict())

    wcsv(
        out / "tables/stage6d3c6_first_propensity_pass_neighborhood.csv",
        list(focus.columns),
        neighbor_rows,
    )

    # Gate transitions along C.
    transitions = []
    gates = [
        ("propensity_gate_pass", "PROPENSITY"),
        ("smd_gate_pass", "SMD"),
        ("ess_gate_pass", "ESS"),
        ("all_numeric_gates_pass", "ALL"),
    ]
    for col, label in gates:
        vals = focus[col].astype(bool).to_numpy()
        Cs = focus["C"].to_numpy(float)
        for i in range(1, len(vals)):
            if vals[i] != vals[i-1]:
                transitions.append({
                    "gate": label,
                    "higher_C": Cs[i-1],
                    "higher_C_pass": bool(vals[i-1]),
                    "lower_C": Cs[i],
                    "lower_C_pass": bool(vals[i]),
                })
    wcsv(
        out / "tables/stage6d3c6_gate_transition_ledger.csv",
        ["gate", "higher_C", "higher_C_pass", "lower_C", "lower_C_pass"],
        transitions,
    )

    # Worst SMD feature at each C in focus branch.
    fs = feature_smd[
        feature_smd["branch"]
        == f"{cfg['focus_weight_formula']}__{cfg['focus_normalization']}"
    ].copy()
    fs["C"] = pd.to_numeric(fs["C"], errors="coerce")
    fs["absolute_smd"] = pd.to_numeric(fs["absolute_smd"], errors="coerce")

    worst_rows = []
    for C, group in fs.groupby("C", sort=False):
        group = group.sort_values("absolute_smd", ascending=False)
        if len(group):
            r = group.iloc[0]
            worst_rows.append({
                "C": float(C),
                "worst_smd_feature": str(r["feature"]),
                "worst_absolute_smd": float(r["absolute_smd"]),
                "signed_smd": float(r["smd_GALAH_minus_APOGEE"]),
            })
    worst_df = pd.DataFrame(worst_rows).sort_values("C", ascending=False)
    worst_df.to_csv(
        out / "tables/stage6d3c6_worst_smd_feature_by_C.csv",
        index=False,
    )

    # Determine exact blocking gate at first propensity PASS.
    if first_prop_row is not None:
        blockers = []
        if not bool(first_prop_row["smd_gate_pass"]):
            blockers.append("SMD")
        if not bool(first_prop_row["ess_gate_pass"]):
            blockers.append("ESS")
        first_prop_blockers = blockers
    else:
        first_prop_blockers = ["PROPENSITY"]

    # Check whether there exists any C with SMD+ESS pass simultaneously,
    # independent of propensity.
    balance_only = focus[
        (focus["smd_gate_pass"] == True)
        & (focus["ess_gate_pass"] == True)
    ]
    balance_only_Cs = sorted(
        [float(x) for x in balance_only["C"].tolist()],
        reverse=True,
    )

    # Check whether propensity and ESS pass while only SMD fails, etc.
    prop_ess_not_smd = focus[
        (focus["propensity_gate_pass"] == True)
        & (focus["ess_gate_pass"] == True)
        & (focus["smd_gate_pass"] == False)
    ]
    prop_smd_not_ess = focus[
        (focus["propensity_gate_pass"] == True)
        & (focus["smd_gate_pass"] == True)
        & (focus["ess_gate_pass"] == False)
    ]

    if first_prop_row is None:
        classification = "PROPENSITY_NEVER_PASSES"
        next_action = (
            "No corrected ridge C reaches the propensity gate. "
            "Further C tuning is not justified."
        )
    elif first_prop_blockers == ["SMD"]:
        classification = "PROPENSITY_RECOVERY_TRADES_OFF_AGAINST_SMD"
        next_action = (
            "At the first propensity-passing C, ESS remains adequate but SMD fails. "
            "The next justified test is a constrained positive cell-target calibration "
            "at fixed C that preserves equal survey totals per cell and enforces only "
            "the frozen SMD<=0.10 and ESS>=0.35 gates."
        )
    elif first_prop_blockers == ["ESS"]:
        classification = "PROPENSITY_RECOVERY_TRADES_OFF_AGAINST_ESS"
        next_action = (
            "At the first propensity-passing C, SMD is adequate but ESS fails. "
            "Do not add stronger weighting; inspect weight concentration/cell targets."
        )
    elif set(first_prop_blockers) == {"SMD", "ESS"}:
        classification = "PROPENSITY_RECOVERY_TRADES_OFF_AGAINST_SMD_AND_ESS"
        next_action = (
            "At the first propensity-passing C both SMD and ESS fail. "
            "A simple cell-target repair is unlikely to be sufficient; "
            "review the balancing design before production."
        )
    else:
        classification = "FIRST_PROPENSITY_PASS_HAS_NO_REMAINING_NUMERIC_BLOCKER"
        next_action = (
            "The first propensity-passing C appears numerically feasible; "
            "verify matrix consistency before protocol closure."
        )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "classification": classification,
        "focus_branch": (
            f"{cfg['focus_weight_formula']}__{cfg['focus_normalization']}"
        ),
        "first_propensity_passing_row": first_prop_row,
        "first_propensity_passing_blockers": first_prop_blockers,
        "balance_only_passing_C_values": balance_only_Cs,
        "propensity_plus_ESS_but_SMD_fail_count": int(len(prop_ess_not_smd)),
        "propensity_plus_SMD_but_ESS_fail_count": int(len(prop_smd_not_ess)),
        "STAGE6D3C5_PREREQUISITE_READY": prereq,
        "GATE_TRANSITION_LEDGER_READY": True,
        "FIRST_PROPENSITY_PASS_NEIGHBORHOOD_READY": True,
        "WORST_SMD_FEATURE_BY_C_READY": True,
        "NO_FROZEN_THRESHOLD_WEAKENED": True,
        "NO_MODEL_REFIT_PERFORMED": True,
        "NO_SCIENCE_MODEL_AUTHORIZED": True,
        "STAGE6D3C6_FRONTIER_LOCALIZATION_READY": prereq,
        "STAGE6D4_SCIENCE_MODELS_READY": False,
    }
    wjson(
        out / "validation/stage6d3c6_validation.json",
        validation,
    )

    summary = {
        "classification": classification,
        "first_propensity_passing_C": (
            first_prop_row["C"] if first_prop_row else None
        ),
        "first_propensity_passing_blockers": first_prop_blockers,
        "next_action": next_action,
        "scientific_disposition": (
            "D3C6 localizes the corrected ridge-path trade-off only. "
            "It does not change weights, thresholds, or protocol semantics."
        ),
    }
    wjson(
        out / "summaries/stage6d3c6_summary.json",
        summary,
    )

    (out / "reports/stage6d3c6_report.md").write_text(
        "\n".join([
            "# Stage-6D3C6 corrected gate-frontier localization",
            "",
            f"- Classification: `{classification}`",
            f"- Focus branch: "
            f"`{cfg['focus_weight_formula']}__{cfg['focus_normalization']}`",
            f"- First propensity-passing C: "
            f"`{first_prop_row['C'] if first_prop_row else None}`",
            f"- Remaining blockers there: `{first_prop_blockers}`",
            f"- Balance-only passing C values: `{balance_only_Cs}`",
            "- Stage-6D4 authorized: `False`",
            "",
            next_action,
            "",
        ]),
        encoding="utf-8",
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
