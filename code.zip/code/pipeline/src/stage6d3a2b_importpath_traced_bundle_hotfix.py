from __future__ import annotations
import argparse, copy, csv, hashlib, json, os, re, shutil, subprocess, sys, traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import pandas as pd
import yaml
PACKAGE_ROOT=Path(__file__).resolve().parents[1]
def now():return datetime.now(timezone.utc).isoformat()
def rel(p,r):
    try:return str(p.resolve().relative_to(r.resolve())).replace('\\','/')
    except Exception:return str(p).replace('\\','/')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def wjson(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False,default=str)+'\n',encoding='utf-8')
def wcsv(p,fields,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
def columns(p):
    if p.suffix.lower()=='.parquet':
        import pyarrow.parquet as pq
        q=pq.ParquetFile(p);return list(q.schema_arrow.names),int(q.metadata.num_rows)
    return list(pd.read_csv(p,nrows=5).columns),-1
def read(p,cols=None):return pd.read_parquet(p,columns=cols) if p.suffix.lower()=='.parquet' else pd.read_csv(p,usecols=cols)
def alias(cols,opts):
    m={c.lower():c for c in cols}
    for o in opts:
        if o.lower() in m:return m[o.lower()]
    return None
def tok(v):return re.sub(r'[^a-z0-9]+','_',v.lower()).strip('_')
def label_col(cols,label,variants):
    m={tok(c):c for c in cols}
    for v in variants[label]:
        if tok(v) in m:return m[tok(v)]
    return None
def patch_cfg(obj,outdir,logdir):
    obj=copy.deepcopy(obj);audit=[]
    def walk(v,path):
        if isinstance(v,dict):
            for k in list(v):
                q=path+[str(k)];low=str(k).lower()
                if low=='stage4a_output_dir':audit.append({'json_path':'.'.join(q),'action':'preserved','old_value':str(v[k]),'new_value':str(v[k])})
                elif low=='output_dir':old=v[k];v[k]=outdir;audit.append({'json_path':'.'.join(q),'action':'redirected','old_value':str(old),'new_value':outdir})
                elif low=='log_dir':old=v[k];v[k]=logdir;audit.append({'json_path':'.'.join(q),'action':'redirected','old_value':str(old),'new_value':logdir})
                else:walk(v[k],q)
        elif isinstance(v,list):
            for i,x in enumerate(v):walk(x,path+[str(i)])
    walk(obj,[]);return obj,audit
def parse_trace(p,root):
    out=[]
    if not p.exists():return out
    for line in p.read_text(encoding='utf-8').splitlines():
        try:x=json.loads(line)
        except Exception:continue
        raw=x.get('path','');target=Path(raw) if raw else None
        out.append({'timestamp_utc':x.get('timestamp_utc',''),'operation':x.get('operation',''),'path':rel(target,root) if target else '','absolute_path':raw,'exists_after_run':str(target.exists()).lower() if target else '','status':x.get('status',''),'error':x.get('error','')})
    return out
def infer_survey(p,cfg):
    s=str(p).lower();a=any(t in s for t in cfg['survey_normalization']['APOGEE_NATIVE']);g=any(t in s for t in cfg['survey_normalization']['GALAH_CORRECTED'])
    return 'APOGEE_NATIVE' if a and not g else ('GALAH_CORRECTED' if g and not a else None)
def norm_survey(s,cfg):
    out=pd.Series(pd.NA,index=s.index,dtype='string');low=s.astype('string').str.lower()
    for canon,tokens in cfg['survey_normalization'].items():
        mask=pd.Series(False,index=s.index)
        for t in tokens:mask|=low.str.contains(t.lower(),na=False,regex=False)
        out.loc[mask]=canon
    return out
def profile(p,cfg):
    cols,n=columns(p);mapping={k:alias(cols,v) for k,v in cfg['aliases'].items()};lm={lab:label_col(cols,lab,cfg['label_variants']) for lab in cfg['labels']}
    return {'columns':cols,'row_count':n,'mapping':mapping,'label_mapping':lm,'inferred_survey':infer_survey(p,cfg)}
def canon(p,item,cfg):
    m=item['mapping'];lm=item['label_mapping'];need=[m[k] for k in cfg['required_fields']+['distance_quality'] if m.get(k)]+[lm[k] for k in cfg['labels'] if lm.get(k)];need=sorted(set(need));f=read(p,need).copy()
    for k in cfg['required_fields']+['distance_quality']:
        if m.get(k):f[k]=f[m[k]]
    for k in cfg['labels']:
        if lm.get(k):f[k]=pd.to_numeric(f[lm[k]],errors='coerce')
    if 'survey' in f:f['survey']=norm_survey(f['survey'],cfg)
    elif item['inferred_survey']:f['survey']=item['inferred_survey']
    return f
def collapse(f,survey=True):
    f=f.copy();f['source_id']=pd.to_numeric(f['source_id'],errors='coerce');f=f[f['source_id'].notna()].copy();f['source_id']=f['source_id'].astype('uint64');keys=['source_id']
    if survey and 'survey' in f and f['survey'].notna().any():keys.append('survey')
    d=int(f.duplicated(keys).sum())
    if d:
        vals=[c for c in f.columns if c not in keys];f=f.groupby(keys,as_index=False).agg({c:'first' for c in vals})
    return f,d,keys
def coalesce(base,add,fields,keys):
    cand=[x for x in fields if x not in keys and x in add];before={x:int(base[x].notna().sum()) if x in base else 0 for x in fields};validate='one_to_one' if keys==['source_id','survey'] else 'many_to_one';j=base.merge(add[keys+cand],on=keys,how='left',suffixes=('','__c'),validate=validate)
    for x in cand:
        c=x+'__c';j[x]=j[c] if x not in j else j[x].where(j[x].notna(),j[c]);j.drop(columns=[c],inplace=True)
    after={x:int(j[x].notna().sum()) if x in j else 0 for x in fields};return j,{x:after[x]-before[x] for x in fields}
def complete(f,cfg):
    req=[x for x in cfg['required_fields'] if x!='source_id']+cfg['labels'];m=pd.Series(True,index=f.index)
    for x in req:
        if x not in f:return pd.Series(False,index=f.index)
        m&=f[x].notna()
    return m
def interaction_schema(p,cfg):
    if any(t in str(p).lower() for t in cfg['interaction_excluded_tokens']):return False,{'reason':'excluded_path_token'}
    cols,n=columns(p);lab=alias(cols,cfg['aliases']['label']);wide=[c for c in cols if any(t in c.lower() for t in cfg['interaction_tokens'])];ready=bool(lab and wide);return ready,{'row_count':n,'label_column':lab,'wide_interaction_columns':wide,'reason':'' if ready else 'science_interaction_schema_not_found'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--project-root',default='.');args=ap.parse_args();root=Path(args.project_root).resolve();cfg=json.loads((root/'config/stage6d3a2b_config.json').read_text(encoding='utf-8'));out=root/cfg['output_dir']
    if out.exists():shutil.rmtree(out)
    for d in ['validation','summaries','tables','trace','shadow','assembled','reports']:(out/d).mkdir(parents=True,exist_ok=True)
    d3a=json.loads((root/cfg['prerequisite_stage6d3a']).read_text(encoding='utf-8'));protocol=bool(d3a.get('STAGE6D3A_PROTOCOL_READY') and d3a.get('PROTOCOL_SEMANTIC_IDENTITY_READY') and d3a.get('FROZEN_FULL_SUPPORT_GRADIENTS_READY') and d3a.get('FROZEN_FULL_SUPPORT_BOOTSTRAP_READY'))
    d3a2a=json.loads((root/cfg['prerequisite_stage6d3a2a']).read_text(encoding='utf-8'));prior=bool(d3a2a.get('prior_failure_category')=='module_import_failure' and d3a2a.get('PRIOR_ZERO_TRACE_FAILURE_CLASSIFIED'))
    original=yaml.safe_load((root/cfg['stage4b_config']).read_text(encoding='utf-8'));shadow,audit=patch_cfg(original,cfg['shadow_output_dir'],cfg['shadow_log_dir']);shadow_path=root/cfg['shadow_config'];shadow_path.write_text(yaml.safe_dump(shadow,sort_keys=False,allow_unicode=True),encoding='utf-8');wcsv(out/'tables/stage6d3a2b_shadow_config_audit.csv',['json_path','action','old_value','new_value'],audit)
    trace_path=root/cfg['trace_log'];trace_path.unlink(missing_ok=True);wrapper=PACKAGE_ROOT/'trace_hook/run_with_trace.py';script=root/cfg['stage4b_script'];env=os.environ.copy();env['RGB_STAGE6D3_TRACE_LOG']=str(trace_path.resolve());env['RGB_STAGE6D3_PROJECT_ROOT']=str(root);cmd=[sys.executable,str(wrapper),str(script.resolve()),'--config',str(shadow_path.resolve())];done=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True);(out/'trace/stage4b_stdout.txt').write_text(done.stdout,encoding='utf-8');(out/'trace/stage4b_stderr.txt').write_text(done.stderr,encoding='utf-8')
    tr=parse_trace(trace_path,root);wcsv(out/'tables/stage6d3a2b_runtime_io_trace.csv',['timestamp_utc','operation','path','absolute_path','exists_after_run','status','error'],tr);bootstrap=any(x['operation']=='trace_bootstrap' and x['status']!='error' for x in tr);finish=any(x['operation']=='trace_complete' and x['status']!='error' for x in tr);reads=list(dict.fromkeys(Path(x['absolute_path']).resolve() for x in tr if x['operation'] in {'read_csv','read_parquet'} and x['status']!='error' and x['absolute_path'] and Path(x['absolute_path']).exists()));writes=list(dict.fromkeys(Path(x['absolute_path']).resolve() for x in tr if x['operation'] in {'write_csv','write_parquet'} and x['status']!='error' and x['absolute_path'] and Path(x['absolute_path']).exists()));trace_ready=bool(bootstrap and reads)
    traced=[]
    for p in reads:
        try:
            it=profile(p,cfg);f=canon(p,it,cfg)
            if 'source_id' not in f:continue
            f,d,k=collapse(f,True);score=1000+500*int('survey' in f and f['survey'].notna().any())+500*int(all(x in f and f[x].notna().any() for x in ['R','Z']))+100*sum(x in f and f[x].notna().any() for x in cfg['labels'])+20*sum(x in f and f[x].notna().any() for x in cfg['required_fields']);traced.append({'path':p,'item':it,'frame':f,'dup':d,'keys':k,'score':score})
        except Exception:pass
    bases=[x for x in traced if 'survey' in x['frame'] and x['frame']['survey'].notna().any() and len(x['frame'])>=cfg['minimum_base_rows'] and (all(y in x['frame'] and x['frame'][y].notna().any() for y in ['R','Z']) or sum(y in x['frame'] and x['frame'][y].notna().any() for y in cfg['labels'])>=3)];bases.sort(key=lambda x:(-x['score'],str(x['path'])))
    assembled=pd.DataFrame();bundle=[];greedy=[];err='';counts={'APOGEE_NATIVE':0,'GALAH_CORRECTED':0};assembled_path=None
    if bases:
        try:
            allf=cfg['required_fields']+['distance_quality']+cfg['labels'];frames=[]
            for x in bases:
                f=x['frame'].copy()
                for c in allf:
                    if c not in f:f[c]=pd.NA
                frames.append(f[allf]);bundle.append({'role':'exact_traced_base','path':x['path'],'keys':x['keys'],'dup':x['dup'],'traced':True,'score':x['score']})
            assembled=pd.concat(frames,ignore_index=True,sort=False);assembled,_,_=collapse(assembled,True);basepaths={x['path'] for x in bases};pool=[{**x,'traced':True} for x in traced if x['path'] not in basepaths];seen={x['path'] for x in traced}
            for rr in cfg['scan_roots']:
                b=root/rr
                if not b.exists():continue
                for p in b.rglob('*'):
                    if not p.is_file() or p.suffix.lower() not in cfg['suffixes'] or p.resolve() in seen:continue
                    try:
                        it=profile(p,cfg)
                        if not it['mapping'].get('source_id'):continue
                        f=canon(p,it,cfg)
                        if 'source_id' not in f:continue
                        f,d,k=collapse(f,True);pool.append({'path':p.resolve(),'item':it,'frame':f,'dup':d,'keys':k,'score':0,'traced':False})
                    except Exception:pass
            ids=set(assembled['source_id'].tolist());eligible=[]
            for x in pool:
                ov=len(ids.intersection(set(x['frame']['source_id'].tolist())))/max(len(ids),1)
                if ov>=cfg['minimum_anchor_overlap_fraction']:x['overlap']=ov;eligible.append(x)
            used=set(basepaths)
            for _ in range(cfg['maximum_enrichment_files']):
                cur=int(complete(assembled,cfg).sum());best=None
                for x in eligible:
                    if x['path'] in used:continue
                    keys=['source_id','survey'] if 'survey' in x['frame'] and x['frame']['survey'].notna().any() else ['source_id'];add=x['frame']
                    if keys==['source_id']:add,_,_=collapse(add,False)
                    try:trial,g=coalesce(assembled,add,allf,keys)
                    except Exception:continue
                    gain=int(complete(trial,cfg).sum())-cur;tot=sum(max(int(v),0) for v in g.values());score=10000*gain+tot+1000*int(x['traced'])+int(100*x['overlap'])
                    if (gain>0 or tot>0) and (best is None or score>best['score']):best={'x':x,'trial':trial,'g':g,'gain':gain,'score':score,'keys':keys}
                if best is None:break
                x=best['x'];assembled=best['trial'];used.add(x['path']);bundle.append({'role':'traced_enrichment' if x['traced'] else 'frozen_upstream_enrichment','path':x['path'],'keys':best['keys'],'dup':x['dup'],'traced':x['traced'],'score':best['score']});greedy.append({'path':rel(x['path'],root),'traced':str(x['traced']).lower(),'score':best['score'],'join_keys':'|'.join(best['keys']),'complete_row_gain':best['gain'],'anchor_overlap_fraction':x['overlap'],'field_gains':json.dumps(best['g'],sort_keys=True)})
            cm=complete(assembled,cfg)
            for s in counts:counts[s]=int((cm & (assembled['survey']==s)).sum())
            assembled_path=out/'assembled/stage6d3a2b_production_source_assembled.parquet'
            try:assembled.to_parquet(assembled_path,index=False)
            except Exception:assembled_path=out/'assembled/stage6d3a2b_production_source_assembled.csv';assembled.to_csv(assembled_path,index=False)
        except Exception as e:err=f'{type(e).__name__}: {e}\n{traceback.format_exc()}'
    else:err='No exact traced survey-bearing source table or survey-specific table pair contains source ID plus gradient coordinates or at least three primary labels.'
    wcsv(out/'tables/stage6d3a2b_selected_source_bundle.csv',['bundle_order','role','path','join_keys','duplicate_keys','traced','score'],[{'bundle_order':i+1,'role':x['role'],'path':rel(x['path'],root),'join_keys':'|'.join(x['keys']),'duplicate_keys':x['dup'],'traced':str(x['traced']).lower(),'score':x['score']} for i,x in enumerate(bundle)]);wcsv(out/'tables/stage6d3a2b_greedy_enrichment_audit.csv',['path','traced','score','join_keys','complete_row_gain','anchor_overlap_fraction','field_gains'],greedy)
    coverage=[]
    if not assembled.empty:
        for c in cfg['required_fields']+['distance_quality']+cfg['labels']:coverage.append({'field':c,'non_null_rows':int(assembled[c].notna().sum()) if c in assembled else 0,'coverage_fraction':float(assembled[c].notna().mean()) if c in assembled else 0.0})
    wcsv(out/'tables/stage6d3a2b_assembled_field_coverage.csv',['field','non_null_rows','coverage_fraction'],coverage)
    contexts=[]
    for d in [root/'outputs/stage4b',root/cfg['shadow_output_dir']]:
        for name in cfg['interaction_preferred_names']:
            p=d/name
            if p.exists():
                ready,sch=interaction_schema(p,cfg);contexts.append({'path':p,'ready':ready,'schema':sch,'traced_write':p.resolve() in writes})
    wcsv(out/'tables/stage6d3a2b_interaction_context_audit.csv',['path','ready','traced_write','label_column','wide_interaction_columns','reason'],[{'path':rel(x['path'],root),'ready':str(x['ready']).lower(),'traced_write':str(x['traced_write']).lower(),'label_column':x['schema'].get('label_column',''),'wide_interaction_columns':'|'.join(x['schema'].get('wide_interaction_columns',[])),'reason':x['schema'].get('reason','')} for x in contexts]);context=next((x for x in contexts if x['ready']),None)
    source_ready=bool(not err and assembled_path and all(counts[s]>=cfg['minimum_complete_rows_per_survey'] for s in counts));remaining=[]
    if not protocol:remaining.append({'gate':'STAGE6D3A_BASELINE_PROTOCOL_READY','required_action':'Restore frozen Stage-6D3A protocol and authoritative full-support gradient/bootstrap inputs.'})
    if not trace_ready:remaining.append({'gate':'IMPORTPATH_CORRECTED_RUNTIME_TRACE_READY','required_action':f'No valid traced read; returncode={done.returncode}. Inspect trace stdout/stderr.'})
    if err:remaining.append({'gate':'TRACED_SOURCE_BUNDLE_READY','required_action':err})
    elif not source_ready:remaining.append({'gate':'PRODUCTION_SOURCE_COMPLETE_ROWS_READY','required_action':f"Need at least {cfg['minimum_complete_rows_per_survey']} complete rows per survey. Observed: {json.dumps(counts,sort_keys=True)}"})
    if context is None:remaining.append({'gate':'EXISTING_INTERACTION_CONTEXT_READY','required_action':'Optional interaction context absent; does not block D3B because D4 refits it.'})
    wcsv(out/'tables/stage6d3a2b_remaining_items.csv',['gate','required_action'],remaining);ready=bool(protocol and trace_ready and source_ready)
    val={'stage':cfg['stage'],'protocol_version':cfg['protocol_version'],'implementation_version':cfg['implementation_version'],'timestamp_utc':now(),'project_root':str(root),'exact_command':' '.join(cmd),'execution_returncode':done.returncode,'trace_bootstrap_event_ready':bootstrap,'trace_completion_event_ready':finish,'trace_event_count':len(tr),'read_path_count':len(reads),'write_path_count':len(writes),'traced_read_paths':[rel(p,root) for p in reads],'traced_write_paths':[rel(p,root) for p in writes],'selected_source_bundle':[rel(x['path'],root) for x in bundle],'assembled_source_table':rel(assembled_path,root) if assembled_path else '','assembled_rows':len(assembled),'complete_rows_by_survey':counts,'selected_interaction_context':rel(context['path'],root) if context else '','assembly_error':err,'prior_stage_outputs_modified':False,'STAGE6D3A_BASELINE_PROTOCOL_READY':protocol,'PRIOR_MODULE_IMPORT_FAILURE_CONFIRMED':prior,'SCRIPT_DIRECTORY_INSERTED_IN_SYS_PATH':True,'PROJECT_ROOT_INSERTED_IN_SYS_PATH':True,'TRACE_BOOTSTRAP_READY':bootstrap,'EXACT_STAGE4B_RUNTIME_TRACE_READY':trace_ready,'SHADOW_STAGE4B_REPLAY_COMPLETED':bool(done.returncode==0 and finish),'TRACED_BASE_BUNDLE_READY':bool(bases),'SURVEY_AWARE_SOURCE_ID_JOIN_READY':bool(bundle),'PRODUCTION_SOURCE_ASSEMBLY_READY':source_ready,'CLAIM_LEDGER_EXCLUDED_FROM_INTERACTION_ROLE':True,'EXISTING_INTERACTION_CONTEXT_READY':context is not None,'INTERACTION_CONTEXT_REQUIRED_FOR_D3B':False,'STAGE6D3A2B_LINEAGE_READY':bool(protocol and trace_ready),'STAGE6D3B_COMMON_FOOTPRINT_READY':ready};wjson(out/'validation/stage6d3a2b_validation.json',val)
    summary={'stage':cfg['stage'],'timestamp_utc':now(),'runtime_trace':{'returncode':done.returncode,'bootstrap_ready':bootstrap,'completion_ready':finish,'read_paths':val['traced_read_paths'],'write_paths':val['traced_write_paths']},'source_assembly':{'bundle':val['selected_source_bundle'],'assembled_rows':len(assembled),'complete_rows_by_survey':counts,'ready':source_ready},'interaction_context':{'path':val['selected_interaction_context'],'ready':context is not None,'required_for_d3b':False},'remaining_items':remaining,'scientific_disposition':'The import-path-corrected trace and production-source bundle are closed. Stage-6D3B common-footprint construction is authorized.' if ready else 'Import-path correction is audited; common-footprint construction remains blocked by the listed traced-input or complete-row gap.'};wjson(out/'summaries/stage6d3a2b_summary.json',summary)
    (out/'reports/stage6d3a2b_importpath_traced_bundle.md').write_text('\n'.join(['# Stage-6D3A2B import-path-corrected traced bundle','',f'- Prior module-import failure confirmed: `{prior}`',f'- Trace bootstrap event: `{bootstrap}`',f'- Shadow replay completed: `{bool(done.returncode==0 and finish)}`',f'- Traced reads: `{len(reads)}`',f'- Traced writes: `{len(writes)}`',f'- Base bundle files: `{len(bases)}`',f'- Selected bundle files: `{len(bundle)}`',f'- Assembled rows: `{len(assembled)}`',f'- Complete APOGEE rows: `{counts["APOGEE_NATIVE"]}`',f'- Complete GALAH rows: `{counts["GALAH_CORRECTED"]}`',f'- Stage-6D3B ready: `{ready}`','']),encoding='utf-8')
    print(json.dumps({'validation':val,'summary':summary},indent=2,ensure_ascii=False));return 0
if __name__=='__main__':raise SystemExit(main())
