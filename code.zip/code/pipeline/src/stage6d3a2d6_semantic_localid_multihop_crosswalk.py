from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
import traceback
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


UINT64_MAX = 18446744073709551615
FLOAT_EXACT_INTEGER_MAX = 9007199254740991


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def normalise_name(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def read_columns(path: Path) -> tuple[list[str], int]:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        import pyarrow.parquet as pq
        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    if suffix == ".feather":
        import pyarrow.feather as feather
        table = feather.read_table(path)
        return list(table.column_names), int(table.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def read_table(
    path: Path,
    columns: list[str] | None = None,
    exact_string_columns: list[str] | None = None,
) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path, columns=columns)
    if suffix == ".feather":
        return pd.read_feather(path, columns=columns)
    dtype = (
        {column: "string" for column in exact_string_columns}
        if exact_string_columns else None
    )
    return pd.read_csv(path, usecols=columns, dtype=dtype)


def resolve_with_fallback(path: Path) -> Path | None:
    for candidate in [
        path,
        path.with_suffix(".csv"),
        path.with_suffix(".feather"),
    ]:
        if candidate.exists():
            return candidate
    return None


def find_alias(columns: list[str], aliases: list[str]) -> str | None:
    lookup = {normalise_name(column): column for column in columns}
    for alias in aliases:
        token = normalise_name(alias)
        if token in lookup:
            return lookup[token]
    return None


def all_alias_matches(columns: list[str], aliases: list[str]) -> list[str]:
    lookup = {normalise_name(column): column for column in columns}
    matches = []
    for alias in aliases:
        token = normalise_name(alias)
        if token in lookup and lookup[token] not in matches:
            matches.append(lookup[token])
    return matches


def local_family_matches(
    columns: list[str],
    cfg: dict[str, Any],
) -> dict[str, list[str]]:
    lookup = {normalise_name(column): column for column in columns}
    output: dict[str, list[str]] = {}
    for family, aliases in cfg["local_id_families"].items():
        matches = []
        alias_tokens = {normalise_name(alias) for alias in aliases}
        for token, original in lookup.items():
            if token in alias_tokens and original not in matches:
                matches.append(original)
        if matches:
            output[family] = matches
    return output


def path_excluded(path: Path, root: Path, cfg: dict[str, Any]) -> bool:
    text = safe_rel(path, root).lower().replace("\\", "/")
    return any(token.lower() in text for token in cfg["excluded_path_tokens"])


def path_is_galah(path: Path, cfg: dict[str, Any]) -> bool:
    token = normalise_name(str(path))
    return any(
        normalise_name(value) in token
        for value in cfg["galah_survey_values"]
    )


def detect_snr_contract(
    columns: list[str],
    cfg: dict[str, Any],
) -> tuple[str | None, list[str], dict[str, str]]:
    scalar = find_alias(columns, cfg["galah_scalar_snr_aliases"])
    if scalar:
        return "scalar_native_snr", [scalar], {}
    channels = {}
    for role, aliases in cfg["galah_channel_snr_alias_groups"].items():
        column = find_alias(columns, aliases)
        if column:
            channels[role] = column
    if len(channels) >= int(cfg["minimum_galah_finite_channels"]):
        return "galah_channel_median", list(channels.values()), channels
    return None, [], channels


def clean_uint64(series: pd.Series) -> pd.Series:
    output = pd.Series(pd.NA, index=series.index, dtype="UInt64")
    if pd.api.types.is_unsigned_integer_dtype(series.dtype):
        return series.astype("UInt64")
    if pd.api.types.is_integer_dtype(series.dtype):
        numeric = series.astype("Int64")
        valid = numeric.notna() & (numeric >= 0)
        if valid.any():
            output.loc[valid] = pd.array(
                numeric.loc[valid].astype("string"), dtype="UInt64"
            )
        return output
    if pd.api.types.is_float_dtype(series.dtype):
        numeric = pd.to_numeric(series, errors="coerce")
        valid = (
            numeric.notna()
            & np.isfinite(numeric)
            & (numeric >= 0)
            & (numeric <= FLOAT_EXACT_INTEGER_MAX)
            & (numeric == np.floor(numeric))
        )
        if valid.any():
            output.loc[valid] = pd.array(
                numeric.loc[valid].astype("uint64").astype("string"),
                dtype="UInt64",
            )
        return output

    text = series.astype("string").str.strip()
    text = text.str.replace(r"^\+", "", regex=True)
    valid = text.str.fullmatch(r"[0-9]+", na=False)
    if valid.any():
        values = text.loc[valid].str.lstrip("0").mask(lambda x: x == "", "0")
        within_length = values.str.len() <= len(str(UINT64_MAX))
        bounded = values[within_length]
        if not bounded.empty:
            same_length = bounded.str.len() == len(str(UINT64_MAX))
            within_max = (~same_length) | (bounded <= str(UINT64_MAX))
            bounded = bounded[within_max]
            if not bounded.empty:
                output.loc[bounded.index] = pd.array(
                    bounded, dtype="UInt64"
                )
    return output


def normalise_local_id(series: pd.Series, family: str) -> pd.Series:
    if pd.api.types.is_integer_dtype(series.dtype):
        text = series.astype("Int64").astype("string")
    elif pd.api.types.is_float_dtype(series.dtype):
        numeric = pd.to_numeric(series, errors="coerce")
        safe = (
            numeric.notna()
            & np.isfinite(numeric)
            & (np.abs(numeric) <= FLOAT_EXACT_INTEGER_MAX)
            & (numeric == np.floor(numeric))
        )
        text = pd.Series(pd.NA, index=series.index, dtype="string")
        text.loc[safe] = numeric.loc[safe].astype("int64").astype("string")
    else:
        text = series.astype("string").str.strip()
        numeric_decimal = text.str.fullmatch(r"[+]?[0-9]+(?:\.0+)?", na=False)
        if numeric_decimal.any():
            canonical = (
                text.loc[numeric_decimal]
                .str.replace(r"^\+", "", regex=True)
                .str.replace(r"\.0+$", "", regex=True)
                .str.lstrip("0")
                .mask(lambda x: x == "", "0")
            )
            text.loc[numeric_decimal] = canonical

    text = text.str.strip().replace(
        {"": pd.NA, "nan": pd.NA, "None": pd.NA, "<NA>": pd.NA}
    )
    if family == "tmass_id":
        text = (
            text.str.upper()
            .str.replace(r"^2MASS", "", regex=True)
            .str.replace(r"^J", "", regex=True)
            .str.replace(r"[\s_-]+", "", regex=True)
        )
    elif family in {"sobject_id", "galah_object_id"}:
        text = text.str.upper().str.replace(r"\s+", "", regex=True)
    return text


def build_snr(
    frame: pd.DataFrame,
    contract: str,
    columns: list[str],
    cfg: dict[str, Any],
) -> pd.Series:
    if contract == "scalar_native_snr":
        snr = pd.to_numeric(frame[columns[0]], errors="coerce")
    else:
        channels = pd.DataFrame({
            column: pd.to_numeric(frame[column], errors="coerce")
            for column in columns
        })
        finite = channels.notna().sum(axis=1)
        snr = channels.median(axis=1, skipna=True)
        snr.loc[
            finite < int(cfg["minimum_galah_finite_channels"])
        ] = np.nan
    snr = pd.to_numeric(snr, errors="coerce")
    snr.loc[
        ~np.isfinite(snr)
        | (snr <= float(cfg["snr_minimum_exclusive"]))
        | (snr > float(cfg["snr_maximum"]))
    ] = np.nan
    return snr


def functional_map(
    left: pd.Series,
    right: pd.Series,
    left_name: str,
    right_name: str,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    frame = pd.DataFrame({
        left_name: left,
        right_name: right,
    }).dropna()
    frame = frame.drop_duplicates()
    conflicts = (
        frame.groupby(left_name)[right_name].nunique() > 1
        if not frame.empty else pd.Series(dtype=bool)
    )
    ready = bool(not conflicts.any())
    if ready:
        frame = frame.drop_duplicates(left_name)
    return frame, {
        "rows": len(frame),
        "left_unique": int(frame[left_name].nunique()) if not frame.empty else 0,
        "right_unique": int(frame[right_name].nunique()) if not frame.empty else 0,
        "conflicting_left_ids": int(conflicts.sum()) if len(conflicts) else 0,
        "functional_ready": ready,
    }


def aggregate_product(
    source_ids: pd.Series,
    snr: pd.Series,
    contract: str,
    route: str,
) -> pd.DataFrame:
    work = pd.DataFrame({
        "source_id": source_ids,
        "snr_native": snr,
    }).dropna(subset=["source_id"])
    work["source_id"] = work["source_id"].astype("uint64")
    rows = []
    for source_id, group in work.groupby("source_id", sort=False):
        values = group["snr_native"].dropna().to_numpy(dtype=float)
        rows.append({
            "source_id": source_id,
            "survey": "GALAH_CORRECTED",
            "snr_native": float(np.median(values)) if len(values) else np.nan,
            "snr_measurement_count": int(len(values)),
            "snr_input_row_count": int(len(group)),
            "snr_contract": contract,
            "snr_id_route": route,
        })
    return pd.DataFrame(rows)


def product_fingerprint(
    product: pd.DataFrame,
    decimals: int,
) -> str:
    if product.empty:
        return hashlib.sha256(b"empty").hexdigest()
    work = product[["source_id", "snr_native"]].copy()
    work["source_id"] = work["source_id"].astype("uint64")
    work["snr_native"] = pd.to_numeric(
        work["snr_native"], errors="coerce"
    ).round(decimals)
    work = work.sort_values("source_id")
    payload = work.to_csv(index=False, na_rep="NA").encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def complete_mask(frame: pd.DataFrame) -> pd.Series:
    required = [
        "R", "abs_Z", "teff", "logg",
        "snr_native", "g_mag", "bp_rp"
    ]
    mask = pd.Series(True, index=frame.index)
    for field in required:
        if field not in frame.columns:
            return pd.Series(False, index=frame.index)
        mask &= frame[field].notna()
    sky = (
        (
            frame.get("l", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("b", pd.Series(pd.NA, index=frame.index)).notna()
        )
        |
        (
            frame.get("ra", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("dec", pd.Series(pd.NA, index=frame.index)).notna()
        )
    )
    return mask & sky


def percentile_transform(series: pd.Series) -> pd.Series:
    output = pd.Series(np.nan, index=series.index, dtype=float)
    valid = series.notna()
    if valid.any():
        output.loc[valid] = series.loc[valid].rank(
            method="average", pct=True
        )
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2d6_config.json").read_text(
            encoding="utf-8"
        )
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables",
        "assembled", "reports", "diagnostics"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg["prerequisite_d5_validation"]
    prereq = (
        json.loads(prereq_path.read_text(encoding="utf-8"))
        if prereq_path.exists() else {}
    )
    prereq_ready = bool(
        prereq.get("EXACT_UINT64_GAIA_ID_PARSING_READY", False)
        and prereq.get("FINAL_ROW_CONSERVATION_READY", False)
        and prereq.get(
            "APOGEE_NATIVE_SNR_RECOVERED_ON_CANONICAL_KEYS", False
        )
        and prereq.get("REBUILT_FROM_CANONICAL_D2_ANCHOR", False)
    )

    anchor_path = resolve_with_fallback(
        root / cfg["canonical_anchor_with_apogee_snr"]
    )
    anchor = (
        read_table(
            anchor_path,
            None,
            exact_string_columns=["source_id"],
        )
        if anchor_path else pd.DataFrame()
    )
    if "source_id" in anchor.columns:
        anchor["source_id"] = clean_uint64(anchor["source_id"])
        anchor = anchor[anchor["source_id"].notna()].copy()
        anchor["source_id"] = anchor["source_id"].astype("uint64")

    anchor_ready = bool(
        not anchor.empty
        and {"source_id", "survey", "snr_native"}.issubset(anchor.columns)
        and not anchor.duplicated(["source_id", "survey"]).any()
        and set(anchor["survey"].dropna().astype(str))
        >= {"APOGEE_NATIVE", "GALAH_CORRECTED"}
        and anchor.loc[
            anchor["survey"] == "APOGEE_NATIVE", "snr_native"
        ].notna().sum() >= int(cfg["minimum_complete_rows_per_survey"])
    )
    galah_anchor_ids = set(
        anchor.loc[
            anchor["survey"] == "GALAH_CORRECTED", "source_id"
        ].astype("uint64")
    ) if anchor_ready else set()

    suffixes = set(cfg["tabular_suffixes"])
    inventory = []
    snr_candidates = []
    bridge_candidates = []

    for rel_root in cfg["scan_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if (
                not path.is_file()
                or path.suffix.lower() not in suffixes
                or path_excluded(path, root, cfg)
            ):
                continue
            try:
                columns, row_count = read_columns(path)
            except Exception as exc:
                inventory.append({
                    "path": safe_rel(path, root),
                    "row_count": "",
                    "dr3_columns": "",
                    "dr2_columns": "",
                    "local_families": "",
                    "snr_contract": "",
                    "snr_columns": "",
                    "read_error": f"{type(exc).__name__}: {exc}",
                })
                continue
            dr3 = all_alias_matches(columns, cfg["dr3_id_aliases"])
            dr2 = all_alias_matches(columns, cfg["dr2_id_aliases"])
            local = local_family_matches(columns, cfg)
            contract, snr_columns, channel_map = detect_snr_contract(
                columns, cfg
            )
            inventory.append({
                "path": safe_rel(path, root),
                "row_count": row_count,
                "dr3_columns": "|".join(dr3),
                "dr2_columns": "|".join(dr2),
                "local_families": json.dumps(local, sort_keys=True),
                "snr_contract": contract or "",
                "snr_columns": "|".join(snr_columns),
                "read_error": "",
            })

            if contract and (
                path_is_galah(path, cfg)
                or bool(local)
                or bool(dr2)
            ):
                snr_candidates.append({
                    "path": path,
                    "row_count": row_count,
                    "dr3": dr3,
                    "dr2": dr2,
                    "local": local,
                    "contract": contract,
                    "snr_columns": snr_columns,
                })

            if (
                (local and (dr3 or dr2))
                or (dr2 and dr3)
            ):
                bridge_candidates.append({
                    "path": path,
                    "row_count": row_count,
                    "dr3": dr3,
                    "dr2": dr2,
                    "local": local,
                })

    write_csv(
        out / "tables/stage6d3a2d6_schema_inventory.csv",
        [
            "path", "row_count", "dr3_columns",
            "dr2_columns", "local_families",
            "snr_contract", "snr_columns", "read_error"
        ],
        inventory,
    )

    snr_candidates = sorted(
        snr_candidates,
        key=lambda item: (
            0 if path_is_galah(item["path"], cfg) else 1,
            -max(item["row_count"], 0),
            str(item["path"]),
        ),
    )[: int(cfg["maximum_snr_candidates"])]
    bridge_candidates = sorted(
        bridge_candidates,
        key=lambda item: (
            -max(item["row_count"], 0),
            str(item["path"]),
        ),
    )[: int(cfg["maximum_bridge_candidates"])]

    direct_local_dr3: dict[str, list[dict[str, Any]]] = defaultdict(list)
    local_dr2: dict[str, list[dict[str, Any]]] = defaultdict(list)
    dr2_dr3: list[dict[str, Any]] = []
    bridge_audit = []
    local_normalisation_audit = []

    for bridge in bridge_candidates:
        all_ids = (
            bridge["dr3"]
            + bridge["dr2"]
            + [
                column
                for columns in bridge["local"].values()
                for column in columns
            ]
        )
        try:
            frame = read_table(
                bridge["path"],
                sorted(set(all_ids)),
                exact_string_columns=sorted(set(all_ids)),
            )
        except Exception as exc:
            bridge_audit.append({
                "path": safe_rel(bridge["path"], root),
                "route_type": "load_error",
                "left_family": "",
                "left_column": "",
                "right_column": "",
                "rows": 0,
                "conflicting_left_ids": "",
                "functional_ready": "false",
                "load_error": f"{type(exc).__name__}: {exc}",
            })
            continue

        for family, local_columns in bridge["local"].items():
            for local_column in local_columns:
                local_id = normalise_local_id(
                    frame[local_column], family
                )
                raw_unique = int(
                    frame[local_column].astype("string").nunique(dropna=True)
                )
                normalized_unique = int(local_id.nunique(dropna=True))
                local_normalisation_audit.append({
                    "path": safe_rel(bridge["path"], root),
                    "family": family,
                    "column": local_column,
                    "raw_unique": raw_unique,
                    "normalized_unique": normalized_unique,
                    "normalization_collisions": max(
                        raw_unique - normalized_unique, 0
                    ),
                })

                for dr3_column in bridge["dr3"]:
                    mapping, diag = functional_map(
                        local_id,
                        clean_uint64(frame[dr3_column]),
                        "local_id",
                        "source_id",
                    )
                    bridge_audit.append({
                        "path": safe_rel(bridge["path"], root),
                        "route_type": "local_to_dr3",
                        "left_family": family,
                        "left_column": local_column,
                        "right_column": dr3_column,
                        "rows": diag["rows"],
                        "conflicting_left_ids": diag[
                            "conflicting_left_ids"
                        ],
                        "functional_ready": str(
                            diag["functional_ready"]
                        ).lower(),
                        "load_error": "",
                    })
                    if diag["functional_ready"] and not mapping.empty:
                        direct_local_dr3[family].append({
                            "path": bridge["path"],
                            "left_column": local_column,
                            "right_column": dr3_column,
                            "mapping": mapping,
                        })

                for dr2_column in bridge["dr2"]:
                    mapping, diag = functional_map(
                        local_id,
                        clean_uint64(frame[dr2_column]),
                        "local_id",
                        "dr2_id",
                    )
                    bridge_audit.append({
                        "path": safe_rel(bridge["path"], root),
                        "route_type": "local_to_dr2",
                        "left_family": family,
                        "left_column": local_column,
                        "right_column": dr2_column,
                        "rows": diag["rows"],
                        "conflicting_left_ids": diag[
                            "conflicting_left_ids"
                        ],
                        "functional_ready": str(
                            diag["functional_ready"]
                        ).lower(),
                        "load_error": "",
                    })
                    if diag["functional_ready"] and not mapping.empty:
                        local_dr2[family].append({
                            "path": bridge["path"],
                            "left_column": local_column,
                            "right_column": dr2_column,
                            "mapping": mapping,
                        })

        for dr2_column in bridge["dr2"]:
            for dr3_column in bridge["dr3"]:
                mapping, diag = functional_map(
                    clean_uint64(frame[dr2_column]),
                    clean_uint64(frame[dr3_column]),
                    "dr2_id",
                    "source_id",
                )
                bridge_audit.append({
                    "path": safe_rel(bridge["path"], root),
                    "route_type": "dr2_to_dr3",
                    "left_family": "gaia_dr2",
                    "left_column": dr2_column,
                    "right_column": dr3_column,
                    "rows": diag["rows"],
                    "conflicting_left_ids": diag[
                        "conflicting_left_ids"
                    ],
                    "functional_ready": str(
                        diag["functional_ready"]
                    ).lower(),
                    "load_error": "",
                })
                if diag["functional_ready"] and not mapping.empty:
                    dr2_dr3.append({
                        "path": bridge["path"],
                        "left_column": dr2_column,
                        "right_column": dr3_column,
                        "mapping": mapping,
                    })

    write_csv(
        out / "tables/stage6d3a2d6_bridge_functionality_audit.csv",
        [
            "path", "route_type", "left_family",
            "left_column", "right_column", "rows",
            "conflicting_left_ids", "functional_ready", "load_error"
        ],
        bridge_audit,
    )
    write_csv(
        out / "tables/stage6d3a2d6_local_id_normalisation_audit.csv",
        [
            "path", "family", "column",
            "raw_unique", "normalized_unique",
            "normalization_collisions"
        ],
        local_normalisation_audit,
    )

    route_rows = []
    route_products = []

    def add_route(
        candidate: dict[str, Any],
        route_name: str,
        id_column: str,
        bridge_paths: list[Path],
        source_ids: pd.Series,
        snr: pd.Series,
    ) -> None:
        product = aggregate_product(
            source_ids, snr, candidate["contract"], route_name
        )
        finite = product[
            product["snr_native"].notna()
        ]
        finite_ids = set(finite["source_id"].astype("uint64"))
        overlap = galah_anchor_ids.intersection(finite_ids)
        overlap_fraction = len(overlap) / max(len(galah_anchor_ids), 1)
        fingerprint = product_fingerprint(
            product,
            int(cfg["route_equivalence_round_decimals"]),
        )
        score = (
            1_000_000_000 * len(overlap)
            + 1_000_000 * len(finite_ids)
            + (
                3000 if route_name == "direct_dr3"
                else 2000 if route_name == "semantic_local_to_dr3"
                else 1000
            )
        )
        row = {
            "candidate_path": safe_rel(candidate["path"], root),
            "contract": candidate["contract"],
            "id_column": id_column,
            "route": route_name,
            "bridge_paths": "|".join(
                safe_rel(path, root) for path in bridge_paths
            ),
            "finite_source_rows": len(finite_ids),
            "anchor_overlap_rows": len(overlap),
            "anchor_overlap_fraction": overlap_fraction,
            "product_fingerprint": fingerprint,
            "selection_score": score,
            "load_error": "",
        }
        route_rows.append(row)
        route_products.append({
            "row": row,
            "product": product,
        })

    for candidate in snr_candidates:
        id_columns = (
            candidate["dr3"]
            + candidate["dr2"]
            + [
                column
                for columns in candidate["local"].values()
                for column in columns
            ]
        )
        required = sorted(set(id_columns + candidate["snr_columns"]))
        try:
            frame = read_table(
                candidate["path"],
                required,
                exact_string_columns=id_columns,
            )
        except Exception as exc:
            route_rows.append({
                "candidate_path": safe_rel(candidate["path"], root),
                "contract": candidate["contract"],
                "id_column": "",
                "route": "load_error",
                "bridge_paths": "",
                "finite_source_rows": 0,
                "anchor_overlap_rows": 0,
                "anchor_overlap_fraction": 0.0,
                "product_fingerprint": "",
                "selection_score": -1,
                "load_error": f"{type(exc).__name__}: {exc}",
            })
            continue

        snr = build_snr(
            frame, candidate["contract"],
            candidate["snr_columns"], cfg
        )

        for dr3_column in candidate["dr3"]:
            add_route(
                candidate,
                "direct_dr3",
                dr3_column,
                [],
                clean_uint64(frame[dr3_column]),
                snr,
            )

        for dr2_column in candidate["dr2"]:
            candidate_dr2 = pd.DataFrame({
                "dr2_id": clean_uint64(frame[dr2_column]),
                "snr_native": snr,
            }).dropna(subset=["dr2_id"])
            for bridge in dr2_dr3:
                joined = candidate_dr2.merge(
                    bridge["mapping"],
                    on="dr2_id",
                    how="inner",
                    validate="many_to_one",
                )
                add_route(
                    candidate,
                    "dr2_to_dr3",
                    dr2_column,
                    [bridge["path"]],
                    joined["source_id"],
                    joined["snr_native"],
                )

        for family, local_columns in candidate["local"].items():
            for local_column in local_columns:
                local = normalise_local_id(
                    frame[local_column], family
                )
                candidate_local = pd.DataFrame({
                    "local_id": local,
                    "snr_native": snr,
                }).dropna(subset=["local_id"])

                for bridge in direct_local_dr3.get(family, []):
                    joined = candidate_local.merge(
                        bridge["mapping"],
                        on="local_id",
                        how="inner",
                        validate="many_to_one",
                    )
                    add_route(
                        candidate,
                        "semantic_local_to_dr3",
                        f"{family}:{local_column}",
                        [bridge["path"]],
                        joined["source_id"],
                        joined["snr_native"],
                    )

                for first in local_dr2.get(family, []):
                    local_to_dr2 = candidate_local.merge(
                        first["mapping"],
                        on="local_id",
                        how="inner",
                        validate="many_to_one",
                    )
                    for second in dr2_dr3:
                        joined = local_to_dr2.merge(
                            second["mapping"],
                            on="dr2_id",
                            how="inner",
                            validate="many_to_one",
                        )
                        add_route(
                            candidate,
                            "semantic_local_to_dr2_to_dr3",
                            f"{family}:{local_column}",
                            [first["path"], second["path"]],
                            joined["source_id"],
                            joined["snr_native"],
                        )

    write_csv(
        out / "tables/stage6d3a2d6_galah_route_audit.csv",
        [
            "candidate_path", "contract", "id_column",
            "route", "bridge_paths", "finite_source_rows",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "product_fingerprint", "selection_score", "load_error"
        ],
        sorted(
            route_rows,
            key=lambda row: (
                -float(row["selection_score"]),
                row["candidate_path"],
                row["route"],
            ),
        ),
    )

    eligible = [
        item for item in route_products
        if (
            item["row"]["anchor_overlap_rows"]
            >= int(cfg["minimum_anchor_overlap_rows"])
            and item["row"]["anchor_overlap_fraction"]
            >= float(cfg["minimum_anchor_overlap_fraction"])
        )
    ]
    eligible.sort(
        key=lambda item: (
            -item["row"]["selection_score"],
            item["row"]["candidate_path"],
            item["row"]["route"],
        )
    )

    selected = None
    equivalent_tie_collapsed = False
    selection_error = ""
    if not eligible:
        selection_error = (
            "no direct, semantic local-ID, or local→DR2→DR3 route "
            "meets the finite GALAH-anchor overlap gate"
        )
    else:
        top_score = eligible[0]["row"]["selection_score"]
        tied = [
            item for item in eligible
            if item["row"]["selection_score"] == top_score
        ]
        fingerprints = {
            item["row"]["product_fingerprint"] for item in tied
        }
        if len(tied) > 1 and len(fingerprints) > 1:
            selection_error = (
                "top GALAH S/N routes are tied but produce non-equivalent "
                "source-level S/N products"
            )
        else:
            selected = tied[0]
            equivalent_tie_collapsed = len(tied) > 1

    selected_rows = []
    if selected:
        selected_rows.append({
            **selected["row"],
            "equivalent_tie_collapsed": str(
                equivalent_tie_collapsed
            ).lower(),
            "selection_reason": (
                "unique maximum finite anchor overlap, or an equivalent "
                "same-product tie collapsed deterministically"
            ),
        })
    write_csv(
        out / "tables/stage6d3a2d6_selected_galah_snr_contract.csv",
        [
            "candidate_path", "contract", "id_column",
            "route", "bridge_paths", "finite_source_rows",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "product_fingerprint", "selection_score",
            "equivalent_tie_collapsed", "selection_reason"
        ],
        selected_rows,
    )

    final = anchor.copy()
    final["_anchor_row_id"] = np.arange(len(final), dtype=np.int64)
    galah_columns = [
        "snr_native", "snr_measurement_count",
        "snr_input_row_count", "snr_contract", "snr_id_route"
    ]
    if selected:
        # Preserve APOGEE S/N and replace only GALAH S/N fields.
        galah_mask = final["survey"] == "GALAH_CORRECTED"
        for column in galah_columns:
            if column not in final.columns:
                final[column] = np.nan if column == "snr_native" else pd.NA
            final.loc[galah_mask, column] = (
                np.nan if column == "snr_native" else pd.NA
            )
        product = selected["product"].copy()
        product["source_id"] = clean_uint64(product["source_id"])
        product = product[product["source_id"].notna()].copy()
        product["source_id"] = product["source_id"].astype("uint64")
        if product.duplicated(["source_id", "survey"]).any():
            raise RuntimeError(
                "selected GALAH S/N product is not unique in "
                "(source_id, survey)"
            )
        # Merge GALAH product separately, then coalesce by immutable anchor rows.
        suffix_fields = [
            column for column in galah_columns
            if column in product.columns
        ]
        joined = final.merge(
            product[["source_id", "survey"] + suffix_fields],
            on=["source_id", "survey"],
            how="left",
            suffixes=("", "__galah"),
            validate="one_to_one",
        )
        for column in suffix_fields:
            candidate_column = column + "__galah"
            replace = joined["survey"] == "GALAH_CORRECTED"
            joined.loc[replace, column] = joined.loc[
                replace, candidate_column
            ].to_numpy()
            joined.drop(columns=[candidate_column], inplace=True)
        final = joined

    final = final.sort_values(
        "_anchor_row_id", kind="stable"
    ).reset_index(drop=True)

    row_conservation_ready = bool(
        len(final) == len(anchor)
        and final["_anchor_row_id"].is_unique
        and final["_anchor_row_id"].tolist() == list(range(len(anchor)))
        and not final.duplicated(["source_id", "survey"]).any()
        and final["source_id"].astype("uint64").tolist()
        == anchor["source_id"].astype("uint64").tolist()
        and final["survey"].astype(str).tolist()
        == anchor["survey"].astype(str).tolist()
    )

    if "snr_native" not in final.columns:
        final["snr_native"] = np.nan
    final["snr_log1p_native"] = np.log1p(
        pd.to_numeric(final["snr_native"], errors="coerce").clip(lower=0)
    )
    final["snr_within_survey_percentile"] = np.nan
    final["snr_support_half"] = pd.Series(
        pd.NA, index=final.index, dtype="string"
    )
    medians = {}
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        mask = final["survey"] == survey
        series = pd.to_numeric(
            final.loc[mask, "snr_native"], errors="coerce"
        )
        final.loc[
            mask, "snr_within_survey_percentile"
        ] = percentile_transform(series)
        median = float(series.median()) if series.notna().any() else np.nan
        medians[survey] = median
        if np.isfinite(median):
            final.loc[
                mask & final["snr_native"].notna()
                & (final["snr_native"] <= median),
                "snr_support_half"
            ] = "LOW_NATIVE_SNR_HALF"
            final.loc[
                mask & final["snr_native"].notna()
                & (final["snr_native"] > median),
                "snr_support_half"
            ] = "HIGH_NATIVE_SNR_HALF"

    support = complete_mask(final)
    complete_counts = {
        survey: int(
            ((final["survey"] == survey) & support).sum()
        )
        for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]
    }
    galah_ready = selected is not None
    complete_ready = all(
        complete_counts[survey]
        >= int(cfg["minimum_complete_rows_per_survey"])
        for survey in complete_counts
    )
    source_ready = bool(
        prereq_ready
        and anchor_ready
        and galah_ready
        and row_conservation_ready
        and complete_ready
    )

    coverage_rows = []
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        subset = final[final["survey"] == survey]
        coverage_rows.append({
            "survey": survey,
            "anchor_rows": len(subset),
            "finite_snr_rows": int(
                subset["snr_native"].notna().sum()
            ),
            "finite_snr_fraction": (
                float(subset["snr_native"].notna().mean())
                if len(subset) else 0.0
            ),
            "support_complete_rows": complete_counts[survey],
        })
    write_csv(
        out / "tables/stage6d3a2d6_final_join_coverage.csv",
        [
            "survey", "anchor_rows", "finite_snr_rows",
            "finite_snr_fraction", "support_complete_rows"
        ],
        coverage_rows,
    )

    final_path = (
        out
        / "assembled/stage6d3a2d6_production_source_with_snr.parquet"
    )
    try:
        final.drop(columns=["_anchor_row_id"]).to_parquet(
            final_path, index=False
        )
    except Exception:
        final_path = (
            out
            / "assembled/stage6d3a2d6_production_source_with_snr.csv"
        )
        final.drop(columns=["_anchor_row_id"]).to_csv(
            final_path, index=False
        )

    remaining = []
    if not prereq_ready:
        remaining.append({
            "gate": "STAGE6D3A2D5_PREREQUISITE_READY",
            "required_action": (
                "Restore PASS exact UInt64, canonical row-conservation, "
                "and APOGEE S/N prerequisites."
            ),
        })
    if not anchor_ready:
        remaining.append({
            "gate": "CANONICAL_D5_ANCHOR_READY",
            "required_action": (
                "D5 anchor must preserve unique source×survey rows and "
                "validated APOGEE native S/N."
            ),
        })
    if not galah_ready:
        remaining.append({
            "gate": "GALAH_SEMANTIC_OR_MULTIHOP_ID_ROUTE_READY",
            "required_action": selection_error,
        })
    if not row_conservation_ready:
        remaining.append({
            "gate": "FINAL_ROW_CONSERVATION_READY",
            "required_action": (
                "Final table must preserve the exact ordered D5 "
                "(source_id, survey) row universe."
            ),
        })
    if galah_ready and row_conservation_ready and not complete_ready:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_COMPLETE_ROWS_READY",
            "required_action": (
                f"Need at least {cfg['minimum_complete_rows_per_survey']} "
                "support-complete rows per survey. Observed: "
                + json.dumps(complete_counts, sort_keys=True)
            ),
        })
    write_csv(
        out / "tables/stage6d3a2d6_remaining_items.csv",
        ["gate", "required_action"],
        remaining,
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "canonical_anchor": (
            safe_rel(anchor_path, root) if anchor_path else ""
        ),
        "canonical_anchor_rows": len(anchor),
        "snr_candidate_count": len(snr_candidates),
        "bridge_candidate_count": len(bridge_candidates),
        "selected_galah_contract": (
            selected["row"]["contract"] if selected else ""
        ),
        "selected_galah_route": (
            selected["row"]["route"] if selected else ""
        ),
        "selected_galah_candidate_path": (
            selected["row"]["candidate_path"] if selected else ""
        ),
        "selected_galah_bridge_paths": (
            selected["row"]["bridge_paths"] if selected else ""
        ),
        "equivalent_route_tie_collapsed": equivalent_tie_collapsed,
        "survey_native_snr_medians": medians,
        "assembled_source_table": safe_rel(final_path, root),
        "assembled_rows": len(final),
        "support_complete_rows_by_survey": complete_counts,
        "prior_stage_outputs_modified": False,
        "STAGE6D3A2D5_PREREQUISITE_READY": prereq_ready,
        "CANONICAL_D5_ANCHOR_READY": anchor_ready,
        "SEMANTIC_LOCAL_ID_FAMILY_MATCHING_READY": True,
        "LOCAL_ID_NUMERIC_FORMAT_NORMALISATION_READY": True,
        "FUNCTIONAL_LOCAL_TO_DR3_MAPPING_REQUIRED": True,
        "FUNCTIONAL_LOCAL_TO_DR2_MAPPING_REQUIRED": True,
        "FUNCTIONAL_DR2_TO_DR3_MAPPING_REQUIRED": True,
        "MULTIPLE_LOCAL_IDS_PER_GAIA_SOURCE_ALLOWED": True,
        "GALAH_DIRECT_OR_SEMANTIC_MULTIHOP_ROUTE_READY": galah_ready,
        "FINAL_ROW_CONSERVATION_READY": row_conservation_ready,
        "NATIVE_SNR_PRESERVED": galah_ready,
        "WITHIN_SURVEY_SNR_PERCENTILE_READY": galah_ready,
        "SURVEY_SPECIFIC_SNR_SUPPORT_READY": galah_ready,
        "PRODUCTION_SOURCE_COMPLETE_ROWS_READY": complete_ready,
        "PRODUCTION_SOURCE_ASSEMBLY_READY": source_ready,
        "TARGET_ABUNDANCE_MATCHING_FORBIDDEN": True,
        "SURVEY_NEUTRAL_SNR_PROXY_FORBIDDEN": True,
        "STAGE6D3A2D6_LINEAGE_READY": bool(
            prereq_ready
            and anchor_ready
            and galah_ready
            and row_conservation_ready
        ),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": source_ready,
    }
    write_json(
        out / "validation/stage6d3a2d6_validation.json",
        validation,
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "galah_snr": {
            "contract": validation["selected_galah_contract"],
            "route": validation["selected_galah_route"],
            "candidate_path": validation[
                "selected_galah_candidate_path"
            ],
            "bridge_paths": validation[
                "selected_galah_bridge_paths"
            ],
            "ready": galah_ready,
        },
        "row_conservation": {
            "anchor_rows": len(anchor),
            "final_rows": len(final),
            "ready": row_conservation_ready,
        },
        "source_assembly": {
            "support_complete_rows_by_survey": complete_counts,
            "ready": source_ready,
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "A defensible GALAH S/N route is closed through direct DR3, "
            "semantic local-ID matching, or a functional local→DR2→DR3 "
            "chain. The canonical row universe is preserved and D3B is "
            "authorized."
            if source_ready else
            "All semantic local-ID and multihop bridge routes are audited. "
            "D3B remains blocked only by the listed GALAH identifier route "
            "or support-complete-row gap."
        ),
    }
    write_json(
        out / "summaries/stage6d3a2d6_summary.json",
        summary,
    )

    report = [
        "# Stage-6D3A2D6 semantic local-ID and multihop crosswalk",
        "",
        f"- Canonical anchor rows: `{len(anchor)}`",
        f"- S/N candidates: `{len(snr_candidates)}`",
        f"- Bridge candidates: `{len(bridge_candidates)}`",
        f"- Selected GALAH contract: `{validation['selected_galah_contract'] or 'not resolved'}`",
        f"- Selected route: `{validation['selected_galah_route'] or 'not resolved'}`",
        f"- Final row conservation: `{row_conservation_ready}`",
        f"- APOGEE support-complete rows: `{complete_counts['APOGEE_NATIVE']}`",
        f"- GALAH support-complete rows: `{complete_counts['GALAH_CORRECTED']}`",
        f"- Stage-6D3B ready: `{source_ready}`",
        "",
        "`sobject_id`, `sobject_id_1`, `sobject_id_2`, and other aliases "
        "are matched by semantic identifier family rather than literal "
        "column-name equality. Numeric local identifiers are normalized "
        "without routing Gaia source IDs through float64.",
        "",
        "Allowed routes are direct Gaia DR3, semantic local-ID to DR3, "
        "Gaia DR2 to DR3, and semantic local-ID to DR2 to DR3. Every "
        "left-side mapping must be functional; multiple observations or "
        "multiple local IDs may map to one Gaia source.",
        "",
        "No abundance, gradient, residual, or outcome participates in "
        "route selection.",
        "",
    ]
    (
        out
        / "reports/stage6d3a2d6_semantic_localid_multihop_crosswalk.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
