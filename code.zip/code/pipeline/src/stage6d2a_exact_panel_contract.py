from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

def read_columns(path: Path) -> tuple[list[str], int]:
    if path.suffix.lower() == ".parquet":
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(path)
        return list(pf.schema_arrow.names), int(pf.metadata.num_rows)
    frame = pd.read_csv(path, nrows=5)
    return list(frame.columns), -1

def read_table(path: Path, columns: list[str] | None = None) -> pd.DataFrame:
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path, columns=columns)
    return pd.read_csv(path, usecols=columns)

def find_alias(columns: list[str], options: list[str]) -> str | None:
    lower = {c.lower(): c for c in columns}
    for option in options:
        if option.lower() in lower:
            return lower[option.lower()]
    return None

def robust_iqr(values: pd.Series) -> float:
    clean = pd.to_numeric(values, errors="coerce").dropna()
    if clean.empty:
        return float("nan")
    return float(clean.quantile(0.75) - clean.quantile(0.25))

def mad(values: pd.Series) -> float:
    clean = pd.to_numeric(values, errors="coerce").dropna()
    if clean.empty:
        return float("nan")
    med = clean.median()
    return float((clean - med).abs().median())

def classify_file(path: Path, columns: list[str], cfg: dict[str, Any]) -> dict[str, Any]:
    aliases = cfg["aliases"]
    mapping = {
        logical: find_alias(columns, options)
        for logical, options in aliases.items()
    }
    lower_columns = {c.lower() for c in columns}
    wide_residual_hits, wide_observed_hits, wide_predicted_hits = [], [], []
    for label in cfg["primary_labels"]:
        for pattern in cfg["wide_label_value_patterns"]:
            name = pattern.format(label=label).lower()
            if name in lower_columns:
                if "residual" in name:
                    wide_residual_hits.append(name)
                elif "predicted" in name or "corrected" in name:
                    wide_predicted_hits.append(name)
                else:
                    wide_observed_hits.append(name)

    has_long_residual = mapping["label"] is not None and (
        mapping["residual"] is not None or (
            mapping["observed"] is not None and mapping["predicted"] is not None
        )
    )
    has_wide_residual = bool(wide_residual_hits) or (
        bool(wide_observed_hits) and bool(wide_predicted_hits)
    )
    has_coefficients = mapping["label"] is not None and all(
        mapping[key] is not None for key in ["a_t", "a_g", "a_fe"]
    )
    has_support = all(mapping[key] is not None for key in ["teff", "logg", "feh"])
    has_source = mapping["source_id"] is not None
    has_fold = mapping["fold"] is not None

    path_text = str(path).lower().replace("\\", "/")
    heldout_name_bonus = 40 if any(
        token in path_text for token in ["heldout", "held_out", "oof", "crossfit", "cross_fit"]
    ) else 0
    support_name_bonus = 40 if any(
        token in path_text for token in ["common_star", "common_support", "overlap", "support"]
    ) else 0
    coefficient_name_bonus = 30 if any(
        token in path_text for token in ["coefficient", "calibration_model", "transport_model"]
    ) else 0
    support_as_heldout_penalty = 35 if (
        support_name_bonus and not heldout_name_bonus
    ) else 0

    role_scores = {
        "heldout_long": (
            int(has_long_residual) * 100 + int(has_fold) * 20
            + int(has_source) * 10 + int(has_support) * 10
            + heldout_name_bonus - support_as_heldout_penalty
        ),
        "heldout_wide": (
            int(has_wide_residual) * 90 + int(has_fold) * 20
            + int(has_source) * 10 + int(has_support) * 10
            + heldout_name_bonus - support_as_heldout_penalty
        ),
        "coefficients": int(has_coefficients) * 100 + coefficient_name_bonus,
        "support": (
            int(has_source and has_support) * 80
            + int(mapping["survey"] is not None) * 10
            + support_name_bonus
        )
    }
    best_role = max(role_scores, key=role_scores.get)
    best_score = role_scores[best_role]
    if best_score == 0:
        best_role = "unclassified"
    return {
        "mapping": mapping,
        "wide_residual_hits": sorted(set(wide_residual_hits)),
        "wide_observed_hits": sorted(set(wide_observed_hits)),
        "wide_predicted_hits": sorted(set(wide_predicted_hits)),
        "role_scores": role_scores,
        "best_role": best_role,
        "best_score": best_score
    }

def deterministic_fold(source: pd.Series, n_folds: int) -> pd.Series:
    ids = pd.to_numeric(source, errors="coerce")
    if ids.isna().any():
        raise ValueError("Deterministic fold fallback requires finite numeric source IDs.")
    return (ids.astype("uint64") % np.uint64(n_folds)).astype("int16")

def support_cell(frame: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    teff_bin = pd.cut(
        pd.to_numeric(frame["teff"], errors="coerce"),
        bins=cfg["support_cells"]["teff_edges"],
        labels=["cool", "warm"], include_lowest=True
    )
    logg_bin = pd.cut(
        pd.to_numeric(frame["logg"], errors="coerce"),
        bins=cfg["support_cells"]["logg_edges"],
        labels=["lowg", "highg"], include_lowest=True
    )
    feh_bin = pd.cut(
        pd.to_numeric(frame["feh"], errors="coerce"),
        bins=cfg["support_cells"]["feh_edges"],
        labels=["metalpoor", "intermediate", "metalrich"], include_lowest=True
    )
    if "snr" in frame.columns:
        snr = pd.to_numeric(frame["snr"], errors="coerce")
        median = float(snr.median()) if snr.notna().any() else float("nan")
        snr_bin = pd.Series(np.where(snr >= median, "highsnr", "lowsnr"), index=frame.index)
    else:
        snr_bin = pd.Series("snr_na", index=frame.index)
    return (
        teff_bin.astype("string").fillna("teff_na")
        + "__" + logg_bin.astype("string").fillna("logg_na")
        + "__" + feh_bin.astype("string").fillna("feh_na")
        + "__" + snr_bin.astype("string")
    )

def build_long_panel(path: Path, profile: dict[str, Any], cfg: dict[str, Any]) -> pd.DataFrame:
    mapping = profile["mapping"]
    needed = sorted(set(v for v in mapping.values() if v))
    frame = read_table(path, needed).copy()
    frame = frame.rename(columns={v: k for k, v in mapping.items() if v})
    frame["label"] = frame["label"].astype(str).str.lower()
    frame = frame[frame["label"].isin(cfg["primary_labels"])].copy()

    if "residual" not in frame.columns:
        frame["residual"] = (
            pd.to_numeric(frame["observed"], errors="coerce")
            - pd.to_numeric(frame["predicted"], errors="coerce")
        )
    else:
        frame["residual"] = pd.to_numeric(frame["residual"], errors="coerce")

    if "observed" not in frame.columns:
        frame["observed"] = np.nan

    if "fold" not in frame.columns:
        if not cfg["allow_deterministic_fold_fallback"] or "source_id" not in frame.columns:
            raise RuntimeError("No fold column and no permitted source-ID fallback.")
        frame["fold"] = deterministic_fold(frame["source_id"], cfg["minimum_folds"])
        frame["fold_origin"] = cfg["fold_fallback_rule"]
    else:
        frame["fold"] = pd.to_numeric(frame["fold"], errors="coerce")
        frame["fold_origin"] = "frozen_existing_fold"

    for name in ["teff", "logg", "feh"]:
        if name not in frame.columns:
            frame[name] = np.nan
    frame["support_cell"] = support_cell(frame, cfg)
    return frame

def aggregate_panel(frame: pd.DataFrame, cfg: dict[str, Any]) -> pd.DataFrame:
    rows = []
    for (label, fold, cell), group in frame.groupby(["label", "fold", "support_cell"], dropna=False):
        n = len(group)
        residual_mad = mad(group["residual"])
        observed_iqr = robust_iqr(group["observed"])
        q = residual_mad / observed_iqr if math.isfinite(observed_iqr) and observed_iqr >= cfg["minimum_iqr"] else float("nan")
        rows.append({
            "label": label,
            "fold": int(fold) if pd.notna(fold) else -1,
            "support_cell": str(cell),
            "n_rows": n,
            "heldout_residual_mad": residual_mad,
            "heldout_residual_median": float(pd.to_numeric(group["residual"], errors="coerce").median()),
            "common_sample_iqr": observed_iqr,
            "Q_heldout": q,
            "valid_min_rows": n >= cfg["minimum_heldout_rows_per_label_fold_cell"],
            "valid_iqr": math.isfinite(observed_iqr) and observed_iqr >= cfg["minimum_iqr"],
            "fold_origin": "|".join(sorted(set(group["fold_origin"].astype(str))))
        })
    return pd.DataFrame(rows)

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    cfg = json.loads((root / "config/stage6d2a_config.json").read_text(encoding="utf-8"))

    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in ["validation", "summaries", "tables", "panel", "reports"]:
        (out / d).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg["prerequisite_validation"]
    prereq = json.loads(prereq_path.read_text(encoding="utf-8")) if prereq_path.exists() else {}
    prereq_ready = bool(
        prereq.get("STAGE6D1_PROTOCOL_FROZEN", False)
        and prereq.get("STAGE6D2_DATA_READY", False)
    )

    candidates = []
    suffixes = set(cfg["suffixes"])
    for rel_root in cfg["search_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in suffixes:
                continue
            try:
                columns, row_count = read_columns(path)
                profile = classify_file(path, columns, cfg)
                candidates.append({
                    "path": safe_rel(path, root),
                    "suffix": path.suffix.lower(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                    "row_count": row_count,
                    "column_count": len(columns),
                    "columns": "|".join(columns),
                    "best_role": profile["best_role"],
                    "best_score": profile["best_score"],
                    "role_scores": json.dumps(profile["role_scores"], sort_keys=True),
                    "mapping": json.dumps(profile["mapping"], sort_keys=True),
                    "wide_residual_hits": "|".join(profile["wide_residual_hits"]),
                    "wide_observed_hits": "|".join(profile["wide_observed_hits"]),
                    "wide_predicted_hits": "|".join(profile["wide_predicted_hits"]),
                    "read_error": ""
                })
            except Exception as exc:
                candidates.append({
                    "path": safe_rel(path, root), "suffix": path.suffix.lower(),
                    "size_bytes": path.stat().st_size, "sha256": sha256_file(path),
                    "row_count": "", "column_count": "", "columns": "",
                    "best_role": "read_error", "best_score": 0, "role_scores": "",
                    "mapping": "", "wide_residual_hits": "",
                    "wide_observed_hits": "", "wide_predicted_hits": "",
                    "read_error": f"{type(exc).__name__}: {exc}"
                })

    candidates.sort(key=lambda r: (-int(r["best_score"]), r["path"]))
    write_csv(
        out / "tables/stage6d2a_exact_file_inventory.csv",
        ["path","suffix","size_bytes","sha256","row_count","column_count","columns",
         "best_role","best_score","role_scores","mapping","wide_residual_hits",
         "wide_observed_hits","wide_predicted_hits","read_error"],
        candidates
    )

    role_selection = {}
    for role in ["heldout_long", "heldout_wide", "coefficients", "support"]:
        hits = [r for r in candidates if r["best_role"] == role and int(r["best_score"]) > 0]
        role_selection[role] = hits[0] if hits else None

    heldout = role_selection["heldout_long"]
    aggregate = pd.DataFrame()
    panel_error = ""
    panel_format = ""
    panel_file = ""
    if heldout:
        try:
            path = root / heldout["path"]
            columns, _ = read_columns(path)
            profile = classify_file(path, columns, cfg)
            source_panel = build_long_panel(path, profile, cfg)
            aggregate = aggregate_panel(source_panel, cfg)
            parquet_path = out / "panel" / cfg["output_panel_parquet"]
            try:
                aggregate.to_parquet(parquet_path, index=False)
                panel_format = "parquet"
                panel_file = safe_rel(parquet_path, root)
            except Exception:
                csv_path = out / "panel" / cfg["output_panel_csv"]
                aggregate.to_csv(csv_path, index=False)
                panel_format = "csv_fallback"
                panel_file = safe_rel(csv_path, root)
        except Exception as exc:
            panel_error = f"{type(exc).__name__}: {exc}"

    label_rows = []
    for label in cfg["primary_labels"]:
        subset = aggregate[aggregate["label"] == label] if not aggregate.empty else pd.DataFrame()
        if not subset.empty:
            valid = subset[
                subset["valid_min_rows"].astype(bool)
                & subset["valid_iqr"].astype(bool)
                & pd.to_numeric(subset["Q_heldout"], errors="coerce").notna()
            ]
        else:
            valid = pd.DataFrame()
        folds = int(valid["fold"].nunique()) if not valid.empty else 0
        label_rows.append({
            "label": label, "panel_rows": len(subset),
            "valid_panel_rows": len(valid), "valid_folds": folds,
            "ready": str(folds >= cfg["minimum_folds"]).lower()
        })
    write_csv(
        out / "tables/stage6d2a_label_coverage.csv",
        ["label","panel_rows","valid_panel_rows","valid_folds","ready"],
        label_rows
    )

    selection_rows = []
    for role, row in role_selection.items():
        selection_rows.append({
            "role": role, "selected": str(row is not None).lower(),
            "path": row["path"] if row else "",
            "score": row["best_score"] if row else "",
            "reason": "highest exact schema score" if row else "no file satisfied exact role schema"
        })
    write_csv(
        out / "tables/stage6d2a_selected_inputs.csv",
        ["role","selected","path","score","reason"], selection_rows
    )

    valid_labels = sum(row["ready"] == "true" for row in label_rows)
    exact_heldout_ready = heldout is not None and not panel_error
    panel_ready = not aggregate.empty and valid_labels >= cfg["minimum_valid_primary_labels"]
    coefficient_ready = role_selection["coefficients"] is not None
    support_ready = role_selection["support"] is not None

    remaining = []
    if not exact_heldout_ready:
        remaining.append({
            "gate":"EXACT_HELDOUT_PRODUCT_READY",
            "required_action":"Locate or regenerate a long-form held-out residual/prediction product with label and fold/source-ID columns."
        })
    if panel_error:
        remaining.append({"gate":"PANEL_CONSTRUCTION_READY","required_action":panel_error})
    if not coefficient_ready:
        remaining.append({
            "gate":"EXACT_COEFFICIENT_PRODUCT_READY",
            "required_action":"Locate a coefficient table containing label, a_T, a_g, and a_Fe."
        })
    if not support_ready:
        remaining.append({
            "gate":"EXACT_SUPPORT_PRODUCT_READY",
            "required_action":"Locate a source-level overlap-support table with source ID, Teff, logg, and Fe/H."
        })
    if exact_heldout_ready and not panel_ready:
        remaining.append({
            "gate":"PRIMARY_LABEL_COVERAGE_READY",
            "required_action":f"At least {cfg['minimum_valid_primary_labels']} primary labels need {cfg['minimum_folds']} valid folds after support-cell gates."
        })
    write_csv(
        out / "tables/stage6d2a_remaining_items.csv",
        ["gate","required_action"], remaining
    )

    model_ready = bool(
        prereq_ready and exact_heldout_ready and coefficient_ready
        and support_ready and panel_ready
    )
    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "candidate_file_count": len(candidates),
        "selected_heldout_product": heldout["path"] if heldout else "",
        "selected_coefficient_product": role_selection["coefficients"]["path"] if role_selection["coefficients"] else "",
        "selected_support_product": role_selection["support"]["path"] if role_selection["support"] else "",
        "panel_file": panel_file,
        "panel_format": panel_format,
        "panel_rows": len(aggregate),
        "valid_primary_labels": valid_labels,
        "panel_error": panel_error,
        "prior_stage_outputs_modified": False,
        "STAGE6D1A_PREREQUISITE_READY": prereq_ready,
        "EXACT_HELDOUT_PRODUCT_READY": exact_heldout_ready,
        "EXACT_COEFFICIENT_PRODUCT_READY": coefficient_ready,
        "EXACT_SUPPORT_PRODUCT_READY": support_ready,
        "LEAKAGE_FREE_FOLD_CONTRACT_READY": exact_heldout_ready,
        "SUPPORT_CELL_CONTRACT_READY": exact_heldout_ready,
        "Q_HELDOUT_PANEL_READY": panel_ready,
        "STAGE6D2A_CONTRACT_READY": model_ready,
        "STAGE6D2B_MODEL_READY": model_ready
    }
    write_json(out / "validation/stage6d2a_validation.json", validation)

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "selected_inputs": role_selection,
        "label_coverage": label_rows,
        "remaining_items": remaining,
        "scientific_disposition": (
            "Exact leakage-free Q_heldout panel contract is closed. Stage-6D2B predictive fitting is authorized."
            if model_ready else
            "Exact input contract remains incomplete. Do not fit the predictive model."
        )
    }
    write_json(out / "summaries/stage6d2a_summary.json", summary)
    (out / "reports/stage6d2a_exact_panel_contract.md").write_text(
        "\n".join([
            "# Stage-6D2A exact predictive-transportability panel contract",
            "",
            f"- Prerequisite ready: `{prereq_ready}`",
            f"- Exact held-out product: `{heldout['path'] if heldout else 'not found'}`",
            f"- Panel rows: `{len(aggregate)}`",
            f"- Valid primary labels: `{valid_labels}`",
            f"- Model ready: `{model_ready}`",
            "",
            "No predictive coefficient or success/null claim is produced at this stage.",
            ""
        ]),
        encoding="utf-8"
    )
    print(json.dumps({"validation":validation,"summary":summary}, indent=2, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
