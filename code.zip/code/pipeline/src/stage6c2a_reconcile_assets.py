from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

STAGE = "Stage-6C2A strict science-asset reconciliation and figure regeneration"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.15.0"

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).lower()).strip("_")

def safe_rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def read_json(path: Path) -> dict[str, Any]:
    obj = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return obj

def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)

def excluded(path: Path, root: Path, prefixes: list[str]) -> bool:
    rel = safe_rel(path, root).lower()
    return any(rel == p.lower() or rel.startswith(p.lower().rstrip("/") + "/") for p in prefixes)

def json_records(obj: Any) -> list[dict[str, Any]]:
    candidates: list[list[dict[str, Any]]] = []
    def walk(x: Any) -> None:
        if isinstance(x, list) and x and all(isinstance(v, dict) for v in x):
            candidates.append(x)
        elif isinstance(x, dict):
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x[:30]:
                walk(v)
    walk(obj)
    if candidates:
        candidates.sort(key=len, reverse=True)
        return candidates[0]
    if isinstance(obj, dict):
        scalar = {k: v for k, v in obj.items() if not isinstance(v, (dict, list))}
        if scalar:
            return [scalar]
    return []

def profile_file(path: Path) -> dict[str, Any]:
    suffix = path.suffix.lower()
    result = {
        "path": str(path),
        "suffix": suffix,
        "columns": [],
        "n_rows": None,
        "load_error": ""
    }
    try:
        if suffix in {".csv", ".tsv"}:
            sep = "\t" if suffix == ".tsv" else ","
            frame = pd.read_csv(path, sep=sep, nrows=25)
            result["columns"] = [str(c) for c in frame.columns]
            # Count without loading the full file.
            with path.open("rb") as f:
                result["n_rows"] = max(sum(1 for _ in f) - 1, 0)
        elif suffix == ".parquet":
            try:
                import pyarrow.parquet as pq
                pf = pq.ParquetFile(path)
                result["columns"] = pf.schema.names
                result["n_rows"] = pf.metadata.num_rows
            except Exception:
                frame = pd.read_parquet(path)
                result["columns"] = [str(c) for c in frame.columns]
                result["n_rows"] = len(frame)
        elif suffix == ".json":
            obj = json.loads(path.read_text(encoding="utf-8"))
            records = json_records(obj)
            frame = pd.json_normalize(records) if records else pd.DataFrame()
            result["columns"] = [str(c) for c in frame.columns]
            result["n_rows"] = len(frame)
    except Exception as exc:
        result["load_error"] = f"{type(exc).__name__}: {exc}"
    return result

def matches_group(columns: list[str], aliases: list[str]) -> tuple[bool, str]:
    cn = [norm(c) for c in columns]
    for alias in aliases:
        a = norm(alias)
        for col in cn:
            if col == a or col.endswith("_" + a) or a in col:
                return True, a
    return False, ""

def candidate_score(
    profile: dict[str, Any],
    asset: dict[str, Any],
    rel: str,
    non_authoritative_tokens: list[str],
    secondary_tokens: list[str]
) -> tuple[bool, int, list[str], list[str]]:
    columns = profile["columns"]
    missing: list[str] = []
    reasons: list[str] = []
    score = 0

    for group in asset["required_groups"]:
        ok, matched = matches_group(columns, group)
        if not ok:
            missing.append("/".join(group))
        else:
            score += 20
            reasons.append("column:" + matched)

    if missing:
        return False, score, reasons, missing

    low = rel.lower()
    if any(token in low for token in non_authoritative_tokens):
        return False, score, reasons + ["rejected:non_authoritative_filename"], []
    if any(token in low for token in secondary_tokens):
        score -= 8
        reasons.append("penalty:secondary_product")

    for token in asset.get("preferred_tokens", []):
        if norm(token) in norm(low):
            score += 4
            reasons.append("name:" + token)

    n_rows = profile.get("n_rows")
    if isinstance(n_rows, int):
        if n_rows >= 2:
            score += 4
        if n_rows >= 5:
            score += 3
    return True, score, reasons, []

def load_frame(path: Path, max_rows: int | None = None) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix in {".csv", ".tsv"}:
        sep = "\t" if suffix == ".tsv" else ","
        return pd.read_csv(path, sep=sep, nrows=max_rows)
    if suffix == ".parquet":
        frame = pd.read_parquet(path)
        return frame.head(max_rows) if max_rows else frame
    if suffix == ".json":
        obj = json.loads(path.read_text(encoding="utf-8"))
        records = json_records(obj)
        frame = pd.json_normalize(records)
        return frame.head(max_rows) if max_rows else frame
    raise ValueError(path)

def find_col(frame: pd.DataFrame, aliases: list[str]) -> str | None:
    for alias in aliases:
        a = norm(alias)
        for c in frame.columns:
            cn = norm(c)
            if cn == a or cn.endswith("_" + a) or a in cn:
                return str(c)
    return None

ALIASES = {
    "stage": ["stage", "criterion", "gate"],
    "apogee": ["apogee", "apogee_count", "n_apogee"],
    "galah": ["galah", "galah_count", "n_galah"],
    "label": ["label", "quantity", "abundance", "element"],
    "n_common": ["n_common", "common_count", "n_overlap", "overlap_count"],
    "a_fe": ["a_fe", "afe", "coef_fe", "metallicity_coefficient"],
    "residual_median": ["residual_median", "median_residual", "post_median"],
    "residual_mad": ["residual_mad", "mad_residual", "post_mad"],
    "sample": ["sample", "subset", "survey", "view"],
    "population": ["population", "class", "component"],
    "n": ["n", "count", "n_stars", "sample_size"],
    "secure_fraction": ["secure_fraction", "secure_frac", "pmax_fraction", "fraction_secure"],
    "beta_r": ["beta_r", "b_r", "radial_slope", "gradient_r"],
    "beta_z": ["beta_z", "b_z", "vertical_slope", "gradient_z"],
    "beta_r_lo": ["beta_r_lo", "b_r_lo", "radial_ci_low", "beta_r_p16"],
    "beta_r_hi": ["beta_r_hi", "b_r_hi", "radial_ci_high", "beta_r_p84"],
    "beta_z_lo": ["beta_z_lo", "b_z_lo", "vertical_ci_low", "beta_z_p16"],
    "beta_z_hi": ["beta_z_hi", "b_z_hi", "vertical_ci_high", "beta_z_p84"],
}

def canonicalise(frame: pd.DataFrame, asset_id: str) -> pd.DataFrame:
    wanted = {
        "T01": ["stage", "apogee", "galah"],
        "T02": ["label", "n_common", "a_fe", "residual_median", "residual_mad"],
        "T03": ["sample", "label", "n", "beta_r", "beta_r_lo", "beta_r_hi", "beta_z", "beta_z_lo", "beta_z_hi"],
        "T04": ["population", "n", "secure_fraction"],
        "T05": ["population", "label", "n", "beta_r", "beta_r_lo", "beta_r_hi", "beta_z", "beta_z_lo", "beta_z_hi"],
        "T06": ["sample", "label", "n", "beta_r", "beta_r_lo", "beta_r_hi", "beta_z", "beta_z_lo", "beta_z_hi"],
    }[asset_id]
    data: dict[str, Any] = {}
    for key in wanted:
        col = find_col(frame, ALIASES[key])
        data[key] = frame[col] if col else [None] * len(frame)
    out = pd.DataFrame(data)
    out = out.dropna(how="all")
    return out

def fmt_value(value: Any, decimals: int = 4) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "--"
    if isinstance(value, (int,)):
        return f"{value:,}"
    try:
        x = float(value)
        if x.is_integer() and abs(x) >= 100:
            return f"{int(x):,}"
        return f"{x:+.{decimals}f}" if abs(x) < 10 else f"{x:.{decimals}f}"
    except Exception:
        return str(value).replace("_", r"\_")

def tex_escape(text: Any) -> str:
    value = str(text)
    for a, b in [
        ("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"),
        ("$", r"\$"), ("#", r"\#"), ("_", r"\_"),
        ("{", r"\{"), ("}", r"\}"),
    ]:
        value = value.replace(a, b)
    return value

def dataframe_to_latex(asset_id: str, title: str, frame: pd.DataFrame, source_rel: str) -> str:
    display = frame.copy()
    # Keep manuscript tables compact and deterministic.
    if len(display) > 60:
        display = display.head(60)
    cols = list(display.columns)
    headings = {
        "stage": "Stage", "apogee": "APOGEE", "galah": "GALAH",
        "label": "Label", "n_common": r"$N_{\rm common}$", "a_fe": r"$a_{\rm Fe}$",
        "residual_median": "Residual median", "residual_mad": "Residual MAD",
        "sample": "Sample", "population": "Population", "n": r"$N$",
        "secure_fraction": "Secure frac.", "beta_r": r"$\beta_R$",
        "beta_z": r"$\beta_Z$", "beta_r_lo": r"$\beta_{R,\rm lo}$",
        "beta_r_hi": r"$\beta_{R,\rm hi}$", "beta_z_lo": r"$\beta_{Z,\rm lo}$",
        "beta_z_hi": r"$\beta_{Z,\rm hi}$",
    }
    colspec = "l" + "r" * max(len(cols)-1, 0)
    env = "table*" if len(cols) >= 5 else "table"
    lines = [
        "% Auto-generated by Stage-6C2A from: " + source_rel,
        rf"\begin{{{env}}}",
        r"\centering",
        r"\small",
        rf"\caption{{{tex_escape(title)} Machine-readable source: \texttt{{{tex_escape(source_rel)}}}.}}",
        rf"\label{{tab:{asset_id.lower()}}}",
        rf"\resizebox{{\textwidth}}{{!}}{{%" if env == "table*" else rf"\resizebox{{\columnwidth}}{{!}}{{%",
        rf"\begin{{tabular}}{{{colspec}}}",
        r"\hline",
        " & ".join(headings.get(c, tex_escape(c)) for c in cols) + r"\\",
        r"\hline",
    ]
    for _, row in display.iterrows():
        cells = []
        for c in cols:
            v = row[c]
            if c in {"stage", "label", "sample", "population"}:
                cells.append(tex_escape(v) if pd.notna(v) else "--")
            elif c in {"n", "n_common", "apogee", "galah"}:
                try:
                    cells.append(f"{int(float(v)):,}" if pd.notna(v) else "--")
                except Exception:
                    cells.append(tex_escape(v))
            else:
                cells.append(fmt_value(v))
        lines.append(" & ".join(cells) + r"\\")
    lines += [r"\hline", r"\end{tabular}", r"}", rf"\end{{{env}}}", ""]
    return "\n".join(lines)

def import_pyplot():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    return plt

def save_bar_labels(frame: pd.DataFrame, x: str, y: str, path: Path, ylabel: str, rotate: int = 45) -> bool:
    work = frame[[x, y]].dropna()
    if work.empty:
        return False
    plt = import_pyplot()
    fig, ax = plt.subplots(figsize=(8.0, 4.8))
    ax.bar(work[x].astype(str), pd.to_numeric(work[y], errors="coerce"))
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=rotate)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def plot_gradient(frame: pd.DataFrame, path: Path, group_col: str | None = None) -> bool:
    required = ["label", "beta_r", "beta_z"]
    if any(c not in frame.columns for c in required):
        return False
    work = frame.dropna(subset=["label", "beta_r", "beta_z"]).copy()
    if work.empty:
        return False
    if len(work) > 30:
        work = work.head(30)
    labels = work["label"].astype(str)
    x = list(range(len(work)))
    br = pd.to_numeric(work["beta_r"], errors="coerce")
    bz = pd.to_numeric(work["beta_z"], errors="coerce")
    plt = import_pyplot()
    fig, ax = plt.subplots(figsize=(9.0, 5.0))
    ax.axhline(0.0, linewidth=0.8)
    ax.plot(x, br, marker="o", linestyle="-", label=r"$\beta_R$")
    ax.plot(x, bz, marker="s", linestyle="--", label=r"$\beta_Z$")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=55, ha="right")
    ax.set_ylabel(r"Gradient [dex kpc$^{-1}$]")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def plot_survey(frame: pd.DataFrame, path: Path) -> bool:
    work = frame.dropna(subset=["sample", "label", "beta_r", "beta_z"]).copy()
    if work.empty:
        return False
    # Prefer [Fe/H] or the most frequent label.
    label_values = work["label"].astype(str)
    fe_mask = label_values.str.lower().str.contains("fe")
    if fe_mask.any():
        work = work[fe_mask]
    else:
        mode = label_values.mode()
        if not mode.empty:
            work = work[label_values == mode.iloc[0]]
    x = list(range(len(work)))
    plt = import_pyplot()
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ax.axhline(0.0, linewidth=0.8)
    ax.plot(x, pd.to_numeric(work["beta_r"], errors="coerce"), marker="o", label=r"$\beta_R$")
    ax.plot(x, pd.to_numeric(work["beta_z"], errors="coerce"), marker="s", label=r"$\beta_Z$")
    ax.set_xticks(x)
    ax.set_xticklabels(work["sample"].astype(str), rotation=50, ha="right")
    ax.set_ylabel(r"Gradient [dex kpc$^{-1}$]")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def find_star_level(profiles: list[dict[str, Any]], aliases: dict[str, list[str]]) -> dict[str, Any] | None:
    best = None
    for p in profiles:
        columns = p["columns"]
        matched = {}
        for key, group in aliases.items():
            ok, alias = matches_group(columns, group)
            if ok:
                matched[key] = alias
        if len(matched) == len(aliases):
            score = 100 + min(int(p.get("n_rows") or 0), 1000000) / 100000
            if best is None or score > best["score"]:
                best = {"profile": p, "score": score}
    return best

def plot_population_map(frame: pd.DataFrame, aliases: dict[str, list[str]], path: Path, max_rows: int) -> bool:
    cols = {}
    for key, group in aliases.items():
        col = find_col(frame, group)
        if col is None:
            return False
        cols[key] = col
    work = frame[list(cols.values())].copy()
    work.columns = list(cols.keys())
    work = work.dropna(subset=["feh", "alpha", "population"])
    if len(work) > max_rows:
        work = work.sample(max_rows, random_state=1729)
    if work.empty:
        return False
    codes, uniques = pd.factorize(work["population"].astype(str))
    plt = import_pyplot()
    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    scatter = ax.scatter(
        pd.to_numeric(work["feh"], errors="coerce"),
        pd.to_numeric(work["alpha"], errors="coerce"),
        c=codes,
        s=4,
        alpha=0.45
    )
    ax.set_xlabel("[Fe/H]")
    ax.set_ylabel(r"[$\alpha$/Fe]")
    # Keep the plot robust for categorical populations; the full class mapping
    # remains available in the accompanying machine-readable table.
    if len(uniques) <= 8:
        for idx, name in enumerate(uniques):
            subset = work[codes == idx]
            if not subset.empty:
                ax.scatter(
                    pd.to_numeric(subset["feh"], errors="coerce"),
                    pd.to_numeric(subset["alpha"], errors="coerce"),
                    s=4, alpha=0.45, label=str(name)
                )
        ax.legend(fontsize=7, loc="best")
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def patch_bibliography(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    replacements = {
        "Jonsson2020": r"""@article{Jonsson2020,
  author={Jönsson, H. and others},
  title={APOGEE Data Releases 13 and 14: Stellar Parameter and Abundance Comparisons with Independent Analyses},
  journal={The Astronomical Journal},
  volume={156}, pages={126}, year={2018},
  doi={10.3847/1538-3881/aad4f5}
}""",
        "Martell2017": r"""@article{Martell2017,
  author={Martell, S. L. and others},
  title={The GALAH survey: observational overview and Gaia DR1 companion},
  journal={Monthly Notices of the Royal Astronomical Society},
  volume={465}, pages={3235--3253}, year={2017},
  doi={10.1093/mnras/stw2851}
}""",
        "Kos2017": r"""@article{Kos2017,
  author={Kos, J. and others},
  title={The GALAH survey: the data reduction pipeline},
  journal={Monthly Notices of the Royal Astronomical Society},
  volume={464}, pages={1259--1281}, year={2017},
  doi={10.1093/mnras/stw2064}
}""",
        "Martig2016": r"""@article{Martig2016,
  author={Martig, M. and others},
  title={Red giant masses and ages derived from carbon and nitrogen abundances},
  journal={Monthly Notices of the Royal Astronomical Society},
  volume={456}, pages={3655--3670}, year={2016},
  doi={10.1093/mnras/stv2830}
}""",
        "Masseron2017": r"""@article{Masseron2017,
  author={Masseron, T. and Lagarde, N. and Miglio, A. and Elsworth, Y. and Gilmore, G.},
  title={Nitrogen depletion in field red giants: mixing during the He flash?},
  journal={Monthly Notices of the Royal Astronomical Society},
  volume={464}, number={3}, pages={3021--3028}, year={2017},
  doi={10.1093/mnras/stw2632}
}""",
    }
    for key, entry in replacements.items():
        pattern = re.compile(r"@article\{" + re.escape(key) + r",.*?\n\}", re.S)
        if pattern.search(text):
            text = pattern.sub(lambda _: entry, text)
        else:
            text += "\n\n" + entry + "\n"
    text = text.replace("note={STAGE6C2 VERIFY}", "")
    path.write_text(text, encoding="utf-8")
    return "STAGE6C2 VERIFY" not in text

def patch_latex(package_root: Path) -> None:
    # Use the generic fallback style only in main.tex.
    main = package_root / "main.tex"
    text = main.read_text(encoding="utf-8")
    text = text.replace(r"\bibliographystyle{mnras}", r"\bibliographystyle{plainnat}")
    if r"\setlength{\emergencystretch}" not in text:
        text = text.replace(r"\begin{document}", r"\setlength{\emergencystretch}{2em}" + "\n" + r"\begin{document}")
    main.write_text(text, encoding="utf-8")

    # Split the long calibration equation.
    p = package_root / "sections" / "04_calibration.tex"
    if p.exists():
        t = p.read_text(encoding="utf-8")
        old = r"""\begin{equation}
\Delta y_i =
a_{0,y}
+a_{T,y}\left(\frac{T_{{\rm eff},i}-4800}{1000}\right)
+a_{g,y}(\log g_i-2.5)
+a_{{\rm Fe},y}[{\rm Fe/H}]_i+\epsilon_{i,y}.
\label{eq:calibration_model}
\end{equation}"""
        new = r"""\begin{equation}
\begin{split}
\Delta y_i ={}& a_{0,y}
+a_{T,y}\left(\frac{T_{{\rm eff},i}-4800}{1000}\right)\\
&+a_{g,y}(\log g_i-2.5)
+a_{{\rm Fe},y}[{\rm Fe/H}]_i+\epsilon_{i,y}.
\end{split}
\label{eq:calibration_model}
\end{equation}"""
        t = t.replace(old, new)
        p.write_text(t, encoding="utf-8")

    p = package_root / "sections" / "05_methodology.tex"
    if p.exists():
        t = p.read_text(encoding="utf-8")
        old = r"""\begin{equation}
y_i = \beta_{0,y}+\beta_{R,y}(R_i-R_0)+\beta_{Z,y}|Z_i|+\epsilon_{i,y},
\qquad R_0=8.2\,{\rm kpc}.
\label{eq:gradient_model}
\end{equation}"""
        new = r"""\begin{equation}
\begin{split}
y_i={}&\beta_{0,y}+\beta_{R,y}(R_i-R_0)\\
&+\beta_{Z,y}|Z_i|+\epsilon_{i,y},
\qquad R_0=8.2\,{\rm kpc}.
\end{split}
\label{eq:gradient_model}
\end{equation}"""
        t = t.replace(old, new)
        p.write_text(t, encoding="utf-8")

def locate_mnras(root: Path, package_root: Path) -> str:
    candidates = [root / "mnras.cls", root / "templates" / "mnras.cls"]
    for p in root.rglob("mnras.cls"):
        if "stage6c2a_asset_reconciliation" not in str(p).lower():
            candidates.append(p)
    for p in candidates:
        if p.exists():
            shutil.copy2(p, package_root / "mnras.cls")
            return safe_rel(p, root)
    try:
        result = subprocess.run(["kpsewhich", "mnras.cls"], capture_output=True, text=True, timeout=20)
        found = Path(result.stdout.strip())
        if result.returncode == 0 and found.exists():
            shutil.copy2(found, package_root / "mnras.cls")
            return str(found)
    except Exception:
        pass
    return ""

def scan_human_metadata(package_root: Path) -> list[dict[str, str]]:
    markers = ["INSERT ", "INSERT_", "TODO", "EXACT_VERSION_DOI", "CONCEPT_DOI", "REPOSITORY_URL"]
    rows = []
    for p in sorted(package_root.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in {".tex", ".yaml", ".yml", ".json", ".cff", ".md"}:
            continue
        text = p.read_text(encoding="utf-8", errors="ignore")
        for marker in markers:
            count = text.count(marker)
            if count:
                rows.append({"path": safe_rel(p, package_root), "marker": marker, "count": str(count)})
    return rows

def update_figure_slot(package_root: Path, number: int, filename: str, caption: str) -> None:
    slot = package_root / "figures" / f"figure{number:02d}_slot.tex"
    slot.write_text(
        rf"""\begin{{figure*}}
\centering
\includegraphics[width=0.96\textwidth]{{figures/{filename}}}
\caption{{{caption}}}
\label{{fig:f{number:02d}}}
\end{{figure*}}
""", encoding="utf-8"
    )

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE)
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = read_json(root / "config" / "stage6c2a_config.json")
    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for d in ["validation", "summaries", "tables", "figures", "manuscript_source", "checksums"]:
        (out_dir / d).mkdir(parents=True, exist_ok=True)

    s6a_path = root / "outputs/stage6a_claimsafe_closeout/validation/stage6a_validation.json"
    s6b_path = root / "outputs/stage6b_release_candidate/validation/stage6b_validation.json"
    s6c1_path = root / "outputs/stage6c1_mnras_source/validation/stage6c1_validation.json"
    s6a = read_json(s6a_path) if s6a_path.exists() else {}
    s6b = read_json(s6b_path) if s6b_path.exists() else {}
    s6c1 = read_json(s6c1_path) if s6c1_path.exists() else {}

    source_package = root / cfg["stage6c1_package"]
    if not source_package.exists():
        raise FileNotFoundError(f"Missing Stage-6C1 manuscript source: {source_package}")
    package_root = out_dir / "manuscript_source" / cfg["new_package_name"]
    shutil.copytree(source_package, package_root)

    suffixes = {s.lower() for s in cfg["scan_suffixes"]}
    files = [
        p for p in root.rglob("*")
        if p.is_file()
        and p.suffix.lower() in suffixes
        and not excluded(p, root, cfg["exclude_prefixes"])
    ]

    profiles: list[dict[str, Any]] = []
    for p in files:
        prof = profile_file(p)
        prof["relative_path"] = safe_rel(p, root)
        profiles.append(prof)

    candidate_rows: list[dict[str, Any]] = []
    selected: dict[str, dict[str, Any]] = {}
    for asset_id, asset in cfg["assets"].items():
        ranked = []
        for prof in profiles:
            if prof["load_error"] or not prof["columns"]:
                continue
            ok, score, reasons, missing = candidate_score(
                prof, asset, prof["relative_path"],
                cfg["non_authoritative_tokens"], cfg["secondary_tokens"]
            )
            row = {
                "asset_id": asset_id,
                "asset_title": asset["title"],
                "candidate_path": prof["relative_path"],
                "accepted_schema": str(ok).lower(),
                "score": score,
                "n_rows": prof["n_rows"] if prof["n_rows"] is not None else "",
                "columns": "|".join(prof["columns"]),
                "reasons": ";".join(reasons),
                "missing_required_groups": ";".join(missing),
            }
            if ok:
                ranked.append(row)
        ranked.sort(key=lambda r: (-int(r["score"]), str(r["candidate_path"])))
        candidate_rows.extend(ranked[: int(cfg["candidate_limit"])])
        if ranked:
            selected[asset_id] = ranked[0]

    write_csv(
        out_dir / "tables/stage6c2a_strict_asset_candidates.csv",
        ["asset_id", "asset_title", "candidate_path", "accepted_schema", "score",
         "n_rows", "columns", "reasons", "missing_required_groups"],
        candidate_rows
    )

    selected_rows: list[dict[str, Any]] = []
    canonical: dict[str, pd.DataFrame] = {}
    for asset_id, asset in cfg["assets"].items():
        candidate = selected.get(asset_id)
        status = "missing_strict_source"
        canonical_path = ""
        if candidate:
            try:
                src = root / candidate["candidate_path"]
                frame = load_frame(src)
                canon = canonicalise(frame, asset_id)
                if not canon.empty:
                    canonical[asset_id] = canon
                    canonical_path = f"tables/canonical_{asset_id.lower()}.csv"
                    canon.to_csv(out_dir / canonical_path, index=False)
                    status = "strict_source_selected"
                    table_number = int(asset_id[1:])
                    target = package_root / "tables" / {
                        1: "table01_sample_flow.tex",
                        2: "table02_calibration.tex",
                        3: "table03_global_gradients.tex",
                        4: "table04_population_summary.tex",
                        5: "table05_population_gradients.tex",
                        6: "table06_survey_subsets.tex",
                    }[table_number]
                    target.write_text(
                        dataframe_to_latex(asset_id, asset["title"], canon, candidate["candidate_path"]),
                        encoding="utf-8"
                    )
            except Exception as exc:
                status = f"load_failed:{type(exc).__name__}"
        selected_rows.append({
            "asset_id": asset_id,
            "title": asset["title"],
            "status": status,
            "selected_source": candidate["candidate_path"] if candidate else "",
            "score": candidate["score"] if candidate else "",
            "canonical_product": canonical_path,
        })

    write_csv(
        out_dir / "tables/stage6c2a_selected_sources.csv",
        ["asset_id", "title", "status", "selected_source", "score", "canonical_product"],
        selected_rows
    )

    generated = {}
    if "T02" in canonical:
        path = package_root / "figures/f01_calibration_residual_mad.pdf"
        generated["F01"] = save_bar_labels(
            canonical["T02"], "label", "residual_mad", path, "Post-calibration residual MAD [dex]"
        )
        if generated["F01"]:
            update_figure_slot(package_root, 1, path.name, "Label-specific APOGEE--GALAH post-calibration residual MAD.")

    # F02: star-level map.
    star = find_star_level(profiles, cfg["star_level_aliases"])
    if star:
        try:
            star_path = root / star["profile"]["relative_path"]
            star_frame = load_frame(star_path, max_rows=int(cfg["max_plot_rows"]))
            path = package_root / "figures/f02_chemo_kinematic_population_map.pdf"
            generated["F02"] = plot_population_map(
                star_frame, cfg["star_level_aliases"], path, int(cfg["max_plot_rows"])
            )
            if generated["F02"]:
                update_figure_slot(
                    package_root, 2, path.name,
                    "Chemo-kinematic population structure in the linked star-level frozen product."
                )
        except Exception:
            generated["F02"] = False
    else:
        generated["F02"] = False

    if "T04" in canonical:
        path = package_root / "figures/f03_population_counts.pdf"
        generated["F03"] = save_bar_labels(
            canonical["T04"], "population", "n", path, "Number of stars"
        )
        if generated["F03"]:
            update_figure_slot(package_root, 3, path.name, "Probabilistic population counts in the frozen summary.")

    if "T03" in canonical:
        path = package_root / "figures/f04_global_gradients.pdf"
        generated["F04"] = plot_gradient(canonical["T03"], path)
        if generated["F04"]:
            update_figure_slot(package_root, 4, path.name, "Global radial and vertical gradients from the strict frozen source.")

    if "T06" in canonical:
        path = package_root / "figures/f05_survey_subset_gradients.pdf"
        generated["F05"] = plot_survey(canonical["T06"], path)
        if generated["F05"]:
            update_figure_slot(package_root, 5, path.name, "Survey-subset comparison of radial and vertical gradients.")

    figure_rows = [
        {"figure_id": key, "generated": str(bool(generated.get(key, False))).lower()}
        for key in ["F01", "F02", "F03", "F04", "F05"]
    ]
    write_csv(out_dir / "tables/stage6c2a_figure_generation.csv", ["figure_id", "generated"], figure_rows)

    bibliography_ready = patch_bibliography(package_root / "references.bib")
    patch_latex(package_root)
    mnras_source = locate_mnras(root, package_root)
    human_rows = scan_human_metadata(package_root)
    write_csv(
        out_dir / "tables/stage6c2a_human_metadata_audit.csv",
        ["path", "marker", "count"],
        human_rows
    )

    # Compile scripts.
    (package_root / "compile_fallback.bat").write_text(
        r"""@echo off
setlocal
cd /d "%~dp0"
pdflatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
bibtex main || exit /b 1
pdflatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
pdflatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
findstr /I /C:"undefined citations" /C:"undefined references" main.log >nul
if not errorlevel 1 (
  echo [ERROR] Undefined citations or references remain.
  exit /b 2
)
echo [OK] main.pdf created without undefined citation/reference markers.
endlocal
""", encoding="utf-8")
    (package_root / "install_or_find_mnras_class.bat").write_text(
        r"""@echo off
setlocal
cd /d "%~dp0"
for /f "delims=" %%I in ('kpsewhich mnras.cls 2^>nul') do set "MNRASCLS=%%I"
if defined MNRASCLS (
  copy /Y "%MNRASCLS%" mnras.cls >nul
  echo [OK] mnras.cls copied from TeX installation.
  exit /b 0
)
echo [INFO] mnras.cls was not found by kpsewhich.
echo [INFO] Install the official MNRAS LaTeX package or copy mnras.cls here.
exit /b 2
""", encoding="utf-8")

    strict_tables_ready = len(canonical) == 6
    figures_ready = all(generated.get(k, False) for k in ["F01", "F02", "F03", "F04", "F05"])
    human_ready = len(human_rows) == 0
    latex_ready = (package_root / "main.tex").exists() and (package_root / "main_mnras.tex").exists()
    mnras_ready = bool(mnras_source) and (package_root / "mnras.cls").exists()
    preconditions = bool(
        s6a.get("STAGE6A_CLOSEOUT_READY", False)
        and s6b.get("STAGE6B_ARCHIVAL_RC_READY", False)
        and s6c1.get("STAGE6C1_SOURCE_TREE_READY", False)
    )
    science_ready = bool(
        preconditions and strict_tables_ready and figures_ready
        and bibliography_ready and latex_ready
    )

    remaining = []
    if not strict_tables_ready:
        missing = [k for k in cfg["assets"] if k not in canonical]
        remaining.append({"gate": "STRICT_TABLE_LINKAGE_READY", "required_action": "Strict numerical source missing for: " + ", ".join(missing)})
    if not figures_ready:
        missing = [k for k in ["F01", "F02", "F03", "F04", "F05"] if not generated.get(k, False)]
        remaining.append({"gate": "FIGURE_REGENERATION_READY", "required_action": "Figure could not be regenerated for: " + ", ".join(missing)})
    if not mnras_ready:
        remaining.append({"gate": "MNRAS_TEMPLATE_READY", "required_action": "Run install_or_find_mnras_class.bat or copy the official mnras.cls into the source package."})
    if not human_ready:
        remaining.append({"gate": "HUMAN_METADATA_READY", "required_action": "Complete AUTHOR_METADATA.yaml and replace author, affiliation, funding, repository, and DOI placeholders."})
    write_csv(
        out_dir / "tables/stage6c2a_remaining_closure_items.csv",
        ["gate", "required_action"],
        remaining
    )

    validation = {
        "stage": STAGE,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "stage6a_closeout_ready": bool(s6a.get("STAGE6A_CLOSEOUT_READY", False)),
        "stage6b_archival_rc_ready": bool(s6b.get("STAGE6B_ARCHIVAL_RC_READY", False)),
        "stage6c1_source_tree_ready": bool(s6c1.get("STAGE6C1_SOURCE_TREE_READY", False)),
        "profiled_machine_readable_file_count": len(profiles),
        "strict_table_source_count": len(canonical),
        "generated_figure_count": sum(bool(v) for v in generated.values()),
        "mnras_class_source": mnras_source,
        "human_metadata_placeholder_count": sum(int(r["count"]) for r in human_rows),
        "prior_stage_outputs_modified": False,
        "STRICT_TABLE_LINKAGE_READY": strict_tables_ready,
        "FIGURE_REGENERATION_READY": figures_ready,
        "BIBLIOGRAPHY_VERIFICATION_READY": bibliography_ready,
        "LATEX_HARDENING_READY": latex_ready,
        "MNRAS_TEMPLATE_READY": mnras_ready,
        "HUMAN_METADATA_READY": human_ready,
        "STAGE6C2A_SCIENCE_ASSETS_READY": science_ready,
        "ZENODO_SUBMISSION_READY": bool(science_ready and mnras_ready and human_ready),
    }

    # Manifest and archive.
    manifest = []
    for p in sorted(package_root.rglob("*")):
        if p.is_file():
            manifest.append({
                "path": safe_rel(p, package_root),
                "size_bytes": p.stat().st_size,
                "sha256": sha256_file(p)
            })
    write_json(package_root / "PROVENANCE_MANIFEST.json", {
        "stage": STAGE, "created_utc": utc_now(), "files": manifest
    })
    sums = [
        f"{sha256_file(p)}  {safe_rel(p, package_root)}"
        for p in sorted(package_root.rglob("*"))
        if p.is_file() and p.name != "SHA256SUMS.txt"
    ]
    (package_root / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")

    zip_path = out_dir / "manuscript_source" / f"{cfg['new_package_name']}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        for p in sorted(package_root.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(package_root.parent))
    validation["source_package"] = safe_rel(package_root, root)
    validation["source_zip"] = safe_rel(zip_path, root)
    validation["source_zip_size_bytes"] = zip_path.stat().st_size
    validation["source_zip_sha256"] = sha256_file(zip_path)
    write_json(out_dir / "validation/stage6c2a_validation.json", validation)

    summary = {
        "stage": STAGE,
        "timestamp_utc": utc_now(),
        "strict_table_sources": {
            row["asset_id"]: row["selected_source"]
            for row in selected_rows if row["status"] == "strict_source_selected"
        },
        "figures_generated": [k for k, v in generated.items() if v],
        "remaining_closure_items": remaining,
        "scientific_disposition": (
            "Scientific manuscript assets are closed; complete MNRAS class and human metadata for final Zenodo/submission assembly."
            if science_ready else
            "Strict reconciliation exposed unresolved scientific assets. Do not mint the final Zenodo release yet."
        )
    }
    write_json(out_dir / "summaries/stage6c2a_summary.json", summary)

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    return 0 if preconditions and latex_ready and bibliography_ready else 2

if __name__ == "__main__":
    raise SystemExit(main())
