from __future__ import annotations
import argparse, csv, json, math, re, shutil
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd

MAX_EXACT_FLOAT_INT = 9007199254740991

def now(): return datetime.now(timezone.utc).isoformat()
def norm(x): return re.sub(r"[^a-z0-9]+","_",str(x).lower()).strip("_")
def rel(p,r):
    try: return str(p.resolve().relative_to(r.resolve())).replace("\\","/")
    except Exception: return str(p).replace("\\","/")
def wjson(p,x):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, indent=2, default=str)+"\n", encoding="utf-8")
def wcsv(p, fields, rows):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", newline="", encoding="utf-8") as h:
        w=csv.DictWriter(h, fieldnames=fields, extrasaction="ignore"); w.writeheader(); w.writerows(rows)
def find(cols, names):
    m={norm(c):c for c in cols}
    for n in names:
        if norm(n) in m: return m[norm(n)]
    return None
def resolve(p):
    for q in [p,p.with_suffix(".csv"),p.with_suffix(".feather")]:
        if q.exists(): return q
    return None
def read(p, cols=None, strings=None):
    if p.suffix.lower()==".parquet": return pd.read_parquet(p, columns=cols)
    if p.suffix.lower()==".feather": return pd.read_feather(p, columns=cols)
    dtype={c:"string" for c in (strings or [])}
    return pd.read_csv(p, usecols=cols, dtype=dtype or None)

def exact_uint64(s):
    out=pd.Series(pd.NA,index=s.index,dtype="UInt64")
    a={"dtype":str(s.dtype),"non_null":int(s.notna().sum()),
       "exact_rows":0,"large_float_gt_2p53":0,"other_rejected":0}
    if pd.api.types.is_unsigned_integer_dtype(s.dtype):
        out=s.astype("UInt64")
    elif pd.api.types.is_integer_dtype(s.dtype):
        v=s.astype("Int64"); ok=v.notna()&(v>=0)
        if ok.any(): out.loc[ok]=pd.array(v.loc[ok].astype("string"),dtype="UInt64")
    elif pd.api.types.is_float_dtype(s.dtype):
        v=pd.to_numeric(s,errors="coerce"); finite=v.notna()&np.isfinite(v)
        integer=finite&(v==np.floor(v))
        large=integer&(v>MAX_EXACT_FLOAT_INT)
        ok=integer&(v>=0)&(v<=MAX_EXACT_FLOAT_INT)
        a["large_float_gt_2p53"]=int(large.sum())
        if ok.any(): out.loc[ok]=pd.array(v.loc[ok].astype("uint64").astype("string"),dtype="UInt64")
    else:
        t=s.astype("string").str.strip().str.replace(r"^\+","",regex=True)
        ok=t.str.fullmatch(r"[0-9]+",na=False)
        if ok.any():
            vals=t.loc[ok].str.lstrip("0").mask(lambda x:x=="","0")
            good=vals.str.len()<=20
            vals=vals.loc[good]
            if len(vals):
                out.loc[vals.index]=pd.array(vals,dtype="UInt64")
    a["exact_rows"]=int(out.notna().sum())
    a["other_rejected"]=a["non_null"]-a["exact_rows"]-a["large_float_gt_2p53"]
    a["precision_risk"]=a["large_float_gt_2p53"]>0
    return out,a

def sobject(s):
    t=s.astype("string").str.strip()
    dec=t.str.fullmatch(r"[+]?[0-9]+(?:\.0+)?",na=False)
    if dec.any():
        v=t.loc[dec].str.replace(r"^\+","",regex=True).str.replace(r"\.0+$","",regex=True).str.lstrip("0").mask(lambda x:x=="","0")
        t.loc[dec]=v
    return t.str.upper().str.replace(r"\s+","",regex=True).replace({"":pd.NA,"NAN":pd.NA,"NONE":pd.NA})

def snr_contract(cols):
    scalar=find(cols,["snr","snr_med","snr_median","median_snr","galah_snr","snr_galah"])
    if scalar: return "scalar",[scalar]
    groups=[
        ["snr_c1","snr_c1_iraf","snr_ccd1","snr_blue"],
        ["snr_c2","snr_c2_iraf","snr_ccd2","snr_green"],
        ["snr_c3","snr_c3_iraf","snr_ccd3","snr_red"],
        ["snr_c4","snr_c4_iraf","snr_ccd4","snr_ir"],
    ]
    got=[]
    for g in groups:
        c=find(cols,g)
        if c: got.append(c)
    return ("channels",got) if len(got)>=2 else (None,[])

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); args=ap.parse_args()
    root=Path(args.project_root).resolve()
    cfg=json.loads((root/"config/stage6d3a2d8a_config.json").read_text())
    out=root/cfg["output_dir"]
    if out.exists(): shutil.rmtree(out)
    (out/"validation").mkdir(parents=True); (out/"tables").mkdir(); (out/"summaries").mkdir()
    prepath=root/cfg["prerequisite_validation"]
    pre=json.loads(prepath.read_text()) if prepath.exists() else {}
    prereq=bool(pre.get("STAGE6D3A2D8_PROVENANCE_DIAGNOSIS_READY",False) and pre.get("FROZEN_OVERLAP_GATES_UNCHANGED",False))

    anchor_path=resolve(root/cfg["canonical_anchor"])
    anchor=read(anchor_path, strings=["source_id"]) if anchor_path else pd.DataFrame()
    anchor_ready={"source_id","survey"}.issubset(anchor.columns)
    if anchor_ready:
        aid,_=exact_uint64(anchor["source_id"]); anchor=anchor[aid.notna()].copy(); anchor["source_id"]=aid[aid.notna()].astype("uint64")
    galah_ids=set(anchor.loc[anchor["survey"]=="GALAH_CORRECTED","source_id"].astype("uint64")) if anchor_ready else set()

    pop_rows=[]; best_pop_overlap=0; any_precision=False
    for rr in cfg["population_candidates"]:
        p=resolve(root/rr)
        row={"path":rr,"exists":bool(p),"read_error":""}
        if not p:
            row.update({"source_id_dtype":"","exact_source_id_rows":0,"large_float_gt_2p53":0,"precision_risk":False,"snr_contract":"","finite_snr_rows":0,"exact_id_anchor_overlap_rows":0,"exact_id_anchor_overlap_fraction":0.0})
            pop_rows.append(row); continue
        try:
            cols=list(read(p).columns)
            sid=find(cols,["gaia_dr3_source_id","dr3_source_id","gaia_source_id","gaiaedr3_source_id","gaia_edr3_source_id"])
            contract,scols=snr_contract(cols)
            if not sid: raise RuntimeError("no Gaia DR3 source-ID column")
            use=[sid]+scols
            fr=read(p,use,strings=[sid])
            ids,a=exact_uint64(fr[sid]); any_precision|=a["precision_risk"]
            overlap=len(galah_ids.intersection(set(ids.dropna().astype("uint64"))))
            finite_snr=0
            if contract=="scalar":
                finite_snr=int(pd.to_numeric(fr[scols[0]],errors="coerce").notna().sum())
            elif contract=="channels":
                vv=pd.DataFrame({c:pd.to_numeric(fr[c],errors="coerce") for c in scols})
                finite_snr=int((vv.notna().sum(axis=1)>=2).sum())
            row.update({"source_id_column":sid,"source_id_dtype":a["dtype"],"exact_source_id_rows":a["exact_rows"],"large_float_gt_2p53":a["large_float_gt_2p53"],"precision_risk":a["precision_risk"],"snr_contract":contract or "","finite_snr_rows":finite_snr,"exact_id_anchor_overlap_rows":overlap,"exact_id_anchor_overlap_fraction":overlap/max(len(galah_ids),1)})
            best_pop_overlap=max(best_pop_overlap,overlap)
        except Exception as e:
            row["read_error"]=f"{type(e).__name__}: {e}"
        pop_rows.append(row)

    diag_rows=[]; best_diag=0; best_diag_frac=0.0
    for rr in cfg["diagnostic_crosswalks"]:
        p=resolve(root/rr); row={"path":rr,"exists":bool(p),"read_error":""}
        if not p:
            row.update({"mapping_rows":0,"conflicting_sobject_ids":0,"functional_ready":False,"anchor_overlap_rows":0,"anchor_overlap_fraction":0.0}); diag_rows.append(row); continue
        try:
            cols=list(read(p).columns)
            so=find(cols,["galah_sobject_id","sobject_id","sobject_id_1","sobject_id_2"])
            sid=find(cols,["gaia_dr3_source_id","dr3_source_id","gaia_source_id"])
            if not so or not sid: raise RuntimeError("missing sobject/Gaia columns")
            fr=read(p,[so,sid],strings=[so,sid])
            left=sobject(fr[so]); right,a=exact_uint64(fr[sid])
            m=pd.DataFrame({"sobject_id":left,"source_id":right}).dropna().drop_duplicates()
            conflicts=(m.groupby("sobject_id")["source_id"].nunique()>1)
            functional=not conflicts.any()
            if functional: m=m.drop_duplicates("sobject_id")
            overlap=len(galah_ids.intersection(set(m["source_id"].astype("uint64"))))
            frac=overlap/max(len(galah_ids),1); best_diag=max(best_diag,overlap); best_diag_frac=max(best_diag_frac,frac)
            row.update({"sobject_column":so,"source_id_column":sid,"source_id_dtype":a["dtype"],"mapping_rows":len(m),"conflicting_sobject_ids":int(conflicts.sum()),"functional_ready":functional,"anchor_overlap_rows":overlap,"anchor_overlap_fraction":frac})
        except Exception as e:
            row["read_error"]=f"{type(e).__name__}: {e}"
        diag_rows.append(row)

    minrows=int(cfg["minimum_overlap_rows"]); minfrac=float(cfg["minimum_overlap_fraction"])
    internal_ready=any((r.get("exact_id_anchor_overlap_rows",0)>=minrows and r.get("exact_id_anchor_overlap_fraction",0)>=minfrac and r.get("finite_snr_rows",0)>=minrows and not r.get("precision_risk",False)) for r in pop_rows)
    diag_ready=best_diag>=minrows and best_diag_frac>=minfrac

    if internal_ready:
        diagnosis="INTERNAL_FULL_POPULATION_GALAH_SOURCE_READY"
    elif any_precision and diag_ready:
        diagnosis="UPSTREAM_GALAH_GAIA_ID_FLOAT64_PRECISION_LOSS"
    elif diag_ready:
        diagnosis="UPSTREAM_GALAH_GAIA_IDENTIFIER_RELEASE_OR_GENERATION_MISMATCH"
    else:
        diagnosis="NO_INTERNAL_EXACT_GALAH_POPULATION_BRIDGE"

    wcsv(out/"tables/stage6d3a2d8a_population_precision_audit.csv",
         ["path","exists","source_id_column","source_id_dtype","exact_source_id_rows","large_float_gt_2p53","precision_risk","snr_contract","finite_snr_rows","exact_id_anchor_overlap_rows","exact_id_anchor_overlap_fraction","read_error"],pop_rows)
    wcsv(out/"tables/stage6d3a2d8a_common_star_crosswalk_diagnostic.csv",
         ["path","exists","sobject_column","source_id_column","source_id_dtype","mapping_rows","conflicting_sobject_ids","functional_ready","anchor_overlap_rows","anchor_overlap_fraction","read_error"],diag_rows)

    external_required=not internal_ready
    val={
        "stage":cfg["stage"],"implementation_version":cfg["implementation_version"],"timestamp_utc":now(),
        "diagnosis":diagnosis,"canonical_galah_anchor_rows":len(galah_ids),
        "best_population_exact_anchor_overlap_rows":best_pop_overlap,
        "best_diagnostic_crosswalk_anchor_overlap_rows":best_diag,
        "best_diagnostic_crosswalk_anchor_overlap_fraction":best_diag_frac,
        "any_population_gaia_id_float64_precision_loss_risk":any_precision,
        "STAGE6D3A2D8_PREREQUISITE_READY":prereq,
        "CANONICAL_ANCHOR_READY":anchor_ready,
        "INTERNAL_GALAH_POPULATION_PRECISION_AUDIT_READY":True,
        "COMMON_STAR_CROSSWALK_DIAGNOSTIC_READY":True,
        "COMMON_STAR_OVERLAP_PRODUCT_NOT_ALLOWED_AS_POPULATION_BRIDGE":True,
        "INTERNAL_FULL_POPULATION_GALAH_SOURCE_READY":internal_ready,
        "EXTERNAL_SOURCE_ACQUISITION_REQUIRED":external_required,
        "FROZEN_OVERLAP_GATES_UNCHANGED":True,
        "STAGE6D3A2D8A_DIAGNOSIS_READY":bool(prereq and anchor_ready),
        "STAGE6D3B_COMMON_FOOTPRINT_READY":False
    }
    wjson(out/"validation/stage6d3a2d8a_validation.json",val)
    wjson(out/"summaries/stage6d3a2d8a_summary.json",{
        "diagnosis":diagnosis,
        "scientific_disposition":(
            "Internal full-population GALAH source is exact enough to supersede the D8 external-acquisition diagnosis; build a separate source-assembly closure next."
            if internal_ready else
            "External reacquisition remains required, but the exact reason is now precision loss, identifier-generation mismatch, or absence of a population bridge as classified above."
        )
    })
    print(json.dumps({"validation":val},indent=2))
    return 0

if __name__=="__main__": raise SystemExit(main())
