from __future__ import annotations
import argparse, csv, hashlib, json, re, shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd

def now():
    return datetime.now(timezone.utc).isoformat()

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def wjson(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8"
    )

def wcsv(path: Path, fields, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as h:
        w = csv.DictWriter(h, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)

def read_table(path: Path):
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower() == ".feather":
        return pd.read_feather(path)
    return pd.read_csv(path)

def bool_series(s):
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False)
    if pd.api.types.is_numeric_dtype(s):
        return pd.to_numeric(s, errors="coerce").fillna(0).astype(float) != 0
    return s.astype(str).str.strip().str.lower().isin(
        ["true", "1", "yes", "y", "t"]
    )

def numeric_alias_identity(df, cols, atol, rtol):
    if len(cols) <= 1:
        return True
    ref = pd.to_numeric(df[cols[0]], errors="coerce").to_numpy(float)
    for c in cols[1:]:
        x = pd.to_numeric(df[c], errors="coerce").to_numpy(float)
        both = np.isfinite(ref) & np.isfinite(x)
        if not np.any(both):
            return False
        if not np.allclose(ref[both], x[both], atol=atol, rtol=rtol):
            return False
    return True

def resolve_alias(df, candidates, name, numeric=False, atol=1e-10, rtol=1e-12):
    present = [c for c in candidates if c in df.columns]
    if not present:
        return {
            "semantic_name": name,
            "selected": None,
            "present_candidates": [],
            "status": "MISSING"
        }
    if len(present) == 1:
        return {
            "semantic_name": name,
            "selected": present[0],
            "present_candidates": present,
            "status": "RESOLVED_UNIQUE"
        }
    if numeric and numeric_alias_identity(df, present, atol, rtol):
        return {
            "semantic_name": name,
            "selected": present[0],
            "present_candidates": present,
            "status": "RESOLVED_MULTIPLE_NUMERICALLY_IDENTICAL"
        }
    # For nonnumeric aliases, exact string identity is required.
    if not numeric:
        ref = df[present[0]].astype(str).fillna("")
        identical = all(
            ref.equals(df[c].astype(str).fillna(""))
            for c in present[1:]
        )
        if identical:
            return {
                "semantic_name": name,
                "selected": present[0],
                "present_candidates": present,
                "status": "RESOLVED_MULTIPLE_IDENTICAL"
            }
    return {
        "semantic_name": name,
        "selected": None,
        "present_candidates": present,
        "status": "AMBIGUOUS_NONIDENTICAL"
    }

def find_first_existing(root, candidates):
    for c in candidates:
        p = root / c
        if p.exists():
            return p
    return None

def stage4b_inventory(root):
    if not root.exists():
        return []
    rows = []
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.suffix.lower() in {".csv",".parquet",".feather",".json",".yml",".yaml",".py"}:
            rows.append({
                "path": str(p),
                "suffix": p.suffix.lower(),
                "size_bytes": p.stat().st_size
            })
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d4a1_config.json").read_text(encoding="utf-8")
    )

    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in ["validation","tables","lineage","summaries","reports"]:
        (out/d).mkdir(parents=True, exist_ok=True)

    d3v_path = root / cfg["d3c9_validation"]
    source_path = root / cfg["balanced_source"]
    if not d3v_path.exists():
        raise FileNotFoundError(str(d3v_path))
    if not source_path.exists():
        raise FileNotFoundError(str(source_path))

    d3v = json.loads(d3v_path.read_text(encoding="utf-8"))
    prereq = bool(
        d3v.get("PRODUCTION_BALANCED_WEIGHTS_READY", False)
        and d3v.get("STAGE6D3C9_PRODUCTION_REPLAY_READY", False)
        and d3v.get("STAGE6D4_SCIENCE_MODELS_READY", False)
        and d3v.get("d3c8_amended_protocol_canonical_sha256")
        == cfg["expected_d3c8_sha256"]
    )

    df = read_table(source_path).reset_index(drop=True)

    column_rows = []
    for i, c in enumerate(df.columns):
        column_rows.append({
            "index": i,
            "column": c,
            "dtype": str(df[c].dtype),
            "finite_or_nonnull": int(
                np.isfinite(pd.to_numeric(df[c], errors="coerce")).sum()
                if pd.api.types.is_numeric_dtype(df[c])
                else df[c].notna().sum()
            )
        })
    wcsv(
        out/"tables/stage6d4a1_balanced_source_column_inventory.csv",
        ["index","column","dtype","finite_or_nonnull"],
        column_rows
    )

    resolutions = [
        resolve_alias(df, cfg["source_id_candidates"], "source_id", numeric=False),
        resolve_alias(df, cfg["survey_candidates"], "survey", numeric=False),
        resolve_alias(df, cfg["r_candidates"], "R_cyl_gc_kpc", numeric=True,
                      atol=cfg["alias_identity_atol"], rtol=cfg["alias_identity_rtol"]),
        resolve_alias(df, cfg["abs_z_candidates"], "abs_Z_gc_kpc", numeric=True,
                      atol=cfg["alias_identity_atol"], rtol=cfg["alias_identity_rtol"]),
        resolve_alias(df, cfg["cell_candidates"], "healpix_nside16", numeric=True,
                      atol=0.0, rtol=0.0),
        resolve_alias(df, cfg["weight_candidates"], "balance_weight", numeric=True,
                      atol=cfg["alias_identity_atol"], rtol=cfg["alias_identity_rtol"])
    ]
    rmap = {x["semantic_name"]: x for x in resolutions}
    base_schema_ready = all(x["selected"] is not None for x in resolutions)

    wcsv(
        out/"tables/stage6d4a1_base_alias_resolution.csv",
        ["semantic_name","selected","present_candidates","status"],
        [{
            **x,
            "present_candidates": "|".join(x["present_candidates"])
        } for x in resolutions]
    )

    shape_ready = False
    if base_schema_ready:
        survey_col = rmap["survey"]["selected"]
        r_col = rmap["R_cyl_gc_kpc"]["selected"]
        z_col = rmap["abs_Z_gc_kpc"]["selected"]
        cell_col = rmap["healpix_nside16"]["selected"]
        weight_col = rmap["balance_weight"]["selected"]

        R = pd.to_numeric(df[r_col], errors="coerce")
        Z = pd.to_numeric(df[z_col], errors="coerce")
        W = pd.to_numeric(df[weight_col], errors="coerce")
        exact_surveys = set(df[survey_col].astype(str).unique()) == set(cfg["expected_surveys"])
        shape_ready = bool(
            len(df) == cfg["expected_rows"]
            and int(df[cell_col].nunique()) == cfg["expected_cells"]
            and exact_surveys
            and np.all(np.isfinite(R))
            and np.all(np.isfinite(Z))
            and np.all(np.isfinite(W))
            and np.all(W > 0)
        )
        radial = (R > cfg["radial_domain"][0]) & (R < cfg["radial_domain"][1])
    else:
        survey_col = r_col = z_col = cell_col = weight_col = None
        radial = pd.Series(False, index=df.index)

    label_rows = []
    for lab in cfg["primary_labels"] + cfg["secondary_labels"]:
        yres = resolve_alias(
            df, cfg["label_candidates"][lab],
            f"{lab}_outcome", numeric=True,
            atol=cfg["alias_identity_atol"], rtol=cfg["alias_identity_rtol"]
        )
        gres = resolve_alias(
            df, cfg["eligibility_candidates"][lab],
            f"{lab}_eligibility", numeric=False
        )
        ready = False
        n = cells = arows = grows = 0
        if base_schema_ready and yres["selected"] and gres["selected"]:
            finite = np.isfinite(pd.to_numeric(df[yres["selected"]], errors="coerce"))
            eligible = bool_series(df[gres["selected"]])
            use = finite & eligible & radial
            n = int(use.sum())
            cells = int(df.loc[use, cell_col].nunique()) if n else 0
            arows = int((use & (df[survey_col].astype(str)=="APOGEE_NATIVE")).sum())
            grows = int((use & (df[survey_col].astype(str)=="GALAH_CORRECTED")).sum())
            ready = bool(n > 0 and cells > 1 and arows > 0 and grows > 0)
        label_rows.append({
            "label": lab,
            "outcome_selected": yres["selected"] or "",
            "outcome_status": yres["status"],
            "eligibility_selected": gres["selected"] or "",
            "eligibility_status": gres["status"],
            "usable_rows": n,
            "usable_cells": cells,
            "APOGEE_NATIVE_rows": arows,
            "GALAH_CORRECTED_rows": grows,
            "MODEL_INPUT_READY": ready
        })

    wcsv(
        out/"tables/stage6d4a1_label_input_inventory.csv",
        list(label_rows[0].keys()), label_rows
    )

    primary_ready = all(
        x["MODEL_INPUT_READY"]
        for x in label_rows
        if x["label"] in cfg["primary_labels"]
    )
    alpha_ready = next(
        x["MODEL_INPUT_READY"] for x in label_rows if x["label"]=="alpha3"
    )

    s4root = root / cfg["stage4b_root"]
    inv = stage4b_inventory(s4root)
    if inv:
        wcsv(
            out/"tables/stage6d4a1_stage4b_file_inventory.csv",
            ["path","suffix","size_bytes"], inv
        )
    else:
        wcsv(
            out/"tables/stage6d4a1_stage4b_file_inventory.csv",
            ["path","suffix","size_bytes"], []
        )

    config_path = find_first_existing(root, cfg["stage4b_config_candidates"])
    script_path = find_first_existing(root, cfg["stage4b_script_candidates"])

    estimator_evidence = {}
    if script_path:
        text = script_path.read_text(encoding="utf-8", errors="ignore")
        estimator_evidence = {
            "huber_hits": len(re.findall(r"huber", text, re.I)),
            "bootstrap_hits": len(re.findall(r"bootstrap|resampl", text, re.I)),
            "gradient_hits": len(re.findall(r"abs_z|r_cyl|beta_R|beta_Z", text, re.I)),
            "pivot_hits": len(re.findall(r"8\.2|pivot|r0", text, re.I))
        }

    lineage_ready = bool(config_path and script_path)
    estimator_evidence_ready = bool(
        lineage_ready
        and estimator_evidence.get("huber_hits",0)>0
        and estimator_evidence.get("gradient_hits",0)>0
    )

    wjson(
        out/"lineage/stage6d4a1_schema_and_estimator_lineage.json",
        {
            "balanced_source": str(source_path.relative_to(root)).replace("\\","/"),
            "balanced_source_sha256": sha256_file(source_path),
            "base_alias_resolution": resolutions,
            "stage4b_config": str(config_path.relative_to(root)).replace("\\","/") if config_path else "",
            "stage4b_config_sha256": sha256_file(config_path) if config_path else "",
            "stage4b_script": str(script_path.relative_to(root)).replace("\\","/") if script_path else "",
            "stage4b_script_sha256": sha256_file(script_path) if script_path else "",
            "estimator_evidence": estimator_evidence
        }
    )

    ready = bool(
        prereq
        and base_schema_ready
        and shape_ready
        and primary_ready
        and lineage_ready
        and estimator_evidence_ready
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "input_rows": len(df),
        "D3C9_PRODUCTION_PREREQUISITE_READY": prereq,
        "BASE_SCHEMA_ALIAS_RESOLUTION_READY": base_schema_ready,
        "BASE_SOURCE_SHAPE_AND_FINITE_SUPPORT_READY": shape_ready,
        "resolved_source_id_column": rmap["source_id"]["selected"],
        "resolved_survey_column": rmap["survey"]["selected"],
        "resolved_R_column": rmap["R_cyl_gc_kpc"]["selected"],
        "resolved_abs_Z_column": rmap["abs_Z_gc_kpc"]["selected"],
        "resolved_cell_column": rmap["healpix_nside16"]["selected"],
        "resolved_weight_column": rmap["balance_weight"]["selected"],
        "PRIMARY_LABEL_INPUTS_READY": primary_ready,
        "ALPHA3_SECONDARY_INPUT_READY": alpha_ready,
        "STAGE4B_ESTIMATOR_LINEAGE_READY": lineage_ready,
        "STAGE4B_ESTIMATOR_EVIDENCE_READY": estimator_evidence_ready,
        "NO_FUZZY_SCHEMA_MATCHING_USED": True,
        "NO_OUTCOME_DEPENDENT_SCHEMA_SELECTION": True,
        "NO_SCIENCE_FIT_PERFORMED": True,
        "STAGE6D4A1_SCHEMA_PREFLIGHT_READY": ready,
        "STAGE6D4B_PRODUCTION_FITS_READY": ready
    }
    wjson(out/"validation/stage6d4a1_validation.json", validation)
    wjson(
        out/"summaries/stage6d4a1_summary.json",
        {
            "preflight_ready": ready,
            "resolved_columns": {
                "R": rmap["R_cyl_gc_kpc"]["selected"],
                "abs_Z": rmap["abs_Z_gc_kpc"]["selected"],
                "cell": rmap["healpix_nside16"]["selected"],
                "weight": rmap["balance_weight"]["selected"]
            },
            "primary_labels_ready": [
                x["label"] for x in label_rows
                if x["label"] in cfg["primary_labels"] and x["MODEL_INPUT_READY"]
            ],
            "secondary_alpha3_ready": alpha_ready,
            "next_action": (
                "Run D4B production science fits."
                if ready else
                "Inspect alias, label, or Stage4B lineage inventory; do not fit D4 science yet."
            )
        }
    )

    print(json.dumps(
        {"validation": validation, "label_inventory": label_rows},
        indent=2, ensure_ascii=False
    ))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
