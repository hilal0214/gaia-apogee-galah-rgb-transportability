from __future__ import annotations
import argparse,csv,hashlib,json,math,shutil
from datetime import datetime,timezone
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OneHotEncoder,StandardScaler

def now(): return datetime.now(timezone.utc).isoformat()
def rel(p,r):
    try:return str(p.resolve().relative_to(r.resolve())).replace("\\","/")
    except:return str(p).replace("\\","/")
def wjson(p,x):
    p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(x,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def wcsv(p,fields,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("w",newline="",encoding="utf-8") as h:
        w=csv.DictWriter(h,fieldnames=fields,extrasaction="ignore"); w.writeheader(); w.writerows(rows)
def resolve(p):
    for q in [p,p.with_suffix(".csv"),p.with_suffix(".feather")]:
        if q.exists(): return q
    return None
def read_table(p):
    if p.suffix.lower()==".parquet": return pd.read_parquet(p)
    if p.suffix.lower()==".feather": return pd.read_feather(p)
    return pd.read_csv(p)
def fold_of(source_id,k):
    d=hashlib.sha256(str(source_id).encode("utf-8")).digest()
    return int.from_bytes(d[:8],"big")%int(k)
def weighted_mean(x,w):
    x=np.asarray(x,float); w=np.asarray(w,float); ok=np.isfinite(x)&np.isfinite(w)&(w>0)
    if not np.any(ok): return np.nan
    return float(np.sum(x[ok]*w[ok])/np.sum(w[ok]))
def weighted_var(x,w):
    x=np.asarray(x,float); w=np.asarray(w,float); ok=np.isfinite(x)&np.isfinite(w)&(w>0)
    if np.sum(ok)<2:return np.nan
    x=x[ok]; w=w[ok]; m=np.sum(x*w)/np.sum(w)
    return float(np.sum(w*(x-m)**2)/np.sum(w))
def ess(w):
    w=np.asarray(w,float); w=w[np.isfinite(w)&(w>0)]
    if len(w)==0:return 0.0
    d=np.sum(w*w); return float((np.sum(w)**2)/d) if d>0 else 0.0
def smd(frame,field,weight_col,cfg):
    x=pd.to_numeric(frame[field],errors="coerce").to_numpy(float)
    w=pd.to_numeric(frame[weight_col],errors="coerce").to_numpy(float)
    a=(frame["survey"]==cfg["apogee_label"]).to_numpy(); g=(frame["survey"]==cfg["galah_label"]).to_numpy()
    ma=weighted_mean(x[a],w[a]); mg=weighted_mean(x[g],w[g]); va=weighted_var(x[a],w[a]); vg=weighted_var(x[g],w[g])
    psd=math.sqrt(.5*(va+vg)) if np.isfinite(va) and np.isfinite(vg) else np.nan
    val=(mg-ma)/psd if np.isfinite(psd) and psd>0 else np.nan
    return {"feature":field,"APOGEE_mean":ma,"GALAH_mean":mg,"pooled_sd":psd,"smd_GALAH_minus_APOGEE":val,"absolute_smd":abs(val) if np.isfinite(val) else np.nan}

def crossfit_with_cell_fixed_effects(frame,cfg):
    Xc=frame[cfg["feature_fields"]].apply(pd.to_numeric,errors="coerce").to_numpy(float)
    if not np.all(np.isfinite(Xc)): raise RuntimeError("non-finite balancing features")
    cells=frame[[cfg["cell_field"]]].astype(str).to_numpy()
    y=(frame["survey"]==cfg["galah_label"]).astype(int).to_numpy()
    folds=np.array([fold_of(x,cfg["n_folds"]) for x in frame["source_id"]],int)
    p=np.full(len(frame),np.nan); ledger=[]
    for fold in range(int(cfg["n_folds"])):
        test=folds==fold; train=~test
        if set(np.unique(y[train]).tolist())!={0,1}: raise RuntimeError(f"fold {fold} lacks both surveys")
        sc=StandardScaler(); xc_tr=sc.fit_transform(Xc[train]); xc_te=sc.transform(Xc[test])
        enc=OneHotEncoder(handle_unknown="ignore",sparse_output=True)
        ce_tr=enc.fit_transform(cells[train]); ce_te=enc.transform(cells[test])
        Xtr=sparse.hstack([sparse.csr_matrix(xc_tr),ce_tr],format="csr")
        Xte=sparse.hstack([sparse.csr_matrix(xc_te),ce_te],format="csr")
        m=LogisticRegression(C=float(cfg["ridge_C"]),solver="lbfgs",max_iter=int(cfg["logistic_max_iter"]),fit_intercept=True,random_state=0)
        m.fit(Xtr,y[train]); p[test]=m.predict_proba(Xte)[:,1]
        ledger.append({"fold":fold,"train_rows":int(train.sum()),"heldout_rows":int(test.sum()),"training_cell_levels":int(len(enc.categories_[0])),"design_columns":int(Xtr.shape[1])})
    if not np.all(np.isfinite(p)): raise RuntimeError("non-finite propensity")
    return p,folds,ledger

def raw_weights(frame,p,branch,cfg):
    gal=(frame["survey"]==cfg["galah_label"]).to_numpy()
    if branch=="LITERAL_FROZEN_JSON":
        return np.where(gal,p,1.0-p)
    if branch=="STANDARD_OVERLAP_SEMANTICS":
        return np.where(gal,1.0-p,p)
    raise ValueError(branch)

def within_survey_cap(frame,raw,cfg):
    capped=np.asarray(raw,float).copy(); caps={}
    for survey in cfg["surveys"]:
        mask=(frame["survey"]==survey).to_numpy()
        cap=float(np.quantile(raw[mask],float(cfg["weight_cap_quantile"])))
        capped[mask]=np.minimum(raw[mask],cap); caps[survey]=cap
    return capped,caps

def normalize_cell(frame,capped,branch,cfg):
    final=np.zeros(len(frame),float); ledger=[]
    for cell,idx0 in frame.groupby(cfg["cell_field"],sort=True).groups.items():
        idx=np.asarray(list(idx0),int); surveys=frame.loc[idx,"survey"].astype(str).to_numpy()
        totals={s:float(np.sum(capped[idx][surveys==s])) for s in cfg["surveys"]}
        if any(totals[s]<=0 for s in cfg["surveys"]): raise RuntimeError(f"cell {cell} non-positive total")
        target=1.0 if branch=="UNIT_TOTAL_PER_SURVEY_PER_CELL" else .5*sum(totals.values())
        factors={s:target/totals[s] for s in cfg["surveys"]}
        for s in cfg["surveys"]:
            m=surveys==s; final[idx[m]]=capped[idx][m]*factors[s]
        ledger.append({"cell":cell,"normalization_branch":branch,"APOGEE_pre_total":totals[cfg["apogee_label"]],"GALAH_pre_total":totals[cfg["galah_label"]],"target":target,"APOGEE_factor":factors[cfg["apogee_label"]],"GALAH_factor":factors[cfg["galah_label"]],"APOGEE_final_total":float(final[idx][surveys==cfg["apogee_label"]].sum()),"GALAH_final_total":float(final[idx][surveys==cfg["galah_label"]].sum())})
    return final,ledger

def evaluate(frame,weight_col,p,cfg):
    srows=[smd(frame,f,weight_col,cfg) for f in cfg["feature_fields"]]
    max_s=max([r["absolute_smd"] for r in srows if np.isfinite(r["absolute_smd"])],default=np.nan)
    ratios={}
    for s in cfg["surveys"]:
        m=frame["survey"]==s; ratios[s]=ess(frame.loc[m,weight_col].to_numpy(float))/int(m.sum())
    pmin=float(np.min(p)); pmax=float(np.max(p))
    ppass=bool(pmin>=float(cfg["propensity_lower_gate"]) and pmax<=float(cfg["propensity_upper_gate"]))
    spass=bool(np.isfinite(max_s) and max_s<=float(cfg["maximum_absolute_smd_gate"]))
    epass=all(v>=float(cfg["minimum_ess_raw_ratio_gate"]) for v in ratios.values())
    return {"propensity_min":pmin,"propensity_max":pmax,"propensity_gate_pass":ppass,"maximum_absolute_smd":max_s,"smd_gate_pass":spass,"APOGEE_ESS_raw_ratio":ratios[cfg["apogee_label"]],"GALAH_ESS_raw_ratio":ratios[cfg["galah_label"]],"ess_gate_pass":epass,"all_numeric_gates_pass":bool(ppass and spass and epass)},srows

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); args=ap.parse_args()
    root=Path(args.project_root).resolve(); cfg=json.loads((root/"config/stage6d3c4_config.json").read_text())
    out=root/cfg["output_dir"]
    if out.exists(): shutil.rmtree(out)
    for d in ["validation","tables","diagnostic","summaries","reports"]:(out/d).mkdir(parents=True,exist_ok=True)

    d3avp=root/cfg["d3a_validation"]; d3app=root/cfg["d3a_frozen_protocol"]; d3c3p=root/cfg["d3c3_validation"]
    d3av=json.loads(d3avp.read_text()) if d3avp.exists() else {}
    d3ap=json.loads(d3app.read_text()) if d3app.exists() else {}
    d3c3=json.loads(d3c3p.read_text()) if d3c3p.exists() else {}
    canonical=d3av.get("frozen_protocol_canonical_sha256")==cfg["expected_d3a_canonical_sha256"]
    prereq=bool(d3av.get("STAGE6D3A_PROTOCOL_READY",False) and d3av.get("SURVEY_BALANCE_METHOD_FROZEN",False) and d3c3.get("STAGE6D3C3_FEASIBILITY_AUDIT_READY",False) and canonical)

    sb=d3ap.get("survey_balance",{})
    audit=[
      {"contract_item":"survey_model","frozen_value":sb.get("survey_model",""),"prior_D3C_v0_20_0":"standardized continuous covariates only","reconciliation":"CELL_FIXED_EFFECTS_WERE_OMITTED"},
      {"contract_item":"weight_cap","frozen_value":sb.get("weight_cap",""),"prior_D3C_v0_20_0":"global p99 across both surveys","reconciliation":"CAP_SCOPE_WAS_NOT_FROZEN_SCOPE"},
      {"contract_item":"overlap_weights","frozen_value":json.dumps(sb.get("overlap_weights",{}),sort_keys=True),"prior_D3C_v0_20_0":"APOGEE=p(GALAH|X); GALAH=1-p(GALAH|X)","reconciliation":"FORMULA_CONFLICT_REQUIRES_SEMANTIC_AUDIT"},
      {"contract_item":"normalization","frozen_value":sb.get("normalization",""),"prior_D3C_v0_20_0":"arithmetic mean of pre-normalization survey totals","reconciliation":"COMMON_CELL_TARGET_NOT_EXPLICITLY_FROZEN"}
    ]
    wcsv(out/"tables/stage6d3c4_contract_deviation_audit.csv",["contract_item","frozen_value","prior_D3C_v0_20_0","reconciliation"],audit)

    sp=resolve(root/cfg["common_footprint_source"])
    if not sp: raise FileNotFoundError("D3B1 common footprint source missing")
    frame=read_table(sp).reset_index(drop=True)
    missing=sorted({"source_id","survey",cfg["cell_field"],*cfg["feature_fields"]}-set(frame.columns))
    if missing: raise RuntimeError(f"missing fields {missing}")

    p,folds,fold_rows=crossfit_with_cell_fixed_effects(frame,cfg)
    wcsv(out/"diagnostic/stage6d3c4_crossfit_fold_ledger.csv",["fold","train_rows","heldout_rows","training_cell_levels","design_columns"],fold_rows)

    matrix=[]; all_smd=[]; all_cells=[]; payload={}
    for wf in cfg["weight_formula_branches"]:
        raw=raw_weights(frame,p,wf,cfg); capped,caps=within_survey_cap(frame,raw,cfg)
        for nb in cfg["normalization_branches"]:
            weights,cells=normalize_cell(frame,capped,nb,cfg)
            work=frame.copy(); work["audit_weight"]=weights
            met,srows=evaluate(work,"audit_weight",p,cfg)
            key=f"{wf}__{nb}"
            matrix.append({"branch":key,"weight_formula_branch":wf,"normalization_branch":nb,"APOGEE_p99_cap":caps[cfg["apogee_label"]],"GALAH_p99_cap":caps[cfg["galah_label"]],**met})
            all_smd.extend([{"branch":key,**r} for r in srows])
            all_cells.extend([{"branch":key,**r} for r in cells])
            payload[key]=met

    wcsv(out/"diagnostic/stage6d3c4_implementation_matrix.csv",["branch","weight_formula_branch","normalization_branch","APOGEE_p99_cap","GALAH_p99_cap","propensity_min","propensity_max","propensity_gate_pass","maximum_absolute_smd","smd_gate_pass","APOGEE_ESS_raw_ratio","GALAH_ESS_raw_ratio","ess_gate_pass","all_numeric_gates_pass"],matrix)
    wcsv(out/"diagnostic/stage6d3c4_branch_smd.csv",["branch","feature","APOGEE_mean","GALAH_mean","pooled_sd","smd_GALAH_minus_APOGEE","absolute_smd"],all_smd)
    wcsv(out/"diagnostic/stage6d3c4_cell_normalization_ledger.csv",["branch","cell","normalization_branch","APOGEE_pre_total","GALAH_pre_total","target","APOGEE_factor","GALAH_factor","APOGEE_final_total","GALAH_final_total"],all_cells)

    lu=payload["LITERAL_FROZEN_JSON__UNIT_TOTAL_PER_SURVEY_PER_CELL"]
    su=payload["STANDARD_OVERLAP_SEMANTICS__UNIT_TOTAL_PER_SURVEY_PER_CELL"]
    la=payload["LITERAL_FROZEN_JSON__PRIOR_ARITHMETIC_MEAN_TARGET"]
    sa=payload["STANDARD_OVERLAP_SEMANTICS__PRIOR_ARITHMETIC_MEAN_TARGET"]

    if lu["all_numeric_gates_pass"]:
        cls="LITERAL_FROZEN_JSON_PLUS_LITERAL_NORMALIZATION_NUMERICALLY_VALID"
    elif su["all_numeric_gates_pass"]:
        cls="STANDARD_OVERLAP_SEMANTICS_VALID_BUT_FROZEN_WEIGHT_FORMULA_CONFLICTS"
    elif sa["all_numeric_gates_pass"]:
        cls="PRIOR_CELL_TARGET_REQUIRED_BUT_WEIGHT_FORMULA_SEMANTICS_CONFLICT"
    elif la["all_numeric_gates_pass"]:
        cls="LITERAL_WEIGHT_FORMULA_VALID_ONLY_WITH_UNFROZEN_CELL_TARGET_CHOICE"
    elif not lu["propensity_gate_pass"]:
        cls="PROPENSITY_GATE_FAILS_AFTER_RESTORING_CELL_FIXED_EFFECTS"
    else:
        cls="NO_BRANCH_PASSES_AFTER_FROZEN_IMPLEMENTATION_RECONCILIATION"

    anypass=any(r["all_numeric_gates_pass"] for r in matrix)
    validation={"stage":cfg["stage"],"protocol_version":cfg["protocol_version"],"implementation_version":cfg["implementation_version"],"timestamp_utc":now(),"classification":cls,"input_rows":len(frame),"cell_count":int(frame[cfg["cell_field"]].nunique()),"d3a_canonical_sha256_ready":canonical,"propensity_model":"standardized non-outcome covariates + HEALPix cell fixed effects","ridge_C_for_reconciliation":cfg["ridge_C"],"numeric_passing_branch_count":sum(bool(r["all_numeric_gates_pass"]) for r in matrix),"STAGE6D3A_D3C3_PREREQUISITES_READY":prereq,"CELL_FIXED_EFFECTS_RESTORED":True,"P99_CAP_WITHIN_SURVEY_RESTORED":True,"FROZEN_AND_STANDARD_WEIGHT_FORMULAS_BOTH_AUDITED":True,"CELL_NORMALIZATION_TARGET_AMBIGUITY_AUDITED":True,"NO_FROZEN_THRESHOLD_WEAKENED":True,"NO_OUTCOME_ABUNDANCE_R_ABSZ_USED":True,"ANY_NUMERIC_BRANCH_PASSES":anypass,"FORMAL_PROTOCOL_RECONCILIATION_STILL_REQUIRED":True,"PRODUCTION_BALANCED_WEIGHTS_READY":False,"STAGE6D3C4_RECONCILIATION_READY":prereq,"STAGE6D4_SCIENCE_MODELS_READY":False}
    wjson(out/"validation/stage6d3c4_validation.json",validation)

    if cls=="LITERAL_FROZEN_JSON_PLUS_LITERAL_NORMALIZATION_NUMERICALLY_VALID":
        nxt="Literal frozen JSON passes once omitted cell fixed effects and within-survey p99 are restored. Freeze the literal unit-normalization interpretation before production."
    elif cls=="STANDARD_OVERLAP_SEMANTICS_VALID_BUT_FROZEN_WEIGHT_FORMULA_CONFLICTS":
        nxt="Standard overlap semantics pass while the literal frozen formula does not. The protocol has a semantic formula contradiction; amend/freeze explicitly before production."
    elif cls=="PROPENSITY_GATE_FAILS_AFTER_RESTORING_CELL_FIXED_EFFECTS":
        nxt="Corrected frozen survey model still fails propensity at C=1.0. Since C was not explicitly frozen, only a prespecified cell-fixed-effect C-path audit is justified next."
    else:
        nxt="Inspect the implementation matrix. No production branch is authorized; D4 remains blocked."

    summary={"classification":cls,"literal_frozen_unit":lu,"standard_overlap_unit":su,"literal_frozen_prior_arithmetic":la,"standard_overlap_prior_arithmetic":sa,"next_action":nxt,"scientific_disposition":"Prior D3C/D3C3 infeasibility results are implementation-conditional, not a final test of Stage-6D3A, because cell fixed effects and within-survey p99 were not implemented as frozen."}
    wjson(out/"summaries/stage6d3c4_summary.json",summary)
    (out/"reports/stage6d3c4_report.md").write_text("\n".join(["# Stage-6D3C4 frozen-contract implementation reconciliation","",f"- Classification: `{cls}`",f"- Input rows: `{len(frame)}`",f"- Cells: `{frame[cfg['cell_field']].nunique()}`",f"- Numeric passing branches: `{validation['numeric_passing_branch_count']}`","- Cell fixed effects restored: `True`","- p99 cap within survey restored: `True`","- Production weights authorized: `False`","- Stage-6D4 authorized: `False`","",nxt,""]),encoding="utf-8")
    print(json.dumps({"validation":validation,"summary":summary},indent=2))
    return 0

if __name__=="__main__": raise SystemExit(main())
