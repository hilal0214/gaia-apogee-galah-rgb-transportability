from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import math
import re
import shutil
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8"
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_columns(path: Path) -> tuple[list[str], int]:
    if path.suffix.lower() == ".parquet":
        import pyarrow.parquet as pq
        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def read_table(path: Path, columns: list[str] | None = None) -> pd.DataFrame:
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path, columns=columns)
    return pd.read_csv(path, usecols=columns)


def find_alias(columns: list[str], options: list[str]) -> str | None:
    lookup = {column.lower(): column for column in columns}
    for option in options:
        if option.lower() in lookup:
            return lookup[option.lower()]
    return None


def normalize_token(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def find_label_column(
    columns: list[str],
    label: str,
    variants: dict[str, list[str]]
) -> str | None:
    lookup = {normalize_token(column): column for column in columns}
    candidates = variants[label]
    for candidate in candidates:
        token = normalize_token(candidate)
        if token in lookup:
            return lookup[token]

    # Restricted suffix/prefix matching for production variants.
    approved_suffixes = {
        "corrected", "calibrated", "transported", "transport",
        "final", "common", "harmonized", "primary", "value"
    }
    base_tokens = {normalize_token(value) for value in candidates[:2]}
    for normalized, original in lookup.items():
        for base in base_tokens:
            if normalized.startswith(base + "_"):
                suffix = normalized[len(base) + 1 :]
                if suffix in approved_suffixes:
                    return original
            if normalized.endswith("_" + base):
                prefix = normalized[: -(len(base) + 1)]
                if prefix in {"corrected", "calibrated", "final", "common"}:
                    return original
    return None


def profile(path: Path, cfg: dict[str, Any]) -> dict[str, Any]:
    columns, rows = read_columns(path)
    mapping = {
        field: find_alias(columns, aliases)
        for field, aliases in cfg["aliases"].items()
    }
    label_mapping = {
        label: find_label_column(
            columns, label, cfg["label_variants"]
        )
        for label in cfg["labels"]
    }
    return {
        "columns": columns,
        "rows": rows,
        "mapping": mapping,
        "label_mapping": label_mapping,
        "labels": [
            label for label, column in label_mapping.items()
            if column is not None
        ]
    }


def normalize_survey(
    series: pd.Series,
    cfg: dict[str, Any]
) -> pd.Series:
    output = pd.Series(pd.NA, index=series.index, dtype="string")
    lower = series.astype("string").str.lower()
    for canonical, tokens in cfg["survey_normalization"].items():
        mask = pd.Series(False, index=series.index)
        for token in tokens:
            mask |= lower.str.contains(
                token.lower(), na=False, regex=False
            )
        output.loc[mask] = canonical
    return output


def extract_existing_paths_from_text(
    text: str,
    root: Path
) -> list[Path]:
    patterns = [
        r'(?P<path>[A-Za-z]:[\\/][^"\']+\.(?:csv|parquet))',
        r'(?P<path>(?:outputs|data)[\\/][^"\']+\.(?:csv|parquet))',
    ]
    found: list[Path] = []
    for pattern in patterns:
        for match in re.finditer(pattern, text, flags=re.IGNORECASE):
            raw = match.group("path").strip()
            path = Path(raw)
            if not path.is_absolute():
                path = root / raw
            if path.exists():
                found.append(path.resolve())
    return found


def collect_lineage_evidence(
    root: Path,
    cfg: dict[str, Any]
) -> tuple[set[Path], list[dict[str, Any]]]:
    evidence_paths: set[Path] = set()
    rows: list[dict[str, Any]] = []

    source_files = [
        root / cfg["stage4b_script"],
        root / cfg["stage4b_config"],
        root / cfg["prior_stage6d3a2_stderr"],
    ]
    for rel_root in cfg["evidence_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if path.is_file() and path.suffix.lower() in {
                ".json", ".csv", ".md", ".txt", ".yml", ".yaml"
            }:
                source_files.append(path)

    seen_sources = set()
    for source in source_files:
        if not source.exists() or source.resolve() in seen_sources:
            continue
        seen_sources.add(source.resolve())
        try:
            text = source.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        for target in extract_existing_paths_from_text(text, root):
            evidence_paths.add(target)
            rows.append({
                "evidence_source": safe_rel(source, root),
                "target_path": safe_rel(target, root),
                "target_exists": "true",
                "target_sha256": sha256_file(target),
            })

    return evidence_paths, rows


def diagnose_prior_failure(
    root: Path,
    cfg: dict[str, Any]
) -> dict[str, Any]:
    stderr_path = root / cfg["prior_stage6d3a2_stderr"]
    text = (
        stderr_path.read_text(encoding="utf-8", errors="replace")
        if stderr_path.exists() else ""
    )
    lower = text.lower()
    category = "stderr_unavailable"
    if text:
        category = "unclassified_pre_io_failure"
        if "modulenotfounderror" in lower or "no module named" in lower:
            category = "module_import_failure"
        elif "unrecognized arguments" in lower:
            category = "cli_contract_failure"
        elif "required" in lower and "--" in lower:
            category = "missing_cli_argument"
        elif "filenotfounderror" in lower:
            category = "pre_io_path_failure"
        elif "traceback" in lower:
            category = "python_exception_before_traced_pandas_io"

    return {
        "stderr_path": safe_rel(stderr_path, root),
        "stderr_exists": stderr_path.exists(),
        "stderr_sha256": (
            sha256_file(stderr_path) if stderr_path.exists() else ""
        ),
        "stderr_bytes": len(text.encode("utf-8")),
        "failure_category": category,
        "stderr_tail": "\n".join(text.splitlines()[-40:]),
    }


def canonical_frame(
    path: Path,
    item: dict[str, Any],
    fields: list[str],
    labels: list[str]
) -> pd.DataFrame:
    mapping = item["mapping"]
    label_mapping = item["label_mapping"]

    needed = [
        mapping[field] for field in fields
        if mapping.get(field)
    ]
    needed += [
        label_mapping[label] for label in labels
        if label_mapping.get(label)
    ]
    needed = sorted(set(needed))
    frame = read_table(path, needed).copy()

    for field in fields:
        source = mapping.get(field)
        if source:
            frame[field] = frame[source]
    for label in labels:
        source = label_mapping.get(label)
        if source:
            frame[label] = pd.to_numeric(
                frame[source], errors="coerce"
            )
    return frame


def collapse_frame(
    frame: pd.DataFrame,
    has_survey_key: bool
) -> tuple[pd.DataFrame, int, list[str]]:
    work = frame.copy()
    work["source_id"] = pd.to_numeric(
        work["source_id"], errors="coerce"
    )
    work = work[work["source_id"].notna()].copy()
    work["source_id"] = work["source_id"].astype("uint64")

    keys = ["source_id"]
    if has_survey_key and "survey" in work.columns:
        keys.append("survey")

    duplicates = int(work.duplicated(keys).sum())
    if duplicates:
        value_columns = [
            column for column in work.columns
            if column not in keys
        ]
        aggregation = {
            column: "first" for column in value_columns
        }
        work = work.groupby(keys, as_index=False).agg(aggregation)
    return work, duplicates, keys


def coalesce(
    base: pd.DataFrame,
    addition: pd.DataFrame,
    fields: list[str],
    join_keys: list[str]
) -> tuple[pd.DataFrame, dict[str, int]]:
    candidate_fields = [
        field for field in fields
        if field not in join_keys and field in addition.columns
    ]
    before = {
        field: (
            int(base[field].notna().sum())
            if field in base.columns else 0
        )
        for field in fields
    }
    joined = base.merge(
        addition[join_keys + candidate_fields],
        on=join_keys,
        how="left",
        suffixes=("", "__candidate"),
        validate="many_to_one" if join_keys == ["source_id"] else "one_to_one",
    )
    for field in candidate_fields:
        candidate = field + "__candidate"
        if field not in joined.columns:
            joined[field] = joined[candidate]
        else:
            joined[field] = joined[field].where(
                joined[field].notna(),
                joined[candidate],
            )
        joined.drop(columns=[candidate], inplace=True)
    after = {
        field: (
            int(joined[field].notna().sum())
            if field in joined.columns else 0
        )
        for field in fields
    }
    gains = {
        field: after[field] - before[field]
        for field in fields
    }
    return joined, gains


def complete_mask(
    frame: pd.DataFrame,
    cfg: dict[str, Any]
) -> pd.Series:
    required = [
        field for field in cfg["required_fields"]
        if field != "source_id"
    ] + cfg["labels"]
    mask = pd.Series(True, index=frame.index)
    for field in required:
        if field not in frame.columns:
            return pd.Series(False, index=frame.index)
        mask &= frame[field].notna()
    return mask


def interaction_schema(
    path: Path,
    cfg: dict[str, Any]
) -> tuple[bool, dict[str, Any]]:
    path_text = safe_rel(path, path.parent).lower()
    if any(
        token in path_text
        for token in cfg["interaction_excluded_tokens"]
    ):
        return False, {"reason": "excluded_path_token"}

    columns, rows = read_columns(path)
    label_column = find_alias(
        columns, cfg["aliases"]["label"]
    )
    wide = [
        column for column in columns
        if any(
            token in column.lower()
            for token in cfg["interaction_tokens"]
        )
    ]
    term_column = find_alias(
        columns, cfg["aliases"]["term"]
    )
    estimate_column = find_alias(
        columns, cfg["aliases"]["estimate"]
    )
    long_terms: list[str] = []
    if label_column and term_column and estimate_column:
        try:
            values = read_table(
                path, [term_column]
            )[term_column]
            for value in sorted(set(values.dropna().astype(str))):
                lower = value.lower()
                if (
                    ("survey" in lower or "apogee" in lower or "galah" in lower)
                    and (
                        "beta_r" in lower or "beta_z" in lower
                        or "radial" in lower or "vertical" in lower
                    )
                ):
                    long_terms.append(value)
        except Exception:
            pass

    ready = bool(label_column and (wide or long_terms))
    return ready, {
        "row_count": rows,
        "columns": columns,
        "label_column": label_column,
        "wide_interaction_columns": wide,
        "term_column": term_column,
        "estimate_column": estimate_column,
        "long_interaction_terms": long_terms,
        "reason": "" if ready else "science_interaction_schema_not_found",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2a_config.json").read_text(
            encoding="utf-8"
        )
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables",
        "assembled", "reports", "diagnostics"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    stage6d3a_path = root / cfg["prerequisite_stage6d3a"]
    stage6d3a = (
        json.loads(stage6d3a_path.read_text(encoding="utf-8"))
        if stage6d3a_path.exists() else {}
    )
    protocol_ready = bool(
        stage6d3a.get("STAGE6D3A_PROTOCOL_READY", False)
        and stage6d3a.get("PROTOCOL_SEMANTIC_IDENTITY_READY", False)
        and stage6d3a.get("FROZEN_FULL_SUPPORT_GRADIENTS_READY", False)
        and stage6d3a.get("FROZEN_FULL_SUPPORT_BOOTSTRAP_READY", False)
    )

    prior_validation_path = root / cfg["prior_stage6d3a2_validation"]
    prior_validation = (
        json.loads(prior_validation_path.read_text(encoding="utf-8"))
        if prior_validation_path.exists() else {}
    )
    prior_failure = diagnose_prior_failure(root, cfg)
    write_json(
        out / "diagnostics/stage6d3a2_prior_failure.json",
        prior_failure
    )

    evidence_paths, evidence_rows = collect_lineage_evidence(
        root, cfg
    )
    write_csv(
        out / "tables/stage6d3a2a_lineage_path_evidence.csv",
        [
            "evidence_source", "target_path",
            "target_exists", "target_sha256"
        ],
        evidence_rows
    )

    candidates: list[dict[str, Any]] = []
    suffixes = set(cfg["suffixes"])
    for rel_root in cfg["scan_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in suffixes:
                continue
            try:
                item = profile(path, cfg)
                mapping = item["mapping"]
                covered_fields = [
                    field for field in cfg["required_fields"]
                    if mapping.get(field)
                ]
                covered_labels = item["labels"]
                evidence = path.resolve() in evidence_paths
                path_text = safe_rel(path, root).lower()
                row_count_gate = (
                    item["rows"] == -1
                    or item["rows"] >= cfg["minimum_anchor_rows"]
                )
                anchor_ready = bool(
                    mapping.get("source_id")
                    and mapping.get("survey")
                    and mapping.get("R")
                    and mapping.get("Z")
                    and row_count_gate
                )
                anchor_score = (
                    1000 * int(anchor_ready)
                    + 500 * int(evidence)
                    + 150 * int("stage4a" in path_text)
                    + 100 * int("production" in path_text)
                    + 50 * len(covered_labels)
                    + 10 * len(covered_fields)
                    + max(item["rows"], 0) / 1_000_000
                )
                candidates.append({
                    "path": path,
                    "profile": item,
                    "covered_fields": covered_fields,
                    "covered_labels": covered_labels,
                    "lineage_evidence": evidence,
                    "anchor_ready": anchor_ready,
                    "anchor_score": anchor_score,
                    "read_error": "",
                })
            except Exception as exc:
                candidates.append({
                    "path": path,
                    "profile": {
                        "columns": [],
                        "rows": "",
                        "mapping": {},
                        "label_mapping": {},
                        "labels": [],
                    },
                    "covered_fields": [],
                    "covered_labels": [],
                    "lineage_evidence": False,
                    "anchor_ready": False,
                    "anchor_score": -1,
                    "read_error": f"{type(exc).__name__}: {exc}",
                })

    inventory_rows = []
    for row in candidates:
        item = row["profile"]
        inventory_rows.append({
            "path": safe_rel(row["path"], root),
            "row_count": item["rows"],
            "column_count": len(item["columns"]),
            "columns": "|".join(item["columns"]),
            "lineage_evidence": str(row["lineage_evidence"]).lower(),
            "anchor_ready": str(row["anchor_ready"]).lower(),
            "anchor_score": row["anchor_score"],
            "covered_fields": "|".join(row["covered_fields"]),
            "covered_labels": "|".join(row["covered_labels"]),
            "mapping": json.dumps(item["mapping"], sort_keys=True),
            "label_mapping": json.dumps(
                item["label_mapping"], sort_keys=True
            ),
            "read_error": row["read_error"],
        })
    inventory_rows.sort(
        key=lambda row: (-float(row["anchor_score"]), row["path"])
    )
    write_csv(
        out / "tables/stage6d3a2a_source_schema_inventory.csv",
        [
            "path", "row_count", "column_count", "columns",
            "lineage_evidence", "anchor_ready", "anchor_score",
            "covered_fields", "covered_labels",
            "mapping", "label_mapping", "read_error"
        ],
        inventory_rows
    )

    anchor_candidates = [
        row for row in candidates if row["anchor_ready"]
    ]
    anchor_candidates.sort(
        key=lambda row: (-row["anchor_score"], str(row["path"]))
    )
    anchor = anchor_candidates[0] if anchor_candidates else None

    assembled = pd.DataFrame()
    selected_bundle: list[dict[str, Any]] = []
    greedy_rows: list[dict[str, Any]] = []
    assembly_error = ""
    complete_counts = {
        "APOGEE_NATIVE": 0,
        "GALAH_CORRECTED": 0,
    }
    assembled_path: Path | None = None

    if anchor is not None:
        try:
            anchor_frame = canonical_frame(
                anchor["path"],
                anchor["profile"],
                cfg["required_fields"],
                cfg["labels"],
            )
            if "survey" not in anchor_frame.columns:
                raise RuntimeError(
                    "Selected anchor lacks a canonical survey column."
                )
            anchor_frame["survey"] = normalize_survey(
                anchor_frame["survey"], cfg
            )
            anchor_frame, duplicates, anchor_keys = collapse_frame(
                anchor_frame, has_survey_key=True
            )
            assembled = anchor_frame
            for field in cfg["required_fields"] + cfg["labels"]:
                if field not in assembled.columns:
                    assembled[field] = pd.NA

            selected_bundle.append({
                "role": "outcome_blind_gradient_anchor",
                "path": anchor["path"],
                "join_keys": anchor_keys,
                "covered_fields": anchor["covered_fields"],
                "covered_labels": anchor["covered_labels"],
                "duplicate_keys": duplicates,
                "lineage_evidence": anchor["lineage_evidence"],
                "overlap_fraction": 1.0,
            })

            anchor_ids = set(
                assembled["source_id"].astype("uint64").tolist()
            )
            pool: list[dict[str, Any]] = []
            for candidate in candidates:
                if (
                    candidate is anchor
                    or not candidate["profile"]["mapping"].get("source_id")
                ):
                    continue
                available = set(candidate["covered_fields"]).union(
                    candidate["covered_labels"]
                )
                if len(available - {"source_id"}) == 0:
                    continue
                try:
                    frame = canonical_frame(
                        candidate["path"],
                        candidate["profile"],
                        cfg["required_fields"],
                        cfg["labels"],
                    )
                    has_survey = (
                        "survey" in frame.columns
                        and frame["survey"].notna().any()
                    )
                    if has_survey:
                        frame["survey"] = normalize_survey(
                            frame["survey"], cfg
                        )
                    frame, duplicate_keys, join_keys = collapse_frame(
                        frame, has_survey_key=has_survey
                    )
                    overlap_fraction = (
                        len(
                            anchor_ids.intersection(
                                set(frame["source_id"].tolist())
                            )
                        )
                        / max(len(anchor_ids), 1)
                    )
                    if overlap_fraction < cfg[
                        "minimum_anchor_overlap_fraction"
                    ]:
                        continue
                    pool.append({
                        "candidate": candidate,
                        "frame": frame,
                        "join_keys": join_keys,
                        "duplicate_keys": duplicate_keys,
                        "overlap_fraction": overlap_fraction,
                    })
                except Exception:
                    continue

            used_paths: set[Path] = set()
            all_fields = cfg["required_fields"] + cfg["labels"]
            for _ in range(cfg["maximum_enrichment_files"]):
                current_complete = int(
                    complete_mask(assembled, cfg).sum()
                )
                best = None
                for item in pool:
                    path = item["candidate"]["path"].resolve()
                    if path in used_paths:
                        continue
                    try:
                        trial, gains = coalesce(
                            assembled,
                            item["frame"],
                            all_fields,
                            item["join_keys"],
                        )
                    except Exception:
                        continue
                    after_complete = int(
                        complete_mask(trial, cfg).sum()
                    )
                    complete_gain = after_complete - current_complete
                    total_gain = sum(
                        max(int(value), 0)
                        for value in gains.values()
                    )
                    candidate = item["candidate"]
                    score = (
                        10000 * complete_gain
                        + total_gain
                        + 500 * int(candidate["lineage_evidence"])
                        + 100 * int(
                            "stage4a" in safe_rel(
                                candidate["path"], root
                            ).lower()
                        )
                        + int(100 * item["overlap_fraction"])
                    )
                    if (
                        (complete_gain > 0 or total_gain > 0)
                        and (best is None or score > best["score"])
                    ):
                        best = {
                            "item": item,
                            "trial": trial,
                            "gains": gains,
                            "complete_gain": complete_gain,
                            "score": score,
                        }
                if best is None:
                    break

                item = best["item"]
                candidate = item["candidate"]
                assembled = best["trial"]
                used_paths.add(candidate["path"].resolve())
                selected_bundle.append({
                    "role": "source_id_enrichment",
                    "path": candidate["path"],
                    "join_keys": item["join_keys"],
                    "covered_fields": candidate["covered_fields"],
                    "covered_labels": candidate["covered_labels"],
                    "duplicate_keys": item["duplicate_keys"],
                    "lineage_evidence": candidate["lineage_evidence"],
                    "overlap_fraction": item["overlap_fraction"],
                })
                greedy_rows.append({
                    "path": safe_rel(candidate["path"], root),
                    "score": best["score"],
                    "join_keys": "|".join(item["join_keys"]),
                    "complete_row_gain": best["complete_gain"],
                    "anchor_overlap_fraction": item["overlap_fraction"],
                    "field_gains": json.dumps(
                        best["gains"], sort_keys=True
                    ),
                })

            complete = complete_mask(assembled, cfg)
            for survey in complete_counts:
                complete_counts[survey] = int(
                    (
                        complete
                        & (assembled["survey"] == survey)
                    ).sum()
                )

            assembled_path = (
                out
                / "assembled/stage6d3a2a_production_source_assembled.parquet"
            )
            try:
                assembled.to_parquet(assembled_path, index=False)
            except Exception:
                assembled_path = (
                    out
                    / "assembled/stage6d3a2a_production_source_assembled.csv"
                )
                assembled.to_csv(assembled_path, index=False)
        except Exception as exc:
            assembly_error = (
                f"{type(exc).__name__}: {exc}\n"
                + traceback.format_exc()
            )
    else:
        assembly_error = (
            "No candidate file contains source ID, survey, R, and Z "
            f"with at least {cfg['minimum_anchor_rows']} rows."
        )

    write_csv(
        out / "tables/stage6d3a2a_greedy_enrichment_audit.csv",
        [
            "path", "score", "join_keys", "complete_row_gain",
            "anchor_overlap_fraction", "field_gains"
        ],
        greedy_rows
    )
    write_csv(
        out / "tables/stage6d3a2a_selected_source_bundle.csv",
        [
            "bundle_order", "role", "path", "join_keys",
            "covered_fields", "covered_labels",
            "duplicate_keys", "lineage_evidence",
            "anchor_overlap_fraction"
        ],
        [
            {
                "bundle_order": index + 1,
                "role": row["role"],
                "path": safe_rel(row["path"], root),
                "join_keys": "|".join(row["join_keys"]),
                "covered_fields": "|".join(row["covered_fields"]),
                "covered_labels": "|".join(row["covered_labels"]),
                "duplicate_keys": row["duplicate_keys"],
                "lineage_evidence": str(
                    row["lineage_evidence"]
                ).lower(),
                "anchor_overlap_fraction": row["overlap_fraction"],
            }
            for index, row in enumerate(selected_bundle)
        ]
    )

    coverage_rows = []
    if not assembled.empty:
        for field in cfg["required_fields"] + cfg["labels"]:
            coverage_rows.append({
                "field": field,
                "non_null_rows": (
                    int(assembled[field].notna().sum())
                    if field in assembled.columns else 0
                ),
                "coverage_fraction": (
                    float(assembled[field].notna().mean())
                    if field in assembled.columns else 0.0
                ),
            })
    write_csv(
        out / "tables/stage6d3a2a_assembled_field_coverage.csv",
        ["field", "non_null_rows", "coverage_fraction"],
        coverage_rows
    )

    interaction_candidates: list[dict[str, Any]] = []
    stage4b_dir = root / "outputs/stage4b"
    for name in cfg["interaction_preferred_names"]:
        path = stage4b_dir / name
        if not path.exists():
            continue
        ready, schema = interaction_schema(path, cfg)
        interaction_candidates.append({
            "path": path,
            "ready": ready,
            "schema": schema,
            "preferred_name": True,
        })
    write_csv(
        out / "tables/stage6d3a2a_interaction_context_audit.csv",
        [
            "path", "ready", "preferred_name",
            "label_column", "wide_interaction_columns",
            "long_interaction_terms", "reason"
        ],
        [
            {
                "path": safe_rel(row["path"], root),
                "ready": str(row["ready"]).lower(),
                "preferred_name": str(
                    row["preferred_name"]
                ).lower(),
                "label_column": row["schema"].get(
                    "label_column", ""
                ),
                "wide_interaction_columns": "|".join(
                    row["schema"].get(
                        "wide_interaction_columns", []
                    )
                ),
                "long_interaction_terms": "|".join(
                    row["schema"].get(
                        "long_interaction_terms", []
                    )
                ),
                "reason": row["schema"].get("reason", ""),
            }
            for row in interaction_candidates
        ]
    )
    interaction = next(
        (
            row for row in interaction_candidates
            if row["ready"]
        ),
        None,
    )
    interaction_context_ready = interaction is not None

    source_ready = bool(
        not assembly_error
        and assembled_path is not None
        and all(
            complete_counts[survey]
            >= cfg["minimum_complete_rows_per_survey"]
            for survey in complete_counts
        )
    )

    remaining = []
    if not protocol_ready:
        remaining.append({
            "gate": "STAGE6D3A_BASELINE_PROTOCOL_READY",
            "required_action": (
                "Restore PASS Stage-6D3A protocol, frozen full-support "
                "gradients, and bootstrap products."
            ),
        })
    if anchor is None:
        remaining.append({
            "gate": "OUTCOME_BLIND_GRADIENT_ANCHOR_READY",
            "required_action": assembly_error,
        })
    elif assembly_error:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_ASSEMBLY_READY",
            "required_action": assembly_error,
        })
    elif not source_ready:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_COMPLETE_ROWS_READY",
            "required_action": (
                f"Need at least {cfg['minimum_complete_rows_per_survey']} "
                "complete rows per survey. Observed: "
                + json.dumps(complete_counts, sort_keys=True)
            ),
        })

    if not interaction_context_ready:
        remaining.append({
            "gate": "EXISTING_INTERACTION_CONTEXT_READY",
            "required_action": (
                "Optional context table was not found or did not satisfy "
                "the science schema. This does not block Stage-6D3B because "
                "Stage-6D4 refits the balanced-footprint interaction model."
            ),
        })
    write_csv(
        out / "tables/stage6d3a2a_remaining_items.csv",
        ["gate", "required_action"],
        remaining
    )

    d3b_ready = bool(protocol_ready and source_ready)
    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "prior_stage6d3a2_returncode": prior_validation.get(
            "execution_returncode"
        ),
        "prior_trace_event_count": prior_validation.get(
            "trace_event_count"
        ),
        "prior_failure_category": prior_failure["failure_category"],
        "prior_stderr_path": prior_failure["stderr_path"],
        "lineage_evidence_target_count": len(evidence_paths),
        "candidate_file_count": len(candidates),
        "selected_anchor": (
            safe_rel(anchor["path"], root) if anchor else ""
        ),
        "selected_source_bundle": [
            safe_rel(row["path"], root)
            for row in selected_bundle
        ],
        "assembled_source_table": (
            safe_rel(assembled_path, root)
            if assembled_path else ""
        ),
        "assembled_rows": len(assembled),
        "complete_rows_by_survey": complete_counts,
        "selected_interaction_context": (
            safe_rel(interaction["path"], root)
            if interaction else ""
        ),
        "assembly_error": assembly_error,
        "prior_stage_outputs_modified": False,
        "STAGE6D3A_BASELINE_PROTOCOL_READY": protocol_ready,
        "PRIOR_ZERO_TRACE_FAILURE_CLASSIFIED": bool(
            prior_failure["failure_category"]
        ),
        "STATIC_PROVENANCE_LINEAGE_READY": bool(evidence_rows),
        "OUTCOME_BLIND_GRADIENT_ANCHOR_READY": anchor is not None,
        "SURVEY_AWARE_SOURCE_ID_JOIN_READY": bool(selected_bundle),
        "PRODUCTION_SOURCE_ASSEMBLY_READY": source_ready,
        "CLAIM_LEDGER_EXCLUDED_FROM_INTERACTION_ROLE": True,
        "EXISTING_INTERACTION_CONTEXT_READY": interaction_context_ready,
        "INTERACTION_CONTEXT_REQUIRED_FOR_D3B": False,
        "STAGE6D3A2A_RECOVERY_READY": bool(
            protocol_ready and anchor is not None
        ),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": d3b_ready,
    }
    write_json(
        out / "validation/stage6d3a2a_validation.json",
        validation
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "prior_failure": prior_failure,
        "source_assembly": {
            "anchor": validation["selected_anchor"],
            "bundle": validation["selected_source_bundle"],
            "assembled_rows": len(assembled),
            "complete_rows_by_survey": complete_counts,
            "ready": source_ready,
        },
        "interaction_context": {
            "path": validation["selected_interaction_context"],
            "ready": interaction_context_ready,
            "required_for_d3b": False,
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "The frozen production-source assembly is complete. "
            "Stage-6D3B common-footprint construction is authorized; "
            "the existing interaction table is contextual only."
            if d3b_ready else
            "Trace failure is classified and static provenance recovery "
            "is complete, but source assembly remains blocked by the "
            "listed exact-data gap."
        ),
    }
    write_json(
        out / "summaries/stage6d3a2a_summary.json",
        summary
    )

    report = [
        "# Stage-6D3A2A trace-bootstrap recovery and source assembly",
        "",
        f"- Prior trace failure: `{prior_failure['failure_category']}`",
        f"- Provenance target paths: `{len(evidence_paths)}`",
        f"- Candidate files: `{len(candidates)}`",
        f"- Selected anchor: `{validation['selected_anchor'] or 'not found'}`",
        f"- Source bundle files: `{len(selected_bundle)}`",
        f"- Assembled rows: `{len(assembled)}`",
        f"- Complete APOGEE rows: `{complete_counts['APOGEE_NATIVE']}`",
        f"- Complete GALAH rows: `{complete_counts['GALAH_CORRECTED']}`",
        f"- Existing interaction context: `{validation['selected_interaction_context'] or 'not found'}`",
        f"- Interaction required for D3B: `False`",
        f"- Stage-6D3B ready: `{d3b_ready}`",
        "",
        "The assembly uses only frozen schema/provenance evidence and "
        "Gaia source-ID joins. Target abundance is never used as a "
        "matching or weighting variable.",
        "",
        "No common-footprint, propensity, gradient, or bootstrap fit is run.",
        "",
    ]
    (
        out
        / "reports/stage6d3a2a_trace_bootstrap_source_assembly.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
