from __future__ import annotations
import argparse, hashlib, json, sys, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd

# Reuse the already-tested Stage-8B2A synthetic engine only.
import stage8b2a_synthetic_morphology_power_pilot as eng

def now(): return datetime.now(timezone.utc).isoformat()

def canon(o):
    return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def task_key(t):
    kind,effect,delta,sign,rep=t
    return f"{kind}__{effect}__d{float(delta):.3f}__s{int(sign):+d}__r{int(rep):04d}".replace("+","p").replace("-","m")

def as_bool(s):
    if pd.api.types.is_bool_dtype(s.dtype):
        return s.to_numpy(bool)
    return s.astype(str).str.strip().str.lower().isin(["true","1","yes","y"]).to_numpy(bool)

def load_support(root,C):
    cc=C["columns"]
    cols=[cc[x] for x in ["source_id","survey","R","absZ","fe_h","alpha3","alpha3_flag","feh_flag","cell","weight"]]
    df=pd.read_parquet(root/C["source"],columns=cols)
    if pd.api.types.is_float_dtype(df[cc["source_id"]].dtype):
        raise RuntimeError("source_id float coercion forbidden")
    R=pd.to_numeric(df[cc["R"]],errors="coerce").to_numpy(float)
    Z=pd.to_numeric(df[cc["absZ"]],errors="coerce").to_numpy(float)
    feh=pd.to_numeric(df[cc["fe_h"]],errors="coerce").to_numpy(float)
    alpha_finite=np.isfinite(pd.to_numeric(df[cc["alpha3"]],errors="coerce").to_numpy(float))
    af=as_bool(df[cc["alpha3_flag"]]); ff=as_bool(df[cc["feh_flag"]])
    w=pd.to_numeric(df[cc["weight"]],errors="coerce").to_numpy(float)
    cell=pd.to_numeric(df[cc["cell"]],errors="raise").to_numpy(np.int64)
    survey=df[cc["survey"]].astype(str).to_numpy()
    d=C["domain"]
    m=(np.isfinite(R)&np.isfinite(Z)&np.isfinite(feh)&alpha_finite&np.isfinite(w)&(w>0)&af&ff&
       (R>=d["R_min"])&(R<=d["R_max"])&(Z>=d["absZ_min"])&(Z<=d["absZ_max"])&
       (feh>=d["feh_min"])&(feh<=d["feh_max"]))
    return {"feh":feh[m],"survey":survey[m],"cell":cell[m],"weight":w[m]}

def evaluate(rr,C):
    if len(rr)==0:
        raise RuntimeError("No replicate results")
    fit_failures=int((~rr["fit_ok"].astype(bool)).sum())
    good=rr[rr["fit_ok"].astype(bool)].copy()

    nnull=int(C["formal"]["null_replicates"])
    null=good[good["kind"]=="null"].copy()
    if len(null)!=nnull:
        raise RuntimeError(f"formal null count mismatch: {len(null)} != {nnull}")
    Tnull=null["T_family"].to_numpy(float)

    alpha=float(C["detector"]["family_alpha"])
    minconc=float(C["detector"]["minimum_sign_concordance_fraction"])
    minadj=int(C["detector"]["minimum_adjacent_practical_knots"])

    null_detect=[]
    for idx,row in null.iterrows():
        arr=null.drop(index=idx)["T_family"].to_numpy(float)
        p=(1+int(np.sum(arr>=float(row["T_family"]))))/len(null)
        any_practical=any(
            row[f"{e}_sign_concordance"]>=minconc and
            row[f"{e}_max_adjacent_practical"]>=minadj
            for e in ["valley","separation","fraction"]
        )
        null_detect.append(bool(p<=alpha and any_practical))
    null_fpr=float(np.mean(null_detect))

    tar=good[good["kind"]=="target"].copy()
    for idx,row in tar.iterrows():
        p=(1+int(np.sum(Tnull>=float(row["T_family"]))))/(len(Tnull)+1)
        e=str(row["effect"]); expected=int(row["sign"])
        med=float(row[f"{e}_median_diff"])
        correct=(1 if med>=0 else -1)==expected
        detected=bool(
            p<=alpha and
            row[f"{e}_sign_concordance"]>=minconc and
            row[f"{e}_max_adjacent_practical"]>=minadj and
            correct
        )
        tar.loc[idx,"family_p"]=p
        tar.loc[idx,"correct_sign"]=correct
        tar.loc[idx,"detected"]=detected

    rows=[]
    for (e,dlt,sgn),g in tar.groupby(["effect","delta","sign"]):
        expected=float(sgn)*float(dlt)
        medrec=float(g[f"{e}_median_diff"].median())
        rows.append({
            "effect":str(e),"delta":float(dlt),"sign":int(sgn),"replicates":int(len(g)),
            "detection_power":float(g["detected"].mean()),
            "family_p_le_0p05_fraction":float((g["family_p"]<=alpha).mean()),
            "correct_sign_fraction":float(g["correct_sign"].mean()),
            "median_sign_concordance":float(g[f"{e}_sign_concordance"].median()),
            "practical_adjacent_gate_fraction":float((g[f"{e}_max_adjacent_practical"]>=minadj).mean()),
            "median_estimated_effect":medrec,
            "expected_effect":expected,
            "median_abs_bias":abs(medrec-expected)
        })
    summ=pd.DataFrame(rows).sort_values(["effect","delta","sign"]).reset_index(drop=True)

    strong=C["strong_targets"]; biasmax=C["gates"]["strong_effect_median_abs_bias_max"]
    strong_mask=summ.apply(lambda r: abs(float(r["delta"])-float(strong[r["effect"]]))<1e-12,axis=1)
    strongrows=summ[strong_mask].copy()
    strongrows["power_gate_pass"]=strongrows["detection_power"]>=float(C["gates"]["strong_target_power_min"])
    strongrows["bias_gate_pass"]=strongrows.apply(
        lambda r: float(r["median_abs_bias"])<=float(biasmax[r["effect"]]),axis=1
    )
    all_power=bool(len(strongrows)==6 and strongrows["power_gate_pass"].all())
    all_bias=bool(len(strongrows)==6 and strongrows["bias_gate_pass"].all())

    formal_pass=bool(
        fit_failures<=int(C["gates"]["fit_failures_max"]) and
        null_fpr<=float(C["gates"]["null_fpr_max"]) and
        all_power and all_bias
    )
    return rr,tar,summ,strongrows,null_fpr,fit_failures,formal_pass

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",default=".")
    ap.add_argument("--workers",type=int,default=None)
    a=ap.parse_args()
    root=Path(a.project_root).resolve()
    C=json.loads((root/"config/stage8b2_config.json").read_text(encoding="utf-8"))
    prot=json.loads((root/"protocol/stage8b2_protocol.json").read_text(encoding="utf-8"))

    p1=json.loads((root/C["parent_stage8b1e"]).read_text(encoding="utf-8"))
    pp=json.loads((root/C["pilot_validation"]).read_text(encoding="utf-8"))
    parent_ready=bool(
        p1.get("STAGE8B1E_SUPPORT_DOMAIN_AMENDMENT_FROZEN") is True and
        p1.get("STAGE8B2_SYNTHETIC_POWER_READY") is True and
        p1.get("REAL_ALPHA3_MIXTURE_FIT_PERFORMED") is False and
        p1.get("REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED") is False and
        p1.get("AMENDED_PRIMARY_KNOTS")==C["knots"] and
        pp.get("STAGE8B2A_PILOT_COMPLETE") is True and
        pp.get("REAL_ALPHA3_MIXTURE_FIT_PERFORMED") is False and
        pp.get("REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED") is False
    )
    if not parent_ready:
        raise RuntimeError("Stage-8B1E / Stage-8B2A parent guards failed")

    arrays=load_support(root,C)
    expected_rows=26180
    if len(arrays["feh"])!=expected_rows:
        raise RuntimeError(f"eligible support identity mismatch: {len(arrays['feh'])} != {expected_rows}")

    # Full formal task registry.
    tasks=[]
    nnull=int(C["formal"]["null_replicates"])
    for r in range(nnull):
        tasks.append(("null","null",0.0,1,r))
    nrep=int(C["formal"]["replicates_per_signed_target"])
    for effect,mags in C["all_targets"].items():
        for delta in mags:
            for sign in (-1,1):
                for r in range(nrep):
                    tasks.append(("target",effect,float(delta),sign,r))
    if len(tasks)!=1792:
        raise RuntimeError(f"formal task registry mismatch: {len(tasks)}")

    out=root/C["output_dir"]
    ck=out/"checkpoints"
    for q in ["checkpoints","tables","validation","freeze"]:
        (out/q).mkdir(parents=True,exist_ok=True)

    existing={}
    for p in ck.glob("*.json"):
        try:
            rec=json.loads(p.read_text(encoding="utf-8"))
            existing[p.stem]=rec
        except Exception:
            pass

    pending=[t for t in tasks if task_key(t) not in existing]
    workers=a.workers or int(C["formal"]["workers_default"])
    print(f"[8B2] total={len(tasks)} existing={len(tasks)-len(pending)} pending={len(pending)} workers={workers}")
    print("[8B2] Formal synthetic-only calibration. Real alpha3 morphology remains unopened.")

    # Formal engine config is intentionally separate from pilot seed namespace.
    eng_cfg={
        **C,
        "pilot":{"null_replicates":nnull,"replicates_per_signed_target":nrep,"workers_default":workers}
    }
    t0=time.time(); completed=0; errors=0
    if pending:
        with ProcessPoolExecutor(max_workers=workers,initializer=eng.init_worker,initargs=(arrays,eng_cfg)) as ex:
            fmap={ex.submit(eng.simulate_one,t):t for t in pending}
            for f in as_completed(fmap):
                t=fmap[f]; key=task_key(t)
                try:
                    rec=f.result()
                    write_json(ck/(key+".json"),rec)
                except Exception as e:
                    errors+=1
                    write_json(ck/(key+".json"),{
                        "kind":t[0],"effect":t[1],"delta":t[2],"sign":t[3],"rep":t[4],
                        "fit_ok":False,"error":repr(e)
                    })
                completed+=1
                if completed%32==0 or completed==len(pending):
                    print(f"[8B2] completed_or_attempted={completed}/{len(pending)} errors={errors} elapsed_min={(time.time()-t0)/60:.1f}")

    recs=[]
    missing=[]
    for t in tasks:
        p=ck/(task_key(t)+".json")
        if not p.exists():
            missing.append(task_key(t))
        else:
            recs.append(json.loads(p.read_text(encoding="utf-8")))
    if missing:
        raise RuntimeError(f"missing formal checkpoints: {len(missing)}")

    rr=pd.DataFrame(recs)
    rr,tar,summ,strongrows,null_fpr,fit_failures,formal_pass=evaluate(rr,C)
    rr.to_csv(out/"tables/stage8b2_all_formal_replicates.csv",index=False)
    summ.to_csv(out/"tables/stage8b2_target_power_summary.csv",index=False)
    strongrows.to_csv(out/"tables/stage8b2_strong_target_gate_summary.csv",index=False)
    (out/"freeze/stage8b2_protocol_frozen.json").write_text(
        (root/"protocol/stage8b2_protocol.json").read_text(encoding="utf-8"),encoding="utf-8"
    )

    val={
      "stage":C["stage"],"implementation_version":C["implementation_version"],"timestamp_utc":now(),
      "STAGE8B1E_AND_PILOT_PARENT_GUARDS_READY":parent_ready,
      "FORMAL_ELIGIBLE_SYNTHETIC_SUPPORT_ROWS":int(len(arrays["feh"])),
      "FORMAL_NULL_REPLICATES_COMPLETED":int((rr["kind"]=="null").sum()),
      "FORMAL_INJECTED_REPLICATES_COMPLETED":int((rr["kind"]=="target").sum()),
      "FORMAL_TOTAL_REPLICATES_COMPLETED":int(len(rr)),
      "FORMAL_SYNTHETIC_FIT_FAILURES":fit_failures,
      "FORMAL_NULL_FAMILYWISE_FALSE_POSITIVE_RATE":null_fpr,
      "FORMAL_NULL_FPR_GATE_PASS":bool(null_fpr<=float(C["gates"]["null_fpr_max"])),
      "ALL_SIX_STRONG_SIGNED_TARGET_POWER_GATES_PASS":bool(
          len(strongrows)==6 and strongrows["power_gate_pass"].all()
      ),
      "ALL_SIX_STRONG_SIGNED_TARGET_EFFECT_BIAS_GATES_PASS":bool(
          len(strongrows)==6 and strongrows["bias_gate_pass"].all()
      ),
      "MARGIN_LEVEL_SCENARIOS_FORMAL_GATE":False,
      "REAL_ALPHA3_VALUES_USED_FOR_SYNTHETIC_GENERATION":False,
      "REAL_ALPHA3_FINITE_MASK_USED_FOR_ELIGIBILITY":True,
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":False,
      "REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED":False,
      "STAGE8B2_FORMAL_POWER_CALIBRATION_PASS":formal_pass,
      "STAGE8C_REAL_INFERENCE_PROTOCOL_CONSTRUCTION_READY":formal_pass,
      "STAGE8_REAL_MIXTURE_INTERPRETATION_AUTHORIZED":False,
      "PROTOCOL_CANONICAL_SHA256":canon(prot)
    }
    write_json(out/"validation/stage8b2_validation.json",val)
    print(json.dumps({
        "validation":val,
        "strong_target_summary":strongrows.to_dict(orient="records")
    },indent=2,ensure_ascii=False))
    return 0 if formal_pass else 2

if __name__=="__main__":
    raise SystemExit(main())
