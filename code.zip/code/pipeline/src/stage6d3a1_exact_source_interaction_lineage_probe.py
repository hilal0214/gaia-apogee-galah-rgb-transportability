from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import yaml


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8"
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_columns(path: Path) -> tuple[list[str], int]:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        import pyarrow.parquet as pq
        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    if suffix == ".csv":
        return list(pd.read_csv(path, nrows=5).columns), -1
    value = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(value, list) and value and isinstance(value[0], dict):
        return sorted(value[0]), len(value)
    if isinstance(value, dict):
        return sorted(value), -1
    return [], -1


def read_column_values(path: Path, column: str, limit: int = 500) -> list[str]:
    try:
        if path.suffix.lower() == ".parquet":
            values = pd.read_parquet(path, columns=[column])[column]
        elif path.suffix.lower() == ".csv":
            values = pd.read_csv(path, usecols=[column], nrows=limit)[column]
        else:
            return []
        return sorted(set(values.dropna().astype(str)))[:100]
    except Exception:
        return []


def find_alias(columns: list[str], options: list[str]) -> str | None:
    lookup = {column.lower(): column for column in columns}
    for option in options:
        if option.lower() in lookup:
            return lookup[option.lower()]
    return None


def flatten_mapping(value: Any, prefix: str = "$") -> list[tuple[str, Any]]:
    rows: list[tuple[str, Any]] = []
    if isinstance(value, dict):
        for key, child in value.items():
            rows.extend(flatten_mapping(child, f"{prefix}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            rows.extend(flatten_mapping(child, f"{prefix}[{index}]"))
    else:
        rows.append((prefix, value))
    return rows


def resolve_path(value: str, root: Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def extract_script_file_literals(script_path: Path) -> list[dict[str, Any]]:
    text = script_path.read_text(encoding="utf-8")
    tree = ast.parse(text)
    literals = []
    seen = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            value = node.value.strip()
            if re.search(r"\.(csv|parquet|json|yml|yaml)$", value, re.I):
                key = (value, getattr(node, "lineno", -1))
                if key not in seen:
                    seen.add(key)
                    literals.append({
                        "literal": value,
                        "line": getattr(node, "lineno", -1),
                        "context": ""
                    })
    lines = text.splitlines()
    for row in literals:
        line = int(row["line"])
        if line > 0:
            start = max(0, line - 3)
            end = min(len(lines), line + 2)
            row["context"] = " || ".join(
                item.strip() for item in lines[start:end]
            )
    return literals


def exact_path_contract(
    root: Path,
    stage4a_dir: Path,
    stage4b_dir: Path,
    literals: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    rows = []
    for item in literals:
        literal = item["literal"]
        candidates = [
            root / literal,
            stage4a_dir / literal,
            stage4b_dir / literal
        ]
        unique = []
        seen = set()
        for candidate in candidates:
            resolved = candidate.resolve()
            if str(resolved) not in seen:
                seen.add(str(resolved))
                unique.append(candidate)
        existing = [candidate for candidate in unique if candidate.exists()]
        role_hint = "unknown"
        context = str(item["context"]).lower()
        if any(token in context for token in ["read_csv", "read_parquet"]):
            role_hint = "script_read"
        if any(token in context for token in ["to_csv", "to_parquet", "write"]):
            role_hint = (
                "script_write"
                if role_hint == "unknown"
                else role_hint + "_and_write"
            )
        rows.append({
            "literal": literal,
            "script_line": item["line"],
            "role_hint": role_hint,
            "existing_count": len(existing),
            "resolved_existing_paths": "|".join(
                safe_rel(path, root) for path in existing
            ),
            "context": item["context"]
        })
    return rows


def detect_labels(columns: list[str], labels: list[str]) -> list[str]:
    lookup = {column.lower() for column in columns}
    return [label for label in labels if label.lower() in lookup]


def profile_file(
    path: Path,
    columns: list[str],
    config: dict[str, Any],
    exact_script_paths: set[str]
) -> dict[str, Any]:
    aliases = config["aliases"]
    mapping = {
        key: find_alias(columns, options)
        for key, options in aliases.items()
    }
    labels = detect_labels(columns, config["labels"])
    covered_fields = [
        field for field in config["required_source_fields"]
        if mapping.get(field)
    ]
    lower_columns = [column.lower() for column in columns]
    path_text = str(path).lower().replace("\\", "/")
    exact_reference = str(path.resolve()) in exact_script_paths

    wide_interaction_columns = []
    for column in lower_columns:
        has_interaction = any(
            token in column
            for token in config["interaction_column_tokens"]
        )
        has_survey = any(
            token in column for token in config["survey_tokens"]
        )
        has_direction = any(
            token in column
            for token in config["radial_tokens"] + config["vertical_tokens"]
        )
        if (has_interaction or has_survey) and has_direction:
            wide_interaction_columns.append(column)

    long_interaction_ready = False
    long_interaction_terms: list[str] = []
    if mapping.get("term") and mapping.get("estimate"):
        terms = read_column_values(path, mapping["term"])
        for term in terms:
            lower = term.lower()
            has_survey = any(
                token in lower for token in config["survey_tokens"]
            )
            has_direction = any(
                token in lower
                for token in config["radial_tokens"] + config["vertical_tokens"]
            )
            if has_survey and has_direction:
                long_interaction_terms.append(term)
        long_interaction_ready = bool(long_interaction_terms)

    interaction_ready = bool(
        mapping.get("label")
        and (wide_interaction_columns or long_interaction_ready)
    )

    source_base_ready = bool(
        mapping.get("source_id")
        and mapping.get("survey")
        and len(labels) >= config["minimum_primary_labels"]
    )
    coordinate_ready = bool(
        mapping.get("source_id")
        and mapping.get("R") and mapping.get("Z")
        and mapping.get("l") and mapping.get("b")
    )
    covariate_ready = bool(
        mapping.get("source_id")
        and mapping.get("teff")
        and mapping.get("logg")
        and mapping.get("snr")
        and mapping.get("photometry")
    )
    complete_source_ready = bool(
        source_base_ready and coordinate_ready and covariate_ready
    )

    reference_bonus = 500 if exact_reference else 0
    stage_bonus = 100 if "stage4a" in path_text else 0
    production_bonus = 100 if "production" in path_text else 0
    interaction_bonus = 100 if "interaction" in path_text else 0

    scores = {
        "complete_source": (
            1000 + reference_bonus + stage_bonus + production_bonus
            + 20 * len(labels)
        ) if complete_source_ready else -1,
        "source_base": (
            800 + reference_bonus + stage_bonus + production_bonus
            + 20 * len(labels)
        ) if source_base_ready else -1,
        "coordinates": (
            700 + reference_bonus + stage_bonus
        ) if coordinate_ready else -1,
        "covariates": (
            700 + reference_bonus + stage_bonus
        ) if covariate_ready else -1,
        "interaction": (
            1000 + reference_bonus + interaction_bonus
            + 20 * len(wide_interaction_columns)
            + 20 * len(long_interaction_terms)
        ) if interaction_ready else -1
    }

    return {
        "mapping": mapping,
        "labels": labels,
        "covered_fields": covered_fields,
        "exact_script_reference": exact_reference,
        "complete_source_ready": complete_source_ready,
        "source_base_ready": source_base_ready,
        "coordinate_ready": coordinate_ready,
        "covariate_ready": covariate_ready,
        "interaction_ready": interaction_ready,
        "wide_interaction_columns": wide_interaction_columns,
        "long_interaction_terms": long_interaction_terms,
        "scores": scores
    }


def choose_role(
    rows: list[dict[str, Any]],
    predicate: str,
    score_key: str
) -> dict[str, Any] | None:
    eligible = [
        row for row in rows if row["profile"][predicate]
    ]
    if not eligible:
        return None
    eligible.sort(
        key=lambda row: (
            -int(row["profile"]["scores"][score_key]),
            -int(row["row_count"] if row["row_count"] not in ("", -1) else 0),
            row["path"]
        )
    )
    return eligible[0]


def greedy_source_bundle(
    rows: list[dict[str, Any]],
    required_fields: list[str],
    minimum_labels: int
) -> list[dict[str, Any]]:
    source_keyed = [
        row for row in rows
        if row["profile"]["mapping"].get("source_id")
    ]
    if not source_keyed:
        return []

    selected: list[dict[str, Any]] = []
    uncovered = set(required_fields)
    label_union: set[str] = set()

    while uncovered or len(label_union) < minimum_labels:
        best = None
        best_gain = -1
        for row in source_keyed:
            if row in selected:
                continue
            covered = set(row["profile"]["covered_fields"])
            new_fields = len(uncovered.intersection(covered))
            new_labels = len(
                set(row["profile"]["labels"]) - label_union
            )
            reference = int(row["profile"]["exact_script_reference"])
            score = 100 * new_fields + 20 * new_labels + 5 * reference
            if score > best_gain:
                best_gain = score
                best = row
        if best is None or best_gain <= 0:
            break
        selected.append(best)
        uncovered -= set(best["profile"]["covered_fields"])
        label_union.update(best["profile"]["labels"])

    if uncovered or len(label_union) < minimum_labels:
        return []
    return selected


def read_source_ids(
    root: Path,
    row: dict[str, Any]
) -> tuple[pd.Series, str]:
    path = root / row["path"]
    column = row["profile"]["mapping"].get("source_id")
    if not column:
        return pd.Series(dtype="uint64"), "source_id alias missing"
    try:
        if path.suffix.lower() == ".parquet":
            values = pd.read_parquet(path, columns=[column])[column]
        elif path.suffix.lower() == ".csv":
            values = pd.read_csv(path, usecols=[column])[column]
        else:
            return pd.Series(dtype="uint64"), "unsupported source table suffix"
        numeric = pd.to_numeric(values, errors="coerce")
        if numeric.isna().any():
            return pd.Series(dtype="uint64"), "non-numeric or missing source IDs"
        return numeric.astype("uint64"), ""
    except Exception as exc:
        return pd.Series(dtype="uint64"), f"{type(exc).__name__}: {exc}"


def audit_bundle_join(
    root: Path,
    bundle: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], bool]:
    rows = []
    sets = []
    ready = True
    for item in bundle:
        values, error = read_source_ids(root, item)
        unique = bool(not values.empty and not values.duplicated().any())
        ready &= unique and not error
        source_set = set(values.tolist()) if not error else set()
        sets.append(source_set)
        rows.append({
            "path": item["path"],
            "rows": len(values),
            "unique_source_ids": len(source_set),
            "duplicate_source_ids": (
                int(values.duplicated().sum()) if not values.empty else ""
            ),
            "source_id_unique": str(unique).lower(),
            "read_error": error
        })
    if sets:
        intersection = set.intersection(*sets)
        union = set.union(*sets)
        rows.append({
            "path": "__BUNDLE_SUMMARY__",
            "rows": "",
            "unique_source_ids": len(union),
            "duplicate_source_ids": "",
            "source_id_unique": str(ready).lower(),
            "read_error": f"intersection_source_ids={len(intersection)}"
        })
        ready &= len(intersection) > 0
    else:
        ready = False
    return rows, ready


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    config = json.loads(
        (root / "config/stage6d3a1_config.json").read_text(encoding="utf-8")
    )
    out = root / config["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables", "reports", "probe"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / config["prerequisite_validation"]
    prereq = (
        json.loads(prereq_path.read_text(encoding="utf-8"))
        if prereq_path.exists() else {}
    )
    prereq_ready = bool(
        prereq.get("STAGE6D3A_PROTOCOL_READY", False)
        and prereq.get("PROTOCOL_SEMANTIC_IDENTITY_READY", False)
    )

    stage4b_config_path = root / config["stage4b_config"]
    stage4b_script_path = root / config["stage4b_script"]
    if not stage4b_config_path.exists():
        raise FileNotFoundError(stage4b_config_path)
    if not stage4b_script_path.exists():
        raise FileNotFoundError(stage4b_script_path)

    stage4b_config = yaml.safe_load(
        stage4b_config_path.read_text(encoding="utf-8")
    )
    flattened = flatten_mapping(stage4b_config)
    path_rows = []
    stage4a_value = "outputs/stage4a"
    output_value = "outputs/stage4b"
    for json_path, value in flattened:
        lower_path = json_path.lower()
        if isinstance(value, str):
            if "stage4a_output_dir" in lower_path:
                stage4a_value = value
            if lower_path.endswith(".output_dir") and "stage4a" not in lower_path:
                output_value = value
            path_like = (
                any(key in lower_path for key in config["path_keys"])
                or re.search(r"\.(csv|parquet|json|yml|yaml)$", value, re.I)
            )
            if path_like:
                resolved = resolve_path(value, root)
                path_rows.append({
                    "json_path": json_path,
                    "value": value,
                    "resolved_path": safe_rel(resolved, root),
                    "exists": str(resolved.exists()).lower(),
                    "is_file": str(resolved.is_file()).lower(),
                    "is_dir": str(resolved.is_dir()).lower()
                })
    write_csv(
        out / "tables/stage6d3a1_stage4b_config_path_contract.csv",
        [
            "json_path", "value", "resolved_path",
            "exists", "is_file", "is_dir"
        ],
        path_rows
    )

    stage4a_dir = resolve_path(stage4a_value, root)
    stage4b_dir = resolve_path(output_value, root)
    literals = extract_script_file_literals(stage4b_script_path)
    exact_rows = exact_path_contract(
        root, stage4a_dir, stage4b_dir, literals
    )
    write_csv(
        out / "tables/stage6d3a1_script_file_contract.csv",
        [
            "literal", "script_line", "role_hint", "existing_count",
            "resolved_existing_paths", "context"
        ],
        exact_rows
    )

    exact_paths = set()
    for row in exact_rows:
        for value in row["resolved_existing_paths"].split("|"):
            if value:
                exact_paths.add(str((root / value).resolve()))

    candidates = []
    suffixes = set(config["suffixes"])
    for rel_root in config["scan_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in suffixes:
                continue
            try:
                columns, row_count = read_columns(path)
                profile = profile_file(
                    path, columns, config, exact_paths
                )
                candidates.append({
                    "path": safe_rel(path, root),
                    "suffix": path.suffix.lower(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                    "row_count": row_count,
                    "column_count": len(columns),
                    "columns": "|".join(columns),
                    "profile": profile,
                    "read_error": ""
                })
            except Exception as exc:
                candidates.append({
                    "path": safe_rel(path, root),
                    "suffix": path.suffix.lower(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                    "row_count": "",
                    "column_count": "",
                    "columns": "",
                    "profile": {
                        "mapping": {},
                        "labels": [],
                        "covered_fields": [],
                        "exact_script_reference": False,
                        "complete_source_ready": False,
                        "source_base_ready": False,
                        "coordinate_ready": False,
                        "covariate_ready": False,
                        "interaction_ready": False,
                        "wide_interaction_columns": [],
                        "long_interaction_terms": [],
                        "scores": {
                            "complete_source": -1,
                            "source_base": -1,
                            "coordinates": -1,
                            "covariates": -1,
                            "interaction": -1
                        }
                    },
                    "read_error": f"{type(exc).__name__}: {exc}"
                })

    inventory = []
    for row in candidates:
        profile = row["profile"]
        inventory.append({
            "path": row["path"],
            "suffix": row["suffix"],
            "size_bytes": row["size_bytes"],
            "sha256": row["sha256"],
            "row_count": row["row_count"],
            "column_count": row["column_count"],
            "columns": row["columns"],
            "exact_script_reference": str(
                profile["exact_script_reference"]
            ).lower(),
            "complete_source_ready": str(
                profile["complete_source_ready"]
            ).lower(),
            "source_base_ready": str(
                profile["source_base_ready"]
            ).lower(),
            "coordinate_ready": str(
                profile["coordinate_ready"]
            ).lower(),
            "covariate_ready": str(
                profile["covariate_ready"]
            ).lower(),
            "interaction_ready": str(
                profile["interaction_ready"]
            ).lower(),
            "labels": "|".join(profile["labels"]),
            "covered_fields": "|".join(profile["covered_fields"]),
            "wide_interaction_columns": "|".join(
                profile["wide_interaction_columns"]
            ),
            "long_interaction_terms": "|".join(
                profile["long_interaction_terms"]
            ),
            "mapping": json.dumps(
                profile["mapping"], sort_keys=True
            ),
            "scores": json.dumps(
                profile["scores"], sort_keys=True
            ),
            "read_error": row["read_error"]
        })
    inventory.sort(key=lambda row: row["path"])
    write_csv(
        out / "tables/stage6d3a1_file_schema_inventory.csv",
        [
            "path", "suffix", "size_bytes", "sha256",
            "row_count", "column_count", "columns",
            "exact_script_reference", "complete_source_ready",
            "source_base_ready", "coordinate_ready",
            "covariate_ready", "interaction_ready",
            "labels", "covered_fields",
            "wide_interaction_columns", "long_interaction_terms",
            "mapping", "scores", "read_error"
        ],
        inventory
    )

    complete_source = choose_role(
        candidates, "complete_source_ready", "complete_source"
    )
    source_base = choose_role(
        candidates, "source_base_ready", "source_base"
    )
    coordinates = choose_role(
        candidates, "coordinate_ready", "coordinates"
    )
    covariates = choose_role(
        candidates, "covariate_ready", "covariates"
    )
    interaction = choose_role(
        candidates, "interaction_ready", "interaction"
    )

    bundle = [complete_source] if complete_source else greedy_source_bundle(
        candidates,
        config["required_source_fields"],
        config["minimum_primary_labels"]
    )
    bundle = [row for row in bundle if row is not None]
    join_rows, join_ready = audit_bundle_join(root, bundle)

    selection_rows = []
    selected_roles = {
        "complete_source": complete_source,
        "source_base": source_base,
        "coordinates": coordinates,
        "covariates": covariates,
        "interaction": interaction
    }
    for role, row in selected_roles.items():
        selection_rows.append({
            "role": role,
            "selected": str(row is not None).lower(),
            "path": row["path"] if row else "",
            "exact_script_reference": (
                str(row["profile"]["exact_script_reference"]).lower()
                if row else ""
            ),
            "labels": (
                "|".join(row["profile"]["labels"]) if row else ""
            ),
            "covered_fields": (
                "|".join(row["profile"]["covered_fields"]) if row else ""
            ),
            "mapping": (
                json.dumps(row["profile"]["mapping"], sort_keys=True)
                if row else ""
            )
        })
    write_csv(
        out / "tables/stage6d3a1_selected_roles.csv",
        [
            "role", "selected", "path", "exact_script_reference",
            "labels", "covered_fields", "mapping"
        ],
        selection_rows
    )

    bundle_rows = []
    for index, row in enumerate(bundle):
        bundle_rows.append({
            "bundle_order": index + 1,
            "path": row["path"],
            "exact_script_reference": str(
                row["profile"]["exact_script_reference"]
            ).lower(),
            "labels": "|".join(row["profile"]["labels"]),
            "covered_fields": "|".join(
                row["profile"]["covered_fields"]
            )
        })
    write_csv(
        out / "tables/stage6d3a1_selected_source_bundle.csv",
        [
            "bundle_order", "path", "exact_script_reference",
            "labels", "covered_fields"
        ],
        bundle_rows
    )
    write_csv(
        out / "tables/stage6d3a1_source_id_join_audit.csv",
        [
            "path", "rows", "unique_source_ids",
            "duplicate_source_ids", "source_id_unique", "read_error"
        ],
        join_rows
    )

    source_lineage_ready = bool(bundle and join_ready)
    interaction_ready = interaction is not None
    exact_interaction_reference = bool(
        interaction
        and (
            interaction["profile"]["exact_script_reference"]
            or "stage4b" in interaction["path"].lower()
        )
    )
    config_ready = bool(stage4a_dir.exists() and stage4b_dir.exists())
    script_contract_ready = bool(literals and exact_rows)

    remaining = []
    if not source_lineage_ready:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_LINEAGE_READY",
            "required_action": (
                "The exact Stage-4B input lineage does not yet yield a source-ID "
                "keyed bundle covering survey, R/Z, l/b, Teff, logg, S/N, "
                "photometry, and at least five labels."
            )
        })
    if not interaction_ready:
        remaining.append({
            "gate": "EXACT_SURVEY_INTERACTION_PRODUCT_READY",
            "required_action": (
                "No Stage-4B interaction table was found using either wide "
                "interaction columns or a long term/estimate contract."
            )
        })
    elif not exact_interaction_reference:
        remaining.append({
            "gate": "SURVEY_INTERACTION_LINEAGE_READY",
            "required_action": (
                "An interaction-shaped table exists but is not yet tied to the "
                "exact Stage-4B output lineage."
            )
        })
    write_csv(
        out / "tables/stage6d3a1_remaining_items.csv",
        ["gate", "required_action"],
        remaining
    )

    d3b_ready = bool(
        prereq_ready and config_ready and script_contract_ready
        and source_lineage_ready and interaction_ready
        and exact_interaction_reference
    )

    validation = {
        "stage": config["stage"],
        "protocol_version": config["protocol_version"],
        "implementation_version": config["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "stage4b_config": safe_rel(stage4b_config_path, root),
        "stage4b_config_sha256": sha256_file(stage4b_config_path),
        "stage4b_script": safe_rel(stage4b_script_path, root),
        "stage4b_script_sha256": sha256_file(stage4b_script_path),
        "resolved_stage4a_output_dir": safe_rel(stage4a_dir, root),
        "resolved_stage4b_output_dir": safe_rel(stage4b_dir, root),
        "script_file_literal_count": len(literals),
        "candidate_file_count": len(candidates),
        "selected_complete_source": (
            complete_source["path"] if complete_source else ""
        ),
        "selected_source_bundle": [
            row["path"] for row in bundle
        ],
        "selected_interaction_product": (
            interaction["path"] if interaction else ""
        ),
        "prior_stage_outputs_modified": False,
        "STAGE6D3A_PREREQUISITE_READY": prereq_ready,
        "STAGE4B_CONFIG_PATH_CONTRACT_READY": config_ready,
        "STAGE4B_SCRIPT_FILE_CONTRACT_READY": script_contract_ready,
        "PRODUCTION_SOURCE_LINEAGE_READY": source_lineage_ready,
        "SOURCE_ID_JOIN_CONTRACT_READY": join_ready,
        "EXACT_SURVEY_INTERACTION_PRODUCT_READY": interaction_ready,
        "SURVEY_INTERACTION_LINEAGE_READY": exact_interaction_reference,
        "STAGE6D3A1_LINEAGE_READY": bool(
            prereq_ready and config_ready and script_contract_ready
        ),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": d3b_ready
    }
    write_json(
        out / "validation/stage6d3a1_validation.json",
        validation
    )

    summary = {
        "stage": config["stage"],
        "timestamp_utc": utc_now(),
        "selected_source_bundle": [
            {
                "path": row["path"],
                "covered_fields": row["profile"]["covered_fields"],
                "labels": row["profile"]["labels"],
                "exact_script_reference": (
                    row["profile"]["exact_script_reference"]
                )
            }
            for row in bundle
        ],
        "selected_interaction": (
            {
                "path": interaction["path"],
                "wide_interaction_columns": (
                    interaction["profile"]["wide_interaction_columns"]
                ),
                "long_interaction_terms": (
                    interaction["profile"]["long_interaction_terms"]
                ),
                "exact_script_reference": (
                    interaction["profile"]["exact_script_reference"]
                )
            }
            if interaction else {}
        ),
        "remaining_items": remaining,
        "scientific_disposition": (
            "Exact Stage-4B source and interaction lineages are closed. "
            "Stage-6D3B construction is authorized."
            if d3b_ready else
            "The exact probe is complete; common-footprint construction remains "
            "blocked only by the listed lineage gap."
        )
    }
    write_json(
        out / "summaries/stage6d3a1_summary.json",
        summary
    )

    report = [
        "# Stage-6D3A1 exact source/interactions lineage probe",
        "",
        f"- Stage-4B config contract: `{config_ready}`",
        f"- Stage-4B script file contract: `{script_contract_ready}`",
        f"- Source bundle files: `{len(bundle)}`",
        f"- Source-ID join contract: `{join_ready}`",
        f"- Interaction product: `{interaction['path'] if interaction else 'not found'}`",
        f"- Interaction lineage: `{exact_interaction_reference}`",
        f"- Stage-6D3B ready: `{d3b_ready}`",
        "",
        "No gradient, propensity, common-footprint, or survey-weight fit is run.",
        ""
    ]
    (
        out / "reports/stage6d3a1_exact_source_interaction_lineage_probe.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
