from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

STAGE = "Stage-6C3B flat MNRAS bibliography hotfix"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.16.1"

INPUT_PATTERN = re.compile(r"\\(?:input|include)\s*\{([^}]+)\}")
FORBIDDEN_INPUT_PATTERN = re.compile(r"\\(?:input|include)(?!graphics)\b")
BIB_STYLE_PATTERN = re.compile(r"\\bibliographystyle\s*\{[^}]+\}\s*", re.S)
BIB_PATTERN = re.compile(r"\\bibliography\s*\{[^}]+\}\s*", re.S)
FIGURE_PATTERN = re.compile(
    r"\\includegraphics(?:\[[^\]]*\])?\s*\{([^}]+)\}"
)

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def safe_rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def write_csv(path: Path, fields: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

def first_existing(root: Path, values: list[str]) -> Path | None:
    for value in values:
        path = root / value
        if path.exists():
            return path
    return None

def split_unescaped_comment(line: str) -> tuple[str, str]:
    slash_count = 0
    for index, char in enumerate(line):
        if char == "\\":
            slash_count += 1
            continue
        if char == "%" and slash_count % 2 == 0:
            return line[:index], line[index:]
        slash_count = 0
    return line, ""

def resolve_tex_target(base_file: Path, target: str, source_root: Path) -> Path:
    candidate = Path(target)
    if candidate.suffix.lower() != ".tex":
        candidate = candidate.with_suffix(".tex")
    possibilities = [
        (base_file.parent / candidate).resolve(),
        (source_root / candidate).resolve(),
    ]
    for path in possibilities:
        if path.exists() and path.is_file():
            return path
    raise FileNotFoundError(
        f"Unable to resolve LaTeX dependency '{target}' from {base_file}"
    )

def flatten_tex(
    path: Path,
    source_root: Path,
    dependency_rows: list[dict[str, Any]],
    stack: tuple[Path, ...] = ()
) -> str:
    path = path.resolve()
    if path in stack:
        chain = " -> ".join(str(p) for p in stack + (path,))
        raise RuntimeError(f"Circular LaTeX dependency: {chain}")
    text = path.read_text(encoding="utf-8", errors="strict")
    output_lines: list[str] = []
    for line_number, line in enumerate(text.splitlines(keepends=True), start=1):
        code, comment = split_unescaped_comment(line)
        matches = list(INPUT_PATTERN.finditer(code))
        if not matches:
            output_lines.append(line)
            continue

        cursor = 0
        rebuilt = ""
        for match in matches:
            rebuilt += code[cursor:match.start()]
            target = match.group(1).strip()
            child = resolve_tex_target(path, target, source_root)
            child_text = flatten_tex(
                child, source_root, dependency_rows, stack + (path,)
            )
            dependency_rows.append({
                "parent": safe_rel(path, source_root),
                "line": line_number,
                "command": match.group(0),
                "child": safe_rel(child, source_root),
                "child_sha256": sha256_file(child)
            })
            rebuilt += (
                "\n% ===== BEGIN INLINED FILE: "
                + safe_rel(child, source_root)
                + " =====\n"
                + child_text.rstrip()
                + "\n% ===== END INLINED FILE: "
                + safe_rel(child, source_root)
                + " =====\n"
            )
            cursor = match.end()
        rebuilt += code[cursor:]
        if comment:
            rebuilt += comment
        output_lines.append(rebuilt)
    return "".join(output_lines)

def remove_unresolved_assets(source_root: Path, cfg: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    targets = set(cfg["remove_input_targets"])

    for tex_path in source_root.rglob("*.tex"):
        text = tex_path.read_text(encoding="utf-8", errors="ignore")
        original = text

        for target in targets:
            pattern = re.compile(
                r"^[ \t]*\\(?:input|include)\s*\{"
                + re.escape(target)
                + r"(?:\.tex)?\}[ \t]*\r?\n?",
                re.M
            )
            count = len(pattern.findall(text))
            if count:
                text = pattern.sub("", text)
                rows.append({
                    "path": safe_rel(tex_path, source_root),
                    "action": "remove_unresolved_input",
                    "target": target,
                    "count": count
                })

        if tex_path.name == "06_results.tex":
            section_pattern = re.compile(
                r"\\subsection\{Survey-origin support test\}.*?"
                r"(?=\\subsection\{|\\section\{|\\end\{document\}|\Z)",
                re.S
            )
            replacement = r"""\subsection{Survey-support limitation}
The Stage-4B production writer, estimator implementation, and robust-loss parameters are
archived, but the original runner lineage required for an exact survey-origin replay is not
fully recoverable from the frozen package. A reconstructed solver did not reproduce the
authoritative all-clean coefficients within the predefined identity tolerance. We therefore
do not publish newly computed survey-origin coefficients. APOGEE and GALAH support differences
are discussed qualitatively and remain part of the explicit limitation boundary.

"""
            count = len(section_pattern.findall(text))
            if count:
                text = section_pattern.sub(lambda _match: replacement, text)
                rows.append({
                    "path": safe_rel(tex_path, source_root),
                    "action": "replace_unresolved_survey_section",
                    "target": "Survey-origin support test",
                    "count": count
                })

        if text != original:
            tex_path.write_text(text, encoding="utf-8")

    return rows

def scrub_named_claims(source_root: Path, patterns: list[str]) -> list[dict[str, Any]]:
    replacements = {
        "Low-alpha thin disc": "anonymous latent component",
        "High-alpha disc": "anonymous latent component",
        "Halo-like candidates": "anonymous latent-component candidates",
        "Vertically extended rotating disc": "anonymous latent component",
        "Intermediate disc-like candidates": "ambiguous latent-component candidates",
        "population-resolved gradients": "component-resolved gradients not retained in the claim-safe analysis"
    }
    rows = []
    for path in source_root.rglob("*.tex"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        original = text
        for pattern in patterns:
            count = text.lower().count(pattern.lower())
            if count:
                replacement = replacements.get(
                    pattern, "anonymous latent-component diagnostics"
                )
                text = re.sub(
                    re.escape(pattern), replacement, text, flags=re.I
                )
                rows.append({
                    "path": safe_rel(path, source_root),
                    "pattern": pattern,
                    "replacement": replacement,
                    "count": count
                })
        if text != original:
            path.write_text(text, encoding="utf-8")
    return rows

def locate_tex_dependency(name: str, source_root: Path, final_root: Path) -> tuple[Path | None, str]:
    local_candidates = list(source_root.rglob(name))
    if local_candidates:
        source = local_candidates[0]
        shutil.copy2(source, final_root / name)
        return source, "source_package"
    try:
        result = subprocess.run(
            ["kpsewhich", name],
            capture_output=True,
            text=True,
            timeout=30
        )
        candidate = Path(result.stdout.strip())
        if result.returncode == 0 and candidate.exists():
            shutil.copy2(candidate, final_root / name)
            return candidate, "kpsewhich"
    except Exception:
        pass
    return None, ""

def resolve_figure_source(
    source_root: Path,
    tex_reference: str
) -> Path | None:
    reference = Path(tex_reference)
    extensions = ["", ".pdf", ".png", ".jpg", ".jpeg", ".eps"]
    candidates = []
    for extension in extensions:
        candidate = reference if extension == "" else Path(str(reference) + extension)
        candidates.extend([
            source_root / candidate,
            source_root / "figures" / candidate.name,
        ])
    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate
    return None

def copy_referenced_figures(
    flat_text: str,
    source_root: Path,
    final_root: Path
) -> tuple[list[dict[str, Any]], bool]:
    rows = []
    ready = True
    for reference in sorted(set(FIGURE_PATTERN.findall(flat_text))):
        source = resolve_figure_source(source_root, reference)
        if source is None:
            rows.append({
                "reference": reference,
                "status": "missing",
                "source": "",
                "destination": "",
                "sha256": ""
            })
            ready = False
            continue
        destination = final_root / reference
        if destination.suffix == "":
            destination = destination.with_suffix(source.suffix)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        rows.append({
            "reference": reference,
            "status": "copied",
            "source": safe_rel(source, source_root),
            "destination": safe_rel(destination, final_root),
            "sha256": sha256_file(destination)
        })
    return rows, ready

def inline_bibliography(
    main_draft: Path,
    final_root: Path,
    timeout_seconds: int
) -> tuple[str, list[dict[str, Any]], bool]:
    audit = []
    commands = [
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", main_draft.name],
        ["bibtex", main_draft.stem],
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", main_draft.name],
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", main_draft.name],
    ]
    compile_ready = True
    for command in commands:
        try:
            result = subprocess.run(
                command,
                cwd=final_root,
                capture_output=True,
                text=True,
                timeout=timeout_seconds
            )
            audit.append({
                "phase": "bibliography_generation",
                "command": " ".join(command),
                "returncode": result.returncode,
                "stdout_tail": result.stdout[-2000:],
                "stderr_tail": result.stderr[-2000:]
            })
            if result.returncode != 0:
                compile_ready = False
                break
        except Exception as exc:
            audit.append({
                "phase": "bibliography_generation",
                "command": " ".join(command),
                "returncode": -1,
                "stdout_tail": "",
                "stderr_tail": f"{type(exc).__name__}: {exc}"
            })
            compile_ready = False
            break

    draft_text = main_draft.read_text(encoding="utf-8")
    bbl_path = final_root / f"{main_draft.stem}.bbl"
    if not compile_ready or not bbl_path.exists():
        return draft_text, audit, False

    bbl_text = bbl_path.read_text(encoding="utf-8")
    text = BIB_STYLE_PATTERN.sub("", draft_text)
    bibliography_matches = list(BIB_PATTERN.finditer(text))
    if not bibliography_matches:
        audit.append({
            "phase": "bibliography_inline",
            "command": "replace bibliography command",
            "returncode": -1,
            "stdout_tail": "",
            "stderr_tail": "No bibliography command was found."
        })
        return draft_text, audit, False

    bibliography_block = (
        "\n% ===== BEGIN INLINED BIBLIOGRAPHY =====\n"
        + bbl_text.strip()
        + "\n% ===== END INLINED BIBLIOGRAPHY =====\n"
    )
    # Use a callback so LaTeX backslashes in the .bbl are inserted literally
    # rather than parsed as Python regular-expression replacement escapes.
    text = BIB_PATTERN.sub(lambda _match: bibliography_block, text, count=1)
    return text, audit, True

def compile_final(main_tex: Path, final_root: Path, timeout_seconds: int) -> tuple[list[dict[str, Any]], bool]:
    audit = []
    commands = [
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", main_tex.name],
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", main_tex.name],
    ]
    ready = True
    for command in commands:
        try:
            result = subprocess.run(
                command,
                cwd=final_root,
                capture_output=True,
                text=True,
                timeout=timeout_seconds
            )
            audit.append({
                "phase": "final_compile",
                "command": " ".join(command),
                "returncode": result.returncode,
                "stdout_tail": result.stdout[-2500:],
                "stderr_tail": result.stderr[-2500:]
            })
            if result.returncode != 0:
                ready = False
                break
        except Exception as exc:
            audit.append({
                "phase": "final_compile",
                "command": " ".join(command),
                "returncode": -1,
                "stdout_tail": "",
                "stderr_tail": f"{type(exc).__name__}: {exc}"
            })
            ready = False
            break
    pdf = final_root / f"{main_tex.stem}.pdf"
    return audit, bool(ready and pdf.exists() and pdf.stat().st_size > 0)

def clean_auxiliary_files(final_root: Path, keep_pdf: bool = True) -> None:
    removable = {
        ".aux", ".bbl", ".blg", ".log", ".out", ".toc",
        ".lof", ".lot", ".fls", ".fdb_latexmk", ".synctex.gz"
    }
    for path in final_root.iterdir():
        if path.is_file() and any(str(path).endswith(suffix) for suffix in removable):
            path.unlink(missing_ok=True)
    (final_root / "main_draft.tex").unlink(missing_ok=True)
    (final_root / "main_draft.pdf").unlink(missing_ok=True)

def command_audit(text: str) -> list[dict[str, Any]]:
    checks = {
        "input_or_include": FORBIDDEN_INPUT_PATTERN.findall(text),
        "bibliography_command": BIB_PATTERN.findall(text),
        "bibliographystyle_command": BIB_STYLE_PATTERN.findall(text),
    }
    rows = []
    for name, matches in checks.items():
        rows.append({
            "check": name,
            "count": len(matches),
            "passed": str(len(matches) == 0).lower()
        })
    return rows

def placeholder_figure_audit(
    source_root: Path,
    markers: list[str]
) -> list[dict[str, Any]]:
    rows = []
    for tex_path in source_root.rglob("*.tex"):
        text = tex_path.read_text(encoding="utf-8", errors="ignore")
        for marker in markers:
            count = text.count(marker)
            if count:
                rows.append({
                    "path": safe_rel(tex_path, source_root),
                    "marker": marker,
                    "count": count
                })
    return rows

def claim_audit(text: str, patterns: list[str]) -> list[dict[str, Any]]:
    rows = []
    for pattern in patterns:
        count = text.lower().count(pattern.lower())
        if count:
            rows.append({"pattern": pattern, "count": count})
    for forbidden in [
        "table05_population_gradients",
        "table06_survey_subsets",
        "figure05_slot",
        "T06 survey-origin coefficient",
    ]:
        count = text.lower().count(forbidden.lower())
        if count:
            rows.append({"pattern": forbidden, "count": count})
    return rows

def metadata_audit(final_root: Path, markers: list[str]) -> list[dict[str, Any]]:
    rows = []
    for path in final_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {
            ".tex", ".yaml", ".yml", ".json", ".md", ".cff"
        }:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for marker in markers:
            count = text.count(marker)
            if count:
                rows.append({
                    "path": safe_rel(path, final_root),
                    "marker": marker,
                    "count": count
                })
    return rows

def write_final_scripts(final_root: Path) -> None:
    (final_root / "compile_final.bat").write_text(
        r"""@echo off
setlocal
cd /d "%~dp0"
pdflatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
pdflatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1
findstr /I /C:"undefined citations" /C:"undefined references" main.log >nul
if not errorlevel 1 (
  echo [ERROR] Undefined citations or references remain.
  exit /b 2
)
echo [OK] main.pdf created from the flat source.
endlocal
""",
        encoding="utf-8"
    )
    (final_root / "validate_final.bat").write_text(
        r"""@echo off
setlocal
cd /d "%~dp0"
findstr /R /C:"\\input[ ]*{" /C:"\\include[ ]*{" main.tex >nul
if not errorlevel 1 (
  echo [ERROR] main.tex still contains \input or \include.
  exit /b 1
)
findstr /R /C:"\\bibliography[ ]*{" /C:"\\bibliographystyle[ ]*{" main.tex >nul
if not errorlevel 1 (
  echo [ERROR] Bibliography was not inlined.
  exit /b 1
)
if not exist main.pdf (
  echo [ERROR] main.pdf is absent.
  exit /b 1
)
echo [OK] Flat-package validation passed.
endlocal
""",
        encoding="utf-8"
    )

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE)
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6c3_config.json").read_text(encoding="utf-8")
    )
    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for name in [
        "validation", "summaries", "tables", "final_package", "checksums"
    ]:
        (out_dir / name).mkdir(parents=True, exist_ok=True)

    source_package = first_existing(root, cfg["source_package_candidates"])
    if source_package is None:
        raise FileNotFoundError("No Stage-6C2G/6C2F source package was found.")

    working_source = out_dir / "_working_source"
    shutil.copytree(source_package, working_source)

    removal_rows = remove_unresolved_assets(working_source, cfg)
    scrub_rows = scrub_named_claims(
        working_source, cfg["named_claim_patterns"]
    )
    placeholder_rows = placeholder_figure_audit(
        working_source, cfg["placeholder_figure_markers"]
    )

    entry = first_existing(
        working_source, cfg["source_entry_candidates"]
    )
    if entry is None:
        raise FileNotFoundError("No main_mnras.tex or main.tex was found.")

    dependency_rows: list[dict[str, Any]] = []
    flat_text = flatten_tex(entry, working_source, dependency_rows)

    final_root = (
        out_dir / "final_package" / cfg["final_package_name"]
    )
    final_root.mkdir(parents=True, exist_ok=True)

    # Copy metadata and bibliography before compilation.
    for name in ["AUTHOR_METADATA.yaml", "references.bib", "LICENSE", "CITATION.cff"]:
        source = working_source / name
        if source.exists():
            shutil.copy2(source, final_root / name)

    mnras_cls, cls_origin = locate_tex_dependency(
        "mnras.cls", working_source, final_root
    )
    mnras_bst, bst_origin = locate_tex_dependency(
        "mnras.bst", working_source, final_root
    )

    figure_rows, figures_ready = copy_referenced_figures(
        flat_text, working_source, final_root
    )

    draft_path = final_root / "main_draft.tex"
    draft_path.write_text(flat_text, encoding="utf-8")

    bibliography_text, compile_audit_1, bibliography_ready = inline_bibliography(
        draft_path,
        final_root,
        int(cfg["compile_timeout_seconds"])
    )

    main_path = final_root / "main.tex"
    main_path.write_text(bibliography_text, encoding="utf-8")

    command_rows = command_audit(bibliography_text)
    claim_rows = claim_audit(
        bibliography_text, cfg["named_claim_patterns"]
    )

    compile_audit_2, pdf_ready = compile_final(
        main_path,
        final_root,
        int(cfg["compile_timeout_seconds"])
    )
    compile_rows = compile_audit_1 + compile_audit_2

    write_final_scripts(final_root)

    final_readme = f"""# RGB atlas flat MNRAS source v0.16.0

This directory is generated from:

`{safe_rel(source_package, root)}`

The article text, retained tables, retained figure environments, and bibliography are contained
directly in `main.tex`.

There are no `\\input`, `\\include`, `\\bibliography`, or `\\bibliographystyle` commands in the
final source. Figures remain external under `figures/`.

The unresolved Stage-4B exact survey-origin replay is not reported. No T06 coefficient table or
Figure 5 is included.

Human-controlled metadata must be completed in `main.tex` and `AUTHOR_METADATA.yaml` before
submission or Zenodo deposit.

Compile with:

`compile_final.bat`
"""
    (final_root / "README.md").write_text(
        final_readme, encoding="utf-8"
    )

    metadata_rows = metadata_audit(
        final_root, cfg["human_metadata_markers"]
    )

    write_csv(
        out_dir / "tables/stage6c3_dependency_audit.csv",
        ["parent", "line", "command", "child", "child_sha256"],
        dependency_rows
    )
    write_csv(
        out_dir / "tables/stage6c3_source_transformations.csv",
        ["path", "action", "target", "count"],
        removal_rows
    )
    write_csv(
        out_dir / "tables/stage6c3_named_claim_scrub.csv",
        ["path", "pattern", "replacement", "count"],
        scrub_rows
    )
    write_csv(
        out_dir / "tables/stage6c3_placeholder_figure_audit.csv",
        ["path", "marker", "count"],
        placeholder_rows
    )
    write_csv(
        out_dir / "tables/stage6c3_figure_audit.csv",
        ["reference", "status", "source", "destination", "sha256"],
        figure_rows
    )
    write_csv(
        out_dir / "tables/stage6c3_command_audit.csv",
        ["check", "count", "passed"],
        command_rows
    )
    write_csv(
        out_dir / "tables/stage6c3_claim_audit.csv",
        ["pattern", "count"],
        claim_rows
    )
    write_csv(
        out_dir / "tables/stage6c3_compile_audit.csv",
        ["phase", "command", "returncode", "stdout_tail", "stderr_tail"],
        compile_rows
    )
    write_csv(
        out_dir / "tables/stage6c3_metadata_audit.csv",
        ["path", "marker", "count"],
        metadata_rows
    )

    no_inputs = FORBIDDEN_INPUT_PATTERN.search(bibliography_text) is None
    no_bib_commands = (
        BIB_PATTERN.search(bibliography_text) is None
        and BIB_STYLE_PATTERN.search(bibliography_text) is None
    )
    no_claims = len(claim_rows) == 0
    no_placeholder_figures = len(placeholder_rows) == 0
    mnras_ready = bool(mnras_cls and mnras_bst)
    human_ready = len(metadata_rows) == 0

    flat_ready = bool(
        no_inputs
        and no_bib_commands
        and bibliography_ready
        and figures_ready
        and no_placeholder_figures
        and no_claims
        and mnras_ready
        and pdf_ready
    )

    # Remove transient compilation files before freezing provenance/checksums.
    clean_auxiliary_files(final_root)

    # Provenance manifest after all final retained files exist.
    manifest = []
    for path in sorted(final_root.rglob("*")):
        if path.is_file():
            manifest.append({
                "path": safe_rel(path, final_root),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path)
            })
    write_json(
        final_root / "PROVENANCE_MANIFEST.json",
        {
            "stage": STAGE,
            "created_utc": utc_now(),
            "source_package": safe_rel(source_package, root),
            "files": manifest
        }
    )
    sums = [
        f"{sha256_file(path)}  {safe_rel(path, final_root)}"
        for path in sorted(final_root.rglob("*"))
        if path.is_file() and path.name != "SHA256SUMS.txt"
    ]
    (final_root / "SHA256SUMS.txt").write_text(
        "\n".join(sums) + "\n", encoding="utf-8"
    )

    package_zip = (
        out_dir / "final_package" / f"{cfg['final_package_name']}.zip"
    )
    with zipfile.ZipFile(
        package_zip, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True
    ) as archive:
        for path in sorted(final_root.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(final_root.parent))

    validation = {
        "stage": STAGE,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "source_package": safe_rel(source_package, root),
        "source_entry": safe_rel(entry, working_source),
        "inlined_dependency_count": len(dependency_rows),
        "removed_unresolved_asset_count": sum(int(r["count"]) for r in removal_rows),
        "scrubbed_named_claim_count": sum(int(r["count"]) for r in scrub_rows),
        "figure_reference_count": len(figure_rows),
        "metadata_placeholder_count": sum(int(r["count"]) for r in metadata_rows),
        "mnras_cls_origin": cls_origin,
        "mnras_bst_origin": bst_origin,
        "prior_stage_outputs_modified": False,
        "SOURCE_PACKAGE_READY": True,
        "CLAIMSAFE_T06_REMOVAL_READY": len(claim_rows) == 0,
        "FLAT_MAIN_TEX_READY": main_path.exists(),
        "NO_INPUT_OR_INCLUDE_COMMANDS": no_inputs,
        "BIBLIOGRAPHY_INLINED": no_bib_commands and bibliography_ready,
        "FIGURE_DEPENDENCIES_READY": figures_ready,
        "NO_PLACEHOLDER_FIGURES": no_placeholder_figures,
        "NO_UNSUPPORTED_NAMED_POPULATION_CLAIMS": no_claims,
        "MNRAS_DEPENDENCIES_READY": mnras_ready,
        "PDF_COMPILED": pdf_ready,
        "FLAT_MNRAS_PACKAGE_READY": flat_ready,
        "HUMAN_METADATA_READY": human_ready,
        "SUBMISSION_READY": flat_ready and human_ready,
        "final_package": safe_rel(final_root, root),
        "final_zip": safe_rel(package_zip, root),
        "final_zip_size_bytes": package_zip.stat().st_size,
        "final_zip_sha256": sha256_file(package_zip)
    }
    write_json(
        out_dir / "validation/stage6c3_validation.json",
        validation
    )

    remaining = []
    if not flat_ready:
        for key in [
            "NO_INPUT_OR_INCLUDE_COMMANDS",
            "BIBLIOGRAPHY_INLINED",
            "FIGURE_DEPENDENCIES_READY",
            "NO_PLACEHOLDER_FIGURES",
            "NO_UNSUPPORTED_NAMED_POPULATION_CLAIMS",
            "MNRAS_DEPENDENCIES_READY",
            "PDF_COMPILED"
        ]:
            if not validation[key]:
                remaining.append(key)
    if not human_ready:
        remaining.append("HUMAN_METADATA_READY")

    summary = {
        "stage": STAGE,
        "timestamp_utc": utc_now(),
        "flat_main_tex_bytes": main_path.stat().st_size if main_path.exists() else 0,
        "pdf_bytes": (
            (final_root / "main.pdf").stat().st_size
            if (final_root / "main.pdf").exists() else 0
        ),
        "remaining_gates": remaining,
        "scientific_disposition": (
            "Flat claim-safe MNRAS package created. Only human-controlled metadata remains."
            if flat_ready and not human_ready
            else "Flat-package build completed; inspect the remaining gates before submission."
        )
    }
    write_json(
        out_dir / "summaries/stage6c3_summary.json",
        summary
    )

    shutil.rmtree(working_source, ignore_errors=True)

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False
    ))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
