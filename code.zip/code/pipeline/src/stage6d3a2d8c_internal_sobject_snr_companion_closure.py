from __future__ import annotations
import argparse,csv,json,re,shutil
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import pandas as pd
MAX_EXACT_FLOAT_INT=9007199254740991

def now():return datetime.now(timezone.utc).isoformat()
def norm(x):return re.sub(r"[^a-z0-9]+","_",str(x).lower()).strip("_")
def rel(p,r):
    try:return str(p.resolve().relative_to(r.resolve())).replace("\\","/")
    except:return str(p).replace("\\","/")
def wjson(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,default=str)+"\n",encoding="utf-8")
def wcsv(p,fields,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("w",newline="",encoding="utf-8") as h:
        w=csv.DictWriter(h,fieldnames=fields,extrasaction="ignore");w.writeheader();w.writerows(rows)
def resolve(p):
    for q in [p,p.with_suffix('.csv'),p.with_suffix('.feather')]:
        if q.exists():return q
    return None
def cols(p):
    if p.suffix.lower()=='.parquet':
        import pyarrow.parquet as pq
        f=pq.ParquetFile(p);return list(f.schema_arrow.names),int(f.metadata.num_rows)
    if p.suffix.lower()=='.feather':
        import pyarrow.feather as feather
        t=feather.read_table(p);return list(t.column_names),int(t.num_rows)
    return list(pd.read_csv(p,nrows=5).columns),-1
def read(p,columns=None,strings=None):
    if p.suffix.lower()=='.parquet':return pd.read_parquet(p,columns=columns)
    if p.suffix.lower()=='.feather':return pd.read_feather(p,columns=columns)
    return pd.read_csv(p,usecols=columns,dtype={c:'string' for c in (strings or [])} or None)
def find(columns,aliases):
    m={norm(c):c for c in columns}
    for a in aliases:
        if norm(a) in m:return m[norm(a)]
    return None
def exact_id(s):
    out=pd.Series(pd.NA,index=s.index,dtype='UInt64')
    if pd.api.types.is_unsigned_integer_dtype(s.dtype):return s.astype('UInt64')
    if pd.api.types.is_integer_dtype(s.dtype):
        v=s.astype('Int64');ok=v.notna()&(v>=0)
        if ok.any():out.loc[ok]=pd.array(v.loc[ok].astype('string'),dtype='UInt64')
        return out
    if pd.api.types.is_float_dtype(s.dtype):
        v=pd.to_numeric(s,errors='coerce');ok=v.notna()&np.isfinite(v)&(v==np.floor(v))&(v>=0)&(v<=MAX_EXACT_FLOAT_INT)
        if ok.any():out.loc[ok]=pd.array(v.loc[ok].astype('uint64').astype('string'),dtype='UInt64')
        return out
    t=s.astype('string').str.strip();ok=t.str.fullmatch(r'[0-9]+',na=False)
    if ok.any():
        v=t.loc[ok].str.lstrip('0').mask(lambda x:x=='','0');v=v.loc[v.str.len()<=20]
        if len(v):out.loc[v.index]=pd.array(v,dtype='UInt64')
    return out
def sobj(s):
    t=s.astype('string').str.strip();dec=t.str.fullmatch(r'[+]?[0-9]+(?:\.0+)?',na=False)
    if dec.any():
        v=t.loc[dec].str.replace(r'^\+','',regex=True).str.replace(r'\.0+$','',regex=True).str.lstrip('0').mask(lambda x:x=='','0');t.loc[dec]=v
    return t.str.upper().str.replace(r'\s+','',regex=True).replace({'':pd.NA,'NAN':pd.NA,'NONE':pd.NA})
def detect(columns,cfg):
    scalar=find(columns,cfg['scalar_snr_aliases'])
    if scalar:return 'scalar_native_snr',[scalar]
    got=[]
    for aliases in cfg['channel_groups'].values():
        c=find(columns,aliases)
        if c and c not in got:got.append(c)
    if len(got)>=int(cfg['minimum_channels']):return 'channel_median_native_snr',got
    return None,[]
def snr_values(fr,contract,scols,cfg):
    if contract=='scalar_native_snr':s=pd.to_numeric(fr[scols[0]],errors='coerce')
    else:
        v=pd.DataFrame({c:pd.to_numeric(fr[c],errors='coerce') for c in scols});n=v.notna().sum(axis=1);s=v.median(axis=1,skipna=True);s.loc[n<int(cfg['minimum_channels'])]=np.nan
    s=pd.to_numeric(s,errors='coerce');s.loc[~np.isfinite(s)|(s<=0)|(s>1e6)]=np.nan;return s
def aggregate(ids,sv,contract,lineage):
    w=pd.DataFrame({'source_id':ids,'snr_native':sv}).dropna(subset=['source_id']);w['source_id']=w['source_id'].astype('uint64');rows=[]
    for sid,g in w.groupby('source_id',sort=False):
        v=g['snr_native'].dropna().to_numpy(float);rows.append({'source_id':int(sid),'snr_native':float(np.median(v)) if len(v) else np.nan,'snr_measurement_count':int(len(v)),'snr_input_row_count':int(len(g)),'snr_contract':contract,'snr_id_route':lineage})
    return pd.DataFrame(rows)
def complete(fr):
    req=['R','abs_Z','teff','logg','snr_native','g_mag','bp_rp'];m=pd.Series(True,index=fr.index)
    for c in req:
        if c not in fr.columns:return pd.Series(False,index=fr.index)
        m &= fr[c].notna()
    sky=(fr.get('l',pd.Series(pd.NA,index=fr.index)).notna()&fr.get('b',pd.Series(pd.NA,index=fr.index)).notna())|(fr.get('ra',pd.Series(pd.NA,index=fr.index)).notna()&fr.get('dec',pd.Series(pd.NA,index=fr.index)).notna())
    return m&sky

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--project-root',default='.');args=ap.parse_args();root=Path(args.project_root).resolve();cfg=json.loads((root/'config/stage6d3a2d8c_config.json').read_text())
    out=root/cfg['output_dir'];shutil.rmtree(out,ignore_errors=True)
    for d in ['validation','tables','summaries','assembled','reports']:(out/d).mkdir(parents=True,exist_ok=True)
    pp=root/cfg['prerequisite_validation'];pre=json.loads(pp.read_text()) if pp.exists() else {};prereq=bool(pre.get('STAGE6D3A2D8B_LINEAGE_READY',False) and pre.get('EXACT_GAIA_DR3_IDENTITY_ALREADY_CLOSED',False) and not pre.get('INTERNAL_NATIVE_GALAH_SNR_READY',True))
    apath=resolve(root/cfg['canonical_anchor']);anchor=read(apath,strings=['source_id']) if apath else pd.DataFrame();anchor_ready={'source_id','survey'}.issubset(anchor.columns)
    if anchor_ready:
        aid=exact_id(anchor['source_id']);ok=aid.notna();anchor=anchor.loc[ok].copy();anchor['source_id']=aid.loc[ok].astype('uint64').to_numpy()
    anchor['_anchor_row_id']=np.arange(len(anchor),dtype=np.int64);galah_ids=set(anchor.loc[anchor['survey']=='GALAH_CORRECTED','source_id'].astype('uint64')) if anchor_ready else set()

    bridges=[];bridge_audit=[]
    for rr in cfg['population_candidates']:
        p=resolve(root/rr)
        if not p:continue
        try:
            cc,n=cols(p);sid=find(cc,cfg['source_id_aliases']);so=find(cc,cfg['sobject_aliases'])
            if not sid or not so:continue
            fr=read(p,[sid,so],strings=[sid,so]);ids=exact_id(fr[sid]);ss=sobj(fr[so]);m=pd.DataFrame({'sobject_id':ss,'source_id':ids}).dropna().drop_duplicates();conf=(m.groupby('sobject_id')['source_id'].nunique()>1);functional=not conf.any()
            if functional:m=m.drop_duplicates('sobject_id')
            ov=len(galah_ids.intersection(set(m['source_id'].astype('uint64'))))
            row={'population_path':rel(p,root),'mapping_rows':len(m),'conflicting_sobject_ids':int(conf.sum()),'functional_ready':functional,'anchor_overlap_rows':ov,'anchor_overlap_fraction':ov/max(len(galah_ids),1)};bridge_audit.append(row)
            if functional and ov>=int(cfg['minimum_overlap_rows']) and row['anchor_overlap_fraction']>=float(cfg['minimum_overlap_fraction']):bridges.append({'row':row,'map':m})
        except Exception as e:bridge_audit.append({'population_path':rel(p,root),'mapping_rows':0,'conflicting_sobject_ids':0,'functional_ready':False,'anchor_overlap_rows':0,'anchor_overlap_fraction':0.0,'read_error':f'{type(e).__name__}: {e}'})
    wcsv(out/'tables/stage6d3a2d8c_population_sobject_bridge_audit.csv',['population_path','mapping_rows','conflicting_sobject_ids','functional_ready','anchor_overlap_rows','anchor_overlap_fraction','read_error'],bridge_audit)

    companions=[];seen=set()
    for rr in cfg['companion_scan_roots']:
        b=root/rr
        if not b.exists():continue
        for p in b.rglob('*'):
            if p.is_file() and p.suffix.lower() in set(cfg['tabular_suffixes']) and rel(p,root) not in seen:
                seen.add(rel(p,root));companions.append(p)
                if len(companions)>=int(cfg['maximum_companion_files']):break
    audit=[];products=[]
    for p in companions:
        try:
            cc,n=cols(p);so=find(cc,cfg['sobject_aliases']);contract,scols=detect(cc,cfg);like=[c for c in cc if 'snr' in norm(c) or 'signal_to_noise' in norm(c)]
            row={'companion_path':rel(p,root),'row_count':n,'sobject_column':so or '','snr_contract':contract or '','snr_columns':'|'.join(scols),'all_snr_like_columns':'|'.join(like),'bridge_population_path':'','finite_source_snr_rows':0,'anchor_overlap_rows':0,'anchor_overlap_fraction':0.0,'read_error':''}
            if so and contract:
                fr=read(p,[so]+scols,strings=[so]);ss=sobj(fr[so]);sv=snr_values(fr,contract,scols,cfg);cw=pd.DataFrame({'sobject_id':ss,'snr_native':sv}).dropna(subset=['sobject_id'])
                for br in bridges:
                    j=cw.merge(br['map'],on='sobject_id',how='inner',validate='many_to_one');prod=aggregate(j['source_id'],j['snr_native'],contract,f"sobject_companion:{rel(p,root)} via {br['row']['population_path']}")
                    finite=prod[prod['snr_native'].notna()];fids=set(finite['source_id'].astype('uint64'));ov=galah_ids.intersection(fids);frac=len(ov)/max(len(galah_ids),1)
                    candidate={**row,'bridge_population_path':br['row']['population_path'],'finite_source_snr_rows':len(fids),'anchor_overlap_rows':len(ov),'anchor_overlap_fraction':frac}
                    audit.append(candidate);products.append({'row':candidate,'product':prod})
            else:audit.append(row)
        except Exception as e:audit.append({'companion_path':rel(p,root),'row_count':'','sobject_column':'','snr_contract':'','snr_columns':'','all_snr_like_columns':'','bridge_population_path':'','finite_source_snr_rows':0,'anchor_overlap_rows':0,'anchor_overlap_fraction':0.0,'read_error':f'{type(e).__name__}: {e}'})
    wcsv(out/'tables/stage6d3a2d8c_sobject_snr_companion_audit.csv',['companion_path','row_count','sobject_column','snr_contract','snr_columns','all_snr_like_columns','bridge_population_path','finite_source_snr_rows','anchor_overlap_rows','anchor_overlap_fraction','read_error'],audit)
    elig=[x for x in products if x['row']['anchor_overlap_rows']>=int(cfg['minimum_overlap_rows']) and x['row']['anchor_overlap_fraction']>=float(cfg['minimum_overlap_fraction'])]
    elig.sort(key=lambda x:(-x['row']['anchor_overlap_rows'],-x['row']['finite_source_snr_rows'],x['row']['companion_path']));selected=elig[0] if elig else None
    wcsv(out/'tables/stage6d3a2d8c_selected_sobject_snr_companion.csv',['companion_path','sobject_column','snr_contract','snr_columns','bridge_population_path','finite_source_snr_rows','anchor_overlap_rows','anchor_overlap_fraction'],[selected['row']] if selected else [])

    final=anchor.copy()
    if selected:
        prod=selected['product'].set_index('source_id');gm=final['survey']=='GALAH_CORRECTED';keys=final.loc[gm,'source_id'].astype('uint64')
        for f in ['snr_native','snr_measurement_count','snr_input_row_count','snr_contract','snr_id_route']:
            if f not in final.columns:final[f]=np.nan if f=='snr_native' else pd.NA
            final.loc[gm,f]=keys.map(prod[f]).to_numpy()
    row_ok=bool(len(final)==len(anchor) and final['_anchor_row_id'].tolist()==anchor['_anchor_row_id'].tolist() and final['source_id'].astype('uint64').tolist()==anchor['source_id'].astype('uint64').tolist() and final['survey'].astype(str).tolist()==anchor['survey'].astype(str).tolist() and not final.duplicated(['source_id','survey']).any())
    support=complete(final);counts={s:int(((final['survey']==s)&support).sum()) for s in ['APOGEE_NATIVE','GALAH_CORRECTED']};snr_ready=selected is not None;complete_ready=all(v>=int(cfg['minimum_complete_rows_per_survey']) for v in counts.values());source_ready=bool(prereq and anchor_ready and snr_ready and row_ok and complete_ready)
    fp=out/'assembled/stage6d3a2d8c_production_source_with_sobject_native_snr.parquet'
    try:final.drop(columns=['_anchor_row_id']).to_parquet(fp,index=False)
    except Exception:fp=fp.with_suffix('.csv');final.drop(columns=['_anchor_row_id']).to_csv(fp,index=False)
    if snr_ready:diagnosis='INTERNAL_SOBJECT_NATIVE_GALAH_SNR_LINEAGE_READY'
    elif any(r.get('all_snr_like_columns') for r in audit):diagnosis='SOBJECT_SNR_COLUMNS_PRESENT_BUT_CONTRACT_UNRESOLVED'
    else:diagnosis='NO_INTERNAL_SOBJECT_NATIVE_SNR_COMPANION'
    rem=[] if snr_ready else [{'gate':'INTERNAL_SOBJECT_NATIVE_GALAH_SNR_READY','required_action':'Inspect the companion audit exact S/N-like column names. If they are raw GALAH native S/N under a documented upstream schema, add only that exact contract; otherwise reacquire native S/N, not a Gaia-ID bridge.'}]
    wcsv(out/'tables/stage6d3a2d8c_remaining_items.csv',['gate','required_action'],rem)
    val={'stage':cfg['stage'],'implementation_version':cfg['implementation_version'],'timestamp_utc':now(),'diagnosis':diagnosis,'canonical_galah_anchor_rows':len(galah_ids),'selected_companion_path':selected['row']['companion_path'] if selected else '','selected_population_bridge_path':selected['row']['bridge_population_path'] if selected else '','selected_anchor_overlap_rows':selected['row']['anchor_overlap_rows'] if selected else 0,'selected_anchor_overlap_fraction':selected['row']['anchor_overlap_fraction'] if selected else 0.0,'assembled_source_table':rel(fp,root),'assembled_rows':len(final),'support_complete_rows_by_survey':counts,'STAGE6D3A2D8B_PREREQUISITE_READY':prereq,'CANONICAL_ANCHOR_READY':anchor_ready,'EXACT_GAIA_DR3_IDENTITY_ALREADY_CLOSED':True,'POPULATION_SOBJECT_TO_GAIA_BRIDGE_READY':bool(bridges),'SOBJECT_SNR_COMPANION_AUDIT_READY':True,'INTERNAL_SOBJECT_NATIVE_GALAH_SNR_READY':snr_ready,'EXTERNAL_GAIA_ID_BRIDGE_ACQUISITION_REQUIRED':False,'FINAL_ROW_CONSERVATION_READY':row_ok,'PRODUCTION_SOURCE_COMPLETE_ROWS_READY':complete_ready,'PRODUCTION_SOURCE_ASSEMBLY_READY':source_ready,'FROZEN_OVERLAP_GATES_UNCHANGED':True,'TARGET_ABUNDANCE_MATCHING_FORBIDDEN':True,'STAGE6D3A2D8C_LINEAGE_READY':bool(prereq and anchor_ready and row_ok),'STAGE6D3B_COMMON_FOOTPRINT_READY':source_ready}
    wjson(out/'validation/stage6d3a2d8c_validation.json',val);wjson(out/'summaries/stage6d3a2d8c_summary.json',{'diagnosis':diagnosis,'remaining_items':rem});print(json.dumps({'validation':val},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
