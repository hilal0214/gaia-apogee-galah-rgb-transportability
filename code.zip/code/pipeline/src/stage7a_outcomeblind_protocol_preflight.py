from __future__ import annotations
import argparse,hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
import numpy as np,pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def canonical_sha(o):
    return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def wj(p,o):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");a=ap.parse_args()
    root=Path(a.project_root).resolve();c=json.loads((root/"config/stage7a_config.json").read_text());p=json.loads((root/c["protocol"]).read_text())
    out=root/c["output_dir"]
    if out.exists():shutil.rmtree(out)
    for d in ["validation","freeze","tables","reports","manifest"]:(out/d).mkdir(parents=True,exist_ok=True)
    d5=json.loads((root/c["d5a_validation"]).read_text());d5_ready=bool(d5.get("STAGE6D5A_MANUSCRIPT_CLAIM_INTEGRATION_READY") and d5.get("STAGE6D5B_ARCHIVAL_RELEASE_READY"))
    src=root/c["d3c9_balanced_source"]
    if not src.exists():raise FileNotFoundError(str(src))
    allowed=c["allowed_columns_to_read"];forbidden=[x.lower() for x in c["forbidden_outcome_tokens"]]
    if any(any(t in col.lower() for t in forbidden) for col in allowed):raise RuntimeError("Outcome leakage in Stage7A allowed-column list")
    df=pd.read_parquet(src,columns=allowed)
    rows=len(df);cells=int(df["healpix_gal_ring_nside16"].nunique());surveys=sorted(df["survey"].astype(str).unique().tolist());sid_unique=bool(df["source_id"].nunique(dropna=False)==rows)
    num=np.isfinite(pd.to_numeric(df["R"],errors="coerce")) & np.isfinite(pd.to_numeric(df["abs_Z"],errors="coerce"));finite_frac=float(num.mean())
    weights=pd.to_numeric(df["balance_weight_final"],errors="coerce").to_numpy(float);weights_ready=bool(np.all(np.isfinite(weights)) and np.all(weights>0))
    R=pd.to_numeric(df["R"],errors="coerce").to_numpy(float);cell=df["healpix_gal_ring_nside16"].to_numpy();survey=df["survey"].astype(str).to_numpy()
    support=[];support_all=True;sg=p["support_gates"]
    for rb in p["break_search"]["grid_values"]:
        left=np.isfinite(R)&(R<=rb);right=np.isfinite(R)&(R>rb)
        rec={"R_break_kpc":rb,"rows_left":int(left.sum()),"rows_right":int(right.sum()),"cells_left":int(pd.Series(cell[left]).nunique()),"cells_right":int(pd.Series(cell[right]).nunique())}
        for s in ["APOGEE_NATIVE","GALAH_CORRECTED"]:
            rec[f"{s}_left"]=int((left&(survey==s)).sum());rec[f"{s}_right"]=int((right&(survey==s)).sum())
        rec["support_ready"]=bool(rec["rows_left"]>=sg["minimum_rows_each_side_of_every_break_candidate"] and rec["rows_right"]>=sg["minimum_rows_each_side_of_every_break_candidate"] and rec["cells_left"]>=sg["minimum_cells_each_side_of_every_break_candidate"] and rec["cells_right"]>=sg["minimum_cells_each_side_of_every_break_candidate"] and rec["APOGEE_NATIVE_left"]>=sg["minimum_rows_per_survey_each_side_of_every_break_candidate"] and rec["APOGEE_NATIVE_right"]>=sg["minimum_rows_per_survey_each_side_of_every_break_candidate"] and rec["GALAH_CORRECTED_left"]>=sg["minimum_rows_per_survey_each_side_of_every_break_candidate"] and rec["GALAH_CORRECTED_right"]>=sg["minimum_rows_per_survey_each_side_of_every_break_candidate"])
        support_all &= rec["support_ready"];support.append(rec)
    pd.DataFrame(support).to_csv(out/"tables/stage7a_break_grid_support_audit.csv",index=False)
    shape_ready=bool(rows==sg["common_input_rows_expected"] and cells==sg["common_primary_nside16_cells_expected"]);survey_ready=set(surveys)=={"APOGEE_NATIVE","GALAH_CORRECTED"};finite_ready=finite_frac>=float(sg["minimum_finite_R_absZ_fraction"])
    protocol_sha=canonical_sha(p);lit=json.loads((root/"protocol/stage7a_literature_anchor_ledger.json").read_text());lit_sha=canonical_sha(lit)
    ready=bool(d5_ready and shape_ready and sid_unique and survey_ready and finite_ready and weights_ready and support_all)
    val={"stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),"protocol_canonical_sha256":protocol_sha,"literature_anchor_ledger_canonical_sha256":lit_sha,"D5A_PREREQUISITE_READY":d5_ready,"OUTCOME_COLUMN_PROJECTION_GUARD_READY":True,"OUTCOME_VALUES_READ":False,"COMMON_INPUT_ROWS":rows,"COMMON_NSIDE16_CELLS":cells,"COMMON_INPUT_SHAPE_READY":shape_ready,"SOURCE_ID_UNIQUE_READY":sid_unique,"SURVEY_IDENTITY_READY":survey_ready,"FINITE_R_ABSZ_FRACTION":finite_frac,"FINITE_R_ABSZ_READY":finite_ready,"POSITIVE_FINITE_BALANCE_WEIGHTS_READY":weights_ready,"BREAK_GRID_SUPPORT_READY":bool(support_all),"BREAK_GRID_START_KPC":p["break_search"]["grid_start"],"BREAK_GRID_STOP_KPC":p["break_search"]["grid_stop"],"BREAK_GRID_N":len(p["break_search"]["grid_values"]),"NESTED_SPATIAL_CV_FROZEN_READY":True,"INJECTION_RECOVERY_BEFORE_REAL_OUTCOME_FROZEN_READY":True,"AZIMUTH_CONFOUNDING_AUDIT_FROZEN_READY":True,"NO_CAUSAL_BAR_CLAIM_AUTHORIZED":True,"NO_REAL_FEH_FIT_PERFORMED":True,"STAGE7A_PROTOCOL_FROZEN":ready,"STAGE7B_INJECTION_RECOVERY_READY":ready}
    wj(out/"validation/stage7a_validation.json",val);shutil.copy2(root/c["protocol"],out/"freeze/stage7a_radial_break_protocol_frozen.json");shutil.copy2(root/"protocol/stage7a_literature_anchor_ledger.json",out/"freeze/stage7a_literature_anchor_ledger_frozen.json")
    report=f"""# Stage-7A radial-break protocol freeze\n\nProtocol frozen: `{ready}`\n\nThis stage reads only source ID, survey identity, R, |Z|, primary NSIDE16 cell, and the already-frozen D3C9 balance weight. No abundance or residual values are read.\n\nBreak search grid: {p['break_search']['grid_start']:.1f}--{p['break_search']['grid_stop']:.1f} kpc in {p['break_search']['grid_step']:.1f}-kpc steps.\n\nReal [Fe/H] fitting is forbidden until Stage-7B injection-recovery passes.\n"""
    (out/"reports/stage7a_report.md").write_text(report,encoding="utf-8")
    manifest=[]
    for fp in sorted(out.rglob("*")):
        if fp.is_file() and "manifest" not in fp.parts:manifest.append({"path":str(fp.relative_to(root)).replace("\\","/"),"size_bytes":fp.stat().st_size,"sha256":sha(fp)})
    pd.DataFrame(manifest).to_csv(out/"manifest/stage7a_manifest_sha256.csv",index=False)
    print(json.dumps({"validation":val},indent=2,ensure_ascii=False));return 0 if ready else 2
if __name__=="__main__":raise SystemExit(main())
