from __future__ import annotations
import argparse,hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
import pyarrow.parquet as pq

def now(): return datetime.now(timezone.utc).isoformat()
def canon(o):
    return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage8c_config.json").read_text(encoding="utf-8"))
    p=json.loads((root/"protocol/stage8c_real_alpha_morphology_protocol.json").read_text(encoding="utf-8"))
    pv=root/c["parent_validation"]
    src=root/c["source"]
    if not pv.exists(): raise FileNotFoundError(pv)
    if not src.exists(): raise FileNotFoundError(src)
    v=json.loads(pv.read_text(encoding="utf-8"))

    parent_ready=bool(
      v.get("STAGE8B2_FORMAL_POWER_CALIBRATION_PASS") is True and
      v.get("STAGE8C_REAL_INFERENCE_PROTOCOL_CONSTRUCTION_READY") is True and
      v.get("FORMAL_NULL_FPR_GATE_PASS") is True and
      v.get("ALL_SIX_STRONG_SIGNED_TARGET_POWER_GATES_PASS") is True and
      v.get("ALL_SIX_STRONG_SIGNED_TARGET_EFFECT_BIAS_GATES_PASS") is True and
      v.get("FORMAL_SYNTHETIC_FIT_FAILURES")==0 and
      v.get("REAL_ALPHA3_MIXTURE_FIT_PERFORMED") is False and
      v.get("REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED") is False and
      v.get("STAGE8_REAL_MIXTURE_INTERPRETATION_AUTHORIZED") is False and
      v.get("PROTOCOL_CANONICAL_SHA256")==c["expected_parent_protocol_sha256"]
    )
    if not parent_ready:
        raise RuntimeError("Stage-8B2 formal parent guards failed")

    schema=pq.ParquetFile(src).schema_arrow.names
    req=["source_id","survey","R","abs_Z","fe_h","alpha3_hom",
         "alpha3_gradient_primary_ok","fe_h_gradient_primary_ok",
         "healpix_gal_ring_nside16","balance_weight_final"]
    schema_ready=all(x in schema for x in req)
    if not schema_ready:
        raise RuntimeError(f"Stage-8C source schema missing: {[x for x in req if x not in schema]}")

    # Internal protocol consistency checks only; no row values are read.
    margins=p["practical_margins"]
    knots=p["data_contract"]["primary_knots"]
    internal=bool(
      knots==c["primary_knots"] and
      p["data_contract"]["audit_only_low_support"]["knot"]==-0.8 and
      p["data_contract"]["audit_only_low_support"]["disposition"]=="LOW_SUPPORT_NOT_TESTABLE" and
      p["uncertainty"]["draws"]==4096 and
      p["uncertainty"]["seed"]==c["bootstrap_seed"] and
      p["uncertainty"]["minimum_valid_draw_fraction_per_knot_estimand"]==0.95 and
      margins=={"valley":0.03,"separation":0.04,"fraction":0.08} and
      p["real_fit_authorization"]["this_stage_performs_real_mixture_fit"] is False and
      p["claim_boundaries"]["indeterminate_does_not_mean_nontransportable"] is True
    )
    if not internal:
        raise RuntimeError("Stage-8C internal protocol consistency failed")

    out=root/c["output_dir"]
    for q in ["freeze","validation"]: (out/q).mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/"protocol/stage8c_real_alpha_morphology_protocol.json",
                 out/"freeze/stage8c_real_alpha_morphology_protocol_frozen.json")

    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "STAGE8B2_FORMAL_PARENT_READY":parent_ready,
      "STAGE8C_SOURCE_SCHEMA_READY":schema_ready,
      "STAGE8C_INTERNAL_PROTOCOL_CONSISTENCY_READY":internal,
      "PRIMARY_KNOTS":c["primary_knots"],
      "AUDIT_ONLY_MINUS0P8_DISPOSITION":"LOW_SUPPORT_NOT_TESTABLE",
      "BOOTSTRAP_DRAWS":4096,
      "BOOTSTRAP_UNIT":"paired NSIDE16 common-footprint cell",
      "PRACTICAL_MARGINS":margins,
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":False,
      "REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED":False,
      "REAL_DATA_ROW_VALUES_READ_BY_STAGE8C":False,
      "STAGE8C_REAL_INFERENCE_PROTOCOL_FROZEN":True,
      "STAGE8D_REAL_ALPHA_MORPHOLOGY_INFERENCE_READY":True,
      "POST_REAL_FIT_GATE_CHANGES_FORBIDDEN":True,
      "PROTOCOL_CANONICAL_SHA256":canon(p)
    }
    write_json(out/"validation/stage8c_validation.json",val)
    print(json.dumps(val,indent=2,ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
