from __future__ import annotations
import argparse, json, hashlib
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\\n",encoding="utf-8")
def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()
def wilson(k,n,z=1.959963984540054):
    if n<=0: return (np.nan,np.nan)
    ph=k/n; den=1+z*z/n
    ctr=(ph+z*z/(2*n))/den
    half=z*np.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
    return float(max(0,ctr-half)),float(min(1,ctr+half))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve(); b2=root/"outputs/stage7b2_full_signed_injection_recovery"
    val=json.loads((b2/"validation/stage7b2_validation.json").read_text(encoding="utf-8"))
    if not val.get("STAGE7B2_FORMAL_COMPLETE"): raise RuntimeError("Stage-7B2 formal production is not complete")
    if val.get("REAL_FEH_M1_BREAK_FIT_PERFORMED") is not False: raise RuntimeError("Real Fe/H M1 leakage guard failed")
    if val.get("STAGE7C_REAL_BREAK_FIT_AUTHORIZED") is not False: raise RuntimeError("Stage-7C is already authorized; B2C failure diagnostic not applicable")
    pq=b2/"tables/stage7b2_formal_replicates.parquet"; smp=b2/"tables/stage7b2_signed_scenario_summary.csv"
    if not pq.exists() or not smp.exists(): raise FileNotFoundError("Stage-7B2 replicate/summary table missing")
    df=pd.read_parquet(pq); _=pd.read_csv(smp,keep_default_na=False,na_values=["","NaN","nan"])
    out=root/"outputs/stage7b2c_synthetic_power_envelope_diagnostics"
    for d in ["tables","validation","reports","manifest"]: (out/d).mkdir(parents=True,exist_ok=True)
    inj=df[df["kind"]=="INJECTED"].copy()
    req={"R_break_kpc","delta_beta","detected_rule","predictive_p","wald_excludes_zero","boundary_flag","sign_correct","break_abs_error_kpc","selected_break_kpc","median_outer_cv_improvement"}
    miss=req-set(inj.columns)
    if miss: raise RuntimeError(f"missing columns: {sorted(miss)}")
    rows=[]
    for (rb,delta),g in inj.groupby(["R_break_kpc","delta_beta"],sort=True):
        n=len(g); det=int(g["detected_rule"].astype(bool).sum()); lo,hi=wilson(det,n)
        rows.append({"R_break_kpc":float(rb),"delta_beta":float(delta),"abs_delta_beta":float(abs(delta)),"sign":"positive" if float(delta)>0 else "negative","replicates":int(n),"detection_power":det/n,"power_wilson95_low":lo,"power_wilson95_high":hi,"predictive_gate_fraction":float((g["predictive_p"]<=0.05).mean()),"wald_gate_fraction":float(g["wald_excludes_zero"].astype(bool).mean()),"nonboundary_fraction":float((~g["boundary_flag"].astype(bool)).mean()),"sign_correct_fraction":float(g["sign_correct"].astype(bool).mean()),"median_abs_break_error_kpc":float(g["break_abs_error_kpc"].median()),"q84_abs_break_error_kpc":float(g["break_abs_error_kpc"].quantile(.84)),"median_cv_improvement":float(g["median_outer_cv_improvement"].median()),"median_selected_break_kpc":float(g["selected_break_kpc"].median())})
    env=pd.DataFrame(rows).sort_values(["R_break_kpc","delta_beta"]); env.to_csv(out/"tables/stage7b2c_power_envelope.csv",index=False)
    comb=[]
    tmp=inj.assign(abs_delta_beta=np.abs(inj["delta_beta"].astype(float)))
    for (rb,mag),g in tmp.groupby(["R_break_kpc","abs_delta_beta"],sort=True):
        n=len(g); det=int(g["detected_rule"].astype(bool).sum()); lo,hi=wilson(det,n)
        comb.append({"R_break_kpc":float(rb),"abs_delta_beta":float(mag),"replicates":int(n),"signed_combined_power":det/n,"power_wilson95_low":lo,"power_wilson95_high":hi,"median_abs_break_error_kpc":float(g["break_abs_error_kpc"].median()),"predictive_gate_fraction":float((g["predictive_p"]<=0.05).mean()),"wald_gate_fraction":float(g["wald_excludes_zero"].astype(bool).mean()),"nonboundary_fraction":float((~g["boundary_flag"].astype(bool)).mean())})
    pd.DataFrame(comb).sort_values(["R_break_kpc","abs_delta_beta"]).to_csv(out/"tables/stage7b2c_signcombined_power_envelope.csv",index=False)
    mde=[]
    for rb in sorted(env["R_break_kpc"].unique()):
        er=env[env["R_break_kpc"]==rb]; qualifying=[]
        for mag in sorted(er["abs_delta_beta"].unique()):
            q=er[np.isclose(er["abs_delta_beta"],mag)]
            if len(q)==2 and (q["detection_power"]>=0.80).all() and (q["median_abs_break_error_kpc"]<=0.5).all(): qualifying.append(float(mag))
        mde.append({"R_break_kpc":float(rb),"smallest_tested_abs_delta_meeting_both_sign_power_and_error_gates":min(qualifying) if qualifying else np.nan,"any_tested_strength_meets_both_sign_gates":bool(qualifying)})
    pd.DataFrame(mde).to_csv(out/"tables/stage7b2c_minimum_detectable_strength_grid.csv",index=False)
    target=inj[inj["R_break_kpc"].isin([6.0,6.5]) & np.isclose(np.abs(inj["delta_beta"].astype(float)),0.05)].copy()
    dec=[]
    for (rb,delta),g in target.groupby(["R_break_kpc","delta_beta"],sort=True):
        pred=(g["predictive_p"]<=0.05); wald=g["wald_excludes_zero"].astype(bool); nonb=~g["boundary_flag"].astype(bool); sign=g["sign_correct"].astype(bool)
        dec.append({"R_break_kpc":float(rb),"delta_beta":float(delta),"replicates":len(g),"fail_predictive_fraction":float((~pred).mean()),"fail_wald_fraction":float((~wald).mean()),"fail_boundary_fraction":float((~nonb).mean()),"fail_sign_fraction":float((~sign).mean()),"all_detection_gates_pass_fraction":float((pred&wald&nonb&sign).mean()),"median_abs_break_error_kpc":float(g["break_abs_error_kpc"].median())})
    pd.DataFrame(dec).to_csv(out/"tables/stage7b2c_target_failure_decomposition.csv",index=False)
    target05=env[env["R_break_kpc"].isin([6.0,6.5]) & np.isclose(env["abs_delta_beta"],0.05)]
    target07=env[env["R_break_kpc"].isin([6.0,6.5]) & np.isclose(env["abs_delta_beta"],0.07)]
    target05_fail=bool(len(target05)==4 and ((target05["detection_power"]<0.80).any() or (target05["median_abs_break_error_kpc"]>0.5).any()))
    target07_allpass=bool(len(target07)==4 and (target07["detection_power"]>=0.80).all() and (target07["median_abs_break_error_kpc"]<=0.5).all())
    if target07_allpass:
        disposition="CURRENT_DESIGN_POWERED_ONLY_FOR_STRONGER_BREAKS"
        rec="Do not open real M1 under the frozen 0.05 target claim. The present design supports only stronger-break detectability; any new estimand must be re-frozen before real M1."
    else:
        disposition="CURRENT_DESIGN_NOT_RELIABLY_POWERED_FOR_RADIAL_BREAK_LOCALIZATION"
        rec="Do not open real M1. The common-support plus free-break spatial-CV design does not meet the frozen adjudication goal even at the strongest tested synthetic target in all sign/location cases. Prefer closing or reframing the branch rather than weakening gates."
    summary={"stage":"Stage-7B2C synthetic-only power-envelope diagnostics","implementation_version":"0.35.0","timestamp_utc":now(),"SOURCE_STAGE7B2_FORMAL_COMPLETE":True,"REAL_FEH_M1_BREAK_FIT_PERFORMED":False,"REAL_BREAK_GRID_SCANNED":False,"STAGE7C_REAL_BREAK_FIT_AUTHORIZED":False,"FROZEN_TARGET_ABS_DELTA_0P05_FAIL_CONFIRMED":target05_fail,"ALL_FOUR_TARGET_0P07_SIGN_LOCATION_SCENARIOS_PASS":target07_allpass,"DISPOSITION":disposition,"RECOMMENDATION":rec}
    write_json(out/"validation/stage7b2c_validation.json",summary)
    lines=["# Stage-7B2C synthetic power-envelope diagnostics","",f"Disposition: **{disposition}**","","No real Fe/H broken-profile fit or real break-grid scan is performed.","","## Frozen target |delta_beta|=0.05"]
    for _,r in target05.sort_values(["R_break_kpc","delta_beta"]).iterrows(): lines.append(f"- Rb={r.R_break_kpc:.1f}, delta={r.delta_beta:+.2f}: power={r.detection_power:.3f}, median break error={r.median_abs_break_error_kpc:.3f} kpc")
    lines += ["","## Strongest tested |delta_beta|=0.07"]
    for _,r in target07.sort_values(["R_break_kpc","delta_beta"]).iterrows(): lines.append(f"- Rb={r.R_break_kpc:.1f}, delta={r.delta_beta:+.2f}: power={r.detection_power:.3f}, median break error={r.median_abs_break_error_kpc:.3f} kpc")
    lines += ["",rec]
    (out/"reports/stage7b2c_report.md").write_text("\\n".join(lines)+"\\n",encoding="utf-8")
    man=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and "manifest" not in p.parts: man.append({"path":str(p.relative_to(root)).replace("\\\\","/"),"size_bytes":p.stat().st_size,"sha256":sha_file(p)})
    pd.DataFrame(man).to_csv(out/"manifest/stage7b2c_manifest_sha256.csv",index=False)
    print(json.dumps(summary,indent=2,ensure_ascii=False))
    print("\\nTARGET_0P05")
    print(target05[["R_break_kpc","delta_beta","detection_power","median_abs_break_error_kpc"]].to_string(index=False))
    print("\\nTARGET_0P07")
    print(target07[["R_break_kpc","delta_beta","detection_power","median_abs_break_error_kpc"]].to_string(index=False))
    return 0
if __name__=="__main__": raise SystemExit(main())
