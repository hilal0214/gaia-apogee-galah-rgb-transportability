from __future__ import annotations
import argparse,json,hashlib
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd
import numpy as np

def now(): return datetime.now(timezone.utc).isoformat()
def canon(o): return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage8f_config.json").read_text())
    p=json.loads((root/"protocol/stage8f_protocol.json").read_text())
    pv=json.loads((root/c["parent_validation"]).read_text())

    parent=bool(
      pv.get("STAGE8E_CLAIM_SAFE_INTEGRATION_COMPLETE") is True and
      pv.get("FROZEN_OVERALL_CLASSIFICATION")=="INDETERMINATE" and
      pv.get("REAL_MIXTURE_REFIT_PERFORMED") is False and
      pv.get("PRACTICAL_MARGINS_CHANGED") is False and
      pv.get("FROZEN_CLASSIFICATION_CHANGED") is False
    )
    if not parent: raise RuntimeError("Stage-8E parent guards failed")

    ci=pd.read_csv(root/c["intervals"])
    dr=pd.read_csv(root/c["resolution"])
    cl=pd.read_csv(root/c["classification"])

    if set(cl["classification"].astype(str))!={"INDETERMINATE"}:
        raise RuntimeError("Frozen classification identity changed")

    sep=ci[ci["estimand"]=="separation"].copy()
    sep["zero_excluded_negative"]=sep["ci_high"]<0

    piv=dr.pivot(index="feh_knot",columns="survey",values="component_resolution_ratio").reset_index()
    piv=piv.rename(columns={
      "APOGEE_NATIVE":"D_res_APOGEE",
      "GALAH_CORRECTED":"D_res_GALAH"
    })
    tab=sep.merge(piv,on="feh_knot",how="left",validate="one_to_one")
    tab["D_res_min_between_surveys"]=tab[["D_res_APOGEE","D_res_GALAH"]].min(axis=1)
    tab["D_res_ratio_GALAH_over_APOGEE"]=tab["D_res_GALAH"]/tab["D_res_APOGEE"]
    tab["interpretation_note"]=tab.apply(
      lambda r: (
        "zero-excluding negative separation; comparatively well-resolved in both surveys"
        if r["zero_excluded_negative"] and r["D_res_min_between_surveys"]>=2.0 else
        "zero-excluding negative separation; interpret cautiously because at least one survey has overlapping fitted components"
        if r["zero_excluded_negative"] else
        "no zero-excluding separation difference"
      ),axis=1
    )

    # IMPORTANT: D_res>=2 flag is descriptive labeling only, never a new inference gate.
    # It is supplied merely to identify where both components are visually/parametrically separated.
    tab["descriptive_both_Dres_ge_2"]=(
        (tab["D_res_APOGEE"]>=2.0)&(tab["D_res_GALAH"]>=2.0)
    )
    tab["descriptive_threshold_has_classification_role"]=False

    well=tab[tab["zero_excluded_negative"] & tab["descriptive_both_Dres_ge_2"]]
    caution=tab[tab["zero_excluded_negative"] & ~tab["descriptive_both_Dres_ge_2"]]

    core_claim = (
      "The frozen overall morphology classification remains INDETERMINATE. "
      "Negative GALAH-minus-APOGEE sequence-separation differences exclude zero at four adjacent knots, "
      "but the mixture-identifiability context is not uniform across those knots. "
      "At [Fe/H]=-0.6 and -0.4, both surveys have comparatively well-separated fitted components "
      "(D_res>2 in each survey), so the negative separation offsets are the cleanest descriptive evidence "
      "for a survey-scale contraction of the fitted sequence separation. "
      "At [Fe/H]=-0.2 and 0.0, at least one survey has strongly overlapping fitted components, "
      "so the fitted separation is weakly identifiable and must not be promoted to a precise physical "
      "four-knot sequence-contraction claim. No frozen classification or practical margin is changed."
    )

    manuscript = r"""\paragraph{Identifiability of the two-sequence decomposition.}
The frozen morphology classification remains \emph{indeterminate}.  Although the
GALAH-minus-APOGEE sequence-separation difference is negative with a 95\% interval excluding
zero at four adjacent metallicity knots, the identifiability of the two-component decomposition is
not uniform across this range.  At $[\mathrm{Fe/H}]=-0.6$ and $-0.4$, the fitted components are
comparatively well separated in both surveys, and these bins provide the cleanest descriptive
evidence that GALAH yields a smaller fitted low-$\alpha$/high-$\alpha$ separation than APOGEE.
At $[\mathrm{Fe/H}]=-0.2$ and especially near solar metallicity, one or both fitted mixtures are
strongly overlapping, so the separation and mixture-fraction parameters become weakly identified
descriptive summaries rather than precise physical sequence properties.  We therefore do not
interpret the four-knot zero-exclusion pattern as a robust four-bin physical contraction, and none
of these post-hoc resolution diagnostics alter the pre-specified transport classification.
"""

    out=root/c["output_dir"]
    for d in ["tables","validation","text","freeze"]:
        (out/d).mkdir(parents=True,exist_ok=True)
    tab.to_csv(out/"tables/stage8f_separation_identifiability_audit.csv",index=False)
    (out/"text/stage8f_claimsafe_core_claim.txt").write_text(core_claim+"\n",encoding="utf-8")
    (out/"text/stage8f_manuscript_identifiability_snippet.tex").write_text(manuscript,encoding="utf-8")
    (out/"freeze/stage8f_protocol_frozen.json").write_text(
        (root/"protocol/stage8f_protocol.json").read_text(),encoding="utf-8")

    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "STAGE8E_PARENT_READY":parent,
      "FROZEN_OVERALL_CLASSIFICATION":"INDETERMINATE",
      "ZERO_EXCLUDING_NEGATIVE_SEPARATION_KNOTS":int(tab["zero_excluded_negative"].sum()),
      "ZERO_EXCLUDING_NEGATIVE_WITH_BOTH_DRES_GE_2_KNOTS":int((tab["zero_excluded_negative"] & tab["descriptive_both_Dres_ge_2"]).sum()),
      "ZERO_EXCLUDING_NEGATIVE_WITH_OVERLAP_CAUTION_KNOTS":int((tab["zero_excluded_negative"] & ~tab["descriptive_both_Dres_ge_2"]).sum()),
      "CLEANEST_DESCRIPTIVE_KNOTS":[float(x) for x in well["feh_knot"].tolist()],
      "OVERLAP_CAUTION_ZERO_EXCLUDING_KNOTS":[float(x) for x in caution["feh_knot"].tolist()],
      "REAL_MIXTURE_REFIT_PERFORMED":False,
      "NEW_BOOTSTRAP_PERFORMED":False,
      "NEW_CLASSIFICATION_GATE_INTRODUCED":False,
      "DRES_THRESHOLD_USED_FOR_RECLASSIFICATION":False,
      "PRACTICAL_MARGINS_CHANGED":False,
      "FROZEN_CLASSIFICATION_CHANGED":False,
      "IDENTIFIABILITY_CAVEAT_READY":True,
      "STAGE8F_IDENTIFIABILITY_CLAIM_CLOSURE_COMPLETE":True,
      "D6C_MANUSCRIPT_SCIENCE_INTEGRATION_READY":True,
      "PROTOCOL_CANONICAL_SHA256":canon(p)
    }
    write_json(out/"validation/stage8f_validation.json",val)
    print(json.dumps(val,indent=2,ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
