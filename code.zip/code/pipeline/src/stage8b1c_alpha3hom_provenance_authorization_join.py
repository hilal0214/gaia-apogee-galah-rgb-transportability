from __future__ import annotations
import argparse,hashlib,json
from datetime import datetime,timezone
from pathlib import Path
import numpy as np,pandas as pd
import pyarrow.parquet as pq

def now(): return datetime.now(timezone.utc).isoformat()
def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage8b1c_config.json").read_text(encoding="utf-8"))

    st2=root/c["stage2c_validation"]
    st4d=root/c["stage4a_design"]
    st4def=root/c["stage4a_definition"]
    d4cfg=root/c["stage6d4a_config"]
    bal=root/c["balanced_source"]
    for p in [st2,st4d,st4def,d4cfg,bal]:
        if not p.exists(): raise FileNotFoundError(p)

    v2=json.loads(st2.read_text(encoding="utf-8"))
    def4=json.loads(st4def.read_text(encoding="utf-8"))
    cfg4=json.loads(d4cfg.read_text(encoding="utf-8"))

    # Locate explicit frozen-definition evidence without interpreting observed row values.
    v2text=json.dumps(v2,ensure_ascii=False).lower()
    definition_ready=(
        "alpha3" in v2text and
        "unweighted mg-si-ca mean" in v2text and
        "requires all three primary labels" in v2text
    )

    label_map=cfg4.get("label_columns",cfg4.get("label_map",cfg4.get("labels",{})))
    flag_map=cfg4.get("flag_columns",cfg4.get("label_flags",cfg4.get("flags",{})))

    # Be robust to known config nesting by searching all dict string pairs.
    def find_pair(obj,key,value):
        if isinstance(obj,dict):
            for k,v in obj.items():
                if str(k)==key and str(v)==value: return True
                if find_pair(v,key,value): return True
        elif isinstance(obj,list):
            return any(find_pair(x,key,value) for x in obj)
        return False

    map_ready=find_pair(cfg4,"alpha3","alpha3_hom")
    flag_ready=find_pair(cfg4,"alpha3","alpha3_gradient_primary_ok")

    schema=pq.ParquetFile(st4d).schema_arrow.names
    storage_ready=(c["alpha_frozen_column"] in schema and c["alpha_primary_flag"] in schema)
    keys=c["join_keys"]
    key_schema_ready=all(k in schema for k in keys)

    b=pd.read_parquet(bal)
    cols=keys+[c["alpha_frozen_column"],c["alpha_primary_flag"]]
    d=pd.read_parquet(st4d,columns=cols)

    if pd.api.types.is_float_dtype(b["source_id"].dtype) or pd.api.types.is_float_dtype(d["source_id"].dtype):
        raise RuntimeError("source_id float coercion forbidden")
    if len(b)!=int(c["expected_balanced_rows"]):
        raise RuntimeError(f"balanced row identity mismatch: {len(b)}")

    if b.duplicated(keys).any():
        raise RuntimeError("balanced join keys are not unique")

    # Stage4A duplicates only allowed if attached values agree exactly.
    if d.duplicated(keys).any():
        bad=0
        for _,g in d.groupby(keys,dropna=False,sort=False):
            if len(g)<=1: continue
            av=pd.to_numeric(g[c["alpha_frozen_column"]],errors="coerce")
            fv=av[np.isfinite(av)]
            if len(fv)>1 and float(fv.max()-fv.min())!=0.0: bad+=1
            if g[c["alpha_primary_flag"]].astype(str).nunique(dropna=False)>1: bad+=1
        if bad: raise RuntimeError(f"non-identical Stage4A duplicate-key groups: {bad}")
        d=d.drop_duplicates(keys,keep="first")

    # Join via exact canonical string representation, preserving original source_id column untouched.
    b2=b.copy(); d2=d.copy()
    b2["_sid"]=b2["source_id"].astype(str); d2["_sid"]=d2["source_id"].astype(str)
    b2["_survey"]=b2["survey"].astype(str); d2["_survey"]=d2["survey"].astype(str)
    keep=["_sid","_survey",c["alpha_frozen_column"],c["alpha_primary_flag"]]
    m=b2.merge(d2[keep],on=["_sid","_survey"],how="left",validate="one_to_one",indicator=True)
    if len(m)!=len(b): raise RuntimeError("join changed row count")

    matched=int((m["_merge"]=="both").sum())
    unmatched=int((m["_merge"]!="both").sum())
    aval=pd.to_numeric(m[c["alpha_frozen_column"]],errors="coerce").to_numpy(float)
    finite=int(np.isfinite(aval).sum())

    out=m.drop(columns=["_sid","_survey","_merge"])

    # Original balanced columns must remain value-identical row by row.
    original_identity=True
    for col in b.columns:
        x=b[col].reset_index(drop=True); y=out[col].reset_index(drop=True)
        if pd.api.types.is_numeric_dtype(x.dtype):
            xa=pd.to_numeric(x,errors="coerce").to_numpy()
            ya=pd.to_numeric(y,errors="coerce").to_numpy()
            if not np.array_equal(xa,ya,equal_nan=True):
                original_identity=False; break
        else:
            if not x.astype(str).equals(y.astype(str)):
                original_identity=False; break

    outpath=root/c["output_attached_source"]
    outpath.parent.mkdir(parents=True,exist_ok=True)
    out.to_parquet(outpath,index=False)

    ready=bool(
        definition_ready and map_ready and flag_ready and storage_ready and key_schema_ready and
        matched==len(b) and unmatched==0 and original_identity and finite>0
    )

    outdir=root/c["output_dir"]
    for q in ["validation","tables","assembled","freeze"]:
        (outdir/q).mkdir(parents=True,exist_ok=True)

    pd.DataFrame([{
      "balanced_rows":len(b),"matched_rows":matched,"unmatched_rows":unmatched,
      "alpha3_hom_finite_rows":finite,"alpha3_hom_finite_fraction":finite/len(b),
      "definition_ready":definition_ready,"mapping_ready":map_ready,
      "flag_mapping_ready":flag_ready,"storage_schema_ready":storage_ready
    }]).to_csv(outdir/"tables/stage8b1c_join_summary.csv",index=False)

    (outdir/"freeze/stage8b1c_protocol_frozen.json").write_text(
        (root/"protocol/stage8b1c_protocol.json").read_text(encoding="utf-8"),encoding="utf-8"
    )

    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "STAGE2C_ALPHA3_FIXED_DEFINITION_READY":definition_ready,
      "STAGE6D4A_ALPHA3_TO_ALPHA3_HOM_MAPPING_READY":map_ready,
      "STAGE6D4A_ALPHA3_PRIMARY_FLAG_MAPPING_READY":flag_ready,
      "STAGE4A_ALPHA3_HOM_STORAGE_READY":storage_ready,
      "STAGE4A_JOIN_KEYS_READY":key_schema_ready,
      "AUTHORIZED_SCIENCE_NAME":"alpha3",
      "AUTHORIZED_FROZEN_STORAGE_COLUMN":"alpha3_hom",
      "AUTHORIZED_PRIMARY_FLAG":"alpha3_gradient_primary_ok",
      "BALANCED_ROWS":len(b),"MATCHED_ROWS":matched,"UNMATCHED_ROWS":unmatched,
      "ALPHA3_HOM_FINITE_ROWS":finite,"ALPHA3_HOM_FINITE_FRACTION":finite/len(b),
      "SOURCE_ID_FLOAT_COERCION_USED":False,
      "ABUNDANCE_OR_OUTCOME_MATCHING_USED":False,
      "BALANCING_WEIGHTS_CHANGED":False,
      "SUPPORT_SELECTION_CHANGED":False,
      "ORIGINAL_BALANCED_COLUMNS_VALUE_IDENTITY_READY":original_identity,
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":False,
      "REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED":False,
      "STAGE8B1C_ALPHA3_HOM_PROVENANCE_AUTHORIZED":ready,
      "STAGE8B1_REPLAY_WITH_ALPHA3_HOM_READY":ready,
      "ATTACHED_SOURCE_RELATIVE_PATH":c["output_attached_source"],
      "BALANCED_SOURCE_SHA256":sha_file(bal),
      "STAGE4A_DESIGN_SHA256":sha_file(st4d)
    }
    write_json(outdir/"validation/stage8b1c_validation.json",val)
    print(json.dumps(val,indent=2,ensure_ascii=False))
    return 0 if ready else 2

if __name__=="__main__":
    raise SystemExit(main())
