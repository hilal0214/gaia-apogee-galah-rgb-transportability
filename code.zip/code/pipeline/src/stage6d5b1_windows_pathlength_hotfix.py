from __future__ import annotations
import argparse, hashlib, json, re, shutil, zipfile
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

def now():
    return datetime.now(timezone.utc).isoformat()

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str)+"\n", encoding="utf-8")

def short_name(index:int, src:Path, digest:str, max_chars:int)->str:
    stem=re.sub(r"[^A-Za-z0-9._-]+","_",src.stem)
    suffix=src.suffix.lower()
    prefix=f"{index:03d}_"
    tail=f"_{digest[:10]}{suffix}"
    allowed=max(8, max_chars-len(prefix)-len(tail))
    stem=stem[:allowed]
    return prefix+stem+tail

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args=ap.parse_args()
    root=Path(args.project_root).resolve()
    cfg=json.loads((root/"config/stage6d5b1_config.json").read_text(encoding="utf-8"))
    out=root/cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)

    vpath=root/cfg["d5a_validation"]
    if not vpath.exists():
        raise FileNotFoundError(str(vpath))
    d5a=json.loads(vpath.read_text(encoding="utf-8"))
    prereq=bool(
        d5a.get("STAGE6D5A_MANUSCRIPT_CLAIM_INTEGRATION_READY",False)
        and d5a.get("STAGE6D5B_ARCHIVAL_RELEASE_READY",False)
        and d5a.get("CLAIM_BOUNDARIES_PRESERVED",False)
        and d5a.get("NO_SCIENCE_REFIT_PERFORMED",False)
    )

    release_root=out/cfg["release_name"]
    science_dir=release_root/"science"
    science_dir.mkdir(parents=True, exist_ok=True)

    # Verify required source existence and forbidden-source exclusions first.
    missing=[]
    forbidden=[]
    for rel in cfg["required_files"]:
        p=root/rel
        if not p.exists():
            missing.append(rel)
        low=rel.replace("\\","/").lower()
        for tok in cfg["forbidden_original_path_tokens"]:
            if tok.lower() in low:
                forbidden.append({"path":rel,"token":tok})
    if missing:
        write_json(out/"stage6d5b1_missing_required_files.json",{"missing":missing})
        raise RuntimeError(f"Missing required release files: {missing}")
    if forbidden:
        write_json(out/"stage6d5b1_forbidden_required_files.json",{"hits":forbidden})
        raise RuntimeError(f"Forbidden required-file content: {forbidden}")

    rows=[]
    archive_names=set()
    all_rels=list(cfg["required_files"])
    optional_present=[]
    for rel in cfg["optional_files"]:
        p=root/rel
        if p.exists():
            low=rel.replace("\\","/").lower()
            if any(tok.lower() in low for tok in cfg["forbidden_original_path_tokens"]):
                continue
            all_rels.append(rel)
            optional_present.append(rel)

    for i,rel in enumerate(all_rels, start=1):
        src=root/rel
        digest=sha256_file(src)
        arc=short_name(i,src,digest,int(cfg["max_archive_filename_chars"]))
        if arc in archive_names:
            raise RuntimeError(f"Archive name collision: {arc}")
        archive_names.add(arc)
        dst=science_dir/arc
        shutil.copy2(src,dst)
        if sha256_file(dst)!=digest:
            raise RuntimeError(f"Copy SHA mismatch: {rel}")
        rows.append({
            "archive_path":f"science/{arc}",
            "original_project_path":rel.replace("\\","/"),
            "size_bytes":src.stat().st_size,
            "sha256":digest,
            "required":rel in cfg["required_files"]
        })

    pathmap=pd.DataFrame(rows)
    pathmap.to_csv(release_root/"RELEASE_PATH_MAP.csv",index=False)

    readme="""# RGB transportability science release v0.26.1

This is the claim-safe reproducibility archive for the frozen
Gaia--APOGEE--GALAH RGB transportability analysis.

Windows path-length hotfix:
Science files are stored under short deterministic archive names. Their exact
original project paths and SHA-256 identities are recorded in
`RELEASE_PATH_MAP.csv`. File contents are unchanged.

Final Stage-6D4 result:
- [Ni/Fe]: TRANSPORT_STABLE radially and vertically.
- [Si/Fe]: vertical TRANSPORT_STABLE; radial INDETERMINATE.
- [Ca/Fe]: vertical TRANSPORT_STABLE; radial INDETERMINATE.
- [Fe/H]: radial and vertical INDETERMINATE.
- [Mg/Fe]: radial and vertical INDETERMINATE.
- No primary label is FOOTPRINT_SENSITIVE or SURVEY_SENSITIVE.

`INDETERMINATE` is not evidence of instability.

Intentionally excluded:
- manuscript and manuscript PDF;
- raw Gaia/APOGEE/GALAH row-level catalogues;
- D3C9 row-level production-balanced source.

Public Zenodo deposition still requires verified human metadata:
authors, affiliations, ORCIDs, license, and final DOI-facing metadata.
"""
    (release_root/"README.md").write_text(readme,encoding="utf-8")

    claim={
        "allowed":[
            "[Ni/Fe] is transport-stable in both radial and vertical gradients within tested balanced common support.",
            "[Si/Fe] and [Ca/Fe] are vertically transport-stable but overall indeterminate.",
            "[Fe/H] and [Mg/Fe] are indeterminate under frozen practical-equivalence rules.",
            "No primary label is classified as footprint-sensitive or survey-sensitive."
        ],
        "forbidden":[
            "indeterminate means unstable or non-transportable",
            "volume-complete Milky Way gradient",
            "independent GALAH replication",
            "selection-function-corrected replication",
            "causal footprint effect",
            "general five-label predictive law",
            "component-resolved gradients"
        ]
    }
    write_json(release_root/"CLAIM_BOUNDARIES.json",claim)

    cff="""cff-version: 1.2.0
message: "If you use this science release, please cite the associated paper and archived release."
title: "RGB transportability science release"
version: "0.26.1"
type: software
authors:
  - family-names: "TO_BE_VERIFIED"
    given-names: "TO_BE_VERIFIED"
date-released: "2026-08-11"
doi: "TO_BE_ASSIGNED_BY_ZENODO"
"""
    (release_root/"CITATION.cff").write_text(cff,encoding="utf-8")

    zenodo={
        "title":"RGB transportability science release",
        "upload_type":"software",
        "description":"Claim-safe reproducibility archive for the frozen Gaia--APOGEE--GALAH RGB transportability common-footprint analysis.",
        "creators":[{"name":"TO_BE_VERIFIED","affiliation":"TO_BE_VERIFIED","orcid":"TO_BE_VERIFIED"}],
        "version":"0.26.1",
        "publication_date":"2026-08-11",
        "license":"TO_BE_SELECTED",
        "keywords":["Milky Way","chemical abundances","APOGEE","GALAH","Gaia","survey transportability","Galactic gradients","reproducibility"],
        "notes":"Manuscript and row-level survey data are intentionally excluded. Complete creators, affiliations, ORCIDs and license before public deposition."
    }
    write_json(release_root/"zenodo_metadata_template.json",zenodo)

    # Content manifest over complete release directory except manifest itself.
    manifest=[]
    for p in sorted(release_root.rglob("*")):
        if p.is_file() and p.name!="MANIFEST_SHA256.csv":
            manifest.append({
                "archive_path":str(p.relative_to(release_root)).replace("\\","/"),
                "size_bytes":p.stat().st_size,
                "sha256":sha256_file(p)
            })
    pd.DataFrame(manifest).to_csv(release_root/"MANIFEST_SHA256.csv",index=False)

    # Ensure staging paths remain short enough for classic Windows MAX_PATH headroom.
    max_abs_path=max(len(str(p.resolve())) for p in release_root.rglob("*") if p.is_file())
    pathlength_ready=max_abs_path < 240

    release_zip=out/f"{cfg['release_name']}.zip"
    with zipfile.ZipFile(release_zip,"w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(release_root.rglob("*")):
            if p.is_file():
                z.write(p,p.relative_to(release_root))

    zip_ready=release_zip.exists() and release_zip.stat().st_size>0
    technical_ready=bool(
        prereq and len(rows)>=len(cfg["required_files"])
        and pathlength_ready and zip_ready
    )

    validation={
        "stage":cfg["stage"],
        "implementation_version":cfg["implementation_version"],
        "timestamp_utc":now(),
        "D5A_PREREQUISITE_READY":prereq,
        "REQUIRED_RELEASE_FILES_READY":True,
        "SHORT_ARCHIVE_PATH_MAPPING_READY":True,
        "RELEASE_PATH_MAP_READY":True,
        "COPIED_FILE_SHA256_IDENTITY_READY":True,
        "MAX_STAGED_ABSOLUTE_PATH_CHARS":max_abs_path,
        "WINDOWS_PATHLENGTH_HEADROOM_READY":pathlength_ready,
        "MANUSCRIPT_EXCLUDED_READY":True,
        "RAW_ROW_LEVEL_SURVEY_DATA_EXCLUDED_READY":True,
        "D3C9_ROW_LEVEL_BALANCED_SOURCE_EXCLUDED_READY":True,
        "CLAIM_BOUNDARIES_ARCHIVED_READY":True,
        "SHA256_MANIFEST_READY":True,
        "RELEASE_ZIP_READY":zip_ready,
        "RELEASE_ZIP":str(release_zip.relative_to(root)).replace("\\","/"),
        "RELEASE_ZIP_SHA256":sha256_file(release_zip) if zip_ready else None,
        "TECHNICAL_ARCHIVAL_RELEASE_READY":technical_ready,
        "ZENODO_HUMAN_METADATA_COMPLETE":False,
        "ZENODO_PUBLIC_DEPOSITION_READY":False,
        "STAGE6D5B1_ARCHIVAL_RELEASE_CLOSED":technical_ready
    }
    (out/"validation").mkdir(exist_ok=True)
    write_json(out/"validation/stage6d5b1_validation.json",validation)
    print(json.dumps({"validation":validation},indent=2,ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
