from __future__ import annotations
import argparse, hashlib, json, os, shutil, subprocess, sys, zipfile
from pathlib import Path

def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()

def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for x in iter(lambda:f.read(1024*1024),b""):
            h.update(x)
    return h.hexdigest()

def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def safe_member(name):
    p=Path(name)
    return not p.is_absolute() and ".." not in p.parts

def scan_plain(roots,target):
    hits=[]
    for root in roots:
        if not root.exists(): continue
        # recursive only in project; shallow common D6B folders under Downloads
        if root.name.lower().startswith("gaia_apogee_galah"):
            it=root.rglob("main.tex")
        else:
            cand=[]
            cand.extend(root.glob("main.tex"))
            cand.extend(root.glob("*D6B*/main.tex"))
            cand.extend(root.glob("*d6b*/main.tex"))
            cand.extend(root.glob("RGB_MNRAS_D6B*/main.tex"))
            it=cand
        for p in it:
            try:
                if sha_file(p)==target:
                    hits.append(("plain",p,None))
            except Exception:
                pass
    return hits

def candidate_zips(downloads,globs):
    seen=set(); out=[]
    for g in globs:
        for p in downloads.glob(g):
            try:
                rp=p.resolve()
            except Exception:
                rp=p
            if rp not in seen and p.is_file():
                seen.add(rp); out.append(p)
    return sorted(out,key=lambda p:p.stat().st_mtime,reverse=True)

def scan_zips(downloads,globs,target):
    hits=[]; scanned=[]; errors=[]
    for zpath in candidate_zips(downloads,globs):
        scanned.append(str(zpath))
        try:
            with zipfile.ZipFile(zpath,"r") as z:
                for info in z.infolist():
                    if Path(info.filename).name.lower()!="main.tex":
                        continue
                    b=z.read(info)
                    if sha_bytes(b)==target:
                        hits.append(("zip",zpath,info.filename))
        except Exception as e:
            errors.append({"zip":str(zpath),"error":repr(e)})
    return hits,scanned,errors

def extract_matching_zip(zpath,member,cache,target):
    if cache.exists(): shutil.rmtree(cache)
    cache.mkdir(parents=True,exist_ok=True)
    member_dir=Path(member).parent
    with zipfile.ZipFile(zpath,"r") as z:
        members=[]
        for info in z.infolist():
            n=Path(info.filename)
            if not safe_member(info.filename): continue
            # extract the directory containing matching main.tex, or top-level package if flat
            if member_dir==Path("."):
                members.append(info)
            else:
                try:
                    n.relative_to(member_dir)
                    members.append(info)
                except Exception:
                    pass
        for info in members:
            rel=Path(info.filename)
            if member_dir!=Path("."):
                rel=rel.relative_to(member_dir)
            dest=cache/rel
            if info.is_dir():
                dest.mkdir(parents=True,exist_ok=True)
            else:
                dest.parent.mkdir(parents=True,exist_ok=True)
                with z.open(info) as src, dest.open("wb") as dst:
                    shutil.copyfileobj(src,dst)
    main=cache/"main.tex"
    if not main.exists() or sha_file(main)!=target:
        raise RuntimeError("Extracted baseline main.tex failed exact SHA identity")
    return main

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",default=".")
    a=ap.parse_args()
    root=Path(a.project_root).resolve()
    cfg=json.loads((root/"config/stage6d6c1_config.json").read_text(encoding="utf-8"))
    target=cfg["target_main_sha256"]

    downloads=Path(os.environ.get("USERPROFILE",str(Path.home())))/"Downloads"
    plain=scan_plain([root,downloads],target)
    zhits,scanned,zerrors=scan_zips(downloads,cfg["candidate_zip_globs"],target)
    hits=plain+zhits

    if len(hits)==0:
        val={
          "stage":"Stage-6D6C1 external D6B baseline locator hotfix",
          "implementation_version":cfg["implementation_version"],
          "TARGET_MAIN_SHA256":target,
          "EXACT_BASELINE_HITS":0,
          "CANDIDATE_ZIPS_SCANNED":scanned,
          "ZIP_SCAN_ERRORS":zerrors,
          "D6B_BASELINE_READY":False,
          "NEXT_ACTION":"Place RGB_MNRAS_D6B_v1_2_0.zip in %USERPROFILE%\\Downloads, then rerun this command. SHA gate is not weakened."
        }
        write_json(root/cfg["validation"],val)
        print(json.dumps(val,indent=2,ensure_ascii=False))
        return 2

    # Multiple exact-SHA copies are scientifically identical. Prefer ZIP D6B candidate, then plain.
    zexact=[h for h in hits if h[0]=="zip"]
    chosen=zexact[0] if zexact else hits[0]
    cache=root/cfg["cache_dir"]
    if chosen[0]=="zip":
        baseline_main=extract_matching_zip(chosen[1],chosen[2],cache,target)
        source_desc=f"{chosen[1]}::{chosen[2]}"
    else:
        srcdir=chosen[1].parent
        if cache.exists(): shutil.rmtree(cache)
        shutil.copytree(srcdir,cache)
        baseline_main=cache/"main.tex"
        if sha_file(baseline_main)!=target:
            raise RuntimeError("Plain baseline cache SHA mismatch")
        source_desc=str(chosen[1])

    # Put an exact-SHA baseline copy under project root where original D6C can find it.
    bridge=root/"outputs/stage6d6c1_external_d6b_baseline_locator_hotfix/d6b_bridge"
    if bridge.exists(): shutil.rmtree(bridge)
    shutil.copytree(cache,bridge)
    if sha_file(bridge/"main.tex")!=target:
        raise RuntimeError("D6B bridge SHA mismatch")

    # Now invoke the existing D6C script unchanged.
    d6c=root/"src/stage6d6c_manuscript_science_integration.py"
    if not d6c.exists():
        raise FileNotFoundError(d6c)
    cp=subprocess.run([sys.executable,str(d6c),"--project-root",str(root)],cwd=root)
    d6c_ok=(cp.returncode==0)

    val={
      "stage":"Stage-6D6C1 external D6B baseline locator hotfix",
      "implementation_version":cfg["implementation_version"],
      "TARGET_MAIN_SHA256":target,
      "EXACT_BASELINE_HITS":len(hits),
      "CHOSEN_BASELINE_SOURCE":source_desc,
      "BRIDGE_MAIN_TEX_SHA256":sha_file(bridge/"main.tex"),
      "SHA_GATE_WEAKENED":False,
      "D6B_BASELINE_READY":True,
      "D6C_INVOKED":True,
      "D6C_RETURN_CODE":cp.returncode,
      "D6C_COMPLETED":d6c_ok
    }
    write_json(root/cfg["validation"],val)
    print(json.dumps(val,indent=2,ensure_ascii=False))
    return cp.returncode

if __name__=="__main__":
    raise SystemExit(main())
