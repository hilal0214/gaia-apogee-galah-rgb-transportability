from __future__ import annotations
import argparse, hashlib, importlib.util, json, shutil, sys, time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np, pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()

def canonical_sha(o):
    return hashlib.sha256(json.dumps(
        o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False
    ).encode()).hexdigest()

def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None:
        raise ImportError(str(path))
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

def flag_to_bool(s):
    if pd.api.types.is_bool_dtype(s): return s.fillna(False).to_numpy(bool)
    x=s.astype(str).str.strip().str.lower()
    return x.isin(["1","true","t","yes","y"]).to_numpy(bool)

def stable_fold(cell, namespace, kind, k, outer=None):
    import hashlib
    tag=f"{namespace}|{kind}|{'' if outer is None else outer}|{int(cell)}"
    d=hashlib.sha256(tag.encode()).digest()
    return int.from_bytes(d[:8],"little") % int(k)

def feature_m0(R,Z):
    return np.column_stack([R-8.2,Z])

def feature_m1(R,Z,rb):
    return np.column_stack([R-8.2,np.maximum(0.0,R-float(rb)),Z])

def predict(fit,X):
    return fit.beta[0] + X @ fit.beta[1:]

def wmae(y,p,w):
    w=np.asarray(w,float);e=np.abs(np.asarray(y,float)-np.asarray(p,float))
    return float(np.sum(w*e)/np.sum(w))

def fit_weighted(d4b,s4b,X,y,w,h):
    return d4b.weighted_huber_fit(
        X,y,w,
        tuning_constant=float(h["tuning_constant"]),
        relative_tolerance=float(h["relative_tolerance"]),
        maximum_iterations=int(h["maximum_iterations"]),
        minimum_scale=float(h["minimum_scale"]),
        robust_scale_fn=s4b.robust_scale
    )

def weighted_group_center(resid,w,survey,cell):
    x=pd.DataFrame({"resid":resid,"w":w,"survey":survey,"cell":cell})
    x["wr"]=x["w"]*x["resid"]
    sums=x.groupby(["survey","cell"],sort=False)[["wr","w"]].sum()
    means=(sums["wr"]/sums["w"]).to_dict()
    mu=np.array([means[(s,int(c))] for s,c in zip(survey,cell)],float)
    return resid-mu

def synthetic_response(fitted, centered_resid, survey, cell, R, rb, delta, seed):
    groups=sorted(set((str(s),int(c)) for s,c in zip(survey,cell)))
    rng=np.random.Generator(np.random.PCG64DXSM(int(seed)))
    signs=rng.integers(0,2,size=len(groups),dtype=np.int8).astype(float)*2.0-1.0
    smap={g:signs[i] for i,g in enumerate(groups)}
    mult=np.array([smap[(str(s),int(c))] for s,c in zip(survey,cell)],float)
    y=fitted + mult*centered_resid
    if float(delta)!=0:
        y=y+float(delta)*np.maximum(0.0,R-float(rb))
    return y

def select_break_inner(d4b,s4b,R,Z,y,w,cell,breaks,h,namespace,outer_tag):
    folds=np.array([
        stable_fold(c,namespace,"inner",3,outer=outer_tag) for c in cell
    ],dtype=int)
    rec=[]
    for rb in breaks:
        losses=[]
        for f in range(3):
            tr=folds!=f;va=folds==f
            if tr.sum()<100 or va.sum()<30: raise RuntimeError("inner fold support too small")
            fit=fit_weighted(d4b,s4b,feature_m1(R[tr],Z[tr],rb),y[tr],w[tr],h)
            if not fit.converged: raise RuntimeError("inner M1 did not converge")
            pred=predict(fit,feature_m1(R[va],Z[va],rb))
            losses.append(wmae(y[va],pred,w[va]))
        rec.append((float(np.mean(losses)),float(rb)))
    rec.sort()
    return rec[0][1],rec

def one_outer_smoke(d4b,s4b,R,Z,y,w,cell,breaks,h,namespace,outer_fold):
    outer=np.array([stable_fold(c,namespace,"outer",5) for c in cell],dtype=int)
    tr=outer!=int(outer_fold);te=outer==int(outer_fold)
    rb,_=select_break_inner(
        d4b,s4b,R[tr],Z[tr],y[tr],w[tr],cell[tr],
        breaks,h,namespace,outer_tag=int(outer_fold)
    )
    m0=fit_weighted(d4b,s4b,feature_m0(R[tr],Z[tr]),y[tr],w[tr],h)
    m1=fit_weighted(d4b,s4b,feature_m1(R[tr],Z[tr],rb),y[tr],w[tr],h)
    p0=predict(m0,feature_m0(R[te],Z[te]))
    p1=predict(m1,feature_m1(R[te],Z[te],rb))
    mae0=wmae(y[te],p0,w[te]);mae1=wmae(y[te],p1,w[te])
    return {
        "outer_fold":int(outer_fold),"selected_break_kpc":rb,
        "mae_m0":mae0,"mae_m1":mae1,
        "improvement":1.0-mae1/mae0,
        "train_rows":int(tr.sum()),"test_rows":int(te.sum()),
        "m0_converged":bool(m0.converged),"m1_converged":bool(m1.converged)
    }

def full_sample_smoke_fit(d4b,s4b,R,Z,y,w,cell,breaks,h,namespace):
    rb,_=select_break_inner(
        d4b,s4b,R,Z,y,w,cell,breaks,h,namespace,outer_tag="full-smoke"
    )
    X=feature_m1(R,Z,rb)
    fit=fit_weighted(d4b,s4b,X,y,w,h)
    inf=d4b.weighted_cluster_inference(
        X,y,cell.astype(np.int64),fit,n_draws=0,seed=1,
        finite_cluster_correction=True
    )
    delta=float(fit.beta[2]);se=float(inf.standard_errors[2])
    z=1.959963984540054
    return {
        "selected_break_kpc":rb,"delta_beta":delta,"delta_beta_se":se,
        "delta_beta_wald_low":delta-z*se,"delta_beta_wald_high":delta+z*se,
        "fit_converged":bool(fit.converged),"blocks":int(len(inf.block_ids))
    }

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage7b1_config.json").read_text())
    out=root/c["output_dir"]
    if out.exists(): shutil.rmtree(out)
    for d in ["validation","tables","freeze","reports","benchmarks","manifest"]:
        (out/d).mkdir(parents=True,exist_ok=True)

    va=json.loads((root/c["stage7a_validation"]).read_text())
    p=json.loads((root/c["stage7a_protocol"]).read_text())
    stage7a_ready=bool(
        va.get("STAGE7A_PROTOCOL_FROZEN") and va.get("STAGE7B_INJECTION_RECOVERY_READY")
        and va.get("protocol_canonical_sha256")==c["expected_stage7a_protocol_sha256"]
        and canonical_sha(p)==c["expected_stage7a_protocol_sha256"]
    )

    d4cfg=json.loads((root/c["d4b_config"]).read_text())
    schema_identity=bool(
        d4cfg["outcome_columns"]["fe_h"]==c["expected_outcome_column"] and
        d4cfg["eligibility_columns"]["fe_h"]==c["expected_eligibility_column"] and
        d4cfg["weight_column"]=="balance_weight_final" and
        d4cfg["bootstrap_block_column"]=="healpix_gal_ring_nside16"
    )
    d4b=load_module("stage7b1_d4b",root/c["d4b_source"])
    s4b=load_module("stage7b1_s4b",root/c["stage4b_common"])
    api_ready=bool(
        hasattr(d4b,"weighted_huber_fit") and
        hasattr(d4b,"weighted_cluster_inference") and
        hasattr(s4b,"robust_scale")
    )

    src=root/c["balanced_source"]
    df=pd.read_parquet(src,columns=c["columns"])
    eligible=flag_to_bool(df["fe_h_gradient_primary_ok"])
    R0=pd.to_numeric(df["R"],errors="coerce").to_numpy(float)
    Z0=pd.to_numeric(df["abs_Z"],errors="coerce").to_numpy(float)
    y0=pd.to_numeric(df["fe_h"],errors="coerce").to_numpy(float)
    w0=pd.to_numeric(df["balance_weight_final"],errors="coerce").to_numpy(float)
    finite=np.isfinite(R0)&np.isfinite(Z0)&np.isfinite(y0)&np.isfinite(w0)&(w0>0)
    domain=(R0>3.0)&(R0<15.0)
    mask=eligible&finite&domain

    d=df.loc[mask].reset_index(drop=True)
    R=pd.to_numeric(d["R"],errors="coerce").to_numpy(float)
    Z=pd.to_numeric(d["abs_Z"],errors="coerce").to_numpy(float)
    y=pd.to_numeric(d["fe_h"],errors="coerce").to_numpy(float)
    w=pd.to_numeric(d["balance_weight_final"],errors="coerce").to_numpy(float)
    survey=d["survey"].astype(str).to_numpy()
    cell=pd.to_numeric(d["healpix_gal_ring_nside16"],errors="raise").to_numpy(np.int64)

    sg=p["support_gates"]
    support=[]
    all_support=True
    for rb in p["break_search"]["grid_values"]:
        left=R<=rb;right=R>rb
        rec={
            "R_break_kpc":rb,"rows_left":int(left.sum()),"rows_right":int(right.sum()),
            "cells_left":int(pd.Series(cell[left]).nunique()),
            "cells_right":int(pd.Series(cell[right]).nunique())
        }
        for s in ["APOGEE_NATIVE","GALAH_CORRECTED"]:
            rec[f"{s}_left"]=int((left&(survey==s)).sum())
            rec[f"{s}_right"]=int((right&(survey==s)).sum())
        rec["support_ready"]=bool(
            rec["rows_left"]>=sg["minimum_rows_each_side_of_every_break_candidate"] and
            rec["rows_right"]>=sg["minimum_rows_each_side_of_every_break_candidate"] and
            rec["cells_left"]>=sg["minimum_cells_each_side_of_every_break_candidate"] and
            rec["cells_right"]>=sg["minimum_cells_each_side_of_every_break_candidate"] and
            rec["APOGEE_NATIVE_left"]>=sg["minimum_rows_per_survey_each_side_of_every_break_candidate"] and
            rec["APOGEE_NATIVE_right"]>=sg["minimum_rows_per_survey_each_side_of_every_break_candidate"] and
            rec["GALAH_CORRECTED_left"]>=sg["minimum_rows_per_survey_each_side_of_every_break_candidate"] and
            rec["GALAH_CORRECTED_right"]>=sg["minimum_rows_per_survey_each_side_of_every_break_candidate"]
        )
        all_support &= rec["support_ready"];support.append(rec)
    pd.DataFrame(support).to_csv(out/"tables/stage7b1_feh_eligible_break_grid_support.csv",index=False)

    h=d4cfg["huber"]
    # Real outcome use is restricted to M0 only.
    t0=time.perf_counter()
    X0=feature_m0(R,Z)
    m0=fit_weighted(d4b,s4b,X0,y,w,h)
    m0_seconds=time.perf_counter()-t0
    if not m0.converged: raise RuntimeError("real Fe/H M0 did not converge")
    fitted=predict(m0,X0)
    centered=weighted_group_center(m0.residuals,w,survey,cell)

    # No M1 real-outcome call exists above or below this point.
    closure=json.loads((root/"protocol/stage7b1_operational_closure.json").read_text())
    closure_sha=canonical_sha(closure)
    shutil.copy2(root/"protocol/stage7b1_operational_closure.json",
                 out/"freeze/stage7b1_operational_closure_frozen.json")

    smoke=[]
    smoke_start=time.perf_counter()
    for sc in c["smoke_scenarios"]:
        ys=synthetic_response(
            fitted,centered,survey,cell,R,
            sc["R_break_kpc"],sc["delta_beta"],sc["seed"]
        )
        rec=one_outer_smoke(
            d4b,s4b,R,Z,ys,w,cell,c["smoke_break_grid_kpc"],
            h,p["predictive_selection"]["namespace"],c["smoke_outer_fold"]
        )
        full=full_sample_smoke_fit(
            d4b,s4b,R,Z,ys,w,cell,c["smoke_break_grid_kpc"],
            h,p["predictive_selection"]["namespace"]
        )
        smoke.append({**sc,**rec,**{f"full_{k}":v for k,v in full.items()}})
    smoke_seconds=time.perf_counter()-smoke_start
    sm=pd.DataFrame(smoke)
    sm.to_csv(out/"tables/stage7b1_synthetic_smoke_results.csv",index=False)

    smoke_ready=bool(
        np.isfinite(sm.select_dtypes(include=[np.number]).to_numpy()).all()
        and sm["m0_converged"].all() and sm["m1_converged"].all()
        and sm["full_fit_converged"].all()
        and (sm["full_blocks"]>=100).all()
    )

    # Engineering benchmark only: no scientific threshold is evaluated.
    benchmark={
        "feh_eligible_rows":int(len(d)),
        "feh_eligible_cells":int(pd.Series(cell).nunique()),
        "survey_rows":pd.Series(survey).value_counts().to_dict(),
        "m0_fit_seconds":m0_seconds,
        "two_scenario_smoke_seconds":smoke_seconds,
        "seconds_per_smoke_scenario":smoke_seconds/len(smoke),
        "note":"Smoke uses one outer fold and four break candidates only; do not extrapolate linearly to production because B2 will use process-level parallelism and cached fold arrays."
    }
    write_json(out/"benchmarks/stage7b1_runtime_benchmark.json",benchmark)

    residual_diag={
        "rows":int(len(d)),"cells":int(pd.Series(cell).nunique()),
        "m0_converged":bool(m0.converged),
        "m0_iterations":int(m0.iterations),
        "m0_residual_mad":float(m0.residual_mad),
        "m0_scale":float(m0.scale),
        "survey_cell_groups":int(pd.DataFrame({"s":survey,"c":cell}).drop_duplicates().shape[0]),
        "real_M1_fit_performed":False,
        "real_break_grid_scanned":False,
        "real_break_result_inspected":False
    }
    write_json(out/"tables/stage7b1_null_residual_diagnostics.json",residual_diag)

    ready=bool(
        stage7a_ready and schema_identity and api_ready and all_support and
        len(d)>=1000 and pd.Series(cell).nunique()>=100 and smoke_ready
    )
    val={
        "stage":c["stage"],"implementation_version":c["implementation_version"],
        "timestamp_utc":now(),
        "STAGE7A_PROTOCOL_IDENTITY_READY":stage7a_ready,
        "D4B_FEH_SCHEMA_IDENTITY_READY":schema_identity,
        "EXACT_D4B_WEIGHTED_HUBER_API_READY":api_ready,
        "BALANCED_SOURCE_ROWS_RAW":int(len(df)),
        "FEH_ELIGIBLE_ROWS":int(len(d)),
        "FEH_ELIGIBLE_NSIDE16_CELLS":int(pd.Series(cell).nunique()),
        "FEH_ELIGIBLE_BREAK_GRID_SUPPORT_READY":bool(all_support),
        "REAL_FEH_M0_NULL_FIT_READY":bool(m0.converged),
        "REAL_FEH_M1_BREAK_FIT_PERFORMED":False,
        "REAL_BREAK_GRID_SCANNED":False,
        "WILD_RESIDUAL_GROUP_CLOSURE_READY":True,
        "SYNTHETIC_NULL_AND_TARGET_ENGINE_READY":smoke_ready,
        "NESTED_SPATIAL_CV_ENGINE_SMOKE_READY":smoke_ready,
        "CLUSTER_WALD_SIMULATION_DETECTION_RULE_FROZEN":True,
        "STAGE7C_4096_DRAW_FINAL_GATE_UNCHANGED":True,
        "SMOKE_RESULTS_NOT_USED_FOR_SCIENCE_DECISIONS":True,
        "stage7b1_operational_closure_canonical_sha256":closure_sha,
        "STAGE7B1_PREFLIGHT_READY":ready,
        "STAGE7B2_FULL_INJECTION_RECOVERY_READY":ready,
        "STAGE7C_REAL_BREAK_FIT_AUTHORIZED":False
    }
    write_json(out/"validation/stage7b1_validation.json",val)

    report=f"""# Stage-7B1 injection-engine preflight

Ready: `{ready}`

Fe/H-specific eligible rows: {len(d)}
Primary NSIDE16 cells: {pd.Series(cell).nunique()}
Full frozen 4.5--8.5 kpc support grid after Fe/H eligibility: `{all_support}`

Real Fe/H use:
- M0 single-slope null fit: performed solely to obtain null fitted values and residual structure.
- M1 broken model on real Fe/H: NOT performed.
- real break grid scan: NOT performed.

The two synthetic smoke scenarios are engineering tests only and cannot be
used for false-positive, power, or astrophysical claims.

If this preflight passes, Stage-7B2 may run the frozen 256 null replicates and
12 x 128 injected-break scenarios. Stage-7C remains forbidden until the full
Stage-7B2 false-positive and target-power gates pass.
"""
    (out/"reports/stage7b1_report.md").write_text(report,encoding="utf-8")

    manifest=[]
    for fp in sorted(out.rglob("*")):
        if fp.is_file() and "manifest" not in fp.parts:
            manifest.append({
                "path":str(fp.relative_to(root)).replace("\\","/"),
                "size_bytes":fp.stat().st_size,"sha256":sha_file(fp)
            })
    pd.DataFrame(manifest).to_csv(out/"manifest/stage7b1_manifest_sha256.csv",index=False)
    print(json.dumps({"validation":val,"benchmark":benchmark},indent=2,ensure_ascii=False))
    return 0 if ready else 2

if __name__=="__main__": raise SystemExit(main())
