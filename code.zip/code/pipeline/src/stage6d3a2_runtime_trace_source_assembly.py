from __future__ import annotations
import argparse, copy, csv, hashlib, json, math, os, shutil, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd
import yaml
PACKAGE_ROOT = Path(__file__).resolve().parents[1]

def now(): return datetime.now(timezone.utc).isoformat()
def rel(p: Path, root: Path):
    try: return str(p.resolve().relative_to(root.resolve())).replace('\\','/')
    except Exception: return str(p).replace('\\','/')
def sha(p: Path):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def wjson(p: Path, v: Any): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(v,indent=2,ensure_ascii=False,default=str)+'\n',encoding='utf-8')
def wcsv(p: Path, fields, rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:
        x=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); x.writeheader(); x.writerows(rows)
def columns(path: Path):
    if path.suffix.lower()=='.parquet':
        import pyarrow.parquet as pq
        q=pq.ParquetFile(path); return list(q.schema_arrow.names), int(q.metadata.num_rows)
    return list(pd.read_csv(path,nrows=5).columns), -1
def table(path: Path, cols=None):
    return pd.read_parquet(path,columns=cols) if path.suffix.lower()=='.parquet' else pd.read_csv(path,usecols=cols)
def alias(cols, opts):
    m={c.lower():c for c in cols}
    for o in opts:
        if o.lower() in m:return m[o.lower()]
    return None
def prof(path: Path,cfg):
    cols,n=columns(path); mp={k:alias(cols,v) for k,v in cfg['aliases'].items()}; labs=[x for x in cfg['labels'] if x.lower() in {c.lower() for c in cols}]
    return {'columns':cols,'rows':n,'mapping':mp,'labels':labs}
def patch_config(value, shadow_out, shadow_log):
    x=copy.deepcopy(value); audit=[]
    def walk(v,path):
        if isinstance(v,dict):
            for k in list(v):
                p=path+[str(k)]; lk=str(k).lower()
                if lk=='stage4a_output_dir': audit.append({'json_path':'.'.join(p),'action':'preserved','old_value':str(v[k]),'new_value':str(v[k])})
                elif lk=='output_dir': old=v[k];v[k]=shadow_out;audit.append({'json_path':'.'.join(p),'action':'redirected','old_value':str(old),'new_value':shadow_out})
                elif lk=='log_dir': old=v[k];v[k]=shadow_log;audit.append({'json_path':'.'.join(p),'action':'redirected','old_value':str(old),'new_value':shadow_log})
                else: walk(v[k],p)
        elif isinstance(v,list):
            for i,c in enumerate(v): walk(c,path+[str(i)])
    walk(x,[]); return x,audit
def parse_trace(path: Path,root: Path):
    out=[]
    if not path.exists(): return out
    for line in path.read_text(encoding='utf-8').splitlines():
        try:r=json.loads(line)
        except Exception:continue
        ap=r.get('path',''); p=Path(ap) if ap else None
        out.append({'timestamp_utc':r.get('timestamp_utc',''),'operation':r.get('operation',''),'path':rel(p,root) if p else '', 'absolute_path':ap,'exists_after_run':str(p.exists()).lower() if p else '', 'status':r.get('status',''),'error':r.get('error','')})
    return out
def normalize_survey(s,cfg):
    out=pd.Series(pd.NA,index=s.index,dtype='string'); low=s.astype('string').str.lower()
    for canon,toks in cfg['survey_normalization'].items():
        m=pd.Series(False,index=s.index)
        for t in toks:m|=low.str.contains(t.lower(),na=False)
        out.loc[m]=canon
    return out
def canonical(path,item,fields):
    mp=item['mapping']; need=[mp[f] for f in fields if mp.get(f)]; need += [l for l in item['labels'] if l in item['columns']]; need=sorted(set(need)); df=table(path,need).copy()
    for f in fields:
        src=mp.get(f)
        if src and src in df.columns and src!=f: df[f]=df[src]
    return df
def collapse(df,fields):
    df=df.copy(); df['source_id']=pd.to_numeric(df['source_id'],errors='coerce'); df=df[df['source_id'].notna()].copy(); df['source_id']=df['source_id'].astype('uint64'); d=int(df['source_id'].duplicated().sum())
    if d:
        agg={f:'first' for f in fields if f in df.columns and f!='source_id'}; df=df.groupby('source_id',as_index=False).agg(agg)
    return df,d
def complete_mask(df,cfg):
    req=[x for x in cfg['required_assembly_fields'] if x!='source_id']+cfg['labels']; m=pd.Series(True,index=df.index)
    for f in req:
        if f not in df.columns:return pd.Series(False,index=df.index)
        m &= df[f].notna()
    return m
def coalesce(base,add,fields):
    cand=[f for f in fields if f!='source_id' and f in add.columns]; before={f:int(base[f].notna().sum()) if f in base.columns else 0 for f in fields}; j=base.merge(add[['source_id']+cand],on='source_id',how='left',suffixes=('','__c'),validate='one_to_one')
    for f in cand:
        c=f+'__c'
        if f not in j.columns:j[f]=j[c]
        else:j[f]=j[f].where(j[f].notna(),j[c])
        j.drop(columns=[c],inplace=True)
    after={f:int(j[f].notna().sum()) if f in j.columns else 0 for f in fields}; return j,{f:after[f]-before[f] for f in fields}
def interaction_schema(path,cfg):
    lowpath=str(path).lower().replace('\\','/')
    if any(t in lowpath for t in cfg['interaction_excluded_path_tokens']): return False,{'reason':'excluded_path_token'}
    cols,n=columns(path); lab=alias(cols,cfg['aliases']['label']); wide=[c for c in cols if any(t in c.lower() for t in cfg['interaction_column_tokens'])]; term=alias(cols,cfg['aliases']['term']); est=alias(cols,cfg['aliases']['estimate']); terms=[]
    if lab and term and est:
        try:
            for v in sorted(set(table(path,[term])[term].dropna().astype(str))):
                z=v.lower()
                if ('survey' in z or 'apogee' in z or 'galah' in z) and ('radial' in z or 'vertical' in z or 'beta_r' in z or 'beta_z' in z):terms.append(v)
        except Exception:pass
    ok=bool(lab and (wide or terms)); return ok,{'columns':cols,'row_count':n,'label_column':lab,'wide_interaction_columns':wide,'term_column':term,'estimate_column':est,'long_interaction_terms':terms,'reason':'' if ok else 'science_interaction_schema_not_found'}
def main():
    a=argparse.ArgumentParser();a.add_argument('--project-root',default='.');args=a.parse_args();root=Path(args.project_root).resolve();cfg=json.loads((root/'config/stage6d3a2_config.json').read_text(encoding='utf-8'));out=root/cfg['output_dir']
    if out.exists():shutil.rmtree(out)
    for d in ['validation','summaries','tables','reports','trace','shadow','assembled']:(out/d).mkdir(parents=True,exist_ok=True)
    pre_path=root/cfg['prerequisite_validation'];pre=json.loads(pre_path.read_text(encoding='utf-8')) if pre_path.exists() else {}; pre_ready=bool(pre.get('STAGE6D3A1_LINEAGE_READY') and pre.get('STAGE4B_CONFIG_PATH_CONTRACT_READY') and pre.get('STAGE4B_SCRIPT_FILE_CONTRACT_READY'))
    orig_path=root/cfg['stage4b_config']; script_path=root/cfg['stage4b_script']; orig=yaml.safe_load(orig_path.read_text(encoding='utf-8')); patched,audit=patch_config(orig,cfg['shadow_output_dir'],cfg['shadow_log_dir']); shadow_cfg=root/cfg['shadow_config']; shadow_cfg.write_text(yaml.safe_dump(patched,sort_keys=False,allow_unicode=True),encoding='utf-8'); wcsv(out/'tables/stage6d3a2_shadow_config_audit.csv',['json_path','action','old_value','new_value'],audit)
    trace=root/cfg['trace_log']; trace.unlink(missing_ok=True); env=os.environ.copy(); env['PYTHONPATH']=str(PACKAGE_ROOT/'trace_hook')+os.pathsep+env.get('PYTHONPATH',''); env['RGB_STAGE6D3_TRACE_LOG']=str(trace.resolve()); cmd=[sys.executable,str((PACKAGE_ROOT/'trace_hook/run_with_trace.py').resolve()),str(script_path.resolve()),'--config',str(shadow_cfg.resolve())]; run=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True); (out/'trace/stage4b_stdout.txt').write_text(run.stdout,encoding='utf-8');(out/'trace/stage4b_stderr.txt').write_text(run.stderr,encoding='utf-8')
    tr=parse_trace(trace,root);wcsv(out/'tables/stage6d3a2_runtime_io_trace.csv',['timestamp_utc','operation','path','absolute_path','exists_after_run','status','error'],tr); reads=list(dict.fromkeys(Path(r['absolute_path']) for r in tr if r['absolute_path'] and r['status']!='error' and r['operation'].startswith('read_'))); writes=list(dict.fromkeys(Path(r['absolute_path']) for r in tr if r['absolute_path'] and r['status']!='error' and r['operation'].startswith('write_')))
    # exact traced gradient anchor
    candidates=[]
    for p in reads:
        if not p.exists() or p.suffix.lower() not in cfg['suffixes']:continue
        try:item=prof(p,cfg)
        except Exception:continue
        mp=item['mapping']; ok=all(mp.get(f) for f in cfg['required_anchor_fields']) and len(item['labels'])==len(cfg['labels'])
        if ok:candidates.append((1000+100*('stage4a' in str(p).lower())+100*('production' in str(p).lower())+max(item['rows'],0)/1e6,p,item))
    candidates.sort(key=lambda x:(-x[0],str(x[1]))); anchor=candidates[0][1] if candidates else None; anchor_item=candidates[0][2] if candidates else None
    # science interaction, claim ledgers excluded
    poss=list(writes); auth=root/cfg['authoritative_stage4b_dir']
    for n in cfg['interaction_preferred_names']:poss += [auth/n, root/cfg['shadow_output_dir']/n]
    ints=[]
    for p in dict.fromkeys(x for x in poss if x.exists() and x.suffix.lower() in cfg['suffixes']):
        ok,sc=interaction_schema(p,cfg)
        if not ok:continue
        preferred=p.name.lower() in {x.lower() for x in cfg['interaction_preferred_names']}; traced=p in writes; score=1000*preferred+500*traced+100*(str(auth.resolve()) in str(p.resolve()))+10*len(sc['wide_interaction_columns'])+10*len(sc['long_interaction_terms']);ints.append({'path':p,'schema':sc,'preferred':preferred,'traced':traced,'score':score})
    ints.sort(key=lambda x:(-x['score'],str(x['path']))); inter=ints[0] if ints else None
    wcsv(out/'tables/stage6d3a2_interaction_candidates.csv',['path','score','preferred_name','traced_write','label_column','wide_interaction_columns','long_interaction_terms','row_count'],[{'path':rel(x['path'],root),'score':x['score'],'preferred_name':str(x['preferred']).lower(),'traced_write':str(x['traced']).lower(),'label_column':x['schema']['label_column'],'wide_interaction_columns':'|'.join(x['schema']['wide_interaction_columns']),'long_interaction_terms':'|'.join(x['schema']['long_interaction_terms']),'row_count':x['schema']['row_count']} for x in ints])
    assembled=pd.DataFrame();bundle=[];greedy=[];assembly_error='';counts={'APOGEE_NATIVE':0,'GALAH_CORRECTED':0}; assembled_path=None
    if anchor:
        try:
            fields=cfg['required_assembly_fields']; assembled=canonical(anchor,anchor_item,fields);assembled,d=collapse(assembled,fields+cfg['labels']);assembled['survey']=normalize_survey(assembled['survey'],cfg)
            for f in fields+cfg['labels']:
                if f not in assembled.columns:assembled[f]=pd.NA
            bundle.append({'path':anchor,'role':'exact_traced_stage4b_anchor','covered_fields':[f for f in fields if anchor_item['mapping'].get(f)],'labels':anchor_item['labels'],'duplicates':d,'overlap':1.0}); anchor_ids=set(assembled['source_id'].tolist()); pool=[]
            for rr in cfg['scan_roots']:
                base=root/rr
                if not base.exists():continue
                for p in base.rglob('*'):
                    if not p.is_file() or p.suffix.lower() not in cfg['suffixes'] or p.resolve()==anchor.resolve():continue
                    try:item=prof(p,cfg)
                    except Exception:continue
                    if not item['mapping'].get('source_id'):continue
                    covered=[f for f in fields if item['mapping'].get(f)]
                    if len(covered)<=1:continue
                    try:df=canonical(p,item,covered);df,dup=collapse(df,covered); ids=set(df['source_id'].tolist());ov=len(anchor_ids&ids)/max(len(anchor_ids),1)
                    except Exception:continue
                    if ov<cfg['minimum_candidate_anchor_overlap']:continue
                    priority=5 if 'stage4a' in str(p).lower() else 4 if 'stage3' in str(p).lower() else 3 if 'stage2' in str(p).lower() else 2
                    pool.append({'path':p,'item':item,'df':df,'dup':dup,'ov':ov,'priority':priority})
            used=set()
            for _ in range(cfg['maximum_enrichment_files']):
                current=int(complete_mask(assembled,cfg).sum()); best=None
                for c in pool:
                    if str(c['path'].resolve()) in used:continue
                    trial,gains=coalesce(assembled,c['df'],fields); after=int(complete_mask(trial,cfg).sum()); cg=after-current; tg=sum(max(v,0) for v in gains.values()); score=1000*cg+tg+100*c['priority']+int(100*c['ov'])
                    if (cg>0 or tg>0) and (best is None or score>best['score']):best={'c':c,'trial':trial,'gains':gains,'cg':cg,'score':score}
                if not best:break
                c=best['c'];assembled=best['trial'];used.add(str(c['path'].resolve()));bundle.append({'path':c['path'],'role':'source_id_enrichment','covered_fields':[f for f in fields if c['item']['mapping'].get(f)],'labels':c['item']['labels'],'duplicates':c['dup'],'overlap':c['ov']});greedy.append({'path':rel(c['path'],root),'score':best['score'],'complete_row_gain':best['cg'],'overlap_fraction':c['ov'],'field_gains':json.dumps(best['gains'],sort_keys=True)})
            cm=complete_mask(assembled,cfg)
            for s in counts:counts[s]=int((cm & (assembled['survey']==s)).sum())
            assembled_path=out/'assembled/stage6d3a2_production_source_assembled.parquet'
            try:assembled.to_parquet(assembled_path,index=False)
            except Exception:assembled_path=out/'assembled/stage6d3a2_production_source_assembled.csv';assembled.to_csv(assembled_path,index=False)
        except Exception as e:assembly_error=f'{type(e).__name__}: {e}'
    else:assembly_error='No exact traced Stage-4B source-level gradient anchor was found.'
    wcsv(out/'tables/stage6d3a2_bundle_greedy_audit.csv',['path','score','complete_row_gain','overlap_fraction','field_gains'],greedy);wcsv(out/'tables/stage6d3a2_selected_source_bundle.csv',['bundle_order','role','path','covered_fields','labels','duplicate_source_ids','anchor_overlap_fraction'],[{'bundle_order':i+1,'role':x['role'],'path':rel(x['path'],root),'covered_fields':'|'.join(x['covered_fields']),'labels':'|'.join(x['labels']),'duplicate_source_ids':x['duplicates'],'anchor_overlap_fraction':x['overlap']} for i,x in enumerate(bundle)])
    coverage=[]
    if not assembled.empty:
        for f in cfg['required_assembly_fields']+cfg['labels']:coverage.append({'field':f,'non_null_rows':int(assembled[f].notna().sum()) if f in assembled.columns else 0,'coverage_fraction':float(assembled[f].notna().mean()) if f in assembled.columns else 0.0})
    wcsv(out/'tables/stage6d3a2_assembled_field_coverage.csv',['field','non_null_rows','coverage_fraction'],coverage)
    trace_ready=bool(run.returncode==0 and tr and reads and writes); source_ready=bool(not assembly_error and anchor and all(counts[s]>=cfg['minimum_complete_rows_per_survey'] for s in counts)); inter_ready=bool(inter and (inter['preferred'] or inter['traced'])); remaining=[]
    if not trace_ready:remaining.append({'gate':'EXACT_STAGE4B_RUNTIME_TRACE_READY','required_action':f'Exact Stage-4B shadow execution returned {run.returncode}; inspect trace stdout/stderr.'})
    if not anchor:remaining.append({'gate':'EXACT_STAGE4B_GRADIENT_ANCHOR_READY','required_action':'No traced input contains source ID, survey, R, Z, and all five primary labels.'})
    if assembly_error:remaining.append({'gate':'PRODUCTION_SOURCE_ASSEMBLY_READY','required_action':assembly_error})
    elif not source_ready:remaining.append({'gate':'PRODUCTION_SOURCE_COMPLETE_ROWS_READY','required_action':f'Need at least {cfg["minimum_complete_rows_per_survey"]} complete rows per survey; observed {json.dumps(counts,sort_keys=True)}.'})
    if not inter_ready:remaining.append({'gate':'EXACT_SCIENCE_INTERACTION_PRODUCT_READY','required_action':'Exact replay did not yield a preferred-name or traced-write science interaction table; claim ledgers are excluded.'})
    wcsv(out/'tables/stage6d3a2_remaining_items.csv',['gate','required_action'],remaining); d3b=bool(pre_ready and trace_ready and source_ready and inter_ready)
    val={'stage':cfg['stage'],'protocol_version':cfg['protocol_version'],'implementation_version':cfg['implementation_version'],'timestamp_utc':now(),'project_root':str(root),'exact_command':' '.join(cmd),'execution_returncode':run.returncode,'trace_event_count':len(tr),'read_path_count':len(reads),'write_path_count':len(writes),'selected_anchor':rel(anchor,root) if anchor else '','selected_source_bundle':[rel(x['path'],root) for x in bundle],'assembled_source_table':rel(assembled_path,root) if assembled_path else '','assembled_rows':len(assembled),'complete_rows_by_survey':counts,'selected_interaction_product':rel(inter['path'],root) if inter else '','selected_interaction_schema':inter['schema'] if inter else {},'assembly_error':assembly_error,'prior_stage_outputs_modified':False,'STAGE6D3A1_PREREQUISITE_READY':pre_ready,'EXACT_STAGE4B_RUNTIME_TRACE_READY':trace_ready,'EXACT_STAGE4B_GRADIENT_ANCHOR_READY':bool(anchor),'SOURCE_ID_ENRICHMENT_BUNDLE_READY':bool(bundle),'PRODUCTION_SOURCE_ASSEMBLY_READY':source_ready,'CLAIM_LEDGER_EXCLUDED_FROM_INTERACTION_ROLE':True,'EXACT_SCIENCE_INTERACTION_PRODUCT_READY':inter_ready,'STAGE6D3A2_LINEAGE_READY':bool(pre_ready and trace_ready),'STAGE6D3B_COMMON_FOOTPRINT_READY':d3b};wjson(out/'validation/stage6d3a2_validation.json',val)
    summary={'stage':cfg['stage'],'timestamp_utc':now(),'runtime_trace':{'returncode':run.returncode,'read_paths':[rel(p,root) for p in reads],'write_paths':[rel(p,root) for p in writes]},'source_assembly':{'anchor':rel(anchor,root) if anchor else '','bundle':[rel(x['path'],root) for x in bundle],'rows':len(assembled),'complete_rows_by_survey':counts,'ready':source_ready},'interaction':{'path':rel(inter['path'],root) if inter else '','ready':inter_ready,'schema':inter['schema'] if inter else {}},'remaining_items':remaining,'scientific_disposition':'Exact runtime lineage, source assembly, and science interaction product are closed. Stage-6D3B common-footprint construction is authorized.' if d3b else 'Runtime lineage is audited; common-footprint construction remains blocked only by the listed source-assembly or interaction gap.'};wjson(out/'summaries/stage6d3a2_summary.json',summary)
    (out/'reports/stage6d3a2_runtime_trace_source_assembly.md').write_text('\n'.join(['# Stage-6D3A2 runtime trace and source assembly','',f'- Exact replay return code: `{run.returncode}`',f'- Trace events: `{len(tr)}`',f'- Traced input files: `{len(reads)}`',f'- Traced output files: `{len(writes)}`',f'- Gradient anchor: `{rel(anchor,root) if anchor else "not found"}`',f'- Source bundle files: `{len(bundle)}`',f'- Complete APOGEE rows: `{counts["APOGEE_NATIVE"]}`',f'- Complete GALAH rows: `{counts["GALAH_CORRECTED"]}`',f'- Science interaction product: `{rel(inter["path"],root) if inter else "not found"}`',f'- Stage-6D3B ready: `{d3b}`','','Claim ledgers and validation summaries are never accepted as interaction science products.','No common-footprint, propensity, gradient, or bootstrap fit is run.','']),encoding='utf-8')
    print(json.dumps({'validation':val,'summary':summary},indent=2,ensure_ascii=False));return 0
if __name__=='__main__':raise SystemExit(main())
