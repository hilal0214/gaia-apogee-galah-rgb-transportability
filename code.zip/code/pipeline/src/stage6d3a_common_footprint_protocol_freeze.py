from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_json_sha(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(
        (json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n")
        .encode("utf-8")
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_columns(path: Path) -> tuple[list[str], int]:
    if path.suffix.lower() == ".parquet":
        import pyarrow.parquet as pq
        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def find_alias(columns: list[str], options: list[str]) -> str | None:
    lookup = {column.lower(): column for column in columns}
    for option in options:
        if option.lower() in lookup:
            return lookup[option.lower()]
    return None


def detect_labels(columns: list[str], labels: list[str]) -> list[str]:
    lookup = {column.lower() for column in columns}
    detected = []
    for label in labels:
        if label.lower() in lookup:
            detected.append(label)
    return detected


def survey_values_ready(path: Path, survey_column: str) -> tuple[bool, list[str], str]:
    try:
        if path.suffix.lower() == ".parquet":
            values = pd.read_parquet(path, columns=[survey_column])[survey_column]
        else:
            values = pd.read_csv(path, usecols=[survey_column])[survey_column]
        unique = sorted(set(values.dropna().astype(str)))
        text = " ".join(value.lower() for value in unique)
        ready = "apogee" in text and "galah" in text
        return ready, unique[:30], ""
    except Exception as exc:
        return False, [], f"{type(exc).__name__}: {exc}"


def classify(path: Path, columns: list[str], config: dict[str, Any]) -> dict[str, Any]:
    aliases = config["aliases"]
    mapping = {
        key: find_alias(columns, options)
        for key, options in aliases.items()
    }
    labels = detect_labels(columns, config["labels"])
    lower_path = str(path).lower().replace("\\", "/")

    source_required = [
        "source_id", "survey", "R", "Z", "l", "b",
        "teff", "logg", "snr"
    ]
    source_schema = all(mapping.get(key) for key in source_required)
    photometry_ready = mapping.get("photometry") is not None
    distance_quality_ready = mapping.get("distance_quality") is not None
    survey_ready = False
    survey_values = []
    survey_error = ""
    if source_schema:
        survey_ready, survey_values, survey_error = survey_values_ready(
            path, mapping["survey"]
        )

    production_source_ready = bool(
        source_schema and survey_ready and len(labels) >= 5
        and photometry_ready
    )
    authoritative_ready = bool(
        mapping.get("label") and mapping.get("beta_R")
        and mapping.get("beta_Z")
    )
    bootstrap_ready = bool(
        authoritative_ready
        and "bootstrap" in lower_path
        and "draw" in lower_path
    )
    interaction_ready = bool(
        mapping.get("label")
        and (mapping.get("delta_R") or mapping.get("delta_Z"))
    )

    role_scores = {
        "production_source_table": (
            1000 + 50 * len(labels)
            + 25 * int(distance_quality_ready)
            + 20 * int("production" in lower_path or "stage4a" in lower_path)
        ) if production_source_ready else -1,
        "authoritative_gradient_table": (
            1000
            + 100 * int("global_gradient_estimates" in lower_path)
            + 50 * int("stage4b" in lower_path)
        ) if authoritative_ready and not bootstrap_ready else -1,
        "bootstrap_draw_table": (
            1000 + 50 * int("stage4b" in lower_path)
        ) if bootstrap_ready else -1,
        "survey_interaction_table": (
            1000
            + 100 * int("interaction" in lower_path)
            + 50 * int("stage4b" in lower_path)
        ) if interaction_ready else -1
    }

    return {
        "mapping": mapping,
        "labels": labels,
        "survey_values": survey_values,
        "survey_error": survey_error,
        "production_source_ready": production_source_ready,
        "authoritative_gradient_ready": (
            authoritative_ready and not bootstrap_ready
        ),
        "bootstrap_draw_ready": bootstrap_ready,
        "survey_interaction_ready": interaction_ready,
        "photometry_ready": photometry_ready,
        "distance_quality_ready": distance_quality_ready,
        "scores": role_scores
    }


def choose(rows: list[dict[str, Any]], role: str) -> dict[str, Any] | None:
    eligible = [
        row for row in rows
        if row["profile"][f"{role.replace('_table', '')}_ready"]
        if False
    ]
    # Explicit predicates avoid dynamic-name ambiguity.
    predicate = {
        "production_source_table": "production_source_ready",
        "authoritative_gradient_table": "authoritative_gradient_ready",
        "bootstrap_draw_table": "bootstrap_draw_ready",
        "survey_interaction_table": "survey_interaction_ready"
    }[role]
    eligible = [
        row for row in rows
        if row["profile"][predicate]
    ]
    if not eligible:
        return None
    eligible.sort(
        key=lambda row: (
            -int(row["profile"]["scores"][role]),
            -int(row["row_count"] if row["row_count"] not in ("", -1) else 0),
            row["path"]
        )
    )
    return eligible[0]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    config = json.loads(
        (root / "config/stage6d3a_config.json").read_text(encoding="utf-8")
    )
    protocol_path = root / config["protocol_file"]
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))

    out = root / config["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables", "freeze", "reports"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / config["prerequisite_validation"]
    prereq = (
        json.loads(prereq_path.read_text(encoding="utf-8"))
        if prereq_path.exists() else {}
    )
    prereq_ready = bool(
        prereq.get("STAGE6D2A5_DIAGNOSTICS_READY", False)
        and prereq.get("STAGE6D3_FOOTPRINT_PROTOCOL_READY", False)
        and prereq.get("PREDICTIVE_LAW_CLAIM_FORBIDDEN", False)
    )

    frozen_protocol = out / "freeze/stage6d3a_frozen_protocol.json"
    write_json(frozen_protocol, protocol)
    protocol_identity = (
        canonical_json_sha(protocol)
        == canonical_json_sha(
            json.loads(frozen_protocol.read_text(encoding="utf-8"))
        )
    )

    candidates = []
    suffixes = set(config["suffixes"])
    for rel_root in config["search_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in suffixes:
                continue
            try:
                columns, row_count = read_columns(path)
                profile = classify(path, columns, config)
                candidates.append({
                    "path": safe_rel(path, root),
                    "suffix": path.suffix.lower(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                    "row_count": row_count,
                    "column_count": len(columns),
                    "columns": "|".join(columns),
                    "profile": profile,
                    "read_error": ""
                })
            except Exception as exc:
                candidates.append({
                    "path": safe_rel(path, root),
                    "suffix": path.suffix.lower(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                    "row_count": "",
                    "column_count": "",
                    "columns": "",
                    "profile": {
                        "mapping": {},
                        "labels": [],
                        "survey_values": [],
                        "survey_error": "",
                        "production_source_ready": False,
                        "authoritative_gradient_ready": False,
                        "bootstrap_draw_ready": False,
                        "survey_interaction_ready": False,
                        "photometry_ready": False,
                        "distance_quality_ready": False,
                        "scores": {
                            "production_source_table": -1,
                            "authoritative_gradient_table": -1,
                            "bootstrap_draw_table": -1,
                            "survey_interaction_table": -1
                        }
                    },
                    "read_error": f"{type(exc).__name__}: {exc}"
                })

    inventory_rows = []
    for row in candidates:
        profile = row["profile"]
        inventory_rows.append({
            "path": row["path"],
            "suffix": row["suffix"],
            "size_bytes": row["size_bytes"],
            "sha256": row["sha256"],
            "row_count": row["row_count"],
            "column_count": row["column_count"],
            "columns": row["columns"],
            "production_source_ready": str(
                profile["production_source_ready"]
            ).lower(),
            "authoritative_gradient_ready": str(
                profile["authoritative_gradient_ready"]
            ).lower(),
            "bootstrap_draw_ready": str(
                profile["bootstrap_draw_ready"]
            ).lower(),
            "survey_interaction_ready": str(
                profile["survey_interaction_ready"]
            ).lower(),
            "label_count": len(profile["labels"]),
            "labels": "|".join(profile["labels"]),
            "photometry_ready": str(
                profile["photometry_ready"]
            ).lower(),
            "distance_quality_ready": str(
                profile["distance_quality_ready"]
            ).lower(),
            "survey_values": "|".join(profile["survey_values"]),
            "mapping": json.dumps(
                profile["mapping"], sort_keys=True
            ),
            "scores": json.dumps(
                profile["scores"], sort_keys=True
            ),
            "survey_error": profile["survey_error"],
            "read_error": row["read_error"]
        })
    inventory_rows.sort(key=lambda row: row["path"])
    write_csv(
        out / "tables/stage6d3a_exact_input_inventory.csv",
        [
            "path", "suffix", "size_bytes", "sha256", "row_count",
            "column_count", "columns", "production_source_ready",
            "authoritative_gradient_ready", "bootstrap_draw_ready",
            "survey_interaction_ready", "label_count", "labels",
            "photometry_ready", "distance_quality_ready",
            "survey_values", "mapping", "scores",
            "survey_error", "read_error"
        ],
        inventory_rows
    )

    roles = [
        "production_source_table",
        "authoritative_gradient_table",
        "bootstrap_draw_table",
        "survey_interaction_table"
    ]
    selected = {role: choose(candidates, role) for role in roles}
    selection_rows = []
    for role in roles:
        row = selected[role]
        selection_rows.append({
            "role": role,
            "selected": str(row is not None).lower(),
            "path": row["path"] if row else "",
            "score": (
                row["profile"]["scores"][role] if row else ""
            ),
            "row_count": row["row_count"] if row else "",
            "labels": (
                "|".join(row["profile"]["labels"]) if row else ""
            ),
            "mapping": (
                json.dumps(row["profile"]["mapping"], sort_keys=True)
                if row else ""
            )
        })
    write_csv(
        out / "tables/stage6d3a_selected_inputs.csv",
        [
            "role", "selected", "path", "score",
            "row_count", "labels", "mapping"
        ],
        selection_rows
    )

    source_ready = selected["production_source_table"] is not None
    baseline_ready = selected["authoritative_gradient_table"] is not None
    bootstrap_ready = selected["bootstrap_draw_table"] is not None
    interaction_ready = selected["survey_interaction_table"] is not None

    remaining = []
    if not source_ready:
        remaining.append({
            "gate": "EXACT_PRODUCTION_SOURCE_TABLE_READY",
            "required_action": (
                "Locate a unique source-level frozen production table containing both "
                "survey groups, Galactic R/Z, l/b, Teff, logg, S/N, Gaia photometry, "
                "and at least five gradient labels."
            )
        })
    if not baseline_ready:
        remaining.append({
            "gate": "FROZEN_FULL_SUPPORT_GRADIENTS_READY",
            "required_action": (
                "Locate the authoritative Stage-4B global-gradient estimate table."
            )
        })
    if not bootstrap_ready:
        remaining.append({
            "gate": "FROZEN_FULL_SUPPORT_BOOTSTRAP_READY",
            "required_action": (
                "Locate the Stage-4B gradient bootstrap-draw product."
            )
        })
    if not interaction_ready:
        remaining.append({
            "gate": "EXISTING_SURVEY_INTERACTION_PRODUCT_READY",
            "required_action": (
                "Locate the Stage-4B survey-interaction table or document its absence."
            )
        })
    write_csv(
        out / "tables/stage6d3a_remaining_items.csv",
        ["gate", "required_action"],
        remaining
    )

    protocol_ready = bool(prereq_ready and protocol_identity)
    construction_ready = bool(
        protocol_ready and source_ready and baseline_ready and bootstrap_ready
    )

    claim_rows = [
        {
            "claim_id": "D3A-C1",
            "status": "FROZEN_PROTOCOL",
            "claim": (
                "Common footprint is defined by shared sky and non-outcome "
                "covariate support, never by target abundance."
            )
        },
        {
            "claim_id": "D3A-C2",
            "status": "FORBIDDEN_BEFORE_D4",
            "claim": "Any gradient is footprint-stable."
        },
        {
            "claim_id": "D3A-C3",
            "status": "FORBIDDEN",
            "claim": "The matched sample is volume complete."
        },
        {
            "claim_id": "D3A-C4",
            "status": "FORBIDDEN",
            "claim": "GALAH independently replicates the APOGEE-dominated atlas."
        }
    ]
    write_csv(
        out / "tables/stage6d3a_claim_ledger.csv",
        ["claim_id", "status", "claim"],
        claim_rows
    )

    validation = {
        "stage": config["stage"],
        "protocol_version": config["protocol_version"],
        "implementation_version": config["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "frozen_protocol": safe_rel(frozen_protocol, root),
        "frozen_protocol_canonical_sha256": canonical_json_sha(protocol),
        "candidate_file_count": len(candidates),
        "selected_production_source_table": (
            selected["production_source_table"]["path"]
            if selected["production_source_table"] else ""
        ),
        "selected_authoritative_gradient_table": (
            selected["authoritative_gradient_table"]["path"]
            if selected["authoritative_gradient_table"] else ""
        ),
        "selected_bootstrap_draw_table": (
            selected["bootstrap_draw_table"]["path"]
            if selected["bootstrap_draw_table"] else ""
        ),
        "selected_survey_interaction_table": (
            selected["survey_interaction_table"]["path"]
            if selected["survey_interaction_table"] else ""
        ),
        "prior_stage_outputs_modified": False,
        "STAGE6D2A5_PREREQUISITE_READY": prereq_ready,
        "PROTOCOL_SEMANTIC_IDENTITY_READY": protocol_identity,
        "COMMON_FOOTPRINT_DEFINITION_FROZEN": True,
        "TARGET_ABUNDANCE_MATCHING_FORBIDDEN": True,
        "SURVEY_BALANCE_METHOD_FROZEN": True,
        "GRADIENT_MODEL_CONTRACT_FROZEN": True,
        "HEALPIX_BLOCK_BOOTSTRAP_FROZEN": True,
        "PRACTICAL_EQUIVALENCE_MARGINS_FROZEN": True,
        "CLAIM_BOUNDARIES_FROZEN": True,
        "EXACT_PRODUCTION_SOURCE_TABLE_READY": source_ready,
        "FROZEN_FULL_SUPPORT_GRADIENTS_READY": baseline_ready,
        "FROZEN_FULL_SUPPORT_BOOTSTRAP_READY": bootstrap_ready,
        "EXISTING_SURVEY_INTERACTION_PRODUCT_READY": interaction_ready,
        "STAGE6D3A_PROTOCOL_READY": protocol_ready,
        "STAGE6D3B_COMMON_FOOTPRINT_READY": construction_ready
    }
    write_json(
        out / "validation/stage6d3a_validation.json",
        validation
    )

    summary = {
        "stage": config["stage"],
        "timestamp_utc": utc_now(),
        "protocol": protocol,
        "selected_inputs": {
            role: selected[role]["path"] if selected[role] else ""
            for role in roles
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "The common-footprint protocol is frozen and exact construction inputs "
            "are ready. Stage-6D3B construction is authorized."
            if construction_ready else
            (
                "The common-footprint protocol is frozen, but construction remains "
                "blocked by the listed exact-input gaps."
                if protocol_ready else
                "The Stage-6D3A protocol freeze is not valid."
            )
        )
    }
    write_json(
        out / "summaries/stage6d3a_summary.json",
        summary
    )

    report = [
        "# Stage-6D3A common-footprint protocol freeze",
        "",
        f"- Prerequisite ready: `{prereq_ready}`",
        f"- Protocol semantic identity: `{protocol_identity}`",
        f"- Production source table: `{validation['selected_production_source_table'] or 'not found'}`",
        f"- Full-support gradients: `{validation['selected_authoritative_gradient_table'] or 'not found'}`",
        f"- Bootstrap draws: `{validation['selected_bootstrap_draw_table'] or 'not found'}`",
        f"- Existing interaction table: `{validation['selected_survey_interaction_table'] or 'not found'}`",
        f"- Construction ready: `{construction_ready}`",
        "",
        "Target abundance, Galactic R, and |Z| are forbidden matching variables.",
        "No footprint-stability claim is made at this stage.",
        ""
    ]
    (
        out / "reports/stage6d3a_common_footprint_protocol_freeze.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
