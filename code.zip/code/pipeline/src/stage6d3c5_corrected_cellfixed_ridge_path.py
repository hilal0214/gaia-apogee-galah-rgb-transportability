from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def now():
    return datetime.now(timezone.utc).isoformat()


def rel(path: Path, root: Path):
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def wjson(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def wcsv(path: Path, fields, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as h:
        w = csv.DictWriter(h, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def resolve(path: Path):
    for q in [path, path.with_suffix(".csv"), path.with_suffix(".feather")]:
        if q.exists():
            return q
    return None


def read_table(path: Path):
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower() == ".feather":
        return pd.read_feather(path)
    return pd.read_csv(path)


def fold_of(source_id, k):
    d = hashlib.sha256(str(source_id).encode("utf-8")).digest()
    return int.from_bytes(d[:8], "big") % int(k)


def weighted_mean(x, w):
    x = np.asarray(x, float)
    w = np.asarray(w, float)
    ok = np.isfinite(x) & np.isfinite(w) & (w > 0)
    if not np.any(ok):
        return np.nan
    return float(np.sum(x[ok] * w[ok]) / np.sum(w[ok]))


def weighted_var(x, w):
    x = np.asarray(x, float)
    w = np.asarray(w, float)
    ok = np.isfinite(x) & np.isfinite(w) & (w > 0)
    if np.sum(ok) < 2:
        return np.nan
    x = x[ok]
    w = w[ok]
    m = np.sum(x * w) / np.sum(w)
    return float(np.sum(w * (x - m) ** 2) / np.sum(w))


def ess(w):
    w = np.asarray(w, float)
    w = w[np.isfinite(w) & (w > 0)]
    if len(w) == 0:
        return 0.0
    denom = np.sum(w ** 2)
    return float((np.sum(w) ** 2) / denom) if denom > 0 else 0.0


def smd(frame, field, weight_col, cfg):
    x = pd.to_numeric(frame[field], errors="coerce").to_numpy(float)
    w = pd.to_numeric(frame[weight_col], errors="coerce").to_numpy(float)
    a = (frame["survey"] == cfg["apogee_label"]).to_numpy()
    g = (frame["survey"] == cfg["galah_label"]).to_numpy()
    ma = weighted_mean(x[a], w[a])
    mg = weighted_mean(x[g], w[g])
    va = weighted_var(x[a], w[a])
    vg = weighted_var(x[g], w[g])
    pooled = (
        math.sqrt(0.5 * (va + vg))
        if np.isfinite(va) and np.isfinite(vg) else np.nan
    )
    value = (
        (mg - ma) / pooled
        if np.isfinite(pooled) and pooled > 0 else np.nan
    )
    return {
        "feature": field,
        "APOGEE_mean": ma,
        "GALAH_mean": mg,
        "pooled_sd": pooled,
        "smd_GALAH_minus_APOGEE": value,
        "absolute_smd": abs(value) if np.isfinite(value) else np.nan,
    }


def crossfit_cellfixed(frame, C, cfg):
    Xc = frame[cfg["feature_fields"]].apply(
        pd.to_numeric, errors="coerce"
    ).to_numpy(float)
    if not np.all(np.isfinite(Xc)):
        raise RuntimeError("non-finite continuous features")

    cells = frame[[cfg["cell_field"]]].astype(str).to_numpy()
    y = (frame["survey"] == cfg["galah_label"]).astype(int).to_numpy()
    folds = np.array([
        fold_of(x, cfg["n_folds"]) for x in frame["source_id"]
    ], int)

    p = np.full(len(frame), np.nan)
    fold_rows = []

    for fold in range(int(cfg["n_folds"])):
        test = folds == fold
        train = ~test
        if set(np.unique(y[train]).tolist()) != {0, 1}:
            raise RuntimeError(f"fold {fold} lacks both surveys")

        scaler = StandardScaler()
        Xtr_cont = scaler.fit_transform(Xc[train])
        Xte_cont = scaler.transform(Xc[test])

        encoder = OneHotEncoder(
            handle_unknown="ignore",
            sparse_output=True
        )
        Xtr_cell = encoder.fit_transform(cells[train])
        Xte_cell = encoder.transform(cells[test])

        Xtr = sparse.hstack(
            [sparse.csr_matrix(Xtr_cont), Xtr_cell],
            format="csr"
        )
        Xte = sparse.hstack(
            [sparse.csr_matrix(Xte_cont), Xte_cell],
            format="csr"
        )

        model = LogisticRegression(
            C=float(C),
            solver="lbfgs",
            max_iter=int(cfg["logistic_max_iter"]),
            fit_intercept=True,
            random_state=0,
        )
        model.fit(Xtr, y[train])
        p[test] = model.predict_proba(Xte)[:, 1]

        fold_rows.append({
            "C": float(C),
            "fold": fold,
            "train_rows": int(train.sum()),
            "heldout_rows": int(test.sum()),
            "training_cell_levels": int(len(encoder.categories_[0])),
            "design_columns": int(Xtr.shape[1]),
        })

    if not np.all(np.isfinite(p)):
        raise RuntimeError("non-finite OOF propensity")
    return p, folds, fold_rows


def raw_weights(frame, p, branch, cfg):
    gal = (frame["survey"] == cfg["galah_label"]).to_numpy()
    if branch == "LITERAL_FROZEN_JSON":
        return np.where(gal, p, 1.0 - p)
    if branch == "STANDARD_OVERLAP_SEMANTICS":
        return np.where(gal, 1.0 - p, p)
    raise ValueError(branch)


def within_survey_cap(frame, raw, cfg):
    capped = np.asarray(raw, float).copy()
    caps = {}
    for survey in cfg["surveys"]:
        mask = (frame["survey"] == survey).to_numpy()
        cap = float(
            np.quantile(raw[mask], float(cfg["weight_cap_quantile"]))
        )
        capped[mask] = np.minimum(raw[mask], cap)
        caps[survey] = cap
    return capped, caps


def normalize_cell(frame, capped, branch, cfg):
    final = np.zeros(len(frame), float)
    for cell, idx0 in frame.groupby(
        cfg["cell_field"], sort=True
    ).groups.items():
        idx = np.asarray(list(idx0), int)
        surveys = frame.loc[idx, "survey"].astype(str).to_numpy()
        totals = {
            s: float(np.sum(capped[idx][surveys == s]))
            for s in cfg["surveys"]
        }
        if any(totals[s] <= 0 for s in cfg["surveys"]):
            raise RuntimeError(
                f"cell {cell}: non-positive survey total"
            )

        if branch == "UNIT_TOTAL_PER_SURVEY_PER_CELL":
            target = 1.0
        elif branch == "PRIOR_ARITHMETIC_MEAN_TARGET":
            target = 0.5 * sum(totals.values())
        else:
            raise ValueError(branch)

        for survey in cfg["surveys"]:
            mask = surveys == survey
            factor = target / totals[survey]
            final[idx[mask]] = capped[idx][mask] * factor

    return final


def evaluate(frame, weights, p, cfg):
    work = frame.copy()
    work["audit_weight"] = weights

    smd_rows = [
        smd(work, field, "audit_weight", cfg)
        for field in cfg["feature_fields"]
    ]
    max_smd = max(
        [
            r["absolute_smd"]
            for r in smd_rows
            if np.isfinite(r["absolute_smd"])
        ],
        default=np.nan
    )

    ratios = {}
    for survey in cfg["surveys"]:
        mask = work["survey"] == survey
        ratios[survey] = (
            ess(work.loc[mask, "audit_weight"].to_numpy(float))
            / int(mask.sum())
        )

    pmin = float(np.min(p))
    pmax = float(np.max(p))
    prop_pass = bool(
        pmin >= float(cfg["propensity_lower_gate"])
        and pmax <= float(cfg["propensity_upper_gate"])
    )
    smd_pass = bool(
        np.isfinite(max_smd)
        and max_smd <= float(cfg["maximum_absolute_smd_gate"])
    )
    ess_pass = all(
        value >= float(cfg["minimum_ess_raw_ratio_gate"])
        for value in ratios.values()
    )

    return {
        "propensity_min": pmin,
        "propensity_max": pmax,
        "propensity_gate_pass": prop_pass,
        "maximum_absolute_smd": max_smd,
        "smd_gate_pass": smd_pass,
        "APOGEE_ESS_raw_ratio": ratios[cfg["apogee_label"]],
        "GALAH_ESS_raw_ratio": ratios[cfg["galah_label"]],
        "ess_gate_pass": ess_pass,
        "all_numeric_gates_pass": bool(
            prop_pass and smd_pass and ess_pass
        ),
    }, smd_rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3c5_config.json").read_text(
            encoding="utf-8"
        )
    )

    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in [
        "validation", "tables", "diagnostic",
        "summaries", "reports"
    ]:
        (out / d).mkdir(parents=True, exist_ok=True)

    prepath = root / cfg["prerequisite_validation"]
    pre = (
        json.loads(prepath.read_text())
        if prepath.exists() else {}
    )
    prereq = bool(
        pre.get("STAGE6D3C4_RECONCILIATION_READY", False)
        and pre.get("CELL_FIXED_EFFECTS_RESTORED", False)
        and pre.get("P99_CAP_WITHIN_SURVEY_RESTORED", False)
        and not pre.get("STAGE6D4_SCIENCE_MODELS_READY", True)
        and pre.get("classification")
        == "PROPENSITY_GATE_FAILS_AFTER_RESTORING_CELL_FIXED_EFFECTS"
    )

    source_path = resolve(root / cfg["common_footprint_source"])
    if not source_path:
        raise FileNotFoundError("D3B1 common-footprint source missing")

    frame = read_table(source_path).reset_index(drop=True)
    required = {
        "source_id", "survey", cfg["cell_field"],
        *cfg["feature_fields"]
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise RuntimeError(f"missing fields: {missing}")

    matrix = []
    all_smd = []
    fold_rows_all = []
    passing = []

    for C in cfg["ridge_C_grid_descending"]:
        p, folds, fold_rows = crossfit_cellfixed(
            frame, float(C), cfg
        )
        fold_rows_all.extend(fold_rows)

        for wf in cfg["weight_formula_branches"]:
            raw = raw_weights(frame, p, wf, cfg)
            capped, caps = within_survey_cap(frame, raw, cfg)

            for nb in cfg["normalization_branches"]:
                weights = normalize_cell(
                    frame, capped, nb, cfg
                )
                met, smd_rows = evaluate(
                    frame, weights, p, cfg
                )
                branch = f"{wf}__{nb}"

                row = {
                    "C": float(C),
                    "branch": branch,
                    "weight_formula_branch": wf,
                    "normalization_branch": nb,
                    "APOGEE_p99_cap": caps[cfg["apogee_label"]],
                    "GALAH_p99_cap": caps[cfg["galah_label"]],
                    **met,
                }
                matrix.append(row)

                for r in smd_rows:
                    all_smd.append({
                        "C": float(C),
                        "branch": branch,
                        **r,
                    })

                if row["all_numeric_gates_pass"]:
                    passing.append(row)

    wcsv(
        out / "diagnostic/stage6d3c5_corrected_ridge_path_matrix.csv",
        [
            "C", "branch", "weight_formula_branch",
            "normalization_branch",
            "APOGEE_p99_cap", "GALAH_p99_cap",
            "propensity_min", "propensity_max",
            "propensity_gate_pass",
            "maximum_absolute_smd", "smd_gate_pass",
            "APOGEE_ESS_raw_ratio", "GALAH_ESS_raw_ratio",
            "ess_gate_pass", "all_numeric_gates_pass"
        ],
        matrix,
    )

    wcsv(
        out / "diagnostic/stage6d3c5_feature_smd_by_C_branch.csv",
        [
            "C", "branch", "feature",
            "APOGEE_mean", "GALAH_mean", "pooled_sd",
            "smd_GALAH_minus_APOGEE", "absolute_smd"
        ],
        all_smd,
    )

    wcsv(
        out / "diagnostic/stage6d3c5_fold_design_ledger.csv",
        [
            "C", "fold", "train_rows", "heldout_rows",
            "training_cell_levels", "design_columns"
        ],
        fold_rows_all,
    )

    passing.sort(
        key=lambda r: (
            -float(r["C"]),
            0 if r["weight_formula_branch"]
            == "STANDARD_OVERLAP_SEMANTICS" else 1,
            0 if r["normalization_branch"]
            == "PRIOR_ARITHMETIC_MEAN_TARGET" else 1,
        )
    )
    best = passing[0] if passing else {}

    standard_arithmetic = [
        r for r in matrix
        if r["weight_formula_branch"]
        == "STANDARD_OVERLAP_SEMANTICS"
        and r["normalization_branch"]
        == "PRIOR_ARITHMETIC_MEAN_TARGET"
    ]
    standard_arithmetic.sort(key=lambda r: -float(r["C"]))

    first_propensity_passing_C = None
    for r in standard_arithmetic:
        if r["propensity_gate_pass"]:
            first_propensity_passing_C = float(r["C"])
            break

    first_all_passing_standard_arithmetic_C = None
    for r in standard_arithmetic:
        if r["all_numeric_gates_pass"]:
            first_all_passing_standard_arithmetic_C = float(r["C"])
            break

    if passing:
        classification = (
            "CORRECTED_CELLFIXED_RIDGE_PATH_HAS_NUMERICALLY_VALID_BRANCH"
        )
        next_action = (
            "A numeric gate-satisfying branch exists under the corrected "
            "frozen survey model. Do not promote it yet: freeze ridge C, "
            "overlap-weight formula semantics, and per-cell target semantics "
            "in a formal protocol-closure stage first."
        )
    elif first_propensity_passing_C is not None:
        classification = (
            "PROPENSITY_GATE_RECOVERABLE_BUT_OTHER_BALANCE_GATE_FAILS"
        )
        next_action = (
            "Regularization can restore the propensity range, but SMD or ESS "
            "still fails. Inspect the corrected path matrix before any further "
            "protocol change."
        )
    else:
        classification = (
            "PROPENSITY_GATE_NOT_RECOVERED_ON_CORRECTED_RIDGE_PATH"
        )
        next_action = (
            "Even strong ridge shrinkage with frozen cell fixed effects does "
            "not restore the propensity gate. Keep D4 blocked and treat the "
            "current common-support/balancing design as requiring protocol-level "
            "revision rather than further hyperparameter tuning."
        )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "classification": classification,
        "input_rows": len(frame),
        "cell_count": int(frame[cfg["cell_field"]].nunique()),
        "tested_C_grid": cfg["ridge_C_grid_descending"],
        "fully_passing_numeric_branch_count": len(passing),
        "best_numeric_candidate": best,
        "standard_overlap_prior_arithmetic_first_propensity_passing_C":
            first_propensity_passing_C,
        "standard_overlap_prior_arithmetic_first_all_gates_passing_C":
            first_all_passing_standard_arithmetic_C,
        "STAGE6D3C4_PREREQUISITE_READY": prereq,
        "CELL_FIXED_EFFECTS_INCLUDED_FOR_ALL_C": True,
        "P99_CAP_WITHIN_SURVEY_FOR_ALL_C": True,
        "NO_FROZEN_THRESHOLD_WEAKENED": True,
        "NO_BALANCING_FEATURE_CHANGED": True,
        "NO_OUTCOME_ABUNDANCE_R_ABSZ_USED": True,
        "RIDGE_C_PATH_OUTCOME_BLIND": True,
        "NUMERIC_CANDIDATE_EXISTS": bool(passing),
        "FORMAL_PROTOCOL_CLOSURE_REQUIRED_BEFORE_PRODUCTION": True,
        "PRODUCTION_BALANCED_WEIGHTS_READY": False,
        "DIAGNOSTIC_ONLY": True,
        "STAGE6D3C5_RIDGE_PATH_READY": prereq,
        "STAGE6D4_SCIENCE_MODELS_READY": False,
    }
    wjson(
        out / "validation/stage6d3c5_validation.json",
        validation,
    )

    summary = {
        "classification": classification,
        "best_numeric_candidate": best,
        "first_propensity_passing_C_standard_overlap_prior_arithmetic":
            first_propensity_passing_C,
        "first_all_gates_passing_C_standard_overlap_prior_arithmetic":
            first_all_passing_standard_arithmetic_C,
        "next_action": next_action,
        "scientific_disposition": (
            "This is the first ridge-path audit that exactly preserves the "
            "Stage-6D3A cell-fixed-effect propensity model and within-survey "
            "p99 cap. It remains diagnostic and cannot authorize D4."
        ),
    }
    wjson(
        out / "summaries/stage6d3c5_summary.json",
        summary,
    )

    (out / "reports/stage6d3c5_report.md").write_text(
        "\n".join([
            "# Stage-6D3C5 corrected cell-fixed-effect ridge-C path",
            "",
            f"- Classification: `{classification}`",
            f"- Tested C values: `{len(cfg['ridge_C_grid_descending'])}`",
            f"- Fully passing numeric branches: `{len(passing)}`",
            f"- Best numeric candidate: `{best}`",
            f"- Standard-overlap/prior-arithmetic first propensity PASS C: "
            f"`{first_propensity_passing_C}`",
            f"- Standard-overlap/prior-arithmetic first all-gates PASS C: "
            f"`{first_all_passing_standard_arithmetic_C}`",
            "- Production weights authorized: `False`",
            "- Stage-6D4 authorized: `False`",
            "",
            next_action,
            "",
        ]),
        encoding="utf-8",
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
