from __future__ import annotations
import argparse,csv,hashlib,json,re,shutil,subprocess,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def canon(o):
    return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def replace_exact(text,old,new,label):
    n=text.count(old)
    if n!=1: raise RuntimeError(f"{label}: expected exactly one occurrence, found {n}")
    return text.replace(old,new,1)

def make_figure(intervals,resolution,pdf):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    labels={
      "valley":r"$\Delta\,\alpha_{\rm valley}$ [dex]",
      "separation":r"$\Delta\,(\mu_{\rm high}-\mu_{\rm low})$ [dex]",
      "fraction":r"$\Delta\,\pi_{\rm high}$"
    }
    margins={"valley":.03,"separation":.04,"fraction":.08}
    fig,axs=plt.subplots(3,1,figsize=(7.25,8.35),sharex=True)
    for ax,e in zip(axs,["valley","separation","fraction"]):
        q=intervals[intervals.estimand==e].sort_values("feh_knot")
        x=q.feh_knot.to_numpy(float); y=q.point_difference.to_numpy(float)
        lo=q.ci_low.to_numpy(float); hi=q.ci_high.to_numpy(float)
        ax.errorbar(x,y,yerr=np.vstack([y-lo,hi-y]),fmt="o",capsize=4,
                    linewidth=1.25,markersize=5.5)
        ax.axhline(0,linewidth=.9)
        ax.axhline(+margins[e],linewidth=.9,linestyle="--")
        ax.axhline(-margins[e],linewidth=.9,linestyle="--")
        ax.set_ylabel(labels[e],fontsize=11)
        ax.tick_params(labelsize=10)
        ax.grid(alpha=.18)
    axs[-1].set_xlabel(r"$[\mathrm{Fe/H}]$ knot",fontsize=11)
    axs[-1].set_xticks([-0.6,-0.4,-0.2,0.0,0.2,0.4])
    fig.tight_layout()
    pdf.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(pdf,bbox_inches="tight")
    plt.close(fig)

def pdf_pages_from_log(logtxt):
    m=re.findall(r"Output written on main\.pdf \((\d+) pages?",logtxt)
    return int(m[-1]) if m else None

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage6d6c5_config.json").read_text(encoding="utf-8"))
    prot=json.loads((root/"protocol/stage6d6c5_protocol.json").read_text(encoding="utf-8"))
    sv=json.loads((root/c["source_validation"]).read_text(encoding="utf-8"))
    srcdir=root/c["source_manuscript_dir"]

    source_ready=bool(
      sv.get("D6C_SCIENCE_INTEGRATION_READY") is True and
      sv.get("D6B_BASELINE_MAIN_EXACT_SHA_READY") is True and
      sv.get("D6B_BASELINE_WAS_MODIFIED_IN_PLACE") is False and
      sv.get("STAGE7_RADIAL_BRANCH_CLOSURE_READY") is True and
      sv.get("STAGE8F_PARENT_READY") is True and
      sv.get("STAGE8_FROZEN_RESULT_IDENTITY_READY") is True and
      sv.get("FROZEN_STAGE8_OVERALL_CLASSIFICATION")=="INDETERMINATE" and
      sv.get("NEW_REAL_SCIENCE_FIT_PERFORMED_BY_D6C") is False and
      sv.get("NEW_BOOTSTRAP_PERFORMED_BY_D6C") is False and
      sv.get("FROZEN_SCIENCE_GATE_CHANGED_BY_D6C") is False and
      sv.get("MANUSCRIPT_MAIN_TEX_SHA256")==c["expected_source_main_sha256"]
    )
    if not source_ready: raise RuntimeError("D6C source science/identity guards failed")
    if sha_file(srcdir/"main.tex")!=c["expected_source_main_sha256"]:
        raise RuntimeError("D6C source main.tex byte identity mismatch")

    out=root/c["output_dir"]; mdir=out/"manuscript"
    if mdir.exists(): shutil.rmtree(mdir)
    shutil.copytree(srcdir,mdir)

    text=(mdir/"main.tex").read_text(encoding="utf-8")

    text=replace_exact(
      text,
      r"\subsection{Power-calibrated $\alpha$-sequence morphology transport}",
      r"\subsection{Power-calibrated alpha-sequence morphology transport}",
      "hyperref-heading"
    )

    text=replace_exact(
      text,
      r"""\begin{tabular}{lrrrr}
\toprule
Estimand & Zero-excl. & Equiv. & Sensitive & Class\\""",
      r"""\small
\setlength{\tabcolsep}{3.0pt}
\begin{tabular}{@{}lrrrr@{}}
\toprule
Estimand & Zero-excl. & Equiv. & Sensitive & Class\\""",
      "morphology-table-width"
    )

    old_archive=(r"The frozen Stage-6 technical reproducibility archive remains "
                 r"\texttt{RGB\_transportability\_science\_release\_v0\_26\_1.zip} "
                 r"(SHA-256 \texttt{6519cd827bd2d01c5b4fe0c300690d4de5ffd6db665e7350a6a934eacf872b63}). "
                 r"It contains the common-footprint production estimates, 4096-draw gradient bootstrap products, "
                 r"practical-equivalence classifications, claim ledgers, exact analysis code/configuration, "
                 r"and SHA-256 manifests used by the D6B baseline.")
    new_archive=(r"""The frozen Stage-6 technical reproducibility archive remains
\texttt{RGB\_transportability\_science\_release\_v0\_26\_1.zip}.  Its SHA-256 is
\begin{center}
\small\texttt{6519cd827bd2d01c5b4fe0c300690d4d}\\[-0.2ex]
\texttt{e5ffd6db665e7350a6a934eacf872b63}
\end{center}
It contains the common-footprint production estimates, 4096-draw gradient bootstrap products,
practical-equivalence classifications, claim ledgers, exact analysis code/configuration,
and SHA-256 manifests used by the D6B baseline.""")
    text=replace_exact(text,old_archive,new_archive,"archive-sha-layout")

    oldcap=(r"Dashed horizontal lines mark the pre-specified practical margins. "
            r"``Better-resolved'' annotations in the separation panel are post-hoc descriptive identifiability "
            r"diagnostics only and do not enter the transport classification.")
    newcap=(r"Dashed horizontal lines mark the pre-specified practical margins. "
            r"The component-resolution diagnostic discussed in the text is post-hoc and descriptive only; "
            r"it does not enter the transport classification.")
    text=replace_exact(text,oldcap,newcap,"figure-caption")

    if re.search(r"\\(?:input|include)\s*\{",text):
        raise RuntimeError("flat main.tex guard failed")
    (mdir/"main.tex").write_text(text,encoding="utf-8")

    intervals=pd.read_csv(root/c["source_intervals"])
    resolution=pd.read_csv(root/c["source_identifiability"])
    make_figure(intervals,resolution,mdir/"figures/figure05_alpha_morphology_transport.pdf")
    png=mdir/"figures/figure05_alpha_morphology_transport.png"
    if png.exists(): png.unlink()

    # Remove stale/intermediate D6B or compile artifacts from copied branch.
    stale=[
      "PDF_PREFLIGHT.json","PROVENANCE_MANIFEST.json","STAGE6D6B_FINAL_POLISH_REPORT.md",
      "STAGE6D6B_VALIDATION.json","SHA256SUMS_STAGE6D6B.csv",
      "main.aux","main.log","main.out"
    ]
    for name in stale:
        p=mdir/name
        if p.exists(): p.unlink()

    # D6C-specific README before compile.
    readme="""# RGB MNRAS D6C v1.3.1 - science-integrated final source

This package extends the frozen D6B manuscript with the pre-outcome Stage-7 radial-transition
power closure and the power-calibrated Stage-8 alpha-sequence morphology transport audit.

Science boundaries:
- Stage-7 is a power-limited design closure, not a real-data no-break result.
- Stage-8 overall morphology classification remains INDETERMINATE.
- The cleanest descriptive sequence-separation differences occur at [Fe/H] = -0.6 and -0.4.
- The -0.2 and 0.0 separation points require mixture-identifiability caution.
- INDETERMINATE is not unstable or non-transportable.
- No Stage-7/8 numerical gate, practical margin, bootstrap result, or classification was changed by D6C5.

Submission metadata still requiring human verification:
authors, affiliations, correspondence, funding, CRediT, repository URL, exact DOI and concept DOI.
"""
    (mdir/"README.md").write_text(readme,encoding="utf-8")

    pdflatex=shutil.which("pdflatex")
    if not pdflatex: raise RuntimeError("pdflatex not found")
    compile_runs=[]
    for i in range(3):
        cp=subprocess.run([pdflatex,"-interaction=nonstopmode","-halt-on-error","main.tex"],
                          cwd=mdir,capture_output=True,text=True)
        compile_runs.append({"pass":i+1,"returncode":cp.returncode,
                             "stdout_tail":cp.stdout[-4000:],"stderr_tail":cp.stderr[-1000:]})
        if cp.returncode!=0: break
    logtxt=(mdir/"main.log").read_text(encoding="utf-8",errors="ignore") if (mdir/"main.log").exists() else ""
    overfull=[x for x in logtxt.splitlines() if "Overfull \\hbox" in x]
    undef=[x for x in logtxt.splitlines() if "undefined" in x.lower() and ("citation" in x.lower() or "reference" in x.lower())]
    fatal=(len(compile_runs)!=3 or any(x["returncode"]!=0 for x in compile_runs))
    pages=pdf_pages_from_log(logtxt)
    compiled_clean=bool(not fatal and not overfull and not undef and (mdir/"main.pdf").exists())

    # D6C-specific preflight.
    preflight={
      "path":"main.pdf","ok_open":(mdir/"main.pdf").exists(),
      "pages":pages,"encrypted":False,"likely_scanned":False,
      "overfull_hboxes":overfull,"undefined_reference_or_citation_lines":undef
    }
    write_json(mdir/"PDF_PREFLIGHT_D6C.json",preflight)

    validation={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "SOURCE_D6C_SCIENCE_IDENTITY_READY":source_ready,
      "SOURCE_MAIN_TEX_SHA256":c["expected_source_main_sha256"],
      "NEW_REAL_SCIENCE_FIT_PERFORMED":False,
      "NEW_BOOTSTRAP_PERFORMED":False,
      "FROZEN_SCIENCE_GATE_CHANGED":False,
      "FROZEN_STAGE8_OVERALL_CLASSIFICATION":"INDETERMINATE",
      "FIGURE_ALPHA_MORPHOLOGY_REGENERATED_LAYOUT_ONLY":True,
      "STALE_D6B_VALIDATION_ARTIFACTS_REMOVED":True,
      "UNREFERENCED_FIGURE_PNG_REMOVED":True,
      "FLAT_MAIN_TEX_READY":True,
      "THREE_PASS_COMPILE_READY":bool(len(compile_runs)==3 and all(x["returncode"]==0 for x in compile_runs)),
      "NO_UNDEFINED_CITATIONS_OR_REFERENCES":not undef,
      "NO_OVERFULL_HBOX":not overfull,
      "PDF_PAGES":pages,
      "PDF_COMPILED_CLEANLY":compiled_clean,
      "MAIN_TEX_SHA256":sha_file(mdir/"main.tex"),
      "MAIN_PDF_SHA256":sha_file(mdir/"main.pdf") if (mdir/"main.pdf").exists() else None,
      "HUMAN_METADATA_READY":False,
      "MNRAS_PUBLIC_SUBMISSION_READY":False,
      "D6C5_FINAL_EDITORIAL_PACKAGING_READY":compiled_clean,
      "PROTOCOL_CANONICAL_SHA256":canon(prot),
      "COMPILE_RUNS":compile_runs
    }
    write_json(mdir/"STAGE6D6C5_VALIDATION.json",validation)

    provenance={
      "package":"RGB_MNRAS_D6C_FINAL_v1_3_1",
      "created_utc":now(),
      "source_stage":"Stage-6D6C science integration",
      "source_main_tex_sha256":c["expected_source_main_sha256"],
      "science_mutation":False,
      "frozen_stage8_classification":"INDETERMINATE",
      "cleanest_descriptive_knots":[-0.6,-0.4],
      "overlap_caution_knots":[-0.2,0.0],
      "stage6_archive_sha256":"6519cd827bd2d01c5b4fe0c300690d4de5ffd6db665e7350a6a934eacf872b63"
    }
    write_json(mdir/"PROVENANCE_MANIFEST_D6C.json",provenance)

    # Remove raw compile intermediates after audit.
    for name in ["main.aux","main.log","main.out"]:
        p=mdir/name
        if p.exists(): p.unlink()

    # Checksums after final cleanup; exclude checksum file itself.
    rows=[]
    for p in sorted(mdir.rglob("*")):
        if p.is_file() and p.name!="SHA256SUMS_STAGE6D6C.csv":
            rows.append((p.relative_to(mdir).as_posix(),p.stat().st_size,sha_file(p)))
    with (mdir/"SHA256SUMS_STAGE6D6C.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["path","size_bytes","sha256"]); w.writerows(rows)

    # Submission release: no aux/log/out, no stale D6B validation files.
    release=out/c["release_name"]
    if release.exists(): release.unlink()
    with zipfile.ZipFile(release,"w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(mdir.rglob("*")):
            if p.is_file():
                z.write(p,p.relative_to(mdir))

    outer_val=dict(validation)
    outer_val["RELEASE_ZIP_RELATIVE_PATH"]=str(release.relative_to(root))
    outer_val["RELEASE_ZIP_SHA256"]=sha_file(release)
    write_json(out/"validation/stage6d6c5_validation.json",outer_val)
    print(json.dumps(outer_val,indent=2,ensure_ascii=False))
    return 0 if compiled_clean else 2

if __name__=="__main__":
    raise SystemExit(main())
