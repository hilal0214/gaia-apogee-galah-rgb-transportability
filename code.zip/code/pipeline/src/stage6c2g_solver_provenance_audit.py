from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

STAGE = "Stage-6C2G exact Stage-4B solver provenance audit and manuscript residual-claim scrub"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.15.6"

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def safe_rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def write_csv(path: Path, fields: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

def first_existing(root: Path, candidates: list[str]) -> Path | None:
    for value in candidates:
        path = root / value
        if path.exists():
            return path
    return None

def scrub_named_claims(package_root: Path, patterns: list[str]) -> list[dict[str, Any]]:
    replacements = {
        "Low-alpha thin disc": "anonymous latent component",
        "High-alpha disc": "anonymous latent component",
        "Halo-like candidates": "anonymous latent-component candidates",
        "Vertically extended rotating disc": "anonymous latent component",
        "Intermediate disc-like candidates": "ambiguous latent-component candidates",
        "population-resolved gradients": "component-resolved gradients not retained in the claim-safe manuscript",
        "thin-disc, thick-disc, halo": "standard physically named Galactic populations",
        "thin disc, thick disc, halo": "standard physically named Galactic populations",
        "named-population gradients": "physically named population gradients"
    }
    rows = []
    for path in package_root.rglob("*.tex"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        original = text
        for pattern in patterns:
            count = text.lower().count(pattern.lower())
            if count:
                replacement = replacements.get(pattern, "anonymous latent components")
                text = re.sub(re.escape(pattern), replacement, text, flags=re.I)
                rows.append({
                    "path": safe_rel(path, package_root),
                    "pattern": pattern,
                    "replacement": replacement,
                    "count": count
                })
        text = text.replace(r"\input{tables/table05_population_gradients}", "")
        if text != original:
            path.write_text(text, encoding="utf-8")
    return rows

def residual_named_claims(package_root: Path, patterns: list[str]) -> list[dict[str, Any]]:
    rows = []
    for path in package_root.rglob("*.tex"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        for pattern in patterns:
            count = text.lower().count(pattern.lower())
            if count:
                rows.append({
                    "path": safe_rel(path, package_root),
                    "pattern": pattern,
                    "count": count
                })
    return rows

def scan_solver_files(root: Path, cfg: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    suffixes = {x.lower() for x in cfg["scan_suffixes"]}
    writer_hits = []
    parameter_hits = []
    runner_hits = []

    parameter_patterns = {
        "huber_epsilon": re.compile(r"(?:epsilon|huber_(?:epsilon|delta|tuning|c|k))\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)", re.I),
        "max_iter": re.compile(r"max_iter(?:ations)?\s*[:=]\s*([0-9]+)", re.I),
        "tolerance": re.compile(r"(?:tol|tolerance)\s*[:=]\s*([0-9.eE+-]+)", re.I),
        "radial_pivot": re.compile(r"(?:radial_pivot_kpc|pivot_r|r0)\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)", re.I),
        "bootstrap_draws": re.compile(r"(?:bootstrap_draws|n_bootstrap|n_draws)\s*[:=]\s*([0-9]+)", re.I),
        "random_seed": re.compile(r"(?:random_seed|seed|rng_seed)\s*[:=]\s*([0-9]+)", re.I),
    }

    for rel_root in cfg["scan_roots"]:
        directory = root / rel_root
        if not directory.exists():
            continue
        for path in directory.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in suffixes:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
            lines = text.splitlines()

            for token in cfg["writer_tokens"]:
                for line_no, line in enumerate(lines, start=1):
                    if token.lower() in line.lower():
                        excerpt = "\n".join(lines[max(0, line_no-6):min(len(lines), line_no+5)])
                        writer_hits.append({
                            "path": safe_rel(path, root),
                            "line": line_no,
                            "token": token,
                            "excerpt": excerpt
                        })

            for token in cfg["solver_tokens"]:
                for line_no, line in enumerate(lines, start=1):
                    if token.lower() in line.lower():
                        excerpt = "\n".join(lines[max(0, line_no-5):min(len(lines), line_no+4)])
                        parameter_hits.append({
                            "path": safe_rel(path, root),
                            "line": line_no,
                            "evidence_type": "solver_token",
                            "name": token,
                            "value": "",
                            "excerpt": excerpt
                        })

            for name, pattern in parameter_patterns.items():
                for match in pattern.finditer(text):
                    line_no = text[:match.start()].count("\n") + 1
                    excerpt = "\n".join(lines[max(0, line_no-4):min(len(lines), line_no+3)])
                    parameter_hits.append({
                        "path": safe_rel(path, root),
                        "line": line_no,
                        "evidence_type": "parameter_value",
                        "name": name,
                        "value": match.group(1),
                        "excerpt": excerpt
                    })

            if path.suffix.lower() in {".bat", ".cmd", ".ps1"}:
                for line_no, line in enumerate(lines, start=1):
                    low = line.lower()
                    if "stage4b" in low or "global_gradient" in low:
                        runner_hits.append({
                            "path": safe_rel(path, root),
                            "line": line_no,
                            "command": line.strip()
                        })

    return writer_hits, parameter_hits, runner_hits

def summarize_replay(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    frame = pd.read_csv(path)
    rows = []
    required = {"tuning", "label", "status"}
    if not required.issubset(frame.columns):
        return rows
    for tuning, group in frame.groupby("tuning", dropna=False):
        fit = group[group["status"] == "fit"].copy()
        if fit.empty:
            continue
        for label, label_group in fit.groupby("label"):
            row = label_group.iloc[0]
            rows.append({
                "tuning": tuning,
                "label": label,
                "n": row.get("n", ""),
                "delta_beta_r": row.get("delta_beta_r", ""),
                "delta_beta_z": row.get("delta_beta_z", ""),
                "max_abs_delta": row.get("max_abs_delta", ""),
                "converged": row.get("converged", ""),
                "iterations": row.get("iterations", "")
            })
    return rows

def identify_exact_spec(
    writer_hits: list[dict[str, Any]],
    parameter_hits: list[dict[str, Any]],
    runner_hits: list[dict[str, Any]]
) -> dict[str, Any]:
    writer_files = sorted({r["path"] for r in writer_hits})
    solver_files = sorted({
        r["path"] for r in parameter_hits
        if any(token.lower() in (r["name"] + " " + r["excerpt"]).lower()
               for token in ["huber", "irls", "HuberRegressor".lower(), "RLM".lower()])
    })
    parameter_names = {
        r["name"] for r in parameter_hits if r["evidence_type"] == "parameter_value"
    }

    writer_identified = len(writer_files) > 0
    solver_identified = len(solver_files) > 0
    parameters_identified = any(
        name in parameter_names for name in ["huber_epsilon", "max_iter", "tolerance"]
    )
    runner_identified = len(runner_hits) > 0

    return {
        "writer_files": writer_files,
        "solver_files": solver_files,
        "parameter_names": sorted(parameter_names),
        "writer_identified": writer_identified,
        "solver_identified": solver_identified,
        "parameters_identified": parameters_identified,
        "runner_identified": runner_identified,
        "exact_replay_spec_ready": bool(
            writer_identified and solver_identified
            and parameters_identified and runner_identified
        )
    }

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE)
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads((root / "config/stage6c2g_config.json").read_text(encoding="utf-8"))
    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for name in ["validation", "summaries", "tables", "reports", "manuscript_source"]:
        (out_dir / name).mkdir(parents=True, exist_ok=True)

    source_package = first_existing(root, cfg["source_package_candidates"])
    if source_package is None:
        raise FileNotFoundError("No Stage-6C2F/6C2D manuscript source package found.")
    package_root = out_dir / "manuscript_source" / cfg["new_package_name"]
    shutil.copytree(source_package, package_root)

    scrub_rows = scrub_named_claims(package_root, cfg["named_claim_patterns"])
    residual_rows = residual_named_claims(package_root, cfg["named_claim_patterns"])
    write_csv(
        out_dir / "tables/stage6c2g_named_claim_scrub.csv",
        ["path", "pattern", "replacement", "count"],
        scrub_rows
    )
    write_csv(
        out_dir / "tables/stage6c2g_named_claim_residuals.csv",
        ["path", "pattern", "count"],
        residual_rows
    )

    writer_hits, parameter_hits, runner_hits = scan_solver_files(root, cfg)
    write_csv(
        out_dir / "tables/stage6c2g_solver_file_hits.csv",
        ["path", "line", "token", "excerpt"],
        writer_hits
    )
    write_csv(
        out_dir / "tables/stage6c2g_solver_parameter_evidence.csv",
        ["path", "line", "evidence_type", "name", "value", "excerpt"],
        parameter_hits
    )
    write_csv(
        out_dir / "tables/stage6c2g_runner_lineage.csv",
        ["path", "line", "command"],
        runner_hits
    )

    replay_rows = summarize_replay(root / cfg["replay_identity_csv"])
    write_csv(
        out_dir / "tables/stage6c2g_replay_delta_summary.csv",
        ["tuning", "label", "n", "delta_beta_r", "delta_beta_z",
         "max_abs_delta", "converged", "iterations"],
        replay_rows
    )

    spec = identify_exact_spec(writer_hits, parameter_hits, runner_hits)
    write_json(out_dir / "summaries/stage6c2g_exact_replay_spec.json", spec)

    remaining = []
    if residual_rows:
        remaining.append({
            "gate": "NAMED_POPULATION_CLAIMS_REMOVED",
            "required_action": "Residual unsupported population phrases remain; inspect stage6c2g_named_claim_residuals.csv."
        })
    if not spec["writer_identified"]:
        remaining.append({
            "gate": "STAGE4B_PRODUCTION_WRITER_IDENTIFIED",
            "required_action": "No source file writing the authoritative Stage-4B estimate table was found."
        })
    if not spec["solver_identified"]:
        remaining.append({
            "gate": "STAGE4B_SOLVER_IMPLEMENTATION_IDENTIFIED",
            "required_action": "No exact Huber/IRLS/RLM implementation was identified."
        })
    if not spec["parameters_identified"]:
        remaining.append({
            "gate": "STAGE4B_SOLVER_PARAMETERS_IDENTIFIED",
            "required_action": "Robust-loss tuning or convergence parameters remain unresolved."
        })
    if not spec["runner_identified"]:
        remaining.append({
            "gate": "STAGE4B_RUNNER_LINEAGE_IDENTIFIED",
            "required_action": "The production batch/PowerShell invocation lineage remains unresolved."
        })
    write_csv(
        out_dir / "tables/stage6c2g_remaining_closure_items.csv",
        ["gate", "required_action"],
        remaining
    )

    report = [
        "# Stage-6C2G exact Stage-4B solver provenance audit",
        "",
        f"Generated: {utc_now()}",
        "",
        "## Manuscript scrub",
        "",
        f"- Replacements applied: {sum(int(r['count']) for r in scrub_rows)}",
        f"- Residual unsupported phrases: {sum(int(r['count']) for r in residual_rows)}",
        "",
        "## Solver provenance",
        "",
        f"- Writer files: {', '.join(spec['writer_files']) or 'none'}",
        f"- Solver files: {', '.join(spec['solver_files']) or 'none'}",
        f"- Parameter names found: {', '.join(spec['parameter_names']) or 'none'}",
        f"- Runner lineage identified: {spec['runner_identified']}",
        f"- Exact replay spec ready: {spec['exact_replay_spec_ready']}",
        "",
        "## Scientific disposition",
        "",
        "Do not compute T06 from a guessed solver. Use the exact Stage-4B production implementation after this audit resolves the writer, solver, parameters, and invocation lineage.",
        ""
    ]
    (out_dir / "reports/stage6c2g_solver_resolution.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    # Package provenance/checksums.
    manifest = []
    for path in sorted(package_root.rglob("*")):
        if path.is_file():
            manifest.append({
                "path": safe_rel(path, package_root),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path)
            })
    write_json(package_root / "PROVENANCE_MANIFEST.json", {
        "stage": STAGE, "created_utc": utc_now(), "files": manifest
    })
    sums = [
        f"{sha256_file(path)}  {safe_rel(path, package_root)}"
        for path in sorted(package_root.rglob("*"))
        if path.is_file() and path.name != "SHA256SUMS.txt"
    ]
    (package_root / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")

    zip_path = out_dir / "manuscript_source" / f"{cfg['new_package_name']}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(package_root.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(package_root.parent))

    validation = {
        "stage": STAGE,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "named_claim_replacement_count": sum(int(r["count"]) for r in scrub_rows),
        "named_claim_residual_count": sum(int(r["count"]) for r in residual_rows),
        "solver_writer_hit_count": len(writer_hits),
        "solver_parameter_evidence_count": len(parameter_hits),
        "runner_lineage_hit_count": len(runner_hits),
        "replay_delta_row_count": len(replay_rows),
        "prior_stage_outputs_modified": False,
        "NAMED_POPULATION_CLAIMS_REMOVED": len(residual_rows) == 0,
        "STAGE4B_PRODUCTION_WRITER_IDENTIFIED": spec["writer_identified"],
        "STAGE4B_SOLVER_IMPLEMENTATION_IDENTIFIED": spec["solver_identified"],
        "STAGE4B_SOLVER_PARAMETERS_IDENTIFIED": spec["parameters_identified"],
        "STAGE4B_RUNNER_LINEAGE_IDENTIFIED": spec["runner_identified"],
        "EXACT_REPLAY_SPEC_READY": spec["exact_replay_spec_ready"],
        "T06_EXACT_REPLAY_READY": False,
        "source_package": safe_rel(package_root, root),
        "source_zip": safe_rel(zip_path, root),
        "source_zip_size_bytes": zip_path.stat().st_size,
        "source_zip_sha256": sha256_file(zip_path)
    }
    write_json(out_dir / "validation/stage6c2g_validation.json", validation)

    summary = {
        "stage": STAGE,
        "timestamp_utc": utc_now(),
        "exact_replay_spec": spec,
        "remaining_closure_items": remaining,
        "scientific_disposition": (
            "Named-population claims are scrubbed. Use the resolved exact Stage-4B implementation for the next T06 replay stage."
            if len(residual_rows) == 0 and spec["exact_replay_spec_ready"]
            else "Audit completed; exact Stage-4B replay specification remains partially unresolved."
        )
    }
    write_json(out_dir / "summaries/stage6c2g_summary.json", summary)

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
