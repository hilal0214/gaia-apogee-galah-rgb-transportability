from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


UINT64_MAX = 18446744073709551615
FLOAT_EXACT_INTEGER_MAX = 9007199254740991


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def normalise_name(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def semantic_name(value: Any, cfg: dict[str, Any]) -> str:
    token = normalise_name(value)
    changed = True
    while changed:
        changed = False
        for suffix in cfg["semantic_suffixes_to_strip"]:
            suffix_token = normalise_name(suffix)
            if token.endswith(suffix_token):
                token = token[: -len(suffix_token)].rstrip("_")
                changed = True
                break
    return token


def read_columns(path: Path) -> tuple[list[str], int]:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        import pyarrow.parquet as pq
        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    if suffix == ".feather":
        import pyarrow.feather as feather
        table = feather.read_table(path)
        return list(table.column_names), int(table.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def read_table(
    path: Path,
    columns: list[str] | None = None,
    string_columns: list[str] | None = None,
) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path, columns=columns)
    if suffix == ".feather":
        return pd.read_feather(path, columns=columns)
    dtype = (
        {column: "string" for column in string_columns}
        if string_columns else None
    )
    return pd.read_csv(path, usecols=columns, dtype=dtype)


def resolve_with_fallback(path: Path) -> Path | None:
    for candidate in [
        path,
        path.with_suffix(".csv"),
        path.with_suffix(".feather"),
    ]:
        if candidate.exists():
            return candidate
    return None


def find_alias(columns: list[str], aliases: list[str]) -> str | None:
    lookup = {normalise_name(column): column for column in columns}
    for alias in aliases:
        token = normalise_name(alias)
        if token in lookup:
            return lookup[token]
    return None


def clean_uint64(series: pd.Series) -> pd.Series:
    output = pd.Series(pd.NA, index=series.index, dtype="UInt64")
    if pd.api.types.is_unsigned_integer_dtype(series.dtype):
        return series.astype("UInt64")
    if pd.api.types.is_integer_dtype(series.dtype):
        numeric = series.astype("Int64")
        valid = numeric.notna() & (numeric >= 0)
        if valid.any():
            output.loc[valid] = pd.array(
                numeric.loc[valid].astype("string"), dtype="UInt64"
            )
        return output
    if pd.api.types.is_float_dtype(series.dtype):
        numeric = pd.to_numeric(series, errors="coerce")
        valid = (
            numeric.notna()
            & np.isfinite(numeric)
            & (numeric >= 0)
            & (numeric <= FLOAT_EXACT_INTEGER_MAX)
            & (numeric == np.floor(numeric))
        )
        if valid.any():
            output.loc[valid] = pd.array(
                numeric.loc[valid].astype("uint64").astype("string"),
                dtype="UInt64",
            )
        return output

    text = series.astype("string").str.strip()
    text = text.str.replace(r"^\+", "", regex=True)
    valid = text.str.fullmatch(r"[0-9]+", na=False)
    if valid.any():
        values = text.loc[valid].str.lstrip("0").mask(lambda x: x == "", "0")
        within_length = values.str.len() <= len(str(UINT64_MAX))
        bounded = values[within_length]
        if not bounded.empty:
            same_length = bounded.str.len() == len(str(UINT64_MAX))
            within_max = (~same_length) | (bounded <= str(UINT64_MAX))
            bounded = bounded[within_max]
            if not bounded.empty:
                output.loc[bounded.index] = pd.array(
                    bounded, dtype="UInt64"
                )
    return output


def normalise_left_id(series: pd.Series) -> pd.Series:
    if pd.api.types.is_integer_dtype(series.dtype):
        text = series.astype("Int64").astype("string")
    elif pd.api.types.is_float_dtype(series.dtype):
        numeric = pd.to_numeric(series, errors="coerce")
        safe = (
            numeric.notna()
            & np.isfinite(numeric)
            & (np.abs(numeric) <= FLOAT_EXACT_INTEGER_MAX)
            & (numeric == np.floor(numeric))
        )
        text = pd.Series(pd.NA, index=series.index, dtype="string")
        text.loc[safe] = numeric.loc[safe].astype("int64").astype("string")
    else:
        text = series.astype("string").str.strip()
        decimal = text.str.fullmatch(r"[+]?[0-9]+(?:\.0+)?", na=False)
        if decimal.any():
            canonical = (
                text.loc[decimal]
                .str.replace(r"^\+", "", regex=True)
                .str.replace(r"\.0+$", "", regex=True)
                .str.lstrip("0")
                .mask(lambda x: x == "", "0")
            )
            text.loc[decimal] = canonical

    text = (
        text.str.strip()
        .replace({"": pd.NA, "nan": pd.NA, "None": pd.NA, "<NA>": pd.NA})
        .str.upper()
        .str.replace(r"\s+", "", regex=True)
    )
    return text


def detect_snr_contract(
    columns: list[str],
    cfg: dict[str, Any],
) -> tuple[str | None, list[str]]:
    scalar = find_alias(columns, cfg["snr_scalar_aliases"])
    if scalar:
        return "scalar_native_snr", [scalar]
    channels = []
    for aliases in cfg["snr_channel_alias_groups"].values():
        column = find_alias(columns, aliases)
        if column and column not in channels:
            channels.append(column)
    if len(channels) >= int(cfg["minimum_finite_snr_channels"]):
        return "galah_channel_median", channels
    return None, []


def build_snr(
    frame: pd.DataFrame,
    contract: str,
    columns: list[str],
    cfg: dict[str, Any],
) -> pd.Series:
    if contract == "scalar_native_snr":
        snr = pd.to_numeric(frame[columns[0]], errors="coerce")
    else:
        channels = pd.DataFrame({
            column: pd.to_numeric(frame[column], errors="coerce")
            for column in columns
        })
        finite = channels.notna().sum(axis=1)
        snr = channels.median(axis=1, skipna=True)
        snr.loc[
            finite < int(cfg["minimum_finite_snr_channels"])
        ] = np.nan
    snr = pd.to_numeric(snr, errors="coerce")
    snr.loc[
        ~np.isfinite(snr)
        | (snr <= float(cfg["snr_minimum_exclusive"]))
        | (snr > float(cfg["snr_maximum"]))
    ] = np.nan
    return snr


def functional_mapping(
    left: pd.Series,
    right: pd.Series,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    frame = pd.DataFrame({
        "left_id": left,
        "source_id": right,
    }).dropna()
    frame = frame.drop_duplicates()
    conflicts = (
        frame.groupby("left_id")["source_id"].nunique() > 1
        if not frame.empty else pd.Series(dtype=bool)
    )
    ready = bool(not conflicts.any())
    if ready:
        frame = frame.drop_duplicates("left_id")
    return frame, {
        "rows": len(frame),
        "left_unique": int(frame["left_id"].nunique()) if not frame.empty else 0,
        "source_unique": int(frame["source_id"].nunique()) if not frame.empty else 0,
        "conflicting_left_ids": int(conflicts.sum()) if len(conflicts) else 0,
        "functional_ready": ready,
    }


def aggregate_source_snr(
    source_ids: pd.Series,
    snr: pd.Series,
    contract: str,
    route: str,
) -> pd.DataFrame:
    work = pd.DataFrame({
        "source_id": clean_uint64(source_ids),
        "snr_native": snr,
    }).dropna(subset=["source_id"])
    work["source_id"] = work["source_id"].astype("uint64")
    rows = []
    for source_id, group in work.groupby("source_id", sort=False):
        values = group["snr_native"].dropna().to_numpy(dtype=float)
        rows.append({
            "source_id": source_id,
            "survey": "GALAH_CORRECTED",
            "snr_native": float(np.median(values)) if len(values) else np.nan,
            "snr_measurement_count": int(len(values)),
            "snr_input_row_count": int(len(group)),
            "snr_contract": contract,
            "snr_id_route": route,
        })
    return pd.DataFrame(rows)


def complete_mask(frame: pd.DataFrame) -> pd.Series:
    required = [
        "R", "abs_Z", "teff", "logg",
        "snr_native", "g_mag", "bp_rp"
    ]
    mask = pd.Series(True, index=frame.index)
    for field in required:
        if field not in frame.columns:
            return pd.Series(False, index=frame.index)
        mask &= frame[field].notna()
    sky = (
        (
            frame.get("l", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("b", pd.Series(pd.NA, index=frame.index)).notna()
        )
        |
        (
            frame.get("ra", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("dec", pd.Series(pd.NA, index=frame.index)).notna()
        )
    )
    return mask & sky


def percentile_transform(series: pd.Series) -> pd.Series:
    output = pd.Series(np.nan, index=series.index, dtype=float)
    valid = series.notna()
    if valid.any():
        output.loc[valid] = series.loc[valid].rank(
            method="average", pct=True
        )
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2d9_config.json").read_text(
            encoding="utf-8"
        )
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables",
        "assembled", "reports", "diagnostics"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg["prerequisite_validation"]
    prereq = (
        json.loads(prereq_path.read_text(encoding="utf-8"))
        if prereq_path.exists() else {}
    )
    prerequisite_ready = bool(
        prereq.get("STAGE6D3A2D8_PROVENANCE_DIAGNOSIS_READY", False)
        and prereq.get("EXTERNAL_SOURCE_ACQUISITION_REQUIRED", False)
        and prereq.get("FROZEN_OVERLAP_GATES_UNCHANGED", False)
        and not prereq.get("STAGE6D3B_COMMON_FOOTPRINT_READY", True)
    )

    spec_path = root / cfg["bridge_spec"]
    spec = pd.read_csv(spec_path) if spec_path.exists() else pd.DataFrame()
    spec_ready = bool(
        not spec.empty
        and {
            "candidate_path",
            "candidate_identifier_column",
        }.issubset(spec.columns)
    )

    anchor_path = resolve_with_fallback(root / cfg["canonical_anchor"])
    anchor = (
        read_table(anchor_path, None, string_columns=["source_id"])
        if anchor_path else pd.DataFrame()
    )
    if "source_id" in anchor.columns:
        anchor["source_id"] = clean_uint64(anchor["source_id"])
        anchor = anchor[anchor["source_id"].notna()].copy()
        anchor["source_id"] = anchor["source_id"].astype("uint64")
    anchor_ready = bool(
        not anchor.empty
        and {"source_id", "survey", "snr_native"}.issubset(anchor.columns)
        and not anchor.duplicated(["source_id", "survey"]).any()
        and set(anchor["survey"].dropna().astype(str))
        >= {"APOGEE_NATIVE", "GALAH_CORRECTED"}
    )
    galah_anchor_ids = set(
        anchor.loc[
            anchor["survey"] == "GALAH_CORRECTED", "source_id"
        ].astype("uint64")
    ) if anchor_ready else set()

    bridge_files = []
    suffixes = set(cfg["tabular_suffixes"])
    for rel_root in cfg["bridge_input_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if (
                path.is_file()
                and path.suffix.lower() in suffixes
            ):
                bridge_files.append(path)
    bridge_files = sorted(bridge_files)[
        : int(cfg["maximum_bridge_files"])
    ]

    intake_rows = []
    route_products = []

    for bridge_path in bridge_files:
        try:
            bridge_columns, bridge_row_count = read_columns(bridge_path)
        except Exception as exc:
            intake_rows.append({
                "bridge_path": safe_rel(bridge_path, root),
                "candidate_path": "",
                "candidate_identifier_column": "",
                "bridge_left_column": "",
                "bridge_gaia_dr3_column": "",
                "bridge_contains_snr": "false",
                "snr_contract": "",
                "mapping_rows": 0,
                "conflicting_left_ids": "",
                "functional_ready": "false",
                "finite_source_snr_rows": 0,
                "anchor_overlap_rows": 0,
                "anchor_overlap_fraction": 0.0,
                "row_count": "",
                "selection_score": -1,
                "load_error": f"{type(exc).__name__}: {exc}",
            })
            continue

        gaia_column = find_alias(
            bridge_columns, cfg["gaia_dr3_aliases"]
        )
        if not gaia_column:
            continue
        bridge_contract, bridge_snr_columns = detect_snr_contract(
            bridge_columns, cfg
        )

        for _, spec_row in spec.iterrows():
            candidate_path = root / str(spec_row["candidate_path"])
            candidate_column = str(
                spec_row["candidate_identifier_column"]
            )
            if not candidate_path.exists():
                continue

            exact_left = next(
                (
                    column for column in bridge_columns
                    if normalise_name(column)
                    == normalise_name(candidate_column)
                ),
                None,
            )
            semantic_left = next(
                (
                    column for column in bridge_columns
                    if semantic_name(column, cfg)
                    == semantic_name(candidate_column, cfg)
                ),
                None,
            )
            bridge_left = exact_left or semantic_left
            if not bridge_left:
                continue

            required_bridge = [bridge_left, gaia_column]
            if bridge_contract:
                required_bridge += bridge_snr_columns
            required_bridge = sorted(set(required_bridge))
            try:
                bridge_frame = read_table(
                    bridge_path,
                    required_bridge,
                    string_columns=[bridge_left, gaia_column],
                )
            except Exception as exc:
                intake_rows.append({
                    "bridge_path": safe_rel(bridge_path, root),
                    "candidate_path": safe_rel(candidate_path, root),
                    "candidate_identifier_column": candidate_column,
                    "bridge_left_column": bridge_left,
                    "bridge_gaia_dr3_column": gaia_column,
                    "bridge_contains_snr": str(
                        bool(bridge_contract)
                    ).lower(),
                    "snr_contract": bridge_contract or "",
                    "mapping_rows": 0,
                    "conflicting_left_ids": "",
                    "functional_ready": "false",
                    "finite_source_snr_rows": 0,
                    "anchor_overlap_rows": 0,
                    "anchor_overlap_fraction": 0.0,
                    "row_count": bridge_row_count,
                    "selection_score": -1,
                    "load_error": f"{type(exc).__name__}: {exc}",
                })
                continue

            left_ids = normalise_left_id(
                bridge_frame[bridge_left]
            )
            source_ids = clean_uint64(
                bridge_frame[gaia_column]
            )
            mapping, mapping_diag = functional_mapping(
                left_ids, source_ids
            )
            if not mapping_diag["functional_ready"]:
                intake_rows.append({
                    "bridge_path": safe_rel(bridge_path, root),
                    "candidate_path": safe_rel(candidate_path, root),
                    "candidate_identifier_column": candidate_column,
                    "bridge_left_column": bridge_left,
                    "bridge_gaia_dr3_column": gaia_column,
                    "bridge_contains_snr": str(
                        bool(bridge_contract)
                    ).lower(),
                    "snr_contract": bridge_contract or "",
                    "mapping_rows": mapping_diag["rows"],
                    "conflicting_left_ids": mapping_diag[
                        "conflicting_left_ids"
                    ],
                    "functional_ready": "false",
                    "finite_source_snr_rows": 0,
                    "anchor_overlap_rows": 0,
                    "anchor_overlap_fraction": 0.0,
                    "row_count": bridge_row_count,
                    "selection_score": -1,
                    "load_error": "",
                })
                continue

            if bridge_contract:
                snr = build_snr(
                    bridge_frame,
                    bridge_contract,
                    bridge_snr_columns,
                    cfg,
                )
                source_product = aggregate_source_snr(
                    source_ids,
                    snr,
                    bridge_contract,
                    "external_original_source_with_snr",
                )
                candidate_contract = bridge_contract
                route = "external_original_source_with_snr"
            else:
                try:
                    candidate_columns, _ = read_columns(
                        candidate_path
                    )
                    candidate_contract, candidate_snr_columns = (
                        detect_snr_contract(
                            candidate_columns, cfg
                        )
                    )
                    if not candidate_contract:
                        raise RuntimeError(
                            "candidate source lacks a supported native S/N schema"
                        )
                    candidate_frame = read_table(
                        candidate_path,
                        [candidate_column]
                        + candidate_snr_columns,
                        string_columns=[candidate_column],
                    )
                    candidate_left = normalise_left_id(
                        candidate_frame[candidate_column]
                    )
                    candidate_snr = build_snr(
                        candidate_frame,
                        candidate_contract,
                        candidate_snr_columns,
                        cfg,
                    )
                    candidate_work = pd.DataFrame({
                        "left_id": candidate_left,
                        "snr_native": candidate_snr,
                    }).dropna(subset=["left_id"])
                    joined = candidate_work.merge(
                        mapping,
                        on="left_id",
                        how="inner",
                        validate="many_to_one",
                    )
                    source_product = aggregate_source_snr(
                        joined["source_id"],
                        joined["snr_native"],
                        candidate_contract,
                        "external_standalone_bridge_to_frozen_candidate_snr",
                    )
                    route = (
                        "external_standalone_bridge_to_frozen_candidate_snr"
                    )
                except Exception as exc:
                    intake_rows.append({
                        "bridge_path": safe_rel(bridge_path, root),
                        "candidate_path": safe_rel(candidate_path, root),
                        "candidate_identifier_column": candidate_column,
                        "bridge_left_column": bridge_left,
                        "bridge_gaia_dr3_column": gaia_column,
                        "bridge_contains_snr": "false",
                        "snr_contract": "",
                        "mapping_rows": mapping_diag["rows"],
                        "conflicting_left_ids": 0,
                        "functional_ready": "true",
                        "finite_source_snr_rows": 0,
                        "anchor_overlap_rows": 0,
                        "anchor_overlap_fraction": 0.0,
                        "row_count": bridge_row_count,
                        "selection_score": -1,
                        "load_error": f"{type(exc).__name__}: {exc}",
                    })
                    continue

            finite_product = source_product[
                source_product["snr_native"].notna()
            ]
            finite_ids = set(
                finite_product["source_id"].astype("uint64")
            )
            overlap = galah_anchor_ids.intersection(finite_ids)
            overlap_fraction = (
                len(overlap) / max(len(galah_anchor_ids), 1)
            )
            score = (
                1_000_000_000 * len(overlap)
                + 1_000_000 * len(finite_ids)
                + mapping_diag["rows"]
            )
            row = {
                "bridge_path": safe_rel(bridge_path, root),
                "candidate_path": safe_rel(candidate_path, root),
                "candidate_identifier_column": candidate_column,
                "bridge_left_column": bridge_left,
                "bridge_gaia_dr3_column": gaia_column,
                "bridge_contains_snr": str(
                    bool(bridge_contract)
                ).lower(),
                "snr_contract": candidate_contract,
                "mapping_rows": mapping_diag["rows"],
                "conflicting_left_ids": mapping_diag[
                    "conflicting_left_ids"
                ],
                "functional_ready": "true",
                "finite_source_snr_rows": len(finite_ids),
                "anchor_overlap_rows": len(overlap),
                "anchor_overlap_fraction": overlap_fraction,
                "row_count": bridge_row_count,
                "selection_score": score,
                "load_error": "",
            }
            intake_rows.append(row)
            route_products.append({
                "row": row,
                "product": source_product,
                "route": route,
            })

    write_csv(
        out / "tables/stage6d3a2d9_bridge_intake_audit.csv",
        [
            "bridge_path", "candidate_path",
            "candidate_identifier_column",
            "bridge_left_column", "bridge_gaia_dr3_column",
            "bridge_contains_snr", "snr_contract",
            "mapping_rows", "conflicting_left_ids",
            "functional_ready", "finite_source_snr_rows",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "row_count", "selection_score", "load_error"
        ],
        sorted(
            intake_rows,
            key=lambda row: (
                -float(row["selection_score"]),
                row["bridge_path"],
            ),
        ),
    )

    eligible = [
        item for item in route_products
        if (
            item["row"]["anchor_overlap_rows"]
            >= int(cfg["minimum_anchor_overlap_rows"])
            and item["row"]["anchor_overlap_fraction"]
            >= float(cfg["minimum_anchor_overlap_fraction"])
            and item["row"]["conflicting_left_ids"] == 0
        )
    ]
    eligible.sort(
        key=lambda item: (
            -item["row"]["selection_score"],
            item["row"]["bridge_path"],
        )
    )

    selected = None
    selection_error = ""
    if not bridge_files:
        selection_error = (
            "no external bridge file found under "
            "inputs/stage6d3a2d9_bridge or data/external/galah_bridge"
        )
    elif not eligible:
        selection_error = (
            "no external bridge satisfies exact functional mapping plus "
            "the frozen 500-row and 0.5% finite GALAH-anchor overlap gates"
        )
    elif (
        len(eligible) > 1
        and eligible[0]["row"]["selection_score"]
        == eligible[1]["row"]["selection_score"]
    ):
        selection_error = (
            "top external bridge candidates are tied; retain only the "
            "authoritative frozen source product or provide provenance metadata"
        )
    else:
        selected = eligible[0]

    selected_rows = []
    if selected:
        selected_rows.append({
            **selected["row"],
            "selected_route": selected["route"],
            "selection_reason": (
                "unique maximum finite canonical GALAH-anchor overlap "
                "under frozen functional-identity gates"
            ),
        })
    write_csv(
        out / "tables/stage6d3a2d9_selected_external_bridge.csv",
        [
            "bridge_path", "candidate_path",
            "candidate_identifier_column",
            "bridge_left_column", "bridge_gaia_dr3_column",
            "bridge_contains_snr", "snr_contract",
            "mapping_rows", "conflicting_left_ids",
            "functional_ready", "finite_source_snr_rows",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "row_count", "selection_score",
            "selected_route", "selection_reason"
        ],
        selected_rows,
    )

    final = anchor.copy()
    final["_anchor_row_id"] = np.arange(len(final), dtype=np.int64)
    if selected:
        galah_mask = final["survey"] == "GALAH_CORRECTED"
        fields = [
            "snr_native", "snr_measurement_count",
            "snr_input_row_count", "snr_contract", "snr_id_route"
        ]
        for field in fields:
            if field not in final.columns:
                final[field] = np.nan if field == "snr_native" else pd.NA
            final.loc[galah_mask, field] = (
                np.nan if field == "snr_native" else pd.NA
            )

        product = selected["product"].copy()
        product["source_id"] = clean_uint64(product["source_id"])
        product = product[product["source_id"].notna()].copy()
        product["source_id"] = product["source_id"].astype("uint64")
        if product.duplicated(["source_id", "survey"]).any():
            raise RuntimeError(
                "selected source-level GALAH S/N product is not unique"
            )
        joined = final.merge(
            product[
                ["source_id", "survey"]
                + [field for field in fields if field in product.columns]
            ],
            on=["source_id", "survey"],
            how="left",
            suffixes=("", "__galah"),
            validate="one_to_one",
        )
        for field in fields:
            candidate = field + "__galah"
            if candidate not in joined.columns:
                continue
            replace = joined["survey"] == "GALAH_CORRECTED"
            joined.loc[replace, field] = joined.loc[
                replace, candidate
            ].to_numpy()
            joined.drop(columns=[candidate], inplace=True)
        final = joined

    final = final.sort_values(
        "_anchor_row_id", kind="stable"
    ).reset_index(drop=True)
    row_conservation_ready = bool(
        len(final) == len(anchor)
        and final["_anchor_row_id"].is_unique
        and final["_anchor_row_id"].tolist() == list(range(len(anchor)))
        and not final.duplicated(["source_id", "survey"]).any()
        and final["source_id"].astype("uint64").tolist()
        == anchor["source_id"].astype("uint64").tolist()
        and final["survey"].astype(str).tolist()
        == anchor["survey"].astype(str).tolist()
    )

    if "snr_native" not in final.columns:
        final["snr_native"] = np.nan
    final["snr_log1p_native"] = np.log1p(
        pd.to_numeric(final["snr_native"], errors="coerce").clip(lower=0)
    )
    final["snr_within_survey_percentile"] = np.nan
    final["snr_support_half"] = pd.Series(
        pd.NA, index=final.index, dtype="string"
    )
    medians = {}
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        mask = final["survey"] == survey
        series = pd.to_numeric(
            final.loc[mask, "snr_native"], errors="coerce"
        )
        final.loc[
            mask, "snr_within_survey_percentile"
        ] = percentile_transform(series)
        median = float(series.median()) if series.notna().any() else np.nan
        medians[survey] = median
        if np.isfinite(median):
            final.loc[
                mask & final["snr_native"].notna()
                & (final["snr_native"] <= median),
                "snr_support_half"
            ] = "LOW_NATIVE_SNR_HALF"
            final.loc[
                mask & final["snr_native"].notna()
                & (final["snr_native"] > median),
                "snr_support_half"
            ] = "HIGH_NATIVE_SNR_HALF"

    support = complete_mask(final)
    complete_counts = {
        survey: int(
            ((final["survey"] == survey) & support).sum()
        )
        for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]
    }
    bridge_ready = selected is not None
    complete_ready = all(
        complete_counts[survey]
        >= int(cfg["minimum_complete_rows_per_survey"])
        for survey in complete_counts
    )
    source_ready = bool(
        prerequisite_ready
        and spec_ready
        and anchor_ready
        and bridge_ready
        and row_conservation_ready
        and complete_ready
    )

    final_path = (
        out
        / "assembled/stage6d3a2d9_production_source_with_external_bridge_snr.parquet"
    )
    try:
        final.drop(columns=["_anchor_row_id"]).to_parquet(
            final_path, index=False
        )
    except Exception:
        final_path = (
            out
            / "assembled/stage6d3a2d9_production_source_with_external_bridge_snr.csv"
        )
        final.drop(columns=["_anchor_row_id"]).to_csv(
            final_path, index=False
        )

    coverage_rows = []
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        subset = final[final["survey"] == survey]
        coverage_rows.append({
            "survey": survey,
            "anchor_rows": len(subset),
            "finite_snr_rows": int(
                subset["snr_native"].notna().sum()
            ),
            "finite_snr_fraction": (
                float(subset["snr_native"].notna().mean())
                if len(subset) else 0.0
            ),
            "support_complete_rows": complete_counts[survey],
        })
    write_csv(
        out / "tables/stage6d3a2d9_final_join_coverage.csv",
        [
            "survey", "anchor_rows",
            "finite_snr_rows", "finite_snr_fraction",
            "support_complete_rows"
        ],
        coverage_rows,
    )

    remaining = []
    if not prerequisite_ready:
        remaining.append({
            "gate": "STAGE6D3A2D8_PREREQUISITE_READY",
            "required_action": (
                "Restore PASS D8 provenance diagnosis and external-acquisition "
                "requirement."
            ),
        })
    if not spec_ready:
        remaining.append({
            "gate": "D8_REQUIRED_BRIDGE_SPEC_READY",
            "required_action": (
                "D8 required_bridge_spec.csv is missing or incomplete."
            ),
        })
    if not anchor_ready:
        remaining.append({
            "gate": "CANONICAL_ANCHOR_READY",
            "required_action": (
                "Canonical D5 source×survey anchor is missing or invalid."
            ),
        })
    if not bridge_ready:
        remaining.append({
            "gate": "EXTERNAL_GALAH_BRIDGE_READY",
            "required_action": selection_error,
        })
    if not row_conservation_ready:
        remaining.append({
            "gate": "FINAL_ROW_CONSERVATION_READY",
            "required_action": (
                "Final table must preserve the exact ordered canonical "
                "source×survey row universe."
            ),
        })
    if bridge_ready and row_conservation_ready and not complete_ready:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_COMPLETE_ROWS_READY",
            "required_action": (
                f"Need at least {cfg['minimum_complete_rows_per_survey']} "
                "support-complete rows per survey. Observed: "
                + json.dumps(complete_counts, sort_keys=True)
            ),
        })
    write_csv(
        out / "tables/stage6d3a2d9_remaining_items.csv",
        ["gate", "required_action"],
        remaining,
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "bridge_input_file_count": len(bridge_files),
        "bridge_spec_row_count": len(spec),
        "selected_bridge_path": (
            selected["row"]["bridge_path"] if selected else ""
        ),
        "selected_candidate_path": (
            selected["row"]["candidate_path"] if selected else ""
        ),
        "selected_candidate_identifier_column": (
            selected["row"]["candidate_identifier_column"]
            if selected else ""
        ),
        "selected_gaia_dr3_column": (
            selected["row"]["bridge_gaia_dr3_column"]
            if selected else ""
        ),
        "selected_route": (
            selected["route"] if selected else ""
        ),
        "selected_anchor_overlap_rows": (
            selected["row"]["anchor_overlap_rows"]
            if selected else 0
        ),
        "selected_anchor_overlap_fraction": (
            selected["row"]["anchor_overlap_fraction"]
            if selected else 0.0
        ),
        "survey_native_snr_medians": medians,
        "assembled_source_table": safe_rel(final_path, root),
        "assembled_rows": len(final),
        "support_complete_rows_by_survey": complete_counts,
        "prior_stage_outputs_modified": False,
        "STAGE6D3A2D8_PREREQUISITE_READY": prerequisite_ready,
        "D8_REQUIRED_BRIDGE_SPEC_READY": spec_ready,
        "CANONICAL_ANCHOR_READY": anchor_ready,
        "EXTERNAL_BRIDGE_INPUT_PRESENT": bool(bridge_files),
        "EXACT_UINT64_GAIA_DR3_PARSING_READY": True,
        "FUNCTIONAL_LEFT_TO_GAIA_DR3_MAPPING_READY": bridge_ready,
        "FROZEN_500_ROW_GATE_PASSED": bool(
            selected
            and selected["row"]["anchor_overlap_rows"]
            >= int(cfg["minimum_anchor_overlap_rows"])
        ),
        "FROZEN_0P5_PERCENT_GATE_PASSED": bool(
            selected
            and selected["row"]["anchor_overlap_fraction"]
            >= float(cfg["minimum_anchor_overlap_fraction"])
        ),
        "EXTERNAL_GALAH_BRIDGE_READY": bridge_ready,
        "FINAL_ROW_CONSERVATION_READY": row_conservation_ready,
        "NATIVE_SNR_PRESERVED": bridge_ready,
        "WITHIN_SURVEY_SNR_PERCENTILE_READY": bridge_ready,
        "SURVEY_SPECIFIC_SNR_SUPPORT_READY": bridge_ready,
        "PRODUCTION_SOURCE_COMPLETE_ROWS_READY": complete_ready,
        "PRODUCTION_SOURCE_ASSEMBLY_READY": source_ready,
        "TARGET_ABUNDANCE_MATCHING_FORBIDDEN": True,
        "COORDINATE_NEAREST_NEIGHBOUR_SUBSTITUTION_FORBIDDEN": True,
        "SURVEY_NEUTRAL_SNR_PROXY_FORBIDDEN": True,
        "FROZEN_OVERLAP_GATES_UNCHANGED": True,
        "STAGE6D3A2D9_LINEAGE_READY": bool(
            prerequisite_ready
            and spec_ready
            and anchor_ready
            and bridge_ready
            and row_conservation_ready
        ),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": source_ready,
    }
    write_json(
        out / "validation/stage6d3a2d9_validation.json",
        validation,
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "bridge_intake": {
            "input_files": len(bridge_files),
            "selected_bridge": validation["selected_bridge_path"],
            "selected_candidate": validation[
                "selected_candidate_path"
            ],
            "route": validation["selected_route"],
            "overlap_rows": validation[
                "selected_anchor_overlap_rows"
            ],
            "overlap_fraction": validation[
                "selected_anchor_overlap_fraction"
            ],
            "ready": bridge_ready,
        },
        "source_assembly": {
            "rows": len(final),
            "support_complete_rows_by_survey": complete_counts,
            "row_conservation_ready": row_conservation_ready,
            "ready": source_ready,
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "The external GALAH identity bridge satisfies exact functional "
            "mapping and frozen overlap gates. Native GALAH S/N is restored "
            "on canonical source×survey rows and Stage-6D3B is authorized."
            if source_ready else
            "External bridge intake is audited. D3B remains blocked until a "
            "bridge satisfying the generated D8 identity contract is placed "
            "in the intake directory."
        ),
    }
    write_json(
        out / "summaries/stage6d3a2d9_summary.json",
        summary,
    )

    report = [
        "# Stage-6D3A2D9 external bridge intake validation",
        "",
        f"- Bridge input files: `{len(bridge_files)}`",
        f"- Selected bridge: `{validation['selected_bridge_path'] or 'not selected'}`",
        f"- Selected route: `{validation['selected_route'] or 'not resolved'}`",
        f"- GALAH anchor overlap rows: `{validation['selected_anchor_overlap_rows']}`",
        f"- GALAH anchor overlap fraction: `{validation['selected_anchor_overlap_fraction']}`",
        f"- Final rows: `{len(final)}`",
        f"- Row conservation: `{row_conservation_ready}`",
        f"- APOGEE support-complete rows: `{complete_counts['APOGEE_NATIVE']}`",
        f"- GALAH support-complete rows: `{complete_counts['GALAH_CORRECTED']}`",
        f"- Stage-6D3B ready: `{source_ready}`",
        "",
        "Accepted inputs are either an original GALAH source product containing "
        "candidate ID, native S/N, and exact Gaia DR3 ID, or a standalone "
        "candidate-ID to Gaia DR3 crosswalk. The latter is joined to the frozen "
        "GALAH S/N candidate identified by D8.",
        "",
        "No coordinate nearest-neighbour, abundance, gradient, residual, or "
        "outcome-based matching is permitted.",
        "",
    ]
    (
        out
        / "reports/stage6d3a2d9_external_bridge_intake_validation.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
