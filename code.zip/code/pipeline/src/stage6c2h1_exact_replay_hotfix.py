from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import pandas as pd
import yaml

STAGE = "Stage-6C2H1 exact Stage-4B replay invocation hotfix"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.15.8"

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def norm(value: Any) -> str:
    import re
    return re.sub(r"[^a-z0-9]+", "_", str(value).lower()).strip("_")

def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8"
    )

def write_csv(path: Path, fields: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

def read_yaml(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))

def write_yaml(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(value, sort_keys=False, allow_unicode=True),
        encoding="utf-8"
    )

def patch_output_paths(
    value: Any,
    shadow_output: Path,
    tokens: list[str],
    changes: list[dict[str, Any]],
    location: str = "$",
    parent_key: str = ""
) -> Any:
    if isinstance(value, dict):
        result = {}
        for key, child in value.items():
            child_location = f"{location}.{key}"
            key_norm = norm(key)
            is_output_key = any(token in key_norm for token in tokens)
            if is_output_key and isinstance(child, str):
                new_value = str(shadow_output).replace("\\", "/")
                result[key] = new_value
                changes.append({
                    "config_path": child_location,
                    "old_value": child,
                    "new_value": new_value,
                    "reason": "explicit_output_key"
                })
            else:
                result[key] = patch_output_paths(
                    child, shadow_output, tokens, changes,
                    child_location, key_norm
                )
        return result

    if isinstance(value, list):
        return [
            patch_output_paths(
                child, shadow_output, tokens, changes,
                f"{location}[{index}]", parent_key
            )
            for index, child in enumerate(value)
        ]

    if isinstance(value, str):
        normalized = value.replace("\\", "/").rstrip("/")
        parent_is_output = any(token in parent_key for token in tokens)
        if normalized.lower() == "outputs/stage4b" or (
            parent_is_output and normalized.lower().startswith("outputs/stage4b/")
        ):
            suffix = normalized[len("outputs/stage4b"):].lstrip("/")
            new_value = str(shadow_output / suffix).replace("\\", "/")
            changes.append({
                "config_path": location,
                "old_value": value,
                "new_value": new_value,
                "reason": "stage4b_output_literal"
            })
            return new_value

    return value

def integrity_snapshot(paths: list[Path], root: Path, phase: str) -> list[dict[str, Any]]:
    rows = []
    for path in paths:
        rows.append({
            "phase": phase,
            "path": safe_rel(path, root),
            "exists": str(path.exists()).lower(),
            "size_bytes": path.stat().st_size if path.exists() else "",
            "sha256": sha256_file(path) if path.exists() else ""
        })
    return rows

def locate_replay_table(shadow_output: Path) -> Path | None:
    candidates = list(shadow_output.rglob("stage4b_global_gradient_estimates.csv"))
    if not candidates:
        candidates = list(shadow_output.rglob("*global*gradient*estimate*.csv"))
    if not candidates:
        return None
    candidates.sort(
        key=lambda path: (path.stat().st_mtime, path.stat().st_size),
        reverse=True
    )
    return candidates[0]

def compare_tables(
    authoritative_path: Path,
    replay_path: Path,
    cfg: dict[str, Any]
) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    authoritative = pd.read_csv(authoritative_path)
    replay = pd.read_csv(replay_path)

    schema_identity = list(authoritative.columns) == list(replay.columns)
    row_count_identity = len(authoritative) == len(replay)

    sort_keys = [
        column for column in ["label", "model_id"]
        if column in authoritative.columns and column in replay.columns
    ]
    if sort_keys:
        authoritative = authoritative.sort_values(sort_keys).reset_index(drop=True)
        replay = replay.sort_values(sort_keys).reset_index(drop=True)
    else:
        authoritative = authoritative.reset_index(drop=True)
        replay = replay.reset_index(drop=True)

    common_columns = [
        column for column in authoritative.columns if column in replay.columns
    ]
    column_rows = []
    numeric_identity = True
    non_numeric_identity = True

    for column in common_columns:
        if not row_count_identity:
            column_rows.append({
                "column": column,
                "type": "uncompared",
                "max_abs_difference": "",
                "max_relative_difference": "",
                "passed": "false"
            })
            numeric_identity = False
            non_numeric_identity = False
            continue

        a = authoritative[column]
        b = replay[column]

        # Boolean fields such as ``converged`` must be compared exactly.
        # Pandas can coerce them to numeric-looking arrays, but subtraction
        # of NumPy boolean arrays is intentionally unsupported.
        is_boolean = (
            pd.api.types.is_bool_dtype(a.dtype)
            or pd.api.types.is_bool_dtype(b.dtype)
        )
        a_num = pd.to_numeric(a, errors="coerce")
        b_num = pd.to_numeric(b, errors="coerce")
        is_numeric = (
            not is_boolean
            and a_num.notna().sum() == a.notna().sum()
            and b_num.notna().sum() == b.notna().sum()
            and (a.notna().sum() > 0 or b.notna().sum() > 0)
        )

        if is_numeric:
            nan_identity = a_num.isna().equals(b_num.isna())
            finite = a_num.notna() & b_num.notna()
            if finite.any():
                difference = (a_num[finite] - b_num[finite]).abs()
                max_abs = float(difference.max())
                denominator = a_num[finite].abs().clip(
                    lower=float(cfg["absolute_numeric_tolerance"])
                )
                max_rel = float((difference / denominator).max())
            else:
                max_abs = 0.0
                max_rel = 0.0
            passed = bool(
                nan_identity
                and max_abs <= float(cfg["absolute_numeric_tolerance"])
                and max_rel <= float(cfg["relative_numeric_tolerance"])
            )
            numeric_identity &= passed
            column_rows.append({
                "column": column,
                "type": "numeric",
                "max_abs_difference": max_abs,
                "max_relative_difference": max_rel,
                "passed": str(passed).lower()
            })
        else:
            passed = a.fillna("<NA>").astype(str).equals(
                b.fillna("<NA>").astype(str)
            )
            non_numeric_identity &= passed
            column_rows.append({
                "column": column,
                "type": "string_or_bool",
                "max_abs_difference": "",
                "max_relative_difference": "",
                "passed": str(passed).lower()
            })

    row_rows = []
    maximum_rows = max(len(authoritative), len(replay))
    for index in range(maximum_rows):
        a_row = authoritative.iloc[index] if index < len(authoritative) else None
        b_row = replay.iloc[index] if index < len(replay) else None
        key = ""
        if sort_keys and a_row is not None:
            key = "|".join(str(a_row[column]) for column in sort_keys)
        elif sort_keys and b_row is not None:
            key = "|".join(str(b_row[column]) for column in sort_keys)

        mismatches = []
        if a_row is None or b_row is None:
            mismatches = ["__row_presence__"]
        else:
            for column in common_columns:
                av = a_row[column]
                bv = b_row[column]
                if pd.isna(av) and pd.isna(bv):
                    continue
                try:
                    av_float = float(av)
                    bv_float = float(bv)
                    if not math.isclose(
                        av_float,
                        bv_float,
                        rel_tol=float(cfg["relative_numeric_tolerance"]),
                        abs_tol=float(cfg["absolute_numeric_tolerance"])
                    ):
                        mismatches.append(column)
                except Exception:
                    if str(av) != str(bv):
                        mismatches.append(column)
        row_rows.append({
            "row_index": index,
            "key": key,
            "mismatch_count": len(mismatches),
            "mismatch_columns": "|".join(mismatches),
            "passed": str(len(mismatches) == 0).lower()
        })

    critical_columns = [
        column for column in cfg["critical_identity_columns"]
        if column in common_columns
    ]
    critical_identity = bool(critical_columns) and all(
        row["passed"] == "true"
        for row in column_rows
        if row["column"] in critical_columns
    )
    row_identity = all(row["passed"] == "true" for row in row_rows)

    result = {
        "authoritative_path": str(authoritative_path),
        "replay_path": str(replay_path),
        "authoritative_sha256": sha256_file(authoritative_path),
        "replay_sha256": sha256_file(replay_path),
        "bitwise_identity": (
            sha256_file(authoritative_path) == sha256_file(replay_path)
        ),
        "authoritative_rows": len(authoritative),
        "replay_rows": len(replay),
        "schema_identity": schema_identity,
        "row_count_identity": row_count_identity,
        "numeric_identity": numeric_identity,
        "non_numeric_identity": non_numeric_identity,
        "critical_column_identity": critical_identity,
        "row_identity": row_identity,
        "scientific_identity": bool(
            schema_identity
            and row_count_identity
            and numeric_identity
            and non_numeric_identity
            and critical_identity
            and row_identity
        )
    }
    return result, column_rows, row_rows

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE)
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg_path = root / "config/stage6c2h1_config.json"
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))

    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for name in ["validation", "summaries", "tables", "reports", "shadow"]:
        (out_dir / name).mkdir(parents=True, exist_ok=True)

    exact_script = root / cfg["exact_script"]
    exact_runner = root / cfg["exact_runner"]
    original_config = root / cfg["original_config"]
    temporary_config = root / cfg["temporary_config"]
    authoritative = root / cfg["authoritative_estimates"]
    authoritative_draws = root / cfg["authoritative_draws"]
    shadow_output = out_dir / cfg["shadow_output_subdir"]
    shadow_output.mkdir(parents=True, exist_ok=True)

    required = {
        "exact_script": exact_script,
        "exact_runner": exact_runner,
        "original_config": original_config,
        "authoritative_estimates": authoritative
    }
    missing = [name for name, path in required.items() if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required files: " + ", ".join(missing))

    protected_paths = [original_config, authoritative]
    if authoritative_draws.exists():
        protected_paths.append(authoritative_draws)
    integrity_rows = integrity_snapshot(protected_paths, root, "before")

    original_config_value = read_yaml(original_config)
    config_changes = []
    patched_config = patch_output_paths(
        original_config_value,
        shadow_output,
        cfg["output_key_tokens"],
        config_changes
    )
    if not config_changes:
        raise RuntimeError(
            "No output destination could be redirected in config/stage4b.yml."
        )

    if temporary_config.exists():
        temporary_config.unlink()
    write_yaml(temporary_config, patched_config)

    audit_copy = out_dir / "shadow/config" / temporary_config.name
    audit_copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(temporary_config, audit_copy)

    write_csv(
        out_dir / "tables/stage6c2h1_config_changes.csv",
        ["config_path", "old_value", "new_value", "reason"],
        config_changes
    )

    command = [
        sys.executable,
        str(exact_script),
        "--config",
        str(temporary_config)
    ]
    execution = {
        "command": subprocess.list2cmdline(command),
        "cwd": str(root),
        "returncode": -1,
        "stdout": "",
        "stderr": ""
    }

    try:
        completed = subprocess.run(
            command,
            cwd=root,
            capture_output=True,
            text=True,
            timeout=int(cfg["execution_timeout_seconds"])
        )
        execution.update({
            "returncode": completed.returncode,
            "stdout": completed.stdout,
            "stderr": completed.stderr
        })
    except Exception as exc:
        execution["stderr"] = f"{type(exc).__name__}: {exc}"
    finally:
        if temporary_config.exists():
            temporary_config.unlink()

    write_csv(
        out_dir / "tables/stage6c2h1_execution_audit.csv",
        ["command", "cwd", "returncode", "stdout", "stderr"],
        [execution]
    )

    integrity_rows.extend(
        integrity_snapshot(protected_paths, root, "after")
    )
    write_csv(
        out_dir / "tables/stage6c2h1_integrity_audit.csv",
        ["phase", "path", "exists", "size_bytes", "sha256"],
        integrity_rows
    )

    before = {
        row["path"]: row["sha256"]
        for row in integrity_rows if row["phase"] == "before"
    }
    after = {
        row["path"]: row["sha256"]
        for row in integrity_rows if row["phase"] == "after"
    }
    frozen_integrity_ready = before == after

    replay_path = (
        locate_replay_table(shadow_output)
        if execution["returncode"] == 0 else None
    )

    comparison = {
        "schema_identity": False,
        "row_count_identity": False,
        "numeric_identity": False,
        "critical_column_identity": False,
        "row_identity": False,
        "scientific_identity": False,
        "reason": "replay_table_not_generated"
    }
    column_rows = []
    row_rows = []
    if replay_path is not None:
        comparison, column_rows, row_rows = compare_tables(
            authoritative, replay_path, cfg
        )

    write_json(
        out_dir / "summaries/stage6c2h1_replay_comparison.json",
        comparison
    )
    write_csv(
        out_dir / "tables/stage6c2h1_column_identity.csv",
        ["column", "type", "max_abs_difference",
         "max_relative_difference", "passed"],
        column_rows
    )
    write_csv(
        out_dir / "tables/stage6c2h1_row_identity.csv",
        ["row_index", "key", "mismatch_count",
         "mismatch_columns", "passed"],
        row_rows
    )

    execution_ready = execution["returncode"] == 0
    replay_generated = replay_path is not None
    identity_ready = bool(comparison.get("scientific_identity", False))
    exact_replay_ready = bool(
        execution_ready
        and replay_generated
        and frozen_integrity_ready
        and identity_ready
    )

    remaining = []
    if not execution_ready:
        remaining.append({
            "gate": "EXACT_STAGE4B_COMMAND_EXECUTED",
            "required_action": (
                "Inspect stage6c2h1_execution_audit.csv for the full "
                "production-script exception."
            )
        })
    if not replay_generated:
        remaining.append({
            "gate": "SHADOW_REPLAY_TABLE_GENERATED",
            "required_action": (
                "Verify the patched output key and the production script's "
                "actual output-directory convention."
            )
        })
    if not frozen_integrity_ready:
        remaining.append({
            "gate": "FROZEN_STAGE4B_INTEGRITY_READY",
            "required_action": (
                "A protected Stage-4B/config checksum changed. Restore the "
                "frozen file before proceeding."
            )
        })
    if replay_generated and not identity_ready:
        remaining.append({
            "gate": "GLOBAL_REPLAY_IDENTITY_READY",
            "required_action": (
                "Inspect the column and row identity tables for the exact "
                "remaining numerical or schema mismatch."
            )
        })

    write_csv(
        out_dir / "tables/stage6c2h1_remaining_closure_items.csv",
        ["gate", "required_action"],
        remaining
    )

    validation = {
        "stage": STAGE,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "exact_runner": safe_rel(exact_runner, root),
        "exact_script": safe_rel(exact_script, root),
        "original_config": safe_rel(original_config, root),
        "shadow_config_copy": safe_rel(audit_copy, root),
        "shadow_output": safe_rel(shadow_output, root),
        "config_change_count": len(config_changes),
        "execution_returncode": execution["returncode"],
        "replay_table": safe_rel(replay_path, root) if replay_path else "",
        "prior_stage_outputs_modified": not frozen_integrity_ready,
        "EXACT_STAGE4B_RUNNER_IDENTIFIED": True,
        "EXACT_STAGE4B_SCRIPT_IDENTIFIED": True,
        "CONFIG_DIRECTORY_SEMANTICS_PRESERVED": True,
        "SHADOW_OUTPUT_REDIRECTED": len(config_changes) > 0,
        "EXACT_STAGE4B_COMMAND_EXECUTED": execution_ready,
        "SHADOW_REPLAY_TABLE_GENERATED": replay_generated,
        "FROZEN_STAGE4B_INTEGRITY_READY": frozen_integrity_ready,
        "GLOBAL_REPLAY_SCHEMA_IDENTITY_READY": bool(
            comparison.get("schema_identity", False)
        ),
        "GLOBAL_REPLAY_NUMERICAL_IDENTITY_READY": bool(
            comparison.get("numeric_identity", False)
        ),
        "GLOBAL_REPLAY_ROW_IDENTITY_READY": bool(
            comparison.get("row_identity", False)
        ),
        "GLOBAL_REPLAY_IDENTITY_READY": identity_ready,
        "EXACT_REPLAY_SPEC_READY": exact_replay_ready,
        "T06_EXACT_REPLAY_READY": exact_replay_ready
    }
    write_json(
        out_dir / "validation/stage6c2h1_validation.json",
        validation
    )

    summary = {
        "stage": STAGE,
        "timestamp_utc": utc_now(),
        "command": execution["command"],
        "replay_comparison": comparison,
        "remaining_closure_items": remaining,
        "scientific_disposition": (
            "Exact Stage-4B replay identity is closed. Stage-6D1 is authorized."
            if exact_replay_ready else
            "Exact replay remains blocked; do not start matched-footprint inference."
        )
    }
    write_json(
        out_dir / "summaries/stage6c2h1_summary.json",
        summary
    )

    report = [
        "# Stage-6C2H1 exact replay invocation hotfix",
        "",
        f"Generated: {utc_now()}",
        "",
        "## Exact lineage",
        "",
        f"- Runner: `{safe_rel(exact_runner, root)}`",
        f"- Script: `{safe_rel(exact_script, root)}`",
        f"- Original config: `{safe_rel(original_config, root)}`",
        f"- Temporary config was created beside the original config and then removed.",
        "",
        "## Execution",
        "",
        f"- Return code: `{execution['returncode']}`",
        f"- Replay table: `{safe_rel(replay_path, root) if replay_path else 'not generated'}`",
        f"- Frozen integrity: `{frozen_integrity_ready}`",
        "",
        "## Identity",
        "",
        f"- Schema identity: `{comparison.get('schema_identity', False)}`",
        f"- Numerical identity: `{comparison.get('numeric_identity', False)}`",
        f"- Row identity: `{comparison.get('row_identity', False)}`",
        f"- Scientific identity: `{identity_ready}`",
        "",
        "No Stage-6D3/6D4 footprint-matched gradient inference is authorized unless GLOBAL_REPLAY_IDENTITY_READY is true.",
        ""
    ]
    (out_dir / "reports/stage6c2h1_exact_replay_hotfix.md").write_text(
        "\n".join(report),
        encoding="utf-8"
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False
    ))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
