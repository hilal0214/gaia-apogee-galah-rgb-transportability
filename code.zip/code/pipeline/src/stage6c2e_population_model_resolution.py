from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

STAGE = "Stage-6C2E population-model resolution and membership-reconstruction feasibility audit"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.15.4"

SOURCE_ID_ALIASES = [
    "gaia_dr3_source_id", "source_id", "gaia_source_id", "star_id", "object_id"
]
VIEW_ALIASES = ["view", "analysis_view", "model_view", "feature_view"]
K_ALIASES = ["k", "n_components", "components", "component_count"]
COMPONENT_ALIASES = ["component", "class", "population", "cluster", "component_id"]
RESPONSIBILITY_TOKENS = ["responsibility", "probability", "posterior", "pmax", "membership"]
PARAMETER_TYPE_ALIASES = ["parameter_type", "parameter", "kind", "statistic", "term"]
FEATURE_ALIASES = ["feature", "variable", "dimension", "column", "label"]
VALUE_ALIASES = ["value", "estimate", "parameter_value", "mean", "weight"]
SELECTED_BOOL_TOKENS = [
    "selected", "primary", "reference", "preferred", "recommended",
    "winner", "best", "adopted", "fiducial", "production"
]

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def norm(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).lower()).strip("_")

def safe_rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def write_csv(path: Path, fields: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

def find_column(columns: Iterable[Any], aliases: list[str]) -> str | None:
    pairs = [(str(c), norm(c)) for c in columns]
    for alias in aliases:
        target = norm(alias)
        for original, candidate in pairs:
            if candidate == target or candidate.endswith("_" + target):
                return original
    return None

def read_table(path: Path, max_rows: int | None = None) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path, nrows=max_rows)
    if suffix == ".tsv":
        return pd.read_csv(path, sep="\t", nrows=max_rows)
    if suffix == ".parquet":
        frame = pd.read_parquet(path)
        return frame.head(max_rows) if max_rows else frame
    raise ValueError(path)

def parquet_metadata(path: Path) -> tuple[list[str], int, int]:
    import pyarrow.parquet as pq
    pf = pq.ParquetFile(path)
    return pf.schema.names, pf.metadata.num_rows, pf.metadata.num_row_groups

def json_scalar_paths(value: Any, prefix: str = "$") -> list[tuple[str, Any]]:
    rows = []
    if isinstance(value, dict):
        for key, child in value.items():
            rows.extend(json_scalar_paths(child, f"{prefix}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value[:1000]):
            rows.extend(json_scalar_paths(child, f"{prefix}[{index}]"))
    elif value is None or isinstance(value, (str, int, float, bool)):
        rows.append((prefix, value))
    return rows

def schema_for_file(path: Path) -> tuple[list[str], int | None, str]:
    try:
        if path.suffix.lower() in {".csv", ".tsv"}:
            frame = read_table(path, max_rows=10)
            sep = "\t" if path.suffix.lower() == ".tsv" else ","
            with path.open("rb") as f:
                rows = max(sum(1 for _ in f) - 1, 0)
            return [str(c) for c in frame.columns], rows, ""
        if path.suffix.lower() == ".parquet":
            columns, rows, _ = parquet_metadata(path)
            return columns, rows, ""
        if path.suffix.lower() == ".json":
            value = json.loads(path.read_text(encoding="utf-8"))
            scalar_paths = json_scalar_paths(value)
            columns = sorted({norm(path.split(".")[-1]) for path, _ in scalar_paths})
            return columns, len(scalar_paths), ""
    except Exception as exc:
        return [], None, f"{type(exc).__name__}: {exc}"
    return [], None, ""

def selection_evidence_from_frame(path: Path, frame: pd.DataFrame, root: Path, tokens: list[str]) -> list[dict[str, Any]]:
    rows = []
    view_col = find_column(frame.columns, VIEW_ALIASES)
    k_col = find_column(frame.columns, K_ALIASES)
    for column in frame.columns:
        normalized = norm(column)
        if not any(token in normalized for token in tokens):
            continue
        series = frame[column]
        if pd.api.types.is_bool_dtype(series) or set(series.dropna().astype(str).str.lower().unique()).issubset(
            {"true", "false", "1", "0", "yes", "no"}
        ):
            mask = series.astype(str).str.lower().isin({"true", "1", "yes"})
            subset = frame[mask]
            for _, row in subset.head(50).iterrows():
                rows.append({
                    "path": safe_rel(path, root),
                    "evidence_type": "boolean_selection_flag",
                    "selection_column": str(column),
                    "view": row.get(view_col, "") if view_col else "",
                    "k": row.get(k_col, "") if k_col else "",
                    "evidence_value": row.get(column, ""),
                    "row_excerpt": json.dumps(
                        {str(c): row[c] for c in frame.columns[:12]},
                        ensure_ascii=False, default=str
                    )
                })
        elif series.dtype == object:
            for index, value in series.dropna().astype(str).items():
                low = norm(value)
                if any(token in low for token in tokens):
                    row = frame.loc[index]
                    rows.append({
                        "path": safe_rel(path, root),
                        "evidence_type": "text_selection_marker",
                        "selection_column": str(column),
                        "view": row.get(view_col, "") if view_col else "",
                        "k": row.get(k_col, "") if k_col else "",
                        "evidence_value": value,
                        "row_excerpt": json.dumps(
                            {str(c): row[c] for c in frame.columns[:12]},
                            ensure_ascii=False, default=str
                        )
                    })
    return rows

def selection_evidence_from_json(path: Path, root: Path, tokens: list[str]) -> list[dict[str, Any]]:
    rows = []
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return rows
    for scalar_path, scalar_value in json_scalar_paths(value):
        low_path = norm(scalar_path)
        low_value = norm(scalar_value)
        if any(token in low_path or token in low_value for token in tokens):
            rows.append({
                "path": safe_rel(path, root),
                "evidence_type": "json_scalar_selection_marker",
                "selection_column": scalar_path,
                "view": "",
                "k": "",
                "evidence_value": scalar_value,
                "row_excerpt": ""
            })
    return rows

def model_parameter_profile(path: Path, root: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    try:
        frame = pd.read_csv(path)
    except Exception as exc:
        return [], {"load_error": f"{type(exc).__name__}: {exc}"}

    view_col = find_column(frame.columns, VIEW_ALIASES)
    k_col = find_column(frame.columns, K_ALIASES)
    component_col = find_column(frame.columns, COMPONENT_ALIASES)
    parameter_col = find_column(frame.columns, PARAMETER_TYPE_ALIASES)
    feature_col = find_column(frame.columns, FEATURE_ALIASES)
    value_col = find_column(frame.columns, VALUE_ALIASES)

    profile_rows = []
    grouping = [c for c in [view_col, k_col, component_col, parameter_col, feature_col] if c]
    if grouping:
        counts = frame.groupby(grouping, dropna=False).size().reset_index(name="rows")
        for _, row in counts.head(5000).iterrows():
            profile_rows.append({
                "path": safe_rel(path, root),
                "view": row.get(view_col, "") if view_col else "",
                "k": row.get(k_col, "") if k_col else "",
                "component": row.get(component_col, "") if component_col else "",
                "parameter_type": row.get(parameter_col, "") if parameter_col else "",
                "feature": row.get(feature_col, "") if feature_col else "",
                "rows": int(row["rows"])
            })

    column_norms = [norm(c) for c in frame.columns]
    values_blob = " ".join(
        norm(x) for col in frame.select_dtypes(include="object").columns
        for x in frame[col].dropna().astype(str).unique()[:300]
    )
    mean_present = any("mean" in c or "location" in c or "mu" == c for c in column_norms) or "mean" in values_blob
    covariance_present = any("cov" in c or "variance" in c or "precision" in c or "scale" in c for c in column_norms) or any(
        token in values_blob for token in ["covariance", "variance", "precision"]
    )
    weight_present = any("weight" in c or "mixing" in c or "prior" in c for c in column_norms) or any(
        token in values_blob for token in ["weight", "mixing_weight"]
    )
    preprocessing_present = any(
        token in " ".join(column_norms) + " " + values_blob
        for token in ["standard", "center", "scale", "median", "iqr", "mean_feature", "feature_scale"]
    )

    summary = {
        "columns": [str(c) for c in frame.columns],
        "rows": len(frame),
        "resolved_columns": {
            "view": view_col, "k": k_col, "component": component_col,
            "parameter_type": parameter_col, "feature": feature_col, "value": value_col
        },
        "mean_parameters_present": mean_present,
        "covariance_or_precision_present": covariance_present,
        "mixture_weights_present": weight_present,
        "preprocessing_parameters_present": preprocessing_present,
        "responsibility_reconstruction_schema_plausible": bool(
            view_col and k_col and component_col
            and mean_present and covariance_present and weight_present and preprocessing_present
        )
    }
    return profile_rows, summary

def semantic_evidence(files: list[Path], root: Path, semantic_tokens: list[str]) -> list[dict[str, Any]]:
    rows = []
    for path in files:
        try:
            if path.suffix.lower() in {".csv", ".tsv"}:
                frame = read_table(path)
                for column in frame.select_dtypes(include="object").columns:
                    for value in frame[column].dropna().astype(str).unique()[:1000]:
                        normalized = norm(value)
                        matched = [token for token in semantic_tokens if token in normalized]
                        if matched:
                            rows.append({
                                "path": safe_rel(path, root),
                                "location": str(column),
                                "value": value,
                                "matched_tokens": "|".join(matched)
                            })
            elif path.suffix.lower() == ".json":
                value = json.loads(path.read_text(encoding="utf-8"))
                for scalar_path, scalar_value in json_scalar_paths(value):
                    normalized = norm(scalar_value)
                    matched = [token for token in semantic_tokens if token in normalized]
                    if matched:
                        rows.append({
                            "path": safe_rel(path, root),
                            "location": scalar_path,
                            "value": scalar_value,
                            "matched_tokens": "|".join(matched)
                        })
        except Exception:
            continue
    return rows

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE)
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads((root / "config/stage6c2e_config.json").read_text(encoding="utf-8"))
    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for name in ["validation", "summaries", "tables", "reports"]:
        (out_dir / name).mkdir(parents=True, exist_ok=True)

    stage5b = root / cfg["stage5b_dir"]
    suffixes = {x.lower() for x in cfg["scan_suffixes"]}
    files = sorted(
        path for path in stage5b.rglob("*")
        if path.is_file() and path.suffix.lower() in suffixes
    ) if stage5b.exists() else []

    file_rows = []
    schema_rows = []
    star_level_candidates = []
    selection_rows = []

    for path in files:
        columns, n_rows, error = schema_for_file(path)
        file_rows.append({
            "path": safe_rel(path, root),
            "suffix": path.suffix.lower(),
            "size_bytes": path.stat().st_size,
            "sha256": sha256_file(path)
        })
        schema_rows.append({
            "path": safe_rel(path, root),
            "n_rows": n_rows if n_rows is not None else "",
            "columns": "|".join(columns),
            "load_error": error
        })

        source_id_col = find_column(columns, SOURCE_ID_ALIASES)
        component_col = find_column(columns, COMPONENT_ALIASES)
        responsibility_cols = [
            c for c in columns
            if any(token in norm(c) for token in RESPONSIBILITY_TOKENS)
        ]
        if source_id_col and (component_col or responsibility_cols):
            star_level_candidates.append({
                "path": safe_rel(path, root),
                "n_rows": n_rows if n_rows is not None else "",
                "source_id_column": source_id_col,
                "component_column": component_col or "",
                "responsibility_columns": "|".join(responsibility_cols),
                "sha256": sha256_file(path)
            })

        if not error:
            if path.suffix.lower() in {".csv", ".tsv"}:
                try:
                    frame = read_table(path)
                    selection_rows.extend(
                        selection_evidence_from_frame(
                            path, frame, root, cfg["selection_tokens"]
                        )
                    )
                except Exception:
                    pass
            elif path.suffix.lower() == ".json":
                selection_rows.extend(
                    selection_evidence_from_json(
                        path, root, cfg["selection_tokens"]
                    )
                )

    write_csv(
        out_dir / "tables/stage6c2e_stage5b_file_inventory.csv",
        ["path", "suffix", "size_bytes", "sha256"], file_rows
    )
    write_csv(
        out_dir / "tables/stage6c2e_stage5b_schema_inventory.csv",
        ["path", "n_rows", "columns", "load_error"], schema_rows
    )
    write_csv(
        out_dir / "tables/stage6c2e_star_level_candidate_files.csv",
        ["path", "n_rows", "source_id_column", "component_column",
         "responsibility_columns", "sha256"],
        star_level_candidates
    )
    write_csv(
        out_dir / "tables/stage6c2e_selection_evidence.csv",
        ["path", "evidence_type", "selection_column", "view", "k",
         "evidence_value", "row_excerpt"],
        selection_rows
    )

    model_path = stage5b / "stage5b_model_parameters.csv"
    parameter_rows, parameter_summary = (
        model_parameter_profile(model_path, root)
        if model_path.exists() else ([], {"load_error": "missing"})
    )
    write_csv(
        out_dir / "tables/stage6c2e_model_parameter_profile.csv",
        ["path", "view", "k", "component", "parameter_type", "feature", "rows"],
        parameter_rows
    )
    write_json(
        out_dir / "summaries/stage6c2e_model_parameter_summary.json",
        parameter_summary
    )

    semantic_rows = semantic_evidence(files, root, cfg["semantic_tokens"])
    write_csv(
        out_dir / "tables/stage6c2e_component_semantic_evidence.csv",
        ["path", "location", "value", "matched_tokens"], semantic_rows
    )

    # Resolve unique selected model only from explicit evidence rows.
    selected_pairs = set()
    for row in selection_rows:
        view = str(row.get("view", "")).strip()
        k = str(row.get("k", "")).strip()
        if view and k:
            selected_pairs.add((view, k))
    primary_model_resolved = len(selected_pairs) == 1
    selected_view, selected_k = next(iter(selected_pairs)) if primary_model_resolved else ("", "")

    # Design-layer feasibility.
    design_path = root / cfg["design_layer"]
    design_rows = []
    design_ready = False
    if design_path.exists():
        columns, n_rows, row_groups = parquet_metadata(design_path)
        resolved = {
            "r": find_column(columns, ["r_cyl_gc_kpc"]),
            "abs_z": find_column(columns, ["abs_z_gc_kpc"]),
            "block": find_column(columns, ["gaia_healpix5"]),
            "survey_origin": find_column(columns, ["survey_origin"]),
            "preferred_spectroscopic_survey": find_column(
                columns, ["preferred_spectroscopic_survey"]
            ),
            "source_id": find_column(columns, ["gaia_dr3_source_id"]),
        }
        label_columns = [
            c for c in columns if norm(c) in {
                "fe_h_hom", "mg_fe_hom", "si_fe_hom",
                "ca_fe_hom", "ni_fe_hom", "alpha3_hom"
            }
        ]
        gradient_ok_columns = [
            c for c in columns if norm(c).endswith("_gradient_primary_ok")
        ]
        design_ready = bool(
            resolved["r"] and resolved["abs_z"] and resolved["block"]
            and resolved["survey_origin"] and label_columns
        )
        for key, value in resolved.items():
            design_rows.append({
                "item": key, "resolved_column": value or "",
                "status": "resolved" if value else "missing"
            })
        design_rows.append({
            "item": "label_columns",
            "resolved_column": "|".join(label_columns),
            "status": "resolved" if label_columns else "missing"
        })
        design_rows.append({
            "item": "gradient_primary_ok_columns",
            "resolved_column": "|".join(gradient_ok_columns),
            "status": "resolved" if gradient_ok_columns else "missing"
        })
        design_rows.append({
            "item": "parquet_rows",
            "resolved_column": str(n_rows), "status": "metadata"
        })
        design_rows.append({
            "item": "row_groups",
            "resolved_column": str(row_groups), "status": "metadata"
        })
    write_csv(
        out_dir / "tables/stage6c2e_design_layer_resolution.csv",
        ["item", "resolved_column", "status"], design_rows
    )

    star_level_present = len(star_level_candidates) > 0
    replay_ready = bool(
        parameter_summary.get("responsibility_reconstruction_schema_plausible", False)
    )
    semantics_ready = len(semantic_rows) > 0

    # T04 requires selected model and responsibility summary, but not star-level membership.
    responsibility_summary_exists = (
        stage5b / "stage5b_responsibility_summary.csv"
    ).exists()
    t04_feasible = primary_model_resolved and responsibility_summary_exists
    t05_feasible = primary_model_resolved and (
        star_level_present or replay_ready
    ) and design_ready
    t06_feasible = design_ready

    required_actions = []
    if not primary_model_resolved:
        required_actions.append({
            "gate": "PRIMARY_MODEL_RESOLVED",
            "required_action": (
                "Identify exactly one frozen primary/reference (view, k) using Stage-5B "
                "validation, stability, or model-selection outputs."
            )
        })
    if not star_level_present and not replay_ready:
        required_actions.append({
            "gate": "POPULATION_MEMBERSHIP_SOURCE",
            "required_action": (
                "No source-ID keyed membership file and no fully replayable parameter schema were "
                "confirmed. Locate the omitted star-level responsibility output or create a frozen "
                "exact-replay stage from the original Stage-5B code."
            )
        })
    if not semantics_ready:
        required_actions.append({
            "gate": "COMPONENT_SEMANTICS_READY",
            "required_action": (
                "No frozen mapping from C1...Ck to physical population names was found. "
                "Use generic component names in the manuscript unless a documented mapping exists."
            )
        })
    if not design_ready:
        required_actions.append({
            "gate": "T06_DESIGN_LAYER_READY",
            "required_action": (
                "Required Stage-4A R, |Z|, block, survey-origin, or label columns are missing."
            )
        })
    write_csv(
        out_dir / "tables/stage6c2e_required_next_actions.csv",
        ["gate", "required_action"], required_actions
    )

    validation = {
        "stage": STAGE,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "stage5b_machine_readable_file_count": len(files),
        "stage5b_star_level_candidate_count": len(star_level_candidates),
        "selection_evidence_row_count": len(selection_rows),
        "explicit_selected_model_pair_count": len(selected_pairs),
        "selected_view": selected_view,
        "selected_k": selected_k,
        "semantic_evidence_row_count": len(semantic_rows),
        "prior_stage_outputs_modified": False,
        "PRIMARY_MODEL_RESOLVED": primary_model_resolved,
        "STAR_LEVEL_MEMBERSHIP_PRESENT": star_level_present,
        "RESPONSIBILITY_RECONSTRUCTION_READY": replay_ready,
        "COMPONENT_SEMANTICS_READY": semantics_ready,
        "T04_POPULATION_SUMMARY_FEASIBLE": t04_feasible,
        "T05_POPULATION_GRADIENTS_FEASIBLE": t05_feasible,
        "T06_SURVEY_SUBSET_CLOSURE_FEASIBLE": t06_feasible,
        "AUDIT_COMPLETED": True
    }
    write_json(out_dir / "validation/stage6c2e_validation.json", validation)

    summary = {
        "stage": STAGE,
        "timestamp_utc": utc_now(),
        "selected_model_pairs": [
            {"view": view, "k": k} for view, k in sorted(selected_pairs)
        ],
        "model_parameter_summary": parameter_summary,
        "star_level_candidate_files": star_level_candidates,
        "component_semantic_evidence": semantic_rows[:100],
        "required_next_actions": required_actions,
        "scientific_disposition": (
            "T04/T05 may proceed only if a unique primary model and auditable population membership are resolved. "
            "T06 is independent of population membership and may proceed from the resolved Stage-4A design layer."
        )
    }
    write_json(out_dir / "summaries/stage6c2e_summary.json", summary)

    report = [
        "# Stage-6C2E population-model resolution",
        "",
        f"Generated: {utc_now()}",
        "",
        "## Gates",
        "",
        f"- PRIMARY_MODEL_RESOLVED: `{primary_model_resolved}`",
        f"- STAR_LEVEL_MEMBERSHIP_PRESENT: `{star_level_present}`",
        f"- RESPONSIBILITY_RECONSTRUCTION_READY: `{replay_ready}`",
        f"- COMPONENT_SEMANTICS_READY: `{semantics_ready}`",
        f"- T04_POPULATION_SUMMARY_FEASIBLE: `{t04_feasible}`",
        f"- T05_POPULATION_GRADIENTS_FEASIBLE: `{t05_feasible}`",
        f"- T06_SURVEY_SUBSET_CLOSURE_FEASIBLE: `{t06_feasible}`",
        "",
        "## Scientific rule",
        "",
        "Generic mixture components must not be renamed as thin-disc, thick-disc, halo, or other physical populations without a frozen semantic mapping.",
        "",
        "T06 survey-subset gradients do not require population membership and should be closed separately from T05.",
        ""
    ]
    (out_dir / "reports/stage6c2e_population_model_resolution.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
