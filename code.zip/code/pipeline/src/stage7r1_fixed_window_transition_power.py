from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, shutil, sys, time, traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd

B=None
CFG=None
KNOTS=None

def now(): return datetime.now(timezone.utc).isoformat()
def canonical_sha(o):
    return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def write_json_atomic(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    t=p.with_suffix(p.suffix+".tmp")
    t.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
    os.replace(t,p)
def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise ImportError(str(path))
    m=importlib.util.module_from_spec(spec); sys.modules[name]=m; spec.loader.exec_module(m); return m
def thash(t):
    return hashlib.sha256(json.dumps(t,sort_keys=True,separators=(",",":")).encode()).hexdigest()
def cp_path(d,t): return d/(t["task_id"]+".json")
def valid_cp(p,t):
    try:
        o=json.loads(p.read_text(encoding="utf-8"))
        return o.get("task_identity_sha256")==thash(t) and np.isfinite(float(o["primary_cv_improvement"]))
    except Exception:
        return False
def p_inj(T,nullT): return float((1+np.sum(nullT>=float(T)))/(len(nullT)+1))
def p_null(i,nullT):
    Ti=float(nullT[i]); o=np.delete(nullT,i)
    return float((1+np.sum(o>=Ti))/len(nullT))

def init_worker(root_s):
    global B,CFG,KNOTS
    root=Path(root_s)
    CFG=json.loads((root/"config/stage7r1_config.json").read_text(encoding="utf-8"))
    B=load_module(f"stage7b2_engine_r1_{os.getpid()}",root/CFG["stage7b2_engine"])
    B.init_worker(str(root),CFG["stage7b2_config"])
    KNOTS=[float(CFG["sensitivity_knots_kpc"][0]),float(CFG["primary_knot_kpc"]),float(CFG["sensitivity_knots_kpc"][1])]

def run_rep(t):
    t0=time.perf_counter()
    y=B.synth(t["seed"],t["R_break_kpc"],t["delta_beta"])
    R,Z,w=B.G["R"],B.G["Z"],B.G["w"]
    primary=float(CFG["primary_knot_kpc"])
    imps=[]
    for of in range(5):
        tr=B.G["outer"]!=of; te=B.G["outer"]==of
        m0=B.wfit(B.f0(R[tr],Z[tr]),y[tr],w[tr])
        m1=B.wfit(B.f1(R[tr],Z[tr],primary),y[tr],w[tr])
        if not (m0.converged and m1.converged): raise RuntimeError("fixed-knot outer fit failed")
        a=B.wmae(y[te],B.pred(m0,B.f0(R[te],Z[te])),w[te])
        b=B.wmae(y[te],B.pred(m1,B.f1(R[te],Z[te],primary)),w[te])
        imps.append(float(1-b/a))

    fits={}
    for k in KNOTS:
        fit=B.wfit(B.f1(R,Z,k),y,w)
        if not fit.converged: raise RuntimeError(f"full fixed-knot fit failed at {k}")
        fits[k]=fit

    fitp=fits[primary]
    Xp=B.f1(R,Z,primary)
    inf=B.G["d4b"].weighted_cluster_inference(
        Xp,y,B.G["cell"].astype(np.int64),fitp,n_draws=0,seed=1,finite_cluster_correction=True
    )
    dh=float(fitp.beta[2]); se=float(inf.standard_errors[2]); z=1.959963984540054
    lo,hi=dh-z*se,dh+z*se
    deltas={f"{k:.1f}":float(fits[k].beta[2]) for k in KNOTS}
    signs=[np.sign(v) for v in deltas.values()]
    concord=bool(all(s==signs[0] and s!=0 for s in signs))
    correct=None if t["kind"]=="NULL" else bool(np.sign(dh)==np.sign(t["delta_beta"]))
    return {
      **t,
      "task_identity_sha256":thash(t),
      "primary_knot_kpc":primary,
      "primary_cv_improvement":float(np.median(imps)),
      "outer_cv_improvements":imps,
      "primary_delta_hat":dh,
      "primary_delta_se":se,
      "primary_wald_low":lo,
      "primary_wald_high":hi,
      "primary_wald_excludes_zero":bool(lo>0 or hi<0),
      "primary_sign_correct":correct,
      "delta_hat_knot_6p0":deltas["6.0"],
      "delta_hat_knot_6p5":deltas["6.5"],
      "delta_hat_knot_7p0":deltas["7.0"],
      "three_knot_sign_concordant":concord,
      "blocks":int(len(inf.block_ids)),
      "runtime_seconds":float(time.perf_counter()-t0),
      "completed_utc":now()
    }

def build_tasks(c):
    out=[]
    for i in range(int(c["null_replicates"])):
        out.append({"task_id":f"NULL_{i:04d}","kind":"NULL","scenario":"NULL","replicate_index":i,
                    "R_break_kpc":6.5,"delta_beta":0.0,"seed":int(c["null_seed_start"])+i})
    si=0
    for rb in c["target_injection_breaks_kpc"]:
        for delta in c["target_delta_beta"]:
            sc=f"RB{float(rb):.1f}_D{float(delta):+.2f}"
            seed0=int(c["target_seed_base"])+si*1000
            for i in range(int(c["replicates_per_target"])):
                out.append({"task_id":f"{sc}_{i:04d}","kind":"INJECTED","scenario":sc,"replicate_index":i,
                            "R_break_kpc":float(rb),"delta_beta":float(delta),"seed":seed0+i})
            si+=1
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",default=".")
    ap.add_argument("--workers",type=int,default=None)
    a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage7r1_config.json").read_text(encoding="utf-8"))
    prot=json.loads((root/"protocol/stage7r1_reframe_protocol.json").read_text(encoding="utf-8"))
    b2=json.loads((root/c["stage7b2_validation"]).read_text(encoding="utf-8"))
    b2c=json.loads((root/c["stage7b2c_validation"]).read_text(encoding="utf-8"))

    prereq=bool(
      b2.get("STAGE7B2_FORMAL_COMPLETE") and
      b2.get("FORMAL_STAGE7B2_POWER_CALIBRATION_PASS") is False and
      b2.get("STAGE7C_REAL_BREAK_FIT_AUTHORIZED") is False and
      b2.get("REAL_FEH_M1_BREAK_FIT_PERFORMED") is False and
      b2c.get("CURRENT_DESIGN_NOT_RELIABLY_POWERED_FOR_RADIAL_BREAK_LOCALIZATION",False) is False
    )
    # Stage7B2C uses disposition string rather than a boolean flag.
    prereq=bool(
      b2.get("STAGE7B2_FORMAL_COMPLETE") and
      b2.get("FORMAL_STAGE7B2_POWER_CALIBRATION_PASS") is False and
      b2.get("STAGE7C_REAL_BREAK_FIT_AUTHORIZED") is False and
      b2.get("REAL_FEH_M1_BREAK_FIT_PERFORMED") is False and
      b2c.get("DISPOSITION")=="CURRENT_DESIGN_NOT_RELIABLY_POWERED_FOR_RADIAL_BREAK_LOCALIZATION" and
      b2c.get("REAL_FEH_M1_BREAK_FIT_PERFORMED") is False
    )
    if not prereq: raise RuntimeError("Stage7B2/B2C closure prerequisite failed")

    out=root/c["output_dir"]
    for d in ["checkpoints","validation","tables","reports","freeze","logs","benchmarks"]:
        (out/d).mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/"protocol/stage7r1_reframe_protocol.json",out/"freeze/stage7r1_reframe_protocol_frozen.json")

    tasks=build_tasks(c)
    if len(tasks)!=768: raise RuntimeError(f"task identity failed: {len(tasks)}")
    cps=out/"checkpoints"
    pending=[t for t in tasks if not valid_cp(cp_path(cps,t),t)]
    workers=max(1,a.workers if a.workers else min(int(c["default_workers"]),max(1,(os.cpu_count() or 2)-1)))
    print(f"[7R1] total=768 existing={768-len(pending)} pending={len(pending)} workers={workers}")
    print("[7R1] No real fixed-knot or free-break Fe/H M1 is fitted.")
    start=time.perf_counter(); errors=[]
    if pending:
        with ProcessPoolExecutor(max_workers=workers,initializer=init_worker,initargs=(str(root),)) as ex:
            fs={ex.submit(run_rep,t):t for t in pending}; done=768-len(pending)
            for f in as_completed(fs):
                t=fs[f]
                try: write_json_atomic(cp_path(cps,t),f.result())
                except Exception as e:
                    errors.append(t["task_id"])
                    write_json_atomic(out/"logs"/f"ERROR_{t['task_id']}.json",
                                      {"task":t,"error":repr(e),"traceback":traceback.format_exc(),"utc":now()})
                done+=1
                if done%int(c["progress_every"])==0 or done==768:
                    print(f"[7R1] completed_or_attempted={done}/768 errors={len(errors)} elapsed_min={(time.perf_counter()-start)/60:.1f}")

    results=[]; missing=[]
    for t in tasks:
        p=cp_path(cps,t)
        if valid_cp(p,t): results.append(json.loads(p.read_text(encoding="utf-8")))
        else: missing.append(t["task_id"])
    if missing:
        write_json_atomic(out/"validation/stage7r1_resume_state.json",
                          {"VALID_CHECKPOINTS":len(results),"MISSING":len(missing),"RESUME_REQUIRED":True,
                           "REAL_TRANSITION_FIT_AUTHORIZED":False})
        return 3

    df=pd.DataFrame(results)
    null=df[df.kind=="NULL"].sort_values("replicate_index").copy()
    inj=df[df.kind=="INJECTED"].copy()
    nt=null.primary_cv_improvement.to_numpy(float)
    null["predictive_p"]=[p_null(i,nt) for i in range(len(nt))]
    null["detected_rule"]=(null.predictive_p<=.05)&null.primary_wald_excludes_zero.astype(bool)&null.three_knot_sign_concordant.astype(bool)
    inj["predictive_p"]=inj.primary_cv_improvement.map(lambda x:p_inj(x,nt))
    inj["detected_rule"]=(inj.predictive_p<=.05)&inj.primary_wald_excludes_zero.astype(bool)&inj.primary_sign_correct.astype(bool)&inj.three_knot_sign_concordant.astype(bool)

    fpr=float(null.detected_rule.mean())
    rows=[]
    for sc,g in inj.groupby("scenario",sort=True):
        rows.append({
          "scenario":sc,"R_break_kpc":float(g.R_break_kpc.iloc[0]),"delta_beta":float(g.delta_beta.iloc[0]),
          "replicates":len(g),"detection_power":float(g.detected_rule.mean()),
          "predictive_gate_fraction":float((g.predictive_p<=.05).mean()),
          "wald_gate_fraction":float(g.primary_wald_excludes_zero.mean()),
          "sign_concordance_fraction":float(g.three_knot_sign_concordant.mean()),
          "correct_primary_sign_fraction":float(g.primary_sign_correct.mean()),
          "median_primary_cv_improvement":float(g.primary_cv_improvement.median())
        })
    sm=pd.DataFrame(rows)
    sm.to_csv(out/"tables/stage7r1_target_power_summary.csv",index=False)
    pd.concat([null,inj],ignore_index=True).to_parquet(out/"tables/stage7r1_formal_replicates.parquet",index=False)
    gates=c["formal_gates"]
    fpass=bool(fpr<=gates["null_fpr_max"])
    ppass=bool(len(sm)==4 and (sm.detection_power>=gates["target_power_min_each"]).all())
    final=bool(fpass and ppass)

    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "STAGE7B2_FREE_BREAK_BRANCH_CLOSED_NOT_POWERED":True,
      "PARENT_SYNTHETIC_CLOSURE_READY":prereq,
      "REAL_FEH_FREE_BREAK_M1_FIT_PERFORMED":False,
      "REAL_FEH_FIXED_WINDOW_M1_FIT_PERFORMED":False,
      "PRIMARY_KNOT_KPC":6.5,
      "SENSITIVITY_KNOTS_KPC":[6.0,7.0],
      "FORMAL_NULL_REPLICATES_COMPLETED":len(null),
      "FORMAL_TARGET_REPLICATES_COMPLETED":len(inj),
      "NULL_FALSE_POSITIVE_RATE":fpr,
      "NULL_FPR_GATE_PASS":fpass,
      "ALL_FOUR_TARGET_POWER_GATES_PASS":ppass,
      "STAGE7R1_FIXED_WINDOW_POWER_CALIBRATION_PASS":final,
      "REAL_FIXED_WINDOW_TRANSITION_FIT_AUTHORIZED":final,
      "FREE_BREAK_RADIUS_LOCALIZATION_CLAIM_AUTHORIZED":False,
      "STAGE7C_REAL_BREAK_FIT_AUTHORIZED":False,
      "PROTOCOL_CANONICAL_SHA256":canonical_sha(prot)
    }
    write_json_atomic(out/"validation/stage7r1_validation.json",val)
    write_json_atomic(out/"benchmarks/stage7r1_runtime.json",
                      {"wall_seconds_this_run":time.perf_counter()-start,"workers":workers,
                       "median_replicate_runtime_seconds":float(df.runtime_seconds.median()),"checkpoint_resume":True})
    print(json.dumps({"validation":val,"target_summary":rows},indent=2,ensure_ascii=False))
    return 0 if final else 2

if __name__=="__main__": raise SystemExit(main())
