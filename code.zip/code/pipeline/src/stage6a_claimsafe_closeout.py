from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

STAGE_NAME = "Stage-6A claim-safe final synthesis and archival closeout"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.12.0"

JSON_SUFFIXES = {".json"}
TABLE_SUFFIXES = {".csv", ".tsv"}
TEXT_SUFFIXES = {".md", ".txt", ".tex", ".log", ".yaml", ".yml"}
SCAN_SUFFIXES = JSON_SUFFIXES | TABLE_SUFFIXES | TEXT_SUFFIXES

STAGE_RE = re.compile(r"stage[\s_\-]?([0-9]+[a-z]?)", re.IGNORECASE)
NUMBER_RE = re.compile(r"[-+]?(?:\d+\.\d+|\d+|\.\d+)(?:[eE][-+]?\d+)?")

@dataclass
class InventoryRow:
    path: str
    stage_tag: str
    suffix: str
    size_bytes: int
    sha256: str

@dataclass
class MetricRow:
    source_path: str
    key: str
    value: str
    value_type: str

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

def stage_tag(path: Path) -> str:
    text = str(path).lower()
    matches = STAGE_RE.findall(text)
    return matches[-1].upper() if matches else "UNSPECIFIED"

def excluded(path: Path, root: Path, out_dir: Path, excluded_names: set[str]) -> bool:
    try:
        rel = path.relative_to(root)
    except ValueError:
        return True
    if out_dir in path.parents or path == out_dir:
        return True
    return any(part.lower() in excluded_names for part in rel.parts)

def discover_files(root: Path, out_dir: Path, excluded_names: set[str]) -> list[Path]:
    files: list[Path] = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if excluded(p, root, out_dir, excluded_names):
            continue
        if p.suffix.lower() in SCAN_SUFFIXES:
            files.append(p)
    return sorted(files)

def scalar_to_text(value: Any) -> tuple[str, str] | None:
    if value is None:
        return "null", "null"
    if isinstance(value, bool):
        return ("true" if value else "false"), "bool"
    if isinstance(value, int):
        return str(value), "int"
    if isinstance(value, float):
        if math.isnan(value):
            return "NaN", "float"
        if math.isinf(value):
            return ("Infinity" if value > 0 else "-Infinity"), "float"
        return format(value, ".12g"), "float"
    if isinstance(value, str):
        clean = " ".join(value.split())
        if len(clean) > 500:
            clean = clean[:497] + "..."
        return clean, "str"
    return None

def flatten_json(obj: Any, prefix: str = "") -> Iterable[tuple[str, Any]]:
    if isinstance(obj, dict):
        for key, value in obj.items():
            next_prefix = f"{prefix}.{key}" if prefix else str(key)
            yield from flatten_json(value, next_prefix)
    elif isinstance(obj, list):
        if len(obj) <= 20 and all(not isinstance(x, (dict, list)) for x in obj):
            yield prefix, obj
        else:
            yield f"{prefix}.__length__", len(obj)
    else:
        yield prefix, obj

def extract_json_metrics(path: Path, root: Path) -> list[MetricRow]:
    rows: list[MetricRow] = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError, OSError):
        return rows
    rel = str(path.relative_to(root)).replace("\\", "/")
    for key, value in flatten_json(data):
        if isinstance(value, list):
            text = json.dumps(value, ensure_ascii=False)
            rows.append(MetricRow(rel, key, text[:500], "list"))
            continue
        scalar = scalar_to_text(value)
        if scalar:
            rows.append(MetricRow(rel, key, scalar[0], scalar[1]))
    return rows

def extract_table_metrics(path: Path, root: Path, max_rows: int = 200) -> list[MetricRow]:
    rows: list[MetricRow] = []
    delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
    rel = str(path.relative_to(root)).replace("\\", "/")
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f, delimiter=delimiter)
            if not reader.fieldnames:
                return rows
            count = 0
            numeric: dict[str, list[float]] = {name: [] for name in reader.fieldnames}
            for record in reader:
                count += 1
                if count <= max_rows:
                    for name, raw in record.items():
                        if raw is None:
                            continue
                        value = raw.strip()
                        if not value:
                            continue
                        if NUMBER_RE.fullmatch(value):
                            try:
                                numeric[name].append(float(value))
                            except ValueError:
                                pass
            rows.append(MetricRow(rel, "__row_count_scanned__", str(count), "int"))
            for name, values in numeric.items():
                if values:
                    rows.append(MetricRow(rel, f"{name}.__numeric_count__", str(len(values)), "int"))
                    rows.append(MetricRow(rel, f"{name}.__min__", format(min(values), ".12g"), "float"))
                    rows.append(MetricRow(rel, f"{name}.__max__", format(max(values), ".12g"), "float"))
    except (OSError, UnicodeDecodeError, csv.Error):
        return rows
    return rows

def read_search_corpus(files: list[Path], root: Path, byte_limit: int = 2_000_000) -> str:
    chunks: list[str] = []
    total = 0
    for path in files:
        if path.suffix.lower() not in SCAN_SUFFIXES:
            continue
        try:
            raw = path.read_bytes()
        except OSError:
            continue
        if total >= byte_limit:
            break
        raw = raw[: min(len(raw), 200_000, byte_limit - total)]
        total += len(raw)
        text = raw.decode("utf-8", errors="ignore")
        chunks.append(str(path.relative_to(root)).lower())
        chunks.append(text.lower())
    return "\n".join(chunks)

def evidence(corpus: str, terms: list[str], mode: str = "any") -> bool:
    hits = [term.lower() in corpus for term in terms]
    return all(hits) if mode == "all" else any(hits)

def build_claims(corpus: str, stage5b_present: bool) -> list[dict[str, str]]:
    crossfit = evidence(corpus, ["cross-fit", "crossfit", "held-out fold", "heldout fold"])
    overlap = evidence(corpus, ["overlap", "common-star", "common star"])
    calibration = evidence(corpus, ["calibration", "harmonisation", "harmonization"])
    transport = evidence(corpus, ["transport", "transfer", "external survey"])
    footprint = evidence(corpus, ["footprint match", "matched footprint", "common magnitude", "selection-function"])
    labelwise = evidence(corpus, ["label", "abundance"])
    validation = evidence(corpus, ["validation", "passed", "ready"])
    heldout = evidence(corpus, ["held-out", "heldout", "test fold", "validation fold"])

    claims = [
        {
            "claim_id": "C01",
            "claim": "The release contains a frozen, reproducible multi-stage Gaia–APOGEE–GALAH RGB transportability workflow.",
            "status": "SUPPORTED" if stage5b_present and validation else "QUALIFIED",
            "evidence_boundary": "Requires a discoverable Stage-5B anchor and machine-readable validation/provenance products.",
            "prohibited_overstatement": "Do not describe the release as independently reproduced outside the archived workflow."
        },
        {
            "claim_id": "C02",
            "claim": "Cross-survey abundance mappings are empirically constrained by APOGEE–GALAH overlap stars.",
            "status": "SUPPORTED" if overlap and calibration else "QUALIFIED",
            "evidence_boundary": "Empirical overlap calibration; not an assertion of an absolute universal abundance scale.",
            "prohibited_overstatement": "Do not claim physical identity of the two survey abundance systems."
        },
        {
            "claim_id": "C03",
            "claim": "Transport performance is evaluated out of sample rather than only on calibration stars.",
            "status": "SUPPORTED" if (crossfit or heldout) and transport else "QUALIFIED",
            "evidence_boundary": "Limited to the discovered held-out/cross-fitted products and their declared support.",
            "prohibited_overstatement": "Do not generalise beyond the tested labels, parameter range, and survey support."
        },
        {
            "claim_id": "C04",
            "claim": "Transportability is label-dependent and should be reported with label-specific uncertainty and residual structure.",
            "status": "SUPPORTED" if labelwise and transport else "QUALIFIED",
            "evidence_boundary": "Interpretation must follow the per-label diagnostics in the frozen tables.",
            "prohibited_overstatement": "Do not collapse all abundances into a single universal transport score."
        },
        {
            "claim_id": "C05",
            "claim": "The smaller GALAH-supported layer provides a robustness test within its observed footprint.",
            "status": "QUALIFIED" if overlap else "NOT_CLAIMED",
            "evidence_boundary": "Survey footprint, magnitude, colour, and support differences remain relevant.",
            "prohibited_overstatement": "Do not call this a fully survey-independent replication."
        },
        {
            "claim_id": "C06",
            "claim": "A universal selection-function-corrected Milky Way abundance atlas is established.",
            "status": "NOT_CLAIMED",
            "evidence_boundary": "Would require explicit footprint matching and a dedicated selection-function model.",
            "prohibited_overstatement": "Exclude this claim from abstract, conclusions, and archive description."
        },
        {
            "claim_id": "C07",
            "claim": "Stage-6A introduces a new scientific fit or changes frozen Stage-1–Stage-5 estimates.",
            "status": "NOT_CLAIMED",
            "evidence_boundary": "Stage-6A is synthesis, audit, and packaging only.",
            "prohibited_overstatement": "Do not cite Stage-6A as an independent modelling result."
        },
    ]
    if footprint:
        for c in claims:
            if c["claim_id"] == "C05":
                c["evidence_boundary"] += " Footprint/selection-function diagnostics were discovered, but their exact scope must still be stated."
    return claims

def write_csv(path: Path, fieldnames: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

def tex_escape(value: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    out = value
    for old, new in replacements.items():
        out = out.replace(old, new)
    return out

def manifest_for(out_dir: Path) -> list[dict[str, Any]]:
    rows = []
    for p in sorted(out_dir.rglob("*")):
        if p.is_file() and "checksums" not in p.parts and "manifest" not in p.parts:
            rows.append({
                "path": str(p.relative_to(out_dir)).replace("\\", "/"),
                "size_bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    return rows

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE_NAME)
    parser.add_argument("--project-root", default=".", help="Project root containing prior-stage outputs.")
    parser.add_argument("--allow-missing-stage5b", action="store_true",
                        help="Write a diagnostic closeout even when the Stage-5B anchor is absent.")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg_path = root / "config" / "stage6a_config.json"
    if cfg_path.exists():
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    else:
        cfg = {
            "output_dir": "outputs/stage6a_claimsafe_closeout",
            "scan_exclude_dirs": [".git", ".conda", "__pycache__", "outputs/stage6a_claimsafe_closeout"],
            "max_metric_rows": 5000,
            "zenodo": {}
        }

    out_dir = root / cfg.get("output_dir", "outputs/stage6a_claimsafe_closeout")
    out_dir.mkdir(parents=True, exist_ok=True)
    for sub in ["validation", "summaries", "tables", "manuscript", "zenodo", "manifest", "checksums"]:
        (out_dir / sub).mkdir(exist_ok=True)

    excluded_names = {".git", ".conda", "__pycache__", ".pytest_cache"}
    files = discover_files(root, out_dir, excluded_names)
    inventory = [
        InventoryRow(
            path=str(p.relative_to(root)).replace("\\", "/"),
            stage_tag=stage_tag(p),
            suffix=p.suffix.lower(),
            size_bytes=p.stat().st_size,
            sha256=sha256_file(p),
        )
        for p in files
    ]

    stage5b_files = [r for r in inventory if "stage5b" in r.path.lower() or r.stage_tag == "5B"]
    stage5b_present = bool(stage5b_files)

    metrics: list[MetricRow] = []
    for p in files:
        if p.suffix.lower() == ".json":
            metrics.extend(extract_json_metrics(p, root))
        elif p.suffix.lower() in TABLE_SUFFIXES:
            metrics.extend(extract_table_metrics(p, root))
        if len(metrics) >= int(cfg.get("max_metric_rows", 5000)):
            metrics = metrics[: int(cfg.get("max_metric_rows", 5000))]
            break

    corpus = read_search_corpus(files, root)
    claims = build_claims(corpus, stage5b_present)

    write_csv(
        out_dir / "tables" / "stage6a_stage_inventory.csv",
        ["path", "stage_tag", "suffix", "size_bytes", "sha256"],
        (asdict(r) for r in inventory),
    )
    write_csv(
        out_dir / "tables" / "stage6a_key_metrics.csv",
        ["source_path", "key", "value", "value_type"],
        (asdict(r) for r in metrics),
    )
    write_csv(
        out_dir / "tables" / "stage6a_claim_ledger.csv",
        ["claim_id", "claim", "status", "evidence_boundary", "prohibited_overstatement"],
        claims,
    )

    counts_by_stage: dict[str, int] = {}
    for row in inventory:
        counts_by_stage[row.stage_tag] = counts_by_stage.get(row.stage_tag, 0) + 1

    validation = {
        "stage": STAGE_NAME,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "project_root": str(root),
        "timestamp_utc": utc_now(),
        "prior_stage_files_discovered": len(inventory) > 0,
        "stage5b_anchor_present": stage5b_present,
        "stage5b_anchor_file_count": len(stage5b_files),
        "machine_readable_metrics_extracted": len(metrics) > 0,
        "claim_ledger_created": True,
        "manuscript_assets_created": True,
        "zenodo_assets_created": True,
        "prior_stage_outputs_modified": False,
        "STAGE6A_CLOSEOUT_READY": bool(stage5b_present and len(metrics) > 0),
    }
    if args.allow_missing_stage5b:
        validation["STAGE6A_CLOSEOUT_READY"] = bool(len(metrics) > 0)
        validation["missing_stage5b_override_used"] = not stage5b_present

    summary = {
        "stage": STAGE_NAME,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": utc_now(),
        "inventory_file_count": len(inventory),
        "stage_counts": counts_by_stage,
        "stage5b_anchor_paths": [r.path for r in stage5b_files[:100]],
        "metric_row_count": len(metrics),
        "claim_status_counts": {
            status: sum(c["status"] == status for c in claims)
            for status in ["SUPPORTED", "QUALIFIED", "NOT_CLAIMED"]
        },
        "scientific_disposition": (
            "Proceed to manuscript and Zenodo integration using the claim ledger."
            if validation["STAGE6A_CLOSEOUT_READY"]
            else "Do not freeze the archival release until the Stage-5B anchor and machine-readable metrics are available."
        ),
    }

    (out_dir / "validation" / "stage6a_validation.json").write_text(
        json.dumps(validation, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    (out_dir / "summaries" / "stage6a_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    macros = [
        "% Auto-generated by RGB transportability Stage-6A v0.12.0",
        rf"\newcommand{{\RGBStageSixInventoryCount}}{{{len(inventory)}}}",
        rf"\newcommand{{\RGBStageSixMetricCount}}{{{len(metrics)}}}",
        rf"\newcommand{{\RGBStageSixStageFiveBCount}}{{{len(stage5b_files)}}}",
        rf"\newcommand{{\RGBStageSixSupportedClaims}}{{{sum(c['status']=='SUPPORTED' for c in claims)}}}",
        rf"\newcommand{{\RGBStageSixQualifiedClaims}}{{{sum(c['status']=='QUALIFIED' for c in claims)}}}",
        rf"\newcommand{{\RGBStageSixNotClaimed}}{{{sum(c['status']=='NOT_CLAIMED' for c in claims)}}}",
        rf"\newcommand{{\RGBStageSixCloseoutStatus}}{{{tex_escape('READY' if validation['STAGE6A_CLOSEOUT_READY'] else 'NOT READY')}}}",
        "",
    ]
    (out_dir / "manuscript" / "stage6a_manuscript_macros.tex").write_text(
        "\n".join(macros), encoding="utf-8"
    )

    supported = [c for c in claims if c["status"] == "SUPPORTED"]
    qualified = [c for c in claims if c["status"] == "QUALIFIED"]
    not_claimed = [c for c in claims if c["status"] == "NOT_CLAIMED"]
    md = [
        "# Stage-6A claim-safe results synthesis",
        "",
        f"Closeout status: **{'READY' if validation['STAGE6A_CLOSEOUT_READY'] else 'NOT READY'}**.",
        "",
        "## Supported release-level statements",
        "",
    ]
    md += [f"- {c['claim']} Boundary: {c['evidence_boundary']}" for c in supported] or ["- None automatically promoted."]
    md += ["", "## Qualified statements", ""]
    md += [f"- {c['claim']} Boundary: {c['evidence_boundary']}" for c in qualified] or ["- None."]
    md += ["", "## Explicitly excluded claims", ""]
    md += [f"- {c['claim']} {c['prohibited_overstatement']}" for c in not_claimed] or ["- None."]
    md += [
        "",
        "## Recommended manuscript wording",
        "",
        "The analysis is interpreted as a support-bounded cross-survey transportability study. "
        "The calibrated APOGEE–GALAH overlap constrains empirical mappings within the stellar-parameter "
        "and abundance support represented by the training and held-out products. Performance is reported "
        "label by label; no universal abundance-scale identity is assumed. The smaller GALAH-supported "
        "subsets provide footprint-limited robustness tests rather than a fully survey-independent replication.",
        "",
    ]
    (out_dir / "manuscript" / "stage6a_results_claimsafe.md").write_text("\n".join(md), encoding="utf-8")

    availability = r"""\section*{Data and Code Availability}
The machine-readable products supporting this analysis are distributed with the versioned reproducibility
release. The archive contains the frozen stage outputs, validation reports, claim ledger, stage inventory,
checksums, and the scripts required to regenerate the Stage-6A closeout products. Large upstream survey
catalogues are not redistributed; they remain available from their respective Gaia DR3, APOGEE DR17,
and GALAH DR4 public data services. The repository and version-specific DOI should be inserted here
after the archival deposit is minted.
"""
    (out_dir / "manuscript" / "stage6a_data_code_availability.tex").write_text(availability, encoding="utf-8")

    zenodo_readme = r"""# Zenodo release assembly

Include:

1. Source code and launchers for all frozen stages.
2. Compact machine-readable stage outputs required to reproduce manuscript tables and figures.
3. Stage-6A validation, summary, claim ledger, inventory, and SHA-256 checksums.
4. Environment specification or dependency lock file.
5. A top-level README containing exact Windows/PowerShell reproduction commands.
6. Citation metadata, software/data licences, funding acknowledgement, and AI-assistance disclosure where required.

Do not redistribute restricted or unnecessarily large upstream survey catalogues. Instead provide stable
source identifiers, query definitions, cache manifests, and integrity hashes.

Before deposit, confirm:

- the manuscript cites the exact-version DOI;
- the repository README may additionally cite the concept DOI;
- every manuscript table/figure maps to a machine-readable source product;
- the claim ledger and known limitations are retained;
- no temporary caches, credentials, or local absolute paths are included.
"""
    (out_dir / "zenodo" / "README_ZENODO.md").write_text(zenodo_readme, encoding="utf-8")

    zen_cfg = cfg.get("zenodo", {})
    metadata = {
        "title": zen_cfg.get("title", "Gaia–APOGEE–GALAH RGB transportability workflow: reproducibility release"),
        "upload_type": zen_cfg.get("upload_type", "software"),
        "description": (
            "Versioned reproducibility release for a support-aware Gaia DR3–APOGEE DR17–GALAH DR4 "
            "red-giant-branch cross-survey calibration and transportability workflow."
        ),
        "creators": [{"name": "INSERT AUTHORS"}],
        "license": zen_cfg.get("license", "MIT"),
        "keywords": zen_cfg.get("keywords", []),
        "version": "0.12.0",
        "related_identifiers": [],
        "notes": "Replace placeholders and verify journal, funding, ORCID, and DOI metadata before deposit."
    }
    (out_dir / "zenodo" / "metadata_template.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    manifest_rows = manifest_for(out_dir)
    manifest = {
        "stage": STAGE_NAME,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "created_utc": utc_now(),
        "files": manifest_rows,
    }
    (out_dir / "manifest" / "stage6a_output_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    final_files = [p for p in sorted(out_dir.rglob("*")) if p.is_file() and "checksums" not in p.parts]
    checksum_lines = [
        f"{sha256_file(p)}  {str(p.relative_to(out_dir)).replace(os.sep, '/')}"
        for p in final_files
    ]
    (out_dir / "checksums" / "SHA256SUMS.txt").write_text("\n".join(checksum_lines) + "\n", encoding="utf-8")

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    return 0 if validation["STAGE6A_CLOSEOUT_READY"] else 2

if __name__ == "__main__":
    raise SystemExit(main())
