from __future__ import annotations
import argparse, hashlib, json, shutil, zipfile
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

def now():
    return datetime.now(timezone.utc).isoformat()

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str)+"\n", encoding="utf-8")

def safe_copy(root: Path, rel: str, release_root: Path):
    src=root/rel
    if not src.exists():
        raise FileNotFoundError(str(src))
    dst=release_root/"science"/rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src,dst)
    return dst

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args=ap.parse_args()
    root=Path(args.project_root).resolve()
    cfg=json.loads((root/"config/stage6d5b_config.json").read_text(encoding="utf-8"))
    out=root/cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)

    d5v_path=root/cfg["d5a_validation"]
    if not d5v_path.exists():
        raise FileNotFoundError(str(d5v_path))
    d5v=json.loads(d5v_path.read_text(encoding="utf-8"))
    prereq=bool(
        d5v.get("STAGE6D5A_MANUSCRIPT_CLAIM_INTEGRATION_READY",False)
        and d5v.get("STAGE6D5B_ARCHIVAL_RELEASE_READY",False)
        and d5v.get("CLAIM_BOUNDARIES_PRESERVED",False)
        and d5v.get("NO_SCIENCE_REFIT_PERFORMED",False)
    )

    release_root=out/cfg["release_name"]
    release_root.mkdir(parents=True, exist_ok=True)

    missing=[]
    copied=[]
    for rel in cfg["required_files"]:
        p=root/rel
        if not p.exists():
            missing.append(rel)
        else:
            copied.append(safe_copy(root,rel,release_root))

    if missing:
        write_json(out/"validation/stage6d5b_missing_required_files.json",{"missing":missing})
        raise RuntimeError(f"Missing required release files: {missing}")

    optional_present=[]
    for rel in cfg["optional_files"]:
        p=root/rel
        if p.exists():
            copied.append(safe_copy(root,rel,release_root))
            optional_present.append(rel)

    # Explicit release documentation.
    readme = """# RGB transportability science release v0.26.0

This archive is the claim-safe reproducibility release for the frozen
Gaia--APOGEE--GALAH RGB transportability common-footprint analysis.

Final Stage-6D4 classification:
- [Ni/Fe]: TRANSPORT_STABLE in both radial and vertical gradients.
- [Si/Fe]: vertical TRANSPORT_STABLE; radial INDETERMINATE.
- [Ca/Fe]: vertical TRANSPORT_STABLE; radial INDETERMINATE.
- [Fe/H]: radial and vertical INDETERMINATE.
- [Mg/Fe]: radial and vertical INDETERMINATE.
- No primary label is classified as FOOTPRINT_SENSITIVE.
- No primary label is classified as SURVEY_SENSITIVE.

Interpretation boundary:
INDETERMINATE is not evidence of instability. It means that the strict frozen
practical-equivalence criterion was not fully established, while the
pre-specified footprint/survey sensitivity criterion was also not triggered.

This archive intentionally excludes:
- the manuscript;
- manuscript PDF;
- raw APOGEE/GALAH/Gaia survey catalogues;
- the row-level D3C9 production-balanced source.

Those exclusions avoid redistributing source survey data and keep this package
focused on derived science outputs, frozen protocols, analysis code, and
reproducibility metadata.

Human Zenodo metadata (authors, affiliations, ORCIDs, license, DOI) are not
invented here and must be completed before public deposition.
"""
    (release_root/"README.md").write_text(readme, encoding="utf-8")

    citation = """cff-version: 1.2.0
message: "If you use this science release, please cite the associated paper and archived release."
title: "RGB transportability science release"
version: "0.26.0"
type: software
authors:
  - family-names: "TO_BE_VERIFIED"
    given-names: "TO_BE_VERIFIED"
date-released: "2026-08-11"
repository-code: "TO_BE_ADDED_IF_PUBLIC"
doi: "TO_BE_ASSIGNED_BY_ZENODO"
"""
    (release_root/"CITATION.cff").write_text(citation, encoding="utf-8")

    zenodo = {
        "title":"RGB transportability science release",
        "upload_type":"software",
        "description":"Claim-safe reproducibility archive for the frozen Gaia--APOGEE--GALAH RGB transportability common-footprint analysis.",
        "creators":[
            {
                "name":"TO_BE_VERIFIED",
                "affiliation":"TO_BE_VERIFIED",
                "orcid":"TO_BE_VERIFIED"
            }
        ],
        "version":"0.26.0",
        "publication_date":"2026-08-11",
        "license":"TO_BE_SELECTED",
        "keywords":[
            "Milky Way","chemical abundances","APOGEE","GALAH","Gaia",
            "survey transportability","Galactic gradients","reproducibility"
        ],
        "notes":"Manuscript and row-level survey data are intentionally excluded. Complete creators, affiliations, ORCIDs, license and DOI metadata before public deposition."
    }
    write_json(release_root/"zenodo_metadata_template.json",zenodo)

    boundary = {
        "allowed_claims":[
            "[Ni/Fe] is transport-stable for both radial and vertical gradients within the tested balanced common support.",
            "[Si/Fe] and [Ca/Fe] are transport-stable vertically but overall indeterminate.",
            "[Fe/H] and [Mg/Fe] are indeterminate under the frozen practical-equivalence rules.",
            "No primary label is classified as footprint-sensitive or survey-sensitive."
        ],
        "forbidden_claims":[
            "indeterminate means unstable or non-transportable",
            "volume-complete Milky Way gradients",
            "independent GALAH replication",
            "selection-function-corrected replication",
            "target-abundance matching",
            "causal footprint effects",
            "general five-label predictive law",
            "component-resolved gradients"
        ]
    }
    write_json(release_root/"CLAIM_BOUNDARIES.json",boundary)

    # Verify no forbidden content entered release.
    forbidden_hits=[]
    for p in release_root.rglob("*"):
        if not p.is_file():
            continue
        rel=str(p.relative_to(release_root)).replace("\\","/").lower()
        for tok in cfg["forbidden_path_tokens"]:
            if tok.lower() in rel:
                forbidden_hits.append({"path":rel,"token":tok})

    # Build manifest before ZIP.
    manifest=[]
    for p in sorted(release_root.rglob("*")):
        if p.is_file():
            manifest.append({
                "path":str(p.relative_to(release_root)).replace("\\","/"),
                "size_bytes":p.stat().st_size,
                "sha256":sha256_file(p)
            })
    pd.DataFrame(manifest).to_csv(release_root/"MANIFEST_SHA256.csv",index=False)

    # Recompute including manifest itself and emit root-level technical manifest.
    tech_manifest=[]
    for p in sorted(release_root.rglob("*")):
        if p.is_file():
            tech_manifest.append({
                "path":str(p.relative_to(release_root)).replace("\\","/"),
                "size_bytes":p.stat().st_size,
                "sha256":sha256_file(p)
            })
    pd.DataFrame(tech_manifest).to_csv(out/"stage6d5b_release_manifest_sha256.csv",index=False)

    release_zip=out/f"{cfg['release_name']}.zip"
    with zipfile.ZipFile(release_zip,"w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(release_root.rglob("*")):
            if p.is_file():
                z.write(p,p.relative_to(release_root))

    metadata_complete=False
    technical_ready=bool(
        prereq
        and not forbidden_hits
        and release_zip.exists()
        and len(manifest)>0
    )

    validation = {
        "stage":cfg["stage"],
        "implementation_version":cfg["implementation_version"],
        "timestamp_utc":now(),
        "D5A_PREREQUISITE_READY":prereq,
        "REQUIRED_RELEASE_FILES_READY":True,
        "OPTIONAL_RELEASE_FILES_PRESENT":optional_present,
        "MANUSCRIPT_EXCLUDED_READY":True,
        "RAW_ROW_LEVEL_SURVEY_DATA_EXCLUDED_READY":True,
        "D3C9_ROW_LEVEL_BALANCED_SOURCE_EXCLUDED_READY":True,
        "FORBIDDEN_RELEASE_CONTENT_HITS":forbidden_hits,
        "CLAIM_BOUNDARIES_ARCHIVED_READY":True,
        "SHA256_MANIFEST_READY":True,
        "RELEASE_ZIP_READY":release_zip.exists(),
        "RELEASE_ZIP":str(release_zip.relative_to(root)).replace("\\","/"),
        "RELEASE_ZIP_SHA256":sha256_file(release_zip),
        "TECHNICAL_ARCHIVAL_RELEASE_READY":technical_ready,
        "ZENODO_HUMAN_METADATA_COMPLETE":metadata_complete,
        "ZENODO_PUBLIC_DEPOSITION_READY":bool(technical_ready and metadata_complete),
        "STAGE6D5B_ARCHIVAL_RELEASE_CLOSED":technical_ready
    }
    (out/"validation").mkdir(exist_ok=True)
    write_json(out/"validation/stage6d5b_validation.json",validation)

    print(json.dumps({"validation":validation},indent=2,ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
