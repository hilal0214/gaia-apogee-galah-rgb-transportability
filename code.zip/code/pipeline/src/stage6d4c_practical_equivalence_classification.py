from __future__ import annotations
import argparse,hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
from typing import Any
import numpy as np,pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def canonical_bytes(o:Any)->bytes:
    return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode("utf-8")
def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
def wj(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def rt(p):
    return pd.read_parquet(p) if p.suffix.lower()==".parquet" else pd.read_csv(p)

def model_row(est,label,model):
    x=est[(est["label"]==label)&(est["model_id"]==model)]
    if len(x)!=1: raise RuntimeError(f"{label}/{model}: expected one estimate row, found {len(x)}")
    return x.iloc[0]

def draw_array(draws,label,model,col):
    x=draws[(draws["label"]==label)&(draws["model_id"]==model)]
    if len(x)==0: raise RuntimeError(f"{label}/{model}: no draws")
    a=pd.to_numeric(x[col],errors="coerce").to_numpy(float)
    if not np.all(np.isfinite(a)): raise RuntimeError(f"{label}/{model}/{col}: nonfinite draws")
    return a

def conservative_difference_interval(b,a,qlo=0.0125,qhi=0.9875):
    b=np.asarray(b,float);a=np.asarray(a,float)
    return (
        float(np.quantile(b,qlo)-np.quantile(a,qhi)),
        float(np.quantile(b,qhi)-np.quantile(a,qlo))
    )

def direct_interval(x):
    return float(np.quantile(x,0.025)),float(np.quantile(x,0.975))

def beyond_margin(lo,hi,margin):
    return bool(lo>margin or hi < -margin)

def inside_margin(lo,hi,margin):
    return bool(lo>=-margin and hi<=margin)

def same_nonzero_sign(values):
    s=np.sign(np.asarray(values,float))
    return bool(np.all(s!=0) and np.all(s==s[0]))

def coordinate_class(bf_lo,bf_hi,int_lo,int_hi,margin,sign_preserved):
    stable=inside_margin(bf_lo,bf_hi,margin) and inside_margin(int_lo,int_hi,margin) and sign_preserved
    footprint=beyond_margin(bf_lo,bf_hi,margin)
    survey=beyond_margin(int_lo,int_hi,margin)
    conflict=footprint and survey
    if conflict:return "INDETERMINATE",stable,footprint,survey,conflict
    if footprint:return "FOOTPRINT_SENSITIVE",stable,footprint,survey,conflict
    if survey:return "SURVEY_SENSITIVE",stable,footprint,survey,conflict
    if stable:return "TRANSPORT_STABLE",stable,footprint,survey,conflict
    return "INDETERMINATE",stable,footprint,survey,conflict

def overall_class(coord_rows):
    any_foot=any(r["footprint_sensitive_flag"] for r in coord_rows)
    any_survey=any(r["survey_sensitive_flag"] for r in coord_rows)
    if any_foot and any_survey:return "INDETERMINATE"
    if any_foot:return "FOOTPRINT_SENSITIVE"
    if any_survey:return "SURVEY_SENSITIVE"
    if all(r["coordinate_classification"]=="TRANSPORT_STABLE" for r in coord_rows):
        return "TRANSPORT_STABLE"
    return "INDETERMINATE"

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage6d4c_config.json").read_text())
    out=root/c["output_dir"]
    if out.exists():shutil.rmtree(out)
    for d in ["validation","tables","freeze","summaries","reports","manifest"]:(out/d).mkdir(parents=True,exist_ok=True)

    v=json.loads((root/c["d4b_validation"]).read_text())
    prereq=bool(v.get("STAGE6D4B_PRODUCTION_FITS_READY") and v.get("STAGE6D4C_PRACTICAL_EQUIVALENCE_CLASSIFICATION_READY"))
    d3a=json.loads((root/c["d3a_protocol"]).read_text())
    d3a_sha=hashlib.sha256(canonical_bytes(d3a)).hexdigest()
    pe=d3a["gradient_models"]["practical_equivalence"]
    protocol_ready=bool(
        d3a_sha==c["expected_d3a_sha256"]
        and pe["radial_margin_rule"]=="max(0.005 dex/kpc, 0.25*abs(full_support_beta_R))"
        and pe["vertical_margin_rule"]=="max(0.030 dex/kpc, 0.25*abs(full_support_beta_Z))"
        and float(pe["confidence_level"])==0.95
        and set(pe["classification"])==set(c["classification_ids"])
    )

    est=pd.read_csv(root/c["d4b_estimates"])
    draws=rt(root/c["d4b_draws"])
    models={"FULL_SUPPORT_FROZEN","COMMON_FOOTPRINT_POOLED","COMMON_FOOTPRINT_BALANCED","COMMON_FOOTPRINT_INTERACTION"}
    schema_ready=bool(
        set(c["primary_labels"])<=set(est["label"].unique())
        and models<=set(est["model_id"].unique())
        and set(c["primary_labels"])<=set(draws["label"].unique())
        and models<=set(draws["model_id"].unique())
    )
    if not schema_ready:raise RuntimeError("D4B estimate/draw model schema incomplete")

    comp_rows=[];coord_rows=[];label_rows=[]

    for label in c["primary_labels"]:
        full=model_row(est,label,"FULL_SUPPORT_FROZEN")
        pooled=model_row(est,label,"COMMON_FOOTPRINT_POOLED")
        balanced=model_row(est,label,"COMMON_FOOTPRINT_BALANCED")
        inter=model_row(est,label,"COMMON_FOOTPRINT_INTERACTION")
        per_label=[]

        for coord,spec in c["coordinates"].items():
            slope=spec["slope_column"];delta=spec["interaction_delta_column"];galslope=spec["galah_slope_column"]
            full_point=float(full[slope]);pool_point=float(pooled[slope]);bal_point=float(balanced[slope])
            apogee_point=float(inter[slope]);galah_point=float(inter[galslope]);delta_point=float(inter[delta])
            margin=max(float(spec["margin_floor"]),float(c["relative_margin_fraction"])*abs(full_point))

            full_d=draw_array(draws,label,"FULL_SUPPORT_FROZEN",slope)
            pool_d=draw_array(draws,label,"COMMON_FOOTPRINT_POOLED",slope)
            bal_d=draw_array(draws,label,"COMMON_FOOTPRINT_BALANCED",slope)
            delta_d=draw_array(draws,label,"COMMON_FOOTPRINT_INTERACTION",delta)

            fp_lo,fp_hi=conservative_difference_interval(pool_d,full_d)
            pb_lo,pb_hi=conservative_difference_interval(bal_d,pool_d)
            bf_lo,bf_hi=conservative_difference_interval(bal_d,full_d)
            in_lo,in_hi=direct_interval(delta_d)

            for cid,a_name,b_name,point,lo,hi in [
                ("FULL_TO_POOLED","FULL_SUPPORT_FROZEN","COMMON_FOOTPRINT_POOLED",pool_point-full_point,fp_lo,fp_hi),
                ("POOLED_TO_BALANCED","COMMON_FOOTPRINT_POOLED","COMMON_FOOTPRINT_BALANCED",bal_point-pool_point,pb_lo,pb_hi),
                ("FULL_TO_BALANCED","FULL_SUPPORT_FROZEN","COMMON_FOOTPRINT_BALANCED",bal_point-full_point,bf_lo,bf_hi),
                ("SURVEY_INTERACTION_DELTA","APOGEE_NATIVE","GALAH_CORRECTED",delta_point,in_lo,in_hi)
            ]:
                comp_rows.append({
                    "label":label,"coordinate":coord,"comparison_id":cid,
                    "reference":a_name,"comparison":b_name,
                    "point_difference":point,"interval_low":lo,"interval_high":hi,
                    "practical_margin":margin,
                    "interval_excludes_zero":bool(lo>0 or hi<0),
                    "interval_inside_practical_margin":inside_margin(lo,hi,margin),
                    "interval_beyond_practical_margin":beyond_margin(lo,hi,margin),
                    "interval_method":("direct_4096_interaction_draw_quantiles" if cid=="SURVEY_INTERACTION_DELTA" else "bonferroni_dependence_robust_marginal_difference")
                })

            sign_preserved=same_nonzero_sign([full_point,bal_point,apogee_point,galah_point])
            cls,stable,foot,survey,conflict=coordinate_class(
                bf_lo,bf_hi,in_lo,in_hi,margin,sign_preserved
            )
            rr={
                "label":label,"coordinate":coord,
                "full_support_slope":full_point,
                "pooled_slope":pool_point,
                "balanced_slope":bal_point,
                "interaction_APOGEE_slope":apogee_point,
                "interaction_GALAH_slope":galah_point,
                "survey_interaction_delta":delta_point,
                "practical_margin":margin,
                "balanced_minus_full_low":bf_lo,
                "balanced_minus_full_high":bf_hi,
                "survey_interaction_low":in_lo,
                "survey_interaction_high":in_hi,
                "sign_preserved":sign_preserved,
                "transport_stable_flag":stable,
                "footprint_sensitive_flag":foot,
                "survey_sensitive_flag":survey,
                "sensitivity_conflict_flag":conflict,
                "coordinate_classification":cls
            }
            coord_rows.append(rr);per_label.append(rr)

        overall=overall_class(per_label)
        label_rows.append({
            "label":label,
            "radial_classification":next(x["coordinate_classification"] for x in per_label if x["coordinate"]=="R"),
            "vertical_classification":next(x["coordinate_classification"] for x in per_label if x["coordinate"]=="Z"),
            "overall_classification":overall,
            "any_footprint_sensitive":any(x["footprint_sensitive_flag"] for x in per_label),
            "any_survey_sensitive":any(x["survey_sensitive_flag"] for x in per_label),
            "all_coordinates_transport_stable":all(x["coordinate_classification"]=="TRANSPORT_STABLE" for x in per_label),
            "classification_claim_safe":True
        })

    comp=pd.DataFrame(comp_rows);coord=pd.DataFrame(coord_rows);lab=pd.DataFrame(label_rows)
    comp.to_csv(out/"tables/gradient_required_comparisons.csv",index=False)
    coord.to_csv(out/"tables/gradient_transport_coordinate_classification.csv",index=False)
    lab.to_csv(out/"tables/gradient_transport_classification.csv",index=False)

    ledger=[]
    for _,r in lab.iterrows():
        cls=r["overall_classification"]
        if cls=="TRANSPORT_STABLE":
            claim="Within the tested shared support, balanced gradients and APOGEE-GALAH interaction slopes are practically equivalent to the frozen full-support slopes with preserved sign."
        elif cls=="FOOTPRINT_SENSITIVE":
            claim="At least one gradient coordinate shows a balanced-minus-full contrast beyond the frozen practical-equivalence margin; interpret as footprint sensitivity within tested shared support."
        elif cls=="SURVEY_SENSITIVE":
            claim="At least one gradient coordinate shows an APOGEE-GALAH interaction contrast beyond the frozen practical-equivalence margin within the balanced common footprint."
        else:
            claim="The frozen practical-equivalence rules do not support a unique stable/footprint-sensitive/survey-sensitive classification."
        ledger.append({
            "label":r["label"],"classification":cls,"allowed_claim":claim,
            "forbidden_claims":"volume-complete Milky Way gradient | independent GALAH replication | target-abundance matching | causal footprint effect | general five-label predictive law | component-resolved gradients"
        })
    pd.DataFrame(ledger).to_csv(out/"tables/footprint_claim_ledger.csv",index=False)

    closure={
        "stage":"Stage-6D4C frozen practical-equivalence implementation closure",
        "d3a_protocol_sha256":d3a_sha,
        "frozen_rules":pe,
        "cross_model_contrast_interval":c["contrast_interval_closure"],
        "sign_preservation_rule":"sign(full_support point) = sign(balanced point) = sign(interaction APOGEE slope) = sign(interaction GALAH slope), all non-zero",
        "coordinate_classification_rule":{
            "TRANSPORT_STABLE":"balanced-minus-full conservative 95% interval inside +/- margin AND direct interaction-delta 95% interval inside +/- margin AND sign preserved",
            "FOOTPRINT_SENSITIVE":"balanced-minus-full conservative 95% interval lies wholly beyond +/- margin, provided no simultaneous survey-sensitive conflict",
            "SURVEY_SENSITIVE":"direct interaction-delta 95% interval lies wholly beyond +/- margin, provided no simultaneous footprint-sensitive conflict",
            "INDETERMINATE":"all other cases, including simultaneous footprint and survey sensitivity"
        },
        "label_rollup_rule":{
            "TRANSPORT_STABLE":"both R and Z are TRANSPORT_STABLE",
            "FOOTPRINT_SENSITIVE":"one or both coordinates footprint-sensitive and no coordinate survey-sensitive",
            "SURVEY_SENSITIVE":"one or both coordinates survey-sensitive and no coordinate footprint-sensitive",
            "INDETERMINATE":"all other cases, including mixed mechanism classifications"
        },
        "outcome_blind_method_choice":True
    }
    wj(out/"freeze/stage6d4c_classification_contract.json",closure)
    closure_sha=hashlib.sha256(canonical_bytes(closure)).hexdigest()

    expected_rows=len(c["primary_labels"])*2*4
    comparison_ready=bool(len(comp)==expected_rows and not comp.isna().any().any())
    coord_ready=bool(len(coord)==len(c["primary_labels"])*2 and set(coord["coordinate_classification"])<=set(c["classification_ids"]))
    label_ready=bool(len(lab)==len(c["primary_labels"]) and set(lab["overall_classification"])<=set(c["classification_ids"]))

    counts=lab["overall_classification"].value_counts().to_dict()
    ready=bool(prereq and protocol_ready and schema_ready and comparison_ready and coord_ready and label_ready)

    val={
        "stage":c["stage"],"protocol_version":c["protocol_version"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
        "d3a_protocol_canonical_sha256":d3a_sha,
        "classification_contract_canonical_sha256":closure_sha,
        "D4B_PRODUCTION_PREREQUISITE_READY":prereq,
        "D3A_PRACTICAL_EQUIVALENCE_PROTOCOL_IDENTITY_READY":protocol_ready,
        "D4B_ESTIMATE_DRAW_SCHEMA_READY":schema_ready,
        "ALL_REQUIRED_COMPARISONS_READY":comparison_ready,
        "DEPENDENCE_ROBUST_CONTRAST_INTERVAL_CLOSURE_READY":True,
        "NO_CROSS_MODEL_INDEPENDENCE_ASSUMPTION_USED":True,
        "RADIAL_MARGIN_RULE_FROZEN_READY":True,
        "VERTICAL_MARGIN_RULE_FROZEN_READY":True,
        "SIGN_PRESERVATION_RULE_READY":True,
        "ALL_COORDINATE_CLASSIFICATIONS_READY":coord_ready,
        "ALL_FIVE_LABEL_CLASSIFICATIONS_READY":label_ready,
        "classification_counts":counts,
        "CLAIM_BOUNDARIES_PRESERVED":True,
        "NO_NEW_OUTCOME_DEPENDENT_THRESHOLD":True,
        "STAGE6D4C_CLASSIFICATION_READY":ready,
        "STAGE6D4_SCIENCE_CLOSURE_READY":ready,
        "STAGE6D5_MANUSCRIPT_INTEGRATION_READY":ready
    }
    wj(out/"validation/stage6d4c_validation.json",val)
    wj(out/"summaries/stage6d4c_summary.json",{
        "ready":ready,
        "classification_counts":counts,
        "label_classifications":lab[["label","overall_classification"]].to_dict("records"),
        "next_action":"Integrate D4 common-footprint robustness results into manuscript/claim ledger and archive release." if ready else "Inspect D4C classification gates before any manuscript claim."
    })
    (out/"reports/stage6d4c_report.md").write_text(
        "# Stage-6D4C practical-equivalence classification\n\n"+
        f"Science closure ready: `{ready}`\n\n"+
        lab.to_markdown(index=False)+"\n",encoding="utf-8"
    )

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and "manifest" not in p.parts:
            manifest.append({"path":str(p.relative_to(root)).replace("\\","/"),"size_bytes":p.stat().st_size,"sha256":sha_file(p)})
    pd.DataFrame(manifest).to_csv(out/"manifest/stage6d4c_output_manifest_sha256.csv",index=False)

    print(json.dumps({"validation":val,"classifications":lab.to_dict("records")},indent=2,ensure_ascii=False))
    return 0
if __name__=="__main__":raise SystemExit(main())
