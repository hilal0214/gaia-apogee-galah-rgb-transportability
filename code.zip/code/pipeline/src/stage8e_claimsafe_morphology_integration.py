from __future__ import annotations
import argparse,json,hashlib,math
from datetime import datetime,timezone
from pathlib import Path
import numpy as np,pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def canon(o): return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def max_adjacent_true(flags):
    best=cur=0
    for x in flags:
        cur=cur+1 if bool(x) else 0
        best=max(best,cur)
    return best

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage8e_config.json").read_text())
    p=json.loads((root/"protocol/stage8e_protocol.json").read_text())

    v=json.loads((root/c["parent_validation"]).read_text())
    parent=bool(
      v.get("STAGE8D_PRODUCTION_INFERENCE_COMPLETE") is True and
      v.get("STAGE8E_CLAIM_SAFE_INTEGRATION_READY") is True and
      v.get("POST_REAL_FIT_GATE_CHANGES_PERFORMED") is False and
      v.get("OVERALL_CLASSIFICATION")=="INDETERMINATE"
    )
    if not parent: raise RuntimeError("Stage-8D parent guards failed")

    ci=pd.read_csv(root/c["intervals"])
    pt=pd.read_csv(root/c["points"])
    el=pd.read_csv(root/c["eligibility"])
    cl=pd.read_csv(root/c["classification"])

    ci["zero_excluded"]=(ci["ci_low"]>0)|(ci["ci_high"]<0)
    ci["inside_practical_margin"]=(ci["ci_low"]>-ci["margin"])&(ci["ci_high"]<ci["margin"])
    ci["beyond_positive_margin"]=ci["ci_low"]>ci["margin"]
    ci["beyond_negative_margin"]=ci["ci_high"]<-ci["margin"]
    ci["ci_width"]=ci["ci_high"]-ci["ci_low"]
    ci["point_over_margin"]=ci["point_difference"]/ci["margin"]
    ci["ci_width_over_margin"]=ci["ci_width"]/ci["margin"]

    # Frozen-classification consistency: all estimands must remain as Stage-8D reported.
    expected={r["estimand"]:r["classification"] for _,r in cl.iterrows()}
    if expected!={"valley":"INDETERMINATE","separation":"INDETERMINATE","fraction":"INDETERMINATE"}:
        raise RuntimeError(f"unexpected parent classification: {expected}")

    zero_summary=[]
    for e in ["valley","separation","fraction"]:
        q=ci[ci["estimand"]==e].sort_values("feh_knot")
        flags=q["zero_excluded"].tolist()
        neg=((q["ci_high"]<0)).tolist()
        pos=((q["ci_low"]>0)).tolist()
        zero_summary.append({
          "estimand":e,
          "zero_excluding_knots":int(q["zero_excluded"].sum()),
          "max_adjacent_zero_excluding_run":int(max(max_adjacent_true(neg),max_adjacent_true(pos))),
          "practical_equivalence_knots":int(q["inside_practical_margin"].sum()),
          "practical_sensitive_knots":int((q["beyond_positive_margin"]|q["beyond_negative_margin"]).sum())
        })
    zs=pd.DataFrame(zero_summary)

    # Existing point fits only: descriptive resolution ratio, never classification.
    surveys=pt[pt["survey"].isin(["APOGEE_NATIVE","GALAH_CORRECTED"])].copy()
    surveys["component_resolution_ratio"]=surveys["separation"]/np.sqrt(
        (np.square(surveys["sigma_low"])+np.square(surveys["sigma_high"]))/2.0
    )
    surveys["resolution_diagnostic_only"]=True

    # Eligibility summary.
    elig_summary=(el.groupby("survey",as_index=False)
                    .agg(min_eligibility_fraction=("eligibility_fraction","min"),
                         median_eligibility_fraction=("eligibility_fraction","median"),
                         min_weighted_ess=("weighted_ess","min"),
                         min_cells=("nside16_cells","min")))

    # Strongly supported statistical pattern (not frozen survey-sensitive classification).
    sep=ci[ci["estimand"]=="separation"].sort_values("feh_knot")
    sep_first4=sep[sep["feh_knot"].isin([-0.6,-0.4,-0.2,0.0])]
    separation_coherent_zero_exclusion=bool(
        len(sep_first4)==4 and (sep_first4["ci_high"]<0).all()
    )
    valley0=ci[(ci["estimand"]=="valley")&(ci["feh_knot"]==0.0)].iloc[0]
    valley0_zero_excluded=bool(valley0["ci_high"]<0)

    # Human-readable claim-safe outputs.
    sep_rows=[]
    for _,r in sep_first4.iterrows():
        sep_rows.append(
            f"[Fe/H]={r['feh_knot']:+.1f}: Δsep={r['point_difference']:+.4f} dex "
            f"(95% CI {r['ci_low']:+.4f} to {r['ci_high']:+.4f})"
        )
    results_text = f"""Stage-8E claim-safe morphology summary

Frozen overall classification: INDETERMINATE.

Sequence separation:
GALAH-minus-APOGEE sequence separation is negative with a 95% paired-cell bootstrap interval excluding zero at four adjacent metallicity knots from [Fe/H]=-0.6 through 0.0:
- """ + "\n- ".join(sep_rows) + f"""

This is evidence for a coherent survey-scale difference in fitted sequence separation on the homogenized alpha3 scale. It is not, however, a frozen SURVEY_SENSITIVE classification, because the 95% intervals do not lie entirely beyond the pre-specified ±0.04 dex practical margin at three adjacent knots.

Valley location:
At [Fe/H]=0.0, Δvalley={valley0['point_difference']:+.4f} dex (95% CI {valley0['ci_low']:+.4f} to {valley0['ci_high']:+.4f}); the interval excludes zero but does not lie entirely beyond the -0.03 dex practical margin. Other valley knots do not exclude zero.

High-alpha fraction:
No primary knot has a 95% interval excluding zero. The bootstrap intervals are broad, so neither practical equivalence nor survey sensitivity is established.

Interpretation:
The data do not establish practical transport equivalence for any of the three morphology estimands. They also do not meet the frozen criterion for a coherent practically large survey-sensitive distortion. Therefore the correct overall label remains INDETERMINATE, not non-transportable.

Eligibility:
Alpha3-primary eligibility is nearly complete in both surveys over the frozen six-knot domain, so the classification is not driven by substantial alpha3 missingness.

Post-hoc descriptive component-resolution ratios are supplied only as diagnostics of mixture overlap; they do not enter or alter the frozen Stage-8D classification.
"""

    manuscript_tex=r"""\paragraph{Alpha-sequence morphology transport audit.}
We tested whether the low-$\alpha$/high-$\alpha$ morphology measured on the frozen homogenized
$\alpha_3$ scale is practically transport-stable between APOGEE and GALAH within the balanced
common-support sample.  The pre-specified paired-NSIDE16 bootstrap classification was
\emph{indeterminate} for valley location, sequence separation, and high-$\alpha$ mixture fraction.
The strongest structured difference was in sequence separation: the GALAH-minus-APOGEE
difference was negative and its 95\% bootstrap interval excluded zero at four adjacent metallicity
knots from $[\mathrm{Fe/H}]=-0.6$ through $0.0$.  However, the intervals did not remain wholly beyond
the pre-specified 0.04-dex practical margin at three adjacent knots, so this pattern does not satisfy
our frozen survey-sensitive criterion.  The valley location showed a localized negative offset at
$[\mathrm{Fe/H}]=0.0$, whereas high-$\alpha$ fraction differences were uncertainty dominated.
Accordingly, these results neither establish practical transport equivalence nor demonstrate a
coherent practically large survey-dependent distortion.  The low-support $[\mathrm{Fe/H}]=-0.8$
knot was retained as audit-only and was not used in the primary classification.
"""

    out=root/c["output_dir"]
    for d in ["tables","validation","text","freeze"]: (out/d).mkdir(parents=True,exist_ok=True)
    ci.to_csv(out/"tables/stage8e_claimsafe_interval_audit.csv",index=False)
    zs.to_csv(out/"tables/stage8e_zero_vs_practical_summary.csv",index=False)
    surveys.to_csv(out/"tables/stage8e_component_resolution_diagnostic.csv",index=False)
    elig_summary.to_csv(out/"tables/stage8e_eligibility_summary.csv",index=False)
    (out/"text/stage8e_claimsafe_results.txt").write_text(results_text,encoding="utf-8")
    (out/"text/stage8e_manuscript_snippet.tex").write_text(manuscript_tex,encoding="utf-8")
    (out/"freeze/stage8e_protocol_frozen.json").write_text(
        (root/"protocol/stage8e_protocol.json").read_text(),encoding="utf-8")

    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "STAGE8D_PARENT_READY":parent,
      "FROZEN_OVERALL_CLASSIFICATION":"INDETERMINATE",
      "VALLEY_ZERO_EXCLUDING_KNOTS":int(zs.loc[zs.estimand=="valley","zero_excluding_knots"].iloc[0]),
      "SEPARATION_ZERO_EXCLUDING_KNOTS":int(zs.loc[zs.estimand=="separation","zero_excluding_knots"].iloc[0]),
      "FRACTION_ZERO_EXCLUDING_KNOTS":int(zs.loc[zs.estimand=="fraction","zero_excluding_knots"].iloc[0]),
      "SEPARATION_FOUR_ADJACENT_NEGATIVE_ZERO_EXCLUSION_READY":separation_coherent_zero_exclusion,
      "VALLEY_ZERO_EXCLUSION_AT_FEH_0P0_READY":valley0_zero_excluded,
      "ANY_PRIMARY_KNOT_PRACTICAL_EQUIVALENCE_READY":bool(ci["inside_practical_margin"].any()),
      "ANY_PRIMARY_KNOT_ENTIRELY_BEYOND_PRACTICAL_MARGIN":bool((ci["beyond_positive_margin"]|ci["beyond_negative_margin"]).any()),
      "POSTHOC_RESOLUTION_DIAGNOSTIC_ONLY":True,
      "REAL_MIXTURE_REFIT_PERFORMED":False,
      "PRACTICAL_MARGINS_CHANGED":False,
      "FROZEN_CLASSIFICATION_CHANGED":False,
      "CLAIM_SAFE_TEXT_READY":True,
      "MANUSCRIPT_SNIPPET_READY":True,
      "STAGE8E_CLAIM_SAFE_INTEGRATION_COMPLETE":True,
      "PROTOCOL_CANONICAL_SHA256":canon(p)
    }
    write_json(out/"validation/stage8e_validation.json",val)
    print(json.dumps(val,indent=2,ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
