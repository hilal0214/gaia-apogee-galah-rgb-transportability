from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace('\\', '/')
    except Exception:
        return str(path).replace('\\', '/')


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str) + '\n', encoding='utf-8')


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def read_table(path: Path, columns: list[str] | None = None) -> pd.DataFrame:
    if path.suffix.lower() == '.parquet':
        return pd.read_parquet(path, columns=columns)
    return pd.read_csv(path, usecols=columns)


def read_columns(path: Path) -> list[str]:
    if path.suffix.lower() == '.parquet':
        import pyarrow.parquet as pq
        return list(pq.ParquetFile(path).schema_arrow.names)
    return list(pd.read_csv(path, nrows=5).columns)


def find_alias(columns: list[str], options: list[str]) -> str | None:
    lookup = {column.lower(): column for column in columns}
    for option in options:
        if option.lower() in lookup:
            return lookup[option.lower()]
    return None


def find_pairs(columns: list[str], cfg: dict[str, Any]) -> dict[str, dict[str, str]]:
    lookup = {column.lower(): column for column in columns}
    pairs: dict[str, dict[str, str]] = {}
    for label in cfg['labels']:
        row: dict[str, str] = {}
        for survey in ['apogee', 'galah']:
            for pattern in cfg['pair_patterns'][survey]:
                candidate = pattern.format(label=label).lower()
                if candidate in lookup:
                    row[survey] = lookup[candidate]
                    break
        if set(row) == {'apogee', 'galah'}:
            pairs[label] = row
    return pairs


def robust_iqr(series: pd.Series) -> float:
    clean = pd.to_numeric(series, errors='coerce').dropna()
    if clean.empty:
        return float('nan')
    return float(clean.quantile(0.75) - clean.quantile(0.25))


def robust_width(series: pd.Series) -> float:
    value = robust_iqr(series)
    return value / 1.349 if math.isfinite(value) else float('nan')


def robust_mad(series: pd.Series) -> float:
    clean = pd.to_numeric(series, errors='coerce').dropna()
    if clean.empty:
        return float('nan')
    median = clean.median()
    return float((clean - median).abs().median())


def make_support_cells(frame: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    spec = cfg['support_cells']
    teff_bin = pd.cut(
        pd.to_numeric(frame['teff'], errors='coerce'),
        bins=spec['teff_edges'], labels=spec['teff_labels'], include_lowest=True
    )
    logg_bin = pd.cut(
        pd.to_numeric(frame['logg'], errors='coerce'),
        bins=spec['logg_edges'], labels=spec['logg_labels'], include_lowest=True
    )
    feh_bin = pd.cut(
        pd.to_numeric(frame['feh'], errors='coerce'),
        bins=spec['feh_edges'], labels=spec['feh_labels'], include_lowest=True
    )
    if 'snr' in frame.columns and pd.to_numeric(frame['snr'], errors='coerce').notna().any():
        snr = pd.to_numeric(frame['snr'], errors='coerce')
        threshold = float(snr.median())
        snr_bin = pd.Series(np.where(snr >= threshold, 'highsnr', 'lowsnr'), index=frame.index)
    else:
        snr_bin = pd.Series('snr_na', index=frame.index)
    return (
        teff_bin.astype('string').fillna('teff_na') + '__'
        + logg_bin.astype('string').fillna('logg_na') + '__'
        + feh_bin.astype('string').fillna('feh_na') + '__'
        + snr_bin.astype('string')
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-root', default='.')
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads((root / 'config/stage6d2a4_config.json').read_text(encoding='utf-8'))
    out = root / cfg['output_dir']
    if out.exists():
        shutil.rmtree(out)
    for directory in ['validation', 'summaries', 'tables', 'panel', 'reports']:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg['prerequisite_validation']
    prereq = json.loads(prereq_path.read_text(encoding='utf-8')) if prereq_path.exists() else {}
    prereq_ready = bool(
        prereq.get('STAGE6D2A4_PILOT_RECONSTRUCTION_READY', False)
        and prereq.get('PREDICTIVE_LAW_CLAIM_FORBIDDEN', False)
        and prereq.get('UNIQUE_COEFFICIENT_LINEAGE_READY', False)
    )
    selected_lineage = prereq.get('selected_coefficient_lineage', {})
    lineage_identity = bool(
        selected_lineage.get('analysis_set') == cfg['selected_analysis_set']
        and selected_lineage.get('model_role') == cfg['selected_model_role']
    )

    fold_path = root / cfg['fold_assignments_file']
    coefficient_path = root / cfg['coefficients_file']
    overlap_path = root / cfg['overlap_file']
    missing_files = [str(path) for path in [fold_path, coefficient_path, overlap_path] if not path.exists()]
    if missing_files:
        raise FileNotFoundError('Missing required frozen products: ' + '; '.join(missing_files))

    aliases = cfg['aliases']
    fold_columns = read_columns(fold_path)
    fold_source = find_alias(fold_columns, aliases['source_id'])
    fold_column = find_alias(fold_columns, aliases['fold'])
    if not fold_source or not fold_column:
        raise RuntimeError('Fold assignment schema is incomplete.')
    folds = read_table(fold_path, [fold_source, fold_column]).rename(columns={fold_source: 'source_id', fold_column: 'fold'})
    folds['source_id'] = pd.to_numeric(folds['source_id'], errors='raise').astype('uint64')
    folds['fold'] = pd.to_numeric(folds['fold'], errors='raise').astype(int)
    fold_unique = not folds['source_id'].duplicated().any()
    expected_fold_set = set(cfg['expected_folds'])
    fold_set_ready = set(folds['fold'].unique()) == expected_fold_set

    coefficient_columns = read_columns(coefficient_path)
    coefficient_mapping = {key: find_alias(coefficient_columns, aliases[key]) for key in ['label', 'fold', 'analysis_set', 'model_role', 'intercept', 'a_t', 'a_g', 'a_fe']}
    if not all(coefficient_mapping.values()):
        raise RuntimeError('Coefficient schema is incomplete: ' + json.dumps(coefficient_mapping, sort_keys=True))
    coefficients = read_table(coefficient_path).rename(columns={source: target for target, source in coefficient_mapping.items() if source})
    coefficients['label'] = coefficients['label'].astype(str).str.lower()
    coefficients['fold'] = pd.to_numeric(coefficients['fold'], errors='coerce')
    coefficients = coefficients[
        coefficients['label'].isin(cfg['labels'])
        & coefficients['fold'].isin(cfg['expected_folds'])
        & (coefficients['analysis_set'].astype(str).str.lower() == cfg['selected_analysis_set'].lower())
        & (coefficients['model_role'].astype(str).str.lower() == cfg['selected_model_role'].lower())
    ].copy()
    coefficient_counts = coefficients.groupby(['label', 'fold']).size()
    coefficient_unique = bool(
        len(coefficient_counts) == len(cfg['labels']) * len(cfg['expected_folds'])
        and (coefficient_counts == 1).all()
    )

    coefficient_audit_rows = []
    for label in cfg['labels']:
        for fold in cfg['expected_folds']:
            count = int(coefficient_counts.get((label, fold), 0))
            coefficient_audit_rows.append({'label': label, 'fold': fold, 'row_count': count, 'passed': str(count == 1).lower()})
    write_csv(out / 'tables/stage6d2a4_coefficient_identity.csv', ['label', 'fold', 'row_count', 'passed'], coefficient_audit_rows)

    overlap_columns = read_columns(overlap_path)
    overlap_mapping = {key: find_alias(overlap_columns, aliases[key]) for key in ['source_id', 'teff', 'logg', 'feh', 'snr']}
    if not all(overlap_mapping[key] for key in ['source_id', 'teff', 'logg', 'feh']):
        raise RuntimeError('Overlap predictor schema is incomplete: ' + json.dumps(overlap_mapping, sort_keys=True))
    pairs = find_pairs(overlap_columns, cfg)
    paired_labels_ready = sorted(pairs) == sorted(cfg['labels'])

    needed = [overlap_mapping[key] for key in ['source_id', 'teff', 'logg', 'feh', 'snr'] if overlap_mapping.get(key)]
    for pair in pairs.values():
        needed.extend(pair.values())
    needed = sorted(set(needed))
    overlap_raw = read_table(overlap_path, needed)
    overlap = overlap_raw.copy()
    overlap['source_id'] = pd.to_numeric(overlap_raw[overlap_mapping['source_id']], errors='raise').astype('uint64')
    overlap['teff'] = pd.to_numeric(overlap_raw[overlap_mapping['teff']], errors='coerce')
    overlap['logg'] = pd.to_numeric(overlap_raw[overlap_mapping['logg']], errors='coerce')
    overlap['feh'] = pd.to_numeric(overlap_raw[overlap_mapping['feh']], errors='coerce')
    if overlap_mapping.get('snr'):
        overlap['snr'] = pd.to_numeric(overlap_raw[overlap_mapping['snr']], errors='coerce')
    overlap_unique = not overlap['source_id'].duplicated().any()

    merged = overlap.merge(folds, on='source_id', how='inner', validate='one_to_one')
    join_ready = bool(not merged.empty and len(merged) == len(overlap))
    merged['support_cell'] = make_support_cells(merged, cfg)

    equation = cfg['equation_contract']
    coefficient_lookup = {(str(row['label']).lower(), int(row['fold'])): row for _, row in coefficients.iterrows()}
    long_blocks = []
    aggregate_rows = []

    for label in cfg['labels']:
        if label not in pairs:
            continue
        apogee_all = pd.to_numeric(merged[pairs[label]['apogee']], errors='coerce')
        galah_all = pd.to_numeric(merged[pairs[label]['galah']], errors='coerce')
        finite_pair = apogee_all.notna() & galah_all.notna()
        for fold in cfg['expected_folds']:
            coefficient = coefficient_lookup.get((label, fold))
            if coefficient is None:
                continue
            heldout_mask = finite_pair & (merged['fold'] == fold)
            training_mask = finite_pair & (merged['fold'] != fold)
            if not heldout_mask.any():
                continue
            predicted_delta = (
                float(coefficient['intercept'])
                + float(coefficient['a_t']) * ((merged.loc[heldout_mask, 'teff'] - equation['teff_center_k']) / equation['teff_scale_k'])
                + float(coefficient['a_g']) * (merged.loc[heldout_mask, 'logg'] - equation['logg_center_dex'])
                + float(coefficient['a_fe']) * (merged.loc[heldout_mask, 'feh'] - equation['feh_center_dex'])
            )
            residual = (galah_all[heldout_mask] - apogee_all[heldout_mask]) - predicted_delta
            block = pd.DataFrame({
                'source_id': merged.loc[heldout_mask, 'source_id'].to_numpy(),
                'label': label,
                'fold': fold,
                'support_cell': merged.loc[heldout_mask, 'support_cell'].astype(str).to_numpy(),
                'apogee_value': apogee_all[heldout_mask].to_numpy(),
                'galah_value': galah_all[heldout_mask].to_numpy(),
                'predicted_delta': predicted_delta.to_numpy(),
                'heldout_residual': residual.to_numpy(),
                'teff': merged.loc[heldout_mask, 'teff'].to_numpy(),
                'logg': merged.loc[heldout_mask, 'logg'].to_numpy(),
                'feh': merged.loc[heldout_mask, 'feh'].to_numpy(),
            })
            if 'snr' in merged.columns:
                block['snr'] = merged.loc[heldout_mask, 'snr'].to_numpy()
            long_blocks.append(block)

            for cell, heldout_group in block.groupby('support_cell', dropna=False):
                train_cell_mask = training_mask & (merged['support_cell'].astype(str) == str(cell))
                training_group = merged.loc[train_cell_mask]
                n_heldout = len(heldout_group)
                n_training = len(training_group)
                residual_mad = robust_mad(heldout_group['heldout_residual'])
                denominator = robust_iqr(heldout_group['apogee_value'])
                q_value = residual_mad / denominator if math.isfinite(denominator) and denominator >= cfg['minimum_iqr'] else float('nan')
                width_teff = robust_width(training_group['teff'])
                width_logg = robust_width(training_group['logg'])
                width_feh = robust_width(training_group['feh'])
                b_t = abs(float(coefficient['a_t'])) * (width_teff / equation['teff_scale_k']) if math.isfinite(width_teff) else float('nan')
                b_g = abs(float(coefficient['a_g'])) * width_logg if math.isfinite(width_logg) else float('nan')
                b_fe = abs(float(coefficient['a_fe'])) * width_feh if math.isfinite(width_feh) else float('nan')
                b_atmos = math.sqrt(b_t*b_t + b_g*b_g + b_fe*b_fe) if all(math.isfinite(value) for value in [b_t, b_g, b_fe]) else float('nan')
                aggregate_rows.append({
                    'label': label,
                    'fold': fold,
                    'support_cell': str(cell),
                    'n_heldout': n_heldout,
                    'n_training_support': n_training,
                    'heldout_residual_mad': residual_mad,
                    'heldout_residual_median': float(pd.to_numeric(heldout_group['heldout_residual'], errors='coerce').median()),
                    'common_sample_iqr': denominator,
                    'Q_heldout': q_value,
                    'B_T': b_t,
                    'B_logg': b_g,
                    'B_feh': b_fe,
                    'B_atmos': b_atmos,
                    'valid_min_rows': n_heldout >= cfg['minimum_rows_per_label_fold_cell'],
                    'valid_iqr': math.isfinite(denominator) and denominator >= cfg['minimum_iqr'],
                    'valid_training_widths': all(math.isfinite(value) for value in [width_teff, width_logg, width_feh]),
                    'analysis_class': 'five_label_transport_validated_exploratory_pilot'
                })

    long_frame = pd.concat(long_blocks, ignore_index=True) if long_blocks else pd.DataFrame()
    panel = pd.DataFrame(aggregate_rows)

    long_csv = out / 'panel/stage6d2a4_oof_residual_rows.csv'
    panel_csv = out / 'panel/label_transportability_panel.csv'
    if not long_frame.empty:
        long_frame.to_csv(long_csv, index=False)
        try:
            long_frame.to_parquet(out / 'panel/stage6d2a4_oof_residual_rows.parquet', index=False)
        except Exception:
            pass
    if not panel.empty:
        panel.to_csv(panel_csv, index=False)
        try:
            panel.to_parquet(out / 'panel/label_transportability_panel.parquet', index=False)
        except Exception:
            pass

    coverage_rows = []
    for label in cfg['labels']:
        subset = panel[panel['label'] == label] if not panel.empty else pd.DataFrame()
        if subset.empty:
            valid = pd.DataFrame()
        else:
            valid = subset[
                subset['valid_min_rows'].astype(bool)
                & subset['valid_iqr'].astype(bool)
                & subset['valid_training_widths'].astype(bool)
                & pd.to_numeric(subset['Q_heldout'], errors='coerce').notna()
                & pd.to_numeric(subset['B_atmos'], errors='coerce').notna()
            ]
        coverage_rows.append({
            'label': label,
            'paired_columns_ready': str(label in pairs).lower(),
            'panel_rows': len(subset),
            'valid_panel_rows': len(valid),
            'valid_folds': int(valid['fold'].nunique()) if not valid.empty else 0,
            'ready': str(not valid.empty and int(valid['fold'].nunique()) == len(cfg['expected_folds'])).lower()
        })
    write_csv(out / 'tables/stage6d2a4_label_coverage.csv', ['label', 'paired_columns_ready', 'panel_rows', 'valid_panel_rows', 'valid_folds', 'ready'], coverage_rows)

    valid_labels = sum(row['ready'] == 'true' for row in coverage_rows)
    panel_ready = bool(not panel.empty and valid_labels == len(cfg['labels']))
    residual_ready = bool(not long_frame.empty and long_frame['label'].nunique() == len(cfg['labels']))
    b_ready = bool(not panel.empty and pd.to_numeric(panel['B_atmos'], errors='coerce').notna().any())

    claim_rows = [
        {'claim_id': 'D2A4-C1', 'status': 'ALLOWED_DESCRIPTIVE', 'claim': 'Leakage-free OOF residuals and Q_heldout were reconstructed for five transport-validated labels.'},
        {'claim_id': 'D2A4-C2', 'status': 'HYPOTHESIS_NOT_YET_TESTED', 'claim': 'Atmospheric-sensitivity burden is associated with held-out transport error.'},
        {'claim_id': 'D2A4-C3', 'status': 'FORBIDDEN', 'claim': 'A general predictive law of label transportability is established.'},
        {'claim_id': 'D2A4-C4', 'status': 'FORBIDDEN', 'claim': 'The original seven-of-nine success gate passed.'}
    ]
    write_csv(out / 'tables/stage6d2a4_claim_ledger.csv', ['claim_id', 'status', 'claim'], claim_rows)

    remaining = []
    if not prereq_ready:
        remaining.append({'gate': 'STAGE6D2A3_PREREQUISITE_READY', 'required_action': 'Restore a PASS Stage-6D2A3 validation.'})
    if not lineage_identity:
        remaining.append({'gate': 'COEFFICIENT_LINEAGE_IDENTITY_READY', 'required_action': 'Selected lineage does not match primary/crossfit_fold.'})
    if not coefficient_unique:
        remaining.append({'gate': 'COEFFICIENT_CELL_IDENTITY_READY', 'required_action': 'Each of 5 labels x 5 folds must have exactly one selected coefficient row.'})
    if not paired_labels_ready:
        remaining.append({'gate': 'PAIRED_LABEL_SCHEMA_READY', 'required_action': 'The overlap product must contain paired APOGEE/GALAH columns for all five labels.'})
    if not join_ready:
        remaining.append({'gate': 'FOLD_OVERLAP_JOIN_READY', 'required_action': 'Fold assignments must join one-to-one to the overlap product.'})
    if not panel_ready:
        remaining.append({'gate': 'FIVE_LABEL_Q_PANEL_READY', 'required_action': 'All five labels must retain valid support in all five folds.'})
    write_csv(out / 'tables/stage6d2a4_remaining_items.csv', ['gate', 'required_action'], remaining)

    pilot_ready = bool(
        prereq_ready and lineage_identity and fold_unique and fold_set_ready
        and coefficient_unique and overlap_unique and paired_labels_ready
        and join_ready and residual_ready and panel_ready and b_ready
    )
    validation = {
        'stage': cfg['stage'],
        'protocol_version': cfg['protocol_version'],
        'implementation_version': cfg['implementation_version'],
        'timestamp_utc': utc_now(),
        'project_root': str(root),
        'fold_assignments_file': safe_rel(fold_path, root),
        'fold_assignments_sha256': sha256_file(fold_path),
        'coefficients_file': safe_rel(coefficient_path, root),
        'coefficients_sha256': sha256_file(coefficient_path),
        'overlap_file': safe_rel(overlap_path, root),
        'overlap_sha256': sha256_file(overlap_path),
        'selected_analysis_set': cfg['selected_analysis_set'],
        'selected_model_role': cfg['selected_model_role'],
        'equation_contract': equation,
        'paired_labels': sorted(pairs),
        'joined_rows': len(merged),
        'oof_residual_rows': len(long_frame),
        'panel_rows': len(panel),
        'valid_labels': valid_labels,
        'prior_stage_outputs_modified': False,
        'STAGE6D2A3_PREREQUISITE_READY': prereq_ready,
        'COEFFICIENT_LINEAGE_IDENTITY_READY': lineage_identity,
        'FOLD_ASSIGNMENT_IDENTITY_READY': fold_unique and fold_set_ready,
        'COEFFICIENT_CELL_IDENTITY_READY': coefficient_unique,
        'PAIRED_LABEL_SCHEMA_READY': paired_labels_ready,
        'FOLD_OVERLAP_JOIN_READY': join_ready,
        'OOF_RESIDUAL_ROWS_READY': residual_ready,
        'Q_HELDOUT_PANEL_READY': panel_ready,
        'B_ATMOS_PANEL_READY': b_ready,
        'FIVE_LABEL_PILOT_RECONSTRUCTION_READY': pilot_ready,
        'PREDICTIVE_LAW_CLAIM_FORBIDDEN': True,
        'STAGE6D2B_PREDICTIVE_LAW_READY': False
    }
    write_json(out / 'validation/stage6d2a4_validation.json', validation)

    summary = {
        'stage': cfg['stage'],
        'timestamp_utc': utc_now(),
        'label_coverage': coverage_rows,
        'remaining_items': remaining,
        'scientific_disposition': (
            'Five-label leakage-free OOF residuals, Q_heldout, and B_atmos are reconstructed. Descriptive pilot diagnostics are authorized; predictive-law claims remain forbidden.'
            if pilot_ready else
            'Five-label reconstruction remains incomplete; do not run association diagnostics.'
        )
    }
    write_json(out / 'summaries/stage6d2a4_summary.json', summary)

    report = [
        '# Stage-6D2A4 five-label OOF pilot reconstruction', '',
        f'- Prerequisite ready: `{prereq_ready}`',
        f'- Lineage identity: `{lineage_identity}`',
        f'- Joined overlap rows: `{len(merged)}`',
        f'- OOF residual rows: `{len(long_frame)}`',
        f'- Panel rows: `{len(panel)}`',
        f'- Valid labels: `{valid_labels}/5`',
        f'- Pilot reconstruction ready: `{pilot_ready}`', '',
        'This stage does not estimate a general predictive law. The original seven-of-nine gate remains not testable.', ''
    ]
    (out / 'reports/stage6d2a4_five_label_oof_reconstruction.md').write_text('\n'.join(report), encoding='utf-8')

    print(json.dumps({'validation': validation, 'summary': summary}, indent=2, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
