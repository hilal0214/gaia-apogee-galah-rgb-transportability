from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def now():
    return datetime.now(timezone.utc).isoformat()


def norm(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def sha256_file(path: Path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def resolve(path: Path):
    for candidate in [path, path.with_suffix(".csv"), path.with_suffix(".feather")]:
        if candidate.exists():
            return candidate
    return None


def read_table(path: Path):
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower() == ".feather":
        return pd.read_feather(path)
    return pd.read_csv(path)


def find_alias(columns, aliases):
    lookup = {norm(c): c for c in columns}
    for alias in aliases:
        if norm(alias) in lookup:
            return lookup[norm(alias)]
    return None


def icrs_to_galactic(ra_deg: np.ndarray, dec_deg: np.ndarray):
    ra = np.deg2rad(ra_deg.astype(float))
    dec = np.deg2rad(dec_deg.astype(float))
    cosd = np.cos(dec)
    vec = np.vstack([
        cosd * np.cos(ra),
        cosd * np.sin(ra),
        np.sin(dec),
    ])
    rot = np.array([
        [-0.0548755604162154, -0.8734370902348850, -0.4838350155487132],
        [ 0.4941094278755837, -0.4448296299600112,  0.7469822444972189],
        [-0.8676661490190047, -0.1980763734312015,  0.4559837761750669],
    ])
    gal = rot @ vec
    l = np.rad2deg(np.arctan2(gal[1], gal[0])) % 360.0
    b = np.rad2deg(np.arcsin(np.clip(gal[2], -1.0, 1.0)))
    return l, b


def healpix_ang2pix_ring(nside: int, lon_deg, lat_deg):
    """
    Pure NumPy HEALPix RING ang2pix implementation.
    Input longitude/latitude are degrees in the requested frame.
    Returns zero-based pixel numbers in [0, 12*nside^2).
    """
    if nside < 1:
        raise ValueError("nside must be >= 1")
    lon = np.asarray(lon_deg, dtype=float)
    lat = np.asarray(lat_deg, dtype=float)
    phi = np.deg2rad(lon % 360.0)
    z = np.sin(np.deg2rad(lat))
    za = np.abs(z)
    tt = phi / (0.5 * np.pi)

    npix = 12 * nside * nside
    ncap = 2 * nside * (nside - 1)
    pix = np.full(lon.shape, -1, dtype=np.int64)
    finite = np.isfinite(lon) & np.isfinite(lat) & (lat >= -90.0) & (lat <= 90.0)

    eq = finite & (za <= (2.0 / 3.0))
    if np.any(eq):
        temp1 = nside * (0.5 + tt[eq])
        temp2 = nside * (0.75 * z[eq])
        jp = np.floor(temp1 - temp2).astype(np.int64)
        jm = np.floor(temp1 + temp2).astype(np.int64)
        ir = nside + 1 + jp - jm
        kshift = 1 - (ir & 1)
        ip = ((jp + jm - nside + kshift + 1) // 2) + 1
        ip = ((ip - 1) % (4 * nside)) + 1
        pix[eq] = ncap + (ir - 1) * (4 * nside) + ip - 1

    pol = finite & ~eq
    if np.any(pol):
        tt_pol = tt[pol]
        za_pol = za[pol]
        z_pol = z[pol]
        tp = tt_pol - np.floor(tt_pol)
        tmp = nside * np.sqrt(3.0 * (1.0 - za_pol))
        jp = np.floor(tp * tmp).astype(np.int64)
        jm = np.floor((1.0 - tp) * tmp).astype(np.int64)
        ir = jp + jm + 1
        ip = (np.floor(tt_pol).astype(np.int64) * ir) + jp + 1
        north = z_pol > 0
        p = np.empty_like(ir)
        p[north] = 2 * ir[north] * (ir[north] - 1) + ip[north] - 1
        p[~north] = (
            npix
            - 2 * ir[~north] * (ir[~north] + 1)
            + ip[~north]
            - 1
        )
        pix[pol] = p

    bad = finite & ((pix < 0) | (pix >= npix))
    if np.any(bad):
        raise RuntimeError("HEALPix RING calculation produced invalid pixel indices")
    return pix


def derive_galactic_coordinates(frame: pd.DataFrame, cfg: dict[str, Any]):
    """
    Outcome-blind coordinate-route adjudication.

    v0.19.0 selected native Galactic l/b whenever those columns existed,
    even if their values were all missing. This hotfix evaluates finite
    coordinate-pair coverage for every allowed route and chooses the route
    with maximum coverage. Native Galactic l/b wins only on an exact tie.
    """
    cols = list(frame.columns)
    candidates = []

    l_col = find_alias(cols, cfg["coordinate_aliases"]["galactic_longitude"])
    b_col = find_alias(cols, cfg["coordinate_aliases"]["galactic_latitude"])
    if l_col and b_col:
        l_native = pd.to_numeric(
            frame[l_col], errors="coerce"
        ).to_numpy(dtype=float)
        b_native = pd.to_numeric(
            frame[b_col], errors="coerce"
        ).to_numpy(dtype=float)
        valid = (
            np.isfinite(l_native)
            & np.isfinite(b_native)
            & (b_native >= -90.0)
            & (b_native <= 90.0)
        )
        candidates.append({
            "priority": 0,
            "route": f"native:{l_col},{b_col}",
            "l": l_native % 360.0,
            "b": b_native,
            "finite_pairs": int(valid.sum()),
        })

    ra_col = find_alias(cols, cfg["coordinate_aliases"]["ra"])
    dec_col = find_alias(cols, cfg["coordinate_aliases"]["dec"])
    if ra_col and dec_col:
        ra = pd.to_numeric(
            frame[ra_col], errors="coerce"
        ).to_numpy(dtype=float)
        dec = pd.to_numeric(
            frame[dec_col], errors="coerce"
        ).to_numpy(dtype=float)
        valid = (
            np.isfinite(ra)
            & np.isfinite(dec)
            & (dec >= -90.0)
            & (dec <= 90.0)
        )
        l_icrs = np.full(len(frame), np.nan)
        b_icrs = np.full(len(frame), np.nan)
        if np.any(valid):
            l_ok, b_ok = icrs_to_galactic(ra[valid], dec[valid])
            l_icrs[valid] = l_ok
            b_icrs[valid] = b_ok
        candidates.append({
            "priority": 1,
            "route": f"ICRS_to_Galactic:{ra_col},{dec_col}",
            "l": l_icrs,
            "b": b_icrs,
            "finite_pairs": int(valid.sum()),
        })

    if not candidates:
        raise RuntimeError(
            "No Galactic l/b or ICRS ra/dec coordinate pair found"
        )

    candidates.sort(
        key=lambda item: (-item["finite_pairs"], item["priority"])
    )
    selected = candidates[0]
    audit = []
    for item in candidates:
        audit.append({
            "route": item["route"],
            "finite_coordinate_pairs": item["finite_pairs"],
            "finite_coordinate_fraction": (
                item["finite_pairs"] / max(len(frame), 1)
            ),
            "selected": item["route"] == selected["route"],
        })

    return (
        selected["l"],
        selected["b"],
        selected["route"],
        audit,
    )


def support_complete_mask(frame: pd.DataFrame, cfg: dict[str, Any]):
    mask = pd.Series(True, index=frame.index)
    for field in cfg["support_required_fields"]:
        if field not in frame.columns:
            return pd.Series(False, index=frame.index)
        mask &= frame[field].notna()
    mask &= np.isfinite(pd.to_numeric(frame["gal_l_deg"], errors="coerce"))
    mask &= np.isfinite(pd.to_numeric(frame["gal_b_deg"], errors="coerce"))
    return mask


def cell_count_table(frame, mask, cell_col, surveys):
    work = frame.loc[mask, [cell_col, "survey"]].copy()
    if work.empty:
        return pd.DataFrame(columns=[cell_col] + surveys + ["minimum_survey_count"])
    counts = (
        work.groupby([cell_col, "survey"])
        .size()
        .unstack(fill_value=0)
        .reindex(columns=surveys, fill_value=0)
        .reset_index()
    )
    counts["minimum_survey_count"] = counts[surveys].min(axis=1)
    return counts


def overlap_intervals(frame, mask, variables, surveys, qlo, qhi):
    rows = []
    intervals = {}
    for spec in variables:
        field = spec["field"]
        survey_quantiles = {}
        for survey in surveys:
            values = pd.to_numeric(
                frame.loc[mask & (frame["survey"] == survey), field],
                errors="coerce",
            ).dropna()
            if values.empty:
                lo = np.nan
                hi = np.nan
            else:
                lo = float(values.quantile(qlo))
                hi = float(values.quantile(qhi))
            survey_quantiles[survey] = (lo, hi)

        lows = [survey_quantiles[s][0] for s in surveys]
        highs = [survey_quantiles[s][1] for s in surveys]
        overlap_lo = float(np.nanmax(lows)) if np.all(np.isfinite(lows)) else np.nan
        overlap_hi = float(np.nanmin(highs)) if np.all(np.isfinite(highs)) else np.nan
        valid = bool(np.isfinite(overlap_lo) and np.isfinite(overlap_hi) and overlap_lo <= overlap_hi)
        intervals[field] = (overlap_lo, overlap_hi, valid)

        row = {
            "field": field,
            "label": spec["label"],
            "mode": spec["mode"],
            "q_low": qlo,
            "q_high": qhi,
            "overlap_low": overlap_lo,
            "overlap_high": overlap_hi,
            "valid_overlap": valid,
        }
        for survey in surveys:
            row[f"{survey}_q_low"] = survey_quantiles[survey][0]
            row[f"{survey}_q_high"] = survey_quantiles[survey][1]
        rows.append(row)
    return intervals, rows


def construct_for_nside(frame, base_complete, nside, cfg):
    surveys = cfg["surveys"]
    cell_col = f"healpix_gal_ring_nside{nside}"

    pre_counts = cell_count_table(frame, base_complete, cell_col, surveys)
    pre_good_cells = set(
        pre_counts.loc[
            pre_counts["minimum_survey_count"]
            >= int(cfg["minimum_rows_per_survey_per_cell_pretrim"]),
            cell_col,
        ].astype(int)
    )
    pre_cell_mask = base_complete & frame[cell_col].isin(pre_good_cells)

    qlo, qhi = cfg["trim_quantiles"]
    intervals, interval_rows = overlap_intervals(
        frame,
        pre_cell_mask,
        cfg["trim_variables"],
        surveys,
        float(qlo),
        float(qhi),
    )
    intervals_ready = all(v[2] for v in intervals.values())

    running = pre_cell_mask.copy()
    trim_flags = {}
    for spec in cfg["trim_variables"]:
        field = spec["field"]
        low, high, valid = intervals[field]
        if valid:
            values = pd.to_numeric(frame[field], errors="coerce")
            flag = values.between(low, high, inclusive="both")
        else:
            flag = pd.Series(False, index=frame.index)
        trim_flags[field] = flag
        running &= flag

    post_counts = cell_count_table(frame, running, cell_col, surveys)
    post_good_cells = set(
        post_counts.loc[
            post_counts["minimum_survey_count"]
            >= int(cfg["minimum_rows_per_survey_per_cell_posttrim"]),
            cell_col,
        ].astype(int)
    )
    final_mask = running & frame[cell_col].isin(post_good_cells)

    return {
        "cell_col": cell_col,
        "pre_counts": pre_counts,
        "pre_good_cells": pre_good_cells,
        "pre_cell_mask": pre_cell_mask,
        "intervals": intervals,
        "interval_rows": interval_rows,
        "intervals_ready": intervals_ready,
        "trim_flags": trim_flags,
        "post_counts": post_counts,
        "post_good_cells": post_good_cells,
        "pre_posttrim_mask": running,
        "final_mask": final_mask,
    }


def exclusion_rows(frame, base_complete, result, cfg):
    rows = []
    final = result["final_mask"]
    pre_cell = result["pre_cell_mask"]
    post_pre = result["pre_posttrim_mask"]
    cell_col = result["cell_col"]

    for idx in frame.index:
        if final.loc[idx]:
            continue
        reasons = []
        if not base_complete.loc[idx]:
            reasons.append("MISSING_SUPPORT_OR_COORDINATE")
        else:
            if not pre_cell.loc[idx]:
                reasons.append("PRETRIM_CELL_MIN25_BOTH_SURVEYS")
            else:
                for spec in cfg["trim_variables"]:
                    field = spec["field"]
                    if not result["trim_flags"][field].loc[idx]:
                        reasons.append(f"Q05_Q95_OVERLAP_TRIM:{field}")
                if post_pre.loc[idx] and not final.loc[idx]:
                    reasons.append("POSTTRIM_CELL_MIN15_BOTH_SURVEYS")
        rows.append({
            "source_id": frame.at[idx, "source_id"],
            "survey": frame.at[idx, "survey"],
            "cell": frame.at[idx, cell_col],
            "reasons": "|".join(reasons) if reasons else "UNCLASSIFIED_EXCLUSION",
        })
    return rows


def write_df_csv(path: Path, df: pd.DataFrame):
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3b_config.json").read_text(encoding="utf-8")
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in ["validation", "tables", "retained", "sensitivity", "manifest", "summaries", "reports"]:
        (out / d).mkdir(parents=True, exist_ok=True)

    prepath = root / cfg["prerequisite_validation"]
    pre = json.loads(prepath.read_text(encoding="utf-8")) if prepath.exists() else {}
    prereq_ready = bool(
        pre.get("STAGE6D3B_COMMON_FOOTPRINT_READY", False)
        and pre.get("PRODUCTION_SOURCE_ASSEMBLY_READY", False)
        and pre.get("FINAL_ROW_CONSERVATION_READY", False)
        and pre.get("SURVEY_SPECIFIC_SNR_SUPPORT_READY", False)
    )

    source_path = resolve(root / cfg["production_source"])
    if not source_path:
        raise FileNotFoundError("D8F production source not found")
    frame = read_table(source_path)

    required = set(cfg["support_required_fields"])
    missing_required = sorted(required - set(frame.columns))
    source_schema_ready = not missing_required
    if missing_required:
        raise RuntimeError(f"Missing required source columns: {missing_required}")

    row_key_unique = not frame.duplicated(["source_id", "survey"]).any()
    survey_set_ready = set(frame["survey"].dropna().astype(str)) == set(cfg["surveys"])

    gal_l, gal_b, coordinate_route, coordinate_route_audit = derive_galactic_coordinates(frame, cfg)
    frame["gal_l_deg"] = gal_l
    frame["gal_b_deg"] = gal_b
    coordinate_finite_pair_count = int(
        (np.isfinite(gal_l) & np.isfinite(gal_b)).sum()
    )
    coordinate_ready = coordinate_finite_pair_count > 0
    write_csv(
        out / "tables/stage6d3b1_coordinate_route_audit.csv",
        [
            "route", "finite_coordinate_pairs",
            "finite_coordinate_fraction", "selected"
        ],
        coordinate_route_audit,
    )

    for nside in [cfg["primary_nside"]] + cfg["sensitivity_nsides"]:
        frame[f"healpix_gal_ring_nside{nside}"] = healpix_ang2pix_ring(
            int(nside), frame["gal_l_deg"].to_numpy(), frame["gal_b_deg"].to_numpy()
        )

    base_complete = support_complete_mask(frame, cfg)

    results = {}
    for nside in [cfg["primary_nside"]] + cfg["sensitivity_nsides"]:
        results[int(nside)] = construct_for_nside(
            frame, base_complete, int(nside), cfg
        )

    primary = results[int(cfg["primary_nside"])]
    retained = frame.loc[primary["final_mask"]].copy()

    retained_counts = {
        survey: int((retained["survey"] == survey).sum())
        for survey in cfg["surveys"]
    }
    retained_rows_ready = all(
        retained_counts[survey] >= int(cfg["minimum_retained_rows_per_survey"])
        for survey in cfg["surveys"]
    )
    primary_cells_ready = bool(
        len(primary["pre_good_cells"]) > 0
        and len(primary["post_good_cells"]) > 0
    )
    intervals_ready = primary["intervals_ready"]

    retained_path = (
        out / "retained/stage6d3b_common_footprint_retained_sources.parquet"
    )
    try:
        retained.to_parquet(retained_path, index=False)
    except Exception:
        retained_path = retained_path.with_suffix(".csv")
        retained.to_csv(retained_path, index=False)

    # Primary ledgers
    write_df_csv(
        out / "tables/stage6d3b_pretrim_cell_ledger_nside16.csv",
        primary["pre_counts"],
    )
    write_df_csv(
        out / "tables/stage6d3b_posttrim_cell_ledger_nside16.csv",
        primary["post_counts"],
    )
    write_csv(
        out / "tables/stage6d3b_overlap_intervals_nside16.csv",
        [
            "field", "label", "mode", "q_low", "q_high",
            "APOGEE_NATIVE_q_low", "APOGEE_NATIVE_q_high",
            "GALAH_CORRECTED_q_low", "GALAH_CORRECTED_q_high",
            "overlap_low", "overlap_high", "valid_overlap"
        ],
        primary["interval_rows"],
    )
    write_csv(
        out / "tables/stage6d3b_exclusion_ledger_nside16.csv",
        ["source_id", "survey", "cell", "reasons"],
        exclusion_rows(frame, base_complete, primary, cfg),
    )

    # Sensitivity ledgers
    sensitivity_summary = []
    for nside in cfg["sensitivity_nsides"]:
        result = results[int(nside)]
        retained_n = frame.loc[result["final_mask"]]
        counts_n = {
            survey: int((retained_n["survey"] == survey).sum())
            for survey in cfg["surveys"]
        }
        write_df_csv(
            out / f"sensitivity/stage6d3b_pretrim_cell_ledger_nside{nside}.csv",
            result["pre_counts"],
        )
        write_df_csv(
            out / f"sensitivity/stage6d3b_posttrim_cell_ledger_nside{nside}.csv",
            result["post_counts"],
        )
        write_csv(
            out / f"sensitivity/stage6d3b_overlap_intervals_nside{nside}.csv",
            [
                "field", "label", "mode", "q_low", "q_high",
                "APOGEE_NATIVE_q_low", "APOGEE_NATIVE_q_high",
                "GALAH_CORRECTED_q_low", "GALAH_CORRECTED_q_high",
                "overlap_low", "overlap_high", "valid_overlap"
            ],
            result["interval_rows"],
        )
        sensitivity_summary.append({
            "nside": int(nside),
            "pretrim_retained_cell_count": len(result["pre_good_cells"]),
            "posttrim_retained_cell_count": len(result["post_good_cells"]),
            "APOGEE_NATIVE_retained_rows": counts_n["APOGEE_NATIVE"],
            "GALAH_CORRECTED_retained_rows": counts_n["GALAH_CORRECTED"],
            "intervals_ready": result["intervals_ready"],
        })
    write_csv(
        out / "sensitivity/stage6d3b_nside_sensitivity_summary.csv",
        [
            "nside", "pretrim_retained_cell_count",
            "posttrim_retained_cell_count",
            "APOGEE_NATIVE_retained_rows",
            "GALAH_CORRECTED_retained_rows",
            "intervals_ready"
        ],
        sensitivity_summary,
    )

    flow_rows = [{
        "stage": "input",
        "APOGEE_NATIVE": int((frame["survey"] == "APOGEE_NATIVE").sum()),
        "GALAH_CORRECTED": int((frame["survey"] == "GALAH_CORRECTED").sum()),
    }, {
        "stage": "support_complete",
        "APOGEE_NATIVE": int(((frame["survey"] == "APOGEE_NATIVE") & base_complete).sum()),
        "GALAH_CORRECTED": int(((frame["survey"] == "GALAH_CORRECTED") & base_complete).sum()),
    }, {
        "stage": "pretrim_cells_min25",
        "APOGEE_NATIVE": int(((frame["survey"] == "APOGEE_NATIVE") & primary["pre_cell_mask"]).sum()),
        "GALAH_CORRECTED": int(((frame["survey"] == "GALAH_CORRECTED") & primary["pre_cell_mask"]).sum()),
    }, {
        "stage": "q05_q95_overlap_trim",
        "APOGEE_NATIVE": int(((frame["survey"] == "APOGEE_NATIVE") & primary["pre_posttrim_mask"]).sum()),
        "GALAH_CORRECTED": int(((frame["survey"] == "GALAH_CORRECTED") & primary["pre_posttrim_mask"]).sum()),
    }, {
        "stage": "posttrim_cells_min15",
        "APOGEE_NATIVE": retained_counts["APOGEE_NATIVE"],
        "GALAH_CORRECTED": retained_counts["GALAH_CORRECTED"],
    }]
    write_csv(
        out / "tables/stage6d3b_sample_flow.csv",
        ["stage", "APOGEE_NATIVE", "GALAH_CORRECTED"],
        flow_rows,
    )

    # Explicit protocol ledger
    protocol_ledger = [
        {"item": "frame", "value": "Galactic"},
        {"item": "healpix_ordering", "value": "RING"},
        {"item": "primary_nside", "value": cfg["primary_nside"]},
        {"item": "sensitivity_nsides", "value": "|".join(map(str, cfg["sensitivity_nsides"]))},
        {"item": "pretrim_min_per_survey_per_cell", "value": cfg["minimum_rows_per_survey_per_cell_pretrim"]},
        {"item": "posttrim_min_per_survey_per_cell", "value": cfg["minimum_rows_per_survey_per_cell_posttrim"]},
        {"item": "trim_quantiles", "value": "|".join(map(str, cfg["trim_quantiles"]))},
        {"item": "snr_support_field", "value": "snr_within_survey_percentile"},
        {"item": "native_snr_retained", "value": True},
        {"item": "optional_distance_quality_used", "value": False},
        {"item": "forbidden_matching_fields_used", "value": False},
    ]
    write_csv(
        out / "tables/stage6d3b_protocol_ledger.csv",
        ["item", "value"],
        protocol_ledger,
    )

    manifest_rows = []
    for path in sorted(out.rglob("*")):
        if path.is_file() and "manifest" not in path.parts:
            manifest_rows.append({
                "path": rel(path, root),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            })
    write_csv(
        out / "manifest/stage6d3b_output_manifest_sha256.csv",
        ["path", "size_bytes", "sha256"],
        manifest_rows,
    )

    common_footprint_ready = bool(
        prereq_ready
        and source_schema_ready
        and row_key_unique
        and survey_set_ready
        and coordinate_ready
        and intervals_ready
        and primary_cells_ready
        and retained_rows_ready
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "production_source": rel(source_path, root),
        "input_rows": len(frame),
        "coordinate_route": coordinate_route,
        "coordinate_route_candidates": coordinate_route_audit,
        "coordinate_finite_pair_count": coordinate_finite_pair_count,
        "primary_nside": cfg["primary_nside"],
        "pretrim_retained_cell_count": len(primary["pre_good_cells"]),
        "posttrim_retained_cell_count": len(primary["post_good_cells"]),
        "retained_source_table": rel(retained_path, root),
        "retained_rows": len(retained),
        "retained_rows_by_survey": retained_counts,
        "support_complete_rows_by_survey": {
            survey: int(((frame["survey"] == survey) & base_complete).sum())
            for survey in cfg["surveys"]
        },
        "sensitivity_summary": sensitivity_summary,
        "prior_stage_outputs_modified": False,
        "STAGE6D3A2D8F_PREREQUISITE_READY": prereq_ready,
        "PRODUCTION_SOURCE_SCHEMA_READY": source_schema_ready,
        "SOURCE_SURVEY_ROW_KEY_UNIQUE": row_key_unique,
        "EXACT_SURVEY_SET_READY": survey_set_ready,
        "GALACTIC_COORDINATE_ROUTE_READY": coordinate_ready,
        "HEALPIX_GALACTIC_RING_READY": coordinate_ready,
        "PRIMARY_NSIDE16_FROZEN": True,
        "SENSITIVITY_NSIDE8_NSIDE32_ARCHIVED": True,
        "PRETRIM_MIN25_PER_SURVEY_PER_CELL_APPLIED": True,
        "Q05_Q95_INTERSECTION_TRIM_APPLIED": True,
        "SNR_WITHIN_SURVEY_PERCENTILE_USED_FOR_SUPPORT_ONLY": True,
        "NATIVE_SNR_VALUES_RETAINED": True,
        "POSTTRIM_MIN15_PER_SURVEY_PER_CELL_APPLIED": True,
        "OVERLAP_INTERVALS_VALID": intervals_ready,
        "PRIMARY_RETAINED_CELLS_READY": primary_cells_ready,
        "MINIMUM_RETAINED_ROWS_PER_SURVEY_READY": retained_rows_ready,
        "ABUNDANCE_MATCHING_FORBIDDEN": True,
        "R_ABSZ_MATCHING_FORBIDDEN": True,
        "RESIDUAL_OUTCOME_MATCHING_FORBIDDEN": True,
        "OPTIONAL_DISTANCE_QUALITY_NOT_USED": True,
        "COMMON_FOOTPRINT_SOURCE_TABLE_READY": common_footprint_ready,
        "STAGE6D3B_COMMON_FOOTPRINT_READY": common_footprint_ready,
        "STAGE6D3C_BALANCING_READY": common_footprint_ready,
    }
    write_json(
        out / "validation/stage6d3b_validation.json",
        validation,
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": now(),
        "primary_common_footprint": {
            "nside": cfg["primary_nside"],
            "ordering": cfg["healpix_ordering"],
            "frame": cfg["healpix_frame"],
            "pretrim_cells": len(primary["pre_good_cells"]),
            "posttrim_cells": len(primary["post_good_cells"]),
            "retained_rows_by_survey": retained_counts,
        },
        "trim_semantics": {
            "variables": [x["field"] for x in cfg["trim_variables"]],
            "snr_support_variable": "snr_within_survey_percentile",
            "native_snr_retained": True,
            "quantile_intersection": cfg["trim_quantiles"],
        },
        "scientific_disposition": (
            "A claim-safe common APOGEE–GALAH footprint is frozen. Stage-6D3C "
            "cross-fitted overlap-weight balancing is authorized."
            if common_footprint_ready else
            "Common-footprint construction is audited but failed one or more frozen gates."
        ),
    }
    write_json(
        out / "summaries/stage6d3b_summary.json",
        summary,
    )

    report = [
        "# Stage-6D3B common-footprint construction",
        "",
        f"- Input rows: `{len(frame)}`",
        f"- Coordinate route: `{coordinate_route}`",
        f"- Primary HEALPix: `Galactic NSIDE={cfg['primary_nside']} RING`",
        f"- Pre-trim retained cells: `{len(primary['pre_good_cells'])}`",
        f"- Post-trim retained cells: `{len(primary['post_good_cells'])}`",
        f"- APOGEE retained rows: `{retained_counts['APOGEE_NATIVE']}`",
        f"- GALAH retained rows: `{retained_counts['GALAH_CORRECTED']}`",
        f"- Stage-6D3C ready: `{common_footprint_ready}`",
        "",
        "S/N overlap trimming uses the frozen within-survey S/N percentile support "
        "coordinate. Native APOGEE and GALAH S/N values are retained and are not "
        "treated as numerically commensurate across surveys.",
        "",
        "No abundance, R, |Z|, residual, outcome, or latent-component quantity is "
        "used to construct the common footprint.",
        "",
    ]
    (out / "reports/stage6d3b_report.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
