from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd


def now():
    return datetime.now(timezone.utc).isoformat()


def rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_df_csv(path: Path, frame: pd.DataFrame):
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)


def resolve(path: Path):
    for candidate in [path, path.with_suffix(".csv"), path.with_suffix(".feather")]:
        if candidate.exists():
            return candidate
    return None


def read_table(path: Path):
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower() == ".feather":
        return pd.read_feather(path)
    return pd.read_csv(path)


def weighted_mean(values, weights):
    x = np.asarray(values, dtype=float)
    w = np.asarray(weights, dtype=float)
    ok = np.isfinite(x) & np.isfinite(w) & (w > 0)
    if not np.any(ok):
        return np.nan
    return float(np.sum(x[ok] * w[ok]) / np.sum(w[ok]))


def weighted_variance(values, weights):
    x = np.asarray(values, dtype=float)
    w = np.asarray(weights, dtype=float)
    ok = np.isfinite(x) & np.isfinite(w) & (w > 0)
    if np.sum(ok) < 2:
        return np.nan
    x = x[ok]
    w = w[ok]
    mean = np.sum(w * x) / np.sum(w)
    return float(np.sum(w * (x - mean) ** 2) / np.sum(w))


def smd(frame, field, weight_field, cfg):
    values = pd.to_numeric(frame[field], errors="coerce").to_numpy(dtype=float)
    if weight_field is None:
        weights = np.ones(len(frame), dtype=float)
    else:
        weights = pd.to_numeric(
            frame[weight_field], errors="coerce"
        ).to_numpy(dtype=float)

    a = (frame["survey"] == cfg["apogee_label"]).to_numpy()
    g = (frame["survey"] == cfg["galah_label"]).to_numpy()
    ma = weighted_mean(values[a], weights[a])
    mg = weighted_mean(values[g], weights[g])
    va = weighted_variance(values[a], weights[a])
    vg = weighted_variance(values[g], weights[g])
    pooled = (
        math.sqrt(0.5 * (va + vg))
        if np.isfinite(va) and np.isfinite(vg) else np.nan
    )
    value = (
        (mg - ma) / pooled
        if np.isfinite(pooled) and pooled > 0 else np.nan
    )
    return {
        "feature": field,
        "APOGEE_mean": ma,
        "GALAH_mean": mg,
        "pooled_sd": pooled,
        "smd_GALAH_minus_APOGEE": value,
        "absolute_smd": abs(value) if np.isfinite(value) else np.nan,
    }


def ess(weights):
    w = np.asarray(weights, dtype=float)
    w = w[np.isfinite(w) & (w > 0)]
    if len(w) == 0:
        return 0.0
    denom = np.sum(w ** 2)
    return float((np.sum(w) ** 2) / denom) if denom > 0 else 0.0


def rebuild_equalized_weights(frame, cfg):
    """
    Diagnostic-only reconstruction after a positivity screen.
    Uses the already generated p99-capped D3C weight; does not refit propensity,
    alter features, or alter any frozen threshold.
    """
    base = pd.to_numeric(
        frame[cfg["capped_weight_field"]], errors="coerce"
    ).to_numpy(dtype=float)
    final = base.copy()
    factors = np.ones(len(frame), dtype=float)
    cell_rows = []

    for cell, indices in frame.groupby(cfg["cell_field"], sort=True).groups.items():
        idx = np.asarray(list(indices), dtype=int)
        surveys = frame.loc[idx, "survey"].astype(str).to_numpy()
        totals = {
            survey: float(np.sum(base[idx][surveys == survey]))
            for survey in cfg["surveys"]
        }
        both_positive = all(totals[s] > 0 for s in cfg["surveys"])
        if not both_positive:
            for j in idx:
                final[j] = np.nan
                factors[j] = np.nan
            cell_rows.append({
                "cell": cell,
                "APOGEE_rows": int(np.sum(surveys == cfg["apogee_label"])),
                "GALAH_rows": int(np.sum(surveys == cfg["galah_label"])),
                "APOGEE_capped_total": totals[cfg["apogee_label"]],
                "GALAH_capped_total": totals[cfg["galah_label"]],
                "both_surveys_positive_weight": False,
                "retained_for_diagnostic": False,
            })
            continue

        target = 0.5 * (totals[cfg["apogee_label"]] + totals[cfg["galah_label"]])
        for survey in cfg["surveys"]:
            mask = surveys == survey
            factor = target / totals[survey]
            factors[idx[mask]] = factor
            final[idx[mask]] = base[idx[mask]] * factor

        cell_rows.append({
            "cell": cell,
            "APOGEE_rows": int(np.sum(surveys == cfg["apogee_label"])),
            "GALAH_rows": int(np.sum(surveys == cfg["galah_label"])),
            "APOGEE_capped_total": totals[cfg["apogee_label"]],
            "GALAH_capped_total": totals[cfg["galah_label"]],
            "both_surveys_positive_weight": True,
            "retained_for_diagnostic": True,
        })
    return final, factors, cell_rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3c1_config.json").read_text(encoding="utf-8")
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in ["validation", "tables", "diagnostic", "summaries", "reports"]:
        (out / d).mkdir(parents=True, exist_ok=True)

    prepath = root / cfg["prerequisite_validation"]
    pre = json.loads(prepath.read_text(encoding="utf-8")) if prepath.exists() else {}
    prereq_ready = bool(
        pre.get("STAGE6D3B1_PREREQUISITE_READY", False)
        and pre.get("CROSSFITTED_RIDGE_LOGISTIC_READY", False)
        and pre.get("OVERLAP_WEIGHTS_READY", False)
        and pre.get("ESS_RAW_GE_0P35_READY", False)
        and not pre.get("STAGE6D3C_BALANCE_GATES_READY", True)
        and not pre.get("STAGE6D4_SCIENCE_MODELS_READY", True)
    )

    source_path = resolve(root / cfg["balanced_source"])
    if not source_path:
        raise FileNotFoundError("D3C balanced diagnostic source not found")
    frame = read_table(source_path).reset_index(drop=True)

    required = {
        "source_id", "survey", cfg["cell_field"], cfg["propensity_field"],
        cfg["raw_weight_field"], cfg["capped_weight_field"],
        cfg["final_weight_field"], *cfg["feature_fields"]
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise RuntimeError(f"Missing required D3C1 columns: {missing}")

    p = pd.to_numeric(frame[cfg["propensity_field"]], errors="coerce")
    low = float(cfg["propensity_lower_gate"])
    high = float(cfg["propensity_upper_gate"])
    inside = p.between(low, high, inclusive="both")
    below = p < low
    above = p > high
    outside = below | above

    # 1) Stage-by-stage global SMD localization.
    stage_rows = []
    stages = [
        ("unweighted", None),
        ("raw_overlap", cfg["raw_weight_field"]),
        ("p99_capped", cfg["capped_weight_field"]),
        ("final_cell_equalized", cfg["final_weight_field"]),
    ]
    for stage, weight_field in stages:
        for feature in cfg["feature_fields"]:
            row = smd(frame, feature, weight_field, cfg)
            row["stage"] = stage
            row["gate_passed"] = bool(
                np.isfinite(row["absolute_smd"])
                and row["absolute_smd"]
                <= float(cfg["maximum_absolute_smd_gate"])
            )
            stage_rows.append(row)
    stage_df = pd.DataFrame(stage_rows)
    write_df_csv(
        out / "tables/stage6d3c1_smd_stage_localization.csv",
        stage_df,
    )

    final_stage = stage_df[
        stage_df["stage"] == "final_cell_equalized"
    ].sort_values("absolute_smd", ascending=False)
    worst_feature = (
        str(final_stage.iloc[0]["feature"]) if len(final_stage) else ""
    )
    worst_final_smd = (
        float(final_stage.iloc[0]["absolute_smd"]) if len(final_stage) else np.nan
    )

    # 2) Propensity tail localization by survey.
    propensity_rows = []
    for survey in cfg["surveys"]:
        mask = frame["survey"] == survey
        values = p[mask]
        propensity_rows.append({
            "survey": survey,
            "rows": int(mask.sum()),
            "below_0p05_rows": int((values < low).sum()),
            "above_0p95_rows": int((values > high).sum()),
            "outside_gate_rows": int(((values < low) | (values > high)).sum()),
            "outside_gate_fraction": float(
                ((values < low) | (values > high)).mean()
            ) if int(mask.sum()) else 0.0,
            "min": float(values.min()),
            "q01": float(values.quantile(.01)),
            "q05": float(values.quantile(.05)),
            "median": float(values.quantile(.50)),
            "q95": float(values.quantile(.95)),
            "q99": float(values.quantile(.99)),
            "max": float(values.max()),
        })
    write_csv(
        out / "tables/stage6d3c1_propensity_tail_by_survey.csv",
        [
            "survey", "rows", "below_0p05_rows", "above_0p95_rows",
            "outside_gate_rows", "outside_gate_fraction",
            "min", "q01", "q05", "median", "q95", "q99", "max"
        ],
        propensity_rows,
    )

    # 3) Feature profiles inside vs outside positivity gate.
    feature_tail_rows = []
    for feature in cfg["feature_fields"]:
        values = pd.to_numeric(frame[feature], errors="coerce")
        for region_name, region_mask in [
            ("inside_0p05_0p95", inside),
            ("outside_0p05_0p95", outside),
            ("above_0p95", above),
            ("below_0p05", below),
        ]:
            for survey in cfg["surveys"]:
                mask = region_mask & (frame["survey"] == survey)
                subset = values[mask].dropna()
                feature_tail_rows.append({
                    "feature": feature,
                    "region": region_name,
                    "survey": survey,
                    "rows": int(mask.sum()),
                    "finite_rows": int(len(subset)),
                    "mean": float(subset.mean()) if len(subset) else np.nan,
                    "median": float(subset.median()) if len(subset) else np.nan,
                    "q05": float(subset.quantile(.05)) if len(subset) else np.nan,
                    "q95": float(subset.quantile(.95)) if len(subset) else np.nan,
                })
    write_csv(
        out / "tables/stage6d3c1_propensity_tail_feature_profiles.csv",
        [
            "feature", "region", "survey", "rows", "finite_rows",
            "mean", "median", "q05", "q95"
        ],
        feature_tail_rows,
    )

    # 4) Cell localization.
    cell_rows = []
    cell_feature_rows = []
    min_per_survey = int(cfg["minimum_rows_per_survey_for_cell_diagnostic"])
    for cell, group in frame.groupby(cfg["cell_field"], sort=True):
        a = group["survey"] == cfg["apogee_label"]
        g = group["survey"] == cfg["galah_label"]
        pg = pd.to_numeric(group[cfg["propensity_field"]], errors="coerce")
        row = {
            "cell": cell,
            "rows": len(group),
            "APOGEE_rows": int(a.sum()),
            "GALAH_rows": int(g.sum()),
            "outside_propensity_rows": int(
                ((pg < low) | (pg > high)).sum()
            ),
            "outside_propensity_fraction": float(
                ((pg < low) | (pg > high)).mean()
            ),
            "min_propensity": float(pg.min()),
            "max_propensity": float(pg.max()),
        }

        max_cell_smd = np.nan
        worst_cell_feature = ""
        if int(a.sum()) >= min_per_survey and int(g.sum()) >= min_per_survey:
            local = []
            for feature in cfg["feature_fields"]:
                sr = smd(group.reset_index(drop=True), feature, cfg["final_weight_field"], cfg)
                sr["cell"] = cell
                sr["eligible_cell_diagnostic"] = True
                local.append(sr)
                cell_feature_rows.append(sr)
            valid_local = [
                x for x in local if np.isfinite(x["absolute_smd"])
            ]
            if valid_local:
                worst = max(valid_local, key=lambda x: x["absolute_smd"])
                max_cell_smd = float(worst["absolute_smd"])
                worst_cell_feature = worst["feature"]
        row["maximum_absolute_cell_smd"] = max_cell_smd
        row["worst_cell_feature"] = worst_cell_feature
        cell_rows.append(row)

    write_csv(
        out / "tables/stage6d3c1_cell_failure_localization.csv",
        [
            "cell", "rows", "APOGEE_rows", "GALAH_rows",
            "outside_propensity_rows", "outside_propensity_fraction",
            "min_propensity", "max_propensity",
            "maximum_absolute_cell_smd", "worst_cell_feature"
        ],
        cell_rows,
    )
    write_csv(
        out / "tables/stage6d3c1_cell_feature_smd.csv",
        [
            "cell", "feature", "APOGEE_mean", "GALAH_mean",
            "pooled_sd", "smd_GALAH_minus_APOGEE",
            "absolute_smd", "eligible_cell_diagnostic"
        ],
        cell_feature_rows,
    )

    # 5) Contribution to the global weighted mean difference for worst feature.
    contribution_rows = []
    if worst_feature:
        total_a_weight = float(
            frame.loc[
                frame["survey"] == cfg["apogee_label"],
                cfg["final_weight_field"],
            ].sum()
        )
        total_g_weight = float(
            frame.loc[
                frame["survey"] == cfg["galah_label"],
                cfg["final_weight_field"],
            ].sum()
        )
        for cell, group in frame.groupby(cfg["cell_field"], sort=True):
            values = pd.to_numeric(group[worst_feature], errors="coerce")
            weights = pd.to_numeric(
                group[cfg["final_weight_field"]], errors="coerce"
            )
            a = group["survey"] == cfg["apogee_label"]
            g = group["survey"] == cfg["galah_label"]
            a_num = float(np.nansum(values[a] * weights[a]))
            g_num = float(np.nansum(values[g] * weights[g]))
            contribution = (
                (g_num / total_g_weight if total_g_weight > 0 else np.nan)
                - (a_num / total_a_weight if total_a_weight > 0 else np.nan)
            )
            contribution_rows.append({
                "cell": cell,
                "feature": worst_feature,
                "APOGEE_weighted_numerator": a_num,
                "GALAH_weighted_numerator": g_num,
                "global_mean_difference_contribution": contribution,
                "absolute_contribution": abs(contribution)
                if np.isfinite(contribution) else np.nan,
            })
    contribution_rows.sort(
        key=lambda x: (
            -x["absolute_contribution"]
            if np.isfinite(x["absolute_contribution"]) else 0
        )
    )
    write_csv(
        out / "tables/stage6d3c1_worst_feature_cell_contributions.csv",
        [
            "cell", "feature", "APOGEE_weighted_numerator",
            "GALAH_weighted_numerator",
            "global_mean_difference_contribution", "absolute_contribution"
        ],
        contribution_rows,
    )

    # 6) Diagnostic-only positivity screen using the already fitted OOF propensity.
    screened = frame.loc[inside].copy().reset_index(drop=True)
    diagnostic_weights, diagnostic_factors, diagnostic_cell_rows = (
        rebuild_equalized_weights(screened, cfg)
    )
    screened["diagnostic_positivity_equalized_weight"] = diagnostic_weights
    screened["diagnostic_cell_equalization_factor"] = diagnostic_factors
    valid_weight = np.isfinite(diagnostic_weights) & (diagnostic_weights > 0)
    screened_valid = screened.loc[valid_weight].copy().reset_index(drop=True)

    diagnostic_smd_rows = []
    for feature in cfg["feature_fields"]:
        sr = smd(
            screened_valid,
            feature,
            "diagnostic_positivity_equalized_weight",
            cfg,
        )
        diagnostic_smd_rows.append(sr)
    write_csv(
        out / "diagnostic/stage6d3c1_positivity_screen_smd.csv",
        [
            "feature", "APOGEE_mean", "GALAH_mean", "pooled_sd",
            "smd_GALAH_minus_APOGEE", "absolute_smd"
        ],
        diagnostic_smd_rows,
    )
    write_csv(
        out / "diagnostic/stage6d3c1_positivity_screen_cell_ledger.csv",
        [
            "cell", "APOGEE_rows", "GALAH_rows",
            "APOGEE_capped_total", "GALAH_capped_total",
            "both_surveys_positive_weight", "retained_for_diagnostic"
        ],
        diagnostic_cell_rows,
    )

    diagnostic_max_smd = max(
        (
            row["absolute_smd"] for row in diagnostic_smd_rows
            if np.isfinite(row["absolute_smd"])
        ),
        default=np.nan,
    )
    diagnostic_ess_ratios = {}
    for survey in cfg["surveys"]:
        survey_rows = screened_valid["survey"] == survey
        raw_n = int(survey_rows.sum())
        value = ess(
            screened_valid.loc[
                survey_rows,
                "diagnostic_positivity_equalized_weight",
            ].to_numpy(dtype=float)
        )
        diagnostic_ess_ratios[survey] = (
            value / raw_n if raw_n > 0 else 0.0
        )

    diagnostic_gate_ready = bool(
        len(screened_valid) > 0
        and np.isfinite(diagnostic_max_smd)
        and diagnostic_max_smd
        <= float(cfg["maximum_absolute_smd_gate"])
        and all(
            ratio >= float(cfg["minimum_ess_raw_ratio_gate"])
            for ratio in diagnostic_ess_ratios.values()
        )
        and screened_valid[cfg["propensity_field"]]
        .between(low, high, inclusive="both").all()
    )

    # Classify failure mechanism.
    stage_max = {}
    for stage in stage_df["stage"].unique():
        values = stage_df.loc[
            stage_df["stage"] == stage, "absolute_smd"
        ]
        stage_max[stage] = float(values.max())

    prop_fail = bool(outside.sum() > 0)
    raw_smd_fail = bool(
        stage_max.get("raw_overlap", np.inf)
        > float(cfg["maximum_absolute_smd_gate"])
    )
    cap_smd_fail = bool(
        stage_max.get("p99_capped", np.inf)
        > float(cfg["maximum_absolute_smd_gate"])
    )
    final_smd_fail = bool(
        stage_max.get("final_cell_equalized", np.inf)
        > float(cfg["maximum_absolute_smd_gate"])
    )

    if (
        not raw_smd_fail
        and not cap_smd_fail
        and final_smd_fail
    ):
        failure_class = "CELL_EQUALIZATION_REINTRODUCES_GLOBAL_IMBALANCE"
    elif (
        not raw_smd_fail
        and cap_smd_fail
    ):
        failure_class = "P99_CAP_REINTRODUCES_IMBALANCE"
    elif raw_smd_fail and prop_fail and diagnostic_gate_ready:
        failure_class = "POSITIVITY_TAIL_DOMINATES_BALANCE_FAILURE"
    elif raw_smd_fail and diagnostic_gate_ready:
        failure_class = "COMMON_SUPPORT_SCREEN_DIAGNOSTICALLY_RESTORES_BALANCE"
    elif raw_smd_fail:
        failure_class = "PERSISTENT_SUPPORT_IMBALANCE_AFTER_OVERLAP_WEIGHTING"
    elif prop_fail:
        failure_class = "PROPENSITY_GATE_ONLY_FAILURE"
    else:
        failure_class = "MIXED_OR_UNRESOLVED_BALANCE_FAILURE"

    # Compact ranked failure feature table.
    ranked_features = final_stage[
        [
            "feature", "absolute_smd",
            "smd_GALAH_minus_APOGEE",
            "APOGEE_mean", "GALAH_mean"
        ]
    ].copy()
    write_df_csv(
        out / "tables/stage6d3c1_ranked_final_smd_features.csv",
        ranked_features,
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "failure_classification": failure_class,
        "input_rows": len(frame),
        "worst_final_smd_feature": worst_feature,
        "worst_final_absolute_smd": worst_final_smd,
        "stage_maximum_absolute_smd": stage_max,
        "propensity_below_0p05_rows": int(below.sum()),
        "propensity_above_0p95_rows": int(above.sum()),
        "propensity_outside_gate_rows": int(outside.sum()),
        "propensity_outside_gate_fraction": float(outside.mean()),
        "diagnostic_positivity_screen_rows": len(screened_valid),
        "diagnostic_positivity_screen_rows_by_survey": {
            survey: int((screened_valid["survey"] == survey).sum())
            for survey in cfg["surveys"]
        },
        "diagnostic_positivity_screen_maximum_absolute_smd": diagnostic_max_smd,
        "diagnostic_positivity_screen_ess_raw_ratio_by_survey": diagnostic_ess_ratios,
        "diagnostic_positivity_screen_all_frozen_gates_pass": diagnostic_gate_ready,
        "STAGE6D3C_PREREQUISITE_FAILURE_STATE_READY": prereq_ready,
        "SMD_STAGE_LOCALIZATION_READY": True,
        "PROPENSITY_TAIL_LOCALIZATION_READY": True,
        "CELL_FAILURE_LOCALIZATION_READY": True,
        "WORST_FEATURE_CELL_CONTRIBUTION_READY": bool(worst_feature),
        "POSITIVITY_SCREEN_DIAGNOSTIC_READY": True,
        "POSITIVITY_SCREEN_IS_DIAGNOSTIC_ONLY": True,
        "NO_FROZEN_THRESHOLD_WEAKENED": True,
        "NO_BALANCING_FEATURE_CHANGED": True,
        "NO_SCIENCE_MODEL_AUTHORIZED": True,
        "STAGE6D3C1_FAILURE_LOCALIZATION_READY": bool(prereq_ready),
        "STAGE6D4_SCIENCE_MODELS_READY": False,
    }
    write_json(
        out / "validation/stage6d3c1_validation.json",
        validation,
    )

    if failure_class == "POSITIVITY_TAIL_DOMINATES_BALANCE_FAILURE":
        next_action = (
            "Audit the frozen protocol wording for whether [0.05,0.95] is a "
            "pre-specified support restriction or only a terminal success gate. "
            "Do not apply the screen to production until that protocol semantics "
            "is explicitly reconciled."
        )
    elif failure_class == "CELL_EQUALIZATION_REINTRODUCES_GLOBAL_IMBALANCE":
        next_action = (
            "Inspect the cell contribution ledger. The failure is introduced "
            "after cell equalization, so any repair must preserve the frozen "
            "equal-cell survey-total rule or document a protocol contradiction."
        )
    elif failure_class == "P99_CAP_REINTRODUCES_IMBALANCE":
        next_action = (
            "Inspect p99-cap sensitivity as a protocol implementation issue; "
            "do not alter the frozen cap without protocol reconciliation."
        )
    elif failure_class == "PERSISTENT_SUPPORT_IMBALANCE_AFTER_OVERLAP_WEIGHTING":
        next_action = (
            "The retained common footprint remains insufficiently balanced under "
            "the frozen model. Localize the worst feature/cells before considering "
            "a protocol-level support refinement."
        )
    else:
        next_action = (
            "Use the ranked feature, propensity-tail, and cell-contribution ledgers "
            "to identify the exact gate mechanism before any production change."
        )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": now(),
        "failure_classification": failure_class,
        "worst_feature": {
            "feature": worst_feature,
            "absolute_final_smd": worst_final_smd,
        },
        "propensity_tail": {
            "outside_gate_rows": int(outside.sum()),
            "outside_gate_fraction": float(outside.mean()),
        },
        "diagnostic_positivity_screen": {
            "rows": len(screened_valid),
            "maximum_absolute_smd": diagnostic_max_smd,
            "ess_raw_ratio_by_survey": diagnostic_ess_ratios,
            "all_frozen_gates_pass": diagnostic_gate_ready,
            "production_authorized": False,
        },
        "next_action": next_action,
        "scientific_disposition": (
            "D3C remains failed. This stage localizes the mechanism only; "
            "Stage-6D4 remains blocked."
        ),
    }
    write_json(
        out / "summaries/stage6d3c1_summary.json",
        summary,
    )

    report = [
        "# Stage-6D3C1 balance-gate failure localization",
        "",
        f"- Failure class: `{failure_class}`",
        f"- Worst final SMD feature: `{worst_feature}`",
        f"- Worst final |SMD|: `{worst_final_smd}`",
        f"- Propensity outside [0.05,0.95]: `{int(outside.sum())}` rows "
        f"(`{float(outside.mean()):.6f}`)",
        f"- Diagnostic positivity-screen rows: `{len(screened_valid)}`",
        f"- Diagnostic positivity-screen max |SMD|: `{diagnostic_max_smd}`",
        f"- Diagnostic positivity-screen all gates pass: `{diagnostic_gate_ready}`",
        "- Stage-6D4 authorized: `False`",
        "",
        "The positivity-screen calculation is diagnostic only. It does not modify "
        "the frozen D3C production result and does not redefine the protocol.",
        "",
        next_action,
        "",
    ]
    (out / "reports/stage6d3c1_report.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
