from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import spearmanr


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8"
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_panel(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    return pd.read_csv(path)


def choose_panel(root: Path, candidates: list[str]) -> Path:
    for candidate in candidates:
        path = root / candidate
        if path.exists():
            return path
    raise FileNotFoundError(
        "No Stage-6D2A4 panel found among: " + ", ".join(candidates)
    )


def standardize(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    mean = float(numeric.mean())
    std = float(numeric.std(ddof=0))
    if not math.isfinite(std) or std <= 0:
        return pd.Series(np.zeros(len(series)), index=series.index)
    return (numeric - mean) / std


def build_design(frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
    work = frame.copy()
    work["z_B_atmos"] = standardize(work["B_atmos"])
    work["z_log_n_training_support"] = standardize(
        np.log1p(pd.to_numeric(work["n_training_support"], errors="coerce"))
    )
    work["z_log_n_heldout"] = standardize(
        np.log1p(pd.to_numeric(work["n_heldout"], errors="coerce"))
    )

    label_dummies = pd.get_dummies(
        work["label"].astype(str), prefix="label", drop_first=True, dtype=float
    )
    fold_dummies = pd.get_dummies(
        work["fold"].astype(str), prefix="fold", drop_first=True, dtype=float
    )

    components = [
        pd.Series(1.0, index=work.index, name="intercept"),
        work["z_B_atmos"],
        work["z_log_n_training_support"],
        work["z_log_n_heldout"],
    ]
    if not label_dummies.empty:
        components.append(label_dummies)
    if not fold_dummies.empty:
        components.append(fold_dummies)

    design = pd.concat(components, axis=1)
    y = np.log(pd.to_numeric(work["Q_heldout"], errors="coerce").to_numpy())
    weights = np.sqrt(
        np.maximum(
            pd.to_numeric(work["n_heldout"], errors="coerce").to_numpy(),
            1.0
        )
    )
    return (
        design.to_numpy(dtype=float),
        y.astype(float),
        weights.astype(float),
        list(design.columns),
    )


def weighted_ols(
    frame: pd.DataFrame
) -> tuple[dict[str, float], np.ndarray, list[str]]:
    X, y, weights, names = build_design(frame)
    sqrt_w = np.sqrt(weights / np.nanmean(weights))
    Xw = X * sqrt_w[:, None]
    yw = y * sqrt_w
    beta = np.linalg.pinv(Xw.T @ Xw) @ (Xw.T @ yw)
    fitted = X @ beta
    coefficients = {
        name: float(value) for name, value in zip(names, beta)
    }
    return coefficients, fitted, names


def valid_panel(frame: pd.DataFrame, labels: list[str]) -> pd.DataFrame:
    required = [
        "label", "fold", "support_cell", "n_heldout",
        "n_training_support", "Q_heldout", "B_atmos",
        "valid_min_rows", "valid_iqr", "valid_training_widths"
    ]
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise RuntimeError("Panel columns missing: " + ", ".join(missing))

    work = frame.copy()
    work["label"] = work["label"].astype(str).str.lower()
    work = work[work["label"].isin(labels)].copy()
    for column in ["Q_heldout", "B_atmos", "n_heldout", "n_training_support"]:
        work[column] = pd.to_numeric(work[column], errors="coerce")
    work = work[
        work["valid_min_rows"].astype(bool)
        & work["valid_iqr"].astype(bool)
        & work["valid_training_widths"].astype(bool)
        & work["Q_heldout"].gt(0)
        & work["Q_heldout"].notna()
        & work["B_atmos"].notna()
        & work["n_heldout"].gt(0)
        & work["n_training_support"].gt(0)
    ].copy()
    return work.reset_index(drop=True)


def group_spearman(
    frame: pd.DataFrame,
    minimum_cells: int
) -> list[dict[str, Any]]:
    rows = []
    for (label, fold), group in frame.groupby(["label", "fold"]):
        if len(group) < minimum_cells:
            continue
        rho, p_value = spearmanr(
            group["B_atmos"].to_numpy(),
            np.log(group["Q_heldout"].to_numpy())
        )
        rows.append({
            "label": label,
            "fold": int(fold),
            "n_cells": len(group),
            "spearman_rho": float(rho),
            "spearman_p": float(p_value),
            "positive": str(bool(rho > 0)).lower(),
            "negative": str(bool(rho < 0)).lower()
        })
    return rows


def permutation_distribution(
    frame: pd.DataFrame,
    minimum_cells: int,
    draws: int,
    seed: int
) -> tuple[np.ndarray, float]:
    observed_rows = group_spearman(frame, minimum_cells)
    observed = float(np.median([
        row["spearman_rho"] for row in observed_rows
    ]))
    rng = np.random.default_rng(seed)
    distribution = np.empty(draws, dtype=float)

    grouped = [
        group.copy()
        for _, group in frame.groupby(["label", "fold"])
        if len(group) >= minimum_cells
    ]
    for draw in range(draws):
        rhos = []
        for group in grouped:
            permuted_q = rng.permutation(
                np.log(group["Q_heldout"].to_numpy())
            )
            rho, _ = spearmanr(
                group["B_atmos"].to_numpy(),
                permuted_q
            )
            if math.isfinite(rho):
                rhos.append(float(rho))
        distribution[draw] = float(np.median(rhos))
    p_value = float(
        (1 + np.sum(np.abs(distribution) >= abs(observed)))
        / (draws + 1)
    )
    return distribution, p_value


def bootstrap_beta(
    frame: pd.DataFrame,
    draws: int,
    seed: int
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    groups = [
        group.index.to_numpy()
        for _, group in frame.groupby(["label", "fold"])
    ]
    results = np.full(draws, np.nan)
    for draw in range(draws):
        chosen = rng.integers(0, len(groups), size=len(groups))
        indices = np.concatenate([groups[index] for index in chosen])
        sample = frame.loc[indices].reset_index(drop=True)
        try:
            coefficients, _, _ = weighted_ols(sample)
            results[draw] = coefficients.get("z_B_atmos", np.nan)
        except Exception:
            continue
    return results[np.isfinite(results)]


def label_jackknife(frame: pd.DataFrame, labels: list[str]) -> list[dict[str, Any]]:
    rows = []
    for omitted in labels:
        sample = frame[frame["label"] != omitted].copy()
        coefficients, fitted, _ = weighted_ols(sample)
        beta = coefficients.get("z_B_atmos", float("nan"))
        mae = float(np.mean(np.abs(np.log(sample["Q_heldout"]) - fitted)))
        rows.append({
            "omitted_label": omitted,
            "training_rows": len(sample),
            "beta_B_atmos": beta,
            "positive": str(bool(beta > 0)).lower(),
            "negative": str(bool(beta < 0)).lower(),
            "training_mae_logQ": mae
        })
    return rows


def create_figures(
    frame: pd.DataFrame,
    group_rows: list[dict[str, Any]],
    output_dir: Path
) -> list[str]:
    paths = []
    try:
        import matplotlib.pyplot as plt

        scatter_path = output_dir / "stage6d2a5_B_atmos_vs_logQ.png"
        fig, ax = plt.subplots(figsize=(7.2, 5.0))
        ax.scatter(frame["B_atmos"], np.log(frame["Q_heldout"]), alpha=0.55)
        ax.set_xlabel("Atmospheric-sensitivity burden, B_atmos")
        ax.set_ylabel("log(Q_heldout)")
        ax.set_title("Five-label exploratory transportability panel")
        fig.tight_layout()
        fig.savefig(scatter_path, dpi=180)
        plt.close(fig)
        paths.append(str(scatter_path))

        label_summary = (
            pd.DataFrame(group_rows)
            .groupby("label")["spearman_rho"]
            .median()
            .sort_values()
        )
        rho_path = output_dir / "stage6d2a5_label_median_spearman.png"
        fig, ax = plt.subplots(figsize=(7.2, 4.6))
        ax.barh(label_summary.index, label_summary.values)
        ax.axvline(0.0, linewidth=1)
        ax.set_xlabel("Median within-fold Spearman rho")
        ax.set_ylabel("Label")
        ax.set_title("Association stability by label")
        fig.tight_layout()
        fig.savefig(rho_path, dpi=180)
        plt.close(fig)
        paths.append(str(rho_path))
    except Exception:
        return []
    return paths


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d2a5_config.json").read_text(encoding="utf-8")
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables", "figures", "reports"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg["prerequisite_validation"]
    prereq = (
        json.loads(prereq_path.read_text(encoding="utf-8"))
        if prereq_path.exists() else {}
    )
    prereq_ready = bool(
        prereq.get("FIVE_LABEL_PILOT_RECONSTRUCTION_READY", False)
        and prereq.get("PREDICTIVE_LAW_CLAIM_FORBIDDEN", False)
        and not prereq.get("STAGE6D2B_PREDICTIVE_LAW_READY", True)
    )

    panel_path = choose_panel(root, cfg["panel_candidates"])
    raw_panel = read_panel(panel_path)
    frame = valid_panel(raw_panel, cfg["labels"])
    panel_ready = bool(
        not frame.empty
        and sorted(frame["label"].unique()) == sorted(cfg["labels"])
    )

    group_rows = group_spearman(
        frame, cfg["minimum_cells_per_label_fold"]
    )
    group_ready = len(group_rows) >= cfg["minimum_valid_groups"]
    group_rhos = np.array(
        [row["spearman_rho"] for row in group_rows],
        dtype=float
    )
    median_group_rho = float(np.median(group_rhos))
    positive_group_fraction = float(np.mean(group_rhos > 0))
    negative_group_fraction = float(np.mean(group_rhos < 0))

    label_rows = []
    group_frame = pd.DataFrame(group_rows)
    for label in cfg["labels"]:
        subset = group_frame[group_frame["label"] == label]
        label_rows.append({
            "label": label,
            "valid_fold_groups": len(subset),
            "median_spearman_rho": (
                float(subset["spearman_rho"].median())
                if not subset.empty else float("nan")
            ),
            "positive_fold_fraction": (
                float((subset["spearman_rho"] > 0).mean())
                if not subset.empty else float("nan")
            ),
            "negative_fold_fraction": (
                float((subset["spearman_rho"] < 0).mean())
                if not subset.empty else float("nan")
            )
        })

    coefficients, fitted, coefficient_names = weighted_ols(frame)
    beta_B = float(coefficients.get("z_B_atmos", float("nan")))
    regression_mae = float(
        np.mean(np.abs(np.log(frame["Q_heldout"]) - fitted))
    )

    jackknife_rows = label_jackknife(frame, cfg["labels"])
    positive_jackknife_fraction = float(np.mean([
        row["beta_B_atmos"] > 0 for row in jackknife_rows
    ]))
    negative_jackknife_fraction = float(np.mean([
        row["beta_B_atmos"] < 0 for row in jackknife_rows
    ]))

    bootstrap = bootstrap_beta(
        frame,
        cfg["bootstrap_draws"],
        cfg["random_seed"] + 1
    )
    bootstrap_ready = len(bootstrap) >= int(0.9 * cfg["bootstrap_draws"])
    bootstrap_probability_positive = float(np.mean(bootstrap > 0))
    bootstrap_probability_negative = float(np.mean(bootstrap < 0))
    bootstrap_q025 = float(np.quantile(bootstrap, 0.025))
    bootstrap_q50 = float(np.quantile(bootstrap, 0.50))
    bootstrap_q975 = float(np.quantile(bootstrap, 0.975))

    permutation, permutation_p = permutation_distribution(
        frame,
        cfg["minimum_cells_per_label_fold"],
        cfg["permutation_draws"],
        cfg["random_seed"] + 2
    )
    permutation_ready = len(permutation) == cfg["permutation_draws"]

    positive_gate = cfg["classification_gates"]["stable_positive"]
    negative_gate = cfg["classification_gates"]["stable_negative"]

    stable_positive = bool(
        median_group_rho > positive_gate["median_group_spearman_min"]
        and positive_group_fraction
        >= positive_gate["positive_group_fraction_min"]
        and permutation_p <= positive_gate["permutation_p_max"]
        and bootstrap_probability_positive
        >= positive_gate["bootstrap_probability_beta_positive_min"]
        and positive_jackknife_fraction
        >= positive_gate["positive_label_jackknife_fraction_min"]
    )
    stable_negative = bool(
        median_group_rho < negative_gate["median_group_spearman_max"]
        and negative_group_fraction
        >= negative_gate["negative_group_fraction_min"]
        and permutation_p <= negative_gate["permutation_p_max"]
        and bootstrap_probability_negative
        >= negative_gate["bootstrap_probability_beta_negative_min"]
        and negative_jackknife_fraction
        >= negative_gate["negative_label_jackknife_fraction_min"]
    )

    if stable_positive:
        association_class = "STABLE_POSITIVE_EXPLORATORY_ASSOCIATION"
    elif stable_negative:
        association_class = "STABLE_NEGATIVE_EXPLORATORY_ASSOCIATION"
    elif permutation_p <= 0.10:
        association_class = "MIXED_OR_UNSTABLE_EXPLORATORY_ASSOCIATION"
    else:
        association_class = "NO_STABLE_EXPLORATORY_ASSOCIATION"

    write_csv(
        out / "tables/stage6d2a5_group_spearman.csv",
        [
            "label", "fold", "n_cells", "spearman_rho",
            "spearman_p", "positive", "negative"
        ],
        group_rows
    )
    write_csv(
        out / "tables/stage6d2a5_label_summary.csv",
        [
            "label", "valid_fold_groups", "median_spearman_rho",
            "positive_fold_fraction", "negative_fold_fraction"
        ],
        label_rows
    )
    write_csv(
        out / "tables/stage6d2a5_label_jackknife.csv",
        [
            "omitted_label", "training_rows", "beta_B_atmos",
            "positive", "negative", "training_mae_logQ"
        ],
        jackknife_rows
    )
    write_csv(
        out / "tables/stage6d2a5_regression_coefficients.csv",
        ["term", "coefficient"],
        [
            {"term": term, "coefficient": coefficients[term]}
            for term in coefficient_names
        ]
    )
    write_csv(
        out / "tables/stage6d2a5_bootstrap_summary.csv",
        ["metric", "value"],
        [
            {"metric": "draws_valid", "value": len(bootstrap)},
            {
                "metric": "probability_beta_positive",
                "value": bootstrap_probability_positive
            },
            {
                "metric": "probability_beta_negative",
                "value": bootstrap_probability_negative
            },
            {"metric": "beta_q025", "value": bootstrap_q025},
            {"metric": "beta_q50", "value": bootstrap_q50},
            {"metric": "beta_q975", "value": bootstrap_q975}
        ]
    )
    write_csv(
        out / "tables/stage6d2a5_permutation_summary.csv",
        ["metric", "value"],
        [
            {"metric": "draws", "value": len(permutation)},
            {
                "metric": "observed_median_group_spearman",
                "value": median_group_rho
            },
            {
                "metric": "two_sided_permutation_p",
                "value": permutation_p
            },
            {
                "metric": "null_q025",
                "value": float(np.quantile(permutation, 0.025))
            },
            {
                "metric": "null_q50",
                "value": float(np.quantile(permutation, 0.50))
            },
            {
                "metric": "null_q975",
                "value": float(np.quantile(permutation, 0.975))
            }
        ]
    )

    figure_paths = create_figures(
        frame, group_rows, out / "figures"
    )

    claim_rows = [
        {
            "claim_id": "D2A5-C1",
            "status": "ALLOWED",
            "claim": (
                "The five-label exploratory panel has the reported within-fold "
                "association class and stability diagnostics."
            )
        },
        {
            "claim_id": "D2A5-C2",
            "status": "CONDITIONAL",
            "claim": (
                "Within the five tested labels and overlap support, held-out "
                "transport error shows a structured association with B_atmos."
            )
        },
        {
            "claim_id": "D2A5-C3",
            "status": "FORBIDDEN",
            "claim": (
                "A general predictive law of chemical-label transportability "
                "has been demonstrated."
            )
        },
        {
            "claim_id": "D2A5-C4",
            "status": "FORBIDDEN",
            "claim": "The original seven-of-nine predictive gate passed."
        }
    ]
    write_csv(
        out / "tables/stage6d2a5_claim_ledger.csv",
        ["claim_id", "status", "claim"],
        claim_rows
    )

    diagnostics_ready = bool(
        prereq_ready and panel_ready and group_ready
        and bootstrap_ready and permutation_ready
    )
    remaining = []
    if not prereq_ready:
        remaining.append({
            "gate": "STAGE6D2A4_PREREQUISITE_READY",
            "required_action": "Restore a PASS Stage-6D2A4 validation."
        })
    if not panel_ready:
        remaining.append({
            "gate": "FIVE_LABEL_VALID_PANEL_READY",
            "required_action": (
                "The valid panel must contain all five amended labels."
            )
        })
    if not group_ready:
        remaining.append({
            "gate": "WITHIN_LABEL_FOLD_GROUPS_READY",
            "required_action": (
                f"At least {cfg['minimum_valid_groups']} label-fold groups "
                "must have the minimum number of valid cells."
            )
        })
    if not bootstrap_ready:
        remaining.append({
            "gate": "GROUP_BOOTSTRAP_READY",
            "required_action": (
                "Fewer than 90% of requested bootstrap draws were valid."
            )
        })
    if not permutation_ready:
        remaining.append({
            "gate": "WITHIN_GROUP_PERMUTATION_READY",
            "required_action": "Permutation draw count is incomplete."
        })
    write_csv(
        out / "tables/stage6d2a5_remaining_items.csv",
        ["gate", "required_action"],
        remaining
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "panel_file": safe_rel(panel_path, root),
        "panel_sha256": sha256_file(panel_path),
        "valid_panel_rows": len(frame),
        "valid_label_fold_groups": len(group_rows),
        "labels": sorted(frame["label"].unique().tolist()),
        "median_group_spearman": median_group_rho,
        "positive_group_fraction": positive_group_fraction,
        "negative_group_fraction": negative_group_fraction,
        "pooled_beta_B_atmos": beta_B,
        "pooled_regression_mae_logQ": regression_mae,
        "bootstrap_probability_beta_positive": (
            bootstrap_probability_positive
        ),
        "bootstrap_probability_beta_negative": (
            bootstrap_probability_negative
        ),
        "bootstrap_beta_q025": bootstrap_q025,
        "bootstrap_beta_q50": bootstrap_q50,
        "bootstrap_beta_q975": bootstrap_q975,
        "positive_label_jackknife_fraction": (
            positive_jackknife_fraction
        ),
        "negative_label_jackknife_fraction": (
            negative_jackknife_fraction
        ),
        "permutation_p_two_sided": permutation_p,
        "association_class": association_class,
        "figure_files": [
            safe_rel(Path(path), root) for path in figure_paths
        ],
        "prior_stage_outputs_modified": False,
        "STAGE6D2A4_PREREQUISITE_READY": prereq_ready,
        "FIVE_LABEL_VALID_PANEL_READY": panel_ready,
        "WITHIN_LABEL_FOLD_ASSOCIATION_READY": group_ready,
        "SUPPORT_ADJUSTED_REGRESSION_READY": math.isfinite(beta_B),
        "LABEL_JACKKNIFE_READY": len(jackknife_rows) == len(cfg["labels"]),
        "GROUP_BOOTSTRAP_READY": bootstrap_ready,
        "WITHIN_GROUP_PERMUTATION_READY": permutation_ready,
        "STAGE6D2A5_DIAGNOSTICS_READY": diagnostics_ready,
        "PREDICTIVE_LAW_CLAIM_FORBIDDEN": True,
        "SEVEN_OF_NINE_GATE_STATUS_NOT_TESTABLE": True,
        "STAGE6D3_FOOTPRINT_PROTOCOL_READY": diagnostics_ready
    }
    write_json(
        out / "validation/stage6d2a5_validation.json",
        validation
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "association_class": association_class,
        "primary_diagnostics": {
            "median_group_spearman": median_group_rho,
            "positive_group_fraction": positive_group_fraction,
            "negative_group_fraction": negative_group_fraction,
            "permutation_p_two_sided": permutation_p
        },
        "secondary_diagnostics": {
            "pooled_beta_B_atmos": beta_B,
            "bootstrap_probability_beta_positive": (
                bootstrap_probability_positive
            ),
            "bootstrap_probability_beta_negative": (
                bootstrap_probability_negative
            ),
            "positive_label_jackknife_fraction": (
                positive_jackknife_fraction
            ),
            "negative_label_jackknife_fraction": (
                negative_jackknife_fraction
            )
        },
        "claim_boundary": cfg["claim_boundary"],
        "remaining_items": remaining,
        "scientific_disposition": (
            "Five-label descriptive diagnostics are complete. The association "
            "class may be reported only as an exploratory result within the "
            "tested overlap support. Stage-6D3 footprint protocol is authorized."
            if diagnostics_ready else
            "Descriptive diagnostics remain incomplete. Do not integrate a "
            "transportability association claim."
        )
    }
    write_json(
        out / "summaries/stage6d2a5_summary.json",
        summary
    )

    report = [
        "# Stage-6D2A5 five-label descriptive diagnostics",
        "",
        f"- Valid panel rows: `{len(frame)}`",
        f"- Valid label-fold groups: `{len(group_rows)}`",
        f"- Median within-group Spearman rho: `{median_group_rho:.6f}`",
        f"- Positive group fraction: `{positive_group_fraction:.6f}`",
        f"- Pooled beta(B_atmos): `{beta_B:.6f}`",
        f"- Bootstrap P(beta>0): `{bootstrap_probability_positive:.6f}`",
        f"- Label-jackknife positive fraction: `{positive_jackknife_fraction:.6f}`",
        f"- Permutation p-value: `{permutation_p:.6f}`",
        f"- Association class: `{association_class}`",
        "",
        "This is an exploratory five-label result. It cannot establish a "
        "general predictive law, and the original seven-of-nine gate remains "
        "not testable.",
        ""
    ]
    (
        out / "reports/stage6d2a5_five_label_descriptive_diagnostics.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
