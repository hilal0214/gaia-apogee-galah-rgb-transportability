from __future__ import annotations
import argparse,hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
import numpy as np,pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def canonical_sha(o):
    return hashlib.sha256(json.dumps(
        o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False
    ).encode()).hexdigest()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage7b2b_config.json").read_text())
    out=root/c["output_dir"]
    if out.exists():shutil.rmtree(out)
    for d in ["validation","freeze","tables","reports","manifest"]:
        (out/d).mkdir(parents=True,exist_ok=True)

    va=json.loads((root/c["stage7a_validation"]).read_text())
    pa=json.loads((root/c["stage7a_protocol"]).read_text())
    vb=json.loads((root/c["stage7b1_validation"]).read_text())
    vc=json.loads((root/c["stage7b2a_validation"]).read_text())
    sm=pd.read_csv(root/c["stage7b2a_summary"], keep_default_na=False, na_values=["", "NaN", "nan"])
    rp=pd.read_csv(root/c["stage7b2a_replicates"], keep_default_na=False, na_values=["", "NaN", "nan"])
    amend=json.loads((root/"protocol/stage7b2b_amendment.json").read_text())

    identity=bool(
        va.get("STAGE7A_PROTOCOL_FROZEN") and
        va.get("protocol_canonical_sha256")==c["expected_stage7a_protocol_sha256"] and
        canonical_sha(pa)==c["expected_stage7a_protocol_sha256"] and
        vb.get("STAGE7B1_PREFLIGHT_READY") and
        vb.get("stage7b1_operational_closure_canonical_sha256")==c["expected_stage7b1_closure_sha256"] and
        vc.get("STAGE7B2A_PILOT_READY") and
        vc.get("PILOT_PROTOCOL_CANONICAL_SHA256")==c["expected_pilot_protocol_sha256"] and
        vc.get("REAL_FEH_M1_BREAK_FIT_PERFORMED") is False and
        vb.get("REAL_FEH_M1_BREAK_FIT_PERFORMED") is False
    )

    expected={"NULL","TARGET_R6P0_D005","TARGET_R6P5_D005"}
    pilot_shape=bool(len(rp)==48 and set(sm["scenario"])==expected)
    q=dict(zip(sm["scenario"],sm["median_cv_improvement_median"]))
    wald=dict(zip(sm["scenario"],sm["wald_excludes_zero_fraction"]))
    boundary=dict(zip(sm["scenario"],sm["boundary_flag_fraction"]))
    target_scale=bool(
        abs(float(q["NULL"]))<0.005 and
        0.0<float(q["TARGET_R6P0_D005"])<0.02 and
        0.0<float(q["TARGET_R6P5_D005"])<0.02
    )
    wald_signal=bool(
        float(wald["TARGET_R6P0_D005"])>=0.5 and
        float(wald["TARGET_R6P5_D005"])>=0.5
    )
    original_gate_never_passed=bool((rp["median_outer_cv_improvement"]<0.05).all())
    real_m1_never_fit=bool(
        vb.get("REAL_FEH_M1_BREAK_FIT_PERFORMED") is False and
        vc.get("REAL_FEH_M1_BREAK_FIT_PERFORMED") is False
    )

    # Preserve parent values explicitly.
    lineage={
      "stage7a_protocol_canonical_sha256":c["expected_stage7a_protocol_sha256"],
      "stage7b1_operational_closure_canonical_sha256":c["expected_stage7b1_closure_sha256"],
      "stage7b2a_pilot_protocol_canonical_sha256":c["expected_pilot_protocol_sha256"],
      "stage7b2b_amendment_canonical_sha256":canonical_sha(amend)
    }
    write_json(out/"freeze/stage7b2b_protocol_lineage.json",lineage)
    shutil.copy2(root/"protocol/stage7b2b_amendment.json",
                 out/"freeze/stage7b2b_amendment_frozen.json")
    # Also copy original parent protocol untouched.
    shutil.copy2(root/c["stage7a_protocol"],out/"freeze/stage7a_parent_protocol_unchanged.json")

    diagnostics=sm[[
        "scenario","replicates","injected_break_kpc","injected_delta_beta",
        "detection_fraction","median_cv_improvement_median",
        "median_cv_improvement_q16","median_cv_improvement_q84",
        "wald_excludes_zero_fraction","boundary_flag_fraction",
        "median_abs_break_error_kpc"
    ]].copy()
    diagnostics.to_csv(out/"tables/stage7b2b_pilot_trigger_diagnostics.csv",index=False)

    # Formal design table, no synthetic outcomes.
    rows=[]
    for rb in amend["formal_stage7b2_signed_injection_design"]["break_locations_kpc"]:
        for mag in amend["formal_stage7b2_signed_injection_design"]["break_strength_magnitudes_dex_per_kpc"]:
            for sign in amend["formal_stage7b2_signed_injection_design"]["signs"]:
                rows.append({
                    "scenario":f"RB{rb:.1f}_D{sign*mag:+.2f}",
                    "R_break_kpc":rb,
                    "delta_beta":sign*mag,
                    "replicates":amend["formal_stage7b2_signed_injection_design"]["replicates_per_signed_scenario"],
                    "target_power_gate":bool(rb in [6.0,6.5] and abs(mag-0.05)<1e-12)
                })
    design=pd.DataFrame(rows)
    design.to_csv(out/"tables/stage7b2b_formal_signed_injection_design.csv",index=False)

    design_ready=bool(
        len(design)==24 and
        int(design["replicates"].sum())==3072 and
        int(amend["formal_stage7b2_signed_injection_design"]["total_formal_replicates"])==3328 and
        int(design["target_power_gate"].sum())==4
    )

    ready=bool(identity and pilot_shape and target_scale and wald_signal and
               original_gate_never_passed and real_m1_never_fit and design_ready)

    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],
      "timestamp_utc":now(),
      "PARENT_PROTOCOL_LINEAGE_IDENTITY_READY":identity,
      "PILOT_48_REPLICATE_IDENTITY_READY":pilot_shape,
      "REAL_FEH_M1_BREAK_FIT_HAS_NEVER_BEEN_PERFORMED":real_m1_never_fit,
      "SYNTHETIC_TARGET_CV_EFFECT_SCALE_DIAGNOSTIC_READY":target_scale,
      "SYNTHETIC_TARGET_WALD_SIGNAL_DIAGNOSTIC_READY":wald_signal,
      "ORIGINAL_5PCT_ABSOLUTE_CV_GATE_PASSED_BY_ANY_PILOT_REPLICATE":not original_gate_never_passed,
      "ORIGINAL_5PCT_GATE_RETAINED_FOR_AUDIT_ONLY":True,
      "NULL_CALIBRATED_CV_PVALUE_GATE_FROZEN_READY":True,
      "FORMAL_NULL_REPLICATES":256,
      "FORMAL_SIGNED_INJECTION_SCENARIOS":24,
      "FORMAL_INJECTED_REPLICATES":3072,
      "FORMAL_TOTAL_REPLICATES":3328,
      "BOTH_BREAK_SIGNS_FROZEN_READY":design_ready,
      "ALL_FOUR_TARGET_SIGN_LOCATION_SCENARIOS_MUST_PASS_POWER_GATE":True,
      "FORMAL_FPR_THRESHOLD_UNCHANGED":0.05,
      "FORMAL_TARGET_POWER_THRESHOLD_UNCHANGED":0.80,
      "TARGET_BREAK_ERROR_THRESHOLD_UNCHANGED_KPC":0.5,
      "STAGE7C_4096_DRAW_FINAL_INFERENCE_UNCHANGED":True,
      "CLASSIFICATION_ENUM_UNCHANGED":True,
      "CLAIM_BOUNDARIES_UNCHANGED":True,
      "stage7b2b_amendment_canonical_sha256":canonical_sha(amend),
      "STAGE7B2B_OUTCOMEBLIND_AMENDMENT_READY":ready,
      "STAGE7B2_FULL_SIGNED_PRODUCTION_READY":ready,
      "STAGE7C_REAL_BREAK_FIT_AUTHORIZED":False
    }
    write_json(out/"validation/stage7b2b_validation.json",val)

    report=f"""# Stage-7B2B outcome-blind predictive-gate amendment

Amendment ready: `{ready}`

Trigger:
- no real Fe/H broken model has been fit;
- all 48 Stage-7B2A outcomes were synthetic;
- the original absolute 5% held-out-MAE improvement gate was passed by
  {int((rp['median_outer_cv_improvement']>=0.05).sum())}/48 pilot replicates;
- target injections nevertheless produced non-zero cluster-Wald evidence in
  {float(wald['TARGET_R6P0_D005']):.3f} and
  {float(wald['TARGET_R6P5_D005']):.3f} of the two target scenarios.

Amendment:
- retain the original 5% improvement gate in the audit trail;
- replace it as a formal detector with an empirical null-calibrated p-value
  for the same five-fold median spatial-CV improvement statistic;
- expand formal injection power calibration to both signs of delta_beta;
- keep the 5% false-positive, 80% target-power, 0.5-kpc break-error, and
  Stage-7C 4096-draw inference requirements unchanged.

Formal Stage-7B2 design after amendment:
- 256 null replicates;
- 24 signed break scenarios x 128 = 3072 injected replicates;
- total = 3328 replicates.

Stage-7C remains forbidden until formal Stage-7B2 passes.
"""
    (out/"reports/stage7b2b_report.md").write_text(report,encoding="utf-8")

    manifest=[]
    for fp in sorted(out.rglob("*")):
        if fp.is_file() and "manifest" not in fp.parts:
            manifest.append({
                "path":str(fp.relative_to(root)).replace("\\","/"),
                "size_bytes":fp.stat().st_size,
                "sha256":sha_file(fp)
            })
    pd.DataFrame(manifest).to_csv(out/"manifest/stage7b2b_manifest_sha256.csv",index=False)
    print(json.dumps({"validation":val,"lineage":lineage},indent=2,ensure_ascii=False))
    return 0 if ready else 2

if __name__=="__main__": raise SystemExit(main())
