from __future__ import annotations
import argparse, csv, json, math, re, shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd
from scipy.optimize import minimize


def now():
    return datetime.now(timezone.utc).isoformat()


def rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def wjson(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def wcsv(path: Path, fields, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as h:
        w = csv.DictWriter(h, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def resolve(path: Path):
    for q in [path, path.with_suffix(".csv"), path.with_suffix(".feather")]:
        if q.exists():
            return q
    return None


def read_table(path: Path):
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower() == ".feather":
        return pd.read_feather(path)
    return pd.read_csv(path)


def weighted_mean(x, w):
    x = np.asarray(x, float)
    w = np.asarray(w, float)
    ok = np.isfinite(x) & np.isfinite(w) & (w > 0)
    if not np.any(ok):
        return np.nan
    return float(np.sum(x[ok] * w[ok]) / np.sum(w[ok]))


def weighted_var(x, w):
    x = np.asarray(x, float)
    w = np.asarray(w, float)
    ok = np.isfinite(x) & np.isfinite(w) & (w > 0)
    if np.sum(ok) < 2:
        return np.nan
    x = x[ok]
    w = w[ok]
    m = np.sum(x*w)/np.sum(w)
    return float(np.sum(w*(x-m)**2)/np.sum(w))


def feature_smd(frame, field, weight_field, cfg):
    x = pd.to_numeric(frame[field], errors="coerce").to_numpy(float)
    w = pd.to_numeric(frame[weight_field], errors="coerce").to_numpy(float)
    a = (frame["survey"] == cfg["apogee_label"]).to_numpy()
    g = (frame["survey"] == cfg["galah_label"]).to_numpy()
    ma = weighted_mean(x[a], w[a])
    mg = weighted_mean(x[g], w[g])
    va = weighted_var(x[a], w[a])
    vg = weighted_var(x[g], w[g])
    psd = math.sqrt(.5*(va+vg)) if np.isfinite(va) and np.isfinite(vg) else np.nan
    s = (mg-ma)/psd if np.isfinite(psd) and psd > 0 else np.nan
    return {
        "feature": field,
        "APOGEE_mean": ma,
        "GALAH_mean": mg,
        "pooled_sd": psd,
        "smd_GALAH_minus_APOGEE": s,
        "absolute_smd": abs(s) if np.isfinite(s) else np.nan,
    }


def ess(weights):
    w = np.asarray(weights, float)
    w = w[np.isfinite(w) & (w > 0)]
    if len(w) == 0:
        return 0.0
    d = np.sum(w*w)
    return float((np.sum(w)**2)/d) if d > 0 else 0.0


def protocol_semantics(root: Path, cfg):
    rows = []
    explicit_screen = False
    explicit_terminal = False
    for rr in cfg["protocol_search_roots"]:
        b = root/rr
        if not b.exists():
            continue
        items = [b] if b.is_file() else b.rglob("*")
        for p in items:
            if (
                not p.is_file()
                or p.suffix.lower() not in set(cfg["protocol_text_suffixes"])
                or p.stat().st_size > int(cfg["maximum_protocol_file_bytes"])
            ):
                continue
            try:
                lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
            except Exception:
                continue
            for i, line in enumerate(lines, 1):
                low = line.lower()
                if not (
                    ("propensity" in low or "overlap" in low)
                    and ("0.05" in low or "0p05" in low)
                    and ("0.95" in low or "0p95" in low)
                ):
                    continue
                pos = any(tok in low for tok in cfg["screen_semantic_positive_tokens"])
                neg = any(tok in low for tok in cfg["screen_semantic_negative_tokens"])
                explicit_screen |= pos and not neg
                explicit_terminal |= neg
                rows.append({
                    "path": rel(p, root),
                    "line_number": i,
                    "screen_semantic_evidence": pos and not neg,
                    "terminal_gate_evidence": neg,
                    "excerpt": line.strip()[:1500],
                })
    return explicit_screen, explicit_terminal, rows


def build_cell_geometry(frame: pd.DataFrame, cfg):
    """
    For each cell, normalize p99-capped weights separately within each survey.
    Cell target t_c is then assigned to each survey, preserving exact equal
    survey total per cell. Feature differences d_ck are the survey-specific
    within-cell weighted mean contrasts.
    """
    cells = []
    rows = []
    for cell, group in frame.groupby(cfg["cell_field"], sort=True):
        rec = {"cell": cell}
        means = {}
        totals = {}
        valid = True
        for survey in cfg["surveys"]:
            g = group[group["survey"] == survey]
            w = pd.to_numeric(g[cfg["capped_weight_field"]], errors="coerce").to_numpy(float)
            total = float(np.nansum(w))
            totals[survey] = total
            if total <= 0 or len(g) == 0:
                valid = False
                break
            means[survey] = {}
            for feature in cfg["feature_fields"]:
                means[survey][feature] = weighted_mean(
                    pd.to_numeric(g[feature], errors="coerce").to_numpy(float),
                    w,
                )
        if not valid:
            continue
        baseline = .5*(totals[cfg["apogee_label"]] + totals[cfg["galah_label"]])
        d = np.array([
            means[cfg["galah_label"]][f] - means[cfg["apogee_label"]][f]
            for f in cfg["feature_fields"]
        ], float)
        cells.append({
            "cell": cell,
            "baseline_target": baseline,
            "difference": d,
        })
        rec.update({
            "baseline_target": baseline,
            "APOGEE_capped_total": totals[cfg["apogee_label"]],
            "GALAH_capped_total": totals[cfg["galah_label"]],
        })
        for j, f in enumerate(cfg["feature_fields"]):
            rec[f"delta_{f}"] = float(d[j])
        rows.append(rec)
    return cells, rows


def entropy_calibrate_targets(cells, cfg):
    if not cells:
        return None
    t0 = np.array([c["baseline_target"] for c in cells], float)
    D = np.vstack([c["difference"] for c in cells]).astype(float)

    # Scale moments for numerical stability, but preserve exact zero constraints.
    scale = np.nanstd(D, axis=0)
    scale[~np.isfinite(scale) | (scale <= 0)] = 1.0
    Ds = D / scale
    total0 = float(np.sum(t0))
    lower = np.maximum(
        t0 * float(cfg["entropy_min_target_fraction_of_baseline"]),
        1e-12,
    )

    def objective(t):
        ratio = t / t0
        return float(np.sum(t*np.log(ratio) - t + t0))

    def gradient(t):
        return np.log(t/t0)

    constraints = [{
        "type": "eq",
        "fun": lambda t: np.array([np.sum(t)-total0]),
    }]
    for j in range(Ds.shape[1]):
        constraints.append({
            "type": "eq",
            "fun": lambda t, j=j: np.array([np.dot(t, Ds[:,j])]),
        })

    res = minimize(
        objective,
        t0.copy(),
        jac=gradient,
        method="SLSQP",
        bounds=[(float(lo), None) for lo in lower],
        constraints=constraints,
        options={
            "maxiter": int(cfg["optimizer_maxiter"]),
            "ftol": float(cfg["optimizer_ftol"]),
            "disp": False,
        },
    )
    t = res.x
    moments = D.T @ t
    normalized_moments = moments / max(np.sum(t), 1e-30)
    ready = bool(
        res.success
        and np.all(np.isfinite(t))
        and np.all(t > 0)
        and np.max(np.abs(normalized_moments))
        <= float(cfg["moment_tolerance"])
    )
    return {
        "success": bool(res.success),
        "message": str(res.message),
        "targets": t,
        "baseline": t0,
        "D": D,
        "normalized_moments": normalized_moments,
        "ready": ready,
        "objective": float(res.fun),
    }


def apply_targets(frame: pd.DataFrame, cells, calibration, cfg, output_field):
    frame = frame.copy().reset_index(drop=True)
    frame[output_field] = np.nan
    target_map = {
        c["cell"]: float(t)
        for c, t in zip(cells, calibration["targets"])
    }
    target_rows = []
    for cell, group_indices in frame.groupby(cfg["cell_field"], sort=True).groups.items():
        if cell not in target_map:
            continue
        idx = np.asarray(list(group_indices), int)
        target = target_map[cell]
        survey_arr = frame.loc[idx, "survey"].astype(str).to_numpy()
        base = pd.to_numeric(
            frame.loc[idx, cfg["capped_weight_field"]],
            errors="coerce",
        ).to_numpy(float)
        final_local = np.full(len(idx), np.nan)
        factors = {}
        for survey in cfg["surveys"]:
            m = survey_arr == survey
            total = float(np.nansum(base[m]))
            if total <= 0:
                continue
            factor = target/total
            final_local[m] = base[m]*factor
            factors[survey] = factor
        frame.loc[idx, output_field] = final_local
        target_rows.append({
            "cell": cell,
            "baseline_target": float(
                next(c["baseline_target"] for c in cells if c["cell"] == cell)
            ),
            "calibrated_target": target,
            "target_ratio": target / float(
                next(c["baseline_target"] for c in cells if c["cell"] == cell)
            ),
            "APOGEE_factor": factors.get(cfg["apogee_label"], np.nan),
            "GALAH_factor": factors.get(cfg["galah_label"], np.nan),
        })
    return frame, target_rows


def evaluate(frame, weight_field, cfg, raw_denominator_counts):
    smd_rows = [
        feature_smd(frame, f, weight_field, cfg)
        for f in cfg["feature_fields"]
    ]
    max_smd = max(
        [r["absolute_smd"] for r in smd_rows if np.isfinite(r["absolute_smd"])],
        default=np.nan,
    )
    ratios = {}
    ess_rows = []
    for survey in cfg["surveys"]:
        m = frame["survey"] == survey
        e = ess(frame.loc[m, weight_field].to_numpy(float))
        denom = int(raw_denominator_counts[survey])
        ratio = e/denom if denom else 0.0
        ratios[survey] = ratio
        ess_rows.append({
            "survey": survey,
            "raw_denominator_rows": denom,
            "effective_sample_size": e,
            "ess_raw_ratio": ratio,
        })
    return max_smd, ratios, smd_rows, ess_rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root/"config/stage6d3c2_config.json").read_text(encoding="utf-8")
    )
    out = root/cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in ["validation","tables","diagnostic","summaries","reports"]:
        (out/d).mkdir(parents=True, exist_ok=True)

    pp = root/cfg["prerequisite_validation"]
    pre = json.loads(pp.read_text()) if pp.exists() else {}
    prereq = bool(
        pre.get("STAGE6D3C1_FAILURE_LOCALIZATION_READY", False)
        and pre.get("NO_FROZEN_THRESHOLD_WEAKENED", False)
        and pre.get("NO_SCIENCE_MODEL_AUTHORIZED", False)
        and pre.get("failure_classification") == "CELL_EQUALIZATION_REINTRODUCES_GLOBAL_IMBALANCE"
    )

    sp = resolve(root/cfg["balanced_source"])
    if not sp:
        raise FileNotFoundError("D3C balanced source not found")
    frame = read_table(sp).reset_index(drop=True)

    screen_explicit, terminal_explicit, protocol_rows = protocol_semantics(root, cfg)
    wcsv(
        out/"tables/stage6d3c2_propensity_protocol_semantics.csv",
        ["path","line_number","screen_semantic_evidence","terminal_gate_evidence","excerpt"],
        protocol_rows,
    )

    raw_counts_all = {
        s:int((frame["survey"]==s).sum()) for s in cfg["surveys"]
    }

    scenarios = []

    def run_scenario(name, scenario_frame, positivity_screen_applied):
        scenario_frame = scenario_frame.copy().reset_index(drop=True)
        cells, geometry_rows = build_cell_geometry(scenario_frame, cfg)
        cal = entropy_calibrate_targets(cells, cfg)
        if cal is None:
            return {
                "name":name, "ready":False, "reason":"no valid cells"
            }, None, [], [], [], []
        calibrated, target_rows = apply_targets(
            scenario_frame, cells, cal, cfg, "entropy_cell_equalized_weight"
        )
        raw_counts = {
            s:int((scenario_frame["survey"]==s).sum()) for s in cfg["surveys"]
        }
        max_smd, ess_ratios, smd_rows, ess_rows = evaluate(
            calibrated,
            "entropy_cell_equalized_weight",
            cfg,
            raw_counts,
        )
        p = pd.to_numeric(calibrated[cfg["propensity_field"]], errors="coerce")
        prop_pass = bool(
            p.between(
                float(cfg["propensity_lower_gate"]),
                float(cfg["propensity_upper_gate"]),
                inclusive="both",
            ).all()
        )
        smd_pass = bool(
            np.isfinite(max_smd)
            and max_smd <= float(cfg["maximum_absolute_smd_gate"])
        )
        ess_pass = all(
            x >= float(cfg["minimum_ess_raw_ratio_gate"])
            for x in ess_ratios.values()
        )
        ready = bool(cal["ready"] and prop_pass and smd_pass and ess_pass)
        result = {
            "name": name,
            "rows": len(calibrated),
            "rows_by_survey": raw_counts,
            "cell_count": len(cells),
            "positivity_screen_applied": positivity_screen_applied,
            "optimizer_success": cal["success"],
            "entropy_moment_ready": cal["ready"],
            "maximum_absolute_smd": max_smd,
            "ess_raw_ratio_by_survey": ess_ratios,
            "propensity_gate_pass": prop_pass,
            "smd_gate_pass": smd_pass,
            "ess_gate_pass": ess_pass,
            "all_frozen_gates_pass": ready,
            "maximum_absolute_normalized_moment": float(
                np.max(np.abs(cal["normalized_moments"]))
            ),
            "optimizer_message": cal["message"],
        }
        return result, calibrated, geometry_rows, target_rows, smd_rows, ess_rows

    # Scenario A: no propensity screening, isolates cell-target geometry only.
    a, a_frame, a_geom, a_targets, a_smd, a_ess = run_scenario(
        "A_all_rows_entropy_cell_targets", frame, False
    )
    scenarios.append(a)

    # Scenario B: frozen-range screen as diagnostic counterfactual.
    p = pd.to_numeric(frame[cfg["propensity_field"]], errors="coerce")
    inside = p.between(
        float(cfg["propensity_lower_gate"]),
        float(cfg["propensity_upper_gate"]),
        inclusive="both",
    )
    screened = frame.loc[inside].copy()
    b, b_frame, b_geom, b_targets, b_smd, b_ess = run_scenario(
        "B_propensity_screen_plus_entropy_cell_targets", screened, True
    )
    scenarios.append(b)

    # Persist diagnostics.
    wcsv(
        out/"diagnostic/stage6d3c2_scenario_summary.csv",
        [
            "name","rows","rows_by_survey","cell_count",
            "positivity_screen_applied","optimizer_success",
            "entropy_moment_ready","maximum_absolute_smd",
            "ess_raw_ratio_by_survey","propensity_gate_pass",
            "smd_gate_pass","ess_gate_pass","all_frozen_gates_pass",
            "maximum_absolute_normalized_moment","optimizer_message"
        ],
        scenarios,
    )
    if a_smd:
        wcsv(
            out/"diagnostic/stage6d3c2_scenarioA_smd.csv",
            ["feature","APOGEE_mean","GALAH_mean","pooled_sd","smd_GALAH_minus_APOGEE","absolute_smd"],
            a_smd,
        )
    if b_smd:
        wcsv(
            out/"diagnostic/stage6d3c2_scenarioB_smd.csv",
            ["feature","APOGEE_mean","GALAH_mean","pooled_sd","smd_GALAH_minus_APOGEE","absolute_smd"],
            b_smd,
        )
    if a_targets:
        wcsv(
            out/"diagnostic/stage6d3c2_scenarioA_cell_targets.csv",
            ["cell","baseline_target","calibrated_target","target_ratio","APOGEE_factor","GALAH_factor"],
            a_targets,
        )
    if b_targets:
        wcsv(
            out/"diagnostic/stage6d3c2_scenarioB_cell_targets.csv",
            ["cell","baseline_target","calibrated_target","target_ratio","APOGEE_factor","GALAH_factor"],
            b_targets,
        )
    if a_ess:
        wcsv(
            out/"diagnostic/stage6d3c2_scenarioA_ess.csv",
            ["survey","raw_denominator_rows","effective_sample_size","ess_raw_ratio"],
            a_ess,
        )
    if b_ess:
        wcsv(
            out/"diagnostic/stage6d3c2_scenarioB_ess.csv",
            ["survey","raw_denominator_rows","effective_sample_size","ess_raw_ratio"],
            b_ess,
        )

    scenarioA_balance_repaired = bool(a.get("smd_gate_pass", False) and a.get("ess_gate_pass", False))
    scenarioB_all_pass = bool(b.get("all_frozen_gates_pass", False))

    if scenarioA_balance_repaired and not a.get("propensity_gate_pass", False):
        geometry_class = "CELL_TARGET_GEOMETRY_REPAIR_WORKS_BUT_PROPENSITY_SEMANTICS_REMAIN"
    elif scenarioA_balance_repaired:
        geometry_class = "CELL_TARGET_GEOMETRY_REPAIR_FULLY_WORKS"
    else:
        geometry_class = "ENTROPY_CELL_TARGET_RECALIBRATION_INSUFFICIENT"

    if screen_explicit:
        propensity_semantics = "EXPLICIT_SUPPORT_SCREEN_FOUND"
    elif terminal_explicit:
        propensity_semantics = "EXPLICIT_TERMINAL_GATE_FOUND"
    else:
        propensity_semantics = "FROZEN_PROPENSITY_OPERATION_SEMANTICS_AMBIGUOUS"

    repair_candidate_ready = bool(
        prereq
        and scenarioB_all_pass
        and screen_explicit
    )

    if repair_candidate_ready:
        next_action = (
            "Freeze D3C3 production semantics exactly as documented: apply the "
            "explicit [0.05,0.95] support screen, then entropy-calibrate positive "
            "cell targets while preserving equal survey totals per retained cell."
        )
    elif scenarioB_all_pass and not screen_explicit:
        next_action = (
            "The mathematical repair passes all gates diagnostically, but the "
            "original frozen files do not explicitly establish that propensity "
            "[0.05,0.95] is a production screen. Create a claim-safe protocol "
            "clarification/amendment before any production rerun."
        )
    elif scenarioA_balance_repaired:
        next_action = (
            "Entropy cell-target calibration repairs the SMD/ESS geometry, but "
            "the propensity gate remains unresolved. Reconcile the exact frozen "
            "meaning of the [0.05,0.95] rule before production."
        )
    else:
        next_action = (
            "Even protocol-safe entropy cell-target calibration is insufficient. "
            "Do not proceed to D4; the common-support/balancing design requires "
            "a higher-level frozen-protocol review."
        )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "STAGE6D3C1_PREREQUISITE_READY": prereq,
        "propensity_operation_semantics": propensity_semantics,
        "PROPENSITY_SCREEN_SEMANTICS_EXPLICIT": screen_explicit,
        "PROPENSITY_TERMINAL_GATE_SEMANTICS_EXPLICIT": terminal_explicit,
        "cell_target_geometry_classification": geometry_class,
        "scenario_A": a,
        "scenario_B": b,
        "SCENARIO_A_SMD_ESS_REPAIRED": scenarioA_balance_repaired,
        "SCENARIO_B_ALL_FROZEN_GATES_PASS_DIAGNOSTICALLY": scenarioB_all_pass,
        "EQUAL_SURVEY_TOTAL_PER_CELL_PRESERVED": True,
        "ENTROPY_TARGETS_POSITIVE_BY_CONSTRUCTION": True,
        "NO_BALANCING_FEATURE_CHANGED": True,
        "NO_FROZEN_THRESHOLD_WEAKENED": True,
        "NO_ABUNDANCE_R_ABSZ_OUTCOME_USED": True,
        "PRODUCTION_REPAIR_CANDIDATE_READY": repair_candidate_ready,
        "DIAGNOSTIC_ONLY": True,
        "STAGE6D3C2_RECONCILIATION_READY": prereq,
        "STAGE6D4_SCIENCE_MODELS_READY": False,
    }
    wjson(out/"validation/stage6d3c2_validation.json", validation)

    summary = {
        "stage": cfg["stage"],
        "propensity_semantics": propensity_semantics,
        "cell_target_geometry": geometry_class,
        "scenario_A": a,
        "scenario_B": b,
        "next_action": next_action,
        "scientific_disposition": (
            "D3C1 proved that arithmetic-mean cell targets, not overlap weighting, "
            "reintroduced global imbalance. D3C2 tests a positive entropy projection "
            "that preserves equal survey totals per cell. Results remain diagnostic "
            "until propensity-screen semantics are proven from the frozen protocol."
        ),
    }
    wjson(out/"summaries/stage6d3c2_summary.json", summary)

    (out/"reports/stage6d3c2_report.md").write_text(
        "\n".join([
            "# Stage-6D3C2 cell-target entropy/protocol reconciliation",
            "",
            f"- Propensity semantics: `{propensity_semantics}`",
            f"- Cell-target geometry: `{geometry_class}`",
            f"- Scenario A max |SMD|: `{a.get('maximum_absolute_smd')}`",
            f"- Scenario A all gates: `{a.get('all_frozen_gates_pass')}`",
            f"- Scenario B max |SMD|: `{b.get('maximum_absolute_smd')}`",
            f"- Scenario B all gates: `{b.get('all_frozen_gates_pass')}`",
            f"- Production repair candidate ready: `{repair_candidate_ready}`",
            "- Stage-6D4 authorized: `False`",
            "",
            next_action,
            "",
        ]),
        encoding="utf-8",
    )

    print(json.dumps({"validation":validation,"summary":summary}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
