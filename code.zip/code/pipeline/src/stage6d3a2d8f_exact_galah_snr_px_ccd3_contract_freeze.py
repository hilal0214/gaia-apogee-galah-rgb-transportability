from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

MAX_EXACT_FLOAT_INT = 9007199254740991


def now():
    return datetime.now(timezone.utc).isoformat()


def norm(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def resolve(path: Path):
    for candidate in [path, path.with_suffix(".csv"), path.with_suffix(".feather")]:
        if candidate.exists():
            return candidate
    return None


def read_columns(path: Path):
    if path.suffix.lower() == ".parquet":
        import pyarrow.parquet as pq
        f = pq.ParquetFile(path)
        return list(f.schema_arrow.names), int(f.metadata.num_rows)
    if path.suffix.lower() == ".feather":
        import pyarrow.feather as feather
        t = feather.read_table(path)
        return list(t.column_names), int(t.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def read_table(path: Path, columns=None, strings=None):
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path, columns=columns)
    if path.suffix.lower() == ".feather":
        return pd.read_feather(path, columns=columns)
    return pd.read_csv(
        path,
        usecols=columns,
        dtype={column: "string" for column in (strings or [])} or None,
    )


def find_alias(columns, aliases):
    lookup = {norm(c): c for c in columns}
    for alias in aliases:
        if norm(alias) in lookup:
            return lookup[norm(alias)]
    return None


def exact_uint64(series: pd.Series):
    out = pd.Series(pd.NA, index=series.index, dtype="UInt64")
    if pd.api.types.is_unsigned_integer_dtype(series.dtype):
        return series.astype("UInt64")
    if pd.api.types.is_integer_dtype(series.dtype):
        values = series.astype("Int64")
        ok = values.notna() & (values >= 0)
        if ok.any():
            out.loc[ok] = pd.array(
                values.loc[ok].astype("string"), dtype="UInt64"
            )
        return out
    if pd.api.types.is_float_dtype(series.dtype):
        values = pd.to_numeric(series, errors="coerce")
        ok = (
            values.notna()
            & np.isfinite(values)
            & (values == np.floor(values))
            & (values >= 0)
            & (values <= MAX_EXACT_FLOAT_INT)
        )
        if ok.any():
            out.loc[ok] = pd.array(
                values.loc[ok].astype("uint64").astype("string"),
                dtype="UInt64",
            )
        return out
    text = series.astype("string").str.strip()
    ok = text.str.fullmatch(r"[0-9]+", na=False)
    if ok.any():
        values = text.loc[ok].str.lstrip("0").mask(lambda x: x == "", "0")
        values = values.loc[values.str.len() <= 20]
        if len(values):
            out.loc[values.index] = pd.array(values, dtype="UInt64")
    return out


def source_level_product(frame, source_col, snr_col, cfg, lineage):
    source_id = exact_uint64(frame[source_col])
    snr = pd.to_numeric(frame[snr_col], errors="coerce")
    snr = snr.mask(
        ~np.isfinite(snr)
        | (snr <= float(cfg["snr_minimum_exclusive"]))
        | (snr > float(cfg["snr_maximum"]))
    )
    work = pd.DataFrame({
        "source_id": source_id,
        "snr_native": snr,
    }).dropna(subset=["source_id"])
    work["source_id"] = work["source_id"].astype("uint64")

    rows = []
    for source_id_value, group in work.groupby("source_id", sort=False):
        values = group["snr_native"].dropna().to_numpy(dtype=float)
        rows.append({
            "source_id": int(source_id_value),
            "survey": "GALAH_CORRECTED",
            "snr_native": float(np.median(values)) if len(values) else np.nan,
            "snr_measurement_count": int(len(values)),
            "snr_input_row_count": int(len(group)),
            "snr_contract": "GALAH_NATIVE_SNR_PX_CCD3",
            "snr_id_route": lineage,
        })
    return pd.DataFrame(rows)


def complete_mask(frame: pd.DataFrame):
    required = [
        "R", "abs_Z", "teff", "logg",
        "snr_native", "g_mag", "bp_rp"
    ]
    mask = pd.Series(True, index=frame.index)
    for field in required:
        if field not in frame.columns:
            return pd.Series(False, index=frame.index)
        mask &= frame[field].notna()
    sky = (
        (
            frame.get("l", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("b", pd.Series(pd.NA, index=frame.index)).notna()
        )
        |
        (
            frame.get("ra", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("dec", pd.Series(pd.NA, index=frame.index)).notna()
        )
    )
    return mask & sky


def percentile(series: pd.Series):
    out = pd.Series(np.nan, index=series.index, dtype=float)
    ok = series.notna()
    if ok.any():
        out.loc[ok] = series.loc[ok].rank(method="average", pct=True)
    return out


def provenance_audit(root: Path, cfg: dict[str, Any]):
    rows = []
    ready = True
    for relative_path, tokens in cfg["required_provenance_evidence"].items():
        path = root / relative_path
        text = ""
        if path.exists():
            text = path.read_text(encoding="utf-8", errors="replace")
        for token in tokens:
            found = token in text
            rows.append({
                "path": relative_path,
                "required_token": token,
                "found": found,
            })
            ready &= found
    return ready, rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2d8f_config.json").read_text(encoding="utf-8")
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in ["validation", "tables", "assembled", "freeze", "summaries", "reports"]:
        (out / d).mkdir(parents=True, exist_ok=True)

    prepath = root / cfg["prerequisite_validation"]
    pre = json.loads(prepath.read_text(encoding="utf-8")) if prepath.exists() else {}
    prerequisite_ready = bool(
        pre.get("STAGE6D3A2D8E_LINEAGE_TRACE_READY", False)
        and pre.get("EXACT_GAIA_DR3_IDENTITY_ALREADY_CLOSED", False)
        and pre.get("FROZEN_OVERLAP_GATES_UNCHANGED", False)
        and not pre.get("STAGE6D3B_COMMON_FOOTPRINT_READY", True)
    )

    provenance_ready, provenance_rows = provenance_audit(root, cfg)
    write_csv(
        out / "tables/stage6d3a2d8f_provenance_evidence_audit.csv",
        ["path", "required_token", "found"],
        provenance_rows,
    )

    anchor_path = resolve(root / cfg["canonical_anchor"])
    anchor = (
        read_table(anchor_path, strings=["source_id"])
        if anchor_path else pd.DataFrame()
    )
    anchor_ready = bool(
        not anchor.empty
        and {"source_id", "survey", "snr_native"}.issubset(anchor.columns)
    )
    if anchor_ready:
        parsed = exact_uint64(anchor["source_id"])
        keep = parsed.notna()
        anchor = anchor.loc[keep].copy()
        anchor["source_id"] = parsed.loc[keep].astype("uint64").to_numpy()
        anchor["_anchor_row_id"] = np.arange(len(anchor), dtype=np.int64)
    else:
        anchor["_anchor_row_id"] = np.arange(len(anchor), dtype=np.int64)

    galah_anchor_ids = set(
        anchor.loc[
            anchor["survey"] == "GALAH_CORRECTED", "source_id"
        ].astype("uint64")
    ) if anchor_ready else set()

    source_audit = []
    candidate_products = []

    for priority, relative_path in enumerate(cfg["source_priority"], start=1):
        path = resolve(root / relative_path)
        row = {
            "priority": priority,
            "path": relative_path,
            "exists": bool(path),
            "row_count": 0,
            "source_id_column": "",
            "snr_column": cfg["frozen_galah_snr_column"],
            "finite_source_snr_rows": 0,
            "anchor_overlap_rows": 0,
            "anchor_overlap_fraction": 0.0,
            "eligible": False,
            "read_error": "",
        }
        if not path:
            source_audit.append(row)
            continue
        try:
            columns, row_count = read_columns(path)
            row["row_count"] = row_count
            source_col = find_alias(columns, cfg["source_id_aliases"])
            if not source_col:
                raise RuntimeError("exact Gaia DR3 source-ID column not found")
            if cfg["frozen_galah_snr_column"] not in columns:
                raise RuntimeError(
                    f"required native field {cfg['frozen_galah_snr_column']} not found"
                )

            frame = read_table(
                path,
                [source_col, cfg["frozen_galah_snr_column"]],
                strings=[source_col],
            )
            product = source_level_product(
                frame,
                source_col,
                cfg["frozen_galah_snr_column"],
                cfg,
                lineage=f"direct_internal:{rel(path, root)}",
            )
            finite = product[product["snr_native"].notna()]
            finite_ids = set(finite["source_id"].astype("uint64"))
            overlap = galah_anchor_ids.intersection(finite_ids)
            fraction = len(overlap) / max(len(galah_anchor_ids), 1)
            eligible = bool(
                len(overlap) >= int(cfg["minimum_anchor_overlap_rows"])
                and fraction >= float(cfg["minimum_anchor_overlap_fraction"])
            )
            row.update({
                "path": rel(path, root),
                "source_id_column": source_col,
                "finite_source_snr_rows": len(finite_ids),
                "anchor_overlap_rows": len(overlap),
                "anchor_overlap_fraction": fraction,
                "eligible": eligible,
            })
            candidate_products.append({
                "priority": priority,
                "row": row,
                "product": product,
            })
        except Exception as exc:
            row["path"] = rel(path, root)
            row["read_error"] = f"{type(exc).__name__}: {exc}"
        source_audit.append(row)

    write_csv(
        out / "tables/stage6d3a2d8f_source_candidate_audit.csv",
        [
            "priority", "path", "exists", "row_count",
            "source_id_column", "snr_column",
            "finite_source_snr_rows", "anchor_overlap_rows",
            "anchor_overlap_fraction", "eligible", "read_error"
        ],
        source_audit,
    )

    eligible = [
        item for item in candidate_products
        if item["row"]["eligible"]
    ]
    eligible.sort(key=lambda item: item["priority"])
    selected = eligible[0] if eligible else None

    selected_rows = []
    if selected:
        selected_rows = [{
            **selected["row"],
            "selection_rule": (
                "frozen source-priority order after exact ID, native-field, "
                "and frozen overlap gates"
            ),
        }]
    write_csv(
        out / "tables/stage6d3a2d8f_selected_galah_snr_source.csv",
        [
            "priority", "path", "row_count", "source_id_column",
            "snr_column", "finite_source_snr_rows",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "eligible", "selection_rule"
        ],
        selected_rows,
    )

    final = anchor.copy()
    if selected:
        product = selected["product"].copy().set_index("source_id")
        galah_mask = final["survey"] == "GALAH_CORRECTED"
        keys = final.loc[galah_mask, "source_id"].astype("uint64")
        for field in [
            "snr_native", "snr_measurement_count",
            "snr_input_row_count", "snr_contract", "snr_id_route"
        ]:
            if field not in final.columns:
                final[field] = np.nan if field == "snr_native" else pd.NA
            mapping = (
                product[field]
                if field in product.columns
                else pd.Series(dtype=object)
            )
            final.loc[galah_mask, field] = keys.map(mapping).to_numpy()

    row_conservation_ready = bool(
        len(final) == len(anchor)
        and final["_anchor_row_id"].tolist() == anchor["_anchor_row_id"].tolist()
        and final["source_id"].astype("uint64").tolist()
        == anchor["source_id"].astype("uint64").tolist()
        and final["survey"].astype(str).tolist()
        == anchor["survey"].astype(str).tolist()
        and not final.duplicated(["source_id", "survey"]).any()
    )

    if "snr_native" not in final.columns:
        final["snr_native"] = np.nan

    final["snr_log1p_native"] = np.log1p(
        pd.to_numeric(final["snr_native"], errors="coerce").clip(lower=0)
    )
    final["snr_within_survey_percentile"] = np.nan
    final["snr_support_half"] = pd.Series(
        pd.NA, index=final.index, dtype="string"
    )
    medians = {}
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        mask = final["survey"] == survey
        values = pd.to_numeric(
            final.loc[mask, "snr_native"], errors="coerce"
        )
        final.loc[
            mask, "snr_within_survey_percentile"
        ] = percentile(values)
        median = float(values.median()) if values.notna().any() else np.nan
        medians[survey] = median
        if np.isfinite(median):
            low = mask & final["snr_native"].notna() & (
                pd.to_numeric(final["snr_native"], errors="coerce") <= median
            )
            high = mask & final["snr_native"].notna() & (
                pd.to_numeric(final["snr_native"], errors="coerce") > median
            )
            final.loc[low, "snr_support_half"] = "LOW_NATIVE_SNR_HALF"
            final.loc[high, "snr_support_half"] = "HIGH_NATIVE_SNR_HALF"

    support = complete_mask(final)
    complete_counts = {
        survey: int(
            ((final["survey"] == survey) & support).sum()
        )
        for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]
    }
    complete_ready = all(
        value >= int(cfg["minimum_complete_rows_per_survey"])
        for value in complete_counts.values()
    )

    selected_ready = selected is not None
    source_ready = bool(
        prerequisite_ready
        and provenance_ready
        and anchor_ready
        and selected_ready
        and row_conservation_ready
        and complete_ready
    )

    final_path = (
        out
        / "assembled/stage6d3a2d8f_production_source_with_frozen_galah_snr.parquet"
    )
    try:
        final.drop(columns=["_anchor_row_id"]).to_parquet(
            final_path, index=False
        )
    except Exception:
        final_path = final_path.with_suffix(".csv")
        final.drop(columns=["_anchor_row_id"]).to_csv(
            final_path, index=False
        )

    coverage_rows = []
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        subset = final[final["survey"] == survey]
        coverage_rows.append({
            "survey": survey,
            "anchor_rows": len(subset),
            "finite_snr_rows": int(subset["snr_native"].notna().sum()),
            "finite_snr_fraction": (
                float(subset["snr_native"].notna().mean())
                if len(subset) else 0.0
            ),
            "support_complete_rows": complete_counts[survey],
            "median_native_snr": medians[survey],
        })
    write_csv(
        out / "tables/stage6d3a2d8f_final_join_coverage.csv",
        [
            "survey", "anchor_rows", "finite_snr_rows",
            "finite_snr_fraction", "support_complete_rows",
            "median_native_snr"
        ],
        coverage_rows,
    )

    contract = {
        "survey": "GALAH_CORRECTED",
        "source_field": cfg["frozen_galah_snr_column"],
        "semantic_label": cfg["frozen_semantic_label"],
        "support_role": cfg["frozen_support_role"],
        "aggregation": cfg["aggregation"],
        "selected_source": (
            selected["row"]["path"] if selected else ""
        ),
        "interpretation_boundary": (
            "Use the exact GALAH field name snr_px_ccd3. Do not describe it "
            "as an all-detector median or as a survey-neutral S/N quantity."
        ),
        "support_transform": (
            "native value retained; within-survey percentile is allowed only "
            "for support matching/balancing"
        ),
        "frozen_overlap_gates": {
            "minimum_rows": cfg["minimum_anchor_overlap_rows"],
            "minimum_fraction": cfg["minimum_anchor_overlap_fraction"],
        },
        "provenance_evidence_ready": provenance_ready,
    }
    write_json(
        out / "freeze/stage6d3a2d8f_frozen_galah_snr_contract.json",
        contract,
    )

    remaining = []
    if not provenance_ready:
        remaining.append({
            "gate": "GALAH_SNR_PX_CCD3_PROVENANCE_READY",
            "required_action": (
                "Restore the Stage-1 ingest/config evidence for snr_px_ccd3."
            ),
        })
    if not selected_ready:
        remaining.append({
            "gate": "GALAH_SNR_PX_CCD3_SOURCE_READY",
            "required_action": (
                "No priority internal source with exact Gaia DR3 IDs and "
                "snr_px_ccd3 meets the frozen overlap gates."
            ),
        })
    if not row_conservation_ready:
        remaining.append({
            "gate": "FINAL_ROW_CONSERVATION_READY",
            "required_action": "Preserve the exact canonical D5 row universe.",
        })
    if selected_ready and row_conservation_ready and not complete_ready:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_COMPLETE_ROWS_READY",
            "required_action": (
                "At least 500 support-complete rows are required in each survey."
            ),
        })
    write_csv(
        out / "tables/stage6d3a2d8f_remaining_items.csv",
        ["gate", "required_action"],
        remaining,
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "frozen_galah_snr_column": cfg["frozen_galah_snr_column"],
        "frozen_semantic_label": cfg["frozen_semantic_label"],
        "selected_source": selected["row"]["path"] if selected else "",
        "selected_anchor_overlap_rows": (
            selected["row"]["anchor_overlap_rows"] if selected else 0
        ),
        "selected_anchor_overlap_fraction": (
            selected["row"]["anchor_overlap_fraction"] if selected else 0.0
        ),
        "survey_native_snr_medians": medians,
        "assembled_source_table": rel(final_path, root),
        "assembled_rows": len(final),
        "support_complete_rows_by_survey": complete_counts,
        "prior_stage_outputs_modified": False,
        "STAGE6D3A2D8E_PREREQUISITE_READY": prerequisite_ready,
        "CANONICAL_ANCHOR_READY": anchor_ready,
        "GALAH_SNR_PX_CCD3_PROVENANCE_READY": provenance_ready,
        "FALSE_NEGATIVE_ALIAS_DIAGNOSIS_CLOSED": True,
        "GALAH_SNR_PX_CCD3_SEMANTIC_CONTRACT_FROZEN": bool(
            provenance_ready and selected_ready
        ),
        "EXACT_GAIA_DR3_IDENTITY_ALREADY_CLOSED": True,
        "EXTERNAL_GAIA_ID_BRIDGE_ACQUISITION_REQUIRED": False,
        "SURVEY_NATIVE_SNR_SEMANTICS_PRESERVED": True,
        "ALL_DETECTOR_MEDIAN_INTERPRETATION_FORBIDDEN": True,
        "FINAL_ROW_CONSERVATION_READY": row_conservation_ready,
        "NATIVE_SNR_PRESERVED": selected_ready,
        "WITHIN_SURVEY_SNR_PERCENTILE_READY": selected_ready,
        "SURVEY_SPECIFIC_SNR_SUPPORT_READY": selected_ready,
        "PRODUCTION_SOURCE_COMPLETE_ROWS_READY": complete_ready,
        "PRODUCTION_SOURCE_ASSEMBLY_READY": source_ready,
        "FROZEN_OVERLAP_GATES_UNCHANGED": True,
        "TARGET_ABUNDANCE_MATCHING_FORBIDDEN": True,
        "STAGE6D3A2D8F_LINEAGE_READY": bool(
            prerequisite_ready
            and provenance_ready
            and anchor_ready
            and selected_ready
            and row_conservation_ready
        ),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": source_ready,
    }
    write_json(
        out / "validation/stage6d3a2d8f_validation.json",
        validation,
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": now(),
        "contract": contract,
        "source_assembly": {
            "rows": len(final),
            "support_complete_rows_by_survey": complete_counts,
            "row_conservation_ready": row_conservation_ready,
            "ready": source_ready,
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "The Stage-1 GALAH field snr_px_ccd3 is frozen by exact provenance "
            "and used only as the survey-native S/N support covariate. "
            "Canonical source assembly is complete and Stage-6D3B is authorized."
            if source_ready else
            "The exact snr_px_ccd3 semantic contract is audited, but D3B remains "
            "blocked by the listed source/support gate."
        ),
    }
    write_json(
        out / "summaries/stage6d3a2d8f_summary.json",
        summary,
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
