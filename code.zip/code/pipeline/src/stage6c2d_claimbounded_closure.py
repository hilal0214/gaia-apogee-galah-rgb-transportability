from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

STAGE = "Stage-6C2D claim-bounded manuscript closure computations"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.15.3"

ALIASES = {
    "label": ["label", "element", "quantity", "abundance", "chemical_label", "target_label"],
    "term": ["term", "coefficient_name", "parameter", "feature", "predictor"],
    "coefficient": ["coefficient", "estimate", "value", "beta", "coef"],
    "n_common": ["n_common", "n_overlap", "matched_count", "common_count", "pair_count", "rows", "n", "evaluation_rows", "heldout_rows"],
    "residual_median": ["residual_median", "median_residual", "heldout_median", "median"],
    "residual_mad": ["residual_mad", "mad_residual", "heldout_mad", "mad", "residual_scale"],
    "fold": ["fold", "fold_id", "cv_fold"],
    "metric": ["metric", "statistic", "summary_metric", "measure"],
    "metric_value": ["metric_value", "value", "statistic_value", "summary_value"],
    "population": ["population", "component", "class", "population_label", "component_name"],
    "sample": ["sample", "subset", "survey", "view", "cohort", "analysis_view", "survey_origin"],
    "n": ["n", "count", "n_stars", "rows", "assigned_n", "member_count", "hard_count", "assigned_count", "membership_count"],
    "secure_n": ["secure_n", "secure_count", "n_secure", "high_confidence_n", "confident_count"],
    "secure_fraction": ["secure_fraction", "secure_frac", "fraction_secure", "pmax_fraction", "secure_rate", "high_confidence_fraction"],
    "median_feh": ["median_feh", "median_fe_h", "feh_median", "median_metallicity"],
    "median_alpha": ["median_alpha", "median_alpha_fe", "alpha_median", "median_mg_fe"],
    "median_abs_z": ["median_abs_z", "median_z_abs", "abs_z_median", "median_z"],
    "median_vphi": ["median_vphi", "median_vphi_disk", "vphi_median", "median_rotation"],
    "median_pmax": ["median_pmax", "pmax_median", "median_max_probability"],
    "beta_r": ["beta_r", "b_r", "radial_gradient", "radial_slope", "gradient_r"],
    "beta_z": ["beta_z", "b_z", "vertical_gradient", "vertical_slope", "gradient_z"],
    "beta_r_lo": ["beta_r_q025", "beta_r_lo", "beta_r_lower", "radial_q025", "radial_low"],
    "beta_r_hi": ["beta_r_q975", "beta_r_hi", "beta_r_upper", "radial_q975", "radial_high"],
    "beta_z_lo": ["beta_z_q025", "beta_z_lo", "beta_z_lower", "vertical_q025", "vertical_low"],
    "beta_z_hi": ["beta_z_q975", "beta_z_hi", "beta_z_upper", "vertical_q975", "vertical_high"],
    "rows": ["rows", "n", "sample_size", "fit_rows"],
    "pivot": ["radial_pivot_kpc", "r0", "pivot_r", "radial_pivot"],
    "huber_scale": ["huber_scale", "huber_delta", "huber_tuning"],
    "r": ["r_kpc", "galcen_r", "galactocentric_r", "r_gal", "r"],
    "abs_z": ["abs_z", "z_abs", "galcen_abs_z", "abs_z_kpc", "z_kpc_abs"],
    "block": ["spatial_block", "block_id", "bootstrap_block", "spatial_block_id", "healpix_block"],
    "survey_origin": ["survey_origin", "origin", "source_survey", "primary_survey"],
    "has_apogee": ["has_apogee", "apogee_available", "in_apogee"],
    "has_galah": ["has_galah", "galah_available", "in_galah"],
    "overlap": ["is_overlap", "overlap", "apogee_galah_overlap", "has_both_surveys"],
    "pmax": ["pmax", "max_probability", "population_probability_max", "assignment_probability"],
}

TABLE_FILES = {
    "T01": "table01_sample_flow.tex",
    "T02": "table02_calibration.tex",
    "T03": "table03_global_gradients.tex",
    "T04": "table04_population_summary.tex",
    "T05": "table05_population_gradients.tex",
    "T06": "table06_survey_subsets.tex",
}

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def norm(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).lower()).strip("_")

def safe_rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def write_csv(path: Path, fields: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

def find_col(frame: pd.DataFrame, key: str) -> str | None:
    columns = [(str(c), norm(c)) for c in frame.columns]
    for alias in ALIASES[key]:
        target = norm(alias)
        for original, candidate in columns:
            if candidate == target or candidate.endswith("_" + target):
                return original
        if len(target) >= 3:
            for original, candidate in columns:
                if target in candidate:
                    return original
    return None

def first_existing(root: Path, values: list[str]) -> Path | None:
    for value in values:
        path = root / value
        if path.exists():
            return path
    return None

def source_manifest(root: Path, cfg: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    for group, values in cfg["sources"].items():
        for value in values:
            path = root / value
            rows.append({
                "source_group": group,
                "path": value,
                "exists": str(path.exists()).lower(),
                "size_bytes": path.stat().st_size if path.exists() else "",
                "sha256": sha256_file(path) if path.exists() else ""
            })
    return rows

def flatten_scalars(value: Any, prefix: str = "$") -> list[tuple[str, Any]]:
    rows = []
    if isinstance(value, dict):
        for key, child in value.items():
            rows.extend(flatten_scalars(child, f"{prefix}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value[:1000]):
            rows.extend(flatten_scalars(child, f"{prefix}[{index}]"))
    elif value is None or isinstance(value, (str, int, float, bool)):
        rows.append((prefix, value))
    return rows

def derive_t01(path: Path) -> tuple[pd.DataFrame | None, dict[str, Any]]:
    value = json.loads(path.read_text(encoding="utf-8"))
    scalars = flatten_scalars(value)
    stages = [
        ("Initial read", ["initial", "raw", "ingest", "parent"]),
        ("Has Gaia source identifier", ["gaia", "source_id"]),
        ("RGB parameter gate", ["rgb", "parameter"]),
        ("Signal-to-noise gate", ["snr", "signal_to_noise"]),
        ("Clean spectroscopic gate", ["clean", "spectroscopic"]),
    ]
    rows = []
    audit = {"resolved_paths": []}
    for stage_name, tokens in stages:
        result = {"stage": stage_name, "apogee": None, "galah": None}
        for survey in ["apogee", "galah"]:
            candidates = []
            for scalar_path, raw in scalars:
                low = norm(scalar_path)
                if survey not in low:
                    continue
                hits = sum(norm(token) in low for token in tokens)
                if hits <= 0:
                    continue
                try:
                    number = int(float(raw))
                except Exception:
                    continue
                candidates.append((hits, number, scalar_path))
            if candidates:
                candidates.sort(key=lambda x: (-x[0], -x[1], x[2]))
                result[survey] = candidates[0][1]
                audit["resolved_paths"].append({
                    "stage": stage_name, "survey": survey,
                    "path": candidates[0][2], "value": candidates[0][1]
                })
        if result["apogee"] is not None and result["galah"] is not None:
            rows.append(result)
    if len(rows) < 3:
        return None, audit
    return pd.DataFrame(rows), audit

def load_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path)

def derive_t02(coeff_path: Path, metrics_path: Path, fold_path: Path) -> tuple[pd.DataFrame | None, dict[str, Any]]:
    coeff = load_csv(coeff_path)
    metrics = load_csv(metrics_path)
    folds = load_csv(fold_path)
    audit = {
        "coeff_columns": list(coeff.columns),
        "metrics_columns": list(metrics.columns),
        "fold_columns": list(folds.columns)
    }

    label_m = find_col(metrics, "label")
    n_m = find_col(metrics, "n_common")
    med_m = find_col(metrics, "residual_median")
    mad_m = find_col(metrics, "residual_mad")

    if label_m is None:
        label_m = find_col(folds, "label")
    if n_m is None:
        n_m = find_col(folds, "n_common")
    if med_m is None:
        med_m = find_col(folds, "residual_median")
    if mad_m is None:
        mad_m = find_col(folds, "residual_mad")

    if not all([label_m, n_m, mad_m]):
        return None, audit

    source = metrics if label_m in metrics.columns and n_m in metrics.columns and mad_m in metrics.columns else folds
    label_m = find_col(source, "label")
    n_m = find_col(source, "n_common")
    med_m = find_col(source, "residual_median")
    mad_m = find_col(source, "residual_mad")

    base = pd.DataFrame({
        "label": source[label_m].astype(str),
        "n_common": pd.to_numeric(source[n_m], errors="coerce"),
        "residual_median": pd.to_numeric(source[med_m], errors="coerce") if med_m else np.nan,
        "residual_mad": pd.to_numeric(source[mad_m], errors="coerce")
    })
    # Aggregate fold-level metrics if needed.
    base = base.groupby("label", as_index=False).agg({
        "n_common": "max",
        "residual_median": "median",
        "residual_mad": "median"
    })

    label_c = find_col(coeff, "label")
    term_c = find_col(coeff, "term")
    value_c = find_col(coeff, "coefficient")
    base["a_fe"] = np.nan
    if label_c and value_c:
        work = coeff.copy()
        if term_c:
            mask = work[term_c].astype(str).map(norm).str.contains("fe")
            work = work[mask]
        work["_coef"] = pd.to_numeric(work[value_c], errors="coerce")
        coef = work.groupby(work[label_c].astype(str))["_coef"].median()
        base["a_fe"] = base["label"].map(coef)

    base = base.dropna(subset=["label", "n_common", "residual_mad"])
    return (base if not base.empty else None), audit

def derive_t03(path: Path) -> tuple[pd.DataFrame | None, dict[str, Any]]:
    frame = load_csv(path)
    label = find_col(frame, "label")
    br = find_col(frame, "beta_r")
    bz = find_col(frame, "beta_z")
    if not all([label, br, bz]):
        return None, {"columns": list(frame.columns)}
    out = pd.DataFrame({
        "sample": "all_clean",
        "label": frame[label].astype(str),
        "n": pd.to_numeric(frame[find_col(frame, "rows")], errors="coerce") if find_col(frame, "rows") else np.nan,
        "beta_r": pd.to_numeric(frame[br], errors="coerce"),
        "beta_r_lo": pd.to_numeric(frame[find_col(frame, "beta_r_lo")], errors="coerce") if find_col(frame, "beta_r_lo") else np.nan,
        "beta_r_hi": pd.to_numeric(frame[find_col(frame, "beta_r_hi")], errors="coerce") if find_col(frame, "beta_r_hi") else np.nan,
        "beta_z": pd.to_numeric(frame[bz], errors="coerce"),
        "beta_z_lo": pd.to_numeric(frame[find_col(frame, "beta_z_lo")], errors="coerce") if find_col(frame, "beta_z_lo") else np.nan,
        "beta_z_hi": pd.to_numeric(frame[find_col(frame, "beta_z_hi")], errors="coerce") if find_col(frame, "beta_z_hi") else np.nan,
    }).dropna(subset=["label", "beta_r", "beta_z"])
    return (out if not out.empty else None), {"columns": list(frame.columns)}

def derive_t04(path: Path) -> tuple[pd.DataFrame | None, dict[str, Any]]:
    frame = load_csv(path)
    pop = find_col(frame, "population")
    metric_col = find_col(frame, "metric")
    metric_value_col = find_col(frame, "metric_value")
    if pop is not None and metric_col is not None and metric_value_col is not None:
        long = frame[[pop, metric_col, metric_value_col]].copy()
        long[metric_col] = long[metric_col].astype(str).map(norm)
        long = long.drop_duplicates([pop, metric_col], keep="last")
        frame = long.pivot(index=pop, columns=metric_col, values=metric_value_col).reset_index()
        frame.columns = [str(c) for c in frame.columns]
        pop = find_col(frame, "population")
    n_col = find_col(frame, "n")
    secure_fraction = find_col(frame, "secure_fraction")
    secure_n = find_col(frame, "secure_n")
    if pop is None or n_col is None or (secure_fraction is None and secure_n is None):
        return None, {"columns": list(frame.columns)}

    out = pd.DataFrame({
        "population": frame[pop].astype(str),
        "n": pd.to_numeric(frame[n_col], errors="coerce"),
        "secure_n": pd.to_numeric(frame[secure_n], errors="coerce") if secure_n else np.nan,
        "secure_fraction": pd.to_numeric(frame[secure_fraction], errors="coerce") if secure_fraction else np.nan,
        "median_feh": pd.to_numeric(frame[find_col(frame, "median_feh")], errors="coerce") if find_col(frame, "median_feh") else np.nan,
        "median_alpha": pd.to_numeric(frame[find_col(frame, "median_alpha")], errors="coerce") if find_col(frame, "median_alpha") else np.nan,
        "median_abs_z": pd.to_numeric(frame[find_col(frame, "median_abs_z")], errors="coerce") if find_col(frame, "median_abs_z") else np.nan,
        "median_vphi": pd.to_numeric(frame[find_col(frame, "median_vphi")], errors="coerce") if find_col(frame, "median_vphi") else np.nan,
        "median_pmax": pd.to_numeric(frame[find_col(frame, "median_pmax")], errors="coerce") if find_col(frame, "median_pmax") else np.nan,
    })
    derived = out["secure_n"] / out["n"].replace(0, np.nan)
    out["secure_fraction"] = out["secure_fraction"].fillna(derived)
    # Prefer primary/all-clean rows when a view column is present.
    sample_col = find_col(frame, "sample")
    if sample_col:
        samples = frame[sample_col].astype(str).map(norm)
        preferred = samples.isin(["primary", "all_clean", "full", "production"])
        if preferred.any():
            out = out[preferred.to_numpy()]
    out = out.dropna(subset=["population", "n", "secure_fraction"])
    # Collapse duplicate component rows deterministically.
    agg = {
        "n": "max", "secure_n": "max", "secure_fraction": "max",
        "median_feh": "median", "median_alpha": "median",
        "median_abs_z": "median", "median_vphi": "median", "median_pmax": "median"
    }
    out = out.groupby("population", as_index=False).agg(agg)
    return (out if not out.empty else None), {"columns": list(frame.columns)}

def design_schema(path: Path) -> list[str]:
    if path.suffix.lower() == ".parquet":
        import pyarrow.parquet as pq
        return pq.ParquetFile(path).schema.names
    if path.suffix.lower() == ".csv":
        return list(pd.read_csv(path, nrows=0).columns)
    raise ValueError(f"Unsupported design-layer format: {path}")

def select_design_columns(path: Path, global_estimates: pd.DataFrame) -> tuple[pd.DataFrame | None, dict[str, Any]]:
    columns = design_schema(path)
    schema_frame = pd.DataFrame(columns=columns)

    resolved = {
        "r": find_col(schema_frame, "r"),
        "abs_z": find_col(schema_frame, "abs_z"),
        "block": find_col(schema_frame, "block"),
        "population": find_col(schema_frame, "population"),
        "pmax": find_col(schema_frame, "pmax"),
        "survey_origin": find_col(schema_frame, "survey_origin"),
        "has_apogee": find_col(schema_frame, "has_apogee"),
        "has_galah": find_col(schema_frame, "has_galah"),
        "overlap": find_col(schema_frame, "overlap"),
    }
    label_values = list(global_estimates["label"].astype(str).unique())
    label_columns = {}
    normalized_columns = {norm(c): c for c in columns}
    for label in label_values:
        candidates = [
            norm(label), norm(label).replace("_fe", "_fe_h"),
            norm(label).replace("fe_h", "feh")
        ]
        selected = None
        for candidate in candidates:
            for cn, original in normalized_columns.items():
                if cn == candidate or cn.endswith("_" + candidate) or candidate in cn:
                    selected = original
                    break
            if selected:
                break
        if selected:
            label_columns[label] = selected

    required = [resolved["r"], resolved["abs_z"], resolved["block"]]
    if any(x is None for x in required) or not label_columns:
        return None, {"columns": columns, "resolved": resolved, "label_columns": label_columns}

    selected_columns = sorted(set(
        [x for x in resolved.values() if x is not None] + list(label_columns.values())
    ))
    if path.suffix.lower() == ".parquet":
        frame = pd.read_parquet(path, columns=selected_columns)
    else:
        frame = pd.read_csv(path, usecols=selected_columns)
    audit = {"columns": columns, "resolved": resolved, "label_columns": label_columns, "format": path.suffix.lower()}
    return frame, audit

def huber_irls(X: np.ndarray, y: np.ndarray, delta: float, max_iter: int = 100, tol: float = 1e-9) -> tuple[np.ndarray, bool, int]:
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    converged = False
    for iteration in range(max_iter):
        residual = y - X @ beta
        scale = 1.4826 * np.median(np.abs(residual - np.median(residual)))
        if not np.isfinite(scale) or scale <= 0:
            scale = float(np.std(residual))
        if not np.isfinite(scale) or scale <= 0:
            break
        u = residual / (delta * scale)
        weights = np.ones_like(u)
        mask = np.abs(u) > 1.0
        weights[mask] = 1.0 / np.abs(u[mask])
        WX = X * np.sqrt(weights)[:, None]
        Wy = y * np.sqrt(weights)
        new_beta, *_ = np.linalg.lstsq(WX, Wy, rcond=None)
        if np.max(np.abs(new_beta - beta)) < tol:
            beta = new_beta
            converged = True
            return beta, converged, iteration + 1
        beta = new_beta
    return beta, converged, max_iter

def deterministic_seed(base: int, *parts: str) -> int:
    payload = "|".join(str(x) for x in parts).encode("utf-8")
    digest = hashlib.sha256(payload).hexdigest()[:12]
    return int(base) + int(digest, 16) % 1000000

def as_bool(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    normalized = series.astype(str).map(norm)
    return normalized.isin({"true", "1", "yes", "y", "t"})

def bootstrap_fit(
    frame: pd.DataFrame,
    value_col: str,
    r_col: str,
    z_col: str,
    block_col: str,
    pivot: float,
    delta: float,
    draws: int,
    seed: int,
    minimum_rows: int,
    minimum_blocks: int
) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    work = frame[[value_col, r_col, z_col, block_col]].copy()
    for col in [value_col, r_col, z_col]:
        work[col] = pd.to_numeric(work[col], errors="coerce")
    work = work.dropna()
    audit = {"rows": len(work), "blocks": int(work[block_col].nunique())}
    if len(work) < minimum_rows or work[block_col].nunique() < minimum_blocks:
        audit["status"] = "insufficient_support"
        return None, audit

    X = np.column_stack([
        np.ones(len(work)),
        work[r_col].to_numpy() - pivot,
        np.abs(work[z_col].to_numpy())
    ])
    y = work[value_col].to_numpy()
    beta, converged, iterations = huber_irls(X, y, delta)
    audit.update({"status": "fit", "converged": converged, "iterations": iterations})

    if draws <= 0:
        audit["successful_draws"] = 0
        return {
            "n": len(work),
            "beta_intercept": beta[0],
            "beta_r": beta[1],
            "beta_r_lo": np.nan,
            "beta_r_hi": np.nan,
            "beta_z": beta[2],
            "beta_z_lo": np.nan,
            "beta_z_hi": np.nan,
            "successful_draws": 0
        }, audit

    blocks = work[block_col].astype(str).to_numpy()
    unique_blocks = np.unique(blocks)
    rng = np.random.default_rng(seed)
    draw_values = []
    grouped_indices = {b: np.flatnonzero(blocks == b) for b in unique_blocks}
    for _ in range(draws):
        sampled = rng.choice(unique_blocks, size=len(unique_blocks), replace=True)
        idx = np.concatenate([grouped_indices[b] for b in sampled])
        Xb = X[idx]
        yb = y[idx]
        try:
            b, _, _ = huber_irls(Xb, yb, delta)
            if np.all(np.isfinite(b)):
                draw_values.append(b)
        except Exception:
            continue
    if len(draw_values) < max(50, int(0.5 * draws)):
        audit["status"] = "bootstrap_failed"
        audit["successful_draws"] = len(draw_values)
        return None, audit

    draws_array = np.asarray(draw_values)
    audit["successful_draws"] = len(draw_values)
    return {
        "n": len(work),
        "beta_intercept": beta[0],
        "beta_r": beta[1],
        "beta_r_lo": np.quantile(draws_array[:, 1], 0.025),
        "beta_r_hi": np.quantile(draws_array[:, 1], 0.975),
        "beta_z": beta[2],
        "beta_z_lo": np.quantile(draws_array[:, 2], 0.025),
        "beta_z_hi": np.quantile(draws_array[:, 2], 0.975),
        "successful_draws": len(draw_values)
    }, audit

def fit_closures(
    design: pd.DataFrame,
    design_audit: dict[str, Any],
    global_estimates: pd.DataFrame,
    cfg: dict[str, Any]
) -> tuple[pd.DataFrame | None, pd.DataFrame | None, list[dict[str, Any]]]:
    resolved = design_audit["resolved"]
    label_columns = design_audit["label_columns"]
    r_col, z_col, block_col = resolved["r"], resolved["abs_z"], resolved["block"]
    population_col = resolved["population"]
    pmax_col = resolved["pmax"]
    survey_origin = resolved["survey_origin"]
    has_apogee = resolved["has_apogee"]
    has_galah = resolved["has_galah"]
    overlap = resolved["overlap"]

    radial_min, radial_max = cfg["radial_window_kpc"]
    design = design[
        pd.to_numeric(design[r_col], errors="coerce").between(radial_min, radial_max)
    ].copy()

    fit_audit = []
    t05_rows = []
    t06_rows = []

    label_meta = {}
    for _, row in global_estimates.iterrows():
        label = str(row["label"])
        label_meta[label] = {
            "pivot": float(row["pivot"]) if pd.notna(row["pivot"]) else None,
            "delta": float(row["huber_scale"]) if pd.notna(row["huber_scale"]) else None
        }

    if population_col:
        populations = design[population_col].dropna().astype(str).unique()
        for population in sorted(populations):
            mask = design[population_col].astype(str) == population
            if pmax_col:
                pmax = pd.to_numeric(design[pmax_col], errors="coerce")
                mask &= pmax >= float(cfg["secure_probability_threshold"])
            subset = design[mask]
            for label, value_col in label_columns.items():
                meta = label_meta.get(label, {})
                pivot, delta = meta.get("pivot"), meta.get("delta")
                if pivot is None or delta is None:
                    fit_audit.append({
                        "asset": "T05", "group": population, "label": label,
                        "status": "missing_frozen_method_parameter", "rows": len(subset)
                    })
                    continue
                result, audit = bootstrap_fit(
                    subset, value_col, r_col, z_col, block_col,
                    pivot, delta, int(cfg["bootstrap_draws"]),
                    deterministic_seed(int(cfg["bootstrap_seed"]), "T05", population, label),
                    int(cfg["minimum_fit_rows"]), int(cfg["minimum_blocks"])
                )
                fit_audit.append({
                    "asset": "T05", "group": population, "label": label,
                    **audit
                })
                if result:
                    t05_rows.append({"population": population, "label": label, **result})

    subset_masks = {"all_clean": pd.Series(True, index=design.index)}
    if survey_origin:
        origin = design[survey_origin].astype(str).map(norm)
        subset_masks["origin_apogee"] = origin.str.contains("apogee")
        subset_masks["origin_galah"] = origin.str.contains("galah")
    if has_apogee:
        subset_masks["has_apogee"] = as_bool(design[has_apogee])
    if has_galah:
        subset_masks["has_galah"] = as_bool(design[has_galah])
    if overlap:
        subset_masks["overlap"] = as_bool(design[overlap])
    elif has_apogee and has_galah:
        subset_masks["overlap"] = as_bool(design[has_apogee]) & as_bool(design[has_galah])

    for sample, mask in subset_masks.items():
        subset = design[mask]
        for label, value_col in label_columns.items():
            meta = label_meta.get(label, {})
            pivot, delta = meta.get("pivot"), meta.get("delta")
            if pivot is None or delta is None:
                fit_audit.append({
                    "asset": "T06", "group": sample, "label": label,
                    "status": "missing_frozen_method_parameter", "rows": len(subset)
                })
                continue
            result, audit = bootstrap_fit(
                subset, value_col, r_col, z_col, block_col,
                pivot, delta, int(cfg["bootstrap_draws"]),
                deterministic_seed(int(cfg["bootstrap_seed"]), "T06", sample, label),
                int(cfg["minimum_fit_rows"]), int(cfg["minimum_blocks"])
            )
            fit_audit.append({
                "asset": "T06", "group": sample, "label": label,
                **audit
            })
            if result:
                t06_rows.append({"sample": sample, "label": label, **result})

    t05 = pd.DataFrame(t05_rows) if t05_rows else None
    t06 = pd.DataFrame(t06_rows) if t06_rows else None
    return t05, t06, fit_audit

def tex_escape(value: Any) -> str:
    text = str(value)
    for old, new in [
        ("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"),
        ("$", r"\$"), ("#", r"\#"), ("_", r"\_"),
        ("{", r"\{"), ("}", r"\}")
    ]:
        text = text.replace(old, new)
    return text

def fmt(value: Any, decimals: int = 4) -> str:
    if value is None or pd.isna(value):
        return "--"
    try:
        number = float(value)
        if number.is_integer() and abs(number) >= 100:
            return f"{int(number):,}"
        if abs(number) < 10:
            return f"{number:+.{decimals}f}"
        return f"{number:.{decimals}f}"
    except Exception:
        return tex_escape(value)

def dataframe_to_latex(asset_id: str, title: str, frame: pd.DataFrame, source: str) -> str:
    display = frame.copy()
    display = display[[c for c in display.columns if display[c].notna().any()]]
    if len(display) > 80:
        display = display.head(80)
    headings = {
        "stage": "Stage", "apogee": "APOGEE", "galah": "GALAH",
        "label": "Label", "n_common": r"$N_{\rm common}$",
        "a_fe": r"$a_{\rm Fe}$", "residual_median": "Residual median",
        "residual_mad": "Residual MAD", "sample": "Sample",
        "population": "Population", "n": r"$N$", "secure_n": r"$N_{\rm secure}$",
        "secure_fraction": "Secure frac.", "median_feh": "Median [Fe/H]",
        "median_alpha": r"Median [$\alpha$/Fe]", "median_abs_z": r"Median $|Z|$",
        "median_vphi": r"Median $v_{\phi,\rm disk}$", "median_pmax": r"Median $P_{\max}$",
        "beta_r": r"$\beta_R$", "beta_z": r"$\beta_Z$",
        "beta_r_lo": r"$\beta_{R,\rm lo}$", "beta_r_hi": r"$\beta_{R,\rm hi}$",
        "beta_z_lo": r"$\beta_{Z,\rm lo}$", "beta_z_hi": r"$\beta_{Z,\rm hi}$"
    }
    cols = list(display.columns)
    wide = len(cols) >= 5
    environment = "table*" if wide else "table"
    width = r"\textwidth" if wide else r"\columnwidth"
    lines = [
        f"% Auto-generated by Stage-6C2D from {source}",
        rf"\begin{{{environment}}}", r"\centering", r"\small",
        rf"\caption{{{tex_escape(title)}. Source/closure: \texttt{{{tex_escape(source)}}}.}}",
        rf"\label{{tab:{asset_id.lower()}}}",
        rf"\resizebox{{{width}}}{{!}}{{%",
        r"\begin{tabular}{" + "l" + "r" * max(len(cols)-1, 0) + "}",
        r"\hline",
        " & ".join(headings.get(c, tex_escape(c)) for c in cols) + r"\\",
        r"\hline"
    ]
    text_cols = {"stage", "label", "sample", "population"}
    int_cols = {"apogee", "galah", "n", "secure_n", "n_common", "successful_draws"}
    for _, row in display.iterrows():
        cells = []
        for col in cols:
            value = row[col]
            if col in text_cols:
                cells.append(tex_escape(value) if pd.notna(value) else "--")
            elif col in int_cols:
                try:
                    cells.append(f"{int(float(value)):,}" if pd.notna(value) else "--")
                except Exception:
                    cells.append(tex_escape(value))
            else:
                cells.append(fmt(value))
        lines.append(" & ".join(cells) + r"\\")
    lines.extend([r"\hline", r"\end{tabular}", r"}", rf"\end{{{environment}}}", ""])
    return "\n".join(lines)

def pyplot():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    return plt

def plot_bar(frame: pd.DataFrame, x: str, y: str, path: Path, ylabel: str) -> bool:
    work = frame[[x, y]].copy()
    work[y] = pd.to_numeric(work[y], errors="coerce")
    work = work.dropna()
    if work.empty:
        return False
    plt = pyplot()
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.bar(work[x].astype(str), work[y])
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=50)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def plot_gradients(frame: pd.DataFrame, category: str, path: Path) -> bool:
    needed = [category, "beta_r", "beta_z"]
    if any(col not in frame.columns for col in needed):
        return False
    work = frame[needed].copy()
    work["beta_r"] = pd.to_numeric(work["beta_r"], errors="coerce")
    work["beta_z"] = pd.to_numeric(work["beta_z"], errors="coerce")
    work = work.dropna()
    if work.empty:
        return False
    if len(work) > 40:
        work = work.head(40)
    plt = pyplot()
    fig, ax = plt.subplots(figsize=(9.0, 5.0))
    x = np.arange(len(work))
    ax.axhline(0.0, linewidth=0.8)
    ax.plot(x, work["beta_r"], marker="o", label=r"$\beta_R$")
    ax.plot(x, work["beta_z"], marker="s", linestyle="--", label=r"$\beta_Z$")
    ax.set_xticks(x)
    ax.set_xticklabels(work[category].astype(str), rotation=55, ha="right")
    ax.set_ylabel(r"Gradient [dex kpc$^{-1}$]")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def plot_population_map(frame: pd.DataFrame, path: Path) -> bool:
    required = ["population", "median_feh", "median_alpha"]
    if any(col not in frame.columns for col in required):
        return False
    work = frame.copy()
    work["median_feh"] = pd.to_numeric(work["median_feh"], errors="coerce")
    work["median_alpha"] = pd.to_numeric(work["median_alpha"], errors="coerce")
    work = work.dropna(subset=required)
    if work.empty:
        return False
    size = pd.to_numeric(work["n"], errors="coerce").fillna(1)
    size = 50 + 500 * size / max(float(size.max()), 1.0)
    plt = pyplot()
    fig, ax = plt.subplots(figsize=(7.3, 5.2))
    ax.scatter(work["median_feh"], work["median_alpha"], s=size, alpha=0.65)
    for _, row in work.iterrows():
        ax.annotate(str(row["population"]), (row["median_feh"], row["median_alpha"]), fontsize=8)
    ax.set_xlabel("[Fe/H]")
    ax.set_ylabel(r"[$\alpha$/Fe]")
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def plot_design_population_map(design: pd.DataFrame, design_audit: dict[str, Any], path: Path, max_rows: int) -> bool:
    resolved = design_audit.get("resolved", {})
    population_col = resolved.get("population")
    pmax_col = resolved.get("pmax")
    label_columns = design_audit.get("label_columns", {})
    if population_col is None or len(label_columns) < 2:
        return False
    labels = list(label_columns.items())
    # Prefer metallicity-like and alpha-like labels.
    x_item = next((item for item in labels if "fe" in norm(item[0])), labels[0])
    y_item = next((item for item in labels if any(t in norm(item[0]) for t in ["alpha", "mg"])), labels[1])
    cols = [population_col, x_item[1], y_item[1]] + ([pmax_col] if pmax_col else [])
    work = design[cols].copy()
    work[x_item[1]] = pd.to_numeric(work[x_item[1]], errors="coerce")
    work[y_item[1]] = pd.to_numeric(work[y_item[1]], errors="coerce")
    if pmax_col:
        work = work[pd.to_numeric(work[pmax_col], errors="coerce") >= 0.70]
    work = work.dropna(subset=[population_col, x_item[1], y_item[1]])
    if len(work) > max_rows:
        work = work.sample(max_rows, random_state=1729)
    if work.empty:
        return False
    codes, names = pd.factorize(work[population_col].astype(str))
    plt = pyplot()
    fig, ax = plt.subplots(figsize=(7.5, 5.3))
    ax.scatter(work[x_item[1]], work[y_item[1]], c=codes, s=4, alpha=0.4)
    ax.set_xlabel(str(x_item[0]))
    ax.set_ylabel(str(y_item[0]))
    for i, name in enumerate(names[:8]):
        ax.plot([], [], marker="o", linestyle="None", label=str(name))
    if len(names):
        ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)
    return True

def update_figure_slot(package_root: Path, number: int, filename: str, caption: str) -> None:
    (package_root / "figures" / f"figure{number:02d}_slot.tex").write_text(
        rf"""\begin{{figure*}}
\centering
\includegraphics[width=0.96\textwidth]{{figures/{filename}}}
\caption{{{caption}}}
\label{{fig:f{number:02d}}}
\end{{figure*}}
""", encoding="utf-8"
    )

def scan_human_metadata(package_root: Path, markers: list[str]) -> list[dict[str, Any]]:
    rows = []
    for path in package_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".tex", ".yaml", ".yml", ".json", ".md", ".cff"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for marker in markers:
            count = text.count(marker)
            if count:
                rows.append({"path": safe_rel(path, package_root), "marker": marker, "count": count})
    return rows

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE)
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads((root / "config/stage6c2d_config.json").read_text(encoding="utf-8"))
    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for name in ["validation", "summaries", "tables", "figures", "manuscript_source", "checksums"]:
        (out_dir / name).mkdir(parents=True, exist_ok=True)

    manifest = source_manifest(root, cfg)
    write_csv(
        out_dir / "tables/stage6c2d_source_manifest.csv",
        ["source_group", "path", "exists", "size_bytes", "sha256"],
        manifest
    )

    source_package = first_existing(root, cfg["source_package_candidates"])
    if source_package is None:
        raise FileNotFoundError("No prior manuscript source package found.")
    package_root = out_dir / "manuscript_source" / cfg["new_package_name"]
    shutil.copytree(source_package, package_root)

    statuses = {}
    audits = {}
    canonical = {}

    t01_path = first_existing(root, cfg["sources"]["t01"])
    if t01_path:
        canonical["T01"], audits["T01"] = derive_t01(t01_path)
    statuses["T01"] = canonical.get("T01") is not None

    t02_paths = [root / x for x in cfg["sources"]["t02"]]
    if all(p.exists() for p in t02_paths):
        canonical["T02"], audits["T02"] = derive_t02(*t02_paths)
    statuses["T02"] = canonical.get("T02") is not None

    t03_path = first_existing(root, cfg["sources"]["t03"])
    if t03_path:
        canonical["T03"], audits["T03"] = derive_t03(t03_path)
    statuses["T03"] = canonical.get("T03") is not None

    t04_path = first_existing(root, cfg["sources"]["t04"])
    if t04_path:
        canonical["T04"], audits["T04"] = derive_t04(t04_path)
    statuses["T04"] = canonical.get("T04") is not None

    fit_audit = []
    design = None
    design_audit = {}
    design_path = first_existing(root, cfg["sources"]["design"])
    if statuses["T03"] and design_path:
        # Recover frozen method parameters directly from the Stage-4B estimate file.
        global_raw = pd.read_csv(t03_path)
        label_col = find_col(global_raw, "label")
        pivot_col = find_col(global_raw, "pivot")
        huber_col = find_col(global_raw, "huber_scale")
        if label_col and pivot_col and huber_col:
            method = pd.DataFrame({
                "label": global_raw[label_col].astype(str),
                "pivot": pd.to_numeric(global_raw[pivot_col], errors="coerce"),
                "huber_scale": pd.to_numeric(global_raw[huber_col], errors="coerce")
            })
            design, design_audit = select_design_columns(design_path, method)
            audits["design"] = design_audit
            if design is not None:
                t05, t06, fit_audit = fit_closures(design, design_audit, method, cfg)
                if t05 is not None and not t05.empty:
                    canonical["T05"] = t05
                if t06 is not None and not t06.empty:
                    canonical["T06"] = t06
        else:
            audits["design"] = {
                "status": "missing_frozen_method_parameters",
                "global_columns": list(global_raw.columns)
            }

    statuses["T05"] = canonical.get("T05") is not None
    statuses["T06"] = canonical.get("T06") is not None

    write_csv(
        out_dir / "tables/stage6c2d_fit_audit.csv",
        sorted({k for row in fit_audit for k in row.keys()}) if fit_audit else ["asset", "group", "label", "status"],
        fit_audit
    )

    titles = {
        "T01": "Spectroscopic sample flow",
        "T02": "APOGEE--GALAH common-star calibration",
        "T03": "Global bootstrap-tested gradients",
        "T04": "Probabilistic population summary",
        "T05": "Population-resolved gradients",
        "T06": "Survey-subset robustness"
    }
    filenames = {
        "T01": "canonical_t01_sample_flow.csv",
        "T02": "canonical_t02_calibration.csv",
        "T03": "canonical_t03_global_gradients.csv",
        "T04": "canonical_t04_population_summary.csv",
        "T05": "canonical_t05_population_gradients.csv",
        "T06": "canonical_t06_survey_subset_gradients.csv"
    }
    source_labels = {
        "T01": "Stage-1 catalogue_ingest_summary.json",
        "T02": "Stage-2B calibration coefficients and held-out metrics",
        "T03": "Stage-4B global_gradient_estimates.csv",
        "T04": "Stage-5B responsibility_summary.csv",
        "T05": "Stage-4A design layer + frozen Stage-4B Huber specification + Stage-5 population labels",
        "T06": "Stage-4A design layer + frozen Stage-4B Huber specification + survey-support subsets"
    }

    for asset_id, frame in canonical.items():
        if frame is None:
            continue
        frame.to_csv(out_dir / "tables" / filenames[asset_id], index=False)
        target = package_root / "tables" / TABLE_FILES[asset_id]
        target.write_text(
            dataframe_to_latex(asset_id, titles[asset_id], frame, source_labels[asset_id]),
            encoding="utf-8"
        )

    generated = {key: False for key in ["F01", "F02", "F03", "F04", "F05"]}
    if statuses["T02"]:
        p = package_root / "figures/f01_calibration_residual_mad.pdf"
        generated["F01"] = plot_bar(canonical["T02"], "label", "residual_mad", p, "Post-calibration residual MAD")
        if generated["F01"]:
            update_figure_slot(package_root, 1, p.name, "Label-specific held-out post-calibration residual MAD.")
    if design is not None:
        p = package_root / "figures/f02_population_design_map.pdf"
        generated["F02"] = plot_design_population_map(design, design_audit, p, int(cfg["maximum_rows_per_fit"]))
        if generated["F02"]:
            update_figure_slot(package_root, 2, p.name, "Frozen design-layer chemo-kinematic population structure.")
    if (not generated["F02"]) and statuses["T04"]:
        p = package_root / "figures/f02_population_median_map.pdf"
        generated["F02"] = plot_population_map(canonical["T04"], p)
        if generated["F02"]:
            update_figure_slot(package_root, 2, p.name, "Population-level median chemo-kinematic locations.")
    if statuses["T04"]:
        p = package_root / "figures/f03_population_counts.pdf"
        generated["F03"] = plot_bar(canonical["T04"], "population", "n", p, "Number of stars")
        if generated["F03"]:
            update_figure_slot(package_root, 3, p.name, "Frozen probabilistic population counts.")
    if statuses["T03"]:
        p = package_root / "figures/f04_global_gradients.pdf"
        generated["F04"] = plot_gradients(canonical["T03"], "label", p)
        if generated["F04"]:
            update_figure_slot(package_root, 4, p.name, "Global radial and vertical gradients.")
    if statuses["T06"]:
        work = canonical["T06"].copy()
        work["display"] = work["sample"].astype(str) + " | " + work["label"].astype(str)
        p = package_root / "figures/f05_survey_subset_gradients.pdf"
        generated["F05"] = plot_gradients(work, "display", p)
        if generated["F05"]:
            update_figure_slot(package_root, 5, p.name, "Survey-support subset radial and vertical gradients.")

    write_csv(
        out_dir / "tables/stage6c2d_figure_generation.csv",
        ["figure_id", "generated"],
        [{"figure_id": k, "generated": str(v).lower()} for k, v in generated.items()]
    )

    for asset_id, audit in audits.items():
        write_json(out_dir / "summaries" / f"{asset_id.lower()}_resolution_audit.json", audit)

    human_rows = scan_human_metadata(package_root, cfg["human_metadata_markers"])
    write_csv(
        out_dir / "tables/stage6c2d_human_metadata_audit.csv",
        ["path", "marker", "count"],
        human_rows
    )

    figures_ready = all(generated.values())
    manuscript_assets_ready = all(statuses.values()) and figures_ready
    human_ready = len(human_rows) == 0
    mnras_ready = (package_root / "mnras.cls").exists()

    remaining = []
    for asset_id, ready in statuses.items():
        if not ready:
            remaining.append({
                "gate": f"{asset_id}_READY",
                "required_action": f"Inspect {asset_id.lower()} resolution audit and source schema."
            })
    if not figures_ready:
        missing = [k for k, v in generated.items() if not v]
        remaining.append({
            "gate": "FIGURES_READY",
            "required_action": "Could not generate: " + ", ".join(missing)
        })
    if not human_ready:
        remaining.append({
            "gate": "HUMAN_METADATA_READY",
            "required_action": "Complete author, affiliation, ORCID, funding, repository, and DOI placeholders."
        })
    if not mnras_ready:
        remaining.append({
            "gate": "MNRAS_TEMPLATE_READY",
            "required_action": "Copy official mnras.cls into the v0.15.3 package."
        })
    write_csv(
        out_dir / "tables/stage6c2d_remaining_closure_items.csv",
        ["gate", "required_action"],
        remaining
    )

    # Provenance.
    provenance_dir = package_root / "provenance"
    provenance_dir.mkdir(parents=True, exist_ok=True)
    for source in [
        out_dir / "tables/stage6c2d_source_manifest.csv",
        out_dir / "tables/stage6c2d_fit_audit.csv",
        out_dir / "tables/stage6c2d_figure_generation.csv"
    ]:
        shutil.copy2(source, provenance_dir / source.name)

    manifest_rows = []
    for path in sorted(package_root.rglob("*")):
        if path.is_file():
            manifest_rows.append({
                "path": safe_rel(path, package_root),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path)
            })
    write_json(package_root / "PROVENANCE_MANIFEST.json", {
        "stage": STAGE, "created_utc": utc_now(), "files": manifest_rows
    })
    sums = [
        f"{sha256_file(path)}  {safe_rel(path, package_root)}"
        for path in sorted(package_root.rglob("*"))
        if path.is_file() and path.name != "SHA256SUMS.txt"
    ]
    (package_root / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")

    zip_path = out_dir / "manuscript_source" / f"{cfg['new_package_name']}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as archive:
        for path in sorted(package_root.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(package_root.parent))

    validation = {
        "stage": STAGE,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "prior_stage_outputs_modified": False,
        "T01_SAMPLE_FLOW_READY": statuses["T01"],
        "T02_CALIBRATION_READY": statuses["T02"],
        "T03_GLOBAL_GRADIENTS_READY": statuses["T03"],
        "T04_POPULATION_SUMMARY_READY": statuses["T04"],
        "T05_POPULATION_GRADIENTS_READY": statuses["T05"],
        "T06_SURVEY_SUBSET_GRADIENTS_READY": statuses["T06"],
        "FIGURES_READY": figures_ready,
        "MANUSCRIPT_ASSETS_READY": manuscript_assets_ready,
        "MNRAS_TEMPLATE_READY": mnras_ready,
        "HUMAN_METADATA_READY": human_ready,
        "ZENODO_SUBMISSION_READY": manuscript_assets_ready and mnras_ready and human_ready,
        "source_package": safe_rel(package_root, root),
        "source_zip": safe_rel(zip_path, root),
        "source_zip_size_bytes": zip_path.stat().st_size,
        "source_zip_sha256": sha256_file(zip_path)
    }
    write_json(out_dir / "validation/stage6c2d_validation.json", validation)

    summary = {
        "stage": STAGE,
        "timestamp_utc": utc_now(),
        "asset_row_counts": {
            asset_id: len(frame) for asset_id, frame in canonical.items() if frame is not None
        },
        "fit_audit_status_counts": (
            pd.Series([row.get("status", "") for row in fit_audit]).value_counts().to_dict()
            if fit_audit else {}
        ),
        "remaining_closure_items": remaining,
        "scientific_disposition": (
            "All manuscript science assets are closed. Complete only human metadata if it remains."
            if manuscript_assets_ready else
            "Claim-bounded closure executed. Unresolved assets remain explicit; no new model development was performed."
        )
    }
    write_json(out_dir / "summaries/stage6c2d_summary.json", summary)

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
