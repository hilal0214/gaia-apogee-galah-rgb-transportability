from __future__ import annotations

import argparse
import csv
import json
import math
import re
import shutil
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def now():
    return datetime.now(timezone.utc).isoformat()


def norm(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def find_alias(columns, aliases):
    lookup = {norm(c): c for c in columns}
    for alias in aliases:
        if norm(alias) in lookup:
            return lookup[norm(alias)]
    return None


def read_columns(path: Path):
    if path.suffix.lower() == ".parquet":
        import pyarrow.parquet as pq
        f = pq.ParquetFile(path)
        return list(f.schema_arrow.names), int(f.metadata.num_rows)
    if path.suffix.lower() == ".feather":
        import pyarrow.feather as feather
        t = feather.read_table(path)
        return list(t.column_names), int(t.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def read_table(path: Path, columns=None):
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path, columns=columns)
    if path.suffix.lower() == ".feather":
        return pd.read_feather(path, columns=columns)
    return pd.read_csv(path, usecols=columns)


def resolve(path: Path):
    for candidate in [path, path.with_suffix(".csv"), path.with_suffix(".feather")]:
        if candidate.exists():
            return candidate
    return None


def canonical_base(column: str, cfg: dict[str, Any]) -> str:
    token = norm(column)
    changed = True
    while changed:
        changed = False
        for suffix in cfg["merge_suffixes"]:
            st = norm(suffix)
            if token.endswith(st):
                token = token[: -len(st)].rstrip("_")
                changed = True
                break
        new = re.sub(cfg["numeric_merge_suffix_pattern"], "", token)
        if new != token:
            token = new.rstrip("_")
            changed = True
    return token


def approved_role(column: str, cfg: dict[str, Any]):
    base = canonical_base(column, cfg)
    scalar = {norm(x) for x in cfg["approved_scalar_bases"]}
    if base in scalar:
        return "scalar", "scalar_native_snr"
    for role, aliases in cfg["approved_channel_bases"].items():
        if base in {norm(x) for x in aliases}:
            return role, "channel_native_snr"
    return "", ""


def numeric_profile(series: pd.Series):
    x = pd.to_numeric(series, errors="coerce")
    finite = x[np.isfinite(x)]
    if finite.empty:
        return {
            "finite_rows": 0,
            "positive_rows": 0,
            "positive_fraction": 0.0,
            "min": "",
            "q01": "",
            "q05": "",
            "q25": "",
            "median": "",
            "q75": "",
            "q95": "",
            "q99": "",
            "max": "",
            "unique_finite": 0,
            "integer_like_fraction": 0.0,
        }
    q = finite.quantile([.01,.05,.25,.5,.75,.95,.99])
    return {
        "finite_rows": int(finite.shape[0]),
        "positive_rows": int((finite > 0).sum()),
        "positive_fraction": float((finite > 0).mean()),
        "min": float(finite.min()),
        "q01": float(q.loc[.01]),
        "q05": float(q.loc[.05]),
        "q25": float(q.loc[.25]),
        "median": float(q.loc[.5]),
        "q75": float(q.loc[.75]),
        "q95": float(q.loc[.95]),
        "q99": float(q.loc[.99]),
        "max": float(finite.max()),
        "unique_finite": int(finite.nunique()),
        "integer_like_fraction": float(
            np.isclose(finite.to_numpy(), np.round(finite.to_numpy())).mean()
        ),
    }


def text_hits(root: Path, column: str, cfg: dict[str, Any]):
    hits = []
    needle = column.lower()
    canonical = canonical_base(column, cfg)
    max_hits = int(cfg["maximum_reference_hits_per_column"])
    for rr in cfg["reference_scan_roots"]:
        base = root / rr
        if not base.exists():
            continue
        paths = [base] if base.is_file() else base.rglob("*")
        for path in paths:
            if len(hits) >= max_hits:
                break
            if (
                not path.is_file()
                or path.suffix.lower() not in set(cfg["text_suffixes"])
                or path.stat().st_size > int(cfg["maximum_text_file_bytes"])
            ):
                continue
            try:
                lines = path.read_text(
                    encoding="utf-8", errors="replace"
                ).splitlines()
            except Exception:
                continue
            for line_number, line in enumerate(lines, start=1):
                low = line.lower()
                if needle not in low and canonical not in norm(line):
                    continue
                derived = any(tok in low for tok in cfg["derived_operation_tokens"])
                path_low = rel(path, root).lower()
                context_galah = ("galah" in low) or ("galah" in path_low)
                direct_read_evidence = any(
                    tok in low
                    for tok in ["usecols", "read_csv", "read_parquet", "rename", "columns"]
                )
                native = (
                    context_galah
                    and direct_read_evidence
                    and not derived
                )
                hits.append({
                    "path": rel(path, root),
                    "line_number": line_number,
                    "column": column,
                    "canonical_base": canonical,
                    "derived_operation_evidence": derived,
                    "native_provenance_evidence": native,
                    "excerpt": line.strip()[:1400],
                })
                if len(hits) >= max_hits:
                    break
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2d8d_config.json").read_text(encoding="utf-8")
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in ["validation", "tables", "summaries", "reports"]:
        (out / d).mkdir(parents=True, exist_ok=True)

    prepath = root / cfg["prerequisite_validation"]
    pre = json.loads(prepath.read_text(encoding="utf-8")) if prepath.exists() else {}
    prereq = bool(
        pre.get("STAGE6D3A2D8C_LINEAGE_READY", False)
        and pre.get("EXACT_GAIA_DR3_IDENTITY_ALREADY_CLOSED", False)
        and pre.get("POPULATION_SOBJECT_TO_GAIA_BRIDGE_READY", False)
        and pre.get("SOBJECT_SNR_COMPANION_AUDIT_READY", False)
        and not pre.get("INTERNAL_SOBJECT_NATIVE_GALAH_SNR_READY", True)
    )

    audit_path = root / cfg["companion_audit"]
    audit = pd.read_csv(audit_path) if audit_path.exists() else pd.DataFrame()
    audit_ready = bool(
        not audit.empty
        and {"companion_path", "sobject_column", "all_snr_like_columns"}.issubset(audit.columns)
    )

    profile_rows = []
    all_reference_rows = []
    shortlist = []

    seen = set()
    if audit_ready:
        for _, row in audit.iterrows():
            companion = str(row.get("companion_path", "")).strip()
            if not companion:
                continue
            path = resolve(root / companion)
            if not path:
                continue
            sobject_col = str(row.get("sobject_column", "")).strip()
            snr_like = [
                c for c in str(row.get("all_snr_like_columns", "")).split("|")
                if c.strip()
            ]
            if not snr_like:
                continue
            try:
                columns, row_count = read_columns(path)
            except Exception:
                continue
            actual = [c for c in snr_like if c in columns]
            if not actual:
                continue
            use = list(dict.fromkeys(([sobject_col] if sobject_col in columns else []) + actual))
            try:
                frame = read_table(path, use)
            except Exception:
                continue

            sobject_non_null = (
                int(frame[sobject_col].notna().sum())
                if sobject_col in frame.columns else 0
            )
            sobject_unique = (
                int(frame[sobject_col].astype("string").nunique(dropna=True))
                if sobject_col in frame.columns else 0
            )

            for column in actual:
                key = (rel(path, root), column)
                if key in seen:
                    continue
                seen.add(key)
                p = numeric_profile(frame[column])
                role, contract_family = approved_role(column, cfg)
                hits = text_hits(root, column, cfg)
                all_reference_rows.extend(hits)
                native_hits = sum(bool(h["native_provenance_evidence"]) for h in hits)
                derived_hits = sum(bool(h["derived_operation_evidence"]) for h in hits)
                base = canonical_base(column, cfg)

                name_compatible = bool(role)
                distribution_plausible = bool(
                    p["finite_rows"] >= int(cfg["minimum_finite_rows_for_candidate"])
                    and p["positive_fraction"] >= float(cfg["minimum_positive_fraction"])
                    and p["q99"] != ""
                    and float(p["q99"]) <= float(cfg["maximum_plausible_snr_q99"])
                )
                documented_native = native_hits > 0 and derived_hits == 0

                if name_compatible and distribution_plausible and documented_native:
                    disposition = "DOCUMENTED_NATIVE_CONTRACT_CANDIDATE"
                elif name_compatible and distribution_plausible:
                    disposition = "NAME_COMPATIBLE_BUT_PROVENANCE_NOT_CLOSED"
                elif distribution_plausible:
                    disposition = "PLAUSIBLE_NUMERIC_SNR_BUT_SCHEMA_UNRESOLVED"
                else:
                    disposition = "NOT_DEFENSIBLE_AS_NATIVE_SNR"

                rec = {
                    "companion_path": rel(path, root),
                    "row_count": row_count,
                    "sobject_column": sobject_col,
                    "sobject_non_null_rows": sobject_non_null,
                    "sobject_unique_values": sobject_unique,
                    "snr_column": column,
                    "canonical_base": base,
                    "approved_role": role,
                    "contract_family": contract_family,
                    "input_dtype": str(frame[column].dtype),
                    **p,
                    "reference_hit_count": len(hits),
                    "native_provenance_hit_count": native_hits,
                    "derived_operation_hit_count": derived_hits,
                    "name_compatible_with_frozen_native_schema": name_compatible,
                    "distribution_plausible_for_snr": distribution_plausible,
                    "documented_native_provenance_ready": documented_native,
                    "disposition": disposition,
                }
                profile_rows.append(rec)
                if disposition == "DOCUMENTED_NATIVE_CONTRACT_CANDIDATE":
                    shortlist.append(rec)

    profile_rows.sort(
        key=lambda r: (
            0 if r["disposition"] == "DOCUMENTED_NATIVE_CONTRACT_CANDIDATE" else
            1 if r["disposition"] == "NAME_COMPATIBLE_BUT_PROVENANCE_NOT_CLOSED" else
            2 if r["disposition"] == "PLAUSIBLE_NUMERIC_SNR_BUT_SCHEMA_UNRESOLVED" else 3,
            -int(r["finite_rows"]),
            r["companion_path"],
            r["snr_column"],
        )
    )

    write_csv(
        out / "tables/stage6d3a2d8d_snr_column_semantic_audit.csv",
        [
            "companion_path", "row_count", "sobject_column",
            "sobject_non_null_rows", "sobject_unique_values",
            "snr_column", "canonical_base", "approved_role",
            "contract_family", "input_dtype", "finite_rows",
            "positive_rows", "positive_fraction", "min", "q01",
            "q05", "q25", "median", "q75", "q95", "q99",
            "max", "unique_finite", "integer_like_fraction",
            "reference_hit_count", "native_provenance_hit_count",
            "derived_operation_hit_count",
            "name_compatible_with_frozen_native_schema",
            "distribution_plausible_for_snr",
            "documented_native_provenance_ready", "disposition"
        ],
        profile_rows,
    )
    write_csv(
        out / "tables/stage6d3a2d8d_provenance_reference_hits.csv",
        [
            "path", "line_number", "column", "canonical_base",
            "derived_operation_evidence", "native_provenance_evidence",
            "excerpt"
        ],
        all_reference_rows,
    )
    write_csv(
        out / "tables/stage6d3a2d8d_documented_native_candidate_shortlist.csv",
        [
            "companion_path", "sobject_column", "snr_column",
            "canonical_base", "approved_role", "contract_family",
            "finite_rows", "positive_fraction", "median", "q95", "q99",
            "native_provenance_hit_count", "derived_operation_hit_count",
            "disposition"
        ],
        shortlist,
    )

    documented_candidate_ready = len(shortlist) > 0
    ambiguous_multiple = len(shortlist) > 1

    if len(shortlist) == 1:
        diagnosis = "ONE_DOCUMENTED_NATIVE_SNR_CONTRACT_CANDIDATE"
        next_action = (
            "Freeze exactly this column/role contract in D8E and rerun the "
            "sobject→Gaia source-level assembly without adding any other aliases."
        )
    elif len(shortlist) > 1:
        diagnosis = "MULTIPLE_DOCUMENTED_NATIVE_SNR_CANDIDATES_REQUIRE_CHANNEL_SET_ADJUDICATION"
        next_action = (
            "Inspect the shortlist as a detector/channel set. D8E must freeze "
            "only a coherent scalar field or coherent multi-channel GALAH set."
        )
    elif any(
        r["disposition"] == "NAME_COMPATIBLE_BUT_PROVENANCE_NOT_CLOSED"
        for r in profile_rows
    ):
        diagnosis = "NATIVE_NAME_COMPATIBLE_BUT_PROVENANCE_NOT_CLOSED"
        next_action = (
            "Use the provenance-reference table to identify the raw GALAH "
            "source/rename lineage. Do not authorize the column from its name alone."
        )
    elif any(
        r["disposition"] == "PLAUSIBLE_NUMERIC_SNR_BUT_SCHEMA_UNRESOLVED"
        for r in profile_rows
    ):
        diagnosis = "PLAUSIBLE_SNR_VALUES_BUT_COLUMN_SEMANTICS_UNRESOLVED"
        next_action = (
            "The values look S/N-like but the field name is outside the frozen "
            "native schema. An exact upstream schema/column definition is required."
        )
    else:
        diagnosis = "NO_DEFENSIBLE_INTERNAL_NATIVE_SNR_COLUMN"
        next_action = (
            "Reacquire/materialize original GALAH native S/N only. The exact "
            "Gaia DR3 identity bridge is already closed and must not be reacquired."
        )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "diagnosis": diagnosis,
        "audited_snr_column_count": len(profile_rows),
        "documented_native_candidate_count": len(shortlist),
        "prerequisite_ready": prereq,
        "companion_audit_ready": audit_ready,
        "STAGE6D3A2D8C_PREREQUISITE_READY": prereq,
        "D8C_COMPANION_AUDIT_READY": audit_ready,
        "SNR_COLUMN_DISTRIBUTION_AUDIT_READY": True,
        "SNR_PROVENANCE_REFERENCE_AUDIT_READY": True,
        "DOCUMENTED_NATIVE_SNR_CANDIDATE_READY": documented_candidate_ready,
        "MULTIPLE_DOCUMENTED_CANDIDATES_REQUIRE_ADJUDICATION": ambiguous_multiple,
        "EXACT_GAIA_DR3_IDENTITY_ALREADY_CLOSED": True,
        "EXTERNAL_GAIA_ID_BRIDGE_ACQUISITION_REQUIRED": False,
        "NO_NEW_SNR_ALIAS_AUTOMATICALLY_AUTHORIZED": True,
        "FROZEN_OVERLAP_GATES_UNCHANGED": True,
        "TARGET_ABUNDANCE_MATCHING_FORBIDDEN": True,
        "STAGE6D3A2D8D_ADJUDICATION_READY": bool(prereq and audit_ready),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": False,
    }
    write_json(
        out / "validation/stage6d3a2d8d_validation.json",
        validation,
    )
    write_json(
        out / "summaries/stage6d3a2d8d_summary.json",
        {
            "diagnosis": diagnosis,
            "next_action": next_action,
            "documented_native_candidates": [
                {
                    "companion_path": r["companion_path"],
                    "snr_column": r["snr_column"],
                    "canonical_base": r["canonical_base"],
                    "approved_role": r["approved_role"],
                    "contract_family": r["contract_family"],
                    "finite_rows": r["finite_rows"],
                    "median": r["median"],
                    "q95": r["q95"],
                    "q99": r["q99"],
                }
                for r in shortlist
            ],
            "scientific_disposition": (
                "This is an audit-only stage. A column is not authorized merely "
                "because its name or numerical distribution resembles S/N."
            ),
        },
    )

    report = [
        "# Stage-6D3A2D8D GALAH S/N semantic/provenance adjudication",
        "",
        f"- Diagnosis: `{diagnosis}`",
        f"- Audited S/N-like columns: `{len(profile_rows)}`",
        f"- Documented native candidates: `{len(shortlist)}`",
        "- Exact Gaia DR3 identity: `already closed`",
        "- External Gaia bridge acquisition: `forbidden/unnecessary`",
        "- Stage-6D3B authorized: `False`",
        "",
        "This stage does not add an alias or assemble a new source table. It "
        "profiles each unresolved S/N-like field and searches project scripts/"
        "config/docs for exact raw/native provenance evidence.",
        "",
        "Next action:",
        next_action,
        "",
    ]
    (out / "reports/stage6d3a2d8d_report.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    print(json.dumps(
        {"validation": validation, "summary": {"diagnosis": diagnosis, "next_action": next_action}},
        indent=2,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
