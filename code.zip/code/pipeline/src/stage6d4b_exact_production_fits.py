from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import math
import shutil
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd


@dataclass
class WeightedHuberFit:
    beta: np.ndarray
    scale: float
    residual_mad: float
    iterations: int
    converged: bool
    downweight_fraction: float
    rank: int
    condition_number: float
    score_max_abs_per_weight: float
    residuals: np.ndarray
    psi: np.ndarray
    active: np.ndarray
    analysis_weights: np.ndarray


@dataclass
class WeightedClusterInference:
    block_ids: np.ndarray
    block_counts: np.ndarray
    cluster_scores: np.ndarray
    bread_inverse: np.ndarray
    covariance: np.ndarray
    standard_errors: np.ndarray
    draws: np.ndarray | None
    delete_one_delta: np.ndarray
    finite_cluster_correction: float


def now():
    return datetime.now(timezone.utc).isoformat()


def canonical_bytes(obj: Any) -> bytes:
    return json.dumps(
        obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        allow_nan=False
    ).encode("utf-8")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8"
    )


def read_table(path: Path):
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower() == ".feather":
        return pd.read_feather(path)
    return pd.read_csv(path)


def bool_series(s: pd.Series) -> np.ndarray:
    if pd.api.types.is_bool_dtype(s):
        return s.fillna(False).to_numpy(bool)
    if pd.api.types.is_numeric_dtype(s):
        return (pd.to_numeric(s, errors="coerce").fillna(0).to_numpy(float) != 0)
    return s.astype(str).str.strip().str.lower().isin(
        ["true", "1", "yes", "y", "t"]
    ).to_numpy(bool)


def normalize_analysis_weights(w):
    w = np.asarray(w, dtype=float)
    if w.ndim != 1 or not np.all(np.isfinite(w)) or np.any(w <= 0):
        raise ValueError("analysis weights must be finite, positive, one-dimensional")
    return w / float(np.mean(w))


def weighted_huber_fit(
    features: np.ndarray,
    response: np.ndarray,
    analysis_weights: np.ndarray,
    *,
    tuning_constant: float,
    relative_tolerance: float,
    maximum_iterations: int,
    minimum_scale: float,
    robust_scale_fn: Callable[[np.ndarray, float], tuple[float, float]],
) -> WeightedHuberFit:
    features = np.asarray(features, dtype=float)
    response = np.asarray(response, dtype=float)
    aw = normalize_analysis_weights(analysis_weights)

    if features.ndim != 2 or response.ndim != 1 or len(features) != len(response):
        raise ValueError("Huber inputs have incompatible shapes")
    if len(aw) != len(response):
        raise ValueError("analysis-weight vector has wrong length")
    if len(response) <= features.shape[1] + 1:
        raise ValueError("Huber model has too few rows")
    if not np.isfinite(features).all() or not np.isfinite(response).all():
        raise ValueError("Huber inputs must be finite")

    # Exact Stage-4B numerical conditioning contract: unweighted feature
    # centering/scaling. Analysis weights enter only the estimating equation.
    centers = features.mean(axis=0)
    scales = features.std(axis=0)
    scales = np.where(scales > 1.0e-12, scales, 1.0)
    standardized = (features - centers) / scales
    design_standardized = np.column_stack([np.ones(len(response)), standardized])

    sr = np.sqrt(aw)
    beta_standardized = np.linalg.lstsq(
        design_standardized * sr[:, None],
        response * sr,
        rcond=None
    )[0]

    converged = False
    iterations = 0
    for iterations in range(1, int(maximum_iterations) + 1):
        residuals = response - design_standardized @ beta_standardized
        scale, _ = robust_scale_fn(residuals, minimum_scale)
        standardized_residual = residuals / scale
        huber_weights = np.minimum(
            1.0,
            float(tuning_constant) /
            np.maximum(np.abs(standardized_residual), 1.0e-300)
        )
        combined = aw * huber_weights
        square_root = np.sqrt(combined)
        updated = np.linalg.lstsq(
            design_standardized * square_root[:, None],
            response * square_root,
            rcond=None
        )[0]
        change = float(
            np.max(
                np.abs(updated - beta_standardized) /
                (1.0 + np.abs(beta_standardized))
            )
        )
        beta_standardized = updated
        if change < float(relative_tolerance):
            converged = True
            break

    slopes = beta_standardized[1:] / scales
    intercept = beta_standardized[0] - float(np.dot(slopes, centers))
    beta = np.concatenate([[intercept], slopes])

    design = np.column_stack([np.ones(len(response)), features])
    residuals = response - design @ beta
    scale, mad = robust_scale_fn(residuals, minimum_scale)
    standardized_residual = residuals / scale
    psi = np.clip(
        standardized_residual, -float(tuning_constant), float(tuning_constant)
    )
    active = np.abs(standardized_residual) < float(tuning_constant)
    weighted_score = design.T @ (aw * psi)
    cross_product = (
        (design_standardized.T * aw) @ design_standardized / float(np.sum(aw))
    )

    return WeightedHuberFit(
        beta=beta,
        scale=float(scale),
        residual_mad=float(mad),
        iterations=int(iterations),
        converged=bool(converged),
        downweight_fraction=float(np.mean(~active)),
        rank=int(np.linalg.matrix_rank(design_standardized)),
        condition_number=float(np.linalg.cond(cross_product)),
        score_max_abs_per_weight=float(
            np.max(np.abs(weighted_score)) / float(np.sum(aw))
        ),
        residuals=residuals,
        psi=psi,
        active=active,
        analysis_weights=aw,
    )


def weighted_cluster_inference(
    features: np.ndarray,
    response: np.ndarray,
    clusters: np.ndarray,
    fit: WeightedHuberFit,
    *,
    n_draws: int,
    seed: int,
    finite_cluster_correction: bool,
    draw_chunk_size: int = 256,
) -> WeightedClusterInference:
    features = np.asarray(features, dtype=float)
    response = np.asarray(response, dtype=float)
    clusters = np.asarray(clusters, dtype=np.int64)
    aw = np.asarray(fit.analysis_weights, dtype=float)
    design = np.column_stack([np.ones(len(response)), features])

    if len(clusters) != len(response) or len(aw) != len(response):
        raise ValueError("cluster/analysis-weight vector has wrong length")

    block_ids, inverse, block_counts = np.unique(
        clusters, return_inverse=True, return_counts=True
    )
    cluster_scores = np.zeros((len(block_ids), design.shape[1]), dtype=float)
    np.add.at(cluster_scores, inverse, design * (aw * fit.psi)[:, None])

    bread = (
        (design.T * (aw * fit.active.astype(float))) @ design / fit.scale
    )
    if np.linalg.matrix_rank(bread) != design.shape[1]:
        raise ValueError("weighted Huber bread matrix is rank deficient")
    bread_inverse = np.linalg.inv(bread)

    correction = 1.0
    if finite_cluster_correction:
        correction = (len(block_ids) / (len(block_ids) - 1.0)) * (
            (len(response) - 1.0) /
            (len(response) - design.shape[1])
        )

    corrected_scores = cluster_scores * np.sqrt(correction)
    covariance = (
        bread_inverse @
        (corrected_scores.T @ corrected_scores) @
        bread_inverse.T
    )
    covariance = (covariance + covariance.T) / 2.0
    standard_errors = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    delete_one_delta = -(cluster_scores @ bread_inverse.T)

    draws = None
    if int(n_draws) > 0:
        if int(n_draws) % 2 != 0:
            raise ValueError("Antithetic draw count must be even")
        half = int(n_draws) // 2
        delta = np.empty((int(n_draws), design.shape[1]), dtype=float)
        generator = np.random.Generator(np.random.PCG64DXSM(int(seed)))
        for start in range(0, half, int(draw_chunk_size)):
            stop = min(start + int(draw_chunk_size), half)
            multipliers = generator.integers(
                0, 2,
                size=(stop - start, len(block_ids)),
                dtype=np.int8,
            )
            multipliers = multipliers.astype(float) * 2.0 - 1.0
            perturbation = (
                (multipliers @ corrected_scores) @ bread_inverse.T
            )
            delta[start:stop] = perturbation
            delta[half + start:half + stop] = -perturbation
        draws = fit.beta[None, :] + delta

    return WeightedClusterInference(
        block_ids=block_ids,
        block_counts=block_counts.astype(np.int64),
        cluster_scores=cluster_scores,
        bread_inverse=bread_inverse,
        covariance=covariance,
        standard_errors=standard_errors,
        draws=draws,
        delete_one_delta=delete_one_delta,
        finite_cluster_correction=float(correction),
    )


def qsummary(draws, point, se):
    q = np.quantile(draws, [0.025, 0.16, 0.50, 0.84, 0.975])
    draw_sd = float(np.std(draws, ddof=1))
    return {
        "point": float(point),
        "cluster_se": float(se),
        "draw_sd": draw_sd,
        "se_draw_relative_difference": float(
            abs(draw_sd - se) / max(abs(se), 1e-15)
        ),
        "q025": float(q[0]),
        "q16": float(q[1]),
        "q50": float(q[2]),
        "q84": float(q[3]),
        "q975": float(q[4]),
        "sign_stability": float(
            max(np.mean(draws > 0), np.mean(draws < 0))
        ),
        "interval95_excludes_zero": bool(q[0] > 0 or q[4] < 0),
    }


def append_summary(row, prefix, summary):
    for key, value in summary.items():
        row[f"{prefix}_{key}"] = value


def build_features(frame, mask, pivot):
    r = pd.to_numeric(frame.loc[mask, "R"], errors="coerce").to_numpy(float)
    z = pd.to_numeric(frame.loc[mask, "abs_Z"], errors="coerce").to_numpy(float)
    return np.column_stack([r - float(pivot), z])


def build_interaction_features(frame, mask, pivot):
    base = build_features(frame, mask, pivot)
    survey = frame.loc[mask, "survey"].astype(str).to_numpy()
    gal = (survey == "GALAH_CORRECTED").astype(float)
    x_r = base[:, 0]
    z = base[:, 1]
    X = np.column_stack([
        x_r, z, gal, gal * x_r, gal * z
    ])
    return X, survey


def validate_d3a_protocol(protocol):
    g = protocol["gradient_models"]
    u = g["uncertainty"]
    model_map = {x["id"]: x for x in g["models"]}
    checks = {
        "D3A_PRIMARY_NSIDE16_READY":
            int(protocol["common_footprint"]["healpix"]["primary_nside"]) == 16,
        "D3A_POOLED_UNITY_WEIGHT_READY":
            model_map["COMMON_FOOTPRINT_POOLED"]["weights"]
            == "unity after common-footprint trimming",
        "D3A_BALANCED_WEIGHT_READY":
            model_map["COMMON_FOOTPRINT_BALANCED"]["weights"]
            == "survey-balanced overlap weights",
        "D3A_INTERACTION_WEIGHT_READY":
            model_map["COMMON_FOOTPRINT_INTERACTION"]["weights"]
            == "survey-balanced overlap weights",
        "D3A_HUBER_CONTRACT_READY":
            g["estimator"] == "same frozen robust Huber contract as Stage-4B",
        "D3A_4096_DRAWS_READY": int(u["draws"]) == 4096,
        "D3A_PRIMARY_NSIDE_BOOTSTRAP_READY":
            u["resampling_unit"] == "retained primary-nside HEALPix cell",
        "D3A_SEED_NAMESPACE_READY":
            u["seed_namespace"] == "RGB_transportability_stage6d3_v0.17.0",
    }
    return checks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root/"config/stage6d4b_config.json").read_text(encoding="utf-8")
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in [
        "validation", "tables", "draws", "models", "freeze",
        "summaries", "reports", "manifest"
    ]:
        (out/d).mkdir(parents=True, exist_ok=True)

    # Import exact local Stage-4B API.
    sys.path.insert(0, str((root/"scripts").resolve()))
    s4b = importlib.import_module("stage4b_common")
    if not hasattr(s4b, "robust_scale"):
        raise RuntimeError("stage4b_common.robust_scale not available")

    d3a_path = root / cfg["d3a_protocol"]
    d3c8_path = root / cfg["d3c8_validation"]
    d3c9_path = root / cfg["d3c9_validation"]
    d4a1_path = root / cfg["d4a1_validation"]
    source_path = root / cfg["balanced_source"]
    full_path = root / cfg["stage4b_global_estimates"]
    full_draw_path = root / cfg["stage4b_bootstrap_draws"]

    for p in [d3a_path, d3c8_path, d3c9_path, d4a1_path,
              source_path, full_path, full_draw_path]:
        if not p.exists():
            raise FileNotFoundError(str(p))

    d3a = json.loads(d3a_path.read_text(encoding="utf-8"))
    d3a_sha = hashlib.sha256(canonical_bytes(d3a)).hexdigest()
    d3a_checks = validate_d3a_protocol(d3a)

    d3c8 = json.loads(d3c8_path.read_text(encoding="utf-8"))
    d3c9 = json.loads(d3c9_path.read_text(encoding="utf-8"))
    d4a1 = json.loads(d4a1_path.read_text(encoding="utf-8"))

    prerequisites = bool(
        d3a_sha == cfg["expected_d3a_canonical_sha256"]
        and all(d3a_checks.values())
        and d3c8.get("D3C8_FORMAL_PROTOCOL_CLOSURE_READY", False)
        and d3c8.get("amended_protocol_canonical_sha256")
            == cfg["expected_d3c8_amended_sha256"]
        and d3c9.get("PRODUCTION_BALANCED_WEIGHTS_READY", False)
        and d3c9.get("STAGE6D4_SCIENCE_MODELS_READY", False)
        and d4a1.get("STAGE6D4A1_SCHEMA_PREFLIGHT_READY", False)
        and d4a1.get("PRIMARY_LABEL_INPUTS_READY", False)
    )

    frame = read_table(source_path).reset_index(drop=True)
    required = [
        cfg["source_id_column"], cfg["survey_column"],
        cfg["r_column"], cfg["abs_z_column"],
        cfg["weight_column"], cfg["bootstrap_block_column"]
    ]
    for label in cfg["primary_labels"]:
        required += [
            cfg["outcome_columns"][label],
            cfg["eligibility_columns"][label]
        ]
    missing = sorted(set(required) - set(frame.columns))
    if missing:
        raise RuntimeError(f"missing D4B input columns: {missing}")

    source_unique = not frame[cfg["source_id_column"]].duplicated().any()
    input_identity = bool(
        len(frame) == int(cfg["expected_input_rows"])
        and int(frame[cfg["bootstrap_block_column"]].nunique())
            == int(cfg["expected_cell_count"])
        and set(frame[cfg["survey_column"]].astype(str).unique())
            == set(cfg["expected_surveys"])
        and source_unique
    )

    Rall = pd.to_numeric(frame[cfg["r_column"]], errors="coerce").to_numpy(float)
    Zall = pd.to_numeric(frame[cfg["abs_z_column"]], errors="coerce").to_numpy(float)
    Wall = pd.to_numeric(frame[cfg["weight_column"]], errors="coerce").to_numpy(float)
    Ball = pd.to_numeric(frame[cfg["bootstrap_block_column"]], errors="coerce").to_numpy(float)
    numeric_ready = bool(
        np.all(np.isfinite(Rall))
        and np.all(np.isfinite(Zall))
        and np.all(np.isfinite(Wall))
        and np.all(Wall > 0)
        and np.all(np.isfinite(Ball))
        and np.all(np.equal(Ball, np.floor(Ball)))
    )
    if not numeric_ready:
        raise RuntimeError("non-finite/non-positive D4B numeric support")

    full = pd.read_csv(full_path)
    full_draws = read_table(full_draw_path)
    primary_full = full[
        full["label"].isin(cfg["primary_labels"])
        & (full["model_id"].astype(str) == "GLOBAL_PRIMARY")
    ].copy()
    full_ready = bool(
        len(primary_full) == len(cfg["primary_labels"])
        and set(primary_full["label"]) == set(cfg["primary_labels"])
    )
    if not full_ready:
        raise RuntimeError("authoritative five-label GLOBAL_PRIMARY rows unresolved")

    # Copy frozen full-support reference rows in standardized D4B form.
    estimate_rows = []
    for _, r in primary_full.iterrows():
        estimate_rows.append({
            "label": r["label"],
            "model_id": "FULL_SUPPORT_FROZEN",
            "rows": int(r["rows"]),
            "spatial_blocks": int(r["spatial_blocks"]),
            "radial_pivot_kpc": float(r["radial_pivot_kpc"]),
            "weighting": "authoritative_frozen_reference_no_refit",
            "residual_mad": float(r["residual_mad"]),
            "huber_scale": float(r["huber_scale"]),
            "downweight_fraction": float(r["downweight_fraction"]),
            "iterations": int(r["iterations"]),
            "converged": bool(r["converged"]),
            "beta_intercept": float(r["beta_intercept"]),
            "beta_intercept_cluster_se": float(r["beta_intercept_cluster_se"]),
            "beta_intercept_q025": float(r["beta_intercept_q025"]),
            "beta_intercept_q975": float(r["beta_intercept_q975"]),
            "beta_R": float(r["beta_R"]),
            "beta_R_cluster_se": float(r["beta_R_cluster_se"]),
            "beta_R_q025": float(r["beta_R_q025"]),
            "beta_R_q975": float(r["beta_R_q975"]),
            "beta_Z": float(r["beta_Z"]),
            "beta_Z_cluster_se": float(r["beta_Z_cluster_se"]),
            "beta_Z_q025": float(r["beta_Z_q025"]),
            "beta_Z_q975": float(r["beta_Z_q975"]),
            "delta_intercept": np.nan,
            "delta_intercept_cluster_se": np.nan,
            "delta_intercept_q025": np.nan,
            "delta_intercept_q975": np.nan,
            "delta_beta_R": np.nan,
            "delta_beta_R_cluster_se": np.nan,
            "delta_beta_R_q025": np.nan,
            "delta_beta_R_q975": np.nan,
            "delta_beta_Z": np.nan,
            "delta_beta_Z_cluster_se": np.nan,
            "delta_beta_Z_q025": np.nan,
            "delta_beta_Z_q975": np.nan,
            "galah_intercept": np.nan,
            "galah_beta_R": np.nan,
            "galah_beta_Z": np.nan,
        })

    # Preserve frozen full-support draws for later D4C comparison.
    fd = full_draws[
        full_draws["label"].isin(cfg["primary_labels"])
        & (full_draws["model_id"].astype(str) == "GLOBAL_PRIMARY")
    ].copy()
    if len(fd) == 0:
        raise RuntimeError("five-label frozen full-support draws missing")
    fd["model_id"] = "FULL_SUPPORT_FROZEN"

    huber_kwargs = dict(
        tuning_constant=float(cfg["huber"]["tuning_constant"]),
        relative_tolerance=float(cfg["huber"]["relative_tolerance"]),
        maximum_iterations=int(cfg["huber"]["maximum_iterations"]),
        minimum_scale=float(cfg["huber"]["minimum_scale"]),
    )
    n_draws = int(cfg["bootstrap"]["draws"])
    namespace = cfg["bootstrap"]["seed_namespace"]
    finite = bool(cfg["bootstrap"]["finite_cluster_correction"])
    chunk = int(cfg["bootstrap"]["draw_chunk_size"])
    pivot = float(cfg["radial_pivot_kpc"])
    tol = float(cfg["identity_absolute_tolerance"])

    identity_rows = []
    diagnostics = []
    new_draw_frames = []

    total_jobs = len(cfg["primary_labels"]) * 3
    job = 0

    for label in cfg["primary_labels"]:
        yall = pd.to_numeric(
            frame[cfg["outcome_columns"][label]], errors="coerce"
        ).to_numpy(float)
        eligible = bool_series(frame[cfg["eligibility_columns"][label]])
        radial = (
            (Rall > float(cfg["radial_lower_exclusive_kpc"]))
            & (Rall < float(cfg["radial_upper_exclusive_kpc"]))
        )
        mask = eligible & radial & np.isfinite(yall)
        rows = int(mask.sum())
        blocks = pd.to_numeric(
            frame.loc[mask, cfg["bootstrap_block_column"]],
            errors="coerce"
        ).to_numpy(np.int64)

        if rows < int(cfg["minimum_rows"]):
            raise RuntimeError(f"{label}: too few rows")
        if len(np.unique(blocks)) < int(cfg["minimum_spatial_blocks"]):
            raise RuntimeError(f"{label}: too few primary-NSIDE16 blocks")

        X = build_features(frame, mask, pivot)
        y = yall[mask]
        w = Wall[mask]

        # Mandatory algebraic identity gate: weighted extension at w=1
        # must reproduce the exact frozen Stage-4B implementation.
        ref_fit = s4b.fit_huber(X, y, **huber_kwargs)
        one_fit = weighted_huber_fit(
            X, y, np.ones(len(y)),
            robust_scale_fn=s4b.robust_scale,
            **huber_kwargs
        )
        ref_inf = s4b.cluster_inference(
            X, y, blocks, ref_fit,
            n_draws=0,
            seed=s4b.stable_seed(namespace, f"{label}|UNITY_IDENTITY"),
            finite_cluster_correction=finite,
        )
        one_inf = weighted_cluster_inference(
            X, y, blocks, one_fit,
            n_draws=0,
            seed=s4b.stable_seed(namespace, f"{label}|UNITY_IDENTITY"),
            finite_cluster_correction=finite,
            draw_chunk_size=chunk,
        )
        beta_err = float(np.max(np.abs(ref_fit.beta - one_fit.beta)))
        scale_err = float(abs(ref_fit.scale - one_fit.scale))
        psi_err = float(np.max(np.abs(ref_fit.psi - one_fit.psi)))
        cov_err = float(np.max(np.abs(ref_inf.covariance - one_inf.covariance)))
        se_err = float(np.max(np.abs(ref_inf.standard_errors - one_inf.standard_errors)))
        identity_pass = bool(
            beta_err <= tol and scale_err <= tol and psi_err <= tol
            and cov_err <= tol and se_err <= tol
        )
        identity_rows.append({
            "label": label,
            "beta_max_abs_error": beta_err,
            "scale_abs_error": scale_err,
            "psi_max_abs_error": psi_err,
            "covariance_max_abs_error": cov_err,
            "standard_error_max_abs_error": se_err,
            "tolerance": tol,
            "UNITY_WEIGHT_STAGE4B_IDENTITY_READY": identity_pass
        })
        if not identity_pass:
            raise RuntimeError(f"{label}: unity-weight Stage4B identity failed")

        # 1) Common-footprint pooled, exact Stage-4B Huber, unity weights.
        job += 1
        model_id = "COMMON_FOOTPRINT_POOLED"
        print(f"[D4B {job}/{total_jobs}] {label} {model_id} : fit + {n_draws} draws", flush=True)
        fit = s4b.fit_huber(X, y, **huber_kwargs)
        inf = s4b.cluster_inference(
            X, y, blocks, fit,
            n_draws=n_draws,
            seed=s4b.stable_seed(namespace, f"{label}|{model_id}"),
            finite_cluster_correction=finite,
            draw_chunk_size=chunk,
        )
        if inf.draws is None or len(inf.draws) != n_draws:
            raise RuntimeError(f"{label}/{model_id}: draws missing")
        if not fit.converged:
            raise RuntimeError(f"{label}/{model_id}: Huber did not converge")

        row = {
            "label": label, "model_id": model_id, "rows": rows,
            "spatial_blocks": len(inf.block_ids),
            "radial_pivot_kpc": pivot, "weighting": "unity",
            "residual_mad": fit.residual_mad, "huber_scale": fit.scale,
            "downweight_fraction": fit.downweight_fraction,
            "iterations": fit.iterations, "converged": fit.converged,
        }
        for idx, p in enumerate(["beta_intercept", "beta_R", "beta_Z"]):
            s = qsummary(inf.draws[:, idx], fit.beta[idx], inf.standard_errors[idx])
            row[p] = s["point"]
            row[p+"_cluster_se"] = s["cluster_se"]
            row[p+"_q025"] = s["q025"]
            row[p+"_q975"] = s["q975"]
        for p in ["delta_intercept","delta_beta_R","delta_beta_Z",
                  "galah_intercept","galah_beta_R","galah_beta_Z"]:
            row[p] = np.nan
            if p.startswith("delta_"):
                row[p+"_cluster_se"] = np.nan
                row[p+"_q025"] = np.nan
                row[p+"_q975"] = np.nan
        estimate_rows.append(row)
        diagnostics.append({
            "label":label,"model_id":model_id,"rows":rows,
            "blocks":len(inf.block_ids),"parameters":len(fit.beta),
            "converged":fit.converged,"iterations":fit.iterations,
            "condition_number":fit.condition_number,
            "downweight_fraction":fit.downweight_fraction,
            "finite_cluster_correction":inf.finite_cluster_correction
        })
        new_draw_frames.append(pd.DataFrame({
            "label": label, "model_id": model_id,
            "draw_id": np.arange(n_draws, dtype=int),
            "beta_intercept": inf.draws[:,0],
            "beta_R": inf.draws[:,1],
            "beta_Z": inf.draws[:,2],
            "delta_intercept": np.nan,
            "delta_beta_R": np.nan,
            "delta_beta_Z": np.nan,
            "galah_intercept": np.nan,
            "galah_beta_R": np.nan,
            "galah_beta_Z": np.nan,
        }))

        # 2) Common-footprint balanced, multiplicative analysis weights.
        job += 1
        model_id = "COMMON_FOOTPRINT_BALANCED"
        print(f"[D4B {job}/{total_jobs}] {label} {model_id} : fit + {n_draws} draws", flush=True)
        wfit = weighted_huber_fit(
            X, y, w, robust_scale_fn=s4b.robust_scale, **huber_kwargs
        )
        winf = weighted_cluster_inference(
            X, y, blocks, wfit,
            n_draws=n_draws,
            seed=s4b.stable_seed(namespace, f"{label}|{model_id}"),
            finite_cluster_correction=finite,
            draw_chunk_size=chunk,
        )
        if winf.draws is None or len(winf.draws) != n_draws:
            raise RuntimeError(f"{label}/{model_id}: draws missing")
        if not wfit.converged:
            raise RuntimeError(f"{label}/{model_id}: weighted Huber did not converge")

        row = {
            "label": label, "model_id": model_id, "rows": rows,
            "spatial_blocks": len(winf.block_ids),
            "radial_pivot_kpc": pivot,
            "weighting": "D3C9_balance_weight_final_mean1",
            "residual_mad": wfit.residual_mad, "huber_scale": wfit.scale,
            "downweight_fraction": wfit.downweight_fraction,
            "iterations": wfit.iterations, "converged": wfit.converged,
        }
        for idx, p in enumerate(["beta_intercept", "beta_R", "beta_Z"]):
            s = qsummary(winf.draws[:, idx], wfit.beta[idx], winf.standard_errors[idx])
            row[p] = s["point"]
            row[p+"_cluster_se"] = s["cluster_se"]
            row[p+"_q025"] = s["q025"]
            row[p+"_q975"] = s["q975"]
        for p in ["delta_intercept","delta_beta_R","delta_beta_Z",
                  "galah_intercept","galah_beta_R","galah_beta_Z"]:
            row[p] = np.nan
            if p.startswith("delta_"):
                row[p+"_cluster_se"] = np.nan
                row[p+"_q025"] = np.nan
                row[p+"_q975"] = np.nan
        estimate_rows.append(row)
        diagnostics.append({
            "label":label,"model_id":model_id,"rows":rows,
            "blocks":len(winf.block_ids),"parameters":len(wfit.beta),
            "converged":wfit.converged,"iterations":wfit.iterations,
            "condition_number":wfit.condition_number,
            "downweight_fraction":wfit.downweight_fraction,
            "finite_cluster_correction":winf.finite_cluster_correction,
            "analysis_weight_min":float(np.min(normalize_analysis_weights(w))),
            "analysis_weight_max":float(np.max(normalize_analysis_weights(w))),
        })
        new_draw_frames.append(pd.DataFrame({
            "label": label, "model_id": model_id,
            "draw_id": np.arange(n_draws, dtype=int),
            "beta_intercept": winf.draws[:,0],
            "beta_R": winf.draws[:,1],
            "beta_Z": winf.draws[:,2],
            "delta_intercept": np.nan,
            "delta_beta_R": np.nan,
            "delta_beta_Z": np.nan,
            "galah_intercept": np.nan,
            "galah_beta_R": np.nan,
            "galah_beta_Z": np.nan,
        }))

        # 3) Weighted common-footprint survey interaction.
        job += 1
        model_id = "COMMON_FOOTPRINT_INTERACTION"
        print(f"[D4B {job}/{total_jobs}] {label} {model_id} : fit + {n_draws} draws", flush=True)
        Xi, surveys = build_interaction_features(frame, mask, pivot)
        if set(np.unique(surveys)) != set(cfg["expected_surveys"]):
            raise RuntimeError(f"{label}: interaction lacks exact two-survey support")

        ifit = weighted_huber_fit(
            Xi, y, w, robust_scale_fn=s4b.robust_scale, **huber_kwargs
        )
        iinf = weighted_cluster_inference(
            Xi, y, blocks, ifit,
            n_draws=n_draws,
            seed=s4b.stable_seed(namespace, f"{label}|{model_id}"),
            finite_cluster_correction=finite,
            draw_chunk_size=chunk,
        )
        if iinf.draws is None or len(iinf.draws) != n_draws:
            raise RuntimeError(f"{label}/{model_id}: draws missing")
        if not ifit.converged:
            raise RuntimeError(f"{label}/{model_id}: weighted Huber did not converge")

        b = ifit.beta
        d = iinf.draws
        # Parameter order:
        # intercept, beta_R(APOGEE), beta_Z(APOGEE),
        # delta_intercept(GALAH-APOGEE), delta_R, delta_Z.
        row = {
            "label": label, "model_id": model_id, "rows": rows,
            "spatial_blocks": len(iinf.block_ids),
            "radial_pivot_kpc": pivot,
            "weighting": "D3C9_balance_weight_final_mean1",
            "residual_mad": ifit.residual_mad, "huber_scale": ifit.scale,
            "downweight_fraction": ifit.downweight_fraction,
            "iterations": ifit.iterations, "converged": ifit.converged,
        }
        names = [
            "beta_intercept","beta_R","beta_Z",
            "delta_intercept","delta_beta_R","delta_beta_Z"
        ]
        for idx, p in enumerate(names):
            s = qsummary(d[:, idx], b[idx], iinf.standard_errors[idx])
            row[p] = s["point"]
            row[p+"_cluster_se"] = s["cluster_se"]
            row[p+"_q025"] = s["q025"]
            row[p+"_q975"] = s["q975"]

        galah_intercept_draw = d[:,0] + d[:,3]
        galah_R_draw = d[:,1] + d[:,4]
        galah_Z_draw = d[:,2] + d[:,5]
        row["galah_intercept"] = float(b[0] + b[3])
        row["galah_beta_R"] = float(b[1] + b[4])
        row["galah_beta_Z"] = float(b[2] + b[5])

        estimate_rows.append(row)
        diagnostics.append({
            "label":label,"model_id":model_id,"rows":rows,
            "blocks":len(iinf.block_ids),"parameters":len(ifit.beta),
            "converged":ifit.converged,"iterations":ifit.iterations,
            "condition_number":ifit.condition_number,
            "downweight_fraction":ifit.downweight_fraction,
            "finite_cluster_correction":iinf.finite_cluster_correction,
            "APOGEE_rows":int(np.sum(surveys=="APOGEE_NATIVE")),
            "GALAH_rows":int(np.sum(surveys=="GALAH_CORRECTED")),
        })
        new_draw_frames.append(pd.DataFrame({
            "label": label, "model_id": model_id,
            "draw_id": np.arange(n_draws, dtype=int),
            "beta_intercept": d[:,0],
            "beta_R": d[:,1],
            "beta_Z": d[:,2],
            "delta_intercept": d[:,3],
            "delta_beta_R": d[:,4],
            "delta_beta_Z": d[:,5],
            "galah_intercept": galah_intercept_draw,
            "galah_beta_R": galah_R_draw,
            "galah_beta_Z": galah_Z_draw,
        }))

    identity_df = pd.DataFrame(identity_rows)
    identity_df.to_csv(
        out/"tables/stage6d4b_weighted_huber_unity_identity_audit.csv",
        index=False
    )
    identity_ready = bool(
        identity_df["UNITY_WEIGHT_STAGE4B_IDENTITY_READY"].all()
    )

    est_df = pd.DataFrame(estimate_rows)
    est_df.to_csv(
        out/"tables/footprint_gradient_estimates.csv", index=False
    )
    pd.DataFrame(diagnostics).to_csv(
        out/"tables/stage6d4b_model_diagnostics.csv", index=False
    )

    # Normalize frozen draw schema to the new common columns, then append.
    draw_cols = [
        "label","model_id","draw_id",
        "beta_intercept","beta_R","beta_Z",
        "delta_intercept","delta_beta_R","delta_beta_Z",
        "galah_intercept","galah_beta_R","galah_beta_Z"
    ]
    for c in draw_cols:
        if c not in fd.columns:
            fd[c] = np.nan
    all_draws = pd.concat(
        [fd[draw_cols]] + [x[draw_cols] for x in new_draw_frames],
        ignore_index=True
    )
    draw_path = out/"draws/footprint_gradient_bootstrap_draws.parquet"
    all_draws.to_parquet(draw_path, index=False)

    model_counts = (
        est_df.groupby("model_id")["label"].nunique().to_dict()
    )
    all_models_ready = all(
        int(model_counts.get(m,0)) == len(cfg["primary_labels"])
        for m in cfg["models"]
    )
    draw_counts = (
        all_draws.groupby(["label","model_id"]).size().reset_index(name="n")
    )
    new_model_draws_ready = bool(
        (
            draw_counts[
                draw_counts["model_id"].isin([
                    "COMMON_FOOTPRINT_POOLED",
                    "COMMON_FOOTPRINT_BALANCED",
                    "COMMON_FOOTPRINT_INTERACTION"
                ])
            ]["n"] == n_draws
        ).all()
    )

    all_converged = bool(
        est_df[
            est_df["model_id"] != "FULL_SUPPORT_FROZEN"
        ]["converged"].fillna(False).all()
    )
    all_blocks_ready = bool(
        (
            est_df[
                est_df["model_id"].isin([
                    "COMMON_FOOTPRINT_POOLED",
                    "COMMON_FOOTPRINT_BALANCED",
                    "COMMON_FOOTPRINT_INTERACTION"
                ])
            ]["spatial_blocks"]
            >= int(cfg["minimum_spatial_blocks"])
        ).all()
    )

    production_ready = bool(
        prerequisites
        and input_identity
        and numeric_ready
        and full_ready
        and identity_ready
        and all_models_ready
        and new_model_draws_ready
        and all_converged
        and all_blocks_ready
    )

    method = {
        "stage": cfg["stage"],
        "d3a_frozen_protocol_canonical_sha256": d3a_sha,
        "d3c8_amended_balance_protocol_sha256":
            cfg["expected_d3c8_amended_sha256"],
        "source": cfg["balanced_source"],
        "primary_labels": cfg["primary_labels"],
        "secondary_alpha3": "not_source_level_available_in_D3C9_balanced_source",
        "models": cfg["models"],
        "coordinate_formula": {
            "pooled_balanced": "y = beta0 + beta_R*(R-8.2) + beta_Z*abs_Z + residual",
            "interaction": (
                "y = beta0 + beta_R*(R-8.2) + beta_Z*abs_Z + "
                "I_GALAH*(delta0 + delta_R*(R-8.2) + delta_Z*abs_Z) + residual"
            )
        },
        "estimator": "Stage-4B Huber_M_estimator_IRLS contract",
        "weighted_operational_closure":
            cfg["weighted_huber_operational_closure"],
        "uncertainty": {
            "engine": (
                "Stage-4B antithetic Rademacher spatial-cluster multiplier "
                "machinery, applied to D3A-frozen retained primary-NSIDE16 cells"
            ),
            "block_column": cfg["bootstrap_block_column"],
            "draws": n_draws,
            "seed_namespace": namespace,
            "finite_cluster_correction": finite
        },
        "claim_boundary": [
            "footprint robustness/sensitivity within tested shared support only",
            "survey-interaction contrast within balanced common footprint only",
            "not volume complete",
            "not selection-function corrected",
            "not independent GALAH replication",
            "no causal footprint claim",
            "no target abundance matching",
            "no component-resolved gradients"
        ]
    }
    write_json(out/"freeze/stage6d4b_method_definition.json", method)

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "d3a_frozen_protocol_canonical_sha256": d3a_sha,
        "d3c8_amended_balance_protocol_sha256":
            cfg["expected_d3c8_amended_sha256"],
        "input_rows": len(frame),
        "input_primary_nside16_cells":
            int(frame[cfg["bootstrap_block_column"]].nunique()),
        "analysis_labels": cfg["primary_labels"],
        "secondary_alpha3_included": False,
        "D3A_PROTOCOL_IDENTITY_READY":
            d3a_sha == cfg["expected_d3a_canonical_sha256"],
        **d3a_checks,
        "D3C8_AMENDED_BALANCE_PROTOCOL_READY":
            d3c8.get("amended_protocol_canonical_sha256")
            == cfg["expected_d3c8_amended_sha256"],
        "D3C9_PRODUCTION_BALANCED_SOURCE_READY":
            d3c9.get("PRODUCTION_BALANCED_WEIGHTS_READY", False),
        "D4A1_PRIMARY_LABEL_SCHEMA_READY":
            d4a1.get("PRIMARY_LABEL_INPUTS_READY", False),
        "D4B_ALL_PREREQUISITES_READY": prerequisites,
        "SOURCE_ID_UNIQUE_READY": source_unique,
        "INPUT_SHAPE_SURVEY_CELL_IDENTITY_READY": input_identity,
        "INPUT_NUMERIC_SUPPORT_READY": numeric_ready,
        "FULL_SUPPORT_FROZEN_REFERENCE_READY": full_ready,
        "WEIGHTED_HUBER_UNITY_STAGE4B_IDENTITY_READY": identity_ready,
        "WEIGHTED_HUBER_OUTCOME_BLIND_OPERATIONAL_CLOSURE_READY": True,
        "PRIMARY_NSIDE16_BOOTSTRAP_BLOCK_USED": True,
        "GAIA_HEALPIX5_NOT_USED_FOR_D4_COMMON_FOOTPRINT_BOOTSTRAP": True,
        "NEW_MODEL_4096_DRAWS_READY": new_model_draws_ready,
        "ALL_FIVE_LABELS_ALL_FOUR_MODELS_READY": all_models_ready,
        "ALL_NEW_HUBER_FITS_CONVERGED": all_converged,
        "ALL_NEW_MODELS_MINIMUM_100_BLOCKS_READY": all_blocks_ready,
        "NO_TARGET_ABUNDANCE_USED_IN_BALANCING_OR_SELECTION": True,
        "NO_SAMPLE_RESELECTION_AFTER_OUTCOME_INSPECTION": True,
        "NO_VOLUME_COMPLETE_OR_CAUSAL_CLAIM_AUTHORIZED": True,
        "STAGE6D4B_PRODUCTION_FITS_READY": production_ready,
        "STAGE6D4C_PRACTICAL_EQUIVALENCE_CLASSIFICATION_READY":
            production_ready,
    }
    write_json(
        out/"validation/stage6d4b_validation.json", validation
    )

    summary = {
        "stage": cfg["stage"],
        "production_ready": production_ready,
        "models": model_counts,
        "weighted_huber_identity_max_errors": {
            "beta": float(identity_df["beta_max_abs_error"].max()),
            "scale": float(identity_df["scale_abs_error"].max()),
            "psi": float(identity_df["psi_max_abs_error"].max()),
            "covariance": float(identity_df["covariance_max_abs_error"].max()),
            "standard_error": float(identity_df["standard_error_max_abs_error"].max()),
        },
        "next_action": (
            "Run Stage-6D4C practical-equivalence and transport classification "
            "using the frozen D3A margins and D4B production draw table."
            if production_ready else
            "Do not classify; inspect failed D4B production gate."
        )
    }
    write_json(out/"summaries/stage6d4b_summary.json", summary)

    (out/"reports/stage6d4b_report.md").write_text(
        "\n".join([
            "# Stage-6D4B exact production fits",
            "",
            f"- Production ready: `{production_ready}`",
            f"- D3A canonical SHA: `{d3a_sha}`",
            f"- Input rows: `{len(frame)}`",
            f"- Primary NSIDE16 cells: `{frame[cfg['bootstrap_block_column']].nunique()}`",
            f"- Primary labels: `{', '.join(cfg['primary_labels'])}`",
            f"- Draws/new model/label: `{n_draws}`",
            f"- Weighted-Huber unity identity ready: `{identity_ready}`",
            "",
            "D4 common-footprint bootstrap uses the D3A-frozen retained "
            "primary-NSIDE16 cells. `gaia_healpix5` is not the governing "
            "D4 uncertainty block.",
            ""
        ]),
        encoding="utf-8"
    )

    manifest = []
    for p in sorted(out.rglob("*")):
        if p.is_file() and "manifest" not in p.parts:
            manifest.append({
                "path": str(p.relative_to(root)).replace("\\","/"),
                "size_bytes": p.stat().st_size,
                "sha256": sha256_file(p)
            })
    pd.DataFrame(manifest).to_csv(
        out/"manifest/stage6d4b_output_manifest_sha256.csv",
        index=False
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2, ensure_ascii=False
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
