from __future__ import annotations

import argparse
import hashlib
import subprocess
import sys
import zipfile
from pathlib import Path

EXPECTED_MAIN_SHA = "ac3fb1c185292858f9222aec366570f6250a83e056d678e3c4b27df326e98edd"
D6A_SCRIPT = Path("src/stage6d6a_mnras_manuscript_reconciliation.py")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def candidate_score(parent: Path) -> int:
    score = 0
    if (parent / "figures").is_dir():
        score += 4
    if (parent / "mnras.cls").exists():
        score += 2
    if (parent / "VALIDATION.json").exists():
        score += 1
    if "RGB_atlas_MNRAS_complete_flat_v1_0_0".lower() in parent.name.lower():
        score += 8
    return score


def find_exact_directory(search_roots: list[Path]) -> Path | None:
    hits: list[tuple[int, int, Path]] = []
    seen: set[str] = set()
    for base in search_roots:
        if not base.exists():
            continue
        try:
            iterator = base.rglob("main.tex")
        except OSError:
            continue
        for mt in iterator:
            try:
                key = str(mt.resolve()).lower()
                if key in seen:
                    continue
                seen.add(key)
                if sha256_file(mt) == EXPECTED_MAIN_SHA:
                    parent = mt.parent
                    hits.append((candidate_score(parent), -len(str(parent)), parent))
            except (OSError, PermissionError):
                continue
    if not hits:
        return None
    hits.sort(reverse=True, key=lambda x: (x[0], x[1]))
    return hits[0][2]


def find_exact_zip(search_roots: list[Path]) -> Path | None:
    hits: list[Path] = []
    seen: set[str] = set()
    for base in search_roots:
        if not base.exists():
            continue
        try:
            iterator = base.rglob("RGB_atlas_MNRAS*.zip")
        except OSError:
            continue
        for zp in iterator:
            try:
                key = str(zp.resolve()).lower()
                if key in seen:
                    continue
                seen.add(key)
                with zipfile.ZipFile(zp, "r") as z:
                    names = [
                        n for n in z.namelist()
                        if n.replace("\\", "/").endswith("/main.tex") or n == "main.tex"
                    ]
                    for name in names:
                        if hashlib.sha256(z.read(name)).hexdigest() == EXPECTED_MAIN_SHA:
                            hits.append(zp)
                            break
            except (OSError, PermissionError, zipfile.BadZipFile):
                continue
    if not hits:
        return None
    hits.sort(key=lambda p: len(str(p)))
    return hits[0]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()

    root = Path(args.project_root).resolve()
    d6a = root / D6A_SCRIPT
    if not d6a.exists():
        raise FileNotFoundError(
            f"D6A v0.27.0 source missing: {d6a}. "
            "Extract the D6A package first."
        )

    search_roots = []
    for p in [root, root / "outputs", Path.home() / "Downloads"]:
        try:
            rp = p.resolve()
        except OSError:
            rp = p
        if p.exists() and rp not in search_roots:
            search_roots.append(rp)

    print("[D6A1] Searching recursively for exact baseline main.tex SHA-256...")
    for p in search_roots:
        print(f"[D6A1] SEARCH_ROOT={p}")

    baseline = find_exact_directory(search_roots)
    source_kind = "DIRECTORY"
    if baseline is None:
        print("[D6A1] No exact directory match; inspecting likely MNRAS ZIPs...")
        baseline = find_exact_zip(search_roots)
        source_kind = "ZIP"

    if baseline is None:
        raise RuntimeError(
            "Exact baseline was not found recursively. "
            f"Required main.tex SHA-256: {EXPECTED_MAIN_SHA}"
        )

    print(f"[D6A1] BASELINE_KIND={source_kind}")
    print(f"[D6A1] EXACT_BASELINE={baseline}")
    print(f"[D6A1] REQUIRED_MAIN_SHA256={EXPECTED_MAIN_SHA}")
    print("[D6A1] Invoking unchanged Stage-6D6A manuscript reconciliation...")

    proc = subprocess.run(
        [
            sys.executable,
            str(d6a),
            "--project-root",
            str(root),
            "--baseline",
            str(baseline),
        ],
        cwd=str(root),
    )
    if proc.returncode != 0:
        return int(proc.returncode)

    validation = (
        root
        / "outputs"
        / "stage6d6a_mnras_manuscript_reconciliation"
        / "validation"
        / "stage6d6a_validation.json"
    )
    if not validation.exists():
        raise RuntimeError("D6A validation missing after recursive-baseline rerun")

    print("[OK] Stage-6D6A1 recursive baseline locator completed.")
    print(
        "Inspect outputs\\stage6d6a_mnras_manuscript_reconciliation\\"
        "validation\\stage6d6a_validation.json"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
