from __future__ import annotations
import argparse, hashlib, json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

def now(): return datetime.now(timezone.utc).isoformat()

def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):
            h.update(b)
    return h.hexdigest()

def find_pair(obj,key,value):
    if isinstance(obj,dict):
        for k,v in obj.items():
            if str(k)==key and str(v)==value:
                return True
            if find_pair(v,key,value):
                return True
    elif isinstance(obj,list):
        return any(find_pair(x,key,value) for x in obj)
    return False

def exact_series_equal(x,y):
    x=x.reset_index(drop=True); y=y.reset_index(drop=True)
    if pd.api.types.is_numeric_dtype(x.dtype):
        xa=pd.to_numeric(x,errors="coerce").to_numpy()
        ya=pd.to_numeric(y,errors="coerce").to_numpy()
        return np.array_equal(xa,ya,equal_nan=True)
    return x.astype(str).equals(y.astype(str))

def candidate_audit(bkey,dkey,candidate,minimum_purity):
    x=bkey.merge(dkey,on="_sid",how="left",validate="one_to_one",indicator=True)
    matched=x["_merge"].eq("both")
    xm=x.loc[matched,["_balanced_survey",candidate]].copy()
    xm[candidate]=xm[candidate].astype(str)
    cross=pd.crosstab(xm["_balanced_survey"],xm[candidate],dropna=False)

    mapping={}
    purity_by_balanced={}
    for bs,row in cross.iterrows():
        total=int(row.sum())
        if total==0: continue
        best=row.idxmax()
        purity=float(row.max()/total)
        mapping[str(best)]=str(bs)
        purity_by_balanced[str(bs)]=purity

    reverse_counts={}
    for a4,bs in mapping.items():
        reverse_counts.setdefault(bs,[]).append(a4)
    bijective=bool(mapping) and all(len(v)==1 for v in reverse_counts.values())
    minpur=min(purity_by_balanced.values()) if purity_by_balanced else 0.0
    mapped=xm[candidate].map(mapping)
    row_agreement=float((mapped==xm["_balanced_survey"].astype(str)).mean()) if len(xm) else 0.0
    ready=bool(minpur>=minimum_purity and row_agreement>=minimum_purity and bijective)

    rows=[]
    for bs,row in cross.iterrows():
        for a4,n in row.items():
            if int(n)>0:
                rows.append({
                    "balanced_survey":str(bs),
                    "stage4a_survey_value":str(a4),
                    "rows":int(n),
                    "candidate":candidate
                })
    return {
        "candidate":candidate,
        "id_matched_rows":int(matched.sum()),
        "id_unmatched_rows":int((~matched).sum()),
        "min_mapping_purity":float(minpur),
        "row_agreement_fraction":float(row_agreement),
        "bijective_crosswalk":bijective,
        "ready":ready,
        "mapping":mapping,
        "crosswalk_rows":rows
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",default=".")
    a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage8b1c1_config.json").read_text(encoding="utf-8"))

    bal=root/c["balanced_source"]
    st4=root/c["stage4a_design"]
    st2=root/c["stage2c_validation"]
    d4c=root/c["stage6d4a_config"]
    for p in [bal,st4,st2,d4c]:
        if not p.exists(): raise FileNotFoundError(p)

    bschema=pq.ParquetFile(bal).schema_arrow.names
    dschema=pq.ParquetFile(st4).schema_arrow.names
    required_bal=[c["balanced_id_column"],c["balanced_survey_column"]]
    required_d=[c["stage4a_id_column"],c["alpha_frozen_column"],c["alpha_primary_flag"]]
    if not all(x in bschema for x in required_bal):
        raise RuntimeError(f"D3C9 key schema missing: {[x for x in required_bal if x not in bschema]}")
    if not all(x in dschema for x in required_d):
        raise RuntimeError(f"Stage4A schema missing: {[x for x in required_d if x not in dschema]}")

    survey_candidates=[x for x in c["stage4a_survey_candidates"] if x in dschema]
    if not survey_candidates: raise RuntimeError("No Stage4A survey candidate columns found")

    b=pd.read_parquet(bal)
    if len(b)!=int(c["expected_balanced_rows"]):
        raise RuntimeError(f"balanced row identity mismatch: {len(b)}")
    if pd.api.types.is_float_dtype(b[c["balanced_id_column"]].dtype):
        raise RuntimeError("balanced source_id float coercion forbidden")
    if b.duplicated([c["balanced_id_column"],c["balanced_survey_column"]]).any():
        raise RuntimeError("D3C9 balanced key duplicates")

    dcols=[c["stage4a_id_column"]]+survey_candidates+[c["alpha_frozen_column"],c["alpha_primary_flag"]]
    d=pd.read_parquet(st4,columns=dcols)
    if pd.api.types.is_float_dtype(d[c["stage4a_id_column"]].dtype):
        raise RuntimeError("Stage4A Gaia source ID float coercion forbidden")
    if d.duplicated([c["stage4a_id_column"]]).any():
        dup=int(d.duplicated([c["stage4a_id_column"]],keep=False).sum())
        raise RuntimeError(f"Stage4A gaia_dr3_source_id is not unique; duplicate rows={dup}")

    bkey=pd.DataFrame({
        "_sid":b[c["balanced_id_column"]].astype(str),
        "_balanced_survey":b[c["balanced_survey_column"]].astype(str)
    })
    dkey=pd.DataFrame({"_sid":d[c["stage4a_id_column"]].astype(str)})
    for sc in survey_candidates:
        dkey[sc]=d[sc].astype(str).to_numpy()

    audits=[]; all_cross=[]
    for sc in survey_candidates:
        q=candidate_audit(bkey,dkey[["_sid",sc]],sc,float(c["minimum_survey_mapping_purity"]))
        audits.append(q); all_cross.extend(q["crosswalk_rows"])

    ready_candidates=[q for q in audits if q["ready"]]
    order={name:i for i,name in enumerate(c["stage4a_survey_candidates"])}
    selected=None
    if ready_candidates:
        ready_candidates=sorted(
            ready_candidates,
            key=lambda q:(-q["row_agreement_fraction"],-q["min_mapping_purity"],order[q["candidate"]])
        )
        selected=ready_candidates[0]

    outdir=root/c["output_dir"]
    for q in ["tables","validation","assembled","freeze"]:
        (outdir/q).mkdir(parents=True,exist_ok=True)

    pd.DataFrame(all_cross).to_csv(outdir/"tables/stage8b1c1_survey_crosswalk_audit.csv",index=False)
    pd.DataFrame([{
        "candidate":q["candidate"],
        "id_matched_rows":q["id_matched_rows"],
        "id_unmatched_rows":q["id_unmatched_rows"],
        "min_mapping_purity":q["min_mapping_purity"],
        "row_agreement_fraction":q["row_agreement_fraction"],
        "bijective_crosswalk":q["bijective_crosswalk"],
        "ready":q["ready"]
    } for q in audits]).to_csv(outdir/"tables/stage8b1c1_survey_candidate_summary.csv",index=False)

    if selected is None:
        val={
          "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
          "STAGE4A_KEY_ALIAS_SCHEMA_READY":True,
          "SURVEY_LINEAGE_CROSSWALK_READY":False,
          "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
          "STAGE8B1C1_PROVENANCE_JOIN_READY":False,
          "NEXT_ACTION":"Inspect survey candidate crosswalk; no automatic attachment authorized."
        }
        write_json(outdir/"validation/stage8b1c1_validation.json",val)
        print(json.dumps(val,indent=2))
        return 2

    selected_name=selected["candidate"]; mapping=selected["mapping"]
    att=pd.DataFrame({
        "_sid":d[c["stage4a_id_column"]].astype(str),
        "_stage4a_survey_raw":d[selected_name].astype(str),
        c["alpha_frozen_column"]:d[c["alpha_frozen_column"]],
        c["alpha_primary_flag"]:d[c["alpha_primary_flag"]]
    })
    att["_balanced_survey"]=att["_stage4a_survey_raw"].map(mapping)

    m=b.copy()
    m["_sid"]=m[c["balanced_id_column"]].astype(str)
    m["_balanced_survey"]=m[c["balanced_survey_column"]].astype(str)
    keep=["_sid","_balanced_survey",c["alpha_frozen_column"],c["alpha_primary_flag"]]
    out=m.merge(att[keep],on=["_sid","_balanced_survey"],how="left",validate="one_to_one",indicator=True)
    if len(out)!=len(b): raise RuntimeError("attachment changed balanced row count")

    matched=int(out["_merge"].eq("both").sum())
    unmatched=int(out["_merge"].ne("both").sum())
    match_fraction=matched/len(b)
    aval=pd.to_numeric(out[c["alpha_frozen_column"]],errors="coerce").to_numpy(float)
    finite=int(np.isfinite(aval).sum())

    out=out.drop(columns=["_sid","_balanced_survey","_merge"])
    original_identity=all(exact_series_equal(b[col],out[col]) for col in b.columns)

    v2=json.loads(st2.read_text(encoding="utf-8"))
    cfg4=json.loads(d4c.read_text(encoding="utf-8"))
    text2=json.dumps(v2,ensure_ascii=False).lower()
    definition_ready=("alpha3" in text2 and "unweighted mg-si-ca mean" in text2)
    map_ready=find_pair(cfg4,"alpha3","alpha3_hom")
    flag_ready=find_pair(cfg4,"alpha3","alpha3_gradient_primary_ok")
    if not flag_ready:
        flag_ready=("alpha3_gradient_primary_ok" in json.dumps(cfg4,ensure_ascii=False))
    storage_ready=(c["alpha_frozen_column"] in dschema and c["alpha_primary_flag"] in dschema)

    ready=bool(
        selected["ready"] and
        match_fraction>=float(c["minimum_id_match_fraction"]) and
        unmatched==0 and original_identity and finite>0 and
        definition_ready and map_ready and flag_ready and storage_ready
    )

    outpath=root/c["output_attached_source"]
    outpath.parent.mkdir(parents=True,exist_ok=True)
    out.to_parquet(outpath,index=False)

    (outdir/"freeze/stage8b1c1_protocol_frozen.json").write_text(
        (root/"protocol/stage8b1c1_protocol.json").read_text(encoding="utf-8"),
        encoding="utf-8"
    )

    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "D3C9_ID_COLUMN":"source_id",
      "STAGE4A_ID_COLUMN":"gaia_dr3_source_id",
      "SELECTED_STAGE4A_SURVEY_COLUMN":selected_name,
      "SURVEY_CROSSWALK":mapping,
      "SURVEY_MAPPING_MIN_PURITY":selected["min_mapping_purity"],
      "SURVEY_ROW_AGREEMENT_FRACTION":selected["row_agreement_fraction"],
      "SURVEY_LINEAGE_CROSSWALK_READY":selected["ready"],
      "STAGE2C_ALPHA3_FIXED_DEFINITION_READY":definition_ready,
      "STAGE6D4A_ALPHA3_TO_ALPHA3_HOM_MAPPING_READY":map_ready,
      "STAGE6D4A_ALPHA3_FLAG_REFERENCE_READY":flag_ready,
      "STAGE4A_ALPHA3_HOM_STORAGE_READY":storage_ready,
      "AUTHORIZED_SCIENCE_NAME":"alpha3",
      "AUTHORIZED_FROZEN_STORAGE_COLUMN":"alpha3_hom",
      "AUTHORIZED_PRIMARY_FLAG":"alpha3_gradient_primary_ok",
      "BALANCED_ROWS":len(b),"MATCHED_ROWS":matched,"UNMATCHED_ROWS":unmatched,
      "ALPHA3_HOM_FINITE_ROWS":finite,"ALPHA3_HOM_FINITE_FRACTION":finite/len(b),
      "SOURCE_ID_FLOAT_COERCION_USED":False,
      "ABUNDANCE_OR_OUTCOME_MATCHING_USED":False,
      "BALANCING_WEIGHTS_CHANGED":False,
      "SUPPORT_SELECTION_CHANGED":False,
      "ORIGINAL_BALANCED_COLUMNS_VALUE_IDENTITY_READY":original_identity,
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":False,
      "REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED":False,
      "STAGE8B1C1_PROVENANCE_JOIN_READY":ready,
      "STAGE8B1_REPLAY_WITH_ALPHA3_HOM_READY":ready,
      "ATTACHED_SOURCE_RELATIVE_PATH":c["output_attached_source"],
      "BALANCED_SOURCE_SHA256":sha_file(bal),
      "STAGE4A_DESIGN_SHA256":sha_file(st4)
    }
    write_json(outdir/"validation/stage8b1c1_validation.json",val)
    print(json.dumps(val,indent=2,ensure_ascii=False))
    return 0 if ready else 2

if __name__=="__main__":
    raise SystemExit(main())
