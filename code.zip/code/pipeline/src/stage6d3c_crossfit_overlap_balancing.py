from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler


def now():
    return datetime.now(timezone.utc).isoformat()


def rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_df_csv(path: Path, frame: pd.DataFrame):
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)


def sha256_file(path: Path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def resolve(path: Path):
    for candidate in [path, path.with_suffix(".csv"), path.with_suffix(".feather")]:
        if candidate.exists():
            return candidate
    return None


def read_table(path: Path):
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower() == ".feather":
        return pd.read_feather(path)
    return pd.read_csv(path)


def source_hash_fold(source_id: Any, n_folds: int):
    token = str(source_id).encode("utf-8")
    digest = hashlib.sha256(token).digest()
    value = int.from_bytes(digest[:8], byteorder="big", signed=False)
    return value % int(n_folds)


def weighted_mean(values, weights):
    values = np.asarray(values, dtype=float)
    weights = np.asarray(weights, dtype=float)
    ok = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    if not np.any(ok):
        return np.nan
    return float(np.sum(values[ok] * weights[ok]) / np.sum(weights[ok]))


def weighted_variance(values, weights):
    values = np.asarray(values, dtype=float)
    weights = np.asarray(weights, dtype=float)
    ok = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    if np.sum(ok) < 2:
        return np.nan
    x = values[ok]
    w = weights[ok]
    mean = np.sum(w * x) / np.sum(w)
    return float(np.sum(w * (x - mean) ** 2) / np.sum(w))


def smd_for_feature(frame, field, weight_col, cfg):
    surveys = cfg["surveys"]
    a = frame["survey"] == surveys[0]
    g = frame["survey"] == surveys[1]
    values = pd.to_numeric(frame[field], errors="coerce").to_numpy(dtype=float)
    if weight_col is None:
        weights = np.ones(len(frame), dtype=float)
    else:
        weights = pd.to_numeric(
            frame[weight_col], errors="coerce"
        ).to_numpy(dtype=float)

    ma = weighted_mean(values[a], weights[a])
    mg = weighted_mean(values[g], weights[g])
    va = weighted_variance(values[a], weights[a])
    vg = weighted_variance(values[g], weights[g])
    pooled = math.sqrt(0.5 * (va + vg)) if np.isfinite(va) and np.isfinite(vg) else np.nan
    smd = (mg - ma) / pooled if np.isfinite(pooled) and pooled > 0 else np.nan
    return {
        "feature": field,
        "APOGEE_mean": ma,
        "GALAH_mean": mg,
        "pooled_sd": pooled,
        "smd_GALAH_minus_APOGEE": smd,
        "absolute_smd": abs(smd) if np.isfinite(smd) else np.nan,
    }


def effective_sample_size(weights):
    w = np.asarray(weights, dtype=float)
    w = w[np.isfinite(w) & (w > 0)]
    if len(w) == 0:
        return 0.0
    denom = np.sum(w ** 2)
    if denom <= 0:
        return 0.0
    return float((np.sum(w) ** 2) / denom)


def fit_crossfitted_propensity(frame, cfg):
    features = cfg["feature_fields"]
    n_folds = int(cfg["n_folds"])
    y = (frame["survey"] == cfg["galah_label"]).astype(int).to_numpy()
    X = frame[features].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)

    if not np.all(np.isfinite(X)):
        raise RuntimeError("Non-finite balancing features found in retained common footprint")

    folds = np.array([
        source_hash_fold(source_id, n_folds)
        for source_id in frame["source_id"]
    ], dtype=int)

    propensity = np.full(len(frame), np.nan, dtype=float)
    model_rows = []
    fold_rows = []

    for fold in range(n_folds):
        test = folds == fold
        train = ~test
        if not np.any(test):
            raise RuntimeError(f"Fold {fold} has no held-out rows")
        train_classes = np.unique(y[train])
        if set(train_classes.tolist()) != {0, 1}:
            raise RuntimeError(f"Fold {fold} training data lacks both surveys")

        scaler = StandardScaler()
        X_train = scaler.fit_transform(X[train])
        X_test = scaler.transform(X[test])

        model = LogisticRegression(
            C=float(cfg["ridge_logistic_C"]),
            solver=cfg["logistic_solver"],
            max_iter=int(cfg["logistic_max_iter"]),
            fit_intercept=True,
            random_state=0,
        )
        model.fit(X_train, y[train])
        propensity[test] = model.predict_proba(X_test)[:, 1]

        for feature, mean, scale, coef in zip(
            features,
            scaler.mean_,
            scaler.scale_,
            model.coef_[0],
        ):
            model_rows.append({
                "fold": fold,
                "feature": feature,
                "training_mean": float(mean),
                "training_scale": float(scale),
                "standardized_logit_coefficient": float(coef),
            })
        model_rows.append({
            "fold": fold,
            "feature": "__INTERCEPT__",
            "training_mean": "",
            "training_scale": "",
            "standardized_logit_coefficient": float(model.intercept_[0]),
        })

        fold_rows.append({
            "fold": fold,
            "train_rows": int(train.sum()),
            "heldout_rows": int(test.sum()),
            "train_APOGEE": int(((frame["survey"] == cfg["apogee_label"]).to_numpy() & train).sum()),
            "train_GALAH": int(((frame["survey"] == cfg["galah_label"]).to_numpy() & train).sum()),
            "heldout_APOGEE": int(((frame["survey"] == cfg["apogee_label"]).to_numpy() & test).sum()),
            "heldout_GALAH": int(((frame["survey"] == cfg["galah_label"]).to_numpy() & test).sum()),
        })

    if not np.all(np.isfinite(propensity)):
        raise RuntimeError("Cross-fitted propensity contains non-finite predictions")
    return folds, propensity, model_rows, fold_rows


def apply_overlap_weights(frame, propensity, cfg):
    galah = frame["survey"] == cfg["galah_label"]
    raw = np.where(galah.to_numpy(), 1.0 - propensity, propensity)
    if np.any(~np.isfinite(raw)) or np.any(raw <= 0):
        raise RuntimeError("Raw overlap weights must be finite and positive")

    cap = float(np.quantile(raw, float(cfg["p99_cap_quantile"])))
    capped = np.minimum(raw, cap)

    final = capped.copy()
    scale = np.ones(len(frame), dtype=float)
    cell_rows = []

    cell_field = cfg["cell_field"]
    for cell, idx in frame.groupby(cell_field, sort=True).groups.items():
        idx = np.asarray(list(idx), dtype=int)
        survey = frame.loc[idx, "survey"].to_numpy()
        w = capped[idx]
        totals = {}
        for s in cfg["surveys"]:
            totals[s] = float(np.sum(w[survey == s]))
            if totals[s] <= 0:
                raise RuntimeError(
                    f"Cell {cell} has non-positive capped weight total for {s}"
                )
        target = 0.5 * sum(totals.values())
        factors = {s: target / totals[s] for s in cfg["surveys"]}
        for s in cfg["surveys"]:
            mask = survey == s
            scale[idx[mask]] = factors[s]
            final[idx[mask]] = w[mask] * factors[s]

        final_totals = {
            s: float(np.sum(final[idx][survey == s]))
            for s in cfg["surveys"]
        }
        cell_rows.append({
            "cell": cell,
            "raw_overlap_total_APOGEE": float(np.sum(raw[idx][survey == cfg["apogee_label"]])),
            "raw_overlap_total_GALAH": float(np.sum(raw[idx][survey == cfg["galah_label"]])),
            "capped_total_APOGEE": totals[cfg["apogee_label"]],
            "capped_total_GALAH": totals[cfg["galah_label"]],
            "target_equal_total": target,
            "APOGEE_equalization_factor": factors[cfg["apogee_label"]],
            "GALAH_equalization_factor": factors[cfg["galah_label"]],
            "final_total_APOGEE": final_totals[cfg["apogee_label"]],
            "final_total_GALAH": final_totals[cfg["galah_label"]],
            "absolute_final_total_difference": abs(
                final_totals[cfg["apogee_label"]]
                - final_totals[cfg["galah_label"]]
            ),
        })
    return raw, cap, capped, scale, final, cell_rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3c_config.json").read_text(encoding="utf-8")
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in [
        "validation", "tables", "balanced", "models",
        "manifest", "summaries", "reports"
    ]:
        (out / d).mkdir(parents=True, exist_ok=True)

    prepath = root / cfg["prerequisite_validation"]
    pre = json.loads(prepath.read_text(encoding="utf-8")) if prepath.exists() else {}
    prereq_ready = bool(
        pre.get("STAGE6D3C_BALANCING_READY", False)
        and pre.get("STAGE6D3B_COMMON_FOOTPRINT_READY", False)
        and pre.get("COMMON_FOOTPRINT_SOURCE_TABLE_READY", False)
    )

    source_path = resolve(root / cfg["common_footprint_source"])
    if not source_path:
        raise FileNotFoundError("D3B1 retained common-footprint source not found")
    frame = read_table(source_path).reset_index(drop=True)

    required = {
        "source_id", "survey", cfg["cell_field"], *cfg["feature_fields"]
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise RuntimeError(f"Missing D3C required columns: {missing}")

    forbidden_used = sorted(
        set(cfg["feature_fields"]).intersection(cfg["forbidden_feature_fields"])
    )
    no_forbidden_features = len(forbidden_used) == 0
    if not no_forbidden_features:
        raise RuntimeError(f"Forbidden balancing feature(s): {forbidden_used}")

    row_key_unique = not frame.duplicated(["source_id", "survey"]).any()
    survey_set_ready = set(frame["survey"].astype(str).unique()) == set(cfg["surveys"])
    survey_counts = {
        survey: int((frame["survey"] == survey).sum())
        for survey in cfg["surveys"]
    }
    minimum_rows_ready = all(
        count >= int(cfg["minimum_rows_per_survey"])
        for count in survey_counts.values()
    )

    folds, propensity, model_rows, fold_rows = fit_crossfitted_propensity(
        frame, cfg
    )
    frame["balance_fold"] = folds
    frame["propensity_GALAH_oof"] = propensity

    raw, cap, capped, scale, final_w, cell_rows = apply_overlap_weights(
        frame, propensity, cfg
    )
    frame["overlap_weight_raw"] = raw
    frame["overlap_weight_p99_capped"] = capped
    frame["cell_equalization_factor"] = scale
    frame["balance_weight_final"] = final_w

    propensity_min = float(np.min(propensity))
    propensity_max = float(np.max(propensity))
    propensity_gate_ready = bool(
        propensity_min >= float(cfg["propensity_lower_gate"])
        and propensity_max <= float(cfg["propensity_upper_gate"])
    )

    balance_rows = []
    stages = [
        ("unweighted", None),
        ("raw_overlap", "overlap_weight_raw"),
        ("p99_capped", "overlap_weight_p99_capped"),
        ("final_cell_equalized", "balance_weight_final"),
    ]
    for stage, weight_col in stages:
        for feature in cfg["feature_fields"]:
            row = smd_for_feature(frame, feature, weight_col, cfg)
            row["stage"] = stage
            balance_rows.append(row)
    balance_df = pd.DataFrame(balance_rows)
    write_df_csv(
        out / "tables/stage6d3c_balance_smd_ledger.csv",
        balance_df,
    )

    final_smd = balance_df[
        balance_df["stage"] == "final_cell_equalized"
    ]["absolute_smd"]
    max_abs_smd = float(final_smd.max()) if len(final_smd) else np.nan
    smd_gate_ready = bool(
        np.isfinite(max_abs_smd)
        and max_abs_smd <= float(cfg["maximum_absolute_smd_gate"])
    )

    ess_rows = []
    ess_ratios = {}
    for survey in cfg["surveys"]:
        mask = frame["survey"] == survey
        weights = frame.loc[mask, "balance_weight_final"].to_numpy(dtype=float)
        ess = effective_sample_size(weights)
        raw_n = int(mask.sum())
        ratio = ess / raw_n if raw_n > 0 else 0.0
        ess_ratios[survey] = ratio
        ess_rows.append({
            "survey": survey,
            "raw_rows": raw_n,
            "sum_final_weights": float(weights.sum()),
            "effective_sample_size": ess,
            "ess_raw_ratio": ratio,
            "minimum_required_ratio": cfg["minimum_ess_raw_ratio_gate"],
            "gate_passed": ratio >= float(cfg["minimum_ess_raw_ratio_gate"]),
        })
    write_csv(
        out / "tables/stage6d3c_ess_ledger.csv",
        [
            "survey", "raw_rows", "sum_final_weights",
            "effective_sample_size", "ess_raw_ratio",
            "minimum_required_ratio", "gate_passed"
        ],
        ess_rows,
    )
    ess_gate_ready = all(
        ratio >= float(cfg["minimum_ess_raw_ratio_gate"])
        for ratio in ess_ratios.values()
    )

    write_csv(
        out / "models/stage6d3c_crossfit_model_coefficients.csv",
        [
            "fold", "feature", "training_mean",
            "training_scale", "standardized_logit_coefficient"
        ],
        model_rows,
    )
    write_csv(
        out / "models/stage6d3c_fold_ledger.csv",
        [
            "fold", "train_rows", "heldout_rows",
            "train_APOGEE", "train_GALAH",
            "heldout_APOGEE", "heldout_GALAH"
        ],
        fold_rows,
    )
    write_csv(
        out / "tables/stage6d3c_cell_weight_equalization_ledger.csv",
        [
            "cell", "raw_overlap_total_APOGEE", "raw_overlap_total_GALAH",
            "capped_total_APOGEE", "capped_total_GALAH",
            "target_equal_total", "APOGEE_equalization_factor",
            "GALAH_equalization_factor", "final_total_APOGEE",
            "final_total_GALAH", "absolute_final_total_difference"
        ],
        cell_rows,
    )

    max_cell_total_diff = max(
        row["absolute_final_total_difference"] for row in cell_rows
    ) if cell_rows else np.nan
    cell_equalization_ready = bool(
        np.isfinite(max_cell_total_diff) and max_cell_total_diff <= 1e-8
    )

    # Diagnostic propensity ledger by survey.
    propensity_rows = []
    for survey in cfg["surveys"]:
        values = frame.loc[
            frame["survey"] == survey, "propensity_GALAH_oof"
        ].to_numpy(dtype=float)
        propensity_rows.append({
            "survey": survey,
            "rows": len(values),
            "min": float(np.min(values)),
            "q01": float(np.quantile(values, .01)),
            "q05": float(np.quantile(values, .05)),
            "median": float(np.quantile(values, .50)),
            "q95": float(np.quantile(values, .95)),
            "q99": float(np.quantile(values, .99)),
            "max": float(np.max(values)),
            "fraction_below_0p05": float(np.mean(values < float(cfg["propensity_lower_gate"]))),
            "fraction_above_0p95": float(np.mean(values > float(cfg["propensity_upper_gate"]))),
        })
    write_csv(
        out / "tables/stage6d3c_propensity_ledger.csv",
        [
            "survey", "rows", "min", "q01", "q05", "median",
            "q95", "q99", "max",
            "fraction_below_0p05", "fraction_above_0p95"
        ],
        propensity_rows,
    )

    balanced_path = (
        out / "balanced/stage6d3c_common_footprint_balanced_sources.parquet"
    )
    try:
        frame.to_parquet(balanced_path, index=False)
    except Exception:
        balanced_path = balanced_path.with_suffix(".csv")
        frame.to_csv(balanced_path, index=False)

    balance_ready = bool(
        prereq_ready
        and row_key_unique
        and survey_set_ready
        and minimum_rows_ready
        and no_forbidden_features
        and propensity_gate_ready
        and smd_gate_ready
        and ess_gate_ready
        and cell_equalization_ready
    )

    protocol = {
        "features": cfg["feature_fields"],
        "folding": {
            "n_folds": cfg["n_folds"],
            "assignment": "sha256(source_id) mod n_folds",
            "same_source_same_fold": True,
        },
        "propensity_model": {
            "type": "ridge logistic regression",
            "standardization": "training-fold StandardScaler only",
            "C": cfg["ridge_logistic_C"],
            "solver": cfg["logistic_solver"],
        },
        "overlap_weights": cfg["overlap_weight_definition"],
        "p99_cap": {
            "quantile": cfg["p99_cap_quantile"],
            "scope": cfg["p99_cap_scope"],
            "value": cap,
        },
        "cell_equalization": cfg["cell_equalization"],
        "gates": {
            "propensity": [
                cfg["propensity_lower_gate"],
                cfg["propensity_upper_gate"],
            ],
            "maximum_absolute_smd": cfg["maximum_absolute_smd_gate"],
            "minimum_ess_raw_ratio": cfg["minimum_ess_raw_ratio_gate"],
        },
        "forbidden_features_used": forbidden_used,
    }
    write_json(
        out / "tables/stage6d3c_protocol_ledger.json",
        protocol,
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": now(),
        "common_footprint_source": rel(source_path, root),
        "input_rows": len(frame),
        "input_rows_by_survey": survey_counts,
        "retained_cell_count": int(frame[cfg["cell_field"]].nunique()),
        "n_folds": cfg["n_folds"],
        "p99_raw_overlap_weight_cap": cap,
        "propensity_min": propensity_min,
        "propensity_max": propensity_max,
        "maximum_absolute_final_smd": max_abs_smd,
        "ess_raw_ratio_by_survey": ess_ratios,
        "maximum_cell_final_weight_total_difference": max_cell_total_diff,
        "balanced_source_table": rel(balanced_path, root),
        "prior_stage_outputs_modified": False,
        "STAGE6D3B1_PREREQUISITE_READY": prereq_ready,
        "SOURCE_SURVEY_ROW_KEY_UNIQUE": row_key_unique,
        "EXACT_SURVEY_SET_READY": survey_set_ready,
        "MINIMUM_ROWS_PER_SURVEY_READY": minimum_rows_ready,
        "SOURCE_HASH_5FOLD_ASSIGNMENT_READY": True,
        "SAME_SOURCE_SAME_FOLD_READY": True,
        "CROSSFITTED_RIDGE_LOGISTIC_READY": True,
        "TRAINING_FOLD_ONLY_STANDARDIZATION_READY": True,
        "OVERLAP_WEIGHTS_READY": True,
        "P99_WEIGHT_CAP_APPLIED": True,
        "EQUAL_SURVEY_WEIGHT_TOTAL_PER_CELL_READY": cell_equalization_ready,
        "PROPENSITY_0P05_0P95_GATE_READY": propensity_gate_ready,
        "MAX_ABS_SMD_LE_0P10_READY": smd_gate_ready,
        "ESS_RAW_GE_0P35_READY": ess_gate_ready,
        "BALANCING_FEATURES_OUTCOME_BLIND": no_forbidden_features,
        "ABUNDANCE_R_ABSZ_RESIDUAL_OUTCOME_FEATURES_FORBIDDEN": True,
        "STAGE6D3C_BALANCE_GATES_READY": balance_ready,
        "STAGE6D3C_BALANCED_SOURCE_READY": balance_ready,
        "STAGE6D4_SCIENCE_MODELS_READY": balance_ready,
    }
    write_json(
        out / "validation/stage6d3c_validation.json",
        validation,
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": now(),
        "balance": {
            "propensity_range": [propensity_min, propensity_max],
            "maximum_absolute_final_smd": max_abs_smd,
            "ess_raw_ratio_by_survey": ess_ratios,
            "cells": int(frame[cfg["cell_field"]].nunique()),
            "rows": len(frame),
        },
        "scientific_disposition": (
            "Frozen cross-fitted support balancing passes all D3C gates. "
            "Stage-6D4 FULL_SUPPORT_FROZEN, COMMON_FOOTPRINT_POOLED, BALANCED, "
            "and INTERACTION science models are authorized."
            if balance_ready else
            "Balancing completed but at least one frozen gate failed. "
            "Do not begin Stage-6D4 science models."
        ),
    }
    write_json(
        out / "summaries/stage6d3c_summary.json",
        summary,
    )

    report = [
        "# Stage-6D3C cross-fitted overlap-weight balancing",
        "",
        f"- Rows: `{len(frame)}`",
        f"- Cells: `{frame[cfg['cell_field']].nunique()}`",
        f"- Propensity range: `[{propensity_min:.6f}, {propensity_max:.6f}]`",
        f"- p99 raw overlap-weight cap: `{cap:.8f}`",
        f"- Maximum |final SMD|: `{max_abs_smd:.6f}`",
        f"- APOGEE ESS/raw: `{ess_ratios[cfg['apogee_label']]:.6f}`",
        f"- GALAH ESS/raw: `{ess_ratios[cfg['galah_label']]:.6f}`",
        f"- Stage-6D4 ready: `{balance_ready}`",
        "",
        "Propensity uses only Teff, logg, within-survey S/N percentile, Gaia G, "
        "and BP-RP. No abundance, R, |Z|, residual, outcome, or latent-component "
        "quantity enters the balancing model.",
        "",
    ]
    (out / "reports/stage6d3c_report.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    manifest_rows = []
    for path in sorted(out.rglob("*")):
        if path.is_file() and "manifest" not in path.parts:
            manifest_rows.append({
                "path": rel(path, root),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            })
    write_csv(
        out / "manifest/stage6d3c_output_manifest_sha256.csv",
        ["path", "size_bytes", "sha256"],
        manifest_rows,
    )

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
