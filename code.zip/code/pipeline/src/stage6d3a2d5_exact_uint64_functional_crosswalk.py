from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def normalise(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def read_columns(path: Path) -> tuple[list[str], int]:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        import pyarrow.parquet as pq
        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    if suffix == ".feather":
        import pyarrow.feather as feather
        table = feather.read_table(path)
        return list(table.column_names), int(table.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def read_table(
    path: Path,
    columns: list[str] | None = None,
    exact_string_columns: list[str] | None = None,
) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path, columns=columns)
    if suffix == ".feather":
        return pd.read_feather(path, columns=columns)
    dtype = None
    if exact_string_columns:
        dtype = {column: "string" for column in exact_string_columns}
    return pd.read_csv(path, usecols=columns, dtype=dtype)


def read_any_table(
    path: Path,
    exact_string_columns: list[str] | None = None,
) -> pd.DataFrame:
    return read_table(
        path,
        None,
        exact_string_columns=exact_string_columns,
    )

def resolve_with_csv_fallback(path: Path) -> Path | None:
    if path.exists():
        return path
    csv_path = path.with_suffix(".csv")
    if csv_path.exists():
        return csv_path
    feather_path = path.with_suffix(".feather")
    if feather_path.exists():
        return feather_path
    return None


def find_alias(columns: list[str], aliases: list[str]) -> str | None:
    lookup = {normalise(column): column for column in columns}
    for alias in aliases:
        token = normalise(alias)
        if token in lookup:
            return lookup[token]
    return None


def all_alias_matches(columns: list[str], aliases: list[str]) -> list[str]:
    lookup = {normalise(column): column for column in columns}
    matches = []
    for alias in aliases:
        token = normalise(alias)
        if token in lookup and lookup[token] not in matches:
            matches.append(lookup[token])
    return matches


def path_excluded(path: Path, root: Path, cfg: dict[str, Any]) -> bool:
    text = safe_rel(path, root).lower().replace("\\", "/")
    return any(token.lower() in text for token in cfg["excluded_path_tokens"])


def path_is_galah(path: Path, cfg: dict[str, Any]) -> bool:
    token = normalise(str(path))
    return any(normalise(value) in token for value in cfg["galah_survey_values"])


def survey_column_is_galah(
    path: Path,
    columns: list[str],
    cfg: dict[str, Any],
) -> bool:
    survey_column = find_alias(columns, cfg["survey_aliases"])
    if not survey_column:
        return path_is_galah(path, cfg)
    try:
        frame = read_table(path, [survey_column])
        values = frame[survey_column].dropna().astype(str)
        if values.empty:
            return path_is_galah(path, cfg)
        tokens = values.map(normalise)
        return bool(
            tokens.str.contains("galah", regex=False).any()
        )
    except Exception:
        return path_is_galah(path, cfg)


def detect_snr_contract(
    columns: list[str],
    cfg: dict[str, Any],
) -> tuple[str | None, list[str], dict[str, str]]:
    scalar = find_alias(columns, cfg["galah_scalar_snr_aliases"])
    if scalar:
        return "scalar_native_snr", [scalar], {}

    channels = {}
    for role, aliases in cfg["galah_channel_snr_alias_groups"].items():
        column = find_alias(columns, aliases)
        if column:
            channels[role] = column
    if len(channels) >= int(cfg["minimum_galah_finite_channels"]):
        return "galah_channel_median", list(channels.values()), channels
    return None, [], channels


UINT64_MAX = 18446744073709551615
FLOAT_EXACT_INTEGER_MAX = 9007199254740991


def clean_integer_id(series: pd.Series) -> pd.Series:
    """Parse integer identifiers without routing large IDs through float64.

    CSV identifier columns are loaded as strings. Native integer dtypes are
    accepted directly. Float identifiers above 2^53-1 are rejected because
    their integer identity is already non-recoverable.
    """
    output = pd.Series(pd.NA, index=series.index, dtype="UInt64")

    if pd.api.types.is_integer_dtype(series.dtype):
        numeric = series.astype("Int64")
        valid = numeric.notna() & (numeric >= 0)
        if valid.any():
            output.loc[valid] = pd.array(
                numeric.loc[valid].astype("string"), dtype="UInt64"
            )
        return output

    if pd.api.types.is_float_dtype(series.dtype):
        numeric = pd.to_numeric(series, errors="coerce")
        valid = (
            numeric.notna()
            & np.isfinite(numeric)
            & (numeric >= 0)
            & (numeric <= FLOAT_EXACT_INTEGER_MAX)
            & (numeric == np.floor(numeric))
        )
        if valid.any():
            output.loc[valid] = pd.array(
                numeric.loc[valid].astype("uint64").astype("string"),
                dtype="UInt64",
            )
        return output

    text = series.astype("string").str.strip()
    text = text.str.replace(r"^\\+", "", regex=True)
    valid = text.str.fullmatch(r"[0-9]+", na=False)
    if valid.any():
        values = text.loc[valid].str.lstrip("0")
        values = values.mask(values == "", "0")
        # Length/lexical bounds avoid overflow before UInt64 construction.
        within_length = values.str.len() <= len(str(UINT64_MAX))
        bounded = values[within_length]
        if not bounded.empty:
            same_length = bounded.str.len() == len(str(UINT64_MAX))
            within_max = (~same_length) | (bounded <= str(UINT64_MAX))
            bounded = bounded[within_max]
            if not bounded.empty:
                output.loc[bounded.index] = pd.array(
                    bounded, dtype="UInt64"
                )
    return output

def clean_string_id(series: pd.Series) -> pd.Series:
    output = series.astype("string").str.strip()
    output = output.replace({"": pd.NA, "nan": pd.NA, "None": pd.NA})
    return output


def build_snr_series(
    frame: pd.DataFrame,
    contract: str,
    snr_columns: list[str],
    cfg: dict[str, Any],
) -> tuple[pd.Series, pd.Series]:
    if contract == "scalar_native_snr":
        snr = pd.to_numeric(frame[snr_columns[0]], errors="coerce")
        finite_channels = snr.notna().astype(int)
    else:
        channels = pd.DataFrame({
            column: pd.to_numeric(frame[column], errors="coerce")
            for column in snr_columns
        })
        finite_channels = channels.notna().sum(axis=1)
        snr = channels.median(axis=1, skipna=True)
        snr.loc[
            finite_channels < int(cfg["minimum_galah_finite_channels"])
        ] = np.nan

    minimum = float(cfg["snr_minimum_exclusive"])
    maximum = float(cfg["snr_maximum"])
    snr = pd.to_numeric(snr, errors="coerce")
    snr.loc[
        ~np.isfinite(snr)
        | (snr <= minimum)
        | (snr > maximum)
    ] = np.nan
    return snr, finite_channels


def aggregate_snr_by_source(
    source_ids: pd.Series,
    snr: pd.Series,
    contract: str,
    source_kind: str,
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    work = pd.DataFrame({
        "source_id": source_ids,
        "snr_native": snr,
    })
    work = work[work["source_id"].notna()].copy()
    work["source_id"] = work["source_id"].astype("uint64")
    rows = []
    audit = []
    for source_id, group in work.groupby("source_id", sort=False):
        values = group["snr_native"].dropna().to_numpy(dtype=float)
        rows.append({
            "source_id": source_id,
            "survey": "GALAH_CORRECTED",
            "snr_native": (
                float(np.median(values)) if len(values) else np.nan
            ),
            "snr_measurement_count": int(len(values)),
            "snr_input_row_count": int(len(group)),
            "snr_contract": contract,
            "snr_id_route": source_kind,
        })
        if len(group) > 1:
            audit.append({
                "source_id": int(source_id),
                "input_rows": int(len(group)),
                "finite_snr_rows": int(len(values)),
                "minimum_snr": (
                    float(np.min(values)) if len(values) else ""
                ),
                "median_snr": (
                    float(np.median(values)) if len(values) else ""
                ),
                "maximum_snr": (
                    float(np.max(values)) if len(values) else ""
                ),
                "aggregation": "source_level_median_native_snr",
                "id_route": source_kind,
            })
    return pd.DataFrame(rows), audit


def complete_mask(frame: pd.DataFrame) -> pd.Series:
    required = [
        "R", "abs_Z", "teff", "logg",
        "snr_native", "g_mag", "bp_rp"
    ]
    mask = pd.Series(True, index=frame.index)
    for field in required:
        if field not in frame.columns:
            return pd.Series(False, index=frame.index)
        mask &= frame[field].notna()
    sky = (
        (
            frame.get("l", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("b", pd.Series(pd.NA, index=frame.index)).notna()
        )
        |
        (
            frame.get("ra", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("dec", pd.Series(pd.NA, index=frame.index)).notna()
        )
    )
    return mask & sky


def percentile_transform(series: pd.Series) -> pd.Series:
    output = pd.Series(np.nan, index=series.index, dtype=float)
    valid = series.notna()
    if valid.any():
        output.loc[valid] = series.loc[valid].rank(
            method="average", pct=True
        )
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2d5_config.json").read_text(
            encoding="utf-8"
        )
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables",
        "assembled", "reports", "diagnostics"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    d2_path = root / cfg["prerequisite_d2_validation"]
    d3_path = root / cfg["prerequisite_d3_validation"]
    d4_path = root / cfg["prerequisite_d4_validation"]
    d2 = (
        json.loads(d2_path.read_text(encoding="utf-8"))
        if d2_path.exists() else {}
    )
    d3 = (
        json.loads(d3_path.read_text(encoding="utf-8"))
        if d3_path.exists() else {}
    )
    d4 = (
        json.loads(d4_path.read_text(encoding="utf-8"))
        if d4_path.exists() else {}
    )
    d4_diagnostic_ready = bool(
        d4.get("CANONICAL_ANCHOR_IDENTITY_READY", False)
        and d4.get("STAGE6D3A2D3_APOGEE_PREREQUISITE_READY", False)
        and not d4.get("FINAL_ROW_CONSERVATION_READY", True)
    )
    d2_ready = bool(
        d2.get("STAGE6D3A2D2_LINEAGE_READY", False)
        and d2.get("SURVEY_ORIGIN_ROW_IDENTITY_READY", False)
        and d2.get("SKY_COORDINATE_SUPPORT_READY", False)
        and d2.get("GAIA_PHOTOMETRY_SUPPORT_READY", False)
    )
    d3_apogee_ready = bool(
        d3.get("APOGEE_NATIVE_SNR_LINEAGE_READY", False)
        and d3.get("ANCHOR_SOURCE_SURVEY_IDENTITY_READY", False)
    )

    anchor_path = resolve_with_csv_fallback(root / cfg["canonical_anchor"])
    prior_path = resolve_with_csv_fallback(root / cfg["prior_d3_assembled"])
    anchor = (
        read_any_table(anchor_path, exact_string_columns=["source_id"])
        if anchor_path else pd.DataFrame()
    )
    prior = (
        read_any_table(prior_path, exact_string_columns=["source_id"])
        if prior_path else pd.DataFrame()
    )
    if "source_id" in anchor.columns:
        anchor["source_id"] = clean_integer_id(anchor["source_id"])
        if anchor["source_id"].notna().all():
            anchor["source_id"] = anchor["source_id"].astype("uint64")
    if "source_id" in prior.columns:
        prior["source_id"] = clean_integer_id(prior["source_id"])
        prior = prior[prior["source_id"].notna()].copy()
        prior["source_id"] = prior["source_id"].astype("uint64")

    anchor_identity_ready = bool(
        not anchor.empty
        and {"source_id", "survey"}.issubset(anchor.columns)
        and anchor["source_id"].notna().all()
        and anchor["survey"].notna().all()
        and not anchor.duplicated(["source_id", "survey"]).any()
        and set(anchor["survey"].dropna().astype(str))
        >= {"APOGEE_NATIVE", "GALAH_CORRECTED"}
    )
    prior_row_conservation_ready = bool(
        anchor_identity_ready
        and len(prior) == len(anchor)
        and {"source_id", "survey"}.issubset(prior.columns)
        and not prior.duplicated(["source_id", "survey"]).any()
        and set(
            zip(
                prior["source_id"].astype("uint64").tolist(),
                prior["survey"].astype(str).tolist(),
            )
        )
        == set(
            zip(
                anchor["source_id"].astype("uint64").tolist(),
                anchor["survey"].astype(str).tolist(),
            )
        )
    )

    row_conservation_rows = [{
        "canonical_anchor_rows": len(anchor),
        "prior_d3_rows": len(prior),
        "row_difference": len(prior) - len(anchor),
        "canonical_unique_keys": (
            int(anchor[["source_id", "survey"]].drop_duplicates().shape[0])
            if {"source_id", "survey"}.issubset(anchor.columns) else 0
        ),
        "prior_unique_keys": (
            int(prior[["source_id", "survey"]].drop_duplicates().shape[0])
            if {"source_id", "survey"}.issubset(prior.columns) else 0
        ),
        "prior_row_conservation_ready": str(
            prior_row_conservation_ready
        ).lower(),
        "disposition": (
            "prior D3 table may be reused"
            if prior_row_conservation_ready
            else "rebuild final table from canonical D2 anchor"
        ),
    }]
    write_csv(
        out / "tables/stage6d3a2d5_prior_row_conservation_audit.csv",
        [
            "canonical_anchor_rows", "prior_d3_rows",
            "row_difference", "canonical_unique_keys",
            "prior_unique_keys", "prior_row_conservation_ready",
            "disposition"
        ],
        row_conservation_rows,
    )

    galah_anchor_ids = set(
        anchor.loc[
            anchor["survey"] == "GALAH_CORRECTED", "source_id"
        ].dropna().astype("uint64")
    ) if anchor_identity_ready else set()

    schema_inventory = []
    snr_candidates = []
    crosswalk_candidates = []
    suffixes = set(cfg["tabular_suffixes"])

    for rel_root in cfg["scan_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if (
                not path.is_file()
                or path.suffix.lower() not in suffixes
                or path_excluded(path, root, cfg)
            ):
                continue
            try:
                columns, row_count = read_columns(path)
            except Exception as exc:
                schema_inventory.append({
                    "path": safe_rel(path, root),
                    "row_count": "",
                    "columns": "",
                    "gaia_id_columns": "",
                    "local_id_columns": "",
                    "snr_contract": "",
                    "snr_columns": "",
                    "path_is_galah": str(path_is_galah(path, cfg)).lower(),
                    "read_error": f"{type(exc).__name__}: {exc}",
                })
                continue

            gaia_columns = all_alias_matches(
                columns, cfg["all_gaia_id_aliases"]
            )
            local_columns = all_alias_matches(
                columns, cfg["local_id_aliases"]
            )
            contract, snr_columns, channel_mapping = detect_snr_contract(
                columns, cfg
            )
            is_galah = path_is_galah(path, cfg)
            schema_inventory.append({
                "path": safe_rel(path, root),
                "row_count": row_count,
                "columns": "|".join(columns),
                "gaia_id_columns": "|".join(gaia_columns),
                "local_id_columns": "|".join(local_columns),
                "snr_contract": contract or "",
                "snr_columns": "|".join(snr_columns),
                "path_is_galah": str(is_galah).lower(),
                "read_error": "",
            })

            if contract and (is_galah or local_columns):
                snr_candidates.append({
                    "path": path,
                    "row_count": row_count,
                    "gaia_id_columns": gaia_columns,
                    "local_id_columns": local_columns,
                    "contract": contract,
                    "snr_columns": snr_columns,
                    "channel_mapping": channel_mapping,
                })

            dr3_columns = all_alias_matches(
                columns, cfg["gaia_dr3_id_aliases"]
            )
            if dr3_columns and local_columns:
                crosswalk_candidates.append({
                    "path": path,
                    "row_count": row_count,
                    "dr3_columns": dr3_columns,
                    "local_id_columns": local_columns,
                })

    write_csv(
        out / "tables/stage6d3a2d5_schema_inventory.csv",
        [
            "path", "row_count", "columns",
            "gaia_id_columns", "local_id_columns",
            "snr_contract", "snr_columns",
            "path_is_galah", "read_error"
        ],
        schema_inventory,
    )

    snr_candidates = sorted(
        snr_candidates,
        key=lambda item: (
            0 if path_is_galah(item["path"], cfg) else 1,
            -max(item["row_count"], 0),
            str(item["path"]),
        ),
    )[: int(cfg["maximum_schema_candidates_to_load"])]

    crosswalk_candidates = sorted(
        crosswalk_candidates,
        key=lambda item: (
            -max(item["row_count"], 0),
            str(item["path"]),
        ),
    )[: int(cfg["maximum_crosswalk_candidates_to_load"])]

    direct_rows = []
    route_products = []
    duplicate_audit = []
    crosswalk_audit = []

    for candidate in snr_candidates:
        required = (
            candidate["gaia_id_columns"]
            + candidate["local_id_columns"]
            + candidate["snr_columns"]
        )
        required = sorted(set(required))
        try:
            frame = read_table(
                candidate["path"],
                required,
                exact_string_columns=(
                    candidate["gaia_id_columns"]
                    + candidate["local_id_columns"]
                ),
            )
        except Exception as exc:
            direct_rows.append({
                "candidate_path": safe_rel(candidate["path"], root),
                "contract": candidate["contract"],
                "id_column": "",
                "id_route": "",
                "finite_snr_rows": 0,
                "anchor_overlap_rows": 0,
                "anchor_overlap_fraction": 0.0,
                "functional_crosswalk_ready": "",
                "crosswalk_path": "",
                "selection_score": -1,
                "load_error": f"{type(exc).__name__}: {exc}",
            })
            continue

        snr, finite_channels = build_snr_series(
            frame, candidate["contract"],
            candidate["snr_columns"], cfg
        )

        # Direct Gaia-ID routes.
        for id_column in candidate["gaia_id_columns"]:
            ids = clean_integer_id(frame[id_column])
            product, audit = aggregate_snr_by_source(
                ids, snr, candidate["contract"],
                f"direct:{id_column}"
            )
            duplicate_audit.extend(audit)
            finite_ids = set(
                product.loc[
                    product["snr_native"].notna(), "source_id"
                ].astype("uint64")
            )
            overlap = galah_anchor_ids.intersection(finite_ids)
            overlap_fraction = (
                len(overlap) / max(len(galah_anchor_ids), 1)
            )
            score = (
                1_000_000_000 * len(overlap)
                + 1_000_000 * len(finite_ids)
                + 1000
            )
            row = {
                "candidate_path": safe_rel(candidate["path"], root),
                "contract": candidate["contract"],
                "id_column": id_column,
                "id_route": "direct_gaia_id",
                "finite_snr_rows": int(
                    product["snr_native"].notna().sum()
                ),
                "anchor_overlap_rows": len(overlap),
                "anchor_overlap_fraction": overlap_fraction,
                "functional_crosswalk_ready": "",
                "crosswalk_path": "",
                "selection_score": score,
                "load_error": "",
            }
            direct_rows.append(row)
            route_products.append({
                "row": row,
                "product": product,
                "candidate": candidate,
                "crosswalk": None,
            })

        # Local-ID routes through explicit crosswalks.
        for local_column in candidate["local_id_columns"]:
            local_values = clean_string_id(frame[local_column])
            local_frame = pd.DataFrame({
                "local_id": local_values,
                "snr_native": snr,
            })
            local_frame = local_frame[
                local_frame["local_id"].notna()
            ].copy()

            for crosswalk in crosswalk_candidates:
                shared_local = [
                    column for column in crosswalk["local_id_columns"]
                    if normalise(column) == normalise(local_column)
                ]
                if not shared_local:
                    continue
                cross_local = shared_local[0]
                for dr3_column in crosswalk["dr3_columns"]:
                    try:
                        cross = read_table(
                            crosswalk["path"],
                            [cross_local, dr3_column],
                            exact_string_columns=[cross_local, dr3_column],
                        )
                    except Exception:
                        continue
                    cross = pd.DataFrame({
                        "local_id": clean_string_id(cross[cross_local]),
                        "source_id": clean_integer_id(cross[dr3_column]),
                    })
                    cross = cross[
                        cross["local_id"].notna()
                        & cross["source_id"].notna()
                    ].copy()
                    local_conflicts = (
                        cross.groupby("local_id")["source_id"].nunique()
                        > 1
                    )
                    source_conflicts = (
                        cross.groupby("source_id")["local_id"].nunique()
                        > 1
                    )
                    functional_mapping = bool(
                        not local_conflicts.any()
                    )
                    crosswalk_audit.append({
                        "candidate_path": safe_rel(candidate["path"], root),
                        "candidate_local_id_column": local_column,
                        "crosswalk_path": safe_rel(crosswalk["path"], root),
                        "crosswalk_local_id_column": cross_local,
                        "crosswalk_dr3_id_column": dr3_column,
                        "crosswalk_rows": len(cross),
                        "conflicting_local_ids": int(local_conflicts.sum()),
                        "multiple_local_ids_per_source": int(source_conflicts.sum()),
                        "functional_mapping_ready": str(functional_mapping).lower(),
                    })
                    if not functional_mapping:
                        continue
                    cross = cross.drop_duplicates(
                        ["local_id", "source_id"]
                    )
                    joined = local_frame.merge(
                        cross,
                        on="local_id",
                        how="inner",
                        validate="many_to_one",
                    )
                    product, audit = aggregate_snr_by_source(
                        joined["source_id"],
                        joined["snr_native"],
                        candidate["contract"],
                        f"crosswalk:{local_column}->{dr3_column}"
                    )
                    duplicate_audit.extend(audit)
                    finite_ids = set(
                        product.loc[
                            product["snr_native"].notna(), "source_id"
                        ].astype("uint64")
                    )
                    overlap = galah_anchor_ids.intersection(finite_ids)
                    overlap_fraction = (
                        len(overlap) / max(len(galah_anchor_ids), 1)
                    )
                    score = (
                        1_000_000_000 * len(overlap)
                        + 1_000_000 * len(finite_ids)
                        + 500
                    )
                    row = {
                        "candidate_path": safe_rel(candidate["path"], root),
                        "contract": candidate["contract"],
                        "id_column": local_column,
                        "id_route": "functional_local_to_gaia_dr3_crosswalk",
                        "finite_snr_rows": int(
                            product["snr_native"].notna().sum()
                        ),
                        "anchor_overlap_rows": len(overlap),
                        "anchor_overlap_fraction": overlap_fraction,
                        "functional_crosswalk_ready": "true",
                        "crosswalk_path": safe_rel(
                            crosswalk["path"], root
                        ),
                        "selection_score": score,
                        "load_error": "",
                    }
                    direct_rows.append(row)
                    route_products.append({
                        "row": row,
                        "product": product,
                        "candidate": candidate,
                        "crosswalk": crosswalk,
                    })

    write_csv(
        out / "tables/stage6d3a2d5_galah_route_audit.csv",
        [
            "candidate_path", "contract", "id_column",
            "id_route", "finite_snr_rows",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "functional_crosswalk_ready", "crosswalk_path",
            "selection_score", "load_error"
        ],
        sorted(
            direct_rows,
            key=lambda row: (
                -float(row["selection_score"]),
                row["candidate_path"],
                row["id_column"],
            ),
        ),
    )
    write_csv(
        out / "tables/stage6d3a2d5_crosswalk_identity_audit.csv",
        [
            "candidate_path", "candidate_local_id_column",
            "crosswalk_path", "crosswalk_local_id_column",
            "crosswalk_dr3_id_column", "crosswalk_rows",
            "conflicting_local_ids", "multiple_local_ids_per_source",
            "functional_mapping_ready"
        ],
        crosswalk_audit,
    )
    write_csv(
        out / "tables/stage6d3a2d5_snr_duplicate_aggregation.csv",
        [
            "source_id", "input_rows", "finite_snr_rows",
            "minimum_snr", "median_snr", "maximum_snr",
            "aggregation", "id_route"
        ],
        duplicate_audit,
    )

    eligible = [
        item for item in route_products
        if (
            item["row"]["anchor_overlap_rows"]
            >= int(cfg["minimum_direct_or_crosswalk_overlap_rows"])
            and item["row"]["anchor_overlap_fraction"]
            >= float(cfg["minimum_overlap_fraction"])
        )
    ]
    eligible.sort(
        key=lambda item: (
            -item["row"]["selection_score"],
            item["row"]["candidate_path"],
            item["row"]["id_column"],
        )
    )
    selected = None
    selection_error = ""
    if not eligible:
        selection_error = (
            "no exact direct or functional-crosswalk GALAH S/N route "
            "meets the finite anchor-overlap gate"
        )
    elif (
        len(eligible) > 1
        and eligible[0]["row"]["selection_score"]
        == eligible[1]["row"]["selection_score"]
    ):
        selection_error = "top GALAH S/N route is tied"
    else:
        selected = eligible[0]

    selected_rows = []
    if selected:
        row = selected["row"]
        selected_rows.append({
            "candidate_path": row["candidate_path"],
            "contract": row["contract"],
            "id_column": row["id_column"],
            "id_route": row["id_route"],
            "crosswalk_path": row["crosswalk_path"],
            "anchor_overlap_rows": row["anchor_overlap_rows"],
            "anchor_overlap_fraction": row["anchor_overlap_fraction"],
            "selection_score": row["selection_score"],
            "selection_reason": (
                "unique maximum finite GALAH-anchor overlap; direct Gaia-ID "
                "route receives only a deterministic lineage tie-break bonus"
            ),
        })
    write_csv(
        out / "tables/stage6d3a2d5_selected_galah_snr_contract.csv",
        [
            "candidate_path", "contract", "id_column",
            "id_route", "crosswalk_path",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "selection_score", "selection_reason"
        ],
        selected_rows,
    )

    # Rebuild from the canonical D2 anchor, never from a row-expanded prior table.
    final = anchor.copy()
    final["_anchor_row_id"] = np.arange(len(final), dtype=np.int64)
    for column in [
        "snr_native", "snr_measurement_count",
        "snr_input_row_count", "snr_contract",
        "snr_id_route", "snr_log1p_native",
        "snr_within_survey_percentile", "snr_support_half"
    ]:
        if column in final.columns:
            final.drop(columns=[column], inplace=True)

    apogee_product = pd.DataFrame()
    if d3_apogee_ready and not prior.empty and {
        "source_id", "survey", "snr_native"
    }.issubset(prior.columns):
        apogee = prior[
            prior["survey"] == "APOGEE_NATIVE"
        ].copy()
        apogee["source_id"] = clean_integer_id(apogee["source_id"])
        apogee = apogee[apogee["source_id"].notna()].copy()
        apogee["source_id"] = apogee["source_id"].astype("uint64")
        apogee["snr_native"] = pd.to_numeric(
            apogee["snr_native"], errors="coerce"
        )
        rows = []
        for source_id, group in apogee.groupby("source_id", sort=False):
            values = group["snr_native"].dropna().to_numpy(dtype=float)
            rows.append({
                "source_id": source_id,
                "survey": "APOGEE_NATIVE",
                "snr_native": (
                    float(np.median(values)) if len(values) else np.nan
                ),
                "snr_measurement_count": int(len(values)),
                "snr_input_row_count": int(len(group)),
                "snr_contract": "recovered_prior_d3_apogee_native_snr",
                "snr_id_route": "canonical_anchor_key_recovery",
            })
        apogee_product = pd.DataFrame(rows)

    products = []
    if not apogee_product.empty:
        products.append(apogee_product)
    if selected:
        products.append(selected["product"])

    if products:
        snr_product = pd.concat(products, ignore_index=True)
        snr_product["source_id"] = clean_integer_id(
            snr_product["source_id"]
        )
        snr_product = snr_product[
            snr_product["source_id"].notna()
        ].copy()
        snr_product["source_id"] = snr_product["source_id"].astype("uint64")
        final["source_id"] = final["source_id"].astype("uint64")
        if snr_product.duplicated(["source_id", "survey"]).any():
            raise RuntimeError(
                "selected S/N products are not unique in (source_id, survey)"
            )
        final = final.merge(
            snr_product,
            on=["source_id", "survey"],
            how="left",
            validate="one_to_one",
        )
    else:
        final["snr_native"] = np.nan

    if "_anchor_row_id" in final.columns:
        final = final.sort_values("_anchor_row_id", kind="stable").reset_index(drop=True)
    final_row_conservation_ready = bool(
        len(final) == len(anchor)
        and final["_anchor_row_id"].is_unique
        and final["_anchor_row_id"].tolist() == list(range(len(anchor)))
        and not final.duplicated(["source_id", "survey"]).any()
        and final["source_id"].astype("uint64").tolist()
            == anchor["source_id"].astype("uint64").tolist()
        and final["survey"].astype(str).tolist()
            == anchor["survey"].astype(str).tolist()
    )

    if "snr_native" not in final.columns:
        final["snr_native"] = np.nan
    final["snr_log1p_native"] = np.log1p(
        pd.to_numeric(
            final["snr_native"], errors="coerce"
        ).clip(lower=0)
    )
    final["snr_within_survey_percentile"] = np.nan
    final["snr_support_half"] = pd.Series(
        pd.NA, index=final.index, dtype="string"
    )
    medians = {}
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        mask = final["survey"] == survey
        series = pd.to_numeric(
            final.loc[mask, "snr_native"], errors="coerce"
        )
        final.loc[
            mask, "snr_within_survey_percentile"
        ] = percentile_transform(series)
        median = float(series.median()) if series.notna().any() else np.nan
        medians[survey] = median
        if np.isfinite(median):
            final.loc[
                mask & final["snr_native"].notna()
                & (final["snr_native"] <= median),
                "snr_support_half"
            ] = "LOW_NATIVE_SNR_HALF"
            final.loc[
                mask & final["snr_native"].notna()
                & (final["snr_native"] > median),
                "snr_support_half"
            ] = "HIGH_NATIVE_SNR_HALF"

    support = complete_mask(final)
    complete_counts = {
        survey: int(
            (
                (final["survey"] == survey)
                & support
            ).sum()
        )
        for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]
    }

    join_rows = []
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        subset = final[final["survey"] == survey]
        join_rows.append({
            "survey": survey,
            "anchor_rows": len(subset),
            "finite_snr_rows": int(
                subset["snr_native"].notna().sum()
            ),
            "finite_snr_fraction": (
                float(subset["snr_native"].notna().mean())
                if len(subset) else 0.0
            ),
            "support_complete_rows": complete_counts[survey],
        })
    write_csv(
        out / "tables/stage6d3a2d5_final_join_coverage.csv",
        [
            "survey", "anchor_rows", "finite_snr_rows",
            "finite_snr_fraction", "support_complete_rows"
        ],
        join_rows,
    )

    galah_ready = selected is not None
    complete_ready = all(
        complete_counts[survey]
        >= int(cfg["minimum_complete_rows_per_survey"])
        for survey in complete_counts
    )
    source_ready = bool(
        d2_ready
        and d3_apogee_ready
        and d4_diagnostic_ready
        and anchor_identity_ready
        and galah_ready
        and final_row_conservation_ready
        and complete_ready
    )

    final_path = None
    final_to_write = final.drop(columns=["_anchor_row_id"], errors="ignore")
    if not final_to_write.empty:
        final_path = (
            out
            / "assembled/stage6d3a2d5_production_source_with_snr.parquet"
        )
        try:
            final_to_write.to_parquet(final_path, index=False)
        except Exception:
            final_path = (
                out
                / "assembled/stage6d3a2d5_production_source_with_snr.csv"
            )
            final_to_write.to_csv(final_path, index=False)

    remaining = []
    if not d2_ready:
        remaining.append({
            "gate": "STAGE6D3A2D2_PREREQUISITE_READY",
            "required_action": "Restore PASS canonical anchor prerequisites.",
        })
    if not d3_apogee_ready:
        remaining.append({
            "gate": "APOGEE_NATIVE_SNR_RECOVERY_READY",
            "required_action": "Restore PASS APOGEE S/N lineage from D3.",
        })
    if not d4_diagnostic_ready:
        remaining.append({
            "gate": "STAGE6D3A2D4_PRECISION_FAILURE_DIAGNOSTIC_READY",
            "required_action": (
                "Stage-6D3A2D4 must document canonical anchor identity, "
                "valid APOGEE lineage, and failed row conservation."
            ),
        })
    if not anchor_identity_ready:
        remaining.append({
            "gate": "CANONICAL_ANCHOR_IDENTITY_READY",
            "required_action": (
                "Canonical D2 anchor must be unique in (source_id, survey)."
            ),
        })
    if not galah_ready:
        remaining.append({
            "gate": "GALAH_CORRECTED_SNR_ID_ROUTE_READY",
            "required_action": selection_error,
        })
    if not final_row_conservation_ready:
        remaining.append({
            "gate": "FINAL_ROW_CONSERVATION_READY",
            "required_action": (
                "Final table must preserve the exact canonical D2 "
                "(source_id, survey) row universe."
            ),
        })
    if galah_ready and final_row_conservation_ready and not complete_ready:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_COMPLETE_ROWS_READY",
            "required_action": (
                f"Need at least {cfg['minimum_complete_rows_per_survey']} "
                "support-complete rows per survey. Observed: "
                + json.dumps(complete_counts, sort_keys=True)
            ),
        })
    write_csv(
        out / "tables/stage6d3a2d5_remaining_items.csv",
        ["gate", "required_action"],
        remaining,
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "canonical_anchor": (
            safe_rel(anchor_path, root) if anchor_path else ""
        ),
        "canonical_anchor_rows": len(anchor),
        "prior_d3_assembled": (
            safe_rel(prior_path, root) if prior_path else ""
        ),
        "prior_d3_rows": len(prior),
        "prior_d3_row_difference": len(prior) - len(anchor),
        "galah_snr_schema_candidate_count": len(snr_candidates),
        "crosswalk_candidate_count": len(crosswalk_candidates),
        "selected_galah_snr_contract": (
            selected["row"]["contract"] if selected else ""
        ),
        "selected_galah_id_route": (
            selected["row"]["id_route"] if selected else ""
        ),
        "selected_galah_candidate_path": (
            selected["row"]["candidate_path"] if selected else ""
        ),
        "selected_galah_crosswalk_path": (
            selected["row"]["crosswalk_path"] if selected else ""
        ),
        "survey_native_snr_medians": medians,
        "assembled_source_table": (
            safe_rel(final_path, root) if final_path else ""
        ),
        "assembled_rows": len(final),
        "support_complete_rows_by_survey": complete_counts,
        "prior_stage_outputs_modified": False,
        "STAGE6D3A2D2_PREREQUISITE_READY": d2_ready,
        "STAGE6D3A2D3_APOGEE_PREREQUISITE_READY": d3_apogee_ready,
        "STAGE6D3A2D4_PRECISION_FAILURE_DIAGNOSTIC_READY": d4_diagnostic_ready,
        "CANONICAL_ANCHOR_IDENTITY_READY": anchor_identity_ready,
        "PRIOR_D3_ROW_CONSERVATION_READY": prior_row_conservation_ready,
        "REBUILT_FROM_CANONICAL_D2_ANCHOR": True,
        "FLOAT64_GAIA_ID_COERCION_FORBIDDEN": True,
        "EXACT_UINT64_GAIA_ID_PARSING_READY": True,
        "APOGEE_NATIVE_SNR_RECOVERED_ON_CANONICAL_KEYS": not apogee_product.empty,
        "GALAH_CORRECTED_SNR_DIRECT_OR_CROSSWALK_READY": galah_ready,
        "GALAH_LOCAL_ID_FUNCTIONAL_MAPPING_READY": bool(
            selected is not None
        ),
        "MULTIPLE_LOCAL_IDS_PER_GAIA_SOURCE_ALLOWED": True,
        "FINAL_ROW_CONSERVATION_READY": final_row_conservation_ready,
        "NATIVE_SNR_PRESERVED": bool(
            not apogee_product.empty and galah_ready
        ),
        "WITHIN_SURVEY_SNR_PERCENTILE_READY": bool(
            not apogee_product.empty and galah_ready
        ),
        "SURVEY_SPECIFIC_SNR_SUPPORT_READY": bool(
            not apogee_product.empty and galah_ready
        ),
        "PRODUCTION_SOURCE_COMPLETE_ROWS_READY": complete_ready,
        "PRODUCTION_SOURCE_ASSEMBLY_READY": source_ready,
        "TARGET_ABUNDANCE_MATCHING_FORBIDDEN": True,
        "SURVEY_NEUTRAL_SNR_PROXY_FORBIDDEN": True,
        "STAGE6D3A2D5_LINEAGE_READY": bool(
            d2_ready
            and d3_apogee_ready
            and d4_diagnostic_ready
            and anchor_identity_ready
            and galah_ready
            and final_row_conservation_ready
        ),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": source_ready,
    }
    write_json(
        out / "validation/stage6d3a2d5_validation.json",
        validation,
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "row_conservation": {
            "canonical_anchor_rows": len(anchor),
            "prior_d3_rows": len(prior),
            "prior_ready": prior_row_conservation_ready,
            "final_rows": len(final),
            "final_ready": final_row_conservation_ready,
            "rebuild_source": "canonical Stage-6D3A2D2 anchor",
        },
        "galah_snr": {
            "contract": validation["selected_galah_snr_contract"],
            "id_route": validation["selected_galah_id_route"],
            "candidate_path": validation[
                "selected_galah_candidate_path"
            ],
            "crosswalk_path": validation[
                "selected_galah_crosswalk_path"
            ],
            "ready": galah_ready,
        },
        "source_assembly": {
            "support_complete_rows_by_survey": complete_counts,
            "ready": source_ready,
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "GALAH S/N has a defensible direct or functional Gaia DR3 "
            "crosswalk lineage. The final source table exactly preserves the "
            "canonical D2 row universe, and Stage-6D3B is authorized."
            if source_ready else
            "GALAH S/N schemas and identifier crosswalks are fully audited. "
            "D3B remains blocked only by the listed GALAH-ID route or "
            "support-complete-row gap."
        ),
    }
    write_json(
        out / "summaries/stage6d3a2d5_summary.json",
        summary,
    )

    report = [
        "# Stage-6D3A2D5 exact UInt64 Gaia-ID and functional crosswalk",
        "",
        f"- Canonical D2 anchor rows: `{len(anchor)}`",
        f"- Prior D3 rows: `{len(prior)}`",
        f"- Prior row conservation: `{prior_row_conservation_ready}`",
        f"- GALAH S/N schema candidates: `{len(snr_candidates)}`",
        f"- Identifier crosswalk candidates: `{len(crosswalk_candidates)}`",
        f"- Selected GALAH contract: `{validation['selected_galah_snr_contract'] or 'not resolved'}`",
        f"- Selected GALAH ID route: `{validation['selected_galah_id_route'] or 'not resolved'}`",
        f"- Final rows: `{len(final)}`",
        f"- Final row conservation: `{final_row_conservation_ready}`",
        f"- APOGEE support-complete rows: `{complete_counts['APOGEE_NATIVE']}`",
        f"- GALAH support-complete rows: `{complete_counts['GALAH_CORRECTED']}`",
        f"- Stage-6D3B ready: `{source_ready}`",
        "",
        "The final source table is rebuilt from the canonical Stage-6D3A2D2 "
        "anchor. The row-expanded Stage-6D3A2D3 table is never used as the "
        "final row universe.",
        "",
        "GALAH may join directly through a Gaia identifier or through an "
        "explicit functional local-ID to Gaia DR3 crosswalk. Ambiguous "
        "crosswalks are rejected.",
        "",
        "No chemical abundance, gradient, residual, or outcome is used to "
        "select an S/N file, identifier route, or crosswalk.",
        "",
    ]
    (
        out / "reports/stage6d3a2d5_exact_uint64_functional_crosswalk.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
