from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import shutil
import traceback
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_columns(path: Path) -> tuple[list[str], int]:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        import pyarrow.parquet as pq
        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    if suffix == ".feather":
        import pyarrow.feather as feather
        table = feather.read_table(path)
        return list(table.column_names), int(table.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def read_table(path: Path, columns: list[str]) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path, columns=columns)
    if suffix == ".feather":
        return pd.read_feather(path, columns=columns)
    return pd.read_csv(path, usecols=columns)


def normalise(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def find_alias(columns: list[str], aliases: list[str]) -> str | None:
    lookup = {normalise(column): column for column in columns}
    for alias in aliases:
        token = normalise(alias)
        if token in lookup:
            return lookup[token]
    return None


def canonical_survey(value: Any, cfg: dict[str, Any]) -> str | None:
    token = normalise(value)
    for survey, variants in cfg["survey_values"].items():
        for variant in variants:
            candidate = normalise(variant)
            if token == candidate or candidate in token:
                return survey
    return None


def infer_survey_from_path(path: Path, cfg: dict[str, Any]) -> str | None:
    token = normalise(str(path))
    matched = []
    for survey, variants in cfg["survey_values"].items():
        if any(normalise(value) in token for value in variants):
            matched.append(survey)
    return matched[0] if len(matched) == 1 else None


def path_is_excluded(path: Path, root: Path, cfg: dict[str, Any]) -> bool:
    text = safe_rel(path, root).lower().replace("\\", "/")
    return any(token.lower() in text for token in cfg["excluded_path_tokens"])


def semantic_priority(path: Path, survey: str, cfg: dict[str, Any]) -> int:
    text = str(path).lower().replace("\\", "/")
    score = 0
    if "stage1" in text:
        score += 800
    if "standard" in text or "common_schema" in text or "ingest" in text:
        score += 500
    if "processed" in text:
        score += 350
    if "interim" in text:
        score += 250
    if "stage2a" in text:
        score += 150
    if survey == "APOGEE_NATIVE" and "apogee" in text:
        score += 1000
    if survey == "GALAH_CORRECTED" and "galah" in text:
        score += 1000
    if "overlap" in text or "common" in text:
        score -= 200
    return score


def detect_contract(path: Path, columns: list[str], row_count: int, cfg: dict[str, Any]) -> list[dict[str, Any]]:
    source_id = find_alias(columns, cfg["source_id_aliases"])
    if not source_id:
        return []

    survey_column = find_alias(columns, cfg["survey_aliases"])
    inferred_survey = infer_survey_from_path(path, cfg)
    rows = []

    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        scalar_aliases = (
            cfg["apogee_scalar_snr_aliases"]
            if survey == "APOGEE_NATIVE"
            else cfg["galah_scalar_snr_aliases"]
        )
        scalar = find_alias(columns, scalar_aliases)
        channels = {}
        if survey == "GALAH_CORRECTED":
            for role, aliases in cfg["galah_channel_snr_alias_groups"].items():
                column = find_alias(columns, aliases)
                if column:
                    channels[role] = column

        survey_possible = bool(
            survey_column
            or inferred_survey == survey
            or (
                survey == "GALAH_CORRECTED"
                and len(channels) >= cfg["minimum_galah_finite_channels"]
            )
        )
        if not survey_possible:
            continue

        contract = None
        columns_used = []
        if scalar:
            contract = "scalar_native_snr"
            columns_used = [scalar]
        elif (
            survey == "GALAH_CORRECTED"
            and len(channels) >= cfg["minimum_galah_finite_channels"]
        ):
            contract = "galah_channel_median"
            columns_used = list(channels.values())
        if not contract:
            continue

        rows.append({
            "path": path,
            "survey": survey,
            "source_id_column": source_id,
            "survey_column": survey_column,
            "inferred_survey": inferred_survey,
            "contract": contract,
            "snr_columns": columns_used,
            "galah_channel_mapping": channels,
            "row_count": row_count,
            "semantic_priority": semantic_priority(path, survey, cfg),
        })
    return rows


def family_key(item: dict[str, Any]) -> tuple[str, ...]:
    return (
        item["survey"],
        str(item["path"].parent.resolve()),
        item["source_id_column"],
        item["survey_column"] or "",
        item["inferred_survey"] or "",
        item["contract"],
        "|".join(sorted(item["snr_columns"])),
    )


def load_item(item: dict[str, Any], cfg: dict[str, Any]) -> pd.DataFrame:
    columns = [item["source_id_column"]] + list(item["snr_columns"])
    if item["survey_column"]:
        columns.append(item["survey_column"])
    columns = sorted(set(columns))
    frame = read_table(item["path"], columns)

    output = pd.DataFrame({
        "source_id": pd.to_numeric(
            frame[item["source_id_column"]], errors="coerce"
        ),
    })

    if item["survey_column"]:
        mapped = frame[item["survey_column"]].map(
            lambda value: canonical_survey(value, cfg)
        ).astype("string")
        output["survey"] = mapped
    else:
        output["survey"] = item["survey"]

    if item["contract"] == "scalar_native_snr":
        output["snr_native"] = pd.to_numeric(
            frame[item["snr_columns"][0]], errors="coerce"
        )
        output["finite_channel_count"] = output["snr_native"].notna().astype(int)
    else:
        channel_frame = pd.DataFrame({
            column: pd.to_numeric(frame[column], errors="coerce")
            for column in item["snr_columns"]
        })
        finite = channel_frame.notna().sum(axis=1)
        output["finite_channel_count"] = finite
        output["snr_native"] = channel_frame.median(axis=1, skipna=True)
        output.loc[
            finite < int(cfg["minimum_galah_finite_channels"]),
            "snr_native"
        ] = np.nan

    output = output[
        output["source_id"].notna()
        & (output["survey"] == item["survey"])
    ].copy()
    output["source_id"] = output["source_id"].astype("uint64")
    output["snr_native"] = pd.to_numeric(
        output["snr_native"], errors="coerce"
    )
    minimum = float(cfg["numeric_snr_minimum_exclusive"])
    maximum = float(cfg["numeric_snr_maximum"])
    output.loc[
        ~np.isfinite(output["snr_native"])
        | (output["snr_native"] <= minimum)
        | (output["snr_native"] > maximum),
        "snr_native"
    ] = np.nan
    output["source_file"] = str(item["path"])
    output["snr_contract"] = item["contract"]
    return output


def aggregate_source_snr(
    frame: pd.DataFrame,
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    audit = []
    rows = []
    for (source_id, survey), group in frame.groupby(
        ["source_id", "survey"], sort=False
    ):
        values = pd.to_numeric(
            group["snr_native"], errors="coerce"
        ).dropna().to_numpy(dtype=float)
        rows.append({
            "source_id": source_id,
            "survey": survey,
            "snr_native": (
                float(np.median(values)) if len(values) else np.nan
            ),
            "snr_measurement_count": int(len(values)),
            "snr_input_row_count": int(len(group)),
            "snr_file_count": int(group["source_file"].nunique()),
            "snr_contract": "|".join(
                sorted(set(group["snr_contract"].astype(str)))
            ),
        })
        if len(group) > 1:
            audit.append({
                "source_id": int(source_id),
                "survey": str(survey),
                "input_rows": int(len(group)),
                "finite_snr_rows": int(len(values)),
                "file_count": int(group["source_file"].nunique()),
                "minimum_snr": (
                    float(np.min(values)) if len(values) else ""
                ),
                "median_snr": (
                    float(np.median(values)) if len(values) else ""
                ),
                "maximum_snr": (
                    float(np.max(values)) if len(values) else ""
                ),
                "aggregation": "source_level_median_native_snr",
            })
    return pd.DataFrame(rows), audit


def load_family(
    items: list[dict[str, Any]],
    cfg: dict[str, Any],
) -> tuple[pd.DataFrame, list[dict[str, Any]], str]:
    if len(items) > int(cfg["maximum_family_files"]):
        return pd.DataFrame(), [], (
            f"family has {len(items)} files; maximum is "
            f"{cfg['maximum_family_files']}"
        )
    pieces = []
    try:
        for item in items:
            pieces.append(load_item(item, cfg))
    except Exception as exc:
        return pd.DataFrame(), [], f"{type(exc).__name__}: {exc}"
    if not pieces:
        return pd.DataFrame(), [], "no loadable files"
    combined = pd.concat(pieces, ignore_index=True)
    aggregated, duplicate_audit = aggregate_source_snr(combined)
    return aggregated, duplicate_audit, ""


def percentile_transform(series: pd.Series) -> pd.Series:
    valid = series.notna()
    output = pd.Series(np.nan, index=series.index, dtype=float)
    if valid.any():
        output.loc[valid] = series.loc[valid].rank(
            method="average", pct=True
        )
    return output


def support_complete_mask(frame: pd.DataFrame) -> pd.Series:
    scalar_required = [
        "R", "abs_Z", "teff", "logg",
        "snr_native", "g_mag", "bp_rp"
    ]
    mask = pd.Series(True, index=frame.index)
    for field in scalar_required:
        if field not in frame.columns:
            return pd.Series(False, index=frame.index)
        mask &= frame[field].notna()
    sky = (
        (
            frame.get("l", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("b", pd.Series(pd.NA, index=frame.index)).notna()
        )
        |
        (
            frame.get("ra", pd.Series(pd.NA, index=frame.index)).notna()
            & frame.get("dec", pd.Series(pd.NA, index=frame.index)).notna()
        )
    )
    return mask & sky


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2d3_config.json").read_text(
            encoding="utf-8"
        )
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables",
        "assembled", "reports", "diagnostics"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg["prerequisite_validation"]
    prereq = (
        json.loads(prereq_path.read_text(encoding="utf-8"))
        if prereq_path.exists() else {}
    )
    prereq_ready = bool(
        prereq.get("STAGE6D3A2D2_LINEAGE_READY", False)
        and prereq.get("SURVEY_ORIGIN_ROW_IDENTITY_READY", False)
        and prereq.get(
            "PREFERRED_SURVEY_NOT_USED_AS_ROW_IDENTITY", False
        )
        and prereq.get("SKY_COORDINATE_SUPPORT_READY", False)
        and prereq.get("GAIA_PHOTOMETRY_SUPPORT_READY", False)
    )

    anchor_path = root / cfg["anchor_table"]
    anchor = pd.DataFrame()
    anchor_error = ""
    if anchor_path.exists():
        try:
            if anchor_path.suffix.lower() == ".parquet":
                anchor = pd.read_parquet(anchor_path)
            elif anchor_path.suffix.lower() == ".feather":
                anchor = pd.read_feather(anchor_path)
            else:
                anchor = pd.read_csv(anchor_path)
        except Exception as exc:
            anchor_error = f"{type(exc).__name__}: {exc}"
    else:
        csv_fallback = anchor_path.with_suffix(".csv")
        if csv_fallback.exists():
            try:
                anchor_path = csv_fallback
                anchor = pd.read_csv(anchor_path)
            except Exception as exc:
                anchor_error = f"{type(exc).__name__}: {exc}"
        else:
            anchor_error = f"anchor table not found: {anchor_path}"

    anchor_identity_ready = bool(
        not anchor.empty
        and {"source_id", "survey"}.issubset(anchor.columns)
        and not anchor.duplicated(["source_id", "survey"]).any()
        and set(anchor["survey"].dropna().astype(str))
        >= {"APOGEE_NATIVE", "GALAH_CORRECTED"}
    )

    inventory = []
    items = []
    suffixes = set(cfg["tabular_suffixes"])
    if anchor_identity_ready:
        for rel_root in cfg["scan_roots"]:
            base = root / rel_root
            if not base.exists():
                continue
            for path in base.rglob("*"):
                if (
                    not path.is_file()
                    or path.suffix.lower() not in suffixes
                    or path.resolve() == anchor_path.resolve()
                    or path_is_excluded(path, root, cfg)
                ):
                    continue
                try:
                    columns, row_count = read_columns(path)
                    detected = detect_contract(
                        path, columns, row_count, cfg
                    )
                    for item in detected:
                        items.append(item)
                        inventory.append({
                            "path": safe_rel(path, root),
                            "survey": item["survey"],
                            "row_count": row_count,
                            "source_id_column": item["source_id_column"],
                            "survey_column": item["survey_column"] or "",
                            "inferred_survey": item["inferred_survey"] or "",
                            "contract": item["contract"],
                            "snr_columns": "|".join(item["snr_columns"]),
                            "semantic_priority": item["semantic_priority"],
                            "read_error": "",
                        })
                except Exception as exc:
                    inventory.append({
                        "path": safe_rel(path, root),
                        "survey": "",
                        "row_count": "",
                        "source_id_column": "",
                        "survey_column": "",
                        "inferred_survey": "",
                        "contract": "",
                        "snr_columns": "",
                        "semantic_priority": "",
                        "read_error": f"{type(exc).__name__}: {exc}",
                    })

    write_csv(
        out / "tables/stage6d3a2d3_snr_candidate_inventory.csv",
        [
            "path", "survey", "row_count",
            "source_id_column", "survey_column",
            "inferred_survey", "contract",
            "snr_columns", "semantic_priority", "read_error"
        ],
        inventory,
    )

    grouped: dict[tuple[str, ...], list[dict[str, Any]]] = defaultdict(list)
    for item in items:
        grouped[family_key(item)].append(item)

    anchor_ids = {
        survey: set(
            anchor.loc[
                anchor["survey"] == survey, "source_id"
            ].dropna().astype("uint64")
        )
        for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]
    } if anchor_identity_ready else {
        "APOGEE_NATIVE": set(),
        "GALAH_CORRECTED": set(),
    }

    family_rows = []
    family_products: dict[str, list[dict[str, Any]]] = {
        "APOGEE_NATIVE": [],
        "GALAH_CORRECTED": [],
    }
    all_duplicate_audit = []

    for key, family_items in grouped.items():
        survey = key[0]
        product, duplicate_audit, error = load_family(
            family_items, cfg
        )
        all_duplicate_audit.extend(duplicate_audit)
        if error:
            family_rows.append({
                "family_id": hashlib.sha256(
                    repr(key).encode("utf-8")
                ).hexdigest()[:16],
                "survey": survey,
                "parent": key[1],
                "contract": key[5],
                "files": len(family_items),
                "source_rows": 0,
                "finite_snr_rows": 0,
                "anchor_overlap_rows": 0,
                "anchor_overlap_fraction": 0.0,
                "finite_overlap_rows": 0,
                "finite_overlap_fraction": 0.0,
                "semantic_priority": max(
                    item["semantic_priority"]
                    for item in family_items
                ),
                "selection_score": -1,
                "load_error": error,
            })
            continue

        if product.empty or "source_id" not in product.columns:
            family_rows.append({
                "family_id": hashlib.sha256(
                    repr(key).encode("utf-8")
                ).hexdigest()[:16],
                "survey": survey,
                "parent": key[1],
                "contract": key[5],
                "files": len(family_items),
                "source_rows": 0,
                "finite_snr_rows": 0,
                "anchor_overlap_rows": 0,
                "anchor_overlap_fraction": 0.0,
                "finite_overlap_rows": 0,
                "finite_overlap_fraction": 0.0,
                "semantic_priority": max(
                    item["semantic_priority"]
                    for item in family_items
                ),
                "selection_score": -1,
                "load_error": "family produced no rows for the requested survey",
            })
            continue

        anchor_set = anchor_ids[survey]
        product_ids = set(product["source_id"].astype("uint64"))
        overlap_ids = anchor_set.intersection(product_ids)
        finite_product = product[product["snr_native"].notna()]
        finite_ids = set(finite_product["source_id"].astype("uint64"))
        finite_overlap = overlap_ids.intersection(finite_ids)
        overlap_fraction = (
            len(overlap_ids) / max(len(anchor_set), 1)
        )
        finite_overlap_fraction = (
            len(finite_overlap) / max(len(anchor_set), 1)
        )
        priority = max(
            item["semantic_priority"] for item in family_items
        )
        score = (
            1_000_000_000 * len(finite_overlap)
            + 1_000_000 * len(overlap_ids)
            + 10_000 * priority
            + len(finite_product)
        )
        family_id = hashlib.sha256(
            repr(key).encode("utf-8")
        ).hexdigest()[:16]
        row = {
            "family_id": family_id,
            "survey": survey,
            "parent": key[1],
            "contract": key[5],
            "files": len(family_items),
            "source_rows": len(product),
            "finite_snr_rows": int(product["snr_native"].notna().sum()),
            "anchor_overlap_rows": len(overlap_ids),
            "anchor_overlap_fraction": overlap_fraction,
            "finite_overlap_rows": len(finite_overlap),
            "finite_overlap_fraction": finite_overlap_fraction,
            "semantic_priority": priority,
            "selection_score": score,
            "load_error": "",
        }
        family_rows.append(row)
        family_products[survey].append({
            "row": row,
            "product": product,
            "items": family_items,
        })

    write_csv(
        out / "tables/stage6d3a2d3_snr_family_audit.csv",
        [
            "family_id", "survey", "parent", "contract",
            "files", "source_rows", "finite_snr_rows",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "finite_overlap_rows", "finite_overlap_fraction",
            "semantic_priority", "selection_score", "load_error"
        ],
        sorted(
            family_rows,
            key=lambda row: (
                row["survey"],
                -float(row["selection_score"]),
                row["family_id"],
            ),
        ),
    )
    write_csv(
        out / "tables/stage6d3a2d3_snr_duplicate_aggregation.csv",
        [
            "source_id", "survey", "input_rows",
            "finite_snr_rows", "file_count",
            "minimum_snr", "median_snr",
            "maximum_snr", "aggregation"
        ],
        all_duplicate_audit,
    )

    selected = {}
    selection_error = {}
    selected_contract_rows = []
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        candidates = [
            item for item in family_products[survey]
            if (
                item["row"]["finite_overlap_rows"]
                >= int(cfg["minimum_selected_join_rows"])
                and item["row"]["finite_overlap_fraction"]
                >= float(cfg["minimum_anchor_overlap_fraction"])
            )
        ]
        candidates.sort(
            key=lambda item: (
                -item["row"]["selection_score"],
                item["row"]["family_id"],
            )
        )
        if not candidates:
            selection_error[survey] = (
                "no family meets finite anchor-overlap gate"
            )
            continue
        if (
            len(candidates) > 1
            and candidates[0]["row"]["selection_score"]
            == candidates[1]["row"]["selection_score"]
        ):
            selection_error[survey] = (
                "top S/N family selection is tied"
            )
            continue
        winner = candidates[0]
        selected[survey] = winner
        selected_contract_rows.append({
            "survey": survey,
            "family_id": winner["row"]["family_id"],
            "contract": winner["row"]["contract"],
            "parent": winner["row"]["parent"],
            "files": winner["row"]["files"],
            "finite_overlap_rows": winner["row"]["finite_overlap_rows"],
            "finite_overlap_fraction": winner["row"]["finite_overlap_fraction"],
            "selection_score": winner["row"]["selection_score"],
            "selection_reason": (
                "unique maximum finite anchor overlap, then total overlap, "
                "semantic priority, and finite source coverage"
            ),
            "file_paths": "|".join(
                safe_rel(item["path"], root)
                for item in winner["items"]
            ),
        })

    write_csv(
        out / "tables/stage6d3a2d3_selected_snr_contracts.csv",
        [
            "survey", "family_id", "contract",
            "parent", "files", "finite_overlap_rows",
            "finite_overlap_fraction", "selection_score",
            "selection_reason", "file_paths"
        ],
        selected_contract_rows,
    )

    assembled = anchor.copy()
    for column in [
        "snr_native", "snr_measurement_count",
        "snr_input_row_count", "snr_file_count",
        "snr_contract"
    ]:
        if column in assembled.columns:
            assembled.drop(columns=[column], inplace=True)

    join_rows = []
    selected_products = [
        winner["product"].copy()
        for winner in selected.values()
    ]
    if selected_products:
        combined_snr = pd.concat(
            selected_products, ignore_index=True, sort=False
        )
        if combined_snr.duplicated(["source_id", "survey"]).any():
            raise RuntimeError(
                "selected S/N families overlap within (source_id, survey)"
            )
        assembled = assembled.merge(
            combined_snr,
            on=["source_id", "survey"],
            how="left",
            validate="one_to_one",
        )

    for survey, winner in selected.items():
        subset = assembled["survey"] == survey
        joined_finite = int(
            (subset & assembled["snr_native"].notna()).sum()
        )
        anchor_rows = int(subset.sum())
        join_rows.append({
            "survey": survey,
            "anchor_rows": anchor_rows,
            "joined_finite_snr_rows": joined_finite,
            "joined_finite_snr_fraction": (
                joined_finite / max(anchor_rows, 1)
            ),
            "family_id": winner["row"]["family_id"],
            "contract": winner["row"]["contract"],
        })

    write_csv(
        out / "tables/stage6d3a2d3_snr_join_coverage.csv",
        [
            "survey", "anchor_rows",
            "joined_finite_snr_rows",
            "joined_finite_snr_fraction",
            "family_id", "contract"
        ],
        join_rows,
    )

    if "snr_native" not in assembled.columns:
        assembled["snr_native"] = np.nan
    assembled["snr_log1p_native"] = np.log1p(
        pd.to_numeric(
            assembled["snr_native"], errors="coerce"
        ).clip(lower=0)
    )
    assembled["snr_within_survey_percentile"] = np.nan
    assembled["snr_support_half"] = pd.Series(
        pd.NA, index=assembled.index, dtype="string"
    )
    survey_medians = {}
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        mask = assembled["survey"] == survey
        series = pd.to_numeric(
            assembled.loc[mask, "snr_native"], errors="coerce"
        )
        transformed = percentile_transform(series)
        assembled.loc[
            mask, "snr_within_survey_percentile"
        ] = transformed
        median = float(series.median()) if series.notna().any() else np.nan
        survey_medians[survey] = median
        if np.isfinite(median):
            low = mask & assembled["snr_native"].notna() & (
                assembled["snr_native"] <= median
            )
            high = mask & assembled["snr_native"].notna() & (
                assembled["snr_native"] > median
            )
            assembled.loc[low, "snr_support_half"] = "LOW_NATIVE_SNR_HALF"
            assembled.loc[high, "snr_support_half"] = "HIGH_NATIVE_SNR_HALF"

    support_mask = support_complete_mask(assembled)
    complete_counts = {
        survey: int(
            (
                (assembled["survey"] == survey)
                & support_mask
            ).sum()
        )
        for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]
    }

    missingness_rows = []
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        subset = assembled[assembled["survey"] == survey]
        for field in [
            "R", "abs_Z", "teff", "logg",
            "snr_native", "g_mag", "bp_rp",
            "l", "b", "ra", "dec"
        ]:
            non_null = (
                int(subset[field].notna().sum())
                if field in subset.columns else 0
            )
            missingness_rows.append({
                "survey": survey,
                "field": field,
                "survey_rows": len(subset),
                "non_null_rows": non_null,
                "missing_rows": len(subset) - non_null,
                "coverage_fraction": (
                    non_null / len(subset) if len(subset) else 0.0
                ),
            })
    write_csv(
        out / "tables/stage6d3a2d3_support_missingness_by_survey.csv",
        [
            "survey", "field", "survey_rows",
            "non_null_rows", "missing_rows",
            "coverage_fraction"
        ],
        missingness_rows,
    )

    snr_ready_by_survey = {
        survey: (
            survey in selected
            and any(
                row["survey"] == survey
                and row["joined_finite_snr_rows"]
                >= int(cfg["minimum_selected_join_rows"])
                for row in join_rows
            )
        )
        for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]
    }
    complete_ready = all(
        complete_counts[survey]
        >= int(cfg["minimum_complete_rows_per_survey"])
        for survey in complete_counts
    )
    snr_lineage_ready = all(snr_ready_by_survey.values())
    source_ready = bool(
        prereq_ready
        and anchor_identity_ready
        and snr_lineage_ready
        and complete_ready
    )

    assembled_path = None
    if not assembled.empty:
        assembled_path = (
            out
            / "assembled/stage6d3a2d3_production_source_with_snr.parquet"
        )
        try:
            assembled.to_parquet(assembled_path, index=False)
        except Exception:
            assembled_path = (
                out
                / "assembled/stage6d3a2d3_production_source_with_snr.csv"
            )
            assembled.to_csv(assembled_path, index=False)

    remaining = []
    if not prereq_ready:
        remaining.append({
            "gate": "STAGE6D3A2D2_PREREQUISITE_READY",
            "required_action": (
                "Restore PASS row-origin, sky-coordinate, and Gaia-photometry "
                "prerequisites from Stage-6D3A2D2."
            ),
        })
    if anchor_error or not anchor_identity_ready:
        remaining.append({
            "gate": "ANCHOR_SOURCE_SURVEY_IDENTITY_READY",
            "required_action": (
                anchor_error
                or "Anchor must be unique in (source_id, survey) and contain "
                   "both APOGEE_NATIVE and GALAH_CORRECTED."
            ),
        })
    for survey in ["APOGEE_NATIVE", "GALAH_CORRECTED"]:
        if not snr_ready_by_survey[survey]:
            remaining.append({
                "gate": f"{survey}_SNR_LINEAGE_READY",
                "required_action": selection_error.get(
                    survey,
                    "selected S/N family does not meet finite join coverage gate",
                ),
            })
    if snr_lineage_ready and not complete_ready:
        remaining.append({
            "gate": "PRODUCTION_SOURCE_COMPLETE_ROWS_READY",
            "required_action": (
                f"Need at least {cfg['minimum_complete_rows_per_survey']} "
                "support-complete rows per survey after S/N join. Observed: "
                + json.dumps(complete_counts, sort_keys=True)
            ),
        })
    write_csv(
        out / "tables/stage6d3a2d3_remaining_items.csv",
        ["gate", "required_action"],
        remaining,
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "anchor_table": safe_rel(anchor_path, root),
        "anchor_rows": len(anchor),
        "candidate_contract_count": len(items),
        "candidate_family_count": len(grouped),
        "selected_snr_families": {
            survey: winner["row"]["family_id"]
            for survey, winner in selected.items()
        },
        "selected_snr_contracts": {
            survey: winner["row"]["contract"]
            for survey, winner in selected.items()
        },
        "survey_native_snr_medians": survey_medians,
        "assembled_source_table": (
            safe_rel(assembled_path, root) if assembled_path else ""
        ),
        "assembled_rows": len(assembled),
        "support_complete_rows_by_survey": complete_counts,
        "anchor_error": anchor_error,
        "prior_stage_outputs_modified": False,
        "STAGE6D3A2D2_PREREQUISITE_READY": prereq_ready,
        "ANCHOR_SOURCE_SURVEY_IDENTITY_READY": anchor_identity_ready,
        "APOGEE_NATIVE_SNR_LINEAGE_READY": snr_ready_by_survey[
            "APOGEE_NATIVE"
        ],
        "GALAH_CORRECTED_SNR_LINEAGE_READY": snr_ready_by_survey[
            "GALAH_CORRECTED"
        ],
        "SOURCE_LEVEL_MEDIAN_SNR_AGGREGATION_READY": snr_lineage_ready,
        "NATIVE_SNR_PRESERVED": snr_lineage_ready,
        "WITHIN_SURVEY_SNR_PERCENTILE_READY": snr_lineage_ready,
        "SURVEY_MEDIAN_SNR_SUPPORT_HALF_READY": snr_lineage_ready,
        "SURVEY_SPECIFIC_SNR_SUPPORT_READY": snr_lineage_ready,
        "PRODUCTION_SOURCE_COMPLETE_ROWS_READY": complete_ready,
        "PRODUCTION_SOURCE_ASSEMBLY_READY": source_ready,
        "TARGET_ABUNDANCE_MATCHING_FORBIDDEN": True,
        "SURVEY_NEUTRAL_SNR_PROXY_FORBIDDEN": True,
        "STAGE6D3A2D3_LINEAGE_READY": bool(
            prereq_ready and anchor_identity_ready and snr_lineage_ready
        ),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": source_ready,
    }
    write_json(
        out / "validation/stage6d3a2d3_validation.json",
        validation,
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "snr_contract": {
            "APOGEE_NATIVE": (
                validation["selected_snr_contracts"].get(
                    "APOGEE_NATIVE", "not resolved"
                )
            ),
            "GALAH_CORRECTED": (
                validation["selected_snr_contracts"].get(
                    "GALAH_CORRECTED", "not resolved"
                )
            ),
            "source_level_aggregation": "median native S/N",
            "galah_channel_rule": (
                f"row median with at least "
                f"{cfg['minimum_galah_finite_channels']} finite channels"
            ),
            "cross_survey_use": (
                "preserve native values; use within-survey percentile or "
                "median half only for support construction"
            ),
        },
        "source_assembly": {
            "rows": len(assembled),
            "support_complete_rows_by_survey": complete_counts,
            "ready": source_ready,
        },
        "remaining_items": remaining,
        "scientific_disposition": (
            "Survey-specific APOGEE and GALAH S/N lineage is closed and the "
            "support-complete production source table is ready. Stage-6D3B "
            "common-footprint construction is authorized."
            if source_ready else
            "The S/N archive has been audited outcome-blindly; D3B remains "
            "blocked only by the listed survey-specific S/N lineage or "
            "complete-row gap."
        ),
    }
    write_json(
        out / "summaries/stage6d3a2d3_summary.json",
        summary,
    )

    report = [
        "# Stage-6D3A2D3 survey-specific S/N lineage",
        "",
        f"- Anchor rows: `{len(anchor)}`",
        f"- Candidate S/N contracts: `{len(items)}`",
        f"- Candidate families: `{len(grouped)}`",
        f"- APOGEE S/N lineage ready: `{snr_ready_by_survey['APOGEE_NATIVE']}`",
        f"- GALAH S/N lineage ready: `{snr_ready_by_survey['GALAH_CORRECTED']}`",
        f"- APOGEE support-complete rows: `{complete_counts['APOGEE_NATIVE']}`",
        f"- GALAH support-complete rows: `{complete_counts['GALAH_CORRECTED']}`",
        f"- Stage-6D3B ready: `{source_ready}`",
        "",
        "APOGEE uses an explicit scalar native S/N. GALAH uses an explicit "
        "scalar native S/N when available; otherwise it uses the row median "
        "of at least two finite detector/arm S/N values.",
        "",
        "Repeated spectroscopic rows are aggregated to one source×survey row "
        "using the median native S/N. Raw native S/N is preserved. The "
        "within-survey percentile and median-half fields are support-only "
        "transformations and are not astrophysical measurements.",
        "",
        "No chemical abundance, gradient estimate, residual, or target label "
        "is used to select an S/N product or define a join.",
        "",
    ]
    (
        out / "reports/stage6d3a2d3_survey_specific_snr_lineage.md"
    ).write_text("\n".join(report), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
