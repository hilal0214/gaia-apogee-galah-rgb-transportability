from __future__ import annotations
import argparse,hashlib,json,math
from datetime import datetime,timezone
from pathlib import Path
import numpy as np,pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def canon(o): return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def ess(w):
    w=np.asarray(w,float); s=w.sum(); ss=np.square(w).sum()
    return float(s*s/ss) if ss>0 else 0.0

def em2(y,w,maxiter=500,tol=1e-10):
    y=np.asarray(y,float); w=np.asarray(w,float)
    q=np.quantile(y,[.30,.70]); mu=np.array(q,float)
    sd=max(np.std(y),1e-3); sig=np.array([sd*.55,sd*.55],float)
    pi=np.array([.5,.5],float)
    last=None
    for _ in range(maxiter):
        dens=[]
        for k in range(2):
            z=(y-mu[k])/sig[k]
            dens.append(pi[k]*np.exp(-.5*z*z)/(sig[k]*np.sqrt(2*np.pi)))
        D=np.column_stack(dens); den=np.maximum(D.sum(axis=1),1e-300)
        r=D/den[:,None]
        rw=r*w[:,None]; nk=rw.sum(axis=0)
        pi=nk/nk.sum()
        mu=(rw*y[:,None]).sum(axis=0)/nk
        var=(rw*np.square(y[:,None]-mu)).sum(axis=0)/nk
        sig=np.sqrt(np.maximum(var,1e-6))
        order=np.argsort(mu); mu,sig,pi=mu[order],sig[order],pi[order]
        ll=float(np.sum(w*np.log(den)))
        if last is not None and abs(ll-last)<=tol*(1+abs(last)): break
        last=ll
    return {"mu_low":float(mu[0]),"mu_high":float(mu[1]),"sigma_low":float(sig[0]),"sigma_high":float(sig[1]),"pi_high":float(pi[1])}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage8b1_config.json").read_text(encoding="utf-8"))
    v8=json.loads((root/c["stage8a_validation"]).read_text(encoding="utf-8"))
    p8=json.loads((root/c["stage8a_protocol"]).read_text(encoding="utf-8"))
    identity=bool(
        v8.get("STAGE8A_ALPHA_MORPHOLOGY_PROTOCOL_FROZEN") and
        v8.get("STAGE8A_PROTOCOL_CANONICAL_SHA256")==c["expected_stage8a_protocol_sha256"] and
        canon(p8)==c["expected_stage8a_protocol_sha256"] and
        v8.get("STAGE8_REAL_MIXTURE_INTERPRETATION_AUTHORIZED") is False and
        v8.get("STAGE8B_SYNTHETIC_POWER_PREFLIGHT_READY")
    )
    if not identity: raise RuntimeError("Stage-8A identity prerequisite failed")

    src=root/c["balanced_source"]
    schema=pd.read_parquet(src).columns.tolist()
    alpha_col=next((x for x in c["candidate_alpha_columns"] if x in schema),None)
    if alpha_col is None:
        raise RuntimeError("No frozen alpha3-compatible column found in balanced source")
    cols=c["required_columns"]+[alpha_col]
    df=pd.read_parquet(src,columns=cols)

    # Exact IDs never coerced through float.
    sid=df["source_id"]
    if pd.api.types.is_float_dtype(sid.dtype):
        raise RuntimeError("source_id float coercion forbidden")

    num={}
    for x in ["R","abs_Z","fe_h","balance_weight_final",alpha_col]:
        num[x]=pd.to_numeric(df[x],errors="coerce").to_numpy(float)
    survey=df["survey"].astype(str).to_numpy()
    cell=pd.to_numeric(df["healpix_gal_ring_nside16"],errors="raise").to_numpy(np.int64)
    d=c["domain"]
    m=(np.isfinite(num["R"])&np.isfinite(num["abs_Z"])&np.isfinite(num["fe_h"])&
       np.isfinite(num["balance_weight_final"])&(num["balance_weight_final"]>0)&
       (num["R"]>=d["R_min"])&(num["R"]<=d["R_max"])&
       (num["abs_Z"]>=d["absZ_min"])&(num["abs_Z"]<=d["absZ_max"])&
       (num["fe_h"]>=d["feh_min"])&(num["fe_h"]<=d["feh_max"]))
    # alpha3 is used only as a finite-value eligibility mask here.
    m &= np.isfinite(num[alpha_col])
    x=df.loc[m].copy()
    feh=num["fe_h"][m]; w=num["balance_weight_final"][m]; sv=survey[m]; ce=cell[m]

    rows=[]
    hw=float(c["knot_halfwidth_dex"])
    for knot in c["fixed_feh_knots"]:
        km=np.abs(feh-float(knot))<=hw
        for s in c["survey_values"]:
            q=km&(sv==s)
            rows.append({
                "feh_knot":float(knot),"survey":s,"rows":int(q.sum()),
                "effective_n":ess(w[q]),"nside16_cells":int(np.unique(ce[q]).size),
                "weight_sum":float(w[q].sum())
            })
    sup=pd.DataFrame(rows)
    miness=float(c["minimum_bin_effective_n"]); mincells=int(c["minimum_cells_per_survey_per_knot"])
    knot_support=bool((sup["effective_n"]>=miness).all() and (sup["nside16_cells"]>=mincells).all())
    surveys_ready=bool(all(np.any(sv==s) for s in c["survey_values"]))
    blocks=int(np.unique(ce).size)
    block_ready=blocks>=100

    # Fully synthetic smoke: no observed alpha3 values enter.
    sm=c["synthetic_smoke"]; rng=np.random.Generator(np.random.PCG64DXSM(int(sm["seed"])))
    n=int(sm["n"]); z=rng.random(n)<float(sm["pi_high"])
    y=np.where(z,rng.normal(sm["mu_high"],sm["sigma_high"],n),rng.normal(sm["mu_low"],sm["sigma_low"],n))
    ws=np.exp(rng.normal(0,.25,n)); fit=em2(y,ws)
    smoke_pass=bool(
        abs(fit["mu_low"]-sm["mu_low"])<=sm["max_abs_mu_error"] and
        abs(fit["mu_high"]-sm["mu_high"])<=sm["max_abs_mu_error"] and
        abs(fit["pi_high"]-sm["pi_high"])<=sm["max_abs_pi_error"] and
        fit["mu_low"]<fit["mu_high"]
    )

    ready=bool(identity and knot_support and surveys_ready and block_ready and smoke_pass)
    out=root/c["output_dir"]
    for q in ["tables","validation","freeze"]: (out/q).mkdir(parents=True,exist_ok=True)
    sup.to_csv(out/"tables/stage8b1_knot_support.csv",index=False)
    (out/"freeze/stage8b1_protocol_frozen.json").write_text((root/"protocol/stage8b1_protocol.json").read_text(),encoding="utf-8")
    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "STAGE8A_IDENTITY_READY":identity,
      "ALPHA_COORDINATE_COLUMN":alpha_col,
      "BALANCED_SOURCE_ROWS":int(len(df)),
      "ELIGIBLE_DOMAIN_ROWS":int(len(x)),
      "ELIGIBLE_SURVEY_COUNTS":{s:int(np.sum(sv==s)) for s in c["survey_values"]},
      "PRIMARY_NSIDE16_BLOCKS":blocks,
      "ALL_7_KNOTS_BOTH_SURVEYS_SUPPORT_READY":knot_support,
      "BOTH_SURVEYS_PRESENT":surveys_ready,
      "PRIMARY_BLOCK_COUNT_READY":block_ready,
      "SYNTHETIC_EM_SMOKE_READY":smoke_pass,
      "SYNTHETIC_EM_SMOKE_FIT":fit,
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":False,
      "REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED":False,
      "STAGE8B1_PREFLIGHT_READY":ready,
      "STAGE8B2_SYNTHETIC_POWER_READY":ready,
      "STAGE8_REAL_MIXTURE_INTERPRETATION_AUTHORIZED":False
    }
    (out/"validation/stage8b1_validation.json").write_text(json.dumps(val,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(val,indent=2))
    return 0 if ready else 2

if __name__=="__main__": raise SystemExit(main())
