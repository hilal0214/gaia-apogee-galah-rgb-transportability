from __future__ import annotations
import argparse, hashlib, json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

def now(): return datetime.now(timezone.utc).isoformat()
def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()
def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage8b1a_config.json").read_text(encoding="utf-8"))
    bal=root/c["balanced_source"]; des=root/c["stage4a_design"]
    if not bal.exists(): raise FileNotFoundError(bal)
    if not des.exists(): raise FileNotFoundError(des)

    bal_schema=pq.ParquetFile(bal).schema_arrow.names
    des_schema=pq.ParquetFile(des).schema_arrow.names

    alpha=next((x for x in c["candidate_alpha_columns"] if x in des_schema),None)
    if alpha is None:
        raise RuntimeError("Frozen alpha3 column not found in Stage4A design layer")

    flag=next((x for x in c["candidate_alpha_flags"] if x in des_schema),None)

    keys=c["join_keys"]
    for k in keys:
        if k not in bal_schema: raise RuntimeError(f"Balanced source missing join key: {k}")
        if k not in des_schema: raise RuntimeError(f"Stage4A design missing join key: {k}")

    b=pd.read_parquet(bal)
    dcols=keys+[alpha]+([flag] if flag else [])
    d=pd.read_parquet(des,columns=dcols)

    # Never coerce source_id through float.
    if pd.api.types.is_float_dtype(b["source_id"].dtype) or pd.api.types.is_float_dtype(d["source_id"].dtype):
        raise RuntimeError("source_id float coercion forbidden")

    if len(b)!=int(c["expected_balanced_rows"]):
        raise RuntimeError(f"balanced row identity mismatch: {len(b)}")

    bdup=int(b.duplicated(keys).sum())
    ddup=int(d.duplicated(keys).sum())
    if bdup: raise RuntimeError(f"balanced join-key duplicates: {bdup}")
    if ddup:
        # Exact duplicates are allowed only if alpha/flag values are identical.
        grp=d.groupby(keys,dropna=False,sort=False)
        bad=0
        for _,g in grp:
            if len(g)>1:
                vals=pd.to_numeric(g[alpha],errors="coerce")
                finite=vals[np.isfinite(vals)]
                if len(finite)>1 and float(finite.max()-finite.min())>0:
                    bad+=1
                if flag:
                    vv=g[flag].astype(str).unique()
                    if len(vv)>1: bad+=1
        if bad: raise RuntimeError(f"Stage4A non-identical duplicate-key groups: {bad}")
        d=d.drop_duplicates(keys,keep="first")

    # Match key dtypes safely by string representation only for comparison/join,
    # while original source_id remains untouched in output.
    b2=b.copy(); d2=d.copy()
    b2["_join_source_id"]=b2["source_id"].astype(str)
    d2["_join_source_id"]=d2["source_id"].astype(str)
    b2["_join_survey"]=b2["survey"].astype(str)
    d2["_join_survey"]=d2["survey"].astype(str)

    keep=["_join_source_id","_join_survey",alpha]+([flag] if flag else [])
    m=b2.merge(d2[keep],on=["_join_source_id","_join_survey"],how="left",validate="one_to_one",indicator=True)

    if len(m)!=len(b):
        raise RuntimeError("left-join row count changed")

    matched=int((m["_merge"]=="both").sum())
    unmatched=int((m["_merge"]!="both").sum())
    aval=pd.to_numeric(m[alpha],errors="coerce").to_numpy(float)
    finite=int(np.isfinite(aval).sum())
    frac=float(finite/len(m))

    # Remove helper columns only; preserve the original balanced source columns byte-semantically
    # at the dataframe-value level and attach frozen alpha3 provenance columns.
    out=m.drop(columns=["_join_source_id","_join_survey","_merge"])
    outpath=root/c["output_attached_source"]
    outpath.parent.mkdir(parents=True,exist_ok=True)
    out.to_parquet(outpath,index=False)

    # Verify all original columns are unchanged row-by-row.
    exact_original=True
    for col in b.columns:
        x=b[col].reset_index(drop=True)
        y=out[col].reset_index(drop=True)
        if pd.api.types.is_numeric_dtype(x.dtype):
            xa=pd.to_numeric(x,errors="coerce").to_numpy()
            ya=pd.to_numeric(y,errors="coerce").to_numpy()
            if not np.array_equal(xa,ya,equal_nan=True):
                exact_original=False; break
        else:
            if not x.astype(str).equals(y.astype(str)):
                exact_original=False; break

    ready=bool(
        matched==len(b) and unmatched==0 and
        frac>=float(c["minimum_alpha3_finite_fraction"]) and
        exact_original
    )

    outdir=root/c["output_dir"]
    for q in ["tables","validation","assembled","manifest"]: (outdir/q).mkdir(parents=True,exist_ok=True)
    pd.DataFrame([{
        "balanced_rows":len(b),"matched_rows":matched,"unmatched_rows":unmatched,
        "alpha3_finite_rows":finite,"alpha3_finite_fraction":frac,
        "stage4a_duplicate_keys_raw":ddup,"alpha_flag_column":flag or ""
    }]).to_csv(outdir/"tables/stage8b1a_join_summary.csv",index=False)

    val={
      "stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
      "BALANCED_SOURCE_SHA256":sha_file(bal),
      "STAGE4A_DESIGN_SHA256":sha_file(des),
      "ALPHA3_PROVENANCE_SOURCE":"Stage4A frozen analysis-design layer",
      "ALPHA3_COLUMN":alpha,
      "ALPHA3_FLAG_COLUMN":flag,
      "JOIN_KEYS":keys,
      "BALANCED_ROWS":len(b),
      "MATCHED_ROWS":matched,
      "UNMATCHED_ROWS":unmatched,
      "ALPHA3_FINITE_ROWS":finite,
      "ALPHA3_FINITE_FRACTION":frac,
      "SOURCE_ID_FLOAT_COERCION_USED":False,
      "ABUNDANCE_OR_OUTCOME_MATCHING_USED":False,
      "BALANCING_WEIGHTS_CHANGED":False,
      "SUPPORT_SELECTION_CHANGED":False,
      "ORIGINAL_BALANCED_COLUMNS_VALUE_IDENTITY_READY":exact_original,
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":False,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":False,
      "STAGE8B1A_ALPHA3_PROVENANCE_JOIN_READY":ready,
      "STAGE8B1_REPLAY_WITH_ATTACHED_ALPHA3_READY":ready,
      "ATTACHED_SOURCE_RELATIVE_PATH":c["output_attached_source"]
    }
    write_json(outdir/"validation/stage8b1a_validation.json",val)
    print(json.dumps(val,indent=2,ensure_ascii=False))
    return 0 if ready else 2

if __name__=="__main__": raise SystemExit(main())
