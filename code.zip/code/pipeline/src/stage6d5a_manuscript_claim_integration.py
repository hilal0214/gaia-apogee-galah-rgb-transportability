from __future__ import annotations
import argparse,hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
import numpy as np,pandas as pd

def now():return datetime.now(timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1048576),b""):h.update(b)
 return h.hexdigest()
def wj(p,o):
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def esc(s):
 return str(s).replace("\\","\\textbackslash{}").replace("_","\\_").replace("%","\\%").replace("&","\\&").replace("#","\\#")
def fmt(x,n=4):
 try:
  v=float(x)
  if not np.isfinite(v):return "--"
  return f"{v:.{n}f}"
 except:return str(x)
def read(p):return pd.read_csv(p)

def main():
 ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");a=ap.parse_args()
 root=Path(a.project_root).resolve()
 c=json.loads((root/"config/stage6d5a_config.json").read_text())
 out=root/c["output_dir"]
 if out.exists():shutil.rmtree(out)
 for d in ["validation","tables","latex","text","summaries","manifest"]:(out/d).mkdir(parents=True,exist_ok=True)

 vp=root/c["d4c_validation"]
 cp=root/c["d4c_classification"]
 xp=root/c["d4c_coordinate"]
 rp=root/c["d4c_comparisons"]
 lp=root/c["d4c_claim_ledger"]
 ep=root/c["d4b_estimates"]
 for p in [vp,cp,xp,rp,lp,ep]:
  if not p.exists():raise FileNotFoundError(str(p))

 v=json.loads(vp.read_text(encoding="utf-8"))
 prereq=bool(v.get("STAGE6D4_SCIENCE_CLOSURE_READY") and v.get("STAGE6D5_MANUSCRIPT_INTEGRATION_READY"))
 cls=read(cp);coord=read(xp);comp=read(rp);ledger=read(lp);est=read(ep)

 labels_ready=set(cls["label"])==set(c["primary_labels"]) and len(cls)==5
 classes_ready=set(cls["overall_classification"])<=set(c["expected_classes"])
 counts=cls["overall_classification"].value_counts().to_dict()
 counts_ready=all(int(counts.get(k,0))==int(vv) for k,vv in c["expected_classification_counts"].items())
 no_sensitive=not cls["overall_classification"].isin(["FOOTPRINT_SENSITIVE","SURVEY_SENSITIVE"]).any()

 stable_labels=cls.loc[cls["overall_classification"]=="TRANSPORT_STABLE","label"].tolist()
 ind_labels=cls.loc[cls["overall_classification"]=="INDETERMINATE","label"].tolist()
 vertical_stable=coord.loc[(coord["coordinate"]=="Z")&(coord["coordinate_classification"]=="TRANSPORT_STABLE"),"label"].tolist()
 radial_stable=coord.loc[(coord["coordinate"]=="R")&(coord["coordinate_classification"]=="TRANSPORT_STABLE"),"label"].tolist()

 # Exact publication summary table.
 rows=[]
 for _,r in cls.iterrows():
  lab=r["label"]
  full=est[(est["label"]==lab)&(est["model_id"]=="FULL_SUPPORT_FROZEN")].iloc[0]
  bal=est[(est["label"]==lab)&(est["model_id"]=="COMMON_FOOTPRINT_BALANCED")].iloc[0]
  inter=est[(est["label"]==lab)&(est["model_id"]=="COMMON_FOOTPRINT_INTERACTION")].iloc[0]
  cr=coord[(coord["label"]==lab)&(coord["coordinate"]=="R")].iloc[0]
  cz=coord[(coord["label"]==lab)&(coord["coordinate"]=="Z")].iloc[0]
  rows.append({
   "label":lab,"display_label":c["display_names"][lab],
   "full_beta_R":full["beta_R"],"balanced_beta_R":bal["beta_R"],
   "full_beta_Z":full["beta_Z"],"balanced_beta_Z":bal["beta_Z"],
   "delta_beta_R":inter["delta_beta_R"],"delta_beta_Z":inter["delta_beta_Z"],
   "radial_margin":cr["practical_margin"],"vertical_margin":cz["practical_margin"],
   "radial_classification":r["radial_classification"],
   "vertical_classification":r["vertical_classification"],
   "overall_classification":r["overall_classification"]
  })
 summary=pd.DataFrame(rows)
 summary.to_csv(out/"tables/stage6d5a_publication_summary.csv",index=False)

 # LaTeX table, no external dependency.
 lines=[
 r"\begin{table*}",
 r"\centering",
 r"\caption{Common-footprint transport classification for the five primary labels. "
 r"The full-support coefficients are frozen Stage-4B values; balanced coefficients use the "
 r"D3C9 outcome-blind survey-balance weights. The final classes follow the pre-specified "
 r"Stage-6D3A practical-equivalence rules.}",
 r"\label{tab:transport_classification}",
 r"\begin{tabular}{lrrrrrrlll}",
 r"\hline",
 r"Label & $\beta_{R,\rm full}$ & $\beta_{R,\rm bal}$ & $\beta_{Z,\rm full}$ & "
 r"$\beta_{Z,\rm bal}$ & $\Delta\beta_R$ & $\Delta\beta_Z$ & Radial & Vertical & Overall \\",
 r"\hline"
 ]
 for _,r in summary.iterrows():
  lines.append(
   f"{r['display_label']} & {fmt(r['full_beta_R'])} & {fmt(r['balanced_beta_R'])} & "
   f"{fmt(r['full_beta_Z'])} & {fmt(r['balanced_beta_Z'])} & "
   f"{fmt(r['delta_beta_R'])} & {fmt(r['delta_beta_Z'])} & "
   f"{esc(r['radial_classification'])} & {esc(r['vertical_classification'])} & "
   f"{esc(r['overall_classification'])} \\\\"
  )
 lines += [r"\hline",r"\end{tabular}",r"\end{table*}"]
 (out/"latex/stage6d5a_transport_classification_table.tex").write_text("\n".join(lines)+"\n",encoding="utf-8")

 # Claim-safe prose.
 stable_names=[c["display_names"][x] for x in stable_labels]
 ind_names=[c["display_names"][x] for x in ind_labels]
 vert_names=[c["display_names"][x] for x in vertical_stable]
 rad_names=[c["display_names"][x] for x in radial_stable]

 abstract=(
  "After restricting both surveys to a frozen common footprint and applying outcome-blind "
  "survey-balance weights, [Ni/Fe] satisfies the pre-specified practical-equivalence criteria "
  "for both radial and vertical gradients. [Si/Fe] and [Ca/Fe] are transport-stable only in "
  "the vertical coordinate, while [Fe/H] and [Mg/Fe] remain indeterminate in both coordinates. "
  "No primary label is classified as footprint-sensitive or survey-sensitive."
 )
 results=(
  "The common-footprint analysis yields one fully transport-stable primary label. "
  "[Ni/Fe] satisfies the frozen practical-equivalence criterion in both the radial and vertical "
  "directions. [Si/Fe] and [Ca/Fe] satisfy the vertical criterion but remain indeterminate "
  "radially. [Fe/H] and [Mg/Fe] are indeterminate in both coordinates. Importantly, none of the "
  "five labels meets the pre-specified criterion for either footprint sensitivity or survey "
  "sensitivity. Thus, the four indeterminate classifications should not be interpreted as "
  "detections of instability: under the conservative frozen decision rules, the data establish "
  "neither full practical equivalence nor a contrast large enough to classify those labels as "
  "footprint- or survey-sensitive."
 )
 discussion=(
  "These results separate positive evidence of transport stability from a failure to establish "
  "equivalence. The [Ni/Fe] gradients are robust to both common-footprint restriction and "
  "outcome-blind survey balancing within the tested shared support. For [Fe/H], [Mg/Fe], "
  "[Si/Fe], and [Ca/Fe], the conservative equivalence intervals are too broad or otherwise fail "
  "the complete stability rule, but they also do not cross the pre-specified sensitivity "
  "criterion. The appropriate conclusion is therefore indeterminacy rather than transport "
  "failure. This analysis is conditional on the tested APOGEE--GALAH common support and is not "
  "a volume-complete, selection-function-corrected, causal, or independent-survey replication "
  "statement."
 )
 methods=(
  "For Stage-6D4, the frozen full-support Stage-4B gradients were compared with pooled, "
  "survey-balanced, and survey-interaction fits on the retained common footprint. The pooled "
  "model uses unity weights, whereas the balanced and interaction models use the D3C9 "
  "outcome-blind overlap weights. All new fits use the frozen Huber IRLS contract and 4096-draw "
  "antithetic Rademacher spatial-cluster multiplier inference over the retained primary-NSIDE16 "
  "HEALPix cells. Practical-equivalence margins are "
  "$\\max(0.005,0.25|\\beta_{R,\\rm full}|)$ for the radial slope and "
  "$\\max(0.030,0.25|\\beta_{Z,\\rm full}|)$ for the vertical slope. "
  "Cross-model contrast intervals are formed conservatively from marginal bootstrap quantiles, "
  "without assuming cross-model bootstrap independence."
 )
 for name,text in [("abstract_sentence",abstract),("results_paragraph",results),("discussion_paragraph",discussion),("methods_paragraph",methods)]:
  (out/f"text/stage6d5a_{name}.txt").write_text(text+"\n",encoding="utf-8")

 # LaTeX integration block.
 integration="\n\n".join([
  "% Stage-6D5A manuscript-ready insertion block",
  "% ABSTRACT/RESULT SUMMARY",
  abstract,
  "% METHODS",
  methods,
  "% RESULTS",
  results,
  "% DISCUSSION / LIMITATIONS",
  discussion
 ])
 (out/"latex/stage6d5a_manuscript_integration.tex").write_text(integration+"\n",encoding="utf-8")

 # Refined claim ledger.
 claim_rows=[]
 for _,r in cls.iterrows():
  lab=r["label"];disp=c["display_names"][lab];oc=r["overall_classification"]
  if oc=="TRANSPORT_STABLE":
   allowed=f"{disp} is transport-stable for both radial and vertical gradients within the tested balanced common support."
  else:
   pieces=[]
   if r["radial_classification"]=="TRANSPORT_STABLE":pieces.append("radial gradient transport-stable")
   if r["vertical_classification"]=="TRANSPORT_STABLE":pieces.append("vertical gradient transport-stable")
   stable_part=("; ".join(pieces)+". ") if pieces else ""
   allowed=(f"{disp}: {stable_part}overall classification is indeterminate; this is not evidence of footprint or survey sensitivity.")
  claim_rows.append({
   "label":lab,"classification":oc,"allowed_claim":allowed,
   "forbidden_interpretation":"Indeterminate must not be rewritten as unstable, non-transportable, footprint-sensitive, or survey-sensitive.",
   "global_forbidden_claims":" | ".join(c["forbidden_claims"])
  })
 pd.DataFrame(claim_rows).to_csv(out/"tables/stage6d5a_claim_ledger.csv",index=False)

 ready=bool(prereq and labels_ready and classes_ready and counts_ready and no_sensitive and stable_labels==["ni_fe"])
 val={
  "stage":c["stage"],"protocol_version":c["protocol_version"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
  "D4_SCIENCE_CLOSURE_PREREQUISITE_READY":prereq,
  "EXACT_FIVE_LABEL_CLASSIFICATION_READY":labels_ready,
  "CLASSIFICATION_ENUM_READY":classes_ready,
  "EXPECTED_FINAL_COUNTS_READY":counts_ready,
  "classification_counts":counts,
  "fully_transport_stable_labels":stable_labels,
  "radial_transport_stable_labels":radial_stable,
  "vertical_transport_stable_labels":vertical_stable,
  "indeterminate_labels":ind_labels,
  "NO_FOOTPRINT_SENSITIVE_LABEL":no_sensitive,
  "NO_SURVEY_SENSITIVE_LABEL":no_sensitive,
  "INDETERMINATE_NOT_RELABELED_AS_SENSITIVE":True,
  "CLAIM_BOUNDARIES_PRESERVED":True,
  "NO_SCIENCE_REFIT_PERFORMED":True,
  "MANUSCRIPT_READY_TABLE_CREATED":True,
  "MANUSCRIPT_READY_TEXT_CREATED":True,
  "STAGE6D5A_MANUSCRIPT_CLAIM_INTEGRATION_READY":ready,
  "STAGE6D5B_ARCHIVAL_RELEASE_READY":ready
 }
 wj(out/"validation/stage6d5a_validation.json",val)
 wj(out/"summaries/stage6d5a_summary.json",{
  "ready":ready,
  "headline":"Only [Ni/Fe] is fully transport-stable; no primary label is classified as footprint-sensitive or survey-sensitive.",
  "interpretation":"Four labels are indeterminate under the strict frozen equivalence rules; indeterminate is not evidence of instability.",
  "next_action":"Integrate these frozen claim-safe results into the current MNRAS manuscript and build the final archival/Zenodo release package." if ready else "Inspect failed Stage-6D5A integration gate."
 })

 manifest=[]
 for p in sorted(out.rglob("*")):
  if p.is_file() and "manifest" not in p.parts:
   manifest.append({"path":str(p.relative_to(root)).replace("\\","/"),"size_bytes":p.stat().st_size,"sha256":sha(p)})
 pd.DataFrame(manifest).to_csv(out/"manifest/stage6d5a_output_manifest_sha256.csv",index=False)

 print(json.dumps({"validation":val,"summary":json.loads((out/"summaries/stage6d5a_summary.json").read_text())},indent=2,ensure_ascii=False))
 return 0

if __name__=="__main__":raise SystemExit(main())
