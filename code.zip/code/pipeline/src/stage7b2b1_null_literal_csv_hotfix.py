from __future__ import annotations
import argparse
import subprocess
import sys
from pathlib import Path

TARGET = Path("src/stage7b2b_outcomeblind_predictive_gate_amendment.py")

OLD_SUMMARY = 'sm=pd.read_csv(root/c["stage7b2a_summary"])'
NEW_SUMMARY = 'sm=pd.read_csv(root/c["stage7b2a_summary"], keep_default_na=False, na_values=["", "NaN", "nan"])'

OLD_REPLICATES = 'rp=pd.read_csv(root/c["stage7b2a_replicates"])'
NEW_REPLICATES = 'rp=pd.read_csv(root/c["stage7b2a_replicates"], keep_default_na=False, na_values=["", "NaN", "nan"])'

def replace_exact(text: str, old: str, new: str, label: str) -> str:
    n = text.count(old)
    if n == 1:
        print(f"[B2B1] PATCHING {label}")
        return text.replace(old, new, 1)
    if new in text:
        print(f"[B2B1] {label} ALREADY PATCHED")
        return text
    raise RuntimeError(f"{label}: expected exact source line once; found {n}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    target = root / TARGET
    if not target.exists():
        raise FileNotFoundError(
            f"Stage-7B2B v0.33.0 source missing: {target}. "
            "Extract the original B2B package first."
        )

    text = target.read_text(encoding="utf-8")
    text = replace_exact(text, OLD_SUMMARY, NEW_SUMMARY, "summary CSV NULL-literal parser")
    text = replace_exact(text, OLD_REPLICATES, NEW_REPLICATES, "replicate CSV NULL-literal parser")
    target.write_text(text, encoding="utf-8")

    print("[B2B1] Re-running unchanged Stage-7B2B science/amendment logic...")
    proc = subprocess.run(
        [sys.executable, str(target), "--project-root", str(root)],
        cwd=str(root),
    )
    if proc.returncode != 0:
        return int(proc.returncode)

    validation = (
        root / "outputs" / "stage7b2b_outcomeblind_predictive_gate_amendment"
        / "validation" / "stage7b2b_validation.json"
    )
    if not validation.exists():
        raise RuntimeError("Stage-7B2B validation missing after hotfix rerun")

    print("[OK] Stage-7B2B1 NULL-literal CSV hotfix completed.")
    print(
        "Inspect outputs\\stage7b2b_outcomeblind_predictive_gate_amendment\\"
        "validation\\stage7b2b_validation.json"
    )
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
