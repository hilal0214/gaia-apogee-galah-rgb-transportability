from pathlib import Path
import argparse,json,hashlib,shutil
from datetime import datetime,timezone

def canon(o): 
    return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"protocol/stage7r2_radial_branch_closeout.json").read_text())
    p=json.loads((root/"protocol/stage8a_alpha_morphology_protocol.json").read_text())
    b2=json.loads((root/"outputs/stage7b2_full_signed_injection_recovery/validation/stage7b2_validation.json").read_text())
    r1=json.loads((root/"outputs/stage7r1_fixed_window_transition_power/validation/stage7r1_validation.json").read_text())
    guards=bool(
        b2.get("STAGE7B2_FORMAL_COMPLETE") and
        b2.get("FORMAL_STAGE7B2_POWER_CALIBRATION_PASS") is False and
        b2.get("STAGE7C_REAL_BREAK_FIT_AUTHORIZED") is False and
        b2.get("REAL_FEH_M1_BREAK_FIT_PERFORMED") is False and
        r1.get("STAGE7R1_FIXED_WINDOW_POWER_CALIBRATION_PASS") is False and
        r1.get("REAL_FIXED_WINDOW_TRANSITION_FIT_AUTHORIZED") is False and
        r1.get("REAL_FEH_FIXED_WINDOW_M1_FIT_PERFORMED") is False
    )
    if not guards: raise RuntimeError("Stage-7 radial closure guards failed")
    out=root/"outputs/stage7r2_closeout_stage8a_alpha_morphology_protocol"
    for d in ["freeze","validation"]: (out/d).mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/"protocol/stage7r2_radial_branch_closeout.json",out/"freeze/stage7r2_radial_branch_closeout_frozen.json")
    shutil.copy2(root/"protocol/stage8a_alpha_morphology_protocol.json",out/"freeze/stage8a_alpha_morphology_protocol_frozen.json")
    v={
      "stage":"Stage-7R2 closeout + Stage-8A alpha morphology protocol freeze",
      "implementation_version":"0.37.0",
      "timestamp_utc":datetime.now(timezone.utc).isoformat(),
      "RADIAL_BRANCH_CLOSURE_GUARDS_READY":guards,
      "RADIAL_BREAK_BRANCH_CLOSED_NOT_POWERED":True,
      "REAL_FEH_FREE_BREAK_M1_EVER_OPENED":False,
      "REAL_FEH_FIXED_WINDOW_M1_EVER_OPENED":False,
      "FROZEN_RADIAL_GATES_WEAKENED":False,
      "STAGE8A_ALPHA_MORPHOLOGY_PROTOCOL_FROZEN":True,
      "STAGE8A_PROTOCOL_CANONICAL_SHA256":canon(p),
      "STAGE8_REAL_MIXTURE_INTERPRETATION_AUTHORIZED":False,
      "STAGE8B_SYNTHETIC_POWER_PREFLIGHT_READY":True
    }
    (out/"validation/stage7r2_stage8a_validation.json").write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(v,indent=2))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
