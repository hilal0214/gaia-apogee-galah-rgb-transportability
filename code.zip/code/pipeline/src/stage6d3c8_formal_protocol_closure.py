from __future__ import annotations
import argparse,csv,hashlib,json,shutil
from datetime import datetime,timezone
from pathlib import Path
from typing import Any

def now(): return datetime.now(timezone.utc).isoformat()
def canonical_json_bytes(obj:Any)->bytes:
    return json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode("utf-8")
def sha256_bytes(data:bytes)->str: return hashlib.sha256(data).hexdigest()
def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()
def wjson(path:Path,obj:Any):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def wcsv(path:Path,fields,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("w",newline="",encoding="utf-8") as h:
        w=csv.DictWriter(h,fieldnames=fields,extrasaction="ignore");w.writeheader();w.writerows(rows)
def load_json(path:Path):
    if not path.exists(): raise FileNotFoundError(str(path))
    return json.loads(path.read_text(encoding="utf-8"))

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");args=ap.parse_args()
    root=Path(args.project_root).resolve()
    cfg=load_json(root/"config/stage6d3c8_config.json")
    out=root/cfg["output_dir"]
    if out.exists(): shutil.rmtree(out)
    for d in ["validation","freeze","tables","summaries","reports","manifest"]:
        (out/d).mkdir(parents=True,exist_ok=True)

    paths={k:root/cfg[k] for k in ["d3a_validation","d3a_frozen_protocol","d3c4_validation","d3c5_validation","d3c7_validation","d3c7a_validation"]}
    d3av=load_json(paths["d3a_validation"]); d3ap=load_json(paths["d3a_frozen_protocol"])
    d3c4=load_json(paths["d3c4_validation"]); d3c5=load_json(paths["d3c5_validation"])
    d3c7=load_json(paths["d3c7_validation"]); d3c7a=load_json(paths["d3c7a_validation"])

    certified_margin=d3c7a.get("maximum_certified_interior_margin")
    prereq={
        "D3A_CANONICAL_PROTOCOL_IDENTITY_READY":
            d3av.get("frozen_protocol_canonical_sha256")==cfg["expected_d3a_canonical_sha256"],
        "D3C4_IMPLEMENTATION_RECONCILIATION_READY":
            bool(d3c4.get("STAGE6D3C4_RECONCILIATION_READY",False)
                 and d3c4.get("CELL_FIXED_EFFECTS_RESTORED",False)
                 and d3c4.get("P99_CAP_WITHIN_SURVEY_RESTORED",False)),
        "D3C5_OUTCOME_BLIND_RIDGE_PATH_READY":
            bool(d3c5.get("STAGE6D3C5_RIDGE_PATH_READY",False)
                 and d3c5.get("RIDGE_C_PATH_OUTCOME_BLIND",False)
                 and float(d3c5.get("standard_overlap_prior_arithmetic_first_propensity_passing_C",-1))==float(cfg["fixed_ridge_C"])),
        "D3C7_NUMERIC_FEASIBILITY_READY":
            bool(d3c7.get("ALL_FROZEN_NUMERIC_GATES_PASS_DIAGNOSTICALLY",False)
                 and d3c7.get("PROPENSITY_GATE_READY",False)
                 and d3c7.get("MAX_ABS_SMD_LE_0P10_READY",False)
                 and d3c7.get("ESS_RAW_GE_0P35_READY",False)),
        "D3C7A_ROBUST_INTERIOR_CERTIFICATION_READY":
            bool(d3c7a.get("classification")=="ROBUST_INTERIOR_NUMERIC_FEASIBILITY"
                 and d3c7a.get("candidate_metrics_reproduced_to_1e_10",False)
                 and d3c7a.get("CELL_ID_LOOKUP_COMPLETE",False)
                 and certified_margin is not None
                 and float(certified_margin)>=float(cfg["minimum_required_certified_margin"]))
    }
    all_ready=all(prereq.values())

    frozen={
        "stage":cfg["stage"],
        "protocol_version":cfg["protocol_version"],
        "amendment_status":"POST_FREEZE_OUTCOME_BLIND_METHOD_AMENDMENT",
        "original_d3a_canonical_sha256":cfg["expected_d3a_canonical_sha256"],
        "lineage_hashes":{
            k:sha256_file(v) for k,v in paths.items()
        },
        "common_footprint_source":cfg["common_footprint_source"],
        "unchanged_d3a_contract":[
            "primary Galactic HEALPix NSIDE16 RING footprint",
            "NSIDE8/32 sensitivity archive",
            "minimum 25 per survey per cell before trim",
            "q05-q95 support intersection",
            "minimum 15 per survey per cell after trim",
            "original numeric gates",
            "forbidden abundance/R/abs_Z/residual/outcome/latent matching"
        ],
        "balance_covariates":cfg["balance_features"],
        "propensity":{
            "estimand":"Pr(GALAH_CORRECTED|X,HEALPix cell)",
            "model":"ridge logistic regression",
            "ridge_C":cfg["fixed_ridge_C"],
            "continuous_standardization":"training-fold only",
            "cell_fixed_effect_field":cfg["cell_field"],
            "crossfit_folds":cfg["n_folds"],
            "fold_assignment":"SHA256(source_id) mod 5",
            "acceptance_gate":[0.05,0.95],
            "propensity_trimming":"none when the full OOF range passes the gate"
        },
        "overlap_weights":{
            "semantic_definition":"STANDARD_OVERLAP_SEMANTICS",
            "APOGEE_NATIVE":"p_GALAH",
            "GALAH_CORRECTED":"1-p_GALAH",
            "p99_cap_scope":"separately within survey",
            "p99_quantile":0.99,
            "amendment_note":"resolves the D3A wording/formula inconsistency for GALAH coded as 1"
        },
        "cell_target_calibration":{
            "equal_survey_total_per_cell":True,
            "baseline_target":"arithmetic mean of capped APOGEE and GALAH totals in the cell",
            "objective":"positive minimum-KL displacement from baseline targets",
            "total_target_mass_preserved":True,
            "target_ratio_bounds":[cfg["optimizer"]["target_ratio_lower_bound"],cfg["optimizer"]["target_ratio_upper_bound"]],
            "solver":cfg["optimizer"],
            "deterministic_margin_path":cfg["margin_path"],
            "production_internal_margin":cfg["production_internal_margin"],
            "production_internal_gates":cfg["production_internal_gates"],
            "original_acceptance_gates_unchanged":cfg["frozen_numeric_gates"]
        },
        "amendment_transparency":{
            "ridge_C_status":"post-freeze outcome-blind tuning amendment; not an original D3A pre-specification",
            "ridge_C_selection":"first/largest C on the corrected prespecified D3C5 ridge path restoring the propensity gate in the focus branch",
            "science_outcomes_used_for_selection":False,
            "internal_margin_status":"delta=0.001 was predeclared as the robustness reference before D3C7A results",
            "certified_maximum_margin":certified_margin,
            "why_not_use_maximum_margin":"avoid post-hoc selection of the largest observed feasible margin"
        },
        "target_concentration":{
            "status":"descriptive audit only; no post-hoc gate added",
            "certification_snapshot":d3c7a.get("target_concentration",{})
        },
        "production_replay_requirements":[
            "recompute five-fold cell-fixed-effect propensity from the frozen D3B1 source",
            "recompute standard overlap weights and within-survey p99 caps",
            "recompute arithmetic baseline cell targets",
            "solve the deterministic positive constrained KL margin path through delta=0.001",
            "independently recompute final row-level SMD and ESS",
            "verify exact equal survey total weight per cell",
            "archive folds, model coefficients, propensities, caps, cell targets, final weights, diagnostics and SHA256 manifest"
        ],
        "claim_boundary":[
            "balanced analysis is not volume-complete",
            "GALAH is not an independent replication sample after balancing",
            "no causal footprint-removal claim",
            "no abundance-target matching",
            "no component-resolved claim from balancing alone"
        ]
    }

    canonical=canonical_json_bytes(frozen); protocol_sha=sha256_bytes(canonical)
    wjson(out/"freeze/stage6d3c8_amended_balance_protocol.json",frozen)
    (out/"freeze/stage6d3c8_amended_balance_protocol_canonical.json").write_bytes(canonical+b"\n")

    ledger=[
        {"item":"propensity model","original_or_prior_state":"D3A required cell fixed effects; D3C v0.20.0 omitted them","amended_frozen_state":"ridge logistic + NSIDE16 cell fixed effects","reason":"restore authoritative D3A contract"},
        {"item":"ridge C","original_or_prior_state":"no exact C frozen in D3A","amended_frozen_state":"C=0.0002","reason":"outcome-blind corrected D3C5 ridge path"},
        {"item":"overlap formula","original_or_prior_state":"D3A wording/formula inconsistent","amended_frozen_state":"APOGEE=p_GALAH; GALAH=1-p_GALAH","reason":"standard overlap semantics"},
        {"item":"p99 cap","original_or_prior_state":"D3A within-survey; D3C v0.20.0 global","amended_frozen_state":"p99 separately within survey","reason":"restore D3A scope"},
        {"item":"cell target","original_or_prior_state":"equal totals/cell frozen; common target unspecified","amended_frozen_state":"positive minimum-KL target from arithmetic baseline","reason":"D3C7 feasibility plus D3C7A robustness"},
        {"item":"production safety margin","original_or_prior_state":"acceptance floor SMD<=0.10, ESS/raw>=0.35","amended_frozen_state":"internal target SMD<=0.099, ESS/raw>=0.351","reason":"predeclared delta=0.001 robustness reference"}
    ]
    wcsv(out/"tables/stage6d3c8_amendment_ledger.csv",["item","original_or_prior_state","amended_frozen_state","reason"],ledger)

    validation={
        "stage":cfg["stage"],"protocol_version":cfg["protocol_version"],"implementation_version":cfg["implementation_version"],"timestamp_utc":now(),
        "amended_protocol_canonical_sha256":protocol_sha,
        "original_d3a_canonical_sha256":cfg["expected_d3a_canonical_sha256"],
        "certified_maximum_interior_margin":certified_margin,
        "frozen_production_internal_margin":cfg["production_internal_margin"],
        "prerequisites":prereq,
        "D3C8_ALL_PREREQUISITES_READY":all_ready,
        "POST_FREEZE_AMENDMENT_EXPLICITLY_DECLARED":True,
        "OUTCOME_BLIND_AMENDMENT_READY":True,
        "RIDGE_C_0P0002_FROZEN":True,
        "CELL_FIXED_EFFECT_PROPENSITY_FROZEN":True,
        "STANDARD_OVERLAP_SEMANTICS_FROZEN":True,
        "WITHIN_SURVEY_P99_FROZEN":True,
        "POSITIVE_MIN_KL_CELL_TARGET_RULE_FROZEN":True,
        "INTERNAL_DELTA_0P001_MARGIN_FROZEN":True,
        "ORIGINAL_NUMERIC_GATES_NOT_WEAKENED":True,
        "TARGET_CONCENTRATION_REMAINS_DESCRIPTIVE_ONLY":True,
        "NO_OUTCOME_ABUNDANCE_R_ABSZ_USED":True,
        "D3C8_FORMAL_PROTOCOL_CLOSURE_READY":all_ready,
        "D3C9_PRODUCTION_BALANCING_RERUN_READY":all_ready,
        "PRODUCTION_BALANCED_WEIGHTS_READY":False,
        "STAGE6D4_SCIENCE_MODELS_READY":False
    }
    wjson(out/"validation/stage6d3c8_validation.json",validation)
    summary={
        "stage":cfg["stage"],
        "amended_protocol_canonical_sha256":protocol_sha,
        "scientific_disposition":"The corrected balancing design is formally closed as an explicit post-freeze, outcome-blind amendment. One clean production replay is required before Stage-6D4.",
        "next_action":"Run Stage-6D3C9 exact production balancing replay from the frozen D3B1 common-footprint source using this canonical amended protocol hash."
    }
    wjson(out/"summaries/stage6d3c8_summary.json",summary)
    (out/"reports/stage6d3c8_protocol_closure.md").write_text(
        f"# Stage-6D3C8 formal protocol closure\n\nCanonical amended protocol SHA-256: `{protocol_sha}`\n\n"
        f"Production internal margin: `{cfg['production_internal_margin']}`\n"
        f"Production target max |SMD| <= `{cfg['production_internal_gates']['maximum_absolute_smd']}`\n"
        f"Production target ESS/raw >= `{cfg['production_internal_gates']['minimum_ess_raw_ratio']}`\n\n"
        f"D3C9 production replay ready: `{all_ready}`\nStage-6D4 ready: `False`\n",
        encoding="utf-8"
    )
    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and "manifest" not in p.parts:
            manifest.append({"path":str(p.relative_to(root)).replace("\\","/"),"size_bytes":p.stat().st_size,"sha256":sha256_file(p)})
    wcsv(out/"manifest/stage6d3c8_output_manifest_sha256.csv",["path","size_bytes","sha256"],manifest)
    print(json.dumps({"validation":validation,"summary":summary},indent=2,ensure_ascii=False))
    return 0

if __name__=="__main__": raise SystemExit(main())
