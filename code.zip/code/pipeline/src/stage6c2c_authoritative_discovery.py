from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

STAGE = "Stage-6C2C authoritative production-asset discovery and gap classification"
PROTOCOL_VERSION = "1.0.0"
IMPLEMENTATION_VERSION = "0.15.2"

ALIASES = {
    "stage": ["stage", "selection_stage", "criterion", "gate", "filter_stage", "step"],
    "apogee": ["apogee", "n_apogee", "apogee_count", "apogee_rows"],
    "galah": ["galah", "n_galah", "galah_count", "galah_rows"],
    "label": ["label", "element", "quantity", "abundance", "chemical_label"],
    "n_common": ["n_common", "n_overlap", "matched_count", "common_count", "pair_count"],
    "residual_mad": ["residual_mad", "corrected_mad", "post_mad", "mad_after", "residual_scale"],
    "population": ["population", "component", "class", "population_label", "component_name"],
    "n": ["n", "count", "n_stars", "assigned_n", "member_count", "rows"],
    "secure_fraction": ["secure_fraction", "secure_frac", "fraction_secure", "pmax_fraction"],
    "secure_n": ["secure_n", "secure_count", "n_secure"],
    "sample": ["sample", "subset", "survey", "view", "cohort", "analysis_view", "survey_origin"],
    "beta_r": ["beta_r", "b_r", "radial_gradient", "radial_slope", "gradient_r"],
    "beta_z": ["beta_z", "b_z", "vertical_gradient", "vertical_slope", "gradient_z"],
    "feh": ["fe_h", "feh", "metallicity", "fe_h_hom", "fe_h_cal"],
    "alpha": ["alpha_fe", "alpha", "alpha_m", "mg_fe"],
    "abs_z": ["abs_z", "z_abs", "galcen_abs_z", "abs_z_kpc"],
    "vphi": ["vphi", "v_phi", "vphi_disk", "v_phi_disk"],
}

ASSETS = {
    "T01": {
        "title": "Spectroscopic sample flow",
        "required": ["stage", "apogee", "galah"],
        "preferred_stage": ["stage1"],
        "derivable_inputs": ["catalogue_ingest_summary", "census"]
    },
    "T02": {
        "title": "APOGEE--GALAH common-star calibration",
        "required": ["label", "n_common", "residual_mad"],
        "preferred_stage": ["stage2b", "stage2c"],
        "derivable_inputs": ["calibration_coefficients", "crossfit_metrics", "crossfit_fold_metrics"]
    },
    "T03": {
        "title": "Global bootstrap-tested gradients",
        "required": ["label", "beta_r", "beta_z"],
        "preferred_stage": ["stage4b"],
        "derivable_inputs": ["global_gradient_estimates", "bootstrap_draws"]
    },
    "T04": {
        "title": "Probabilistic population summary",
        "required": ["population", "n"],
        "required_any": ["secure_fraction", "secure_n"],
        "preferred_stage": ["stage5a", "stage5b"],
        "derivable_inputs": ["responsibility_summary", "assignments", "responsibilities"]
    },
    "T05": {
        "title": "Population-resolved gradients",
        "required": ["population", "label", "beta_r", "beta_z"],
        "preferred_stage": ["stage5a", "stage5b", "stage4b"],
        "derivable_inputs": ["analysis_design_layer", "population_assignments", "global_gradient"]
    },
    "T06": {
        "title": "Survey-subset robustness",
        "required": ["sample", "label", "beta_r", "beta_z"],
        "preferred_stage": ["stage4b", "stage5b"],
        "derivable_inputs": ["analysis_design_layer", "global_gradient"]
    }
}

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def norm(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).lower()).strip("_")

def safe_rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(path)
    return value

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def write_csv(path: Path, fields: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

def scalar(value: Any) -> bool:
    return value is None or isinstance(value, (str, int, float, bool))

def json_frames(value: Any, location: str = "$") -> list[tuple[str, pd.DataFrame]]:
    frames: list[tuple[str, pd.DataFrame]] = []

    if isinstance(value, list):
        if value and all(isinstance(x, dict) for x in value):
            try:
                frame = pd.json_normalize(value)
                if not frame.empty:
                    frames.append((location, frame))
            except Exception:
                pass
        for index, child in enumerate(value[:100]):
            if isinstance(child, (dict, list)):
                frames.extend(json_frames(child, f"{location}[{index}]"))
        return frames

    if not isinstance(value, dict):
        return frames

    scalar_items = {k: v for k, v in value.items() if scalar(v)}
    if scalar_items:
        frames.append((location + ".__scalars__", pd.DataFrame([scalar_items])))

    child_dicts = {k: v for k, v in value.items() if isinstance(v, dict)}
    if child_dicts and all(all(scalar(x) for x in child.values()) for child in child_dicts.values()):
        rows = []
        for key, child in child_dicts.items():
            row = {"record_key": key}
            row.update(child)
            rows.append(row)
        frames.append((location + ".__dict_records__", pd.DataFrame(rows)))

    child_lists = {k: v for k, v in value.items() if isinstance(v, list)}
    if child_lists:
        lengths = {len(v) for v in child_lists.values()}
        if len(lengths) == 1 and next(iter(lengths), 0) > 0:
            if all(all(scalar(x) for x in vals) for vals in child_lists.values()):
                frames.append((location + ".__column_arrays__", pd.DataFrame(child_lists)))

    for key, child in value.items():
        if isinstance(child, (dict, list)):
            frames.extend(json_frames(child, f"{location}.{key}"))

    seen = set()
    unique = []
    for subpath, frame in frames:
        signature = (subpath, tuple(norm(c) for c in frame.columns), len(frame))
        if signature not in seen and len(frame.columns):
            seen.add(signature)
            unique.append((subpath, frame))
    return unique

def file_frames(path: Path) -> list[tuple[str, pd.DataFrame]]:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return [("$", pd.read_csv(path))]
    if suffix == ".tsv":
        return [("$", pd.read_csv(path, sep="\t"))]
    if suffix == ".parquet":
        return [("$", pd.read_parquet(path))]
    if suffix == ".json":
        return json_frames(json.loads(path.read_text(encoding="utf-8")))
    return []

def find_col(frame: pd.DataFrame, key: str) -> str | None:
    columns = [(str(c), norm(c)) for c in frame.columns]
    for alias in ALIASES[key]:
        target = norm(alias)
        for original, candidate in columns:
            if candidate == target or candidate.endswith("_" + target) or target in candidate:
                return original
    return None

def role_for_name(rel: str, non_authoritative_tokens: list[str]) -> str:
    low = rel.lower()
    if any(token in low for token in non_authoritative_tokens):
        return "NON_AUTHORITATIVE_CONTROL_OR_AUDIT"
    if any(token in low for token in ["summary", "estimates", "metrics", "coefficients", "parameters", "responsibility"]):
        return "POSSIBLE_PRODUCTION_SUMMARY"
    if any(token in low for token in ["assignments", "predictions", "draws", "atlas", "layer"]):
        return "POSSIBLE_ROW_LEVEL_OR_DRAW_PRODUCT"
    return "UNCLASSIFIED_MACHINE_READABLE"

def stage_name(rel: str) -> str:
    match = re.search(r"(stage\d+[a-z]?)", rel.lower())
    return match.group(1).upper() if match else "UNKNOWN"

def frame_match(frame: pd.DataFrame, asset: dict[str, Any]) -> tuple[bool, list[str], list[str]]:
    matches = []
    missing = []
    for key in asset["required"]:
        col = find_col(frame, key)
        if col:
            matches.append(f"{key}:{col}")
        else:
            missing.append(key)
    if asset.get("required_any"):
        found_any = []
        for key in asset["required_any"]:
            col = find_col(frame, key)
            if col:
                found_any.append(f"{key}:{col}")
        if found_any:
            matches.extend(found_any)
        else:
            missing.append("any(" + ",".join(asset["required_any"]) + ")")
    return not missing, matches, missing

def main() -> int:
    parser = argparse.ArgumentParser(description=STAGE)
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = read_json(root / "config/stage6c2c_config.json")
    out_dir = root / cfg["output_dir"]
    if out_dir.exists():
        shutil.rmtree(out_dir)
    for name in ["validation", "summaries", "tables", "reports"]:
        (out_dir / name).mkdir(parents=True, exist_ok=True)

    suffixes = {x.lower() for x in cfg["scan_suffixes"]}
    files: list[Path] = []
    for rel_dir in cfg["scan_stage_dirs"]:
        directory = root / rel_dir
        if not directory.exists():
            continue
        for path in directory.rglob("*"):
            if path.is_file() and path.suffix.lower() in suffixes:
                files.append(path)
    files = sorted(set(files))

    file_rows = []
    frame_rows = []
    internal_frames: list[dict[str, Any]] = []

    for path in files:
        rel = safe_rel(path, root)
        role = role_for_name(rel, cfg["non_authoritative_tokens"])
        file_rows.append({
            "path": rel,
            "stage": stage_name(rel),
            "suffix": path.suffix.lower(),
            "size_bytes": path.stat().st_size,
            "filename_role": role,
            "sha256": sha256_file(path)
        })
        try:
            frames = file_frames(path)
        except Exception as exc:
            frame_rows.append({
                "path": rel, "stage": stage_name(rel), "filename_role": role,
                "subpath": "", "n_rows": "", "n_columns": "", "columns": "",
                "load_error": f"{type(exc).__name__}: {exc}"
            })
            continue
        for index, (subpath, frame) in enumerate(frames):
            row = {
                "path": rel,
                "stage": stage_name(rel),
                "filename_role": role,
                "subpath": subpath,
                "frame_index": index,
                "n_rows": len(frame),
                "n_columns": len(frame.columns),
                "columns": "|".join(str(c) for c in frame.columns),
                "load_error": ""
            }
            frame_rows.append(row)
            internal_frames.append({**row, "_frame": frame})

    write_csv(
        out_dir / "tables/stage6c2c_file_inventory.csv",
        ["path", "stage", "suffix", "size_bytes", "filename_role", "sha256"],
        file_rows
    )
    write_csv(
        out_dir / "tables/stage6c2c_frame_inventory.csv",
        ["path", "stage", "filename_role", "subpath", "frame_index", "n_rows", "n_columns", "columns", "load_error"],
        frame_rows
    )

    probe_rows = []
    for rel in cfg["expected_relative_files"]:
        path = root / rel
        probe_rows.append({
            "expected_path": rel,
            "exists": str(path.exists()).lower(),
            "size_bytes": path.stat().st_size if path.exists() else "",
            "sha256": sha256_file(path) if path.exists() else ""
        })
    write_csv(
        out_dir / "tables/stage6c2c_expected_file_probe.csv",
        ["expected_path", "exists", "size_bytes", "sha256"],
        probe_rows
    )

    schema_matches = []
    exact_candidates = []
    classifications = {}

    for asset_id, asset in ASSETS.items():
        matches_for_asset = []
        for profile in internal_frames:
            frame = profile["_frame"]
            ok, matched, missing = frame_match(frame, asset)
            row = {
                "asset_id": asset_id,
                "asset_title": asset["title"],
                "path": profile["path"],
                "stage": profile["stage"],
                "filename_role": profile["filename_role"],
                "subpath": profile["subpath"],
                "n_rows": profile["n_rows"],
                "columns": profile["columns"],
                "schema_match": str(ok).lower(),
                "matched_columns": ";".join(matched),
                "missing_requirements": ";".join(missing)
            }
            if ok:
                schema_matches.append(row)
                if profile["filename_role"] != "NON_AUTHORITATIVE_CONTROL_OR_AUDIT":
                    preferred = any(
                        token.lower() in profile["stage"].lower() or token.lower() in profile["path"].lower()
                        for token in asset["preferred_stage"]
                    )
                    candidate = {**row, "preferred_stage_match": str(preferred).lower()}
                    matches_for_asset.append(candidate)

        matches_for_asset.sort(
            key=lambda row: (
                row["preferred_stage_match"] != "true",
                -int(row["n_rows"]),
                row["path"],
                row["subpath"]
            )
        )
        if matches_for_asset:
            best = matches_for_asset[0]
            exact_candidates.append(best)
            classifications[asset_id] = {
                "classification": "AUTHORITATIVE_CANDIDATE_FOUND",
                "source": best["path"] + "::" + best["subpath"],
                "reason": "Production-role file with the required schema."
            }
            continue

        # Derivability is based on filename evidence only and must be confirmed later.
        available_names = " ".join(row["path"].lower() for row in file_rows)
        tokens = asset["derivable_inputs"]
        hits = [token for token in tokens if token.lower() in available_names]
        if hits:
            classifications[asset_id] = {
                "classification": "DERIVABLE_FROM_FROZEN_PRODUCTS",
                "source": "",
                "reason": "Matching frozen input families found: " + ", ".join(hits)
            }
        else:
            classifications[asset_id] = {
                "classification": "MISSING_PRODUCTION_PRODUCT",
                "source": "",
                "reason": "No production schema match and no expected frozen input family found."
            }

    write_csv(
        out_dir / "tables/stage6c2c_asset_schema_matches.csv",
        ["asset_id", "asset_title", "path", "stage", "filename_role", "subpath",
         "n_rows", "columns", "schema_match", "matched_columns", "missing_requirements"],
        schema_matches
    )
    write_csv(
        out_dir / "tables/stage6c2c_exact_candidates.csv",
        ["asset_id", "asset_title", "path", "stage", "filename_role", "subpath",
         "n_rows", "columns", "schema_match", "matched_columns", "missing_requirements",
         "preferred_stage_match"],
        exact_candidates
    )

    unresolved_rows = []
    for asset_id, asset in ASSETS.items():
        info = classifications[asset_id]
        if info["classification"] != "AUTHORITATIVE_CANDIDATE_FOUND":
            unresolved_rows.append({
                "asset_id": asset_id,
                "title": asset["title"],
                **info
            })
    write_csv(
        out_dir / "tables/stage6c2c_unresolved_assets.csv",
        ["asset_id", "title", "classification", "source", "reason"],
        unresolved_rows
    )

    report = [
        "# Stage-6C2C authoritative production-asset discovery",
        "",
        f"Generated: {utc_now()}",
        "",
        "## Asset classification",
        ""
    ]
    for asset_id, asset in ASSETS.items():
        info = classifications[asset_id]
        report += [
            f"### {asset_id} — {asset['title']}",
            f"- Classification: `{info['classification']}`",
            f"- Source: `{info['source'] or 'none'}`",
            f"- Reason: {info['reason']}",
            ""
        ]
    report += [
        "## Interpretation rule",
        "",
        "Validation reports, design contracts, claim ledgers, manifests, sensitivity ladders, and audit-only files are never promoted to authoritative manuscript tables.",
        "",
        "A `DERIVABLE_FROM_FROZEN_PRODUCTS` classification authorizes a versioned closure computation only after the exact input set and frozen method are recorded.",
        ""
    ]
    (out_dir / "reports/stage6c2c_authoritative_discovery.md").write_text(
        "\n".join(report), encoding="utf-8"
    )

    counts = {}
    for info in classifications.values():
        counts[info["classification"]] = counts.get(info["classification"], 0) + 1

    validation = {
        "stage": STAGE,
        "protocol_version": PROTOCOL_VERSION,
        "implementation_version": IMPLEMENTATION_VERSION,
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "scanned_machine_readable_file_count": len(files),
        "enumerated_frame_count": len(internal_frames),
        "frame_load_error_count": sum(bool(row["load_error"]) for row in frame_rows),
        "authoritative_candidate_count": counts.get("AUTHORITATIVE_CANDIDATE_FOUND", 0),
        "derivable_asset_count": counts.get("DERIVABLE_FROM_FROZEN_PRODUCTS", 0),
        "missing_production_product_count": counts.get("MISSING_PRODUCTION_PRODUCT", 0),
        "prior_stage_outputs_modified": False,
        "DISCOVERY_COMPLETED": True,
        "ALL_MANUSCRIPT_ASSETS_DIRECTLY_LINKED": counts.get("AUTHORITATIVE_CANDIDATE_FOUND", 0) == 6,
        "CLOSURE_COMPUTATION_REQUIRED": counts.get("DERIVABLE_FROM_FROZEN_PRODUCTS", 0) > 0,
        "NEW_PRODUCTION_STAGE_REQUIRED": counts.get("MISSING_PRODUCTION_PRODUCT", 0) > 0
    }
    write_json(out_dir / "validation/stage6c2c_validation.json", validation)

    summary = {
        "stage": STAGE,
        "timestamp_utc": utc_now(),
        "classifications": classifications,
        "scientific_disposition": (
            "Discovery complete. Use direct candidates where present; create only claim-bounded closure computations for derivable assets; do not fabricate missing products from validation or design files."
        )
    }
    write_json(out_dir / "summaries/stage6c2c_summary.json", summary)

    print(json.dumps({"validation": validation, "summary": summary}, indent=2, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
