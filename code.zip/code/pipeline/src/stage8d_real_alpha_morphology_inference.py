from __future__ import annotations
import argparse, importlib.util, json, hashlib, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd

G=None
CFG=None
ENG=None

def now(): return datetime.now(timezone.utc).isoformat()

def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()

def as_bool(s):
    if pd.api.types.is_bool_dtype(s.dtype): return s.to_numpy(bool)
    return s.astype(str).str.strip().str.lower().isin(["true","1","yes","y"]).to_numpy(bool)

def ess(w):
    w=np.asarray(w,float); s=float(w.sum()); ss=float(np.square(w).sum())
    return s*s/ss if ss>0 else 0.0

def load_engine(path):
    spec=importlib.util.spec_from_file_location("stage8b2a_engine",path)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    if not hasattr(m,"em2") or not hasattr(m,"valley_from_fit"):
        raise RuntimeError("calibrated engine API missing em2/valley_from_fit")
    return m

def fit_metrics(y,w,eng):
    f=eng.em2(y,w)
    if f is None: return None
    return {
      "mu_low":float(f[0]),"mu_high":float(f[1]),
      "sigma_low":float(f[2]),"sigma_high":float(f[3]),
      "fraction":float(f[4]),
      "separation":float(f[1]-f[0]),
      "valley":float(eng.valley_from_fit(f))
    }

def init_worker(arrays,cfg,engine_path):
    global G,CFG,ENG
    G=arrays; CFG=cfg; ENG=load_engine(engine_path)

def one_bootstrap(draw):
    cells=G["unique_cells"]
    rng=np.random.Generator(np.random.PCG64DXSM(int(CFG["bootstrap"]["seed"])+int(draw)))
    sampled=rng.choice(cells,size=len(cells),replace=True)
    u,cnt=np.unique(sampled,return_counts=True)
    mult=dict(zip([int(x) for x in u],[int(x) for x in cnt]))
    cell_mult=np.array([mult.get(int(c),0) for c in G["cell"]],dtype=float)

    rec={"draw":int(draw),"fit_ok":True}
    for knot in CFG["primary_knots"]:
        km=np.abs(G["feh"]-float(knot))<=float(CFG["knot_halfwidth"])
        vals={}
        for s in CFG["survey_values"]:
            q=km&(G["survey"]==s)&(cell_mult>0)
            ww=G["weight"][q]*cell_mult[q]
            m=fit_metrics(G["alpha"][q],ww,ENG)
            if m is None:
                rec["fit_ok"]=False
                for e in ["valley","separation","fraction"]:
                    rec[f"k{knot:+.1f}_{e}_diff"]=None
                break
            vals[s]=m
        if not rec["fit_ok"]:
            continue
        for e in ["valley","separation","fraction"]:
            rec[f"k{knot:+.1f}_{e}_diff"]=float(vals["GALAH_CORRECTED"][e]-vals["APOGEE_NATIVE"][e])
    return rec

def classify_estimand(knot_rows,margin,stable_min,sensitive_adj):
    # knot_rows sorted by knot, each has ci_low/ci_high/valid_fraction
    usable=[r["valid_fraction"]>=0.95 and np.isfinite(r["ci_low"]) and np.isfinite(r["ci_high"]) for r in knot_rows]
    stable_flags=[u and (r["ci_low"]>-margin) and (r["ci_high"]<margin) for u,r in zip(usable,knot_rows)]
    pos=[u and r["ci_low"]>margin for u,r in zip(usable,knot_rows)]
    neg=[u and r["ci_high"]<-margin for u,r in zip(usable,knot_rows)]

    def maxrun(x):
        best=cur=0
        for q in x:
            cur=cur+1 if q else 0
            best=max(best,cur)
        return best

    sensitive=max(maxrun(pos),maxrun(neg))>=sensitive_adj
    stable=(sum(stable_flags)>=stable_min) and not sensitive
    if sensitive: cls="SURVEY_SENSITIVE"
    elif stable: cls="TRANSPORT_STABLE"
    else: cls="INDETERMINATE"
    return cls,stable_flags,pos,neg,max(maxrun(pos),maxrun(neg))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",default=".")
    ap.add_argument("--workers",type=int,default=None)
    a=ap.parse_args()
    root=Path(a.project_root).resolve()
    C=json.loads((root/"config/stage8d_config.json").read_text(encoding="utf-8"))
    pv=json.loads((root/C["parent_validation"]).read_text(encoding="utf-8"))
    parent_ready=bool(
      pv.get("STAGE8C_REAL_INFERENCE_PROTOCOL_FROZEN") is True and
      pv.get("STAGE8D_REAL_ALPHA_MORPHOLOGY_INFERENCE_READY") is True and
      pv.get("POST_REAL_FIT_GATE_CHANGES_FORBIDDEN") is True and
      pv.get("REAL_DATA_ROW_VALUES_READ_BY_STAGE8C") is False and
      pv.get("PROTOCOL_CANONICAL_SHA256")==C["expected_parent_protocol_sha256"]
    )
    if not parent_ready: raise RuntimeError("Stage-8C parent identity failed")

    eng_path=root/C["calibrated_engine_module"]
    eng=load_engine(eng_path)

    cc=C["columns"]
    cols=[cc[x] for x in ["source_id","survey","R","absZ","fe_h","alpha3","alpha3_flag","feh_flag","cell","weight"]]
    src=root/C["source"]
    df=pd.read_parquet(src,columns=cols)
    if pd.api.types.is_float_dtype(df[cc["source_id"]].dtype):
        raise RuntimeError("source_id float coercion forbidden")

    R=pd.to_numeric(df[cc["R"]],errors="coerce").to_numpy(float)
    Z=pd.to_numeric(df[cc["absZ"]],errors="coerce").to_numpy(float)
    feh=pd.to_numeric(df[cc["fe_h"]],errors="coerce").to_numpy(float)
    alpha=pd.to_numeric(df[cc["alpha3"]],errors="coerce").to_numpy(float)
    w=pd.to_numeric(df[cc["weight"]],errors="coerce").to_numpy(float)
    cell=pd.to_numeric(df[cc["cell"]],errors="raise").to_numpy(np.int64)
    survey=df[cc["survey"]].astype(str).to_numpy()
    af=as_bool(df[cc["alpha3_flag"]]); ff=as_bool(df[cc["feh_flag"]])
    d=C["domain"]

    base=(np.isfinite(R)&np.isfinite(Z)&np.isfinite(feh)&np.isfinite(w)&(w>0)&ff&
          (R>=d["R_min"])&(R<=d["R_max"])&(Z>=d["absZ_min"])&(Z<=d["absZ_max"])&
          (feh>=d["feh_min"])&(feh<=d["feh_max"]))
    eligible=base&af&np.isfinite(alpha)

    # Mandatory eligibility audit before fitting.
    audit=[]
    for knot in C["primary_knots"]:
        km=np.abs(feh-float(knot))<=float(C["knot_halfwidth"])
        for s in C["survey_values"]:
            den=base&km&(survey==s)
            num=eligible&km&(survey==s)
            audit.append({
              "feh_knot":float(knot),"survey":s,
              "pre_alpha_denominator_rows":int(den.sum()),
              "alpha_primary_eligible_rows":int(num.sum()),
              "eligibility_fraction":float(num.sum()/den.sum()) if den.sum() else np.nan,
              "weighted_ess":ess(w[num]),
              "nside16_cells":int(np.unique(cell[num]).size),
              "weight_sum":float(w[num].sum())
            })
    audit_df=pd.DataFrame(audit)

    m=eligible
    arrays={
      "feh":feh[m],"alpha":alpha[m],"weight":w[m],
      "cell":cell[m],"survey":survey[m],
      "unique_cells":np.unique(cell[m])
    }
    if len(arrays["unique_cells"])<100:
        raise RuntimeError("primary NSIDE16 block gate failed in production sample")

    # Point fits: this is the first real morphology fit.
    point=[]
    technical_fail=False
    for knot in C["primary_knots"]:
        km=np.abs(arrays["feh"]-float(knot))<=float(C["knot_halfwidth"])
        vals={}
        for s in C["survey_values"]:
            q=km&(arrays["survey"]==s)
            met=fit_metrics(arrays["alpha"][q],arrays["weight"][q],eng)
            if met is None:
                technical_fail=True
                point.append({"feh_knot":float(knot),"survey":s,"fit_ok":False})
            else:
                vals[s]=met
                point.append({"feh_knot":float(knot),"survey":s,"fit_ok":True,**met})
        if len(vals)==2:
            point.append({
              "feh_knot":float(knot),"survey":"GALAH_MINUS_APOGEE","fit_ok":True,
              "valley":vals["GALAH_CORRECTED"]["valley"]-vals["APOGEE_NATIVE"]["valley"],
              "separation":vals["GALAH_CORRECTED"]["separation"]-vals["APOGEE_NATIVE"]["separation"],
              "fraction":vals["GALAH_CORRECTED"]["fraction"]-vals["APOGEE_NATIVE"]["fraction"]
            })

    # Secondary pooled descriptive fits.
    pooled=[]
    for knot in C["primary_knots"]:
        q=np.abs(arrays["feh"]-float(knot))<=float(C["knot_halfwidth"])
        met=fit_metrics(arrays["alpha"][q],arrays["weight"][q],eng)
        pooled.append({"feh_knot":float(knot),"fit_ok":met is not None,**({} if met is None else met)})

    out=root/C["output_dir"]
    for q in ["tables","validation","checkpoints","freeze"]:
        (out/q).mkdir(parents=True,exist_ok=True)
    pd.DataFrame(point).to_csv(out/"tables/stage8d_point_estimates.csv",index=False)
    pd.DataFrame(pooled).to_csv(out/"tables/stage8d_pooled_descriptive_estimates.csv",index=False)
    audit_df.to_csv(out/"tables/stage8d_eligibility_audit.csv",index=False)

    if technical_fail:
        val={
          "stage":C["stage"],"implementation_version":C["implementation_version"],"timestamp_utc":now(),
          "STAGE8C_PARENT_READY":parent_ready,
          "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":True,
          "REAL_POINT_FIT_TECHNICAL_FAILURE":True,
          "BOOTSTRAP_PERFORMED":False,
          "STAGE8D_PRODUCTION_INFERENCE_COMPLETE":False,
          "OVERALL_CLASSIFICATION":"TECHNICAL_FAIL"
        }
        write_json(out/"validation/stage8d_validation.json",val)
        print(json.dumps(val,indent=2))
        return 2

    # Bootstrap checkpoint/resume.
    draws=int(C["bootstrap"]["draws"])
    ck=out/"checkpoints"
    existing={}
    for p in ck.glob("draw_*.json"):
        try: existing[int(p.stem.split("_")[1])]=json.loads(p.read_text())
        except Exception: pass
    pending=[i for i in range(draws) if i not in existing]
    workers=a.workers or int(C["bootstrap"]["workers_default"])
    print(f"[8D] point_fits=PASS eligible_rows={len(arrays['feh'])} cells={len(arrays['unique_cells'])}")
    print(f"[8D] bootstrap total={draws} existing={draws-len(pending)} pending={len(pending)} workers={workers}")
    print("[8D] Real morphology is now open under the frozen Stage-8C protocol.")
    t0=time.time(); done=0; errors=0
    if pending:
        with ProcessPoolExecutor(max_workers=workers,initializer=init_worker,
                                 initargs=(arrays,C,str(eng_path))) as ex:
            fmap={ex.submit(one_bootstrap,i):i for i in pending}
            for f in as_completed(fmap):
                i=fmap[f]
                try: rec=f.result()
                except Exception as e:
                    rec={"draw":i,"fit_ok":False,"error":repr(e)}; errors+=1
                write_json(ck/f"draw_{i:04d}.json",rec)
                done+=1
                if done%64==0 or done==len(pending):
                    print(f"[8D] completed_or_attempted={done}/{len(pending)} errors={errors} elapsed_min={(time.time()-t0)/60:.1f}")

    recs=[]
    for i in range(draws):
        p=ck/f"draw_{i:04d}.json"
        if not p.exists(): raise RuntimeError(f"missing checkpoint draw {i}")
        recs.append(json.loads(p.read_text()))
    br=pd.DataFrame(recs)
    br.to_csv(out/"tables/stage8d_bootstrap_draws.csv",index=False)

    # CI table and classification.
    cirows=[]
    class_rows=[]
    classes={}
    for e in ["valley","separation","fraction"]:
        knotrows=[]
        for knot in C["primary_knots"]:
            col=f"k{knot:+.1f}_{e}_diff"
            vals=pd.to_numeric(br.get(col,pd.Series(dtype=float)),errors="coerce").to_numpy(float)
            vals=vals[np.isfinite(vals)]
            vf=len(vals)/draws
            lo=float(np.quantile(vals,.025)) if len(vals) else np.nan
            hi=float(np.quantile(vals,.975)) if len(vals) else np.nan
            pointrow=[r for r in point if r.get("feh_knot")==float(knot) and r.get("survey")=="GALAH_MINUS_APOGEE"][0]
            pe=float(pointrow[e])
            row={"estimand":e,"feh_knot":float(knot),"point_difference":pe,
                 "ci_low":lo,"ci_high":hi,"valid_draws":len(vals),"valid_fraction":vf,
                 "margin":float(C["margins"][e])}
            cirows.append(row); knotrows.append(row)
        cls,stable_flags,pos,neg,maxrun=classify_estimand(
            knotrows,float(C["margins"][e]),
            int(C["classification"]["stable_min_knots"]),
            int(C["classification"]["sensitive_min_adjacent"])
        )
        classes[e]=cls
        class_rows.append({
          "estimand":e,"classification":cls,
          "stable_knots":int(sum(stable_flags)),
          "max_sensitive_adjacent_run":int(maxrun),
          "all_valid_fraction_ge_0p95":bool(all(r["valid_fraction"]>=.95 for r in knotrows))
        })

    if any(v=="SURVEY_SENSITIVE" for v in classes.values()):
        overall="MORPHOLOGY_SURVEY_SENSITIVE"
    elif all(v=="TRANSPORT_STABLE" for v in classes.values()):
        overall="MORPHOLOGY_TRANSPORT_STABLE"
    else:
        overall="INDETERMINATE"

    ci_df=pd.DataFrame(cirows)
    cls_df=pd.DataFrame(class_rows)
    ci_df.to_csv(out/"tables/stage8d_bootstrap_intervals.csv",index=False)
    cls_df.to_csv(out/"tables/stage8d_classification_summary.csv",index=False)
    (out/"freeze/stage8d_execution_contract_frozen.json").write_text(
        (root/"protocol/stage8d_execution_contract.json").read_text(),encoding="utf-8"
    )

    all_valid=bool((ci_df["valid_fraction"]>=float(C["bootstrap"]["minimum_valid_fraction"])).all())
    val={
      "stage":C["stage"],"implementation_version":C["implementation_version"],"timestamp_utc":now(),
      "STAGE8C_PARENT_READY":parent_ready,
      "SOURCE_SHA256":sha_file(src),
      "CALIBRATED_ENGINE_SHA256":sha_file(eng_path),
      "REAL_ALPHA3_MIXTURE_FIT_PERFORMED":True,
      "REAL_ALPHA3_SEQUENCE_INTERPRETATION_PERFORMED":True,
      "REAL_SURVEY_MORPHOLOGY_DIFFERENCE_COMPUTED":True,
      "ELIGIBLE_ROWS":int(len(arrays["feh"])),
      "PRIMARY_NSIDE16_BLOCKS":int(len(arrays["unique_cells"])),
      "PRIMARY_POINT_FITS_ALL_READY":True,
      "BOOTSTRAP_DRAWS_COMPLETED":draws,
      "ALL_PRIMARY_KNOT_ESTIMAND_VALID_FRACTIONS_GE_0P95":all_valid,
      "VALLEY_CLASSIFICATION":classes["valley"],
      "SEPARATION_CLASSIFICATION":classes["separation"],
      "FRACTION_CLASSIFICATION":classes["fraction"],
      "OVERALL_CLASSIFICATION":overall,
      "MINUS0P8_DISPOSITION":"LOW_SUPPORT_NOT_TESTABLE",
      "POST_REAL_FIT_GATE_CHANGES_PERFORMED":False,
      "STAGE8D_PRODUCTION_INFERENCE_COMPLETE":bool(all_valid),
      "STAGE8E_CLAIM_SAFE_INTEGRATION_READY":bool(all_valid)
    }
    write_json(out/"validation/stage8d_validation.json",val)
    print(json.dumps({"validation":val,"classification_summary":class_rows},indent=2,ensure_ascii=False))
    return 0 if all_valid else 2

if __name__=="__main__":
    raise SystemExit(main())
