from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except Exception:
        return str(path).replace("\\", "/")


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_csv_or_empty(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()


def to_bool(value: Any) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes", "y"}


def to_number(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").fillna(0)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def normalise_name(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def read_columns(path: Path) -> tuple[list[str], int]:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        import pyarrow.parquet as pq
        parquet = pq.ParquetFile(path)
        return list(parquet.schema_arrow.names), int(parquet.metadata.num_rows)
    if suffix == ".feather":
        import pyarrow.feather as feather
        table = feather.read_table(path)
        return list(table.column_names), int(table.num_rows)
    return list(pd.read_csv(path, nrows=5).columns), -1


def identifier_like(columns: list[str]) -> list[str]:
    tokens = [
        "source_id", "sourceid", "sobject", "object_id", "objectid",
        "galah_id", "star_id", "target_id", "tmass", "twomass",
        "gaia_id", "dr2", "dr3", "catalog_id", "catalogue_id"
    ]
    output = []
    for column in columns:
        name = normalise_name(column)
        if any(token in name for token in tokens):
            output.append(column)
    return output


def dr3_like(columns: list[str]) -> list[str]:
    output = []
    for column in columns:
        name = normalise_name(column)
        if (
            ("dr3" in name and ("source" in name or "gaia" in name))
            or name in {"gaia_source_id", "source_id"}
        ):
            output.append(column)
    return output


def snr_like(columns: list[str]) -> list[str]:
    return [
        column for column in columns
        if "snr" in normalise_name(column)
        or "signal_to_noise" in normalise_name(column)
    ]


def build_family_graph(edges: pd.DataFrame) -> dict[str, set[str]]:
    graph: dict[str, set[str]] = defaultdict(set)
    if edges.empty:
        return graph
    for _, row in edges.iterrows():
        if not to_bool(row.get("functional_ready", False)):
            continue
        left = str(row.get("left_family", "")).strip()
        right = str(row.get("right_family", "")).strip()
        if not left or not right:
            continue
        graph[left].add(right)
        graph[right].add(left)
    return graph


def connected_component(
    graph: dict[str, set[str]],
    start: str,
) -> set[str]:
    if not start:
        return set()
    visited = {start}
    queue = deque([start])
    while queue:
        current = queue.popleft()
        for neighbor in graph.get(current, set()):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return visited


def classify_gap(
    maximum_overlap_rows: int,
    maximum_overlap_fraction: float,
    frozen_rows: int,
    frozen_fraction: float,
    candidate_components_touch_anchor: bool,
    candidate_count: int,
) -> str:
    if candidate_count == 0:
        return "GALAH_SNR_IDENTIFIER_CANDIDATE_MISSING"
    if (
        maximum_overlap_rows >= frozen_rows
        and maximum_overlap_fraction >= frozen_fraction
    ):
        return "D7_SELECTION_IMPLEMENTATION_CONTRADICTION"
    if maximum_overlap_rows > 0:
        return "ARCHIVE_ROUTE_PRESENT_BELOW_FROZEN_GATE"
    if candidate_components_touch_anchor:
        return "CONNECTED_FAMILY_BUT_IDENTIFIER_GENERATION_MISMATCH"
    return "MISSING_ARCHIVAL_IDENTIFIER_BRIDGE"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    cfg = json.loads(
        (root / "config/stage6d3a2d8_config.json").read_text(
            encoding="utf-8"
        )
    )
    out = root / cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for directory in [
        "validation", "summaries", "tables",
        "reports", "diagnostics", "acquisition"
    ]:
        (out / directory).mkdir(parents=True, exist_ok=True)

    prereq_path = root / cfg["prerequisite_validation"]
    prereq = (
        json.loads(prereq_path.read_text(encoding="utf-8"))
        if prereq_path.exists() else {}
    )
    prerequisite_ready = bool(
        prereq.get("STAGE6D3A2D6_PREREQUISITE_READY", False)
        and prereq.get("CANONICAL_ANCHOR_READY", False)
        and prereq.get("OPAQUE_IDENTIFIER_NAMESPACE_READY", False)
        and prereq.get("IDENTIFIER_VALUE_PROFILE_READY", False)
        and prereq.get("FUNCTIONAL_MAPPING_EDGE_GRAPH_READY", False)
        and prereq.get("FINAL_ROW_CONSERVATION_READY", False)
        and not prereq.get("GALAH_IDENTIFIER_GRAPH_ROUTE_READY", False)
    )

    table_paths = {
        name: root / relative
        for name, relative in cfg["d7_tables"].items()
    }
    schema = read_csv_or_empty(table_paths["schema_inventory"])
    nodes = read_csv_or_empty(table_paths["node_profiles"])
    edges = read_csv_or_empty(table_paths["edge_audit"])
    components = read_csv_or_empty(table_paths["components"])
    routes = read_csv_or_empty(table_paths["route_evaluation"])
    remaining = read_csv_or_empty(table_paths["remaining_items"])

    required_tables_ready = all(
        table_paths[name].exists()
        for name in [
            "schema_inventory", "node_profiles",
            "edge_audit", "route_evaluation"
        ]
    )

    manifest_rows = []
    for name, path in table_paths.items():
        manifest_rows.append({
            "role": name,
            "path": safe_rel(path, root),
            "exists": str(path.exists()).lower(),
            "size_bytes": path.stat().st_size if path.exists() else 0,
            "sha256": sha256_file(path) if path.exists() else "",
        })
    write_csv(
        out / "tables/stage6d3a2d8_input_manifest.csv",
        ["role", "path", "exists", "size_bytes", "sha256"],
        manifest_rows,
    )

    frozen_rows = int(cfg["frozen_minimum_anchor_overlap_rows"])
    frozen_fraction = float(
        cfg["frozen_minimum_anchor_overlap_fraction"]
    )

    if routes.empty:
        maximum_overlap_rows = 0
        maximum_overlap_fraction = 0.0
        best_route_rows = []
    else:
        routes = routes.copy()
        routes["anchor_overlap_rows_num"] = to_number(
            routes.get(
                "anchor_overlap_rows",
                pd.Series(0, index=routes.index),
            )
        )
        routes["anchor_overlap_fraction_num"] = pd.to_numeric(
            routes.get(
                "anchor_overlap_fraction",
                pd.Series(0, index=routes.index),
            ),
            errors="coerce",
        ).fillna(0.0)
        routes["selection_score_num"] = pd.to_numeric(
            routes.get(
                "selection_score",
                pd.Series(0, index=routes.index),
            ),
            errors="coerce",
        ).fillna(0.0)
        ordered = routes.sort_values(
            [
                "anchor_overlap_rows_num",
                "anchor_overlap_fraction_num",
                "selection_score_num",
            ],
            ascending=False,
            kind="stable",
        )
        best = ordered.iloc[0]
        maximum_overlap_rows = int(best["anchor_overlap_rows_num"])
        maximum_overlap_fraction = float(
            best["anchor_overlap_fraction_num"]
        )
        best_route_rows = [
            {
                "rank": rank,
                "route_id": row.get("route_id", ""),
                "candidate_path": row.get("candidate_path", ""),
                "candidate_column": row.get("candidate_column", ""),
                "candidate_family": row.get("candidate_family", ""),
                "contract": row.get("contract", ""),
                "route_depth": row.get("route_depth", ""),
                "route_families": row.get("route_families", ""),
                "edge_ids": row.get("edge_ids", ""),
                "finite_source_rows": row.get("finite_source_rows", ""),
                "anchor_overlap_rows": int(
                    row.get("anchor_overlap_rows_num", 0)
                ),
                "anchor_overlap_fraction": float(
                    row.get("anchor_overlap_fraction_num", 0.0)
                ),
                "rows_short_of_gate": max(
                    frozen_rows
                    - int(row.get("anchor_overlap_rows_num", 0)),
                    0,
                ),
                "fraction_short_of_gate": max(
                    frozen_fraction
                    - float(
                        row.get("anchor_overlap_fraction_num", 0.0)
                    ),
                    0.0,
                ),
            }
            for rank, (_, row) in enumerate(
                ordered.head(20).iterrows(), start=1
            )
        ]
    write_csv(
        out / "tables/stage6d3a2d8_best_available_routes.csv",
        [
            "rank", "route_id", "candidate_path",
            "candidate_column", "candidate_family",
            "contract", "route_depth", "route_families",
            "edge_ids", "finite_source_rows",
            "anchor_overlap_rows", "anchor_overlap_fraction",
            "rows_short_of_gate", "fraction_short_of_gate"
        ],
        best_route_rows,
    )

    schema_candidate_paths = set()
    if not schema.empty:
        for _, row in schema.iterrows():
            contract = str(row.get("snr_contract", "")).strip()
            is_galah = to_bool(row.get("path_is_galah", False))
            if contract and is_galah:
                schema_candidate_paths.add(str(row.get("path", "")))

    route_candidate_pairs = set()
    if not routes.empty:
        for _, row in routes.iterrows():
            route_candidate_pairs.add((
                str(row.get("candidate_path", "")),
                str(row.get("candidate_column", "")),
                str(row.get("candidate_family", "")),
            ))

    candidate_nodes = []
    anchor_nodes = []
    if not nodes.empty:
        for _, row in nodes.iterrows():
            profile = {
                "node_id": row.get("node_id", ""),
                "path": row.get("path", ""),
                "column": row.get("column", ""),
                "family": row.get("family", ""),
                "non_null_rows": row.get("non_null_rows", ""),
                "unique_values": row.get("unique_values", ""),
                "minimum_length": row.get("minimum_length", ""),
                "median_length": row.get("median_length", ""),
                "maximum_length": row.get("maximum_length", ""),
                "direct_anchor_overlap_rows": int(
                    pd.to_numeric(
                        row.get("direct_anchor_overlap_rows", 0),
                        errors="coerce",
                    )
                    if pd.notna(
                        pd.to_numeric(
                            row.get("direct_anchor_overlap_rows", 0),
                            errors="coerce",
                        )
                    )
                    else 0
                ),
                "sample_hash": row.get("sample_hash", ""),
            }
            if (
                str(row.get("path", "")) in schema_candidate_paths
                or (
                    str(row.get("path", "")),
                    str(row.get("column", "")),
                    str(row.get("family", "")),
                ) in route_candidate_pairs
            ):
                candidate_nodes.append(profile)
            if profile["direct_anchor_overlap_rows"] > 0:
                anchor_nodes.append(profile)

    graph = build_family_graph(edges)
    anchor_families = {
        str(row["family"]) for row in anchor_nodes
        if str(row["family"]).strip()
    }
    candidate_component_rows = []
    candidate_components_touch_anchor = False
    for candidate in candidate_nodes:
        family = str(candidate["family"]).strip()
        component = connected_component(graph, family)
        touches = bool(component.intersection(anchor_families))
        candidate_components_touch_anchor |= touches
        candidate_component_rows.append({
            **candidate,
            "component_families": "|".join(sorted(component)),
            "anchor_families": "|".join(sorted(anchor_families)),
            "component_touches_anchor_family": str(touches).lower(),
        })
    write_csv(
        out / "tables/stage6d3a2d8_candidate_component_gap.csv",
        [
            "node_id", "path", "column", "family",
            "non_null_rows", "unique_values",
            "minimum_length", "median_length", "maximum_length",
            "direct_anchor_overlap_rows", "sample_hash",
            "component_families", "anchor_families",
            "component_touches_anchor_family"
        ],
        candidate_component_rows,
    )

    gap_classification = classify_gap(
        maximum_overlap_rows=maximum_overlap_rows,
        maximum_overlap_fraction=maximum_overlap_fraction,
        frozen_rows=frozen_rows,
        frozen_fraction=frozen_fraction,
        candidate_components_touch_anchor=(
            candidate_components_touch_anchor
        ),
        candidate_count=len(candidate_nodes),
    )

    bridge_rows = []
    for candidate in candidate_nodes:
        bridge_rows.append({
            "candidate_path": candidate["path"],
            "candidate_identifier_column": candidate["column"],
            "candidate_identifier_family": candidate["family"],
            "candidate_non_null_rows": candidate["non_null_rows"],
            "candidate_unique_values": candidate["unique_values"],
            "candidate_value_length_range": (
                f"{candidate['minimum_length']}|"
                f"{candidate['median_length']}|"
                f"{candidate['maximum_length']}"
            ),
            "required_bridge_left_column": candidate["column"],
            "required_bridge_right_column": (
                cfg["required_right_identifier"]
            ),
            "required_right_dtype": cfg["required_right_dtype"],
            "mapping_cardinality": (
                cfg["allowed_mapping_cardinality"]
            ),
            "minimum_functional_rows": max(
                int(cfg["minimum_bridge_functional_rows"]),
                frozen_rows,
            ),
            "minimum_finite_anchor_overlap_rows": frozen_rows,
            "minimum_finite_anchor_overlap_fraction": frozen_fraction,
            "preferred_product": (
                "original GALAH source/crossmatch table containing the "
                "candidate identifier, native S/N lineage, and exact Gaia "
                "DR3 source ID; otherwise a standalone frozen crosswalk"
            ),
            "forbidden_substitutions": (
                "coordinate nearest-neighbour matching; abundance matching; "
                "gradient/outcome matching; survey-neutral S/N proxy; "
                "float64 Gaia-ID conversion"
            ),
        })
    write_csv(
        out / "acquisition/stage6d3a2d8_required_bridge_spec.csv",
        [
            "candidate_path", "candidate_identifier_column",
            "candidate_identifier_family", "candidate_non_null_rows",
            "candidate_unique_values", "candidate_value_length_range",
            "required_bridge_left_column",
            "required_bridge_right_column", "required_right_dtype",
            "mapping_cardinality", "minimum_functional_rows",
            "minimum_finite_anchor_overlap_rows",
            "minimum_finite_anchor_overlap_fraction",
            "preferred_product", "forbidden_substitutions"
        ],
        bridge_rows,
    )

    acquisition_request = {
        "stage": cfg["stage"],
        "gap_classification": gap_classification,
        "request": (
            "Provide one frozen GALAH identifier bridge or original source "
            "catalogue that connects at least one listed GALAH S/N candidate "
            "identifier to exact Gaia DR3 source IDs."
        ),
        "acceptable_products": [
            {
                "type": "preferred_original_source",
                "required_columns": [
                    "<candidate identifier from required_bridge_spec.csv>",
                    "native scalar S/N or detector/arm S/N columns",
                    "gaia_dr3_source_id",
                ],
            },
            {
                "type": "standalone_crosswalk",
                "required_columns": [
                    "<candidate identifier from required_bridge_spec.csv>",
                    "gaia_dr3_source_id",
                ],
            },
        ],
        "identity_contract": {
            "gaia_dr3_source_id": cfg["required_right_dtype"],
            "mapping": cfg["allowed_mapping_cardinality"],
            "minimum_rows": max(
                int(cfg["minimum_bridge_functional_rows"]),
                frozen_rows,
            ),
            "minimum_anchor_overlap_fraction": frozen_fraction,
        },
        "forbidden": [
            "lowering the frozen 500-row or 0.5% overlap gates",
            "nearest-neighbour coordinate crossmatch without a frozen "
            "catalogue-level identity audit",
            "chemical-abundance, residual, gradient, or outcome-based matching",
            "survey-neutral synthetic S/N",
            "float64 parsing of Gaia source IDs",
        ],
        "best_existing_route": {
            "maximum_anchor_overlap_rows": maximum_overlap_rows,
            "maximum_anchor_overlap_fraction": maximum_overlap_fraction,
            "rows_short_of_gate": max(
                frozen_rows - maximum_overlap_rows, 0
            ),
            "fraction_short_of_gate": max(
                frozen_fraction - maximum_overlap_fraction, 0.0
            ),
        },
    }
    write_json(
        out / "acquisition/stage6d3a2d8_acquisition_request.json",
        acquisition_request,
    )

    extended_schema_rows = []
    extended_count = 0
    suffixes = set(cfg["tabular_suffixes"])
    for rel_root in cfg["extended_header_scan_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        paths = [base] if base.is_file() else base.rglob("*")
        for path in paths:
            if (
                extended_count >= int(
                    cfg["maximum_extended_schema_files"]
                )
            ):
                break
            if not path.is_file() or path.suffix.lower() not in suffixes:
                continue
            extended_count += 1
            try:
                columns, row_count = read_columns(path)
                identifiers = identifier_like(columns)
                dr3_columns = dr3_like(columns)
                snr_columns = snr_like(columns)
                bridge_candidate = bool(
                    identifiers and dr3_columns
                )
                original_source_candidate = bool(
                    identifiers and dr3_columns and snr_columns
                )
                extended_schema_rows.append({
                    "path": safe_rel(path, root),
                    "row_count": row_count,
                    "identifier_columns": "|".join(identifiers),
                    "dr3_like_columns": "|".join(dr3_columns),
                    "snr_columns": "|".join(snr_columns),
                    "bridge_header_candidate": str(
                        bridge_candidate
                    ).lower(),
                    "original_source_header_candidate": str(
                        original_source_candidate
                    ).lower(),
                    "read_error": "",
                })
            except Exception as exc:
                extended_schema_rows.append({
                    "path": safe_rel(path, root),
                    "row_count": "",
                    "identifier_columns": "",
                    "dr3_like_columns": "",
                    "snr_columns": "",
                    "bridge_header_candidate": "false",
                    "original_source_header_candidate": "false",
                    "read_error": f"{type(exc).__name__}: {exc}",
                })
    write_csv(
        out / "tables/stage6d3a2d8_extended_archive_header_scan.csv",
        [
            "path", "row_count", "identifier_columns",
            "dr3_like_columns", "snr_columns",
            "bridge_header_candidate",
            "original_source_header_candidate", "read_error"
        ],
        extended_schema_rows,
    )
    local_unscanned_candidate_ready = any(
        to_bool(row["bridge_header_candidate"])
        for row in extended_schema_rows
    )

    reference_terms = {
        str(term).lower() for term in cfg["reference_terms"]
    }
    for candidate in candidate_nodes:
        reference_terms.add(str(candidate["column"]).lower())
        reference_terms.add(Path(str(candidate["path"])).name.lower())

    reference_rows = []
    for rel_root in cfg["text_reference_scan_roots"]:
        base = root / rel_root
        if not base.exists():
            continue
        paths = [base] if base.is_file() else base.rglob("*")
        for path in paths:
            if len(reference_rows) >= int(cfg["maximum_reference_hits"]):
                break
            if (
                not path.is_file()
                or path.suffix.lower() not in set(cfg["text_suffixes"])
                or path.stat().st_size
                > int(cfg["maximum_text_file_bytes"])
            ):
                continue
            try:
                lines = path.read_text(
                    encoding="utf-8", errors="replace"
                ).splitlines()
            except Exception:
                continue
            for line_number, line in enumerate(lines, start=1):
                lowered = line.lower()
                hits = sorted(
                    term for term in reference_terms
                    if term and term in lowered
                )
                if not hits:
                    continue
                reference_rows.append({
                    "path": safe_rel(path, root),
                    "line_number": line_number,
                    "matched_terms": "|".join(hits),
                    "line_excerpt": line.strip()[:1000],
                })
                if len(reference_rows) >= int(
                    cfg["maximum_reference_hits"]
                ):
                    break
    write_csv(
        out / "tables/stage6d3a2d8_source_reference_inventory.csv",
        [
            "path", "line_number",
            "matched_terms", "line_excerpt"
        ],
        reference_rows,
    )

    external_acquisition_required = bool(
        gap_classification
        in {
            "MISSING_ARCHIVAL_IDENTIFIER_BRIDGE",
            "CONNECTED_FAMILY_BUT_IDENTIFIER_GENERATION_MISMATCH",
            "GALAH_SNR_IDENTIFIER_CANDIDATE_MISSING",
        }
        and not local_unscanned_candidate_ready
    )

    diagnosis_ready = bool(
        prerequisite_ready
        and required_tables_ready
        and bool(candidate_nodes)
        and bool(bridge_rows)
    )

    validation = {
        "stage": cfg["stage"],
        "protocol_version": cfg["protocol_version"],
        "implementation_version": cfg["implementation_version"],
        "timestamp_utc": utc_now(),
        "project_root": str(root),
        "gap_classification": gap_classification,
        "candidate_node_count": len(candidate_nodes),
        "anchor_node_count": len(anchor_nodes),
        "functional_edge_count": int(
            sum(
                to_bool(value)
                for value in edges.get(
                    "functional_ready",
                    pd.Series(dtype=object),
                )
            )
        ) if not edges.empty else 0,
        "evaluated_route_count": len(routes),
        "maximum_existing_anchor_overlap_rows": maximum_overlap_rows,
        "maximum_existing_anchor_overlap_fraction": (
            maximum_overlap_fraction
        ),
        "frozen_minimum_anchor_overlap_rows": frozen_rows,
        "frozen_minimum_anchor_overlap_fraction": frozen_fraction,
        "rows_short_of_frozen_gate": max(
            frozen_rows - maximum_overlap_rows, 0
        ),
        "fraction_short_of_frozen_gate": max(
            frozen_fraction - maximum_overlap_fraction, 0.0
        ),
        "candidate_components_touch_anchor_family": (
            candidate_components_touch_anchor
        ),
        "local_unscanned_bridge_header_candidate_ready": (
            local_unscanned_candidate_ready
        ),
        "external_source_acquisition_required": (
            external_acquisition_required
        ),
        "prior_stage_outputs_modified": False,
        "STAGE6D3A2D7_PREREQUISITE_READY": prerequisite_ready,
        "D7_REQUIRED_AUDIT_TABLES_READY": required_tables_ready,
        "D7_NO_QUALIFYING_ROUTE_CONFIRMED": bool(
            prerequisite_ready
            and not prereq.get(
                "GALAH_IDENTIFIER_GRAPH_ROUTE_READY", False
            )
        ),
        "BEST_AVAILABLE_ROUTE_QUANTIFIED": True,
        "IDENTIFIER_COMPONENT_GAP_CLASSIFIED": bool(
            gap_classification
        ),
        "REQUIRED_BRIDGE_SPEC_READY": bool(bridge_rows),
        "ACQUISITION_REQUEST_READY": True,
        "FROZEN_OVERLAP_GATES_UNCHANGED": True,
        "OUTCOME_BLIND_PROVENANCE_CLOSURE_READY": diagnosis_ready,
        "LOCAL_UNSCANNED_BRIDGE_HEADER_CANDIDATE_READY": (
            local_unscanned_candidate_ready
        ),
        "EXTERNAL_SOURCE_ACQUISITION_REQUIRED": (
            external_acquisition_required
        ),
        "STAGE6D3A2D8_PROVENANCE_DIAGNOSIS_READY": (
            diagnosis_ready
        ),
        "STAGE6D3B_COMMON_FOOTPRINT_READY": False,
    }
    write_json(
        out / "validation/stage6d3a2d8_validation.json",
        validation,
    )

    summary = {
        "stage": cfg["stage"],
        "timestamp_utc": utc_now(),
        "diagnosis": {
            "classification": gap_classification,
            "candidate_nodes": len(candidate_nodes),
            "anchor_nodes": len(anchor_nodes),
            "maximum_existing_anchor_overlap_rows": (
                maximum_overlap_rows
            ),
            "maximum_existing_anchor_overlap_fraction": (
                maximum_overlap_fraction
            ),
            "candidate_components_touch_anchor_family": (
                candidate_components_touch_anchor
            ),
        },
        "required_next_input": (
            "Inspect the locally discovered bridge-header candidate(s) and "
            "freeze the exact identifier mapping."
            if local_unscanned_candidate_ready
            else
            "Acquire or provide one frozen GALAH candidate-ID to exact Gaia "
            "DR3 source-ID bridge satisfying the generated acquisition request."
        ),
        "d3b_authorized": False,
        "scientific_disposition": (
            "D7's no-route result is converted into an exact provenance-gap "
            "classification and a claim-safe acquisition contract. No "
            "threshold is weakened and D3B remains blocked until the required "
            "identity bridge is supplied."
        ),
    }
    write_json(
        out / "summaries/stage6d3a2d8_summary.json",
        summary,
    )

    report_lines = [
        "# Stage-6D3A2D8 disconnected-component provenance closure",
        "",
        f"- Gap classification: `{gap_classification}`",
        f"- Candidate identifier nodes: `{len(candidate_nodes)}`",
        f"- Anchor-overlapping nodes: `{len(anchor_nodes)}`",
        f"- Evaluated D7 routes: `{len(routes)}`",
        f"- Best existing overlap rows: `{maximum_overlap_rows}`",
        f"- Best existing overlap fraction: `{maximum_overlap_fraction:.8f}`",
        f"- Frozen row gate: `{frozen_rows}`",
        f"- Frozen fraction gate: `{frozen_fraction}`",
        f"- Candidate component touches anchor family: `{candidate_components_touch_anchor}`",
        f"- Local unscanned bridge-header candidate: `{local_unscanned_candidate_ready}`",
        f"- External acquisition required: `{external_acquisition_required}`",
        f"- Stage-6D3B authorized: `False`",
        "",
        "The next valid input is an exact catalogue identity bridge, not a "
        "new matching heuristic. The bridge must contain a listed GALAH S/N "
        "candidate identifier and an exact Gaia DR3 source ID. Each left "
        "identifier must map to at most one Gaia DR3 source, while multiple "
        "left identifiers may map to one source.",
        "",
        "The frozen 500-row and 0.5% finite-overlap gates are unchanged.",
        "",
    ]
    (
        out
        / "reports/stage6d3a2d8_disconnected_component_provenance_closure.md"
    ).write_text("\n".join(report_lines), encoding="utf-8")

    acquisition_md = [
        "# Required GALAH identifier bridge",
        "",
        f"Classification: **{gap_classification}**",
        "",
        "Provide one of the following frozen products:",
        "",
        "1. An original GALAH source table containing the candidate identifier, "
        "the native S/N field(s), and `gaia_dr3_source_id`.",
        "2. A standalone crosswalk containing the candidate identifier and "
        "`gaia_dr3_source_id`.",
        "",
        "Required identity rules:",
        "",
        "- Gaia DR3 IDs are exact UInt64 or digit strings; float64 is forbidden.",
        "- Each left identifier maps to at most one Gaia DR3 source ID.",
        "- Multiple left identifiers may map to one Gaia DR3 source.",
        f"- At least {frozen_rows} finite candidate rows must overlap the "
        "canonical GALAH anchor.",
        f"- The overlap fraction must be at least {frozen_fraction}.",
        "",
        "Forbidden substitutes:",
        "",
        "- lowering the frozen gates;",
        "- coordinate nearest-neighbour matching without catalogue identity;",
        "- abundance, residual, gradient, or outcome-based matching;",
        "- a survey-neutral synthetic S/N proxy.",
        "",
    ]
    (
        out
        / "acquisition/STAGE6D3A2D8_ACQUISITION_REQUEST.md"
    ).write_text("\n".join(acquisition_md), encoding="utf-8")

    print(json.dumps(
        {"validation": validation, "summary": summary},
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
