from __future__ import annotations
import argparse, hashlib, importlib.util, json, math, os, sys, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import numpy as np, pandas as pd

G={}

def now(): return datetime.now(timezone.utc).isoformat()

def canonical_sha(o):
    return hashlib.sha256(json.dumps(
        o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False
    ).encode()).hexdigest()

def write_json(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")

def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise ImportError(str(path))
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
    return mod

def flag_to_bool(s):
    if pd.api.types.is_bool_dtype(s): return s.fillna(False).to_numpy(bool)
    return s.astype(str).str.strip().str.lower().isin(["1","true","t","yes","y"]).to_numpy(bool)

def stable_fold(cell,namespace,kind,k,outer=None):
    tag=f"{namespace}|{kind}|{'' if outer is None else outer}|{int(cell)}"
    d=hashlib.sha256(tag.encode()).digest()
    return int.from_bytes(d[:8],"little")%int(k)

def f0(R,Z): return np.column_stack([R-8.2,Z])
def f1(R,Z,rb): return np.column_stack([R-8.2,np.maximum(0.0,R-float(rb)),Z])
def pred(fit,X): return fit.beta[0]+X@fit.beta[1:]
def wmae(y,p,w):
    return float(np.sum(w*np.abs(y-p))/np.sum(w))

def wfit(X,y,w):
    d4b=G["d4b"];s4b=G["s4b"];h=G["h"]
    return d4b.weighted_huber_fit(
        X,y,w,
        tuning_constant=float(h["tuning_constant"]),
        relative_tolerance=float(h["relative_tolerance"]),
        maximum_iterations=int(h["maximum_iterations"]),
        minimum_scale=float(h["minimum_scale"]),
        robust_scale_fn=s4b.robust_scale
    )

def group_center(resid,w,survey,cell):
    x=pd.DataFrame({"r":resid,"w":w,"s":survey,"c":cell})
    x["wr"]=x["r"]*x["w"]
    q=x.groupby(["s","c"],sort=False)[["wr","w"]].sum()
    mu=(q["wr"]/q["w"]).to_dict()
    return resid-np.array([mu[(s,int(c))] for s,c in zip(survey,cell)],float)

def synth(seed,rb,delta):
    rng=np.random.Generator(np.random.PCG64DXSM(int(seed)))
    groups=G["groups"]
    signs=rng.integers(0,2,size=len(groups),dtype=np.int8).astype(float)*2-1
    smap={g:signs[i] for i,g in enumerate(groups)}
    mult=np.array([smap[(str(s),int(c))] for s,c in zip(G["survey"],G["cell"])],float)
    y=G["fitted"]+mult*G["centered"]
    if float(delta)!=0:
        y=y+float(delta)*np.maximum(0.0,G["R"]-float(rb))
    return y

def select_break(R,Z,y,w,cell,outer_tag):
    folds=np.array([stable_fold(c,G["namespace"],"inner",3,outer=outer_tag) for c in cell],int)
    best=None
    for rb in G["breaks"]:
        loss=0.0
        for f in range(3):
            tr=folds!=f;va=folds==f
            fit=wfit(f1(R[tr],Z[tr],rb),y[tr],w[tr])
            if not fit.converged: raise RuntimeError("M1 inner fit failed")
            loss+=wmae(y[va],pred(fit,f1(R[va],Z[va],rb)),w[va])
        score=loss/3.0
        cand=(score,float(rb))
        if best is None or cand<best: best=cand
    return best[1]

def replicate(task):
    scenario,rb_in,delta,seed=task
    t0=time.perf_counter()
    R,Z,w,cell=G["R"],G["Z"],G["w"],G["cell"]
    y=synth(seed,rb_in,delta)

    improvements=[]
    selected_outer=[]
    outer=G["outer"]
    for of in range(5):
        tr=outer!=of;te=outer==of
        rb=select_break(R[tr],Z[tr],y[tr],w[tr],cell[tr],outer_tag=of)
        m0=wfit(f0(R[tr],Z[tr]),y[tr],w[tr])
        m1=wfit(f1(R[tr],Z[tr],rb),y[tr],w[tr])
        if not (m0.converged and m1.converged): raise RuntimeError("outer fit failed")
        a=wmae(y[te],pred(m0,f0(R[te],Z[te])),w[te])
        b=wmae(y[te],pred(m1,f1(R[te],Z[te],rb)),w[te])
        improvements.append(1-b/a)
        selected_outer.append(rb)

    rb_full=select_break(R,Z,y,w,cell,outer_tag="full")
    X=f1(R,Z,rb_full)
    fit=wfit(X,y,w)
    if not fit.converged: raise RuntimeError("full M1 failed")
    inf=G["d4b"].weighted_cluster_inference(
        X,y,cell.astype(np.int64),fit,n_draws=0,seed=1,
        finite_cluster_correction=True
    )
    delta_hat=float(fit.beta[2]);se=float(inf.standard_errors[2])
    z=1.959963984540054
    lo=delta_hat-z*se;hi=delta_hat+z*se
    wald_excludes=bool(lo>0 or hi<0)
    boundary=bool(rb_full in G["boundary_breaks"])
    median_imp=float(np.median(improvements))
    detected=bool(median_imp>=0.05 and wald_excludes and not boundary)
    sign_ok=bool(delta==0 or np.sign(delta_hat)==np.sign(delta))
    power_detect=bool(detected and sign_ok)
    return {
        "scenario":scenario,"seed":int(seed),
        "injected_break_kpc":float(rb_in),"injected_delta_beta":float(delta),
        "median_outer_cv_improvement":median_imp,
        "outer_improvements_json":json.dumps([float(x) for x in improvements]),
        "outer_selected_breaks_json":json.dumps([float(x) for x in selected_outer]),
        "selected_break_kpc":float(rb_full),
        "break_abs_error_kpc":float(abs(rb_full-rb_in)) if delta!=0 else np.nan,
        "delta_beta_hat":delta_hat,"delta_beta_se":se,
        "delta_beta_wald_low":lo,"delta_beta_wald_high":hi,
        "wald_excludes_zero":wald_excludes,
        "boundary_flag":boundary,"sign_correct":sign_ok,
        "detected_rule":detected,"power_detected_rule":power_detect,
        "runtime_seconds":time.perf_counter()-t0
    }

def init_worker(project_root,config_path):
    root=Path(project_root)
    c=json.loads((root/config_path).read_text())
    p=json.loads((root/c["stage7a_protocol"]).read_text())
    d4cfg=json.loads((root/c["d4b_config"]).read_text())
    d4b=load_module(f"d4b_worker_{os.getpid()}",root/c["d4b_source"])
    s4b=load_module(f"s4b_worker_{os.getpid()}",root/c["stage4b_common"])
    df=pd.read_parquet(root/c["balanced_source"],columns=c["columns"])
    eligible=flag_to_bool(df["fe_h_gradient_primary_ok"])
    R0=pd.to_numeric(df["R"],errors="coerce").to_numpy(float)
    Z0=pd.to_numeric(df["abs_Z"],errors="coerce").to_numpy(float)
    y0=pd.to_numeric(df["fe_h"],errors="coerce").to_numpy(float)
    w0=pd.to_numeric(df["balance_weight_final"],errors="coerce").to_numpy(float)
    mask=eligible&np.isfinite(R0)&np.isfinite(Z0)&np.isfinite(y0)&np.isfinite(w0)&(w0>0)&(R0>3)&(R0<15)
    d=df.loc[mask].reset_index(drop=True)
    R=pd.to_numeric(d["R"]).to_numpy(float);Z=pd.to_numeric(d["abs_Z"]).to_numpy(float)
    y=pd.to_numeric(d["fe_h"]).to_numpy(float);w=pd.to_numeric(d["balance_weight_final"]).to_numpy(float)
    survey=d["survey"].astype(str).to_numpy()
    cell=pd.to_numeric(d["healpix_gal_ring_nside16"]).to_numpy(np.int64)

    G.clear()
    G.update({
        "d4b":d4b,"s4b":s4b,"h":d4cfg["huber"],
        "R":R,"Z":Z,"w":w,"survey":survey,"cell":cell,
        "namespace":p["predictive_selection"]["namespace"],
        "breaks":[float(x) for x in p["break_search"]["grid_values"]],
        "boundary_breaks":set([4.5,4.6,8.4,8.5]),
        "outer":np.array([stable_fold(cc,p["predictive_selection"]["namespace"],"outer",5) for cc in cell],int)
    })
    m0=wfit(f0(R,Z),y,w)
    if not m0.converged: raise RuntimeError("worker real M0 failed")
    G["fitted"]=pred(m0,f0(R,Z))
    G["centered"]=group_center(m0.residuals,w,survey,cell)
    G["groups"]=sorted(set((str(s),int(cc)) for s,cc in zip(survey,cell)))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",default=".")
    ap.add_argument("--workers",type=int,default=None)
    a=ap.parse_args()
    root=Path(a.project_root).resolve()
    config_rel=Path("config/stage7b2a_config.json")
    c=json.loads((root/config_rel).read_text())
    out=root/c["output_dir"]
    if out.exists():
        import shutil;shutil.rmtree(out)
    for d in ["validation","tables","reports","benchmarks","freeze","manifest"]:
        (out/d).mkdir(parents=True,exist_ok=True)

    va=json.loads((root/c["stage7a_validation"]).read_text())
    vb=json.loads((root/c["stage7b1_validation"]).read_text())
    p=json.loads((root/c["stage7a_protocol"]).read_text())
    cl=json.loads((root/c["stage7b1_closure"]).read_text())
    prereq=bool(
        va.get("STAGE7A_PROTOCOL_FROZEN") and
        va.get("protocol_canonical_sha256")==c["expected_stage7a_protocol_sha256"] and
        canonical_sha(p)==c["expected_stage7a_protocol_sha256"] and
        vb.get("STAGE7B1_PREFLIGHT_READY") and
        vb.get("STAGE7B2_FULL_INJECTION_RECOVERY_READY") and
        vb.get("stage7b1_operational_closure_canonical_sha256")==c["expected_stage7b1_closure_sha256"] and
        canonical_sha(cl)==c["expected_stage7b1_closure_sha256"]
    )
    if not prereq: raise RuntimeError("Stage-7A/B1 identity prerequisite failed")

    pilot=json.loads((root/"protocol/stage7b2a_pilot_protocol.json").read_text())
    shutil.copy2(root/"protocol/stage7b2a_pilot_protocol.json",out/"freeze/stage7b2a_pilot_protocol_frozen.json")

    tasks=[]
    for sc in c["pilot_scenarios"]:
        for i in range(int(sc["replicates"])):
            tasks.append((sc["scenario"],float(sc["R_break_kpc"]),float(sc["delta_beta"]),int(sc["seed_start"])+i))

    workers=a.workers if a.workers is not None else min(int(c["default_workers"]),max(1,(os.cpu_count() or 2)-1))
    workers=max(1,int(workers))
    t0=time.perf_counter()
    rows=[]
    print(f"[B2A] tasks={len(tasks)} workers={workers} full_grid=41 outer=5 inner=3")
    with ProcessPoolExecutor(
        max_workers=workers,
        initializer=init_worker,
        initargs=(str(root),str(config_rel))
    ) as ex:
        fut={ex.submit(replicate,t):t for t in tasks}
        done=0
        for f in as_completed(fut):
            rows.append(f.result())
            done+=1
            if done%4==0 or done==len(tasks):
                print(f"[B2A] completed {done}/{len(tasks)}")
    wall=time.perf_counter()-t0

    df=pd.DataFrame(rows).sort_values(["scenario","seed"]).reset_index(drop=True)
    df.to_csv(out/"tables/stage7b2a_pilot_replicates.csv",index=False)

    summaries=[]
    for sc,g in df.groupby("scenario",sort=False):
        injected=float(g["injected_delta_beta"].iloc[0])
        summaries.append({
            "scenario":sc,"replicates":int(len(g)),
            "injected_break_kpc":float(g["injected_break_kpc"].iloc[0]),
            "injected_delta_beta":injected,
            "detection_fraction":float(g["detected_rule"].mean()),
            "power_detection_fraction":float(g["power_detected_rule"].mean()),
            "median_cv_improvement_median":float(g["median_outer_cv_improvement"].median()),
            "median_cv_improvement_q16":float(g["median_outer_cv_improvement"].quantile(.16)),
            "median_cv_improvement_q84":float(g["median_outer_cv_improvement"].quantile(.84)),
            "wald_excludes_zero_fraction":float(g["wald_excludes_zero"].mean()),
            "boundary_flag_fraction":float(g["boundary_flag"].mean()),
            "median_abs_break_error_kpc":(
                float(g["break_abs_error_kpc"].median()) if injected!=0 else np.nan
            ),
            "median_runtime_seconds":float(g["runtime_seconds"].median())
        })
    sm=pd.DataFrame(summaries)
    sm.to_csv(out/"tables/stage7b2a_pilot_summary.csv",index=False)

    benchmark={
        "tasks":len(tasks),"workers":workers,"wall_seconds":wall,
        "aggregate_worker_seconds":float(df["runtime_seconds"].sum()),
        "median_replicate_seconds":float(df["runtime_seconds"].median()),
        "estimated_formal_1792_wall_hours_at_observed_throughput":float((wall/len(tasks))*1792/3600),
        "warning":"This is only a throughput projection; formal B2 may differ because OS scheduling/cache effects change with longer runs."
    }
    write_json(out/"benchmarks/stage7b2a_runtime_benchmark.json",benchmark)

    ready=bool(
        prereq and len(df)==48 and np.isfinite(df["median_outer_cv_improvement"]).all()
        and df["selected_break_kpc"].between(4.5,8.5).all()
    )
    val={
        "stage":c["stage"],"implementation_version":c["implementation_version"],
        "timestamp_utc":now(),
        "STAGE7A_B1_IDENTITY_PREREQUISITE_READY":prereq,
        "PILOT_PROTOCOL_CANONICAL_SHA256":canonical_sha(pilot),
        "FULL_41_POINT_BREAK_GRID_USED":True,
        "FULL_5x3_NESTED_SPATIAL_CV_USED":True,
        "EXACT_D4B_WEIGHTED_HUBER_USED":True,
        "REAL_FEH_M1_BREAK_FIT_PERFORMED":False,
        "PILOT_REPLICATES_EXPECTED":48,
        "PILOT_REPLICATES_COMPLETED":int(len(df)),
        "PILOT_DIAGNOSTICS_READY":ready,
        "PILOT_RESULTS_FORMAL_FPR_OR_POWER_CLAIMS_AUTHORIZED":False,
        "FORMAL_STAGE7B2_DESIGN_UNCHANGED":True,
        "FORMAL_STAGE7B2_THRESHOLDS_UNCHANGED":True,
        "STAGE7C_REAL_BREAK_FIT_AUTHORIZED":False,
        "STAGE7B2A_PILOT_READY":ready,
        "STAGE7B2_FULL_PRODUCTION_TECHNICALLY_READY":ready
    }
    write_json(out/"validation/stage7b2a_validation.json",val)

    lines=["# Stage-7B2A full-grid power/runtime pilot","","This pilot is diagnostic, not the formal power study.",""]
    for r in summaries:
        lines.append(
            f"- {r['scenario']}: detection={r['detection_fraction']:.3f}, "
            f"power-detection={r['power_detection_fraction']:.3f}, "
            f"median CV improvement={r['median_cv_improvement_median']:.4f}, "
            f"median |break error|={r['median_abs_break_error_kpc']}"
        )
    lines += ["",f"Wall time: {wall:.1f} s with {workers} workers.",
              f"Projected 1792-replicate wall time at observed throughput: {benchmark['estimated_formal_1792_wall_hours_at_observed_throughput']:.2f} h.",
              "",
              "Do not interpret 16-replicate fractions as passing/failing the formal FPR or power gates.",
              "Stage-7C remains forbidden."]
    (out/"reports/stage7b2a_report.md").write_text("\n".join(lines)+"\n",encoding="utf-8")

    manifest=[]
    for fp in sorted(out.rglob("*")):
        if fp.is_file() and "manifest" not in fp.parts:
            manifest.append({"path":str(fp.relative_to(root)).replace("\\","/"),"size_bytes":fp.stat().st_size,"sha256":sha_file(fp)})
    pd.DataFrame(manifest).to_csv(out/"manifest/stage7b2a_manifest_sha256.csv",index=False)

    print(json.dumps({"validation":val,"summary":summaries,"benchmark":benchmark},indent=2,ensure_ascii=False))
    return 0 if ready else 2

if __name__=="__main__":
    raise SystemExit(main())
