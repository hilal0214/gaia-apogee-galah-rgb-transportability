import argparse,json,hashlib,re,shutil
from pathlib import Path
from datetime import datetime,timezone
import numpy as np,pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):h.update(b)
    return h.hexdigest()
def wt(p,o):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,indent=2,default=str)+"\n",encoding="utf-8")
def rt(p):
    if p.suffix.lower()==".parquet":return pd.read_parquet(p)
    return pd.read_csv(p)
def bs(s):
    if pd.api.types.is_bool_dtype(s):return s.fillna(False)
    if pd.api.types.is_numeric_dtype(s):return pd.to_numeric(s,errors="coerce").fillna(0)!=0
    return s.astype(str).str.lower().isin(["true","1","yes","y","t"])
def evidence(p):
    if not p.exists():return {}
    t=p.read_text(encoding="utf-8",errors="ignore")
    pats={"huber":r"huber","pivot":r"8\.2|pivot|r0","bootstrap":r"bootstrap|resampl","gradient":r"abs_z|r_cyl|beta_R|beta_Z"}
    return {k:len(re.findall(v,t,re.I)) for k,v in pats.items()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");a=ap.parse_args()
    r=Path(a.project_root).resolve();c=json.loads((r/"config/stage6d4a_config.json").read_text());o=r/c["output_dir"]
    if o.exists():shutil.rmtree(o)
    for d in ["validation","tables","lineage","summaries"]:(o/d).mkdir(parents=True,exist_ok=True)
    v=json.loads((r/c["d3c9_validation"]).read_text())
    pre=bool(v.get("PRODUCTION_BALANCED_WEIGHTS_READY") and v.get("STAGE6D3C9_PRODUCTION_REPLAY_READY") and v.get("STAGE6D4_SCIENCE_MODELS_READY") and v.get("d3c8_amended_protocol_canonical_sha256")==c["expected_d3c8_sha256"])
    sp=r/c["balanced_source"];df=rt(sp)
    sid=next((x for x in c["source_id_candidates"] if x in df.columns),None)
    req=[c["survey_column"],c["r_column"],c["abs_z_column"],c["cell_column"],c["weight_column"]]
    base=bool(sid and all(x in df.columns for x in req) and len(df)==c["expected_rows"] and df[c["cell_column"]].nunique()==c["expected_cells"] and set(df[c["survey_column"]].astype(str).unique())==set(c["expected_surveys"]) and np.all(pd.to_numeric(df[c["weight_column"]],errors="coerce")>0))
    rows=[]
    R=pd.to_numeric(df[c["r_column"]],errors="coerce")
    radial=(R>c["radial_domain"][0])&(R<c["radial_domain"][1])
    for lab in c["primary_labels"]+c["secondary_labels"]:
        y=c["label_columns"][lab];g=c["eligibility_columns"][lab]
        if y in df.columns and g in df.columns:
            use=np.isfinite(pd.to_numeric(df[y],errors="coerce")) & bs(df[g]) & radial
            by={s:int((use&(df[c["survey_column"]].astype(str)==s)).sum()) for s in c["expected_surveys"]}
            rr={"label":lab,"outcome_column":y,"eligibility_column":g,"usable_rows":int(use.sum()),"usable_cells":int(df.loc[use,c["cell_column"]].nunique()),"APOGEE_NATIVE_rows":by["APOGEE_NATIVE"],"GALAH_CORRECTED_rows":by["GALAH_CORRECTED"]}
            rr["MODEL_INPUT_READY"]=bool(rr["usable_rows"]>0 and rr["usable_cells"]>1 and all(x>0 for x in by.values()))
        else:
            rr={"label":lab,"outcome_column":y,"eligibility_column":g,"usable_rows":0,"usable_cells":0,"APOGEE_NATIVE_rows":0,"GALAH_CORRECTED_rows":0,"MODEL_INPUT_READY":False}
        rows.append(rr)
    pd.DataFrame(rows).to_csv(o/"tables/stage6d4a_label_input_inventory.csv",index=False)
    prim=all(x["MODEL_INPUT_READY"] for x in rows if x["label"] in c["primary_labels"])
    alpha=next(x["MODEL_INPUT_READY"] for x in rows if x["label"]=="alpha3")
    ep=r/c["stage4b_estimates"];bp=r/c["stage4b_bootstrap"];cp=r/c["stage4b_config"];scp=r/c["stage4b_script"]
    lin=bool(cp.exists() and scp.exists());ev=evidence(scp);evready=bool(lin and ev.get("huber",0)>0 and ev.get("gradient",0)>0)
    wt(o/"lineage/stage6d4a_stage4b_estimator_evidence.json",{"config_sha256":sha(cp) if cp.exists() else "","script_sha256":sha(scp) if scp.exists() else "","script_evidence":ev,"estimates_sha256":sha(ep) if ep.exists() else "","bootstrap_sha256":sha(bp) if bp.exists() else ""})
    ready=bool(pre and base and prim and ep.exists() and bp.exists() and lin and evready)
    val={"stage":c["stage"],"protocol_version":c["protocol_version"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),"input_rows":len(df),"cell_count":int(df[c["cell_column"]].nunique()),"resolved_source_id_column":sid,"D3C9_PRODUCTION_PREREQUISITE_READY":pre,"BALANCED_SOURCE_BASE_SCHEMA_READY":base,"PRIMARY_LABEL_INPUTS_READY":prim,"ALPHA3_SECONDARY_INPUT_READY":alpha,"FULL_SUPPORT_ESTIMATES_READY":ep.exists(),"FULL_SUPPORT_BOOTSTRAP_READY":bp.exists(),"STAGE4B_ESTIMATOR_LINEAGE_READY":lin,"STAGE4B_ESTIMATOR_EVIDENCE_READY":evready,"NO_NEW_OUTCOME_DEPENDENT_SELECTION":True,"NO_TARGET_ABUNDANCE_MATCHING":True,"STAGE6D4A_PREFLIGHT_READY":ready,"STAGE6D4B_PRODUCTION_FITS_READY":ready}
    wt(o/"validation/stage6d4a_validation.json",val);wt(o/"summaries/stage6d4a_summary.json",{"preflight_ready":ready,"label_inventory":rows,"next_action":"Run D4B production fits" if ready else "Inspect failed D4A gates"})
    print(json.dumps({"validation":val,"label_inventory":rows},indent=2));return 0
if __name__=="__main__":raise SystemExit(main())
