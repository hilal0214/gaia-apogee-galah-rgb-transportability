from __future__ import annotations
import argparse, ast, csv, hashlib, json, math, os, re, shutil, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
import pandas as pd
import yaml

STAGE='Stage-6C2H exact Stage-4B runner-lineage and shadow-replay closure'
PROTOCOL_VERSION='1.0.0'; IMPLEMENTATION_VERSION='0.15.7'
SHELL_SUFFIXES={'.bat','.cmd','.ps1','.sh'}
CONFIG_SUFFIXES={'.json','.yaml','.yml'}

def now(): return datetime.now(timezone.utc).isoformat()
def norm(v): return re.sub(r'[^a-z0-9]+','_',str(v).lower()).strip('_')
def rel(p,r):
    try: return str(p.resolve().relative_to(r.resolve())).replace('\\','/')
    except Exception: return str(p).replace('\\','/')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def write_json(p,v): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(v,indent=2,ensure_ascii=False,default=str)+'\n',encoding='utf-8')
def write_csv(p,fields,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); w.writeheader(); [w.writerow(x) for x in rows]
def load_cfg(p):
    if p.suffix.lower()=='.json': return json.loads(p.read_text(encoding='utf-8'))
    return yaml.safe_load(p.read_text(encoding='utf-8'))
def dump_cfg(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    if p.suffix.lower()=='.json': p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    else: p.write_text(yaml.safe_dump(v,sort_keys=False,allow_unicode=True),encoding='utf-8')
def stage_hit(text,cfg): return any(t.lower() in text.lower() for t in cfg['stage_tokens'])

def project_files(root,cfg,out):
    exc=set(cfg['excluded_directory_names']); suff=set(cfg['scan_suffixes'])
    for p in root.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in suff or out in p.parents: continue
        if any(x in exc for x in p.parts): continue
        yield p

def python_profile(p,text,root,cfg):
    lowrel=rel(p,root).lower()
    # Stage-6 closure scripts mention Stage-4B but are not production writers.
    if re.search(r'stage6c|stage6d|stage6e',lowrel): penalty=-80
    else: penalty=0
    main=bool(re.search(r"if\s+__name__\s*==\s*['\"]__main__['\"]",text))
    argparse_present='ArgumentParser' in text or 'argparse' in text
    cargs=[a for a in cfg['config_argument_names'] if a in text]
    wh=sum(text.lower().count(t.lower()) for t in cfg['writer_tokens'])
    sh=sum(text.lower().count(t.lower()) for t in cfg['stage_tokens'])
    funcs=[]
    try:
        tree=ast.parse(text)
        for n in ast.walk(tree):
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and any(t in n.name.lower() for t in ['main','run','build','fit','gradient','stage4b']): funcs.append(n.name)
    except Exception: pass
    score=penalty+30*(wh>0)+15*main+10*argparse_present+15*bool(cargs)+min(sh,10)+25*('stage4b' in p.name.lower())+10*('stage4b' in lowrel)
    return {'path':rel(p,root),'has_main_guard':main,'argparse_present':argparse_present,'config_arguments':'|'.join(cargs),'writer_token_hits':wh,'stage_token_hits':sh,'main_functions':'|'.join(sorted(set(funcs))),'score':score,'sha256':sha(p)}

def shell_rows(p,text,root,cfg):
    rows=[]
    for i,raw in enumerate(text.splitlines(),1):
        line=raw.strip(); low=line.lower()
        if not line or line.startswith(('#','::','REM ','rem ')) or not stage_hit(line,cfg): continue
        if 'python' not in low and not re.search(r'\bpy\b',low): continue
        score=25+25*('stage4b' in low)+20*any(a in line for a in cfg['config_argument_names'])+20*('config/stage4b' in low.replace('\\','/'))+10*any(t.lower() in low for t in cfg['writer_tokens'])
        rows.append({'source_type':'shell','path':rel(p,root),'line':i,'command':line,'score':score,'sha256':sha(p)})
    return rows

def flatten_json(v,prefix='$'):
    out=[]
    if isinstance(v,dict):
        for k,x in v.items(): out+=flatten_json(x,f'{prefix}.{k}')
    elif isinstance(v,list):
        for i,x in enumerate(v[:5000]): out+=flatten_json(x,f'{prefix}[{i}]')
    else: out.append((prefix,v))
    return out

def manifest_rows(p,root,cfg):
    if not p.exists(): return [],[]
    try: v=json.loads(p.read_text(encoding='utf-8'))
    except Exception: return [],[]
    evidence=[]; commands=[]
    for jp,val in flatten_json(v):
        s=str(val); kl=jp.lower(); sl=s.lower()
        if any(t in kl for t in ['command','argv','entry','runner','script','config','environment','seed','python']) or stage_hit(s,cfg):
            evidence.append({'path':rel(p,root),'json_path':jp,'value':s})
        if ('python' in sl or re.search(r'\bpy\b',sl)) and stage_hit(s,cfg):
            commands.append({'source_type':'manifest','path':rel(p,root),'line':jp,'command':s,'score':90,'sha256':sha(p)})
    return evidence,commands

def config_profile(p,root,cfg):
    row={'path':rel(p,root),'loadable':False,'stage4b_tokens':0,'output_path_fields':0,'seed_fields':0,'method_fields':0,'score':0,'sha256':sha(p),'load_error':''}
    try: v=load_cfg(p); row['loadable']=True
    except Exception as e: row['load_error']=f'{type(e).__name__}: {e}'; return row
    flat=flatten_json(v)
    row['stage4b_tokens']=sum(stage_hit(f'{a} {b}',cfg) for a,b in flat)
    row['output_path_fields']=sum(any(t in norm(a) for t in cfg['output_key_tokens']) or 'outputs_stage4b' in norm(b) for a,b in flat)
    row['seed_fields']=sum('seed' in norm(a) for a,_ in flat)
    row['method_fields']=sum(any(t in norm(a) for t in ['huber','gradient','bootstrap','pivot','block','tolerance']) for a,_ in flat)
    row['score']=50*('stage4b' in row['path'].lower())+min(row['stage4b_tokens'],10)+min(row['output_path_fields']*10,30)+min(row['seed_fields']*3,12)+min(row['method_fields'],15)
    return row

def choose(pyrows,runrows,cfgrows,cfg):
    py=next((r for r in sorted(pyrows,key=lambda x:(-x['score'],x['path'])) if r['score']>=45),None)
    runner=next((r for r in sorted(runrows,key=lambda x:(-x['score'],x['path'],str(x['line']))) if r['score']>=60),None)
    preferred=[]
    for pref in cfg['preferred_configs']:
        preferred += [r for r in cfgrows if r['path'].lower()==pref.lower()]
    cr=sorted(preferred or cfgrows,key=lambda x:(-x['score'],x['path']))
    conf=next((r for r in cr if r['score']>=40),None)
    return py,runner,conf

def patch_value(v,shadow,tokens,changes,path='$'):
    if isinstance(v,dict):
        out={}
        for k,x in v.items():
            kp=f'{path}.{k}'
            if any(t in norm(k) for t in tokens) and isinstance(x,str):
                out[k]=str(shadow).replace('\\','/'); changes.append({'config_path':kp,'old_value':x,'new_value':out[k],'reason':'output_key'})
            else: out[k]=patch_value(x,shadow,tokens,changes,kp)
        return out
    if isinstance(v,list): return [patch_value(x,shadow,tokens,changes,f'{path}[{i}]') for i,x in enumerate(v)]
    if isinstance(v,str) and 'outputs/stage4b' in v.replace('\\','/').lower():
        nv=re.sub(r'(?i)outputs/stage4b(?:/[^ \t\r\n]*)?',str(shadow).replace('\\','/'),v.replace('\\','/')); changes.append({'config_path':path,'old_value':v,'new_value':nv,'reason':'stage4b_literal'}); return nv
    return v

def redirect_command(cmd,orig,shadow_cfg,shadow_out):
    changes=[]; out=cmd
    variants=[str(orig),str(orig).replace('\\','/'),str(orig).replace('/','\\'),'config/stage4b.yml','config\\stage4b.yml','config/stage4b.yaml','config\\stage4b.yaml','config/stage4b.json','config\\stage4b.json']
    for x in sorted(set(variants),key=len,reverse=True):
        if x and x in out: out=out.replace(x,str(shadow_cfg)); changes.append({'item':'command','old_value':x,'new_value':str(shadow_cfg),'reason':'config_redirect'})
    for x in ['outputs/stage4b','outputs\\stage4b']:
        if x in out: out=out.replace(x,str(shadow_out)); changes.append({'item':'command','old_value':x,'new_value':str(shadow_out),'reason':'output_redirect'})
    out=re.sub(r'^\s*(?:call\s+)', '', out, flags=re.I)
    return out,changes

def safe_command(cmd,shadow_cfg,shadow_out,cfg_changes,runner):
    reasons=[]; low=cmd.lower().replace('\\','/')
    if not runner: reasons.append('no_exact_runner_or_manifest_command')
    if not cmd.strip(): reasons.append('empty_command')
    if not cfg_changes: reasons.append('no_redirectable_output_field_in_config')
    if str(shadow_cfg).lower().replace('\\','/') not in low and str(shadow_out).lower().replace('\\','/') not in low: reasons.append('command_not_redirected')
    if 'outputs/stage4b' in low: reasons.append('frozen_destination_remains')
    if any(x in f' {low} ' for x in [' del ',' erase ',' remove-item ',' rm -rf ',' rmdir ']): reasons.append('destructive_token')
    return not reasons,reasons

def execute(cmd,root,timeout):
    if os.name=='nt': r=subprocess.run(['cmd','/d','/s','/c',cmd],cwd=root,capture_output=True,text=True,timeout=timeout)
    else: r=subprocess.run(cmd,cwd=root,shell=True,capture_output=True,text=True,timeout=timeout)
    return {'command':cmd,'returncode':r.returncode,'stdout_tail':r.stdout[-10000:],'stderr_tail':r.stderr[-10000:]}

def replay_file(shadow):
    c=list(shadow.rglob('stage4b_global_gradient_estimates.csv')) or list(shadow.rglob('*global*gradient*estimate*.csv'))
    return sorted(c,key=lambda p:(p.stat().st_mtime,p.stat().st_size),reverse=True)[0] if c else None

def compare(a_path,b_path,cfg):
    a=pd.read_csv(a_path); b=pd.read_csv(b_path)
    keys=[x for x in ['label','model_id'] if x in a.columns and x in b.columns]
    if keys: a=a.sort_values(keys).reset_index(drop=True); b=b.sort_values(keys).reset_index(drop=True)
    schema=list(a.columns)==list(b.columns); rows=len(a)==len(b); colrows=[]; rowrows=[]; allok=schema and rows
    common=[x for x in a.columns if x in b.columns]
    for c in common:
        if rows and pd.api.types.is_numeric_dtype(a[c]) and pd.api.types.is_numeric_dtype(b[c]):
            aa=pd.to_numeric(a[c],errors='coerce'); bb=pd.to_numeric(b[c],errors='coerce'); mask=aa.notna()&bb.notna(); d=(aa[mask]-bb[mask]).abs() if mask.any() else pd.Series([0.0]); ma=float(d.max()); denom=aa[mask].abs().clip(lower=cfg['absolute_numeric_tolerance']) if mask.any() else pd.Series([1.0]); mr=float((d/denom).max()) if mask.any() else 0.0; ok=aa.isna().equals(bb.isna()) and ma<=cfg['absolute_numeric_tolerance'] and mr<=cfg['relative_numeric_tolerance']
            colrows.append({'column':c,'type':'numeric','max_abs_difference':ma,'max_relative_difference':mr,'passed':str(ok).lower()})
        elif rows:
            ok=a[c].fillna('<NA>').astype(str).equals(b[c].fillna('<NA>').astype(str)); colrows.append({'column':c,'type':'string_or_bool','max_abs_difference':'','max_relative_difference':'','passed':str(ok).lower()})
        else: ok=False; colrows.append({'column':c,'type':'uncompared','max_abs_difference':'','max_relative_difference':'','passed':'false'})
        allok &= ok
    for i in range(max(len(a),len(b))):
        mism=[]
        if i>=len(a) or i>=len(b): mism=['__row_presence__']
        else:
            for c in common:
                av,bv=a.iloc[i][c],b.iloc[i][c]
                if pd.isna(av) and pd.isna(bv): continue
                try:
                    if pd.api.types.is_number(av) and pd.api.types.is_number(bv):
                        if not math.isclose(float(av),float(bv),rel_tol=cfg['relative_numeric_tolerance'],abs_tol=cfg['absolute_numeric_tolerance']): mism.append(c)
                    elif str(av)!=str(bv): mism.append(c)
                except Exception:
                    if str(av)!=str(bv): mism.append(c)
        key='|'.join(str(a.iloc[i][k]) for k in keys) if i<len(a) and keys else ''
        rowrows.append({'row_index':i,'key':key,'mismatch_count':len(mism),'mismatch_columns':'|'.join(mism),'passed':str(not mism).lower()}); allok &= not mism
    critical=[c for c in cfg['critical_identity_columns'] if c in common]
    critical_ok=len(critical)>=10 and all(x['passed']=='true' for x in colrows if x['column'] in critical)
    result={'authoritative_path':str(a_path),'replay_path':str(b_path),'authoritative_sha256':sha(a_path),'replay_sha256':sha(b_path),'bitwise_identity':sha(a_path)==sha(b_path),'schema_identity':schema,'row_count_identity':rows,'critical_column_identity':critical_ok,'row_identity':all(x['passed']=='true' for x in rowrows),'scientific_identity':bool(allok and critical_ok),'authoritative_rows':len(a),'replay_rows':len(b)}
    return result,colrows,rowrows

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--project-root',default='.'); ap.add_argument('--no-execute',action='store_true'); args=ap.parse_args()
    root=Path(args.project_root).resolve(); cfg=json.loads((root/'config/stage6c2h_config.json').read_text(encoding='utf-8')); out=root/cfg['output_dir']
    if out.exists(): shutil.rmtree(out)
    for d in ['validation','summaries','tables','reports','shadow']: (out/d).mkdir(parents=True,exist_ok=True)
    authoritative=root/cfg['authoritative_estimates']
    if not authoritative.exists(): raise FileNotFoundError(authoritative)
    pyrows=[]; runrows=[]; cfgrows=[]; writer=[]
    for p in project_files(root,cfg,out):
        text=p.read_text(encoding='utf-8',errors='ignore')
        if p.suffix.lower()=='.py':
            r=python_profile(p,text,root,cfg); pyrows.append(r)
            if r['writer_token_hits']>0 and r['score']>0: writer.append(r)
        elif p.suffix.lower() in SHELL_SUFFIXES: runrows+=shell_rows(p,text,root,cfg)
        if p.suffix.lower() in CONFIG_SUFFIXES and (stage_hit(text,cfg) or 'stage4b' in rel(p,root).lower()): cfgrows.append(config_profile(p,root,cfg))
    manifest_evidence=[]
    for m in cfg['manifest_candidates']:
        e,c=manifest_rows(root/m,root,cfg); manifest_evidence+=e; runrows+=c
    py,runner,conf=choose(pyrows,runrows,cfgrows,cfg)
    write_csv(out/'tables/stage6c2h_writer_candidates.csv',['path','has_main_guard','argparse_present','config_arguments','writer_token_hits','stage_token_hits','main_functions','score','sha256'],sorted(writer,key=lambda x:(-x['score'],x['path'])))
    write_csv(out/'tables/stage6c2h_project_runner_candidates.csv',['source_type','path','line','command','score','sha256'],sorted(runrows,key=lambda x:(-x['score'],x['path'],str(x['line']))))
    write_csv(out/'tables/stage6c2h_config_candidates.csv',['path','loadable','stage4b_tokens','output_path_fields','seed_fields','method_fields','score','sha256','load_error'],sorted(cfgrows,key=lambda x:(-x['score'],x['path'])))
    write_csv(out/'tables/stage6c2h_manifest_lineage_evidence.csv',['path','json_path','value'],manifest_evidence)
    command=runner['command'] if runner else ''
    selected=[{'kind':'writer','selected':str(py is not None).lower(),'path':py['path'] if py else '','score':py['score'] if py else '','detail':py['config_arguments'] if py else ''},{'kind':'runner','selected':str(runner is not None).lower(),'path':runner['path'] if runner else '','score':runner['score'] if runner else '','detail':command},{'kind':'config','selected':str(conf is not None).lower(),'path':conf['path'] if conf else '','score':conf['score'] if conf else '','detail':''}]
    write_csv(out/'tables/stage6c2h_selected_lineage.csv',['kind','selected','path','score','detail'],selected)
    shadow=out/'shadow/stage4b_replay'; shadow.mkdir(parents=True,exist_ok=True); cfgchanges=[]; cmdchanges=[]; shadow_cfg=None; redirected=command
    if conf:
        orig=root/conf['path']; patched=patch_value(load_cfg(orig),shadow,cfg['output_key_tokens'],cfgchanges); shadow_cfg=out/'shadow/config'/orig.name; dump_cfg(shadow_cfg,patched); redirected,cmdchanges=redirect_command(command,orig,shadow_cfg,shadow)
    write_csv(out/'tables/stage6c2h_shadow_config_changes.csv',['config_path','old_value','new_value','reason'],cfgchanges); write_csv(out/'tables/stage6c2h_command_redirect_changes.csv',['item','old_value','new_value','reason'],cmdchanges)
    safety,reasons=(False,['config_not_identified']) if not shadow_cfg else safe_command(redirected,shadow_cfg,shadow,cfgchanges,runner)
    execution=[]; executed=False; success=False
    if cfg['allow_execution'] and not args.no_execute and safety:
        try: x=execute(redirected,root,cfg['execution_timeout_seconds']); execution=[x]; executed=True; success=x['returncode']==0
        except Exception as e: execution=[{'command':redirected,'returncode':-1,'stdout_tail':'','stderr_tail':f'{type(e).__name__}: {e}'}]; executed=True
    else: execution=[{'command':redirected,'returncode':'','stdout_tail':'','stderr_tail':'Execution skipped: '+', '.join(reasons if not safety else ['execution_disabled'])}]
    write_csv(out/'tables/stage6c2h_execution_audit.csv',['command','returncode','stdout_tail','stderr_tail'],execution)
    rp=replay_file(out/'shadow') if success else None; comparison={'schema_identity':False,'row_identity':False,'scientific_identity':False,'reason':'replay_table_not_generated'}; cr=[]; rr=[]
    if rp: comparison,cr,rr=compare(authoritative,rp,cfg)
    write_json(out/'summaries/stage6c2h_replay_comparison.json',comparison); write_csv(out/'tables/stage6c2h_replay_column_comparison.csv',['column','type','max_abs_difference','max_relative_difference','passed'],cr); write_csv(out/'tables/stage6c2h_replay_row_comparison.csv',['row_index','key','mismatch_count','mismatch_columns','passed'],rr)
    writer_ok=py is not None; entry_ok=bool(command); config_ok=conf is not None; runner_ok=runner is not None; identity=bool(comparison.get('scientific_identity')); exact=writer_ok and entry_ok and config_ok and runner_ok and safety and success and identity
    gates={'STAGE4B_PRODUCTION_WRITER_IDENTIFIED':writer_ok,'STAGE4B_ENTRYPOINT_IDENTIFIED':entry_ok,'STAGE4B_CONFIG_IDENTIFIED':config_ok,'STAGE4B_RUNNER_LINEAGE_IDENTIFIED':runner_ok,'SHADOW_REPLAY_SAFETY_READY':safety,'SHADOW_REPLAY_EXECUTED':success,'GLOBAL_REPLAY_SCHEMA_IDENTITY_READY':bool(comparison.get('schema_identity')),'GLOBAL_REPLAY_ROW_IDENTITY_READY':bool(comparison.get('row_identity')),'GLOBAL_REPLAY_IDENTITY_READY':identity,'EXACT_REPLAY_SPEC_READY':exact,'T06_EXACT_REPLAY_READY':exact}
    action={'STAGE4B_PRODUCTION_WRITER_IDENTIFIED':'Identify the original Stage-4B writer module.','STAGE4B_ENTRYPOINT_IDENTIFIED':'Identify the exact production command.','STAGE4B_CONFIG_IDENTIFIED':'Identify the exact Stage-4B config.','STAGE4B_RUNNER_LINEAGE_IDENTIFIED':'Locate the original batch/PowerShell/manifest command.','SHADOW_REPLAY_SAFETY_READY':'Expose a redirectable output path without touching frozen outputs.','SHADOW_REPLAY_EXECUTED':'Correct the exact production invocation.','GLOBAL_REPLAY_IDENTITY_READY':'Resolve remaining filter, weighting, seed, ordering, or solver differences.'}
    remaining=[{'gate':k,'required_action':action[k]} for k in action if not gates[k]]; write_csv(out/'tables/stage6c2h_remaining_closure_items.csv',['gate','required_action'],remaining)
    validation={'stage':STAGE,'protocol_version':PROTOCOL_VERSION,'implementation_version':IMPLEMENTATION_VERSION,'timestamp_utc':now(),'project_root':str(root),'writer_candidate_count':len(writer),'runner_candidate_count':len(runrows),'config_candidate_count':len(cfgrows),'manifest_lineage_evidence_count':len(manifest_evidence),'selected_command':redirected,'shadow_config':rel(shadow_cfg,root) if shadow_cfg else '','shadow_output':rel(shadow,root),'safety_blockers':reasons,'prior_stage_outputs_modified':False,**gates}; write_json(out/'validation/stage6c2h_validation.json',validation)
    summary={'stage':STAGE,'timestamp_utc':now(),'selected_lineage':selected,'replay_comparison':comparison,'remaining_closure_items':remaining,'scientific_disposition':'Exact Stage-4B identity closed; Stage-6D1 and matched-footprint work are authorized.' if exact else 'Exact replay closure remains incomplete; do not start matched-footprint gradient inference.'}; write_json(out/'summaries/stage6c2h_summary.json',summary)
    report=['# Stage-6C2H exact replay closure','',f'Generated: {now()}','',f'- Writer: `{py["path"] if py else "none"}`',f'- Runner: `{runner["path"] if runner else "none"}`',f'- Config: `{conf["path"] if conf else "none"}`',f'- Redirected command: `{redirected or "none"}`',f'- Shadow safety: `{safety}`',f'- Replay success: `{success}`',f'- Scientific identity: `{identity}`','','No Stage-6D3/6D4 gradient inference is authorized unless GLOBAL_REPLAY_IDENTITY_READY is true.','']; (out/'reports/stage6c2h_exact_replay_closure.md').write_text('\n'.join(report),encoding='utf-8')
    print(json.dumps({'validation':validation,'summary':summary},indent=2,ensure_ascii=False)); return 0
if __name__=='__main__': raise SystemExit(main())
