from __future__ import annotations
import argparse,csv,hashlib,json,re,shutil,zipfile
from datetime import datetime,timezone
from pathlib import Path
from typing import Any
STAGE='Stage-6C1 authoritative MNRAS source reconstruction and frozen-output linkage audit'
PROTOCOL_VERSION='1.0.0'; IMPLEMENTATION_VERSION='0.14.0'
def now(): return datetime.now(timezone.utc).isoformat()
def rjson(p:Path):
    with p.open('r',encoding='utf-8') as f: return json.load(f)
def wjson(p:Path,o:Any): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def wcsv(p:Path,fields:list[str],rows:list[dict[str,Any]]):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
def sha(p:Path):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda:f.read(1048576),b''): h.update(c)
    return h.hexdigest()
def rel(p:Path,r:Path): return str(p.relative_to(r)).replace('\\','/')
def norm(s:str): return re.sub(r'[^a-z0-9]+','_',s.lower()).strip('_')
def is_excluded(p:Path,root:Path,out:Path,ex:list[str]):
    if p==out or out in p.parents:return True
    x=rel(p,root).lower(); return any(x==e.lower() or x.startswith(e.lower().rstrip('/')+'/') for e in ex)
def headers(p:Path):
    try:
        if p.suffix.lower() in {'.csv','.tsv'}:
            with p.open('r',encoding='utf-8-sig',newline='') as f:return [x.lower() for x in next(csv.reader(f,delimiter='\t' if p.suffix.lower()=='.tsv' else ','),[])]
        if p.suffix.lower()=='.json':
            o=rjson(p); return [str(k).lower() for k in o.keys()] if isinstance(o,dict) else []
    except Exception:return []
    return []
def score(p:Path,a:dict,root:Path):
    blob=norm(rel(p,root)); s=0; why=[]
    for kw in a.get('keywords',[]):
        if norm(kw) in blob:s+=4;why.append('name:'+kw)
    if a['kind']=='table':
        hb=norm(' '.join(headers(p)))
        for g in a.get('column_groups',[]):
            if any(norm(x) in hb for x in g):s+=5;why.append('column:'+'/'.join(g))
        if 'validation' in blob or 'manifest' in blob:s-=2
    else:
        if p.suffix.lower() in {'.pdf','.png','.jpg','.jpeg','.eps'}:s+=3
        if 'figure' in blob or 'plot' in blob or '/fig' in rel(p,root).lower():s+=3
    return s,';'.join(why)
def main_tex(cls:str,bst:str):
    extra = r'\newenvironment{keywords}{\par\small\noindent\textbf{Key words: }}{\par}' if 'article' in cls else ''
    return rf'''{cls}
\usepackage[T1]{{fontenc}}\usepackage[utf8]{{inputenc}}
{extra}
\usepackage{{amsmath,amssymb,graphicx,booktabs,array,natbib,hyperref,microtype,xcolor}}
\title{{A probabilistic Gaia--APOGEE--GALAH red-giant chemo-kinematic atlas of the Milky Way}}
\author{{INSERT AUTHORS AND AFFILIATIONS}}\date{{}}
\begin{{document}}\maketitle
\input{{sections/00_abstract}}\input{{sections/01_introduction}}\input{{sections/02_data}}
\input{{sections/03_sample}}\input{{sections/04_calibration}}\input{{sections/05_methodology}}
\input{{sections/06_results}}\input{{sections/07_discussion}}\input{{sections/08_conclusions}}
\input{{sections/09_backmatter}}
\bibliographystyle{{{bst}}}\bibliography{{references}}\end{{document}}
'''
def slot(aid:str,cap:str,name:str|None):
    if name:return rf'''\begin{{figure*}}\centering\includegraphics[width=0.96\textwidth]{{figures/{name}}}\caption{{{cap}}}\label{{fig:{aid.lower()}}}\end{{figure*}}
'''
    return rf'''\begin{{figure*}}\centering\fbox{{\parbox[c][5cm][c]{{0.92\textwidth}}{{\centering Stage-6C1 figure slot {aid}.\\No authoritative local figure was linked.\\Regenerate or copy the frozen figure before Stage-6C2.}}}}\caption{{{cap} This visible placeholder is not a scientific result.}}\label{{fig:{aid.lower()}}}\end{{figure*}}
'''
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--project-root',default='.');args=ap.parse_args();root=Path(args.project_root).resolve()
    cfg=rjson(root/'config/stage6c1_config.json');out=root/cfg['output_dir']
    if out.exists():shutil.rmtree(out)
    for d in ['validation','summaries','tables','manuscript_source','checksums']:(out/d).mkdir(parents=True,exist_ok=True)
    p6a=root/'outputs/stage6a_claimsafe_closeout/validation/stage6a_validation.json';p6b=root/'outputs/stage6b_release_candidate/validation/stage6b_validation.json'
    v6a=rjson(p6a) if p6a.exists() else {};v6b=rjson(p6b) if p6b.exists() else {}
    g6a=bool(v6a.get('STAGE6A_CLOSEOUT_READY'));g6b=bool(v6b.get('STAGE6B_ARCHIVAL_RC_READY'))
    ts=set(x.lower() for x in cfg['table_suffixes']);fs=set(x.lower() for x in cfg['figure_suffixes']);files=[]
    for p in root.rglob('*'):
        if p.is_file() and not is_excluded(p,root,out,cfg['exclude_dirs']) and p.suffix.lower() in ts|fs:files.append(p)
    rows=[];by={}
    for a in cfg['assets']:
        ranked=[];eligible=ts if a['kind']=='table' else fs
        for p in files:
            if p.suffix.lower() not in eligible:continue
            sc,why=score(p,a,root)
            if sc>0:ranked.append({'asset_id':a['asset_id'],'kind':a['kind'],'asset_title':a['title'],'candidate_path':rel(p,root),'score':sc,'reason':why,'size_bytes':p.stat().st_size,'sha256':sha(p)})
        ranked.sort(key=lambda x:(-int(x['score']),x['candidate_path']));by[a['asset_id']]=ranked[:cfg.get('candidate_limit',10)];rows.extend(by[a['asset_id']])
    wcsv(out/'tables/stage6c1_asset_candidates.csv',['asset_id','kind','asset_title','candidate_path','score','reason','size_bytes','sha256'],rows)
    pkg=out/'manuscript_source'/cfg['package_name'];shutil.copytree(root/'templates/stage6c1',pkg,dirs_exist_ok=True);(pkg/'figures').mkdir(exist_ok=True);(pkg/'provenance').mkdir(exist_ok=True)
    links=[];lf=0;tc=0
    for a in cfg['assets']:
        best=by[a['asset_id']][0] if by[a['asset_id']] else None;status='missing';dest=''
        if a['kind']=='figure' and best and int(best['score'])>=10:
            src=root/best['candidate_path'];name=a['asset_id'].lower()+src.suffix.lower();shutil.copy2(src,pkg/'figures'/name);status='linked_candidate';dest='figures/'+name;lf+=1
        elif a['kind']=='table' and best and int(best['score'])>=10:status='candidate_identified';tc+=1
        links.append({'asset_id':a['asset_id'],'kind':a['kind'],'title':a['title'],'status':status,'selected_source':best['candidate_path'] if best else '','selected_score':best['score'] if best else '','manuscript_asset':dest})
    wcsv(out/'tables/stage6c1_manuscript_linkage.csv',['asset_id','kind','title','status','selected_source','selected_score','manuscript_asset'],links)
    shutil.copy2(out/'tables/stage6c1_asset_candidates.csv',pkg/'provenance/stage6c1_asset_candidates.csv');shutil.copy2(out/'tables/stage6c1_manuscript_linkage.csv',pkg/'provenance/stage6c1_manuscript_linkage.csv')
    cl=root/'outputs/stage6a_claimsafe_closeout/tables/stage6a_claim_ledger.csv'
    if cl.exists():shutil.copy2(cl,pkg/'provenance/stage6a_claim_ledger.csv')
    caps={'F01':'Cross-survey calibration diagnostics for the common-star layer.','F02':'Chemo-kinematic population structure in the homogenised feature space.','F03':'Distribution of maximum population probability and probabilistic class sizes.','F04':'Bootstrap intervals for global radial and vertical abundance gradients.','F05':'Survey-subset comparison of radial and vertical gradients.'}
    for aid in caps:
        l=next(x for x in links if x['asset_id']==aid);name=Path(l['manuscript_asset']).name if l['status']=='linked_candidate' else None;(pkg/'figures'/f'figure{aid[1:]}_slot.tex').write_text(slot(aid,caps[aid],name),encoding='utf-8')
    (pkg/'main.tex').write_text(main_tex(r'\documentclass[10pt,twocolumn]{article}','plainnat'),encoding='utf-8');(pkg/'main_mnras.tex').write_text(main_tex(r'\documentclass[fleqn,usenatbib]{mnras}','mnras'),encoding='utf-8')
    (pkg/'compile_fallback.bat').write_text('@echo off\ncd /d "%~dp0"\npdflatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1\nbibtex main || exit /b 1\npdflatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1\npdflatex -interaction=nonstopmode -halt-on-error main.tex || exit /b 1\n',encoding='utf-8')
    (pkg/'compile_mnras.bat').write_text('@echo off\ncd /d "%~dp0"\nif not exist mnras.cls (echo [ERROR] Copy official mnras.cls here.& exit /b 2)\npdflatex -interaction=nonstopmode -halt-on-error main_mnras.tex || exit /b 1\nbibtex main_mnras || exit /b 1\npdflatex -interaction=nonstopmode -halt-on-error main_mnras.tex || exit /b 1\npdflatex -interaction=nonstopmode -halt-on-error main_mnras.tex || exit /b 1\n',encoding='utf-8')
    (pkg/'AUTHOR_METADATA.yaml').write_text('title: A probabilistic Gaia–APOGEE–GALAH red-giant chemo-kinematic atlas of the Milky Way\nauthors:\n  - name: INSERT FULL NAME\n    affiliation_ids: [1]\n    email: INSERT EMAIL\n    orcid: INSERT ORCID\naffiliations:\n  - id: 1\n    text: INSERT AFFILIATION\ncorresponding_author: INSERT NAME\nfunding:\n  - INSERT FUNDING OR NONE\nrepository_url: INSERT_REPOSITORY_URL\nzenodo_exact_version_doi: INSERT_EXACT_VERSION_DOI\nzenodo_concept_doi: INSERT_CONCEPT_DOI\n',encoding='utf-8')
    (pkg/'README.md').write_text('# RGB atlas MNRAS source v0.14.0\n\n`main.tex` is a generic compile target. `main_mnras.tex` requires official `mnras.cls`. Snapshot tables must be reconciled against frozen products. Visible figure placeholders must be replaced by actual frozen figures, never PDF screenshots.\n',encoding='utf-8')
    ph=[]
    for p in pkg.rglob('*'):
        if p.is_file() and p.suffix.lower() in {'.tex','.bib','.yaml','.md'}:
            txt=p.read_text(encoding='utf-8',errors='ignore')
            for m in ['INSERT ','INSERT_','STAGE6C2 VERIFY','placeholder']:
                c=txt.count(m)
                if c:ph.append({'path':rel(p,pkg),'marker':m,'count':c})
    wcsv(out/'tables/stage6c1_placeholder_audit.csv',['path','marker','count'],ph)
    if (root/'mnras.cls').exists():shutil.copy2(root/'mnras.cls',pkg/'mnras.cls')
    sr=all((pkg/x).exists() for x in ['main.tex','main_mnras.tex','references.bib','AUTHOR_METADATA.yaml']) and len(list((pkg/'sections').glob('*.tex')))>=10
    tr=tc==6;fr=lf==5;mr=(pkg/'mnras.cls').exists();br='STAGE6C2 VERIFY' not in (pkg/'references.bib').read_text(encoding='utf-8');ar='INSERT' not in (pkg/'AUTHOR_METADATA.yaml').read_text(encoding='utf-8') and 'INSERT' not in (pkg/'main_mnras.tex').read_text(encoding='utf-8')
    val={'stage':STAGE,'protocol_version':PROTOCOL_VERSION,'implementation_version':IMPLEMENTATION_VERSION,'timestamp_utc':now(),'project_root':str(root),'stage6a_closeout_ready':g6a,'stage6b_archival_rc_ready':g6b,'source_package':rel(pkg,root),'section_file_count':len(list((pkg/'sections').glob('*.tex'))),'table_file_count':len(list((pkg/'tables').glob('*.tex'))),'figure_slot_count':len(list((pkg/'figures').glob('*_slot.tex'))),'linked_figure_count':lf,'table_assets_with_candidates':tc,'placeholder_audit_row_count':len(ph),'prior_stage_outputs_modified':False,'STAGE6C1_SOURCE_TREE_READY':sr,'TABLE_PROVENANCE_CANDIDATES_READY':tr,'FIGURE_LINKAGE_READY':fr,'MNRAS_TEMPLATE_READY':mr,'BIBLIOGRAPHY_VERIFICATION_READY':br,'AUTHOR_METADATA_READY':ar,'STAGE6C1_AUTHORITATIVE_READY':bool(g6a and g6b and sr and tr and fr and mr and br and ar)}
    msgs={'TABLE_PROVENANCE_CANDIDATES_READY':'One or more tables lack a strong frozen-output candidate.','FIGURE_LINKAGE_READY':'One or more figures lack an actual local frozen product.','MNRAS_TEMPLATE_READY':'Official mnras.cls is absent.','BIBLIOGRAPHY_VERIFICATION_READY':'One or more BibTeX entries remain provisional.','AUTHOR_METADATA_READY':'Author, affiliation, ORCID, funding, repository, or DOI placeholders remain.'};missing=[{'gate':g,'required_action':m} for g,m in msgs.items() if not val[g]];wcsv(out/'tables/stage6c1_missing_closure_items.csv',['gate','required_action'],missing)
    summary={'stage':STAGE,'timestamp_utc':now(),'source_tree_ready':sr,'authoritative_ready':val['STAGE6C1_AUTHORITATIVE_READY'],'linked_figures':lf,'table_assets_with_candidates':tc,'remaining_closure_items':missing,'scientific_disposition':'Modular manuscript source reconstructed. Stage-6C2 must reconcile snapshot numbers, figures, bibliography, metadata, and Zenodo consistency.'};wjson(out/'summaries/stage6c1_summary.json',summary)
    man=[]
    for p in sorted(pkg.rglob('*')):
        if p.is_file():man.append({'path':rel(p,pkg),'size_bytes':p.stat().st_size,'sha256':sha(p)})
    wjson(pkg/'PROVENANCE_MANIFEST.json',{'stage':STAGE,'created_utc':now(),'files':man});files2=[p for p in sorted(pkg.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt'];(pkg/'SHA256SUMS.txt').write_text('\n'.join(f'{sha(p)}  {rel(p,pkg)}' for p in files2)+'\n',encoding='utf-8')
    zp=out/'manuscript_source'/f"{cfg['package_name']}.zip"
    with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(pkg.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(pkg.parent))
    val.update({'source_zip':rel(zp,root),'source_zip_size_bytes':zp.stat().st_size,'source_zip_sha256':sha(zp)});wjson(out/'validation/stage6c1_validation.json',val)
    print(json.dumps({'validation':val,'summary':summary},indent=2,ensure_ascii=False));return 0 if sr and g6a and g6b else 2
if __name__=='__main__':raise SystemExit(main())
