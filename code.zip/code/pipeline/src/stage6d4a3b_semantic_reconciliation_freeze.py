from __future__ import annotations
import argparse, hashlib, json, shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd

def now():
    return datetime.now(timezone.utc).isoformat()

def canonical_bytes(obj: Any)->bytes:
    return json.dumps(
        obj, sort_keys=True, separators=(",",":"), ensure_ascii=False,
        allow_nan=False
    ).encode("utf-8")

def sha_file(path: Path)->str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def wjson(path: Path,obj: Any):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(
        json.dumps(obj,indent=2,ensure_ascii=False,default=str)+"\n",
        encoding="utf-8"
    )

def read_table(path: Path):
    if path.suffix.lower()==".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower()==".feather":
        return pd.read_feather(path)
    return pd.read_csv(path)

def resolve(cols,cands):
    return next((x for x in cands if x in cols),None)

def exact_id_series(s,name):
    out=[]
    for i,v in enumerate(s):
        if pd.isna(v):
            out.append(pd.NA); continue
        if isinstance(v,(int,np.integer)):
            if int(v)<0: raise ValueError(f"{name}: negative source id at {i}")
            out.append(str(int(v))); continue
        if isinstance(v,(float,np.floating)):
            if (not np.isfinite(v)) or (not float(v).is_integer()) or abs(float(v))>2**53:
                raise ValueError(f"{name}: unsafe float source id at {i}: {v!r}")
            out.append(str(int(v))); continue
        t=str(v).strip()
        if not t.isdigit():
            raise ValueError(f"{name}: non-digit source id at {i}: {v!r}")
        out.append(str(int(t)))
    return pd.Series(out,dtype="string")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--project-root",default=".")
    args=ap.parse_args()
    root=Path(args.project_root).resolve()
    cfg=json.loads((root/"config/stage6d4a3b_config.json").read_text(encoding="utf-8"))

    out=root/cfg["output_dir"]
    if out.exists():
        shutil.rmtree(out)
    for d in ["validation","freeze","tables","lineage","summaries","manifest"]:
        (out/d).mkdir(parents=True,exist_ok=True)

    v3=json.loads((root/cfg["d4a3_validation"]).read_text(encoding="utf-8"))
    v3a=json.loads((root/cfg["d4a3a_validation"]).read_text(encoding="utf-8"))

    prereq=bool(
        v3.get("D4A2_PREREQUISITE_READY",False)
        and v3.get("GAIA_HEALPIX5_COMPLETE_READY",False)
        and v3.get("MINIMUM_100_SPATIAL_BLOCKS_READY",False)
        and v3.get("ROW_COUNT_CONSERVATION_READY",False)
        and v3.get("ROW_ORDER_CONSERVATION_READY",False)
        and v3.get("FINAL_BALANCE_WEIGHT_IDENTITY_READY",False)
        and (v3.get("SURVEY_IDENTITY_READY",True) is False)
        and v3a.get("STAGE6D4A3A_SURVEY_AUDIT_READY",False)
        and v3a.get("STAGE6D4A3B_SEMANTIC_RECONCILIATION_READY",False)
        and v3a.get("SURVEY_FAMILY_IDENTITY_READY",False)
        and v3a.get("TRUE_SURVEY_FAMILY_MISMATCH_COUNT",1)==0
    )

    augp=root/cfg["d4a3_augmented_source"]
    balp=root/cfg["d3c9_balanced_source"]
    s4p=root/cfg["stage4a_source"]
    if not all(p.exists() for p in [augp,balp,s4p]):
        raise FileNotFoundError("required source missing")

    aug=read_table(augp).reset_index(drop=True)
    bal=read_table(balp).reset_index(drop=True)
    s4=read_table(s4p)

    aid=resolve(aug.columns,cfg["source_id_candidates"])
    bid=resolve(bal.columns,cfg["source_id_candidates"])
    sid=resolve(s4.columns,cfg["stage4a_source_id_candidates"])
    if not all([aid,bid,sid]):
        raise RuntimeError("source id column unresolved")

    for col in [cfg["balanced_survey_column"],cfg["balance_weight_column"]]:
        if col not in aug.columns or col not in bal.columns:
            raise RuntimeError(f"required balanced column missing: {col}")
    if cfg["block_column"] not in aug.columns:
        raise RuntimeError("augmented gaia_healpix5 missing")
    if cfg["stage4a_survey_column"] not in s4.columns:
        raise RuntimeError("stage4a survey_origin missing")

    aug["_id"]=exact_id_series(aug[aid],"augmented")
    bal["_id"]=exact_id_series(bal[bid],"balanced")
    s4["_id"]=exact_id_series(s4[sid],"stage4a")

    row_count_ready=(len(aug)==cfg["expected_rows"]==len(bal))
    row_order_ready=(aug["_id"].tolist()==bal["_id"].tolist())
    survey_same_as_balanced=aug[cfg["balanced_survey_column"]].astype(str).equals(
        bal[cfg["balanced_survey_column"]].astype(str)
    )
    weight_identity=bool(np.array_equal(
        pd.to_numeric(aug[cfg["balance_weight_column"]],errors="coerce").to_numpy(float),
        pd.to_numeric(bal[cfg["balance_weight_column"]],errors="coerce").to_numpy(float),
        equal_nan=True
    ))

    # Exact Stage4A source->raw survey consistency.
    raw_rows=[]
    conflicts=[]
    for key,g in s4[["_id",cfg["stage4a_survey_column"]]].groupby("_id",sort=False,dropna=False):
        vals=g[cfg["stage4a_survey_column"]].dropna().astype(str).unique()
        if len(vals)==1:
            raw_rows.append({"_id":key,"stage4a_survey_raw":vals[0]})
        else:
            conflicts.append({"source_id":key,"raw_values":"|".join(map(str,vals))})
    raw=pd.DataFrame(raw_rows)
    if conflicts:
        pd.DataFrame(conflicts).to_csv(
            out/"tables/stage6d4a3b_stage4a_survey_conflicts.csv",index=False
        )

    m=aug[["_id",cfg["balanced_survey_column"],cfg["block_column"]]].merge(
        raw,on="_id",how="left",validate="many_to_one",sort=False
    )
    semantic_map=cfg["semantic_map"]
    m["mapped_stage4a_survey"]=m["stage4a_survey_raw"].map(semantic_map)
    m["semantic_identity"]=(
        m["mapped_stage4a_survey"].astype(str)
        == m[cfg["balanced_survey_column"]].astype(str)
    )

    mapping_complete=bool(m["mapped_stage4a_survey"].notna().all())
    semantic_identity_ready=bool(mapping_complete and m["semantic_identity"].all())
    semantic_mismatch_count=int((~m["semantic_identity"]).sum()) if mapping_complete else int(len(m))

    counts=aug[cfg["balanced_survey_column"]].astype(str).value_counts().to_dict()
    counts_ready=all(int(counts.get(k,0))==int(v) for k,v in cfg["expected_counts"].items())

    block_numeric=pd.to_numeric(aug[cfg["block_column"]],errors="coerce")
    block_complete=bool(np.isfinite(block_numeric).all())
    block_count=int(block_numeric.nunique()) if block_complete else 0
    block_count_ready=bool(
        block_count==int(cfg["expected_block_count"])
        and block_count>=int(cfg["minimum_block_count"])
    )

    semantic_contract={
        "stage":"Stage-6D4A3B frozen survey semantic reconciliation",
        "semantic_map":semantic_map,
        "basis":{
            "raw_normalized_identity_rate":v3a.get("RAW_NORMALIZED_SURVEY_IDENTITY_RATE"),
            "survey_family_identity_rate":v3a.get("SURVEY_FAMILY_IDENTITY_RATE"),
            "true_survey_family_mismatch_count":v3a.get("TRUE_SURVEY_FAMILY_MISMATCH_COUNT"),
            "raw_crosstab_expected":{
                "APOGEE_NATIVE":{"APOGEE_only":10853,"GALAH_only":0},
                "GALAH_CORRECTED":{"APOGEE_only":0,"GALAH_only":23324}
            }
        },
        "scope":"survey naming reconciliation only",
        "prohibitions":[
            "no science outcome used",
            "no abundance used",
            "no R or abs_Z used",
            "no weight modification",
            "no block substitution",
            "no sample modification"
        ]
    }
    canonical=canonical_bytes(semantic_contract)
    semantic_sha=hashlib.sha256(canonical).hexdigest()

    wjson(out/"freeze/stage6d4a3b_survey_semantic_map.json",semantic_contract)
    (out/"freeze/stage6d4a3b_survey_semantic_map_canonical.json").write_bytes(canonical)

    mapping_table=pd.DataFrame([
        {"stage4a_raw":k,"d3c9_canonical":v}
        for k,v in semantic_map.items()
    ])
    mapping_table.to_csv(out/"tables/stage6d4a3b_semantic_map.csv",index=False)

    cross=pd.crosstab(
        m[cfg["balanced_survey_column"]],
        m["stage4a_survey_raw"],
        dropna=False
    )
    cross.to_csv(out/"tables/stage6d4a3b_revalidated_raw_crosstab.csv")

    ready=bool(
        prereq
        and row_count_ready
        and row_order_ready
        and survey_same_as_balanced
        and weight_identity
        and len(conflicts)==0
        and mapping_complete
        and semantic_identity_ready
        and counts_ready
        and block_complete
        and block_count_ready
    )

    lineage={
        "d3c9_balanced_source":str(balp.relative_to(root)).replace("\\","/"),
        "d3c9_balanced_source_sha256":sha_file(balp),
        "d4a3_augmented_source":str(augp.relative_to(root)).replace("\\","/"),
        "d4a3_augmented_source_sha256":sha_file(augp),
        "stage4a_source":str(s4p.relative_to(root)).replace("\\","/"),
        "stage4a_source_sha256":sha_file(s4p),
        "semantic_map_canonical_sha256":semantic_sha
    }
    wjson(out/"lineage/stage6d4a3b_lineage.json",lineage)

    validation={
        "stage":cfg["stage"],
        "protocol_version":cfg["protocol_version"],
        "implementation_version":cfg["implementation_version"],
        "timestamp_utc":now(),
        "D4A3A_PREREQUISITE_READY":prereq,
        "SEMANTIC_MAP_CANONICAL_SHA256":semantic_sha,
        "SEMANTIC_MAP_EXACT":{
            "APOGEE_only":"APOGEE_NATIVE",
            "GALAH_only":"GALAH_CORRECTED"
        },
        "ROW_COUNT_IDENTITY_READY":row_count_ready,
        "ROW_ORDER_IDENTITY_READY":row_order_ready,
        "SURVEY_COLUMN_UNCHANGED_FROM_D3C9_READY":survey_same_as_balanced,
        "FINAL_BALANCE_WEIGHT_IDENTITY_READY":weight_identity,
        "STAGE4A_RAW_SURVEY_CONSISTENCY_READY":len(conflicts)==0,
        "SEMANTIC_MAPPING_COMPLETE_READY":mapping_complete,
        "SEMANTIC_SURVEY_IDENTITY_READY":semantic_identity_ready,
        "SEMANTIC_SURVEY_MISMATCH_COUNT":semantic_mismatch_count,
        "EXPECTED_SURVEY_COUNTS_READY":counts_ready,
        "GAIA_HEALPIX5_COMPLETE_READY":block_complete,
        "GAIA_HEALPIX5_BLOCK_COUNT":block_count,
        "GAIA_HEALPIX5_BLOCK_COUNT_IDENTITY_READY":block_count_ready,
        "NO_SCIENCE_OUTCOME_USED":True,
        "NO_SAMPLE_OR_WEIGHT_MODIFICATION_USED":True,
        "NO_BOOTSTRAP_BLOCK_SUBSTITUTION_USED":True,
        "STAGE6D4A3B_SEMANTIC_RECONCILIATION_READY":ready,
        "STAGE6D4B_EXACT_PRODUCTION_FITS_READY":ready
    }
    wjson(out/"validation/stage6d4a3b_validation.json",validation)
    wjson(out/"summaries/stage6d4a3b_summary.json",{
        "ready":ready,
        "scientific_disposition":(
            "Survey naming mismatch is fully reconciled by an exact frozen semantic map; "
            "the D4A3 augmented source preserves D3C9 rows, order, weights, and the "
            "restored gaia_healpix5 block. D4B exact production fits are authorized."
            if ready else
            "Semantic reconciliation failed at least one identity gate; D4B remains blocked."
        ),
        "next_action":"Run Stage-6D4B exact production fits." if ready else "Inspect failed identity gate."
    })

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and "manifest" not in p.parts:
            manifest.append({
                "path":str(p.relative_to(root)).replace("\\","/"),
                "size_bytes":p.stat().st_size,
                "sha256":sha_file(p)
            })
    pd.DataFrame(manifest).to_csv(
        out/"manifest/stage6d4a3b_output_manifest_sha256.csv",index=False
    )

    print(json.dumps({"validation":validation},indent=2,ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
