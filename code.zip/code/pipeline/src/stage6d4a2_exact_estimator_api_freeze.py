from __future__ import annotations
import argparse,ast,hashlib,inspect,json,shutil,sys
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd

def now():return datetime.now(timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1048576),b""):h.update(b)
 return h.hexdigest()
def wj(p,o):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,indent=2,default=str)+"\n",encoding="utf-8")
def find_common(root,cands):
 for c in cands:
  p=root/c
  if p.exists():return p
 return None
def imported_names(script_path):
 t=ast.parse(script_path.read_text(encoding="utf-8",errors="ignore"))
 names=[]
 for n in ast.walk(t):
  if isinstance(n,ast.ImportFrom) and n.module=="stage4b_common":
   names.extend([a.name for a in n.names])
 return sorted(set(names))
def function_inventory(path):
 t=ast.parse(path.read_text(encoding="utf-8",errors="ignore"))
 rows=[]
 for n in t.body:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
   args=[a.arg for a in n.args.args]
   rows.append({"name":n.name,"args":args,"lineno":n.lineno})
 return rows
def main():
 ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");a=ap.parse_args()
 root=Path(a.project_root).resolve();c=json.loads((root/"config/stage6d4a2_config.json").read_text())
 out=root/c["output_dir"]
 if out.exists():shutil.rmtree(out)
 for d in ["validation","lineage","tables","summaries"]:(out/d).mkdir(parents=True,exist_ok=True)
 pre=json.loads((root/c["d4a1_validation"]).read_text())
 prereq=bool(pre.get("STAGE6D4A1_SCHEMA_PREFLIGHT_READY") and pre.get("STAGE6D4B_PRODUCTION_FITS_READY"))
 sp=root/c["stage4b_script"];cp=find_common(root,c["stage4b_common_candidates"]);yp=root/c["stage4b_config"];bp=root/c["balanced_source"]
 if not sp.exists():raise FileNotFoundError(str(sp))
 if not cp:raise FileNotFoundError("stage4b_common.py not found")
 if not yp.exists():raise FileNotFoundError(str(yp))
 if not bp.exists():raise FileNotFoundError(str(bp))
 df=pd.read_parquet(bp)
 block_present=c["required_original_block_column"] in df.columns
 block_count=int(df[c["required_original_block_column"]].nunique()) if block_present else 0
 footprint_present=c["common_footprint_cell_column"] in df.columns
 imported=imported_names(sp);funcs=function_inventory(cp)
 fnames={x["name"] for x in funcs}
 reusable=[n for n in imported if n in fnames]
 sys.path.insert(0,str(cp.parent))
 mod=__import__("stage4b_common")
 sigs={}
 for n in reusable:
  obj=getattr(mod,n,None)
  if callable(obj):
   try:sigs[n]=str(inspect.signature(obj))
   except:sigs[n]="<signature unavailable>"
 config_text=yp.read_text(encoding="utf-8",errors="ignore")
 checks={
 "HUBER_1P345_CONFIG_READY":"1.345" in config_text,
 "TOL_1E10_CONFIG_READY":("1.0e-10" in config_text or "1e-10" in config_text),
 "MAXITER_100_CONFIG_READY":("maximum_iterations: 100" in config_text),
 "MIN_SCALE_1E8_CONFIG_READY":("1.0e-8" in config_text or "1.0e-08" in config_text),
 "FULL_DRAWS_4096_CONFIG_READY":"4096" in config_text,
 "CONVERGENCE_DRAWS_2048_CONFIG_READY":"2048" in config_text,
 "FINITE_CLUSTER_CORRECTION_READY":"finite_cluster_correction: true" in config_text.lower(),
 "RADEMACHER_METHOD_READY":"Rademacher" in config_text,
 "ORIGINAL_BLOCK_CONFIG_READY":"gaia_healpix5" in config_text
 }
 api_ready=bool(len(reusable)>0 and all(checks.values()))
 block_ready=bool(block_present and block_count>=c["required_method"]["minimum_spatial_blocks"])
 ready=bool(prereq and api_ready and block_ready)
 pd.DataFrame(funcs).to_csv(out/"tables/stage6d4a2_stage4b_common_function_inventory.csv",index=False)
 pd.DataFrame([{"imported_name":n,"defined_in_common":n in fnames,"signature":sigs.get(n,"")} for n in imported]).to_csv(out/"tables/stage6d4a2_import_api_resolution.csv",index=False)
 wj(out/"lineage/stage6d4a2_exact_estimator_contract.json",{
 "stage4b_script":str(sp.relative_to(root)).replace("\\","/"),"stage4b_script_sha256":sha(sp),
 "stage4b_common":str(cp.relative_to(root)).replace("\\","/"),"stage4b_common_sha256":sha(cp),
 "stage4b_config":str(yp.relative_to(root)).replace("\\","/"),"stage4b_config_sha256":sha(yp),
 "imported_stage4b_common_names":imported,"reusable_function_names":reusable,"reusable_signatures":sigs,
 "required_original_block_column":c["required_original_block_column"],"block_present":block_present,"block_count":block_count,
 "common_footprint_cell_present":footprint_present,"frozen_method":c["required_method"],"config_checks":checks})
 val={"stage":c["stage"],"protocol_version":c["protocol_version"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
 "D4A1_PREREQUISITE_READY":prereq,"STAGE4B_COMMON_MODULE_READY":True,"STAGE4B_IMPORTED_API_RESOLVED":len(reusable)>0,
 "FROZEN_METHOD_CONFIG_IDENTITY_READY":all(checks.values()),"ORIGINAL_GAIA_HEALPIX5_BLOCK_PRESENT":block_present,
 "ORIGINAL_GAIA_HEALPIX5_BLOCK_COUNT":block_count,"MINIMUM_100_SPATIAL_BLOCKS_READY":block_ready,
 "COMMON_FOOTPRINT_NSIDE16_CELL_PRESENT":footprint_present,"NO_BOOTSTRAP_BLOCK_SUBSTITUTION_USED":True,
 "NO_SCIENCE_FIT_PERFORMED":True,"STAGE6D4A2_EXACT_ESTIMATOR_API_READY":ready,"STAGE6D4B_EXACT_PRODUCTION_FITS_READY":ready}
 wj(out/"validation/stage6d4a2_validation.json",val)
 wj(out/"summaries/stage6d4a2_summary.json",{"ready":ready,"reusable_function_names":reusable,"bootstrap_block":c["required_original_block_column"] if block_ready else None,"next_action":"Run exact D4B production fits using frozen Stage4B API." if ready else "Do not run D4B; inspect API/block failure."})
 print(json.dumps({"validation":val,"reusable_function_names":reusable,"signatures":sigs},indent=2));return 0
if __name__=="__main__":raise SystemExit(main())
