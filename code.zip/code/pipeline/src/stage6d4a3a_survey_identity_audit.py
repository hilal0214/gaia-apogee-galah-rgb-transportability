from __future__ import annotations
import argparse,json,shutil
from datetime import datetime,timezone
from pathlib import Path
import numpy as np,pandas as pd

def now(): return datetime.now(timezone.utc).isoformat()
def wj(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8")
def rt(p):
    return pd.read_parquet(p) if p.suffix.lower()==".parquet" else pd.read_csv(p)
def resolve(cols,cands):
    return next((x for x in cands if x in cols),None)
def exact_id(s):
    out=[]
    for v in s:
        if pd.isna(v): out.append(pd.NA); continue
        if isinstance(v,(int,np.integer)): out.append(str(int(v))); continue
        if isinstance(v,(float,np.floating)):
            if not np.isfinite(v) or not float(v).is_integer() or abs(float(v))>2**53:
                raise ValueError(f"unsafe float source id: {v!r}")
            out.append(str(int(v))); continue
        t=str(v).strip()
        if not t.isdigit(): raise ValueError(f"non-digit source id: {v!r}")
        out.append(str(int(t)))
    return pd.Series(out,dtype="string")
def norm(x):
    return str(x).strip().upper().replace(" ","_").replace("-","_")
def family(x):
    t=norm(x)
    if "APOGEE" in t: return "APOGEE"
    if "GALAH" in t: return "GALAH"
    return t
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",default=".");a=ap.parse_args()
    root=Path(a.project_root).resolve()
    c=json.loads((root/"config/stage6d4a3a_config.json").read_text())
    out=root/c["output_dir"]
    if out.exists(): shutil.rmtree(out)
    for d in ["validation","tables","summaries"]:(out/d).mkdir(parents=True,exist_ok=True)

    pre=json.loads((root/c["d4a3_validation"]).read_text())
    prereq=bool(
        pre.get("D4A2_PREREQUISITE_READY",False)
        and pre.get("GAIA_HEALPIX5_COMPLETE_READY",False)
        and pre.get("MINIMUM_100_SPATIAL_BLOCKS_READY",False)
        and pre.get("SURVEY_IDENTITY_READY",True) is False
        and pre.get("ROW_COUNT_CONSERVATION_READY",False)
        and pre.get("ROW_ORDER_CONSERVATION_READY",False)
        and pre.get("FINAL_BALANCE_WEIGHT_IDENTITY_READY",False)
    )

    b=rt(root/c["balanced_source"]).reset_index(drop=True)
    s=rt(root/c["stage4a_source"])
    bid=resolve(b.columns,c["balanced_id_candidates"])
    sid=resolve(s.columns,c["stage4a_id_candidates"])
    bsur=resolve(b.columns,c["balanced_survey_candidates"])
    ssur=resolve(s.columns,c["stage4a_survey_candidates"])
    if not all([bid,sid,bsur,ssur]): raise RuntimeError("required columns unresolved")
    if c["block_column"] not in s.columns: raise RuntimeError("gaia_healpix5 missing in Stage4A")

    b2=b[[bid,bsur]].copy()
    b2["_id"]=exact_id(b2[bid])
    s2=s[[sid,ssur,c["block_column"]]].copy()
    s2["_id"]=exact_id(s2[sid])

    # collapse Stage4A only where raw survey and block are internally unique per source
    rows=[]; conflicts=[]
    for key,g in s2.groupby("_id",sort=False,dropna=False):
        surv=[x for x in g[ssur].dropna().astype(str).unique()]
        blocks=[x for x in pd.to_numeric(g[c["block_column"]],errors="coerce").dropna().unique()]
        if len(surv)==1 and len(blocks)==1:
            rows.append({"_id":key,"stage4a_survey_raw":surv[0],"gaia_healpix5":blocks[0]})
        else:
            conflicts.append({"source_id":key,"survey_values":"|".join(surv),"block_values":"|".join(map(str,blocks))})
    su=pd.DataFrame(rows)
    m=b2.merge(su,on="_id",how="left",validate="many_to_one",sort=False)
    m["balanced_survey_raw"]=m[bsur].astype(str)
    m["balanced_norm"]=m["balanced_survey_raw"].map(norm)
    m["stage4a_norm"]=m["stage4a_survey_raw"].map(norm)
    m["balanced_family"]=m["balanced_survey_raw"].map(family)
    m["stage4a_family"]=m["stage4a_survey_raw"].map(family)
    m["raw_exact"]=m["balanced_norm"]==m["stage4a_norm"]
    m["family_exact"]=m["balanced_family"]==m["stage4a_family"]

    raw_cross=pd.crosstab(m["balanced_survey_raw"],m["stage4a_survey_raw"],dropna=False)
    raw_cross.to_csv(out/"tables/stage6d4a3a_raw_survey_crosstab.csv")
    fam_cross=pd.crosstab(m["balanced_family"],m["stage4a_family"],dropna=False)
    fam_cross.to_csv(out/"tables/stage6d4a3a_family_survey_crosstab.csv")

    uniq=pd.DataFrame({
        "balanced_unique":pd.Series(sorted(m["balanced_survey_raw"].dropna().unique())),
        "stage4a_unique":pd.Series(sorted(m["stage4a_survey_raw"].dropna().unique()))
    })
    uniq.to_csv(out/"tables/stage6d4a3a_unique_survey_labels.csv",index=False)

    mism=m.loc[~m["family_exact"],["_id","balanced_survey_raw","stage4a_survey_raw","balanced_family","stage4a_family","gaia_healpix5"]]
    mism.head(int(c["max_mismatch_examples"])).to_csv(out/"tables/stage6d4a3a_family_mismatch_examples.csv",index=False)

    raw_rate=float(m["raw_exact"].mean())
    fam_rate=float(m["family_exact"].mean())
    complete=bool(m["stage4a_survey_raw"].notna().all())
    family_identity=bool(complete and m["family_exact"].all())
    label_only=bool(family_identity and not m["raw_exact"].all())

    # Exact semantic disposition only; no production file is modified here.
    if family_identity:
        disposition="SURVEY_FAMILY_IDENTITY_CONFIRMED_LABEL_SEMANTICS_ONLY"
    elif complete:
        disposition="TRUE_SURVEY_FAMILY_MISMATCH_PRESENT"
    else:
        disposition="INCOMPLETE_STAGE4A_SURVEY_LINKAGE"

    val={
        "stage":c["stage"],"protocol_version":c["protocol_version"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),
        "D4A3_PREREQUISITE_READY":prereq,
        "BALANCED_SURVEY_COLUMN":bsur,"STAGE4A_SURVEY_COLUMN":ssur,
        "STAGE4A_SURVEY_LINKAGE_COMPLETE":complete,
        "RAW_NORMALIZED_SURVEY_IDENTITY_RATE":raw_rate,
        "SURVEY_FAMILY_IDENTITY_RATE":fam_rate,
        "SURVEY_FAMILY_IDENTITY_READY":family_identity,
        "LABEL_SEMANTICS_ONLY_MISMATCH":label_only,
        "TRUE_SURVEY_FAMILY_MISMATCH_COUNT":int((~m["family_exact"]).sum()),
        "NO_SCIENCE_OUTCOME_USED":True,
        "NO_BLOCK_SUBSTITUTION_USED":True,
        "SCIENTIFIC_DISPOSITION":disposition,
        "STAGE6D4A3A_SURVEY_AUDIT_READY":bool(prereq and complete),
        "STAGE6D4A3B_SEMANTIC_RECONCILIATION_READY":bool(prereq and family_identity)
    }
    wj(out/"validation/stage6d4a3a_validation.json",val)
    wj(out/"summaries/stage6d4a3a_summary.json",{
        "disposition":disposition,
        "next_action":(
            "Freeze exact survey-label semantic map and revalidate D4A3 lineage."
            if family_identity else
            "Do not authorize D4B; inspect true survey-family mismatches."
        )
    })
    print(json.dumps({"validation":val},indent=2))
    return 0
if __name__=="__main__": raise SystemExit(main())
