from __future__ import annotations
import argparse, csv, json, re, shutil, traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd

STAGE = "Stage-6D3A2D exact traced design-layer schema adjudication and source-row pivot"
VERSION = "0.17.6"
OUT_REL = "outputs/stage6d3a2d_design_layer_schema_pivot"
D3A_REL = "outputs/stage6d3a_common_footprint_protocol_freeze/validation/stage6d3a_validation.json"
D3A2C_REL = "outputs/stage6d3a2c_universal_io_trace_bundle/validation/stage6d3a2c_validation.json"
PREFERRED = {"stage4a_analysis_design_layer.parquet","stage4a_analysis_design_layer.csv","stage4a_analysis_design_layer.feather"}
SCAN_ROOTS = ["outputs/stage4a","outputs/stage3","outputs/stage3a","outputs/stage3b","outputs/stage2a","outputs/stage2b","data/interim"]
SUFFIXES = {".csv",".parquet",".feather"}
LABELS = ["fe_h","mg_fe","si_fe","ca_fe","ni_fe"]
MIN_ROWS = 500
MIN_OVERLAP = 0.01
MAX_LOAD = 80
MAX_ENRICH = 24
TOL = 1e-12
ALIASES = {
 "source_id":["gaia_dr3_source_id","source_id","gaia_source_id","dr3_source_id","gaia_id"],
 "survey":["survey_group","survey_origin","survey","source_survey","catalogue_origin","analysis_survey","survey_role"],
 "cohort":["cohort","analysis_cohort","sample_cohort","sample","analysis_sample","model_cohort"],
 "label":["label","element","abundance_label","chemical_label","target_label","response_label"],
 "value":["abundance","abundance_value","label_value","chemical_value","response","response_value","target_value","y","y_value","value","calibrated_abundance","transported_abundance"],
 "R":["r_gal_kpc","r_galactocentric_kpc","galr_kpc","r_cyl_kpc","R_kpc","r_kpc","galactocentric_r_kpc","r_gc_kpc","r_centered_kpc"],
 "Z":["z_gal_kpc","z_kpc","galz_kpc","Z_kpc","abs_z_kpc","z_abs_kpc","galactocentric_z_kpc","vertical_height_kpc"],
 "l":["l","gal_l","galactic_l","glon","l_deg","galactic_longitude"],
 "b":["b","gal_b","galactic_b","glat","b_deg","galactic_latitude"],
 "teff":["teff","teff_k","effective_temperature","teff_calibration","teff_reference","effective_temperature_k"],
 "logg":["logg","log_g","surface_gravity","logg_calibration","logg_reference"],
 "snr":["snr","signal_to_noise","s_n","snr_reference","snr_common","signal_to_noise_ratio"],
 "g_mag":["phot_g_mean_mag","g_mag","gaia_g","gmag","gaia_g_mag"],
 "bp_rp":["bp_rp","gaia_bp_rp","color_bp_rp","bp_minus_rp","gaia_bp_minus_rp"],
 "distance_quality":["parallax_over_error","fractional_distance_error","distance_quality","ruwe"]
}
LABEL_VARIANTS = {
 "fe_h":["fe_h","feh","fe_h_corrected","fe_h_calibrated","fe_h_transport","fe_h_final","fe_h_common","[fe/h]","feh_dex"],
 "mg_fe":["mg_fe","mgfe","mg_fe_corrected","mg_fe_calibrated","mg_fe_transport","mg_fe_final","mg_fe_common","[mg/fe]","mgfe_dex"],
 "si_fe":["si_fe","sife","si_fe_corrected","si_fe_calibrated","si_fe_transport","si_fe_final","si_fe_common","[si/fe]","sife_dex"],
 "ca_fe":["ca_fe","cafe","ca_fe_corrected","ca_fe_calibrated","ca_fe_transport","ca_fe_final","ca_fe_common","[ca/fe]","cafe_dex"],
 "ni_fe":["ni_fe","nife","ni_fe_corrected","ni_fe_calibrated","ni_fe_transport","ni_fe_final","ni_fe_common","[ni/fe]","nife_dex"]
}
SURVEYS = {"APOGEE_NATIVE":["apogee_native","apogee","apogee_only","native_apogee"],"GALAH_CORRECTED":["galah_corrected","galah","galah_only","corrected_galah"]}
REQ = ["source_id","survey","R","Z","l","b","teff","logg","snr","g_mag","bp_rp"]

def now(): return datetime.now(timezone.utc).isoformat()
def rel(p,r):
 try:return str(p.resolve().relative_to(r.resolve())).replace('\\','/')
 except:return str(p).replace('\\','/')
def dump(p,x): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False,default=str)+'\n',encoding='utf-8')
def csvwrite(p,fields,rows):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w',encoding='utf-8',newline='') as h:
  w=csv.DictWriter(h,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
def token(v): return re.sub(r'[^a-z0-9]+','_',str(v).lower().replace('[','').replace(']','').replace('/','_')).strip('_')
def alias(cols,opts):
 lu={c.lower():c for c in cols}
 for o in opts:
  if o.lower() in lu:return lu[o.lower()]
 return None
def label_col(cols,label):
 lu={token(c):c for c in cols}
 for x in LABEL_VARIANTS[label]:
  if token(x) in lu:return lu[token(x)]
 return None
def canon_label(v):
 t=token(v)
 for lab,vs in LABEL_VARIANTS.items():
  if t in {token(x) for x in vs}:return lab
 return None
def canon_survey(v):
 t=token(v)
 for s,vs in SURVEYS.items():
  for x in vs:
   q=token(x)
   if t==q or q in t:return s
 return None
def columns(path):
 if path.suffix.lower()=='.parquet':
  import pyarrow.parquet as pq
  q=pq.ParquetFile(path);return list(q.schema_arrow.names),int(q.metadata.num_rows)
 if path.suffix.lower()=='.feather':
  import pyarrow.feather as ft
  q=ft.read_table(path);return list(q.column_names),int(q.num_rows)
 return list(pd.read_csv(path,nrows=5).columns),-1
def read(path,cols=None):
 if path.suffix.lower()=='.parquet':return pd.read_parquet(path,columns=cols)
 if path.suffix.lower()=='.feather':return pd.read_feather(path,columns=cols)
 return pd.read_csv(path,usecols=cols)
def profile(path):
 cols,n=columns(path);m={k:alias(cols,v) for k,v in ALIASES.items()};wide={l:label_col(cols,l) for l in LABELS}
 return {'columns':cols,'rows':n,'mapping':m,'wide':wide,'wide_count':sum(x is not None for x in wide.values()),'long':bool(m['label'] and m['value'])}
def infer_survey(frame,m):
 candidates=[]
 for k in ['survey','cohort']:
  if m.get(k) and m[k] not in candidates:candidates.append(m[k])
 for c in frame.columns:
  if any(x in c.lower() for x in ['survey','cohort','sample','catalog']) and c not in candidates:candidates.append(c)
 diag=[]
 for c in candidates:
  s=frame[c].map(canon_survey).astype('string');cnt=s.value_counts(dropna=True).to_dict();diag.append({'column':c,'counts':cnt,'values':sorted(set(frame[c].dropna().astype(str)))[:50]})
  if cnt.get('APOGEE_NATIVE',0)>0 and cnt.get('GALAH_CORRECTED',0)>0:return c,s,diag
 return None,pd.Series(pd.NA,index=frame.index,dtype='string'),diag
def pivot_design(path,p):
 f=read(path);m=p['mapping'];sid=m['source_id']
 if not sid:raise RuntimeError('source-ID column missing')
 scol,survey,sdiag=infer_survey(f,m)
 if not scol:raise RuntimeError('no schema column contains both APOGEE and GALAH identities')
 static=pd.DataFrame({'source_id':pd.to_numeric(f[sid],errors='coerce'),'survey':survey})
 for x in REQ+['distance_quality']:
  if x in ['source_id','survey']:continue
  if m.get(x):static[x]=f[m[x]]
 static=static[static.source_id.notna() & static.survey.notna()].copy();static.source_id=static.source_id.astype('uint64')
 conflicts=[]
 if p['wide_count']>=3:
  out=static.copy()
  for l,c in p['wide'].items():
   if c:out[l]=pd.to_numeric(f.loc[out.index,c],errors='coerce')
  for keys,g in out.groupby(['source_id','survey'],sort=False):
   if len(g)>1:
    for c in [x for x in out.columns if x not in ['source_id','survey']]:
     vals=pd.to_numeric(g[c],errors='coerce').dropna().to_numpy(float)
     if len(vals)>1 and np.nanmax(vals)-np.nanmin(vals)>TOL:conflicts.append({'source_id':int(keys[0]),'survey':str(keys[1]),'label':c,'row_count':len(g),'min':float(np.nanmin(vals)),'max':float(np.nanmax(vals)),'conflict':'true'})
  if conflicts:return pd.DataFrame(),{'contract':'wide','survey_column':scol,'survey_diag':sdiag,'input_rows':len(f),'conflicts':True},conflicts
  out=out.groupby(['source_id','survey'],as_index=False).first();contract='wide'
 else:
  if not p['long']:raise RuntimeError('neither wide nor long label/value schema found')
  w=pd.DataFrame({'source_id':pd.to_numeric(f[sid],errors='coerce'),'survey':survey,'label':f[m['label']].map(canon_label),'value':pd.to_numeric(f[m['value']],errors='coerce')})
  w=w[w.source_id.notna() & w.survey.notna() & w.label.notna()].copy();w.source_id=w.source_id.astype('uint64')
  rows=[]
  for keys,g in w.groupby(['source_id','survey','label'],sort=False):
   vals=g.value.dropna().to_numpy(float);bad=len(vals)>1 and np.nanmax(vals)-np.nanmin(vals)>TOL
   if bad:conflicts.append({'source_id':int(keys[0]),'survey':str(keys[1]),'label':str(keys[2]),'row_count':len(g),'min':float(np.nanmin(vals)),'max':float(np.nanmax(vals)),'conflict':'true'})
   rows.append({'source_id':keys[0],'survey':keys[1],'label':keys[2],'value':np.nan if bad or len(vals)==0 else float(vals[0])})
  if conflicts:return pd.DataFrame(),{'contract':'long','survey_column':scol,'survey_diag':sdiag,'input_rows':len(f),'conflicts':True},conflicts
  a=pd.DataFrame(rows).pivot(index=['source_id','survey'],columns='label',values='value').reset_index()
  st=static.groupby(['source_id','survey'],as_index=False).first();out=st.merge(a,on=['source_id','survey'],how='inner',validate='one_to_one');contract='long'
 return out,{'contract':contract,'survey_column':scol,'survey_diag':sdiag,'input_rows':len(f),'pivot_rows':len(out),'conflicts':False},conflicts
def enrich_frame(path,p):
 m=p['mapping'];needed=[m[x] for x in REQ+['distance_quality'] if m.get(x)]+[c for c in p['wide'].values() if c];needed=sorted(set(needed));f=read(path,needed);o=pd.DataFrame();o['source_id']=pd.to_numeric(f[m['source_id']],errors='coerce')
 if m.get('survey'):o['survey']=f[m['survey']].map(canon_survey).astype('string')
 elif m.get('cohort'):o['survey']=f[m['cohort']].map(canon_survey).astype('string')
 for x in REQ+['distance_quality']:
  if x in ['source_id','survey']:continue
  if m.get(x):o[x]=f[m[x]]
 for l,c in p['wide'].items():
  if c:o[l]=pd.to_numeric(f[c],errors='coerce')
 o=o[o.source_id.notna()].copy();o.source_id=o.source_id.astype('uint64');keys=['source_id']+(['survey'] if 'survey' in o and o.survey.notna().any() else [])
 if o.duplicated(keys).any():o=o.groupby(keys,as_index=False).first()
 return o
def coalesce(base,add,fields,keys):
 cand=[x for x in fields if x not in keys and x in add.columns];before={x:int(base[x].notna().sum()) if x in base else 0 for x in fields};v='one_to_one' if keys==['source_id','survey'] else 'many_to_one';j=base.merge(add[keys+cand],on=keys,how='left',suffixes=('','__c'),validate=v)
 for x in cand:
  c=x+'__c';j[x]=j[c] if x not in j else j[x].where(j[x].notna(),j[c]);j.drop(columns=[c],inplace=True)
 after={x:int(j[x].notna().sum()) if x in j else 0 for x in fields};return j,{x:after[x]-before[x] for x in fields}
def complete(f):
 mask=pd.Series(True,index=f.index)
 for x in [r for r in REQ if r!='source_id']+LABELS:
  if x not in f:return pd.Series(False,index=f.index)
  mask &= f[x].notna()
 return mask

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--project-root',default='.');root=Path(ap.parse_args().project_root).resolve();out=root/OUT_REL
 if out.exists():shutil.rmtree(out)
 for d in ['validation','summaries','tables','assembled','diagnostics','reports']:(out/d).mkdir(parents=True,exist_ok=True)
 d3a=json.loads((root/D3A_REL).read_text()) if (root/D3A_REL).exists() else {};base_ready=all(d3a.get(x,False) for x in ['STAGE6D3A_PROTOCOL_READY','PROTOCOL_SEMANTIC_IDENTITY_READY','FROZEN_FULL_SUPPORT_GRADIENTS_READY','FROZEN_FULL_SUPPORT_BOOTSTRAP_READY'])
 d3c=json.loads((root/D3A2C_REL).read_text()) if (root/D3A2C_REL).exists() else {};trace_ready=all(d3c.get(x,False) for x in ['UNIVERSAL_RUNTIME_TRACE_READY','PROTECTED_STAGE4A_STAGE4B_UNMODIFIED','NORMAL_SYSTEM_EXIT_HANDLED'])
 traced=[(root/x).resolve() for x in d3c.get('traced_read_paths',[]) if (root/x).exists()]
 cand=[]
 for pth in traced:
  if pth.suffix.lower() not in SUFFIXES:continue
  try:pr=profile(pth);score=5000*int(pth.name in PREFERRED)+3000*int(pr['mapping']['source_id'] is not None)+2000*int(pr['wide_count']>=3 or pr['long'])+500*pr['wide_count'];cand.append({'path':pth,'profile':pr,'score':score,'error':''})
  except Exception as e:cand.append({'path':pth,'profile':None,'score':-1,'error':f'{type(e).__name__}: {e}'})
 cand.sort(key=lambda x:(-x['score'],str(x['path'])))
 csvwrite(out/'tables/stage6d3a2d_traced_design_candidates.csv',['path','score','row_count','columns','source_id','survey','cohort','label','value','wide_count','wide_mapping','long_ready','error'],[{'path':rel(x['path'],root),'score':x['score'],'row_count':x['profile']['rows'] if x['profile'] else '', 'columns':'|'.join(x['profile']['columns']) if x['profile'] else '', 'source_id':x['profile']['mapping']['source_id'] if x['profile'] else '', 'survey':x['profile']['mapping']['survey'] if x['profile'] else '', 'cohort':x['profile']['mapping']['cohort'] if x['profile'] else '', 'label':x['profile']['mapping']['label'] if x['profile'] else '', 'value':x['profile']['mapping']['value'] if x['profile'] else '', 'wide_count':x['profile']['wide_count'] if x['profile'] else 0, 'wide_mapping':json.dumps(x['profile']['wide']) if x['profile'] else '', 'long_ready':str(x['profile']['long']).lower() if x['profile'] else 'false','error':x['error']} for x in cand])
 selected=next((x for x in cand if x['profile'] and x['profile']['mapping']['source_id'] and (x['profile']['wide_count']>=3 or x['profile']['long'])),None)
 pivot=pd.DataFrame();diag={};conf=[];perr=''
 if selected:
  try:pivot,diag,conf=pivot_design(selected['path'],selected['profile'])
  except Exception as e:perr=f'{type(e).__name__}: {e}\n{traceback.format_exc()}'
 else:perr='no traced design layer has source ID plus wide or long label schema'
 csvwrite(out/'tables/stage6d3a2d_duplicate_conflict_audit.csv',['source_id','survey','label','row_count','min','max','conflict'],conf)
 dump(out/'diagnostics/stage6d3a2d_pivot_contract.json',{'selected':rel(selected['path'],root) if selected else '','diagnostics':diag,'pivot_error':perr})
 assembled=pivot.copy();bundle=[];ea=[];aerr=perr;apath=None;counts={'APOGEE_NATIVE':0,'GALAH_CORRECTED':0}
 if not perr and not assembled.empty:
  try:
   fields=REQ+['distance_quality']+LABELS
   for x in fields:
    if x not in assembled:assembled[x]=pd.NA
   bundle.append({'role':'exact_traced_design_layer_pivot','path':selected['path'],'keys':['source_id','survey'],'traced':True,'score':selected['score']})
   ids=set(assembled.source_id.astype('uint64'));tset={x.resolve() for x in traced};pool=[]
   for rr in SCAN_ROOTS:
    b=root/rr
    if not b.exists():continue
    for pth in b.rglob('*'):
     if not pth.is_file() or pth.suffix.lower() not in SUFFIXES or pth.resolve()==selected['path'].resolve():continue
     try:pr=profile(pth)
     except:continue
     if not pr['mapping']['source_id']:continue
     coverage=sum(pr['mapping'].get(x) is not None for x in REQ)+pr['wide_count'];rank=1000*int(pth.resolve() in tset)+500*int('stage4a' in str(pth).lower())+100*coverage;pool.append({'path':pth,'profile':pr,'rank':rank,'traced':pth.resolve() in tset})
   pool.sort(key=lambda x:(-x['rank'],str(x['path'])));loaded=[]
   for r in pool[:MAX_LOAD]:
    try:f=enrich_frame(r['path'],r['profile']);ov=len(ids.intersection(set(f.source_id.astype('uint64'))))/max(len(ids),1)
    except:continue
    if ov>=MIN_OVERLAP:r['frame']=f;r['overlap']=ov;loaded.append(r)
   used={selected['path'].resolve()}
   for _ in range(MAX_ENRICH):
    cur=int(complete(assembled).sum());best=None
    for r in loaded:
     if r['path'].resolve() in used:continue
     f=r['frame'];keys=['source_id','survey'] if 'survey' in f and f.survey.notna().any() else ['source_id']
     if keys==['source_id'] and f.duplicated(['source_id']).any():f=f.groupby(['source_id'],as_index=False).first()
     try:trial,gains=coalesce(assembled,f,fields,keys)
     except:continue
     cg=int(complete(trial).sum())-cur;tg=sum(max(int(v),0) for v in gains.values());score=10000*cg+tg+2000*int(r['traced'])+int(100*r['overlap'])
     if (cg>0 or tg>0) and (best is None or score>best['score']):best={'r':r,'trial':trial,'gains':gains,'cg':cg,'score':score,'keys':keys}
    if best is None:break
    r=best['r'];assembled=best['trial'];used.add(r['path'].resolve());role='traced_enrichment' if r['traced'] else 'frozen_upstream_enrichment';bundle.append({'role':role,'path':r['path'],'keys':best['keys'],'traced':r['traced'],'score':best['score']});ea.append({'path':rel(r['path'],root),'role':role,'join_keys':'|'.join(best['keys']),'score':best['score'],'complete_row_gain':best['cg'],'anchor_overlap_fraction':r['overlap'],'field_gains':json.dumps(best['gains'],sort_keys=True)})
   cm=complete(assembled)
   for s in counts:counts[s]=int((cm & (assembled.survey==s)).sum())
   apath=out/'assembled/stage6d3a2d_production_source_assembled.parquet'
   try:assembled.to_parquet(apath,index=False)
   except:apath=out/'assembled/stage6d3a2d_production_source_assembled.csv';assembled.to_csv(apath,index=False)
   aerr=''
  except Exception as e:aerr=f'{type(e).__name__}: {e}\n{traceback.format_exc()}'
 csvwrite(out/'tables/stage6d3a2d_selected_source_bundle.csv',['bundle_order','role','path','join_keys','traced','score'],[{'bundle_order':i+1,'role':x['role'],'path':rel(x['path'],root),'join_keys':'|'.join(x['keys']),'traced':str(x['traced']).lower(),'score':x['score']} for i,x in enumerate(bundle)])
 csvwrite(out/'tables/stage6d3a2d_enrichment_audit.csv',['path','role','join_keys','score','complete_row_gain','anchor_overlap_fraction','field_gains'],ea)
 cov=[]
 if not assembled.empty:
  for x in REQ+['distance_quality']+LABELS:cov.append({'field':x,'non_null_rows':int(assembled[x].notna().sum()) if x in assembled else 0,'coverage_fraction':float(assembled[x].notna().mean()) if x in assembled else 0.0})
 csvwrite(out/'tables/stage6d3a2d_assembled_field_coverage.csv',['field','non_null_rows','coverage_fraction'],cov)
 pivot_ready=bool(selected and not perr and not diag.get('conflicts',False) and len(pivot)>=MIN_ROWS);source_ready=bool(pivot_ready and not aerr and apath and all(counts[s]>=MIN_ROWS for s in counts));remaining=[]
 if not base_ready:remaining.append({'gate':'STAGE6D3A_BASELINE_PROTOCOL_READY','required_action':'restore PASS Stage-6D3A baseline'})
 if not trace_ready:remaining.append({'gate':'STAGE6D3A2C_TRACE_PREREQUISITE_READY','required_action':'universal trace/protected-output prerequisite not PASS'})
 if not selected:remaining.append({'gate':'EXACT_TRACED_DESIGN_LAYER_READY','required_action':perr})
 if perr:remaining.append({'gate':'DESIGN_LAYER_PIVOT_READY','required_action':perr})
 elif diag.get('conflicts',False):remaining.append({'gate':'DESIGN_LAYER_DUPLICATE_IDENTITY_READY','required_action':'conflicting duplicates; inspect audit'})
 elif len(pivot)<MIN_ROWS:remaining.append({'gate':'DESIGN_LAYER_SOURCE_ROWS_READY','required_action':f'pivot rows={len(pivot)}; need >= {MIN_ROWS}'})
 if pivot_ready and not source_ready:remaining.append({'gate':'PRODUCTION_SOURCE_COMPLETE_ROWS_READY','required_action':f'need >= {MIN_ROWS} complete rows per survey; observed {counts}; assembly_error={aerr}'})
 csvwrite(out/'tables/stage6d3a2d_remaining_items.csv',['gate','required_action'],remaining)
 ready=base_ready and trace_ready and source_ready
 val={'stage':STAGE,'protocol_version':'1.0.0','implementation_version':VERSION,'timestamp_utc':now(),'project_root':str(root),'traced_path_count':len(traced),'selected_design_layer':rel(selected['path'],root) if selected else '','design_layer_contract':diag.get('contract',''),'design_layer_input_rows':diag.get('input_rows',0),'pivot_rows':len(pivot),'duplicate_conflict_count':len(conf),'selected_source_bundle':[rel(x['path'],root) for x in bundle],'assembled_source_table':rel(apath,root) if apath else '','assembled_rows':len(assembled),'complete_rows_by_survey':counts,'pivot_error':perr,'assembly_error':aerr,'prior_stage_outputs_modified':False,'STAGE6D3A_BASELINE_PROTOCOL_READY':base_ready,'STAGE6D3A2C_TRACE_PREREQUISITE_READY':trace_ready,'EXACT_TRACED_DESIGN_LAYER_READY':selected is not None,'DESIGN_LAYER_SCHEMA_READY':bool(selected and (selected['profile']['wide_count']>=3 or selected['profile']['long'])),'SURVEY_IDENTITY_FROM_SCHEMA_READY':bool(diag.get('survey_column')),'LONG_OR_WIDE_LABEL_CONTRACT_READY':bool(diag.get('contract')),'DESIGN_LAYER_DUPLICATE_IDENTITY_READY':not bool(diag.get('conflicts',False)),'DESIGN_LAYER_PIVOT_READY':pivot_ready,'SURVEY_AWARE_SOURCE_ID_JOIN_READY':bool(bundle),'PRODUCTION_SOURCE_ASSEMBLY_READY':source_ready,'TARGET_ABUNDANCE_MATCHING_FORBIDDEN':True,'STAGE6D3A2D_LINEAGE_READY':base_ready and trace_ready and pivot_ready,'STAGE6D3B_COMMON_FOOTPRINT_READY':ready}
 dump(out/'validation/stage6d3a2d_validation.json',val);dump(out/'summaries/stage6d3a2d_summary.json',{'stage':STAGE,'timestamp_utc':now(),'validation':val,'remaining_items':remaining,'scientific_disposition':'Exact traced design layer materialized; Stage-6D3B authorized.' if ready else 'Design-layer schema audited; D3B remains blocked by listed pivot/coverage gap.'});print(json.dumps({'validation':val,'summary':{'remaining_items':remaining}},indent=2,ensure_ascii=False));return 0
if __name__=='__main__':raise SystemExit(main())
