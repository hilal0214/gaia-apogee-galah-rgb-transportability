from __future__ import annotations
from pathlib import Path
import argparse
import subprocess
import sys

TARGET = Path("src/stage6d4c1_practical_equivalence_path_hotfix.py")
OLD = "labdf.to_markdown(index=False)"
NEW = "labdf.to_string(index=False)"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    target = root / TARGET
    if not target.exists():
        raise FileNotFoundError(f"Required D4C1 source missing: {target}")

    text = target.read_text(encoding="utf-8")
    count = text.count(OLD)

    if count == 1:
        target.write_text(text.replace(OLD, NEW), encoding="utf-8")
        print("[D4C2] PATCH_APPLIED: dependency-free report renderer")
    elif count == 0 and NEW in text:
        print("[D4C2] PATCH_ALREADY_PRESENT")
    else:
        raise RuntimeError(
            f"Expected exactly one report-rendering target, found {count}. "
            "Refusing fuzzy or broad source modification."
        )

    print("[D4C2] Re-running identical D4C1 science/classification logic.")
    proc = subprocess.run(
        [sys.executable, str(target), "--project-root", str(root)],
        cwd=str(root)
    )
    if proc.returncode != 0:
        raise SystemExit(proc.returncode)

    validation = root / (
        "outputs/stage6d4c1_practical_equivalence_path_hotfix/"
        "validation/stage6d4c1_validation.json"
    )
    report = root / (
        "outputs/stage6d4c1_practical_equivalence_path_hotfix/"
        "reports/stage6d4c1_report.md"
    )
    if not validation.exists():
        raise RuntimeError("D4C1 validation missing after rerun")
    if not report.exists():
        raise RuntimeError("D4C1 report missing after rerun")

    print("[OK] Stage-6D4C2 report-dependency hotfix completed.")
    print(
        "Inspect outputs\\stage6d4c1_practical_equivalence_path_hotfix\\"
        "validation\\stage6d4c1_validation.json"
    )
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
