from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, shutil, sys, time, traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import numpy as np, pandas as pd
G={}

def now(): return datetime.now(timezone.utc).isoformat()
def canonical_sha(o): return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def write_json_atomic(p,o):
    p.parent.mkdir(parents=True,exist_ok=True); t=p.with_suffix(p.suffix+".tmp")
    t.write_text(json.dumps(o,indent=2,ensure_ascii=False,default=str)+"\n",encoding="utf-8"); os.replace(t,p)
def sha_file(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()
def load_module(name,path):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s); sys.modules[name]=m; s.loader.exec_module(m); return m
def flag_bool(s):
    if pd.api.types.is_bool_dtype(s): return s.fillna(False).to_numpy(bool)
    return s.astype(str).str.strip().str.lower().isin(["1","true","t","yes","y"]).to_numpy(bool)
def stable_fold(cell,ns,kind,k,outer=None):
    d=hashlib.sha256(f"{ns}|{kind}|{'' if outer is None else outer}|{int(cell)}".encode()).digest()
    return int.from_bytes(d[:8],"little")%int(k)
def f0(R,Z): return np.column_stack([R-8.2,Z])
def f1(R,Z,rb): return np.column_stack([R-8.2,np.maximum(0.,R-float(rb)),Z])
def pred(f,X): return f.beta[0]+X@f.beta[1:]
def wmae(y,p,w): return float(np.sum(w*np.abs(y-p))/np.sum(w))
def wfit(X,y,w):
    d,s,h=G["d4b"],G["s4b"],G["h"]
    return d.weighted_huber_fit(X,y,w,tuning_constant=float(h["tuning_constant"]),relative_tolerance=float(h["relative_tolerance"]),maximum_iterations=int(h["maximum_iterations"]),minimum_scale=float(h["minimum_scale"]),robust_scale_fn=s.robust_scale)
def group_center(r,w,s,c):
    x=pd.DataFrame({"r":r,"w":w,"s":s,"c":c}); x["wr"]=x.r*x.w
    q=x.groupby(["s","c"],sort=False)[["wr","w"]].sum(); mu=(q.wr/q.w).to_dict()
    return r-np.array([mu[(ss,int(cc))] for ss,cc in zip(s,c)],float)
def synth(seed,rb,delta):
    rng=np.random.Generator(np.random.PCG64DXSM(int(seed)))
    signs=rng.integers(0,2,size=len(G["groups"]),dtype=np.int8).astype(float)*2-1
    sm={g:signs[i] for i,g in enumerate(G["groups"])}
    mult=np.array([sm[(str(s),int(c))] for s,c in zip(G["survey"],G["cell"])],float)
    y=G["fitted"]+mult*G["centered"]
    if float(delta)!=0: y=y+float(delta)*np.maximum(0.,G["R"]-float(rb))
    return y
def select_break(R,Z,y,w,cell,tag):
    folds=np.array([stable_fold(c,G["namespace"],"inner",3,outer=tag) for c in cell],np.int8)
    best=None
    for rb in G["breaks"]:
        loss=0.
        for f in range(3):
            tr=folds!=f; va=folds==f
            fit=wfit(f1(R[tr],Z[tr],rb),y[tr],w[tr])
            if not fit.converged: raise RuntimeError("inner M1 fit failed")
            loss+=wmae(y[va],pred(fit,f1(R[va],Z[va],rb)),w[va])
        cand=(loss/3,float(rb))
        if best is None or cand<best: best=cand
    return best[1]
def task_hash(t): return hashlib.sha256(json.dumps(t,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def replicate(t):
    t0=time.perf_counter(); R,Z,w,c=G["R"],G["Z"],G["w"],G["cell"]
    y=synth(t["seed"],t["R_break_kpc"],t["delta_beta"])
    imps=[]; obs=[]
    for of in range(5):
        tr=G["outer"]!=of; te=G["outer"]==of
        rb=select_break(R[tr],Z[tr],y[tr],w[tr],c[tr],of)
        m0=wfit(f0(R[tr],Z[tr]),y[tr],w[tr]); m1=wfit(f1(R[tr],Z[tr],rb),y[tr],w[tr])
        if not(m0.converged and m1.converged): raise RuntimeError("outer fit failed")
        a=wmae(y[te],pred(m0,f0(R[te],Z[te])),w[te]); b=wmae(y[te],pred(m1,f1(R[te],Z[te],rb)),w[te])
        imps.append(float(1-b/a)); obs.append(float(rb))
    rb=select_break(R,Z,y,w,c,"full")
    X=f1(R,Z,rb); fit=wfit(X,y,w)
    inf=G["d4b"].weighted_cluster_inference(X,y,c.astype(np.int64),fit,n_draws=0,seed=1,finite_cluster_correction=True)
    dh=float(fit.beta[2]); se=float(inf.standard_errors[2]); z=1.959963984540054
    lo,hi=dh-z*se,dh+z*se
    return {**t,"task_identity_sha256":task_hash(t),"median_outer_cv_improvement":float(np.median(imps)),
            "outer_cv_improvements":imps,"outer_selected_breaks_kpc":obs,"selected_break_kpc":float(rb),
            "break_abs_error_kpc":None if t["kind"]=="NULL" else float(abs(rb-t["R_break_kpc"])),
            "delta_beta_hat":dh,"delta_beta_se":se,"delta_beta_wald_low":lo,"delta_beta_wald_high":hi,
            "wald_excludes_zero":bool(lo>0 or hi<0),"boundary_flag":bool(rb in G["boundary_breaks"]),
            "sign_correct":None if t["kind"]=="NULL" else bool(np.sign(dh)==np.sign(t["delta_beta"])),
            "blocks":int(len(inf.block_ids)),"runtime_seconds":float(time.perf_counter()-t0),"completed_utc":now()}

def init_worker(root_s,cfg_rel):
    root=Path(root_s); c=json.loads((root/cfg_rel).read_text()); p=json.loads((root/c["stage7a_protocol"]).read_text())
    dc=json.loads((root/c["d4b_config"]).read_text()); d4=load_module(f"d4_{os.getpid()}",root/c["d4b_source"]); s4=load_module(f"s4_{os.getpid()}",root/c["stage4b_common"])
    df=pd.read_parquet(root/c["balanced_source"],columns=c["columns"])
    e=flag_bool(df["fe_h_gradient_primary_ok"]); R0=pd.to_numeric(df.R,errors="coerce").to_numpy(float); Z0=pd.to_numeric(df.abs_Z,errors="coerce").to_numpy(float)
    y0=pd.to_numeric(df.fe_h,errors="coerce").to_numpy(float); w0=pd.to_numeric(df.balance_weight_final,errors="coerce").to_numpy(float)
    m=e&np.isfinite(R0)&np.isfinite(Z0)&np.isfinite(y0)&np.isfinite(w0)&(w0>0)&(R0>3)&(R0<15); x=df.loc[m].reset_index(drop=True)
    R=pd.to_numeric(x.R).to_numpy(float); Z=pd.to_numeric(x.abs_Z).to_numpy(float); y=pd.to_numeric(x.fe_h).to_numpy(float); w=pd.to_numeric(x.balance_weight_final).to_numpy(float)
    sv=x.survey.astype(str).to_numpy(); cell=pd.to_numeric(x.healpix_gal_ring_nside16).to_numpy(np.int64)
    G.clear(); G.update({"d4b":d4,"s4b":s4,"h":dc["huber"],"R":R,"Z":Z,"w":w,"survey":sv,"cell":cell,
        "namespace":p["predictive_selection"]["namespace"],"breaks":[float(v) for v in p["break_search"]["grid_values"]],
        "boundary_breaks":set([4.5,4.6,8.4,8.5]),"outer":np.array([stable_fold(cc,p["predictive_selection"]["namespace"],"outer",5) for cc in cell],np.int8)})
    m0=wfit(f0(R,Z),y,w)
    if not m0.converged: raise RuntimeError("real M0 failed")
    G["fitted"]=pred(m0,f0(R,Z)); G["centered"]=group_center(m0.residuals,w,sv,cell); G["groups"]=sorted(set((str(s),int(cc)) for s,cc in zip(sv,cell)))

def build_tasks(c):
    out=[]
    for i in range(c["null_replicates"]):
        out.append({"task_id":f"NULL_{i:04d}","kind":"NULL","scenario":"NULL","replicate_index":i,"R_break_kpc":6.0,"delta_beta":0.0,"seed":c["null_seed_start"]+i})
    si=0
    for rb in c["break_locations_kpc"]:
        for mag in c["break_strength_magnitudes_dex_per_kpc"]:
            for sg in c["signs"]:
                d=float(sg)*float(mag); sc=f"RB{rb:.1f}_D{d:+.2f}"; seed0=c["injection_seed_base"]+si*1000
                for i in range(c["replicates_per_signed_scenario"]):
                    out.append({"task_id":f"{sc}_{i:04d}","kind":"INJECTED","scenario":sc,"replicate_index":i,"R_break_kpc":float(rb),"delta_beta":d,"seed":seed0+i})
                si+=1
    return out
def cp_path(d,t): return d/(t["task_id"]+".json")
def valid_cp(p,t):
    try:
        o=json.loads(p.read_text()); return o.get("task_identity_sha256")==task_hash(t) and np.isfinite(float(o["median_outer_cv_improvement"]))
    except Exception: return False
def p_inj(T,n): return float((1+np.sum(n>=float(T)))/(len(n)+1))
def p_null(i,n):
    Ti=float(n[i]); o=np.delete(n,i); return float((1+np.sum(o>=Ti))/len(n))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--project-root",default="."); ap.add_argument("--workers",type=int); ap.add_argument("--reset",action="store_true"); a=ap.parse_args()
    root=Path(a.project_root).resolve(); rel=Path("config/stage7b2_config.json"); c=json.loads((root/rel).read_text()); out=root/c["output_dir"]
    for d in ["validation","tables","reports","benchmarks","freeze","manifest","checkpoints","logs"]:(out/d).mkdir(parents=True,exist_ok=True)
    if a.reset: shutil.rmtree(out/"checkpoints",ignore_errors=True); (out/"checkpoints").mkdir()
    va=json.loads((root/c["stage7a_validation"]).read_text()); pa=json.loads((root/c["stage7a_protocol"]).read_text())
    v1=json.loads((root/c["stage7b1_validation"]).read_text()); vb=json.loads((root/c["stage7b2b_validation"]).read_text()); ab=json.loads((root/c["stage7b2b_amendment"]).read_text())
    prot=json.loads((root/"protocol/stage7b2_formal_protocol.json").read_text())
    pre=bool(va.get("STAGE7A_PROTOCOL_FROZEN") and canonical_sha(pa)==c["expected_stage7a_protocol_sha256"] and v1.get("STAGE7B1_PREFLIGHT_READY") and
             v1.get("stage7b1_operational_closure_canonical_sha256")==c["expected_stage7b1_closure_sha256"] and vb.get("STAGE7B2_FULL_SIGNED_PRODUCTION_READY") and
             canonical_sha(ab)==c["expected_stage7b2b_amendment_sha256"] and vb.get("STAGE7C_REAL_BREAK_FIT_AUTHORIZED") is False)
    if not pre: raise RuntimeError("prerequisite identity failed")
    shutil.copy2(root/"protocol/stage7b2_formal_protocol.json",out/"freeze/stage7b2_formal_protocol_frozen.json")
    tasks=build_tasks(c)
    if len(tasks)!=3328: raise RuntimeError("task count failed")
    cps=out/"checkpoints"; pending=[t for t in tasks if not valid_cp(cp_path(cps,t),t)]
    workers=max(1,a.workers if a.workers else min(c["default_workers"],max(1,(os.cpu_count() or 2)-1)))
    print(f"[B2] total=3328 existing={3328-len(pending)} pending={len(pending)} workers={workers}")
    start=time.perf_counter(); errors=[]
    if pending:
        with ProcessPoolExecutor(max_workers=workers,initializer=init_worker,initargs=(str(root),str(rel))) as ex:
            fs={ex.submit(replicate,t):t for t in pending}; n=3328-len(pending)
            for f in as_completed(fs):
                t=fs[f]
                try: write_json_atomic(cp_path(cps,t),f.result())
                except Exception as e:
                    errors.append(t["task_id"]); write_json_atomic(out/"logs"/f"ERROR_{t['task_id']}.json",{"task":t,"error":repr(e),"traceback":traceback.format_exc()})
                n+=1
                if n%c["progress_every_completed"]==0 or n==3328: print(f"[B2] completed_or_attempted={n}/3328 errors={len(errors)} elapsed_min={(time.perf_counter()-start)/60:.1f}")
    results=[]; missing=[]
    for t in tasks:
        p=cp_path(cps,t)
        if valid_cp(p,t): results.append(json.loads(p.read_text()))
        else: missing.append(t["task_id"])
    if missing:
        write_json_atomic(out/"validation/stage7b2_resume_state.json",{"VALID_CHECKPOINTS":len(results),"MISSING":len(missing),"RESUME_REQUIRED":True,"STAGE7C_REAL_BREAK_FIT_AUTHORIZED":False})
        print(f"[B2] RESUME_REQUIRED valid={len(results)} missing={len(missing)}"); return 3
    df=pd.DataFrame(results); null=df[df.kind=="NULL"].sort_values("replicate_index").copy(); inj=df[df.kind=="INJECTED"].copy()
    nt=null.median_outer_cv_improvement.to_numpy(float)
    null["predictive_p"]=[p_null(i,nt) for i in range(len(nt))]
    null["detected_rule"]=(null.predictive_p<=.05)&null.wald_excludes_zero.astype(bool)&(~null.boundary_flag.astype(bool))
    inj["predictive_p"]=inj.median_outer_cv_improvement.map(lambda x:p_inj(x,nt))
    inj["detected_rule"]=(inj.predictive_p<=.05)&inj.wald_excludes_zero.astype(bool)&(~inj.boundary_flag.astype(bool))&inj.sign_correct.astype(bool)
    master=pd.concat([null,inj],ignore_index=True); master.to_parquet(out/"tables/stage7b2_formal_replicates.parquet",index=False)
    fpr=float(null.detected_rule.mean()); sums=[]
    for sc,g in inj.groupby("scenario"):
        sums.append({"scenario":sc,"R_break_kpc":float(g.R_break_kpc.iloc[0]),"delta_beta":float(g.delta_beta.iloc[0]),"replicates":len(g),
                     "detection_power":float(g.detected_rule.mean()),"median_abs_break_error_kpc":float(g.break_abs_error_kpc.median()),
                     "predictive_p_le_0p05_fraction":float((g.predictive_p<=.05).mean()),"wald_excludes_zero_fraction":float(g.wald_excludes_zero.mean()),
                     "boundary_flag_fraction":float(g.boundary_flag.mean()),"sign_correct_fraction":float(g.sign_correct.mean()),
                     "median_cv_improvement":float(g.median_outer_cv_improvement.median())})
    sm=pd.DataFrame(sums); g=c["formal_gates"]
    sm["target_gate_scenario"]=sm.R_break_kpc.isin(g["target_locations_kpc"])&np.isclose(np.abs(sm.delta_beta),g["target_abs_delta_beta"])
    sm.to_csv(out/"tables/stage7b2_signed_scenario_summary.csv",index=False)
    tar=sm[sm.target_gate_scenario]; ident=len(tar)==4
    fpass=fpr<=g["null_false_positive_rate_max"]; ppass=bool(ident and (tar.detection_power>=g["minimum_detection_power_each_target_scenario"]).all())
    epass=bool(ident and (tar.median_abs_break_error_kpc<=g["median_abs_break_location_error_max_kpc_each_target_scenario"]).all())
    final=bool(fpass and ppass and epass)
    write_json_atomic(out/"tables/stage7b2_null_summary.json",{"null_replicates":256,"false_positive_count":int(null.detected_rule.sum()),"false_positive_rate":fpr,"gate_pass":fpass,
        "median_cv_improvement":float(null.median_outer_cv_improvement.median()),"q95_cv_improvement":float(null.median_outer_cv_improvement.quantile(.95))})
    val={"stage":c["stage"],"implementation_version":c["implementation_version"],"timestamp_utc":now(),"PARENT_STAGE7A_B1_B2B_IDENTITY_READY":pre,
         "FORMAL_PROTOCOL_CANONICAL_SHA256":canonical_sha(prot),"REAL_FEH_M1_BREAK_FIT_PERFORMED":False,"REAL_BREAK_GRID_SCANNED":False,
         "FORMAL_NULL_REPLICATES_COMPLETED":len(null),"FORMAL_INJECTED_REPLICATES_COMPLETED":len(inj),"FORMAL_TOTAL_REPLICATES_COMPLETED":len(master),
         "NULL_CALIBRATED_PVALUES_READY":True,"NULL_FALSE_POSITIVE_RATE":fpr,"NULL_FPR_GATE_PASS":fpass,"TARGET_SCENARIO_IDENTITY_READY":ident,
         "ALL_FOUR_TARGET_POWER_GATES_PASS":ppass,"ALL_FOUR_TARGET_BREAK_ERROR_GATES_PASS":epass,"FORMAL_STAGE7B2_POWER_CALIBRATION_PASS":final,
         "STAGE7B2_FORMAL_COMPLETE":True,"STAGE7C_REAL_BREAK_FIT_AUTHORIZED":final}
    write_json_atomic(out/"validation/stage7b2_validation.json",val)
    write_json_atomic(out/"benchmarks/stage7b2_runtime_benchmark.json",{"workers":workers,"wall_seconds_this_run":time.perf_counter()-start,"median_replicate_runtime_seconds":float(master.runtime_seconds.median()),"checkpoint_resume_supported":True})
    lines=["# Stage-7B2 formal signed injection-recovery",f"Formal pass: `{final}`",f"Null FPR: `{fpr:.4f}`",""]
    for _,r in tar.sort_values(["R_break_kpc","delta_beta"]).iterrows(): lines.append(f"- Rb={r.R_break_kpc:.1f}, delta={r.delta_beta:+.2f}: power={r.detection_power:.3f}, median break error={r.median_abs_break_error_kpc:.3f} kpc")
    lines+=["","No real Fe/H broken-profile fit was performed.",f"Stage-7C authorization: `{final}`."]
    (out/"reports/stage7b2_report.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps({"validation":val,"target_summary":tar.to_dict(orient="records")},indent=2,ensure_ascii=False))
    return 0 if final else 2
if __name__=="__main__": raise SystemExit(main())
