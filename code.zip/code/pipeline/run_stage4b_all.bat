@echo off
call 99_stage4b_selftest.bat || exit /b %errorlevel%
call 28_fit_stage4b.bat || exit /b %errorlevel%
call 29_validate_stage4b.bat || exit /b %errorlevel%
call 30_package_stage4b.bat || exit /b %errorlevel%

