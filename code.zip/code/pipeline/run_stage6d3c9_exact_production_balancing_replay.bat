@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c9_exact_production_balancing_replay.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C9 exact production balancing replay completed.
echo Inspect outputs\stage6d3c9_exact_production_balancing_replay\validation\stage6d3c9_validation.json
endlocal
