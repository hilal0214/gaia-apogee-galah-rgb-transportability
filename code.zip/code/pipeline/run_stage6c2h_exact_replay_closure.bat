@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is unavailable in the active environment.
  exit /b 1
)
python src\stage6c2h_exact_replay_closure.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C2H failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6C2H completed.
echo Inspect outputs\stage6c2h_exact_replay_closure\validation\stage6c2h_validation.json
endlocal
