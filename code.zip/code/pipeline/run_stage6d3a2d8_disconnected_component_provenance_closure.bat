@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d8_disconnected_component_provenance_closure.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2D8 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2D8 provenance-gap closure completed.
echo Inspect outputs\stage6d3a2d8_disconnected_component_provenance_closure\validation\stage6d3a2d8_validation.json
endlocal
