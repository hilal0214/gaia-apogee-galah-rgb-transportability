@echo off
setlocal
cd /d "%~dp0"
python src\stage6d6a_mnras_manuscript_reconciliation.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D6A MNRAS manuscript reconciliation completed.
echo Inspect outputs\stage6d6a_mnras_manuscript_reconciliation\validation\stage6d6a_validation.json
endlocal
