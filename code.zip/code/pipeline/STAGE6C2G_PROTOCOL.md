# Stage-6C2G protocol

Inspection first. Unsupported named-population claims are scrubbed. T06 remains blocked until the exact Stage-4B production writer, solver implementation, parameters, and runner lineage are identified.
