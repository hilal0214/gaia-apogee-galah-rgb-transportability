@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d7_identifier_graph_route_closure.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2D7 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2D7 identifier-graph route closure completed.
echo Inspect outputs\stage6d3a2d7_identifier_graph_route_closure\validation\stage6d3a2d7_validation.json
endlocal
