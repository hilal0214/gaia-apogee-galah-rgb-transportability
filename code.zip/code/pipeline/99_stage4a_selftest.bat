@echo off
python scripts\selftest_stage4a.py
if errorlevel 1 exit /b %errorlevel%

