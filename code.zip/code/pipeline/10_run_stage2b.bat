@echo off
setlocal
python scripts\10_run_stage2b.py --config config\stage2b.yml
if errorlevel 1 exit /b %errorlevel%
endlocal
