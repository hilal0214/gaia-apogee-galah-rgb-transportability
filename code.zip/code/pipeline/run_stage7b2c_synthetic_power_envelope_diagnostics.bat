@echo off
setlocal
cd /d "%~dp0"
python src\stage7b2c_synthetic_power_envelope_diagnostics.py --project-root "%CD%"
exit /b %ERRORLEVEL%
