# Stage 1 frozen protocol

Protocol version: `0.1.1`  
Frozen: `2026-07-31`

Gaia query patch: `0.1.2`  
Added: `2026-07-31`

## Scientific purpose

Stage 1 replaces the previous 200,000-source production limit with a complete,
auditable source census for the APOGEE DR17–GALAH DR4 red-giant parent sample.
It does not fit Galactic gradients and it does not tune a population model.

The stage answers four factual questions:

1. How many catalogue rows, survey-level stars, Gaia-linked stars, and unique
   Gaia DR3 sources exist?
2. How many within-survey duplicates and cross-survey overlaps exist?
3. How many positive and unique survey-provided Gaia identifiers exist, and
   how large is their direct APOGEE–GALAH intersection?
4. Can all unique Gaia DR3 sources be retrieved with a restartable query and a
   uniform Bailer-Jones distance layer?

## Immutable data products

- APOGEE DR17 `allStarLite-dr17-synspec_rev1.fits`.
- GALAH DR4 `galah_dr4_allstar_240705.fits`.
- Gaia DR3 `gaiadr3.gaia_source`.
- Bailer-Jones et al. (2021) distance table
  `external.gaiaedr3_distance`.

## Identifier rules

- The physical APOGEE DR17 `synspec_rev1` FITS header contains
  `GAIAEDR3_SOURCE_ID`; it is treated as a Gaia EDR3 identifier.
- GALAH `gaiadr3_source_id` is treated as a Gaia DR3 identifier.
- The Gaia EDR3 and Gaia DR3 source lists are identical. APOGEE EDR3 source
  IDs are therefore joined directly to `gaiadr3.gaia_source` by exact
  `source_id` equality.
- No positional nearest-neighbour choice and no DR2-neighbourhood mapping is
  applied.
- Positive-row, unique-ID, repeated-row, intersection, and union counts are
  written to the identifier audit before within-survey de-duplication.
- Cross-survey overlap is defined only by a positive Gaia DR3 `source_id`.

## Census and de-duplication rules

Catalogue rows, survey-level stars, and cross-survey union counts are always
reported separately.

For duplicate APOGEE rows, the retained row is selected deterministically by:

1. valid Gaia EDR3/DR3-compatible identifier;
2. `ASPCAPFLAG == 0`;
3. `STARFLAG == 0`;
4. greater finite-label count;
5. higher `SNREV`;
6. more visits;
7. lower original row index.

For duplicate GALAH rows, the retained row is selected by:

1. valid Gaia DR3 identifier;
2. `flag_sp == 0`;
3. greater finite-label count;
4. higher `snr_px_ccd3`;
5. lower original row index.

No row is silently discarded: duplicate counts and selected-row rules are
recorded in machine-readable outputs.

## Selection flags

The broad red-giant audit flag is

`3500 < Teff < 5500 K` and `0 < logg < 3.5`.

It is explicitly a broad red-giant flag, not a pure RGB evolutionary-state
classification.

The default survey-quality audit flags are:

- APOGEE: `ASPCAPFLAG == 0`, `STARFLAG == 0`, and `SNREV >= 50`;
- GALAH: `flag_sp == 0` and `snr_px_ccd3 > 30`.

The GALAH DR4 `flag_fe_h` field is not used because the release documentation
states that it is not a meaningful reliability indicator. Element-specific
GALAH abundances require `flag_X_fe == 0`.

These flags are reported individually. Stage 1 does not select a final
calibration or gradient sample.

## Stage gates

The census gate passes only if:

- the two raw FITS products open successfully;
- raw row counts match their configured releases;
- the source master has unique positive Gaia DR3 IDs;
- mutually exclusive APOGEE-only, GALAH-only, and overlap counts sum exactly
  to the union count;
- the overlap is large enough for the planned held-out calibration audit.

The full Gaia gate additionally requires:

- every planned Gaia-query chunk has completed;
- all requested Gaia DR3 IDs are returned exactly once;
- missing Bailer-Jones distances are counted rather than silently removed.

Legacy values from the 200,000-source draft are comparison benchmarks, not
acceptance targets.

## Mandatory Gaia-query pilot (query patch v0.1.2)

The full archive retrieval is preceded by a deterministic 20,000-source
infrastructure pilot. It contains 8,000 APOGEE-only, 8,000 GALAH-only, and
4,000 overlap sources selected by a frozen SplitMix64 rank with seed
`20260731`. The pilot is used only to test table schemas, exact source-ID
recovery, Bailer-Jones join accounting, interval integrity, and restart/cache
behaviour. It is not used to estimate gradients or tune scientific cuts.

Every ordered request vector, chunk, and query schema has a SHA-256 identity.
Cached files are reused only when the mode, request hash, selection hash, and
query signature all match. Pilot and full caches occupy separate namespaces.
Missing Bailer-Jones rows are counted explicitly and never remove a Gaia source
from the left-joined product.

The identifier overlap (`59,918`) is a census quantity, not the
calibration-ready denominator. Element-valid overlap is approximately
19,600–20,500 before later joint RGB and quality gates; those denominators are
audited in the calibration stage.

The legacy `1,591,571` value equals the raw row sum minus the direct
cross-survey overlap. It is neither the raw total nor a unique-star union,
because within-survey repeat rows and records without positive Gaia IDs remain.
