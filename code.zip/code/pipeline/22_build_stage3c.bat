@echo off
python scripts\22_build_stage3c.py --config config\stage3c.yml

