@echo off
setlocal
cd /d "%~dp0"
python src\stage8b1c1_keyalias_surveylineage_hotfix.py --project-root "%CD%"
exit /b %ERRORLEVEL%
