@echo off
python scripts\25_build_stage4a.py --config config\stage4a.yml
if errorlevel 1 exit /b %errorlevel%

