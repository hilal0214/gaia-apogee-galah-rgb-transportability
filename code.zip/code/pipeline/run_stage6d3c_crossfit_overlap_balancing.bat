@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c_crossfit_overlap_balancing.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C cross-fitted overlap balancing completed.
echo Inspect outputs\stage6d3c_crossfit_overlap_balancing\validation\stage6d3c_validation.json
endlocal
