@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d8e_galah_snr_static_lineage_trace.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3A2D8E completed.
echo Inspect outputs\stage6d3a2d8e_galah_snr_static_lineage_trace\validation\stage6d3a2d8e_validation.json
endlocal
