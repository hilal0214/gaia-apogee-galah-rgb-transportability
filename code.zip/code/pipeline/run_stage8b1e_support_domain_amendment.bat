@echo off
setlocal
cd /d "%~dp0"
python src\stage8b1e_support_domain_amendment.py --project-root "%CD%"
exit /b %ERRORLEVEL%
