@echo off
setlocal
call conda activate rgb-transport-stage1
if errorlevel 1 exit /b 1
python scripts\download_catalogues.py --config config\stage1.yml
