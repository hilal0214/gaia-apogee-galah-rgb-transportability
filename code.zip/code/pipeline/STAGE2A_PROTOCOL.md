# Stage 2A frozen protocol

Version: `0.2.0`  
Date: `2026-08-01`

## Scope

Stage 2A freezes three inputs required by later cross-survey abundance calibration:

1. element-specific APOGEE-GALAH overlap support;
2. Gaia-coordinate adjudication of survey-coordinate anomalies;
3. deterministic held-out fold assignments.

It does not estimate calibration functions, coefficients, corrected abundances,
cross-fitted predictions, or abundance residuals. Those operations belong to
Stage 2B and are blocked until the Stage 2A output bundle is independently audited.

## Frozen Stage 1 identity

The only accepted upstream release is
`RGB_transportability_stage1_outputs_v0_1_2.zip`, SHA-256
`620ec1151aea23ff649ef198c437c9355852f1c6d2733830f905635728f54bee`.
The Stage 2A build additionally verifies the byte hashes of
`overlap_pairs.parquet` and `spectroscopic_source_master.parquet`, the
1,509,277-source Gaia selection hash, Stage 1 PASS status, and the 59,918-source
same-ID overlap count.

## Support definition

The overlap identity is a positive Gaia DR3 `source_id` present in both surveys
after the deterministic within-survey row selection frozen in Stage 1. For each
of `[Fe/H]`, `[Mg/Fe]`, `[Si/Fe]`, `[Ca/Fe]`, and `[Ni/Fe]`, pre-coordinate
support requires:

- the frozen broad-RGB gate in both surveys (`3500<Teff<5500 K` and
  `0<logg<3.5`);
- the frozen survey-specific stellar-parameter quality gate in both surveys;
- the element value, positive uncertainty, and accepted element flag in both
  surveys;
- the GALAH DR4 `flag_fe_h` caveat remains honoured: that broken flag is not
  used for `[Fe/H]`.

APOGEE remains on its native scale. Stage 2A does not transform GALAH labels.

## Gaia-coordinate adjudication

All 59,918 overlap identities are joined to the actual Gaia DR3 `ra` and `dec`
stored in the accepted Stage 1 joined-chunk cache. Survey-pair separations above
300 arcsec are hard mismatches. A survey coordinate is Gaia-confirmed when it
lies within 10 arcsec of the Gaia coordinate, while the competing survey
coordinate is more than 300 arcsec from Gaia.

Primary support excludes every hard survey-pair mismatch, even when Gaia makes
the metadata failure obvious. The sensitivity support reinstates only a hard
mismatch with exactly one Gaia-confirmed survey coordinate. This preserves the
predeclared treatment of the 381 GALAH `kerr`, `field_id=-9`, observing-block
records, including the 12 joint RGB+quality stars.

## Held-out folds

Every one of the 59,918 overlap identities receives one fold before element,
quality, or coordinate exclusions. The assignment is

`SplitMix64(Gaia DR3 source_id, seed=20260801) modulo 5`.

The fold vector is therefore independent of input row order, operating system,
Python's random-number generator, and later element availability. Stage 2B must
use fold `k` only as the held-out set when training the corresponding
cross-fitted calibration on all folds other than `k`. Fold assignments must not
be regenerated or stratified again in Stage 2B.

## Frozen boundary

The Stage 2A validator rejects calibrated/corrected/cross-fitted output columns
and records `stage2b_cross_fitted_abundance_calibration_performed=false` in both
the build and freeze manifests.
