@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d8f_exact_galah_snr_px_ccd3_contract_freeze.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3A2D8F completed.
echo Inspect outputs\stage6d3a2d8f_exact_galah_snr_px_ccd3_contract_freeze\validation\stage6d3a2d8f_validation.json
endlocal
