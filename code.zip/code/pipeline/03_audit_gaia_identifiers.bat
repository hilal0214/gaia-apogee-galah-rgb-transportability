@echo off
setlocal
call conda activate rgb-transport-stage1
if errorlevel 1 exit /b 1
python scripts\02_audit_gaia_identifiers.py --config config\stage1.yml
