@echo off
setlocal
cd /d "%~dp0"
if not exist "inputs\stage6d3a2d9_bridge" mkdir "inputs\stage6d3a2d9_bridge"
python src\stage6d3a2d9_external_bridge_intake_validation.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2D9 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2D9 external bridge intake validation completed.
echo Inspect outputs\stage6d3a2d9_external_bridge_intake_validation\validation\stage6d3a2d9_validation.json
endlocal
