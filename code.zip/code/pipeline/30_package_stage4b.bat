@echo off
python scripts\30_package_stage4b.py --config config\stage4b.yml
if errorlevel 1 exit /b %errorlevel%

