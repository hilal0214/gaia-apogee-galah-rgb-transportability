@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c5_corrected_cellfixed_ridge_path.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C5 corrected cell-fixed ridge path completed.
echo Inspect outputs\stage6d3c5_corrected_cellfixed_ridge_path\validation\stage6d3c5_validation.json
endlocal
