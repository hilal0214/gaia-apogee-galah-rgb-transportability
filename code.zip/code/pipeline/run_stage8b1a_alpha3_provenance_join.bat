@echo off
setlocal
cd /d "%~dp0"
python src\stage8b1a_alpha3_provenance_join.py --project-root "%CD%"
exit /b %ERRORLEVEL%
