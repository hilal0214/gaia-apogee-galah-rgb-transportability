@echo off
setlocal
cd /d "%~dp0"
call 99_stage5a_selftest.bat || exit /b 1
call 31_build_stage5a.bat || exit /b 1
call 32_validate_stage5a.bat || exit /b 1
call 33_package_stage5a.bat || exit /b 1
exit /b 0
