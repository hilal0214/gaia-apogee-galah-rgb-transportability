@echo off
setlocal
python scripts\17_validate_stage3a.py --config config\stage3a.yml
exit /b %ERRORLEVEL%
