@echo off
setlocal
cd /d "%~dp0"
python src\stage6d4a2_exact_estimator_api_freeze.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D4A2 exact estimator API freeze completed.
echo Inspect outputs\stage6d4a2_exact_estimator_api_freeze\validation\stage6d4a2_validation.json
endlocal
