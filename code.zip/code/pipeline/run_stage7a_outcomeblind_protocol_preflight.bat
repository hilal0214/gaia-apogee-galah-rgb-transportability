@echo off
setlocal
cd /d "%~dp0"
python src\stage7a_outcomeblind_protocol_preflight.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-7A outcome-blind radial-break protocol freeze completed.
echo Inspect outputs\stage7a_radial_break_protocol_freeze\validation\stage7a_validation.json
endlocal
