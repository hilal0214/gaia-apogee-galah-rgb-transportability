@echo off
setlocal
cd /d "%~dp0"
python src\stage8f_identifiability_claim_closure.py --project-root "%CD%"
exit /b %ERRORLEVEL%
