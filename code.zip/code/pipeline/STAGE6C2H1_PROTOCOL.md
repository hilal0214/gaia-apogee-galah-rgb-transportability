# Stage-6C2H1 protocol

The exact production script is scripts/28_fit_stage4b.py. A temporary shadow config is created beside config/stage4b.yml to preserve config-relative path semantics. Only output destinations are redirected. Protected Stage-4B products and the original config are hashed before and after replay. Stage-6D work is authorized only after scientific identity passes.
