@echo off
python scripts\24_package_stage3c.py --config config\stage3c.yml

