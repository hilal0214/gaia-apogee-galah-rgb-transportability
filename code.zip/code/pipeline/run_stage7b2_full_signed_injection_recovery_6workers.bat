@echo off
setlocal
cd /d "%~dp0"
python src\stage7b2_full_signed_injection_recovery.py --project-root "%CD%" --workers 6
exit /b %ERRORLEVEL%
