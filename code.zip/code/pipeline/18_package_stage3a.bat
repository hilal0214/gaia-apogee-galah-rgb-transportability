@echo off
setlocal
python scripts\18_package_stage3a.py --config config\stage3a.yml
exit /b %ERRORLEVEL%
