@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is unavailable in the active environment.
  exit /b 1
)
python src\stage6c2a_reconcile_assets.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C2A did not close its minimum source gate.
  echo Inspect outputs\stage6c2a_asset_reconciliation\validation\stage6c2a_validation.json
  exit /b 1
)
echo.
echo [OK] Stage-6C2A asset reconciliation completed.
echo Output: outputs\stage6c2a_asset_reconciliation
endlocal
