@echo off
setlocal
call conda activate rgb-transport-stage1
if errorlevel 1 exit /b 1
python scripts\05_validate_stage1.py --config config\stage1.yml --level full
if errorlevel 1 exit /b 1
python scripts\06_package_outputs.py --config config\stage1.yml
