@echo off
setlocal
cd /d "%~dp0"
python src\stage8b2a_synthetic_morphology_power_pilot.py --project-root "%CD%" --workers 4
exit /b %ERRORLEVEL%
