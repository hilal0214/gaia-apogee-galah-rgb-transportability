# Stage 5A protocol: leakage-safe population-inference design freeze

## Purpose

Stage 5A begins the population layer only after Stage 4A v0.8.1 and Stage 4B
v0.9.0 are byte-frozen. It creates no population inference. Its purpose is to
freeze the feature, cohort, spatial cross-fitting, target-leakage, survey-support,
and interpretive contracts that Stage 5B must obey.

## Why a separate design stage is required

The legacy manuscript classifier used `[Fe/H]`, alpha, `abs(Z)`, and rotation,
then refitted abundance-versus-`R,abs(Z)` gradients inside the assigned classes.
That two-stage construction risks direct outcome leakage and conditioning on a
gradient covariate. Stage 5A removes both pathways before any responsibility is
created.

## Frozen feature views

1. `DESCRIPTIVE_FULL`: `[Fe/H], alpha3, v_R, v_rot, v_Z`. This may describe the
   atlas but cannot be used for a target-abundance gradient.
2. `FE_H_TARGET_SAFE`: `[alpha3, v_R, v_rot, v_Z]` for future Fe/H gradients.
3. `ALPHA3_TARGET_SAFE`: `[Fe/H, v_R, v_rot, v_Z]` for future alpha3 gradients.
4. `OTHER_ELEMENTS_TARGET_SAFE`: `[Fe/H], alpha3, v_R, v_rot, v_Z` for Mg, Si,
   Ca, and Ni gradients.

No view contains `R_GC` or `abs(Z)`. C/N, C, N, Al, and Ti remain excluded.

## Spatial cross-fitting

Every Gaia HEALPix-5 block is assigned deterministically to one of five folds
from a frozen SHA-256 namespace. Stage 5B must compute preprocessing and fit the
mixture on the other four folds, then obtain each star's responsibility only
from the model that did not train on its sky block.

## Mixture contract for Stage 5B

- family: multivariate Student-t mixture;
- nominal component count: K=4;
- sensitivity counts: K=3 and K=5;
- degrees of freedom: 5;
- full covariance with frozen regularisation;
- sixteen deterministic restarts;
- anonymous canonical component names `C1`-`C4`;
- semantic names only after stability and property audits.

An ambiguous state is defined by low maximum responsibility. It is a diagnostic
state, not a fifth physical component. Responsibilities are empirical
cross-fitted mixture responsibilities, not calibrated probabilities of final
Galactic membership.

## Survey and uncertainty boundary

The primary cohort is nominal. Frame-stable and common-support cohorts are
sensitivity layers. Common support is not a selection-function correction.
Abundance error proxies and velocity half-widths are not likelihood sigmas or
feature weights in Stage 5A; they are guards and reserved stress inputs.

## Outputs

Stage 5A writes only the design contract, cohort flow, diagnostic feature
scaling, HEALPix fold map and balance, survey feature balance, feature
correlations, leakage audit, and provenance/validation records. It writes no
mixture parameters, responsibilities, population labels, or gradients.
