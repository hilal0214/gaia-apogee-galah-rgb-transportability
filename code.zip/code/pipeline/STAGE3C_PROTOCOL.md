# Stage 3C protocol: phase-space uncertainty and transport stress

## Scientific boundary

Stage 3C augments the frozen Stage 3B candidate vector with formal random
phase-space uncertainty summaries and two explicit transport stresses.  It does
not change the Stage 3B primary sample, integrate orbits, fit abundance
gradients, or infer Galactic populations.

## Frozen upstream contract

The full Stage 3A quality layer and the Stage 3B nominal phase-space layer are
accepted only when their byte hashes, row count, source-ID order, source-ID
hash, primary/sensitivity counts, and validation records match the values in
`config/stage3c.yml`.

## Formal-random uncertainty propagation

The target is the 331,399-star frozen Stage 3B primary 6D set.  Each star uses
256 fixed antithetic standard-normal draws generated from a nested,
Owen-scrambled SciPy Sobol sequence with seed 20260801.  The same standardized ensemble is used for every star so that
between-star comparisons use common random numbers.  This is a deterministic
integration design, not a claim that different stars share measurement errors.

The Gaia five-parameter covariance is reconstructed from the five formal
errors and ten catalogue correlation coefficients.  No covariance repair is
allowed.  The right-ascension coordinate is sampled in the Gaia `alpha*`
parameter and converted back to right ascension using `cos(delta)`.

Photogeometric distance is not obtained by direct parallax inversion.  The
catalogue lower/median/upper distance quantiles are mapped with a piecewise
log-normal approximation.  The distance latent rank is the negative of the
correlated standardized parallax perturbation, creating a Gaussian-copula
approximation to the missing joint distance--astrometry posterior.  The mapping
reproduces the published lower, median, and upper distance values at latent
z=-1,0,+1.  Radial velocity is sampled independently as a Gaussian using the
frozen analysis uncertainty.

For R, Z, v_R, v_phi, v_rot=-v_phi, v_Z, total speed, and L_Z, Stage 3C records
the 16th, 50th, and 84th percentiles and their half-width.  A 128-versus-256 draw
comparison quantifies numerical integration convergence.  The fraction of
draws inside the already-frozen wide Stage 3B plausibility guard is diagnostic
only and creates no new primary cut.

## Stress layers

The geometric-distance alternative is compared star by star with the
photogeometric primary estimate, including the shift divided by the formal MC
half-width.  Six explicit Galactocentric frame variants separately stress R0,
z_sun, and solar velocity.  Their bounds are operational envelopes, not a
probability distribution or one-sigma frame uncertainties.  Per-star maximum
absolute shifts and aggregate signed/absolute quantiles are retained.

## Limitations

The Bailer-Jones catalogue provides posterior quantiles, not per-star posterior
samples; the three-quantile copula is therefore an approximation.  Gaia
spatially correlated astrometric systematics, spectroscopic binary/RV jitter,
and abundance-label uncertainties are not modelled here.  These limitations
must remain explicit in the manuscript.

## References

- Gaia DR3 source-column definitions: https://www.cosmos.esa.int/web/gaia/dr3
- Bailer-Jones et al. (2021), geometric and photogeometric EDR3 distances:
  https://www2.mpia-hd.mpg.de/~calj/gedr3_distances.html
- Astropy Galactocentric coordinates:
  https://docs.astropy.org/en/stable/coordinates/galactocentric.html
