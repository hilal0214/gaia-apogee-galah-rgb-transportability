# Stage 3B frozen protocol

Version: 0.6.0  
Date: 2026-08-01

## Scope

Stage 3B augments every one of the 393,834 frozen Stage 3A spectroscopic RGB-quality candidates with explicit nominal Galactocentric positions and, where available, velocities. The input row identity and all Stage 3A eligibility flags are preserved one-to-one. No Gaia query or upstream recalibration is performed.

## Frozen upstream identity

- Stage 3A production release SHA-256: `b882b0b0ae42930fa048adeead9a93750e8abaa330993aaf7a38a50b37284908`.
- Stage 3A quality-layer SHA-256: `b747113ef2a0fc58d36a71381fd45bf36a158453b61ec70417df599720d3ded1`.
- Ordered Stage 3A candidate-ID SHA-256: `9053d1009173d8ffbfa75d38da2b3ec8c5b4d403c1dc721139c37415bac177df`.
- Accepted Stage 3A clean 6D primary/sensitivity counts: 331,399 / 360,311.

## Explicit Galactocentric frame

The transformation uses Astropy's named `v4.0` measurement set, but every value is passed explicitly so that a future Astropy default change cannot alter the scientific frame silently:

- Galactic-centre ICRS direction: RA 266.4051 deg, Dec -28.936175 deg;
- Sun-centre distance: 8.122 kpc;
- solar Galactocentric Cartesian velocity: (12.9, 245.6, 7.78) km/s;
- solar height: 20.8 pc;
- roll: 0 deg.

The Astropy runtime version is recorded. Outputs are quantized far below observational precision (positions 10 decimal places in kpc, velocities 8 decimal places in km/s, angles 12 decimal places in radians) to prevent irrelevant platform-level floating-point noise from changing release bytes.

The frame is right-handed and places the Sun at negative x. Cylindrical quantities are

`R = sqrt(x^2+y^2)`,

`v_R = (x v_x + y v_y)/R`,

`v_phi = (x v_y - y v_x)/R`.

Consequently, normal prograde disc rotation is negative in `v_phi` near the Sun. For continuity with the manuscript population diagnostic, Stage 3B stores `v_rot=-v_phi` exactly. It also stores `L_z=x v_y-y v_x=R v_phi`.

## Distance estimators

The Bailer-Jones photogeometric posterior median frozen in Stage 3A is the primary distance. The geometric posterior median is transformed separately and retained with `_geo_alt` column suffixes. Direct inverse parallax remains forbidden.

## Broad phase-space plausibility guard

The primary operational guard requires finite phase space, Galactocentric spherical radius no larger than 200 kpc, and total Galactocentric speed no larger than 1000 km/s. Sensitivity limits are 300 kpc and 1500 km/s. These deliberately broad thresholds identify catastrophic transforms or catalogue failures. They are not a Galactic escape-speed curve and do not imply bound/unbound classification.

Primary/sensitivity phase-space flags inherit the corresponding Stage 3A clean 5D/6D flags. Six label-specific phase-space supports are written for [Fe/H], [Mg/Fe], [Si/Fe], [Ca/Fe], [Ni/Fe], and alpha3. Every Stage 3A primary-6D row rejected by the broad guard is listed explicitly in the extreme-row audit.

## Frozen boundary

Stage 3B does not select a Galactic potential, integrate orbits, calculate actions, propagate phase-space uncertainties, fit abundance gradients, or classify populations. Those operations require separate pre-registered stages after this nominal transform has passed audit.

## Primary implementation reference

- Astropy documentation, *Description of the Galactocentric Coordinate Frame*: https://docs.astropy.org/en/stable/coordinates/galactocentric.html
- Astropy documentation, *Transforming positions and velocities to and from a Galactocentric frame*: https://docs.astropy.org/en/stable/coordinates/example_gallery_plot_galactocentric_frame.html
