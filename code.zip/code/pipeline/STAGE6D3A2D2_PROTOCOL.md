The exact wide Stage-4A design schema is authoritative. The source grain is
`(gaia_dr3_source_id, survey_origin)` after canonical survey mapping. Duplicate
key groups may be collapsed only when all retained anchor fields, labels, and
eligibility flags are numerically or categorically identical. Missing support
covariates may be joined by `(source_id, survey)` or by source ID for
survey-neutral Gaia fields. Survey-specific S/N is mandatory; `snr_na` and
survey-neutral S/N proxies are forbidden. D3B requires sky coordinates, Gaia G,
BP-RP, survey-specific S/N, and at least 500 support-complete rows per survey.


The immutable row-survey identity is `survey_origin`. `preferred_spectroscopic_survey` is contextual provenance only and must not define survey strata, survey-specific S/N joins, or common-footprint balance groups.
