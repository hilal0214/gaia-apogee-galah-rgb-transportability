@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is unavailable in the active environment.
  exit /b 1
)
python src\stage6c2g_solver_provenance_audit.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C2G execution failed.
  exit /b 1
)
echo.
echo [OK] Stage-6C2G solver provenance audit completed.
echo Output: outputs\stage6c2g_solver_provenance_audit
endlocal
