@echo off
setlocal
cd /d "%~dp0"
python src\stage6d2a5_five_label_descriptive_diagnostics.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D2A5 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D2A5 descriptive diagnostics completed.
echo Inspect outputs\stage6d2a5_five_label_descriptive_diagnostics\validation\stage6d2a5_validation.json
endlocal
