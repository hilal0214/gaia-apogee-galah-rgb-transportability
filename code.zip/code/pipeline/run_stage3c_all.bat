@echo off
setlocal
call 99_stage3c_selftest.bat || exit /b 1
call 22_build_stage3c.bat || exit /b 1
call 23_validate_stage3c.bat || exit /b 1
call 24_package_stage3c.bat || exit /b 1
endlocal

