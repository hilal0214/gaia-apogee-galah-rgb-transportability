@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c2_cell_target_entropy_protocol_reconciliation.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C2 completed.
echo Inspect outputs\stage6d3c2_cell_target_entropy_protocol_reconciliation\validation\stage6d3c2_validation.json
endlocal
