@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d5_exact_uint64_functional_crosswalk.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2D5 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2D5 exact UInt64 and functional crosswalk completed.
echo Inspect outputs\stage6d3a2d5_exact_uint64_functional_crosswalk\validation\stage6d3a2d5_validation.json
endlocal
