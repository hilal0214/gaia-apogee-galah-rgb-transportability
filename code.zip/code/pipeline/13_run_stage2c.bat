@echo off
setlocal
python scripts\13_run_stage2c.py --config config\stage2c.yml
if errorlevel 1 exit /b %errorlevel%
endlocal
