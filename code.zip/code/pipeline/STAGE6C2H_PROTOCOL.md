# Stage-6C2H protocol

Only the original Stage-4B writer/runner/config lineage may be replayed. All destinations must be redirected to the Stage-6C2H shadow directory. Frozen Stage-4B outputs must never be modified.
