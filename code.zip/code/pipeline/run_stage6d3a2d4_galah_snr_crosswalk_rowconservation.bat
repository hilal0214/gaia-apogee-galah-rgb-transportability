@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d4_galah_snr_crosswalk_rowconservation.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2D4 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2D4 GALAH S/N crosswalk and row conservation completed.
echo Inspect outputs\stage6d3a2d4_galah_snr_crosswalk_rowconservation\validation\stage6d3a2d4_validation.json
endlocal
