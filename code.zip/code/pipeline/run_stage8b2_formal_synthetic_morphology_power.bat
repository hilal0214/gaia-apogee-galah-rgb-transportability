@echo off
setlocal
cd /d "%~dp0"
python src\stage8b2_formal_synthetic_morphology_power.py --project-root "%CD%" --workers 4
exit /b %ERRORLEVEL%
