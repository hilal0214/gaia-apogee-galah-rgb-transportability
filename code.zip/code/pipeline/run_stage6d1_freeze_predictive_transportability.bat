@echo off
setlocal
cd /d "%~dp0"
python src\stage6d1_freeze_predictive_transportability.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D1 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D1 predictive transportability protocol frozen.
echo Inspect outputs\stage6d1_predictive_transportability_freeze\validation\stage6d1_validation.json
endlocal
