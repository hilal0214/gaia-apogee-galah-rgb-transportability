@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d8d_galah_snr_semantic_provenance_adjudication.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3A2D8D completed.
echo Inspect outputs\stage6d3a2d8d_galah_snr_semantic_provenance_adjudication\validation\stage6d3a2d8d_validation.json
endlocal
