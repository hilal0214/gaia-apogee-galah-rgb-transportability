# Stage-6C2A protocol

Strict schema linkage supersedes Stage-6C1 semantic filename matching. No scientific fit is rerun.
