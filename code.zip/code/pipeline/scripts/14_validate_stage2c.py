from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from stage2c_common import (
    ALPHA3_ELEMENTS,
    COEFFICIENT_COLUMNS,
    ELEMENTS,
    atomic_write_json,
    close_logger,
    element_flow_table,
    ids_sha256,
    load_config,
    load_models_and_metrics,
    origin_element_flow_table,
    predictor_matrix,
    project_path,
    read_json,
    setup_logger,
    sha256_file,
    support_bounds_table,
    support_tiers,
    utc_now,
)


def gate(
    gates: list[dict[str, Any]],
    name: str,
    observed: Any,
    expected: Any,
    passed: bool,
    detail: str,
) -> None:
    gates.append(
        {
            "name": name,
            "observed": observed,
            "expected": expected,
            "passed": bool(passed),
            "detail": detail,
        }
    )


def max_abs(values: np.ndarray) -> float:
    array = np.asarray(values, dtype=float)
    return float(np.max(np.abs(array))) if array.size else 0.0


def arrays_equal(left: np.ndarray, right: np.ndarray) -> bool:
    return len(left) == len(right) and bool(np.array_equal(left, right))


def frame_exact(left: pd.DataFrame, right: pd.DataFrame, sort: list[str]) -> bool:
    try:
        pd.testing.assert_frame_equal(
            left.sort_values(sort).reset_index(drop=True),
            right.sort_values(sort).reset_index(drop=True),
            check_dtype=False,
            check_exact=False,
            rtol=1.0e-13,
            atol=1.0e-13,
        )
    except AssertionError:
        return False
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Stage 2C transport outputs")
    parser.add_argument("--config", default="config/stage2c.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    output_dir = project_path(root, config["paths"]["output_dir"])
    stage1_dir = project_path(root, config["paths"]["stage1_output_dir"])
    star_dir = project_path(root, config["paths"]["stage1_star_level_dir"])
    stage2a_dir = project_path(root, config["paths"]["stage2a_output_dir"])
    stage2b_dir = project_path(root, config["paths"]["stage2b_output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "14_validate_stage2c.log", "stage2c.validate")

    s1 = config["stage1_frozen"]
    s2a = config["stage2a_frozen"]
    s2b = config["stage2b_frozen"]
    outputs = config["outputs"]
    paths = {
        "master": stage1_dir / s1["source_master_file"],
        "stage1_validation": stage1_dir / s1["validation_file"],
        "census_summary": stage1_dir / s1["census_summary_file"],
        "apogee_star": star_dir / s1["apogee_star_level_file"],
        "galah_star": star_dir / s1["galah_star_level_file"],
        "stage2a_overlap": stage2a_dir / s2a["overlap_file"],
        "stage2a_validation": stage2a_dir / s2a["validation_file"],
        "deploy": stage2b_dir / s2b["deploy_models_file"],
        "coefficients": stage2b_dir / s2b["coefficients_file"],
        "metrics": stage2b_dir / s2b["metrics_file"],
        "stage2b_freeze": stage2b_dir / s2b["freeze_manifest_file"],
        "stage2b_validation": stage2b_dir / s2b["validation_file"],
        "atlas": output_dir / outputs["atlas_file"],
        "element_flow": output_dir / outputs["element_flow_file"],
        "origin_flow": output_dir / outputs["origin_element_flow_file"],
        "support_bounds": output_dir / outputs["support_bounds_file"],
        "summary": output_dir / outputs["build_summary_file"],
        "freeze": output_dir / outputs["freeze_manifest_file"],
    }
    missing = [str(path) for path in paths.values() if not path.exists()]
    if missing:
        raise FileNotFoundError("Stage 2C validation inputs are missing: " + "; ".join(missing))

    gates: list[dict[str, Any]] = []
    expected_upstream = {
        "master": s1["source_master_sha256"],
        "stage1_validation": s1["validation_sha256"],
        "census_summary": s1["census_summary_sha256"],
        "stage2a_overlap": s2a["overlap_sha256"],
        "stage2a_validation": s2a["validation_sha256"],
        "deploy": s2b["deploy_models_sha256"],
        "coefficients": s2b["coefficients_sha256"],
        "metrics": s2b["metrics_sha256"],
        "stage2b_freeze": s2b["freeze_manifest_sha256"],
        "stage2b_validation": s2b["validation_sha256"],
    }
    observed_upstream = {
        key: sha256_file(paths[key]) for key in expected_upstream
    }
    gate(
        gates,
        "upstream_byte_identity",
        observed_upstream,
        expected_upstream,
        observed_upstream == expected_upstream,
        "Stage 1, Stage 2A, and Stage 2B frozen files are byte-identical",
    )

    validations = {
        "stage1": read_json(paths["stage1_validation"]),
        "stage2a": read_json(paths["stage2a_validation"]),
        "stage2b": read_json(paths["stage2b_validation"]),
    }
    observed_validation = {
        key: {
            "overall_passed": bool(value.get("overall_passed", False)),
            "n_passed": int(value.get("n_passed", -1)),
            "n_gates": int(value.get("n_gates", -1)),
        }
        for key, value in validations.items()
    }
    upstream_pass = all(value["overall_passed"] for value in observed_validation.values())
    upstream_pass &= observed_validation["stage2b"]["n_passed"] == int(
        s2b["required_passed_gates"]
    )
    gate(
        gates,
        "upstream_validation",
        observed_validation,
        "all upstream releases PASS; Stage 2B is 19/19",
        upstream_pass,
        "accepted validation state is preserved",
    )

    master = pd.read_parquet(paths["master"])
    atlas = pd.read_parquet(paths["atlas"])
    summary = read_json(paths["summary"])
    freeze = read_json(paths["freeze"])
    expected_counts = s1["expected_counts"]
    master_ids = master["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
    atlas_ids = atlas["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
    identity_observed = {
        "master_rows": int(len(master)),
        "atlas_rows": int(len(atlas)),
        "positive": int((atlas_ids > 0).sum()),
        "duplicates": int(pd.Series(atlas_ids).duplicated().sum()),
        "strictly_increasing": bool(np.all(np.diff(atlas_ids) > 0)),
        "id_sha256": ids_sha256(atlas_ids),
        "exact_master_vector": arrays_equal(master_ids, atlas_ids),
    }
    identity_expected = {
        "master_rows": int(expected_counts["source_master"]),
        "atlas_rows": int(expected_counts["source_master"]),
        "positive": int(expected_counts["source_master"]),
        "duplicates": 0,
        "strictly_increasing": True,
        "id_sha256": ids_sha256(master_ids),
        "exact_master_vector": True,
    }
    gate(
        gates,
        "atlas_source_identity",
        identity_observed,
        identity_expected,
        identity_observed == identity_expected,
        "one output row per frozen positive Gaia DR3 source ID",
    )

    origin_exact = True
    for column in ("has_apogee", "has_galah", "survey_origin"):
        origin_exact &= bool(
            np.array_equal(atlas[column].to_numpy(), master[column].to_numpy())
        )
    origin_counts = atlas["survey_origin"].value_counts().to_dict()
    origin_expected = {
        origin: int(expected_counts[origin])
        for origin in ("APOGEE_only", "GALAH_only", "overlap")
    }
    origin_observed = {key: int(origin_counts.get(key, 0)) for key in origin_expected}
    gate(
        gates,
        "origin_and_membership_provenance",
        {"counts": origin_observed, "columns_exact": origin_exact},
        {"counts": origin_expected, "columns_exact": True},
        origin_exact and origin_observed == origin_expected,
        "survey origin and membership flags are inherited without alteration",
    )

    apogee_ids = np.sort(
        pd.read_parquet(paths["apogee_star"], columns=["gaia_dr3_source_id"])[
            "gaia_dr3_source_id"
        ]
        .fillna(0)
        .astype("int64")
        .loc[lambda value: value.gt(0)]
        .to_numpy()
    )
    galah_ids = np.sort(
        pd.read_parquet(paths["galah_star"], columns=["gaia_dr3_source_id"])[
            "gaia_dr3_source_id"
        ]
        .fillna(0)
        .astype("int64")
        .loc[lambda value: value.gt(0)]
        .to_numpy()
    )
    expected_apogee_ids = master.loc[
        master["has_apogee"].astype(bool), "gaia_dr3_source_id"
    ].to_numpy(dtype=np.int64)
    expected_galah_ids = master.loc[
        master["has_galah"].astype(bool), "gaia_dr3_source_id"
    ].to_numpy(dtype=np.int64)
    star_observed = {
        "apogee_positive": int(len(apogee_ids)),
        "galah_positive": int(len(galah_ids)),
        "apogee_exact": arrays_equal(apogee_ids, expected_apogee_ids),
        "galah_exact": arrays_equal(galah_ids, expected_galah_ids),
        "apogee_sha256": sha256_file(paths["apogee_star"]),
        "galah_sha256": sha256_file(paths["galah_star"]),
    }
    star_expected = {
        "apogee_positive": int(expected_counts["apogee_positive_ids"]),
        "galah_positive": int(expected_counts["galah_positive_ids"]),
        "apogee_exact": True,
        "galah_exact": True,
        "apogee_sha256": freeze["input_sha256"]["apogee_star_level"],
        "galah_sha256": freeze["input_sha256"]["galah_star_level"],
    }
    gate(
        gates,
        "star_level_membership_identity",
        star_observed,
        star_expected,
        star_observed == star_expected,
        "deterministic survey-level rows exactly span source-master memberships",
    )

    coordinate = pd.read_parquet(
        paths["stage2a_overlap"],
        columns=[
            "gaia_dr3_source_id",
            "coordinate_status",
            "coordinate_hard_mismatch",
            "coordinate_primary_ok",
            "coordinate_sensitivity_ok",
        ],
    ).set_index("gaia_dr3_source_id")
    overlap_atlas = atlas.loc[atlas["survey_origin"].eq("overlap")].set_index(
        "gaia_dr3_source_id"
    )
    coordinate_exact = overlap_atlas.index.equals(coordinate.index)
    for column in (
        "coordinate_status",
        "coordinate_hard_mismatch",
        "coordinate_primary_ok",
        "coordinate_sensitivity_ok",
    ):
        coordinate_exact &= bool(
            np.array_equal(
                overlap_atlas.loc[coordinate.index, column].to_numpy(),
                coordinate[column].to_numpy(),
            )
        )
    nonoverlap = atlas["survey_origin"].ne("overlap")
    nonoverlap_default = bool(
        atlas.loc[nonoverlap, "coordinate_status"].eq("NOT_APPLICABLE").all()
        and atlas.loc[nonoverlap, "coordinate_primary_ok"].all()
        and atlas.loc[nonoverlap, "coordinate_sensitivity_ok"].all()
        and ~atlas.loc[nonoverlap, "coordinate_hard_mismatch"].any()
    )
    coordinate_observed = {
        "overlap_rows": int(len(overlap_atlas)),
        "hard_mismatches": int(atlas["coordinate_hard_mismatch"].sum()),
        "overlap_exact": coordinate_exact,
        "nonoverlap_default": nonoverlap_default,
    }
    coordinate_expected = {
        "overlap_rows": int(s2a["expected_overlap_rows"]),
        "hard_mismatches": int(s2a["expected_hard_coordinate_mismatches"]),
        "overlap_exact": True,
        "nonoverlap_default": True,
    }
    gate(
        gates,
        "coordinate_policy_transport",
        coordinate_observed,
        coordinate_expected,
        coordinate_observed == coordinate_expected,
        "Stage 2A overlap adjudication is preserved and not applied to single-survey rows",
    )

    deploy, coefficients, metrics = load_models_and_metrics(
        paths["deploy"], paths["coefficients"], paths["metrics"]
    )
    model_hashes = {
        "deploy_model_spec": deploy.get("model_spec_sha256"),
        "config_model_spec": s2b["model_spec_sha256"],
        "summary_model_spec": summary["upstream"]["stage2b_model_spec_sha256"],
    }
    gate(
        gates,
        "model_specification_freeze",
        model_hashes,
        {key: s2b["model_spec_sha256"] for key in model_hashes},
        len(set(model_hashes.values())) == 1
        and next(iter(model_hashes.values())) == s2b["model_spec_sha256"],
        "only frozen primary deploy models are used",
    )

    matrix, predictors_finite = predictor_matrix(atlas)
    tolerance = float(config["validation"]["prediction_absolute_tolerance"])
    eligibility_exact = True
    equation_errors: dict[str, Any] = {}
    tier_exact: dict[str, bool] = {}
    provenance_exact = True
    flag_exact = True
    nested_ok = True
    extrapolated_primary = 0
    for element in ELEMENTS:
        apogee_value = pd.to_numeric(atlas[f"apogee_{element}"], errors="coerce").to_numpy(float)
        apogee_error = pd.to_numeric(atlas[f"apogee_{element}_err"], errors="coerce").to_numpy(float)
        galah_value = pd.to_numeric(atlas[f"galah_{element}"], errors="coerce").to_numpy(float)
        galah_error = pd.to_numeric(atlas[f"galah_{element}_err"], errors="coerce").to_numpy(float)
        expected_apogee_eligible = (
            atlas["apogee_broad_rg_and_quality"].fillna(False).astype(bool).to_numpy()
            & atlas[f"apogee_valid_{element}"].fillna(False).astype(bool).to_numpy()
            & np.isfinite(apogee_value)
            & np.isfinite(apogee_error)
            & (apogee_error > 0)
        )
        expected_galah_eligible = (
            atlas["galah_broad_rg_and_quality"].fillna(False).astype(bool).to_numpy()
            & atlas[f"galah_valid_{element}"].fillna(False).astype(bool).to_numpy()
            & predictors_finite
            & np.isfinite(galah_value)
            & np.isfinite(galah_error)
            & (galah_error > 0)
        )
        eligibility_exact &= arrays_equal(
            expected_apogee_eligible,
            atlas[f"{element}_apogee_eligible"].to_numpy(bool),
        )
        eligibility_exact &= arrays_equal(
            expected_galah_eligible,
            atlas[f"{element}_galah_transport_eligible"].to_numpy(bool),
        )

        model = deploy["models"]["primary"][element]
        beta = np.asarray(
            [float(model["coefficients"][column]) for column in COEFFICIENT_COLUMNS]
        )
        expected_offset = matrix[expected_galah_eligible] @ beta
        observed_offset = atlas.loc[
            expected_galah_eligible, f"{element}_galah_predicted_offset"
        ].to_numpy(float)
        offset_error = max_abs(expected_offset - observed_offset)
        expected_corrected = galah_value[expected_galah_eligible] - expected_offset
        observed_corrected = atlas.loc[
            expected_galah_eligible, f"{element}_galah_corrected"
        ].to_numpy(float)
        corrected_error = max_abs(expected_corrected - observed_corrected)

        fold_rows = coefficients.loc[
            coefficients["element"].eq(element)
            & coefficients["analysis_set"].eq("primary")
            & coefficients["model_role"].eq("crossfit_fold")
        ].sort_values("heldout_fold")
        fold_betas = fold_rows.loc[:, COEFFICIENT_COLUMNS].to_numpy(float)
        expected_fold_sd = np.std(
            matrix[expected_galah_eligible] @ fold_betas.T, axis=1, ddof=1
        )
        observed_fold_sd = atlas.loc[
            expected_galah_eligible, f"{element}_galah_fold_model_sd"
        ].to_numpy(float)
        fold_sd_error = max_abs(expected_fold_sd - observed_fold_sd)
        metric_row = metrics.loc[
            metrics["element"].eq(element)
            & metrics["analysis_set"].eq("primary")
        ].iloc[0]
        scatter = float(metric_row["post_crossfit_sigma_mad_dex"])
        expected_error_proxy = np.sqrt(
            galah_error[expected_galah_eligible] ** 2
            + scatter**2
            + expected_fold_sd**2
        )
        observed_error_proxy = atlas.loc[
            expected_galah_eligible, f"{element}_galah_transport_error_proxy"
        ].to_numpy(float)
        proxy_error = max_abs(expected_error_proxy - observed_error_proxy)
        equation_errors[element] = {
            "offset": offset_error,
            "corrected": corrected_error,
            "fold_sd": fold_sd_error,
            "error_proxy": proxy_error,
        }

        expected_tier = support_tiers(
            matrix, expected_galah_eligible, model["feature_support"]
        )
        observed_tier = atlas[f"{element}_galah_support_tier"].astype(str).to_numpy()
        tier_exact[element] = arrays_equal(expected_tier, observed_tier)
        observed_support = np.isin(expected_tier, ("CORE_99", "EDGE_OBSERVED"))
        core_support = expected_tier == "CORE_99"
        coord_primary = atlas["coordinate_primary_ok"].to_numpy(bool)
        coord_sensitivity = atlas["coordinate_sensitivity_ok"].to_numpy(bool)
        expected_galah_primary = expected_galah_eligible & observed_support & coord_primary
        expected_galah_core = expected_galah_eligible & core_support & coord_primary
        expected_galah_sensitivity = expected_galah_eligible & coord_sensitivity

        use_apogee = expected_apogee_eligible
        use_galah = ~use_apogee & expected_galah_eligible
        expected_source = np.select(
            [use_apogee, use_galah],
            ["APOGEE_NATIVE", "GALAH_CORRECTED"],
            default="UNAVAILABLE",
        )
        provenance_exact &= arrays_equal(
            expected_source, atlas[f"{element}_hom_source"].astype(str).to_numpy()
        )
        expected_hom = np.where(
            use_apogee,
            apogee_value,
            np.where(use_galah, atlas[f"{element}_galah_corrected"].to_numpy(float), np.nan),
        )
        observed_hom = atlas[f"{element}_hom"].to_numpy(float)
        finite_hom = np.isfinite(expected_hom)
        provenance_exact &= max_abs(expected_hom[finite_hom] - observed_hom[finite_hom]) <= tolerance
        provenance_exact &= arrays_equal(np.isnan(expected_hom), np.isnan(observed_hom))

        expected_primary = use_apogee | (use_galah & expected_galah_primary)
        expected_core = use_apogee | (use_galah & expected_galah_core)
        expected_sensitivity = use_apogee | (use_galah & expected_galah_sensitivity)
        flag_exact &= arrays_equal(
            expected_galah_primary,
            atlas[f"{element}_galah_primary_ok"].to_numpy(bool),
        )
        flag_exact &= arrays_equal(
            expected_galah_core,
            atlas[f"{element}_galah_core_ok"].to_numpy(bool),
        )
        flag_exact &= arrays_equal(
            expected_galah_sensitivity,
            atlas[f"{element}_galah_sensitivity_ok"].to_numpy(bool),
        )
        flag_exact &= arrays_equal(
            expected_primary, atlas[f"{element}_hom_primary_ok"].to_numpy(bool)
        )
        flag_exact &= arrays_equal(
            expected_core, atlas[f"{element}_hom_core_ok"].to_numpy(bool)
        )
        flag_exact &= arrays_equal(
            expected_sensitivity,
            atlas[f"{element}_hom_sensitivity_ok"].to_numpy(bool),
        )
        nested_ok &= bool(np.all(~expected_core | expected_primary))
        nested_ok &= bool(np.all(~expected_primary | expected_sensitivity))
        extrapolated_primary += int(
            (use_galah & expected_primary & (expected_tier == "EXTRAPOLATED")).sum()
        )

    gate(
        gates,
        "survey_and_label_eligibility",
        {"exact": eligibility_exact},
        {"exact": True},
        eligibility_exact,
        "native survey quality, validity, formal-error, and finite-predictor gates recompute",
    )
    max_equation_error = max(
        value for element in equation_errors.values() for value in element.values()
    )
    gate(
        gates,
        "transport_equations",
        {"by_element": equation_errors, "maximum": max_equation_error},
        f"all <= {tolerance}",
        max_equation_error <= tolerance,
        "deploy offset, correction, fold dispersion, and empirical error proxy recompute",
    )
    gate(
        gates,
        "support_tier_recomputation",
        tier_exact,
        {element: True for element in ELEMENTS},
        all(tier_exact.values()),
        "CORE_99, EDGE_OBSERVED, EXTRAPOLATED, and NOT_ELIGIBLE tiers are exact",
    )
    gate(
        gates,
        "homogenised_label_provenance",
        {"exact": provenance_exact},
        {"exact": True},
        provenance_exact,
        "APOGEE native labels have priority; GALAH is corrected only when APOGEE is unavailable",
    )
    gate(
        gates,
        "transport_flag_algebra",
        {"exact": flag_exact},
        {"exact": True},
        flag_exact,
        "primary, core, and sensitivity flags recompute for every element",
    )
    gate(
        gates,
        "nested_analysis_sets_and_no_primary_extrapolation",
        {"nested": nested_ok, "extrapolated_primary_galah": extrapolated_primary},
        {"nested": True, "extrapolated_primary_galah": 0},
        nested_ok and extrapolated_primary == 0,
        "core is nested in primary, primary in sensitivity, and extrapolated GALAH labels are not primary",
    )

    alpha_values = np.column_stack(
        [atlas[f"{element}_hom"].to_numpy(float) for element in ALPHA3_ELEMENTS]
    )
    alpha_errors = np.column_stack(
        [atlas[f"{element}_hom_error_proxy"].to_numpy(float) for element in ALPHA3_ELEMENTS]
    )
    alpha_primary = np.column_stack(
        [atlas[f"{element}_hom_primary_ok"].to_numpy(bool) for element in ALPHA3_ELEMENTS]
    ) & np.isfinite(alpha_values)
    alpha_core = np.column_stack(
        [atlas[f"{element}_hom_core_ok"].to_numpy(bool) for element in ALPHA3_ELEMENTS]
    ) & np.isfinite(alpha_values)
    alpha_sensitivity = np.column_stack(
        [atlas[f"{element}_hom_sensitivity_ok"].to_numpy(bool) for element in ALPHA3_ELEMENTS]
    ) & np.isfinite(alpha_values)
    n_primary = alpha_primary.sum(axis=1).astype(np.int8)
    complete = n_primary == 3
    expected_alpha = np.full(len(atlas), np.nan)
    expected_alpha_error = np.full(len(atlas), np.nan)
    expected_alpha[complete] = np.mean(alpha_values[complete], axis=1)
    expected_alpha_error[complete] = np.sqrt(np.sum(alpha_errors[complete] ** 2, axis=1)) / 3.0
    observed_alpha = atlas["alpha3_hom"].to_numpy(float)
    observed_alpha_error = atlas["alpha3_hom_error_proxy"].to_numpy(float)
    alpha_error = max_abs(expected_alpha[complete] - observed_alpha[complete])
    alpha_proxy_error = max_abs(expected_alpha_error[complete] - observed_alpha_error[complete])
    alpha_exact = arrays_equal(n_primary, atlas["alpha3_n_primary"].to_numpy(np.int8))
    alpha_exact &= arrays_equal(
        alpha_core.sum(axis=1).astype(np.int8), atlas["alpha3_n_core"].to_numpy(np.int8)
    )
    alpha_exact &= arrays_equal(
        alpha_sensitivity.sum(axis=1).astype(np.int8),
        atlas["alpha3_n_sensitivity"].to_numpy(np.int8),
    )
    alpha_exact &= arrays_equal(complete, atlas["alpha3_primary_ok"].to_numpy(bool))
    alpha_exact &= arrays_equal(
        alpha_core.sum(axis=1) == 3, atlas["alpha3_core_ok"].to_numpy(bool)
    )
    alpha_exact &= arrays_equal(
        alpha_sensitivity.sum(axis=1) == 3,
        atlas["alpha3_sensitivity_ok"].to_numpy(bool),
    )
    alpha_tolerance = float(config["validation"]["alpha_absolute_tolerance"])
    gate(
        gates,
        "alpha3_fixed_definition",
        {
            "count_and_flags_exact": alpha_exact,
            "value_max_abs_error": alpha_error,
            "error_proxy_max_abs_error": alpha_proxy_error,
            "primary_rows": int(complete.sum()),
        },
        f"exact flags and both errors <= {alpha_tolerance}",
        alpha_exact
        and alpha_error <= alpha_tolerance
        and alpha_proxy_error <= alpha_tolerance,
        "alpha3 is the unweighted Mg-Si-Ca mean and requires all three primary labels",
    )

    observed_element_flow = pd.read_csv(paths["element_flow"])
    expected_element_flow = element_flow_table(atlas)
    observed_origin_flow = pd.read_csv(paths["origin_flow"])
    expected_origin_flow = origin_element_flow_table(atlas)
    flow_exact = frame_exact(observed_element_flow, expected_element_flow, ["element"])
    flow_exact &= frame_exact(
        observed_origin_flow, expected_origin_flow, ["survey_origin", "element"]
    )
    gate(
        gates,
        "flow_table_recomputation",
        {"element_flow_exact": flow_exact, "element_rows": len(observed_element_flow), "origin_rows": len(observed_origin_flow)},
        {"element_flow_exact": True, "element_rows": 5, "origin_rows": 15},
        flow_exact and len(observed_element_flow) == 5 and len(observed_origin_flow) == 15,
        "element and origin flow tables recompute from the atlas",
    )

    observed_bounds = pd.read_csv(paths["support_bounds"])
    expected_bounds = support_bounds_table(deploy)
    bounds_exact = frame_exact(observed_bounds, expected_bounds, ["element", "predictor"])
    gate(
        gates,
        "support_bounds_identity",
        {"rows": int(len(observed_bounds)), "exact": bounds_exact},
        {"rows": 15, "exact": True},
        bounds_exact and len(observed_bounds) == 15,
        "transport support rectangles are copied from primary deploy models",
    )

    current_outputs = {
        paths["atlas"].name: sha256_file(paths["atlas"]),
        paths["element_flow"].name: sha256_file(paths["element_flow"]),
        paths["origin_flow"].name: sha256_file(paths["origin_flow"]),
        paths["support_bounds"].name: sha256_file(paths["support_bounds"]),
        paths["summary"].name: sha256_file(paths["summary"]),
    }
    freeze_hashes = freeze["output_sha256"]
    summary_hashes = summary["output_sha256"]
    output_hash_exact = current_outputs == freeze_hashes
    output_hash_exact &= all(current_outputs[key] == value for key, value in summary_hashes.items())
    gate(
        gates,
        "output_hash_freeze",
        current_outputs,
        freeze_hashes,
        output_hash_exact,
        "all Stage 2C science products have frozen byte identities",
    )

    forbidden_columns = {
        "parallax",
        "pmra",
        "pmdec",
        "ruwe",
        "r_med_geo",
        "r_med_photogeo",
        "galactocentric_r_kpc",
        "galactocentric_z_kpc",
        "v_phi_kms",
        "population_class",
    }
    boundary = config["science_boundary"]
    boundary_observed = {
        "summary": summary["science_boundary"],
        "freeze": freeze["science_boundary"],
        "forbidden_columns_present": sorted(forbidden_columns.intersection(atlas.columns)),
    }
    boundary_pass = summary["science_boundary"] == boundary
    boundary_pass &= freeze["science_boundary"] == boundary
    boundary_pass &= not boundary_observed["forbidden_columns_present"]
    gate(
        gates,
        "stage2c_science_boundary",
        boundary_observed,
        {"summary": boundary, "freeze": boundary, "forbidden_columns_present": []},
        boundary_pass,
        "spectroscopic transport only; no Gaia clean selection, phase space, gradients, or populations",
    )

    passed = sum(bool(item["passed"]) for item in gates)
    result = {
        "stage": "2C validation",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "overall_passed": passed == len(gates),
        "n_gates": len(gates),
        "n_passed": passed,
        "gates": gates,
    }
    validation_path = output_dir / outputs["validation_file"]
    atomic_write_json(result, validation_path)
    report_path = output_dir / outputs["validation_report_file"]
    lines = [
        "# Stage 2C validation report",
        "",
        f"Overall: **{'PASS' if result['overall_passed'] else 'FAIL'}**",
        "",
        f"Protocol: `{config['project']['version']}`",
        "",
        "| Gate | Result | Detail |",
        "|---|---:|---|",
    ]
    for item in gates:
        lines.append(
            f"| `{item['name']}` | {'PASS' if item['passed'] else 'FAIL'} | {item['detail']} |"
        )
    lines.extend(
        [
            "",
            "Stage 2C applies frozen APOGEE--GALAH abundance mappings to the full spectroscopic census and writes provenance and extrapolation tiers. Gaia clean gates, phase space, gradients, and population inference remain outside this stage.",
            "",
        ]
    )
    report_path.write_text("\n".join(lines), encoding="utf-8")
    logger.info(
        "Stage 2C validation passed=%s; gates=%d/%d; report=%s",
        result["overall_passed"],
        passed,
        len(gates),
        report_path,
    )
    close_logger(logger)
    return 0 if result["overall_passed"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)

