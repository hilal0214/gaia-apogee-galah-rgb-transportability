from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

for _thread_variable in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ.setdefault(_thread_variable, "1")

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import yaml
from scipy.linalg import solve_triangular
from scipy.special import gammaln, logsumexp


BASE_FEATURES = (
    "fe_h_hom",
    "alpha3_hom",
    "v_R_gc_kms",
    "v_rot_gc_kms",
    "v_z_gc_kms",
)
SOURCE_GROUPS = ("APOGEE_NATIVE", "GALAH_CORRECTED")


@dataclass
class StudentTMixtureFit:
    weights: np.ndarray
    means: np.ndarray
    covariances: np.ndarray
    log_likelihood: float
    iterations: int
    converged: bool
    monotonic: bool
    last_relative_improvement: float
    minimum_eigenvalue: float
    maximum_condition_number: float


def load_config(path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {config_path}")
    return config, config_path.parent.parent


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def setup_logger(path: Path, name: str) -> logging.Logger:
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def close_logger(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        handler.flush()
        handler.close()
        logger.removeHandler(handler)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def ids_sha256(values: Sequence[int] | np.ndarray | pd.Series) -> str:
    digest = hashlib.sha256()
    for value in np.asarray(values, dtype=np.int64):
        digest.update(f"{int(value)}\n".encode("ascii"))
    return digest.hexdigest()


def stable_seed(namespace: str, model_id: str) -> int:
    payload = f"{namespace}|{model_id}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "little")


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="\n",
        dir=path.parent,
        prefix=f".{path.name}.",
        delete=False,
    ) as handle:
        temporary = Path(handle.name)
        json.dump(payload, handle, indent=2, sort_keys=True, ensure_ascii=True, allow_nan=False)
        handle.write("\n")
    temporary.replace(path)


def atomic_write_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="",
        dir=path.parent,
        prefix=f".{path.name}.",
        delete=False,
    ) as handle:
        temporary = Path(handle.name)
        frame.to_csv(handle, index=False, lineterminator="\n", float_format="%.17g")
    temporary.replace(path)


def atomic_write_parquet(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="wb", dir=path.parent, prefix=f".{path.name}.", delete=False
    ) as handle:
        temporary = Path(handle.name)
    table = pa.Table.from_pandas(frame, preserve_index=False).replace_schema_metadata(None)
    pq.write_table(
        table,
        temporary,
        compression="zstd",
        compression_level=9,
        use_dictionary=True,
        write_statistics=True,
        version="2.6",
        data_page_version="1.0",
    )
    temporary.replace(path)


def flag(frame: pd.DataFrame, column: str) -> np.ndarray:
    return frame[column].fillna(False).astype(bool).to_numpy()


def number(frame: pd.DataFrame, column: str) -> np.ndarray:
    return pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=float)


def selected_input_columns() -> list[str]:
    return [
        "gaia_dr3_source_id",
        "gaia_healpix5",
        "fe_h_hom",
        "alpha3_hom",
        "fe_h_hom_source",
        "alpha3_source",
        "v_R_gc_kms",
        "v_rot_gc_kms",
        "v_z_gc_kms",
        "population_feature_primary_ok",
        "population_feature_frame_stable_ok",
        "population_feature_gradient_common_support_sensitivity_ok",
    ]


def view_inventory(config: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for view in config["population_inference"]["model_views"]:
        for components in view["component_counts"]:
            rows.append(
                {
                    "name": str(view["name"]),
                    "slug": str(view["slug"]),
                    "features": tuple(str(value) for value in view["features"]),
                    "targets": tuple(str(value) for value in view["targets"]),
                    "allowed_for_population_gradient": bool(view["allowed_for_population_gradient"]),
                    "components": int(components),
                }
            )
    return rows


def responsibility_probability_columns(config: Mapping[str, Any]) -> list[str]:
    columns: list[str] = []
    for row in view_inventory(config):
        columns.extend(
            f"{row['slug']}_k{row['components']}_c{component}_p"
            for component in range(1, row["components"] + 1)
        )
    return columns


def k4_diagnostic_columns(config: Mapping[str, Any]) -> list[str]:
    columns: list[str] = []
    for row in view_inventory(config):
        if row["components"] != 4:
            continue
        prefix = f"{row['slug']}_k4"
        columns.extend(
            [
                f"{prefix}_max_p",
                f"{prefix}_entropy_norm",
                f"{prefix}_secure60",
                f"{prefix}_secure70",
                f"{prefix}_secure80",
            ]
        )
    return columns


def population_source_group(frame: pd.DataFrame) -> np.ndarray:
    fe = frame["fe_h_hom_source"].astype("string").fillna("NOT_AVAILABLE").to_numpy(str)
    alpha = frame["alpha3_source"].astype("string").fillna("NOT_AVAILABLE").to_numpy(str)
    output = np.full(len(frame), "MIXED_OR_OTHER", dtype=object)
    for group in SOURCE_GROUPS:
        output[(fe == group) & (alpha == group)] = group
    return output.astype(str)


def robust_scaler(
    values: np.ndarray, mad_to_sigma: float, minimum_scale: float
) -> tuple[np.ndarray, np.ndarray]:
    center = np.median(values, axis=0)
    mad = np.median(np.abs(values - center), axis=0)
    scale = np.maximum(mad_to_sigma * mad, minimum_scale)
    if not np.isfinite(center).all() or not np.isfinite(scale).all() or np.any(scale <= 0.0):
        raise ValueError("Invalid training-fold robust scaler")
    return center.astype(float), scale.astype(float)


def _regularize_covariance(covariance: np.ndarray, regularization: float) -> np.ndarray:
    covariance = np.asarray(covariance, dtype=float)
    covariance = 0.5 * (covariance + covariance.T)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    eigenvalues = np.maximum(eigenvalues, regularization)
    return (eigenvectors * eigenvalues) @ eigenvectors.T


def mixture_log_terms(
    values: np.ndarray,
    weights: np.ndarray,
    means: np.ndarray,
    covariances: np.ndarray,
    degrees_of_freedom: float,
) -> tuple[np.ndarray, np.ndarray]:
    rows, dimensions = values.shape
    components = len(weights)
    log_terms = np.empty((rows, components), dtype=float)
    deltas = np.empty((rows, components), dtype=float)
    constant = gammaln((degrees_of_freedom + dimensions) / 2.0) - gammaln(
        degrees_of_freedom / 2.0
    ) - 0.5 * dimensions * np.log(degrees_of_freedom * np.pi)
    for component in range(components):
        covariance = covariances[component]
        cholesky = np.linalg.cholesky(covariance)
        centered = values - means[component]
        solved = solve_triangular(
            cholesky, centered.T, lower=True, check_finite=False, overwrite_b=False
        ).T
        delta = np.einsum("ij,ij->i", solved, solved, optimize=True)
        log_determinant = 2.0 * float(np.log(np.diag(cholesky)).sum())
        deltas[:, component] = delta
        log_terms[:, component] = (
            np.log(max(float(weights[component]), 1.0e-300))
            + constant
            - 0.5 * log_determinant
            - 0.5
            * (degrees_of_freedom + dimensions)
            * np.log1p(delta / degrees_of_freedom)
        )
    return log_terms, deltas


def predict_responsibilities(
    values: np.ndarray,
    weights: np.ndarray,
    means: np.ndarray,
    covariances: np.ndarray,
    degrees_of_freedom: float,
) -> tuple[np.ndarray, np.ndarray]:
    log_terms, _ = mixture_log_terms(
        values, weights, means, covariances, degrees_of_freedom
    )
    log_normalizer = logsumexp(log_terms, axis=1)
    responsibilities = np.exp(log_terms - log_normalizer[:, None])
    return responsibilities, log_normalizer


def _kmeans_initialization(
    values: np.ndarray,
    components: int,
    seed: int,
    covariance_regularization: float,
    lloyd_iterations: int = 10,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    rows, dimensions = values.shape
    generator = np.random.Generator(np.random.PCG64DXSM(seed))
    centers = np.empty((components, dimensions), dtype=float)
    first = int(generator.integers(rows))
    centers[0] = values[first]
    distance = np.einsum(
        "ij,ij->i", values - centers[0], values - centers[0], optimize=True
    )
    for component in range(1, components):
        total = float(distance.sum())
        if not np.isfinite(total) or total <= 0.0:
            index = int(generator.integers(rows))
        else:
            threshold = float(generator.random()) * total
            index = int(np.searchsorted(np.cumsum(distance), threshold, side="right"))
            index = min(index, rows - 1)
        centers[component] = values[index]
        new_distance = np.einsum(
            "ij,ij->i", values - centers[component], values - centers[component], optimize=True
        )
        distance = np.minimum(distance, new_distance)

    labels = np.zeros(rows, dtype=np.int16)
    for _ in range(lloyd_iterations):
        distances = np.column_stack(
            [
                np.einsum(
                    "ij,ij->i", values - center, values - center, optimize=True
                )
                for center in centers
            ]
        )
        updated = np.argmin(distances, axis=1).astype(np.int16)
        if np.array_equal(updated, labels):
            labels = updated
            break
        labels = updated
        for component in range(components):
            mask = labels == component
            if mask.any():
                centers[component] = values[mask].mean(axis=0)
            else:
                nearest = distances.min(axis=1)
                centers[component] = values[int(np.argmax(nearest))]

    global_covariance = _regularize_covariance(
        np.cov(values, rowvar=False, bias=True), covariance_regularization
    )
    weights = np.empty(components, dtype=float)
    covariances = np.empty((components, dimensions, dimensions), dtype=float)
    for component in range(components):
        mask = labels == component
        weights[component] = max(float(mask.mean()), 1.0 / rows)
        if int(mask.sum()) > dimensions:
            centered = values[mask] - centers[component]
            covariance = centered.T @ centered / int(mask.sum())
            covariances[component] = _regularize_covariance(
                covariance, covariance_regularization
            )
        else:
            covariances[component] = global_covariance
    weights /= weights.sum()
    return weights, centers, covariances


def fit_student_t_mixture(
    values: np.ndarray,
    components: int,
    degrees_of_freedom: float,
    covariance_regularization: float,
    maximum_iterations: int,
    relative_tolerance: float,
    minimum_iterations: int,
    initialization: tuple[np.ndarray, np.ndarray, np.ndarray],
) -> StudentTMixtureFit:
    weights, means, covariances = (np.asarray(item, dtype=float).copy() for item in initialization)
    previous = -np.inf
    monotonic = True
    last_relative = np.inf
    converged = False
    iterations = 0
    for iteration in range(1, maximum_iterations + 1):
        log_terms, deltas = mixture_log_terms(
            values, weights, means, covariances, degrees_of_freedom
        )
        normalizer = logsumexp(log_terms, axis=1)
        log_likelihood = float(normalizer.sum())
        responsibilities = np.exp(log_terms - normalizer[:, None])
        if np.isfinite(previous):
            improvement = log_likelihood - previous
            scale = max(abs(previous), 1.0)
            last_relative = abs(improvement) / scale
            if improvement < -1.0e-9 * scale:
                monotonic = False
            if iteration >= minimum_iterations and last_relative <= relative_tolerance:
                converged = True
                iterations = iteration
                break
        previous = log_likelihood
        latent = (degrees_of_freedom + values.shape[1]) / (
            degrees_of_freedom + deltas
        )
        effective = responsibilities * latent
        component_mass = responsibilities.sum(axis=0)
        mean_mass = effective.sum(axis=0)
        weights = component_mass / len(values)
        means = (effective.T @ values) / np.maximum(mean_mass[:, None], 1.0e-300)
        for component in range(components):
            centered = values - means[component]
            weighted = centered * np.sqrt(np.maximum(effective[:, component], 0.0))[:, None]
            covariance = weighted.T @ weighted / max(component_mass[component], 1.0e-300)
            covariances[component] = _regularize_covariance(
                covariance, covariance_regularization
            )
        weights = np.maximum(weights, 1.0e-12)
        weights /= weights.sum()
        iterations = iteration
    else:
        log_terms, _ = mixture_log_terms(
            values, weights, means, covariances, degrees_of_freedom
        )
        log_likelihood = float(logsumexp(log_terms, axis=1).sum())

    eigenvalues = np.asarray(
        [np.linalg.eigvalsh(covariance) for covariance in covariances], dtype=float
    )
    condition_numbers = eigenvalues[:, -1] / np.maximum(eigenvalues[:, 0], 1.0e-300)
    return StudentTMixtureFit(
        weights=weights,
        means=means,
        covariances=covariances,
        log_likelihood=log_likelihood,
        iterations=int(iterations),
        converged=bool(converged),
        monotonic=bool(monotonic),
        last_relative_improvement=float(last_relative),
        minimum_eigenvalue=float(eigenvalues.min()),
        maximum_condition_number=float(condition_numbers.max()),
    )


def fit_with_deterministic_screening(
    values: np.ndarray,
    components: int,
    config: Mapping[str, Any],
    model_id: str,
) -> tuple[StudentTMixtureFit, list[dict[str, Any]], int, bool]:
    policy = config["population_inference"]["mixture"]
    namespace = str(policy["random_seed_namespace"])
    sample_rows = min(int(policy["screen_rows"]), len(values))
    sample_seed = stable_seed(namespace, f"{model_id}|SCREEN_SAMPLE")
    generator = np.random.Generator(np.random.PCG64DXSM(sample_seed))
    indices = (
        np.arange(len(values), dtype=np.int64)
        if sample_rows == len(values)
        else np.sort(generator.choice(len(values), size=sample_rows, replace=False))
    )
    sample = values[indices]
    restarts = int(policy["deterministic_restarts"])
    minimum_fraction = float(policy["minimum_component_fraction"])
    screen_fits: list[StudentTMixtureFit] = []
    audit_rows: list[dict[str, Any]] = []
    for restart in range(restarts):
        seed = stable_seed(namespace, f"{model_id}|RESTART|{restart}")
        initialization = _kmeans_initialization(
            sample,
            components,
            seed,
            float(policy["covariance_regularization"]),
        )
        fit = fit_student_t_mixture(
            sample,
            components,
            float(policy["degrees_of_freedom"]),
            float(policy["covariance_regularization"]),
            int(policy["screen_maximum_iterations"]),
            float(policy["screen_relative_tolerance"]),
            int(policy["minimum_iterations"]),
            initialization,
        )
        screen_fits.append(fit)
        valid = bool(
            np.isfinite(fit.log_likelihood)
            and fit.monotonic
            and float(fit.weights.min()) >= minimum_fraction
        )
        audit_rows.append(
            {
                "model_id": model_id,
                "restart": restart,
                "seed": seed,
                "screen_rows": sample_rows,
                "screen_log_likelihood": fit.log_likelihood,
                "screen_iterations": fit.iterations,
                "screen_converged": fit.converged,
                "screen_monotonic": fit.monotonic,
                "screen_minimum_component_fraction": float(fit.weights.min()),
                "screen_valid": valid,
                "selected_for_full_refinement": False,
                "full_log_likelihood": np.nan,
                "full_iterations": np.nan,
                "full_converged": False,
                "full_monotonic": False,
                "full_minimum_component_fraction": np.nan,
                "validity_rescue_refinement": False,
                "selected_final": False,
            }
        )

    ranking = sorted(
        range(restarts),
        key=lambda index: (
            not bool(audit_rows[index]["screen_valid"]),
            -float(audit_rows[index]["screen_log_likelihood"]),
            index,
        ),
    )
    initial_candidate_count = int(policy["full_refinement_candidates"])
    candidates = ranking[:initial_candidate_count]
    full_fits: list[tuple[int, StudentTMixtureFit]] = []

    def refine(restart: int, rescue: bool) -> None:
        audit_rows[restart]["selected_for_full_refinement"] = True
        audit_rows[restart]["validity_rescue_refinement"] = bool(rescue)
        screen = screen_fits[restart]
        full = fit_student_t_mixture(
            values,
            components,
            float(policy["degrees_of_freedom"]),
            float(policy["covariance_regularization"]),
            int(policy["maximum_iterations"]),
            float(policy["relative_tolerance"]),
            int(policy["minimum_iterations"]),
            (screen.weights, screen.means, screen.covariances),
        )
        audit_rows[restart].update(
            {
                "full_log_likelihood": full.log_likelihood,
                "full_iterations": full.iterations,
                "full_converged": full.converged,
                "full_monotonic": full.monotonic,
                "full_minimum_component_fraction": float(full.weights.min()),
            }
        )
        full_fits.append((restart, full))

    for restart in candidates:
        refine(restart, rescue=False)

    def strictly_valid(pair: tuple[int, StudentTMixtureFit]) -> bool:
        _, fit = pair
        return bool(
            np.isfinite(fit.log_likelihood)
            and fit.monotonic
            and (fit.converged or not bool(policy["selection_requires_convergence"]))
            and float(fit.weights.min()) >= minimum_fraction
        )

    valid_full = [
        (restart, fit)
        for restart, fit in full_fits
        if strictly_valid((restart, fit))
    ]
    if not valid_full:
        optional_stress = components in {
            int(value)
            for value in config["population_inference"]["responsibility_policy"][
                "optional_stress_components"
            ]
        }
        maximum_rescue = int(
            policy[
                "optional_stress_rescue_maximum_additional_refinements"
                if optional_stress
                else "validity_rescue_maximum_additional_refinements"
            ]
        )
        for restart in ranking[initial_candidate_count : initial_candidate_count + maximum_rescue]:
            refine(restart, rescue=True)
            if strictly_valid(full_fits[-1]):
                valid_full.append(full_fits[-1])
                break
    if not valid_full:
        optional_stress = components in {
            int(value)
            for value in config["population_inference"]["responsibility_policy"][
                "optional_stress_components"
            ]
        }
        if not optional_stress:
            raise RuntimeError(
                f"No converged full refinement satisfying the component floor for {model_id}"
            )
        selected_restart, selected = max(
            full_fits, key=lambda pair: (pair[1].log_likelihood, -pair[0])
        )
        audit_rows[selected_restart]["selected_final"] = True
        return selected, audit_rows, sample_rows, False
    selected_restart, selected = max(
        valid_full, key=lambda pair: (pair[1].log_likelihood, -pair[0])
    )
    audit_rows[selected_restart]["selected_final"] = True
    return selected, audit_rows, sample_rows, True


def canonicalize_components(
    fit: StudentTMixtureFit,
    features: Sequence[str],
    center: np.ndarray,
    scale: np.ndarray,
    order_features: Sequence[str],
) -> StudentTMixtureFit:
    original_means = fit.means * scale[None, :] + center[None, :]
    feature_index = {feature: index for index, feature in enumerate(features)}
    available = [feature for feature in order_features if feature in feature_index]
    order = sorted(
        range(len(fit.weights)),
        key=lambda component: tuple(
            float(original_means[component, feature_index[feature]])
            for feature in available
        ),
    )
    order_array = np.asarray(order, dtype=int)
    return StudentTMixtureFit(
        weights=fit.weights[order_array],
        means=fit.means[order_array],
        covariances=fit.covariances[order_array],
        log_likelihood=fit.log_likelihood,
        iterations=fit.iterations,
        converged=fit.converged,
        monotonic=fit.monotonic,
        last_relative_improvement=fit.last_relative_improvement,
        minimum_eigenvalue=fit.minimum_eigenvalue,
        maximum_condition_number=fit.maximum_condition_number,
    )


def normalized_entropy(responsibilities: np.ndarray) -> np.ndarray:
    clipped = np.clip(responsibilities, 1.0e-300, 1.0)
    return -np.sum(clipped * np.log(clipped), axis=1) / np.log(responsibilities.shape[1])


def parameter_records(
    view: str,
    components: int,
    fold: int,
    features: Sequence[str],
    center: np.ndarray,
    scale: np.ndarray,
    fit: StudentTMixtureFit,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, feature in enumerate(features):
        rows.append(
            {
                "view": view,
                "k": components,
                "fold": fold,
                "component": "",
                "parameter_type": "SCALER_CENTER",
                "feature_1": feature,
                "feature_2": "",
                "value": float(center[index]),
            }
        )
        rows.append(
            {
                "view": view,
                "k": components,
                "fold": fold,
                "component": "",
                "parameter_type": "SCALER_SCALE",
                "feature_1": feature,
                "feature_2": "",
                "value": float(scale[index]),
            }
        )
    original_means = fit.means * scale[None, :] + center[None, :]
    scale_outer = np.outer(scale, scale)
    for component in range(components):
        label = f"C{component + 1}"
        rows.append(
            {
                "view": view,
                "k": components,
                "fold": fold,
                "component": label,
                "parameter_type": "WEIGHT",
                "feature_1": "",
                "feature_2": "",
                "value": float(fit.weights[component]),
            }
        )
        for index, feature in enumerate(features):
            for parameter_type, value in (
                ("MEAN_STANDARDIZED", fit.means[component, index]),
                ("MEAN_ORIGINAL", original_means[component, index]),
            ):
                rows.append(
                    {
                        "view": view,
                        "k": components,
                        "fold": fold,
                        "component": label,
                        "parameter_type": parameter_type,
                        "feature_1": feature,
                        "feature_2": "",
                        "value": float(value),
                    }
                )
        original_covariance = fit.covariances[component] * scale_outer
        for left, feature_left in enumerate(features):
            for right in range(left, len(features)):
                feature_right = features[right]
                for parameter_type, value in (
                    ("COVARIANCE_STANDARDIZED", fit.covariances[component, left, right]),
                    ("COVARIANCE_ORIGINAL", original_covariance[left, right]),
                ):
                    rows.append(
                        {
                            "view": view,
                            "k": components,
                            "fold": fold,
                            "component": label,
                            "parameter_type": parameter_type,
                            "feature_1": feature_left,
                            "feature_2": feature_right,
                            "value": float(value),
                        }
                    )
    return rows


def reconstruct_standardized_parameters(
    parameters: pd.DataFrame,
    view: str,
    components: int,
    fold: int,
    features: Sequence[str],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    selected = parameters.loc[
        (parameters["view"] == view)
        & (parameters["k"].astype(int) == int(components))
        & (parameters["fold"].astype(int) == int(fold))
    ].copy()
    center = np.empty(len(features), dtype=float)
    scale = np.empty(len(features), dtype=float)
    weights = np.empty(components, dtype=float)
    means = np.empty((components, len(features)), dtype=float)
    covariances = np.zeros((components, len(features), len(features)), dtype=float)
    for index, feature in enumerate(features):
        center[index] = float(
            selected.loc[
                (selected.parameter_type == "SCALER_CENTER")
                & (selected.feature_1 == feature),
                "value",
            ].iloc[0]
        )
        scale[index] = float(
            selected.loc[
                (selected.parameter_type == "SCALER_SCALE")
                & (selected.feature_1 == feature),
                "value",
            ].iloc[0]
        )
    for component in range(components):
        label = f"C{component + 1}"
        component_rows = selected.loc[selected.component.fillna("") == label]
        weights[component] = float(
            component_rows.loc[component_rows.parameter_type == "WEIGHT", "value"].iloc[0]
        )
        for left, feature_left in enumerate(features):
            means[component, left] = float(
                component_rows.loc[
                    (component_rows.parameter_type == "MEAN_STANDARDIZED")
                    & (component_rows.feature_1 == feature_left),
                    "value",
                ].iloc[0]
            )
            for right in range(left, len(features)):
                feature_right = features[right]
                value = float(
                    component_rows.loc[
                        (component_rows.parameter_type == "COVARIANCE_STANDARDIZED")
                        & (component_rows.feature_1 == feature_left)
                        & (component_rows.feature_2 == feature_right),
                        "value",
                    ].iloc[0]
                )
                covariances[component, left, right] = value
                covariances[component, right, left] = value
    return center, scale, weights, means, covariances


def method_definition(
    config: Mapping[str, Any], input_hashes: Mapping[str, str]
) -> dict[str, Any]:
    return {
        "stage": "5B leakage-safe cross-fitted population inference",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": str(config["project"]["frozen_created_utc"]),
        "population_inference": config["population_inference"],
        "input_sha256": dict(input_hashes),
        "interpretive_boundary": {
            "responsibilities": "empirical held-out-spatial-fold mixture responsibilities",
            "component_names": "anonymous deterministic C1..CK ordering, not semantic Galactic populations",
            "secure_flags": "threshold diagnostics, not hard population labels",
            "target_safe_views": "required downstream view for each fitted abundance target",
            "sensitivity_cohorts": "carried as filters; the mixture is not re-fit as a selection correction",
        },
        "science_boundary": config["science_boundary"],
    }


def claim_ledger(config: Mapping[str, Any]) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "claim": "Empirical multivariate population structure exists in the frozen RGB feature space",
                "status": "ALLOWED_WITH_MODEL_SENSITIVITY",
                "basis": "cross-fitted Student-t responsibilities with K=3/4/5 target-safe views",
            },
            {
                "claim": "K=4 is the unique physical number of Galactic populations",
                "status": "FORBIDDEN",
                "basis": "K=4 is nominal and K=3/5 are prespecified sensitivity models",
            },
            {
                "claim": "Every K=5 target-safe stress model is guaranteed to be downstream-eligible",
                "status": "FORBIDDEN",
                "basis": "K=5 is released only when all five folds pass unchanged strict validity gates",
            },
            {
                "claim": "C1..C5 are named thin-disc, thick-disc, halo, or accreted populations",
                "status": "FORBIDDEN",
                "basis": "component names are anonymous fold-local deterministic orderings",
            },
            {
                "claim": "A responsibility is a calibrated Galactic-membership probability",
                "status": "FORBIDDEN",
                "basis": "responsibilities are empirical mixture weights without external calibration",
            },
            {
                "claim": "secure60/70/80 is a hard population label",
                "status": "FORBIDDEN",
                "basis": "secure flags summarize concentration only; no component label is emitted",
            },
            {
                "claim": "Target-safe responsibilities may be used in a later soft-weighted gradient model",
                "status": "ALLOWED_LATER",
                "basis": "the target abundance and R/abs(Z) are excluded from its classifier view",
            },
            {
                "claim": "Stage 5B measures population-resolved abundance gradients",
                "status": "FORBIDDEN",
                "basis": "no spatial-gradient outcome model is fit in Stage 5B",
            },
            {
                "claim": "Common support corrects the survey selection function",
                "status": "FORBIDDEN",
                "basis": "common support is carried only as a sensitivity filter",
            },
        ]
    )


def validation_report(payload: Mapping[str, Any]) -> str:
    lines = [
        "# Stage 5B validation report",
        "",
        f"Overall passed: **{payload['overall_passed']}**",
        "",
        f"Gates: **{payload['n_passed']}/{payload['n_gates']}**",
        "",
        "| Gate | Result | Detail |",
        "|---|---:|---|",
    ]
    for gate in payload["gates"]:
        lines.append(
            f"| `{gate['name']}` | {'PASS' if gate['passed'] else 'FAIL'} | {gate['detail']} |"
        )
    lines.extend(
        [
            "",
            "Stage 5B creates empirical cross-fitted mixture responsibilities only. ",
            "It does not create semantic or calibrated Galactic memberships, hard component labels, ",
            "selection weights, or population-resolved gradients.",
            "",
        ]
    )
    return "\n".join(lines)
