from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from stage4b_common import (
    COHORTS,
    GLOBAL_PARAMETERS,
    INTERACTION_DERIVED_PARAMETERS,
    LABELS,
    atomic_write_csv,
    atomic_write_json,
    atomic_write_parquet,
    close_logger,
    cluster_inference,
    cohort_mask,
    convergence_record,
    coordinate_features,
    diagnostic_record,
    fit_huber,
    flag,
    ids_sha256,
    influence_records,
    interaction_features,
    interaction_transform,
    label_error_column,
    label_source_column,
    label_value_column,
    load_config,
    method_definition,
    number,
    ordered_frame,
    project_path,
    read_json,
    selected_input_columns,
    setup_logger,
    sha256_file,
    stable_seed,
    summary_fields,
    summarize_draws,
    utc_now,
)


def resolve_paths(config: dict[str, Any], root: Path) -> dict[str, Path]:
    stage4a = project_path(root, config["paths"]["stage4a_output_dir"])
    output = project_path(root, config["paths"]["output_dir"])
    frozen = config["stage4a_frozen"]
    outputs = config["outputs"]
    return {
        "design_layer": stage4a / frozen["design_layer_file"],
        "design_definition": stage4a / frozen["design_definition_file"],
        "cohort_flow": stage4a / frozen["cohort_flow_file"],
        "stage4a_summary": stage4a / frozen["build_summary_file"],
        "stage4a_freeze": stage4a / frozen["freeze_manifest_file"],
        "stage4a_validation": stage4a / frozen["validation_file"],
        "stage4a_report": stage4a / frozen["validation_report_file"],
        "stage4a_package": stage4a / frozen["package_manifest_file"],
        **{
            key.removesuffix("_file"): output / value
            for key, value in outputs.items()
            if key.endswith("_file")
        },
    }


def expected_input_hashes(config: dict[str, Any]) -> dict[str, str]:
    frozen = config["stage4a_frozen"]
    return {
        "design_layer": frozen["design_layer_sha256"],
        "design_definition": frozen["design_definition_sha256"],
        "cohort_flow": frozen["cohort_flow_sha256"],
        "stage4a_summary": frozen["build_summary_sha256"],
        "stage4a_freeze": frozen["freeze_manifest_sha256"],
        "stage4a_validation": frozen["validation_sha256"],
        "stage4a_report": frozen["validation_report_sha256"],
        "stage4a_package": frozen["package_manifest_sha256"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Fit Stage 4B robust global gradients")
    parser.add_argument("--config", default="config/stage4b.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    paths = resolve_paths(config, root)
    output_dir = project_path(root, config["paths"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    logger = setup_logger(
        project_path(root, config["paths"]["log_dir"]) / "28_fit_stage4b.log",
        "stage4b.fit",
    )
    try:
        required = [key for key in expected_input_hashes(config)]
        missing = [str(paths[key]) for key in required if not paths[key].is_file()]
        if missing:
            raise FileNotFoundError("Missing frozen Stage 4A input: " + "; ".join(missing))
        expected_hashes = expected_input_hashes(config)
        observed_hashes = {key: sha256_file(paths[key]) for key in expected_hashes}
        if observed_hashes != expected_hashes:
            mismatches = {
                key: {"expected": expected_hashes[key], "observed": observed_hashes[key]}
                for key in expected_hashes
                if observed_hashes[key] != expected_hashes[key]
            }
            raise RuntimeError(f"Frozen Stage 4A byte identity failed: {mismatches}")
        stage4a_validation = read_json(paths["stage4a_validation"])
        expected_gates = int(config["stage4a_frozen"]["expected_validation_gates"])
        if not bool(stage4a_validation.get("overall_passed", False)) or [
            int(stage4a_validation.get("n_passed", -1)),
            int(stage4a_validation.get("n_gates", -1)),
        ] != [expected_gates, expected_gates]:
            raise RuntimeError("Stage 4A is not frozen 19/19 PASS")

        metadata = pq.ParquetFile(paths["design_layer"]).metadata
        if [metadata.num_rows, metadata.num_columns] != [
            int(config["stage4a_frozen"]["expected_rows"]),
            int(config["stage4a_frozen"]["expected_columns"]),
        ]:
            raise RuntimeError("Stage 4A Parquet metadata differs from the frozen contract")
        logger.info("Reading selected Stage 4A columns for %s rows", metadata.num_rows)
        layer = pq.read_table(
            paths["design_layer"], columns=selected_input_columns(config)
        ).to_pandas()
        ids = pd.to_numeric(layer["gaia_dr3_source_id"], errors="raise").to_numpy(np.int64)
        if (
            ids_sha256(ids)
            != str(config["stage4a_frozen"]["expected_candidate_id_sha256"])
            or len(np.unique(ids)) != len(ids)
            or not np.all(ids[1:] > ids[:-1])
        ):
            raise RuntimeError("Stage 4A candidate identity/order is not frozen")

        labels = tuple(str(value) for value in config["analysis_contract"]["labels"])
        if labels != LABELS:
            raise RuntimeError(f"Unexpected label contract: {labels}")
        model = config["analysis_contract"]["nominal_model"]
        resampling = config["analysis_contract"]["spatial_resampling"]
        interaction_policy = config["analysis_contract"]["survey_interaction"]
        radial_pivot = float(model["radial_pivot_kpc"])
        fit_kwargs = {
            "tuning_constant": float(model["huber_tuning_constant"]),
            "relative_tolerance": float(model["convergence_relative_tolerance"]),
            "maximum_iterations": int(model["maximum_iterations"]),
            "minimum_scale": float(model["minimum_scale"]),
        }
        finite_correction = bool(resampling["finite_cluster_correction"])
        full_draws = int(resampling["full_draws"])
        convergence_draws = int(resampling["convergence_draws"])
        quantiles = tuple(float(value) for value in resampling["confidence_quantiles"])
        namespace = str(resampling["random_seed_namespace"])
        top_blocks = int(config["analysis_contract"]["influence_audit"]["top_blocks_per_parameter"])
        blocks_all = pd.to_numeric(layer["gaia_healpix5"], errors="raise").to_numpy(np.int64)

        global_rows: list[dict[str, Any]] = []
        sensitivity_rows: list[dict[str, Any]] = []
        transport_rows: list[dict[str, Any]] = []
        draw_frames: list[pd.DataFrame] = []
        diagnostic_rows: list[dict[str, Any]] = []
        convergence_rows: list[dict[str, Any]] = []
        influence_rows: list[dict[str, Any]] = []

        coordinate_lookup = {
            str(row["name"]): str(row["coordinate_estimator"])
            for row in config["analysis_contract"]["sensitivity_ladder"]
        }
        for label in LABELS:
            logger.info("Fitting %s sensitivity ladder", label)
            response_all = number(layer, label_value_column(label))
            error_all = number(layer, label_error_column(label))
            nominal_beta: np.ndarray | None = None
            nominal_se: np.ndarray | None = None
            label_sensitivity: list[dict[str, Any]] = []

            for cohort in COHORTS:
                mask = cohort_mask(layer, label, cohort, config)
                if np.any(mask & (~np.isfinite(response_all) | ~np.isfinite(error_all) | (error_all < 0.0))):
                    raise RuntimeError(f"{label}/{cohort} violates the finite-outcome guard")
                features = coordinate_features(layer, mask, cohort, radial_pivot)
                response = response_all[mask]
                blocks = blocks_all[mask]
                if len(response) < int(model["minimum_rows"]):
                    raise RuntimeError(f"{label}/{cohort} has too few rows")
                if len(np.unique(blocks)) < int(model["minimum_spatial_blocks"]):
                    raise RuntimeError(f"{label}/{cohort} has too few spatial blocks")
                fit = fit_huber(features, response, **fit_kwargs)
                model_id = f"GLOBAL_{cohort}"
                n_draws = full_draws if cohort == "PRIMARY" else 0
                inference = cluster_inference(
                    features,
                    response,
                    blocks,
                    fit,
                    n_draws=n_draws,
                    seed=stable_seed(namespace, f"{label}|{model_id}"),
                    finite_cluster_correction=finite_correction,
                )
                diagnostic_rows.append(
                    diagnostic_record(
                        label=label,
                        model_id=model_id,
                        cohort=cohort,
                        coordinate_estimator=coordinate_lookup[cohort],
                        rows=len(response),
                        blocks=len(inference.block_ids),
                        parameters=len(fit.beta),
                        fit=fit,
                        inference=inference,
                    )
                )
                record = {
                    "label": label,
                    "model_id": model_id,
                    "cohort": cohort,
                    "coordinate_estimator": coordinate_lookup[cohort],
                    "rows": int(len(response)),
                    "spatial_blocks": int(len(inference.block_ids)),
                    "beta_intercept": float(fit.beta[0]),
                    "beta_R": float(fit.beta[1]),
                    "beta_Z": float(fit.beta[2]),
                    "beta_intercept_cluster_se": float(inference.standard_errors[0]),
                    "beta_R_cluster_se": float(inference.standard_errors[1]),
                    "beta_Z_cluster_se": float(inference.standard_errors[2]),
                }
                label_sensitivity.append(record)

                if cohort == "PRIMARY":
                    if inference.draws is None:
                        raise RuntimeError("Nominal bootstrap draws were not created")
                    nominal_beta = fit.beta.copy()
                    nominal_se = inference.standard_errors.copy()
                    summaries = [
                        summarize_draws(
                            fit.beta[index],
                            inference.standard_errors[index],
                            inference.draws[:, index],
                            quantiles,
                        )
                        for index in range(3)
                    ]
                    global_row: dict[str, Any] = {
                        "label": label,
                        "model_id": model_id,
                        "rows": int(len(response)),
                        "spatial_blocks": int(len(inference.block_ids)),
                        "radial_pivot_kpc": radial_pivot,
                        "residual_mad": float(fit.residual_mad),
                        "huber_scale": float(fit.scale),
                        "downweight_fraction": float(fit.downweight_fraction),
                        "iterations": int(fit.iterations),
                        "converged": bool(fit.converged),
                    }
                    for prefix, summary in zip(
                        ("beta_intercept", "beta_R", "beta_Z"), summaries, strict=True
                    ):
                        global_row.update(summary_fields(prefix, summary))
                    global_rows.append(global_row)

                    draw_frames.append(
                        pd.DataFrame(
                            {
                                "label": label,
                                "model_id": model_id,
                                "draw_id": np.arange(full_draws, dtype=np.int32),
                                "beta_intercept": inference.draws[:, 0],
                                "beta_R": inference.draws[:, 1],
                                "beta_Z": inference.draws[:, 2],
                                "delta_intercept": np.nan,
                                "delta_beta_R": np.nan,
                                "delta_beta_Z": np.nan,
                                "galah_intercept": np.nan,
                                "galah_beta_R": np.nan,
                                "galah_beta_Z": np.nan,
                            }
                        )
                    )
                    for index, parameter in enumerate(GLOBAL_PARAMETERS):
                        convergence_rows.append(
                            convergence_record(
                                label=label,
                                model_id=model_id,
                                parameter=parameter,
                                draws=inference.draws[:, index],
                                convergence_draws=convergence_draws,
                            )
                        )
                    influence_rows.extend(
                        influence_records(
                            label=label,
                            model_id=model_id,
                            parameter_names=GLOBAL_PARAMETERS,
                            transform=np.eye(3),
                            inference=inference,
                            standard_errors=inference.standard_errors,
                            top_blocks=top_blocks,
                        )
                    )

            if nominal_beta is None or nominal_se is None:
                raise RuntimeError(f"Missing nominal model for {label}")
            for record in label_sensitivity:
                record["delta_beta_R_from_primary"] = float(record["beta_R"] - nominal_beta[1])
                record["delta_beta_Z_from_primary"] = float(record["beta_Z"] - nominal_beta[2])
                record["delta_beta_R_over_primary_cluster_se"] = float(
                    (record["beta_R"] - nominal_beta[1]) / max(nominal_se[1], 1.0e-15)
                )
                record["delta_beta_Z_over_primary_cluster_se"] = float(
                    (record["beta_Z"] - nominal_beta[2]) / max(nominal_se[2], 1.0e-15)
                )
                record["radial_sign_agrees_with_primary"] = bool(
                    np.sign(record["beta_R"]) == np.sign(nominal_beta[1])
                )
                record["vertical_sign_agrees_with_primary"] = bool(
                    np.sign(record["beta_Z"]) == np.sign(nominal_beta[2])
                )
                sensitivity_rows.append(record)

            common_mask = cohort_mask(layer, label, "COMMON_SUPPORT", config)
            source_all = (
                layer[label_source_column(label)]
                .astype("string")
                .fillna("NOT_AVAILABLE")
                .to_numpy(dtype=str)
            )
            reference = str(interaction_policy["reference_group"])
            comparison = str(interaction_policy["comparison_group"])
            accepted = np.isin(source_all, [reference, comparison])
            interaction_mask = common_mask & accepted
            interaction_x, interaction_sources = interaction_features(
                layer,
                interaction_mask,
                label,
                radial_pivot,
                comparison,
            )
            interaction_y = response_all[interaction_mask]
            interaction_blocks = blocks_all[interaction_mask]
            interaction_fit = fit_huber(interaction_x, interaction_y, **fit_kwargs)
            interaction_model_id = "COMMON_SUPPORT_SURVEY_INTERACTION"
            interaction_inference = cluster_inference(
                interaction_x,
                interaction_y,
                interaction_blocks,
                interaction_fit,
                n_draws=full_draws,
                seed=stable_seed(namespace, f"{label}|{interaction_model_id}"),
                finite_cluster_correction=finite_correction,
            )
            if interaction_inference.draws is None:
                raise RuntimeError("Survey-interaction draws were not created")
            transform = interaction_transform()
            derived_point = transform @ interaction_fit.beta
            derived_covariance = transform @ interaction_inference.covariance @ transform.T
            derived_se = np.sqrt(np.maximum(np.diag(derived_covariance), 0.0))
            derived_draws = interaction_inference.draws @ transform.T
            reference_rows = int(np.sum(interaction_sources == reference))
            comparison_rows = int(np.sum(interaction_sources == comparison))
            excluded_rows = int(np.sum(common_mask & ~accepted))
            for index, parameter in enumerate(INTERACTION_DERIVED_PARAMETERS):
                summary = summarize_draws(
                    derived_point[index],
                    derived_se[index],
                    derived_draws[:, index],
                    quantiles,
                )
                transport_rows.append(
                    {
                        "label": label,
                        "model_id": interaction_model_id,
                        "parameter": parameter,
                        "rows": int(len(interaction_y)),
                        "spatial_blocks": int(len(interaction_inference.block_ids)),
                        "reference_group": reference,
                        "reference_rows": reference_rows,
                        "comparison_group": comparison,
                        "comparison_rows": comparison_rows,
                        "excluded_common_support_rows": excluded_rows,
                        **summary,
                    }
                )
                convergence_rows.append(
                    convergence_record(
                        label=label,
                        model_id=interaction_model_id,
                        parameter=parameter,
                        draws=derived_draws[:, index],
                        convergence_draws=convergence_draws,
                    )
                )
            diagnostic_rows.append(
                diagnostic_record(
                    label=label,
                    model_id=interaction_model_id,
                    cohort="COMMON_SUPPORT",
                    coordinate_estimator="PHOTOGEOMETRIC_NOMINAL",
                    rows=len(interaction_y),
                    blocks=len(interaction_inference.block_ids),
                    parameters=len(interaction_fit.beta),
                    fit=interaction_fit,
                    inference=interaction_inference,
                )
            )
            influence_rows.extend(
                influence_records(
                    label=label,
                    model_id=interaction_model_id,
                    parameter_names=INTERACTION_DERIVED_PARAMETERS,
                    transform=transform,
                    inference=interaction_inference,
                    standard_errors=derived_se,
                    top_blocks=top_blocks,
                )
            )
            draw_frames.append(
                pd.DataFrame(
                    {
                        "label": label,
                        "model_id": interaction_model_id,
                        "draw_id": np.arange(full_draws, dtype=np.int32),
                        "beta_intercept": interaction_inference.draws[:, 0],
                        "beta_R": interaction_inference.draws[:, 1],
                        "beta_Z": interaction_inference.draws[:, 2],
                        "delta_intercept": interaction_inference.draws[:, 3],
                        "delta_beta_R": interaction_inference.draws[:, 4],
                        "delta_beta_Z": interaction_inference.draws[:, 5],
                        "galah_intercept": derived_draws[:, 3],
                        "galah_beta_R": derived_draws[:, 4],
                        "galah_beta_Z": derived_draws[:, 5],
                    }
                )
            )

        global_frame = ordered_frame(pd.DataFrame(global_rows), [("label", LABELS)])
        sensitivity_frame = ordered_frame(
            pd.DataFrame(sensitivity_rows), [("label", LABELS), ("cohort", COHORTS)]
        )
        transport_frame = ordered_frame(
            pd.DataFrame(transport_rows),
            [("label", LABELS), ("parameter", INTERACTION_DERIVED_PARAMETERS)],
        )
        draws_frame = ordered_frame(
            pd.concat(draw_frames, ignore_index=True),
            [
                ("label", LABELS),
                (
                    "model_id",
                    ("GLOBAL_PRIMARY", "COMMON_SUPPORT_SURVEY_INTERACTION"),
                ),
            ],
        )
        diagnostics_frame = ordered_frame(
            pd.DataFrame(diagnostic_rows),
            [
                ("label", LABELS),
                (
                    "model_id",
                    tuple([f"GLOBAL_{cohort}" for cohort in COHORTS])
                    + ("COMMON_SUPPORT_SURVEY_INTERACTION",),
                ),
            ],
        )
        convergence_frame = ordered_frame(
            pd.DataFrame(convergence_rows),
            [
                ("label", LABELS),
                (
                    "model_id",
                    ("GLOBAL_PRIMARY", "COMMON_SUPPORT_SURVEY_INTERACTION"),
                ),
            ],
        )
        influence_frame = ordered_frame(
            pd.DataFrame(influence_rows),
            [
                ("label", LABELS),
                (
                    "model_id",
                    ("GLOBAL_PRIMARY", "COMMON_SUPPORT_SURVEY_INTERACTION"),
                ),
            ],
        )

        claim_rows: list[dict[str, Any]] = []
        for label in LABELS:
            global_row = global_frame.loc[global_frame["label"] == label].iloc[0]
            ladder = sensitivity_frame.loc[sensitivity_frame["label"] == label]
            transport = transport_frame.loc[transport_frame["label"] == label].set_index(
                "parameter"
            )
            claim_rows.append(
                {
                    "label": label,
                    "global_radial_point": float(global_row["beta_R"]),
                    "global_radial_q025": float(global_row["beta_R_q025"]),
                    "global_radial_q975": float(global_row["beta_R_q975"]),
                    "global_radial_sign_stability": float(global_row["beta_R_sign_stability"]),
                    "global_radial_interval95_excludes_zero": bool(
                        global_row["beta_R_interval95_excludes_zero"]
                    ),
                    "global_vertical_point": float(global_row["beta_Z"]),
                    "global_vertical_q025": float(global_row["beta_Z_q025"]),
                    "global_vertical_q975": float(global_row["beta_Z_q975"]),
                    "global_vertical_sign_stability": float(global_row["beta_Z_sign_stability"]),
                    "global_vertical_interval95_excludes_zero": bool(
                        global_row["beta_Z_interval95_excludes_zero"]
                    ),
                    "all_predefined_radial_signs_agree": bool(
                        ladder["radial_sign_agrees_with_primary"].all()
                    ),
                    "all_predefined_vertical_signs_agree": bool(
                        ladder["vertical_sign_agrees_with_primary"].all()
                    ),
                    "maximum_abs_radial_sensitivity_shift_over_nominal_se": float(
                        ladder["delta_beta_R_over_primary_cluster_se"].abs().max()
                    ),
                    "maximum_abs_vertical_sensitivity_shift_over_nominal_se": float(
                        ladder["delta_beta_Z_over_primary_cluster_se"].abs().max()
                    ),
                    "common_support_delta_beta_R": float(transport.loc["DELTA_BETA_R", "point"]),
                    "common_support_delta_beta_R_q025": float(
                        transport.loc["DELTA_BETA_R", "q025"]
                    ),
                    "common_support_delta_beta_R_q975": float(
                        transport.loc["DELTA_BETA_R", "q975"]
                    ),
                    "common_support_radial_survey_contrast_detected_95": bool(
                        transport.loc["DELTA_BETA_R", "interval95_excludes_zero"]
                    ),
                    "common_support_delta_beta_Z": float(transport.loc["DELTA_BETA_Z", "point"]),
                    "common_support_delta_beta_Z_q025": float(
                        transport.loc["DELTA_BETA_Z", "q025"]
                    ),
                    "common_support_delta_beta_Z_q975": float(
                        transport.loc["DELTA_BETA_Z", "q975"]
                    ),
                    "common_support_vertical_survey_contrast_detected_95": bool(
                        transport.loc["DELTA_BETA_Z", "interval95_excludes_zero"]
                    ),
                    "selection_corrected": False,
                    "claim_scope": "frozen_cross_survey_RGB_analysis_sample_only",
                }
            )
        claim_frame = ordered_frame(pd.DataFrame(claim_rows), [("label", LABELS)])

        atomic_write_csv(global_frame, paths["global_estimates"])
        atomic_write_csv(sensitivity_frame, paths["sensitivity_ladder"])
        atomic_write_csv(transport_frame, paths["transportability"])
        atomic_write_parquet(draws_frame, paths["bootstrap_draws"])
        atomic_write_csv(diagnostics_frame, paths["model_diagnostics"])
        atomic_write_csv(convergence_frame, paths["bootstrap_convergence"])
        atomic_write_csv(influence_frame, paths["influence_audit"])
        atomic_write_csv(claim_frame, paths["claim_ledger"])
        definition = method_definition(config, observed_hashes)
        atomic_write_json(definition, paths["method_definition"])

        science_keys = (
            "global_estimates",
            "sensitivity_ladder",
            "transportability",
            "bootstrap_draws",
            "model_diagnostics",
            "bootstrap_convergence",
            "influence_audit",
            "claim_ledger",
            "method_definition",
        )
        science_hashes = {paths[key].name: sha256_file(paths[key]) for key in science_keys}
        counts = {
            "labels": int(len(global_frame)),
            "global_rows": int(len(global_frame)),
            "sensitivity_rows": int(len(sensitivity_frame)),
            "transportability_rows": int(len(transport_frame)),
            "bootstrap_draw_rows": int(len(draws_frame)),
            "model_diagnostic_rows": int(len(diagnostics_frame)),
            "bootstrap_convergence_rows": int(len(convergence_frame)),
            "spatial_influence_rows": int(len(influence_frame)),
            "claim_ledger_rows": int(len(claim_frame)),
        }
        build_summary = {
            "stage": "4B robust global gradients and conditional survey transportability",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": utc_now(),
            "candidate_id_sha256": ids_sha256(ids),
            "input_sha256": observed_hashes,
            "output_sha256": science_hashes,
            "counts": counts,
            "nominal_cohort_rows": {
                str(row.label): int(row.rows) for row in global_frame.itertuples(index=False)
            },
            "common_support_interaction_rows": {
                label: int(
                    transport_frame.loc[
                        (transport_frame["label"] == label)
                        & (transport_frame["parameter"] == "DELTA_BETA_R"),
                        "rows",
                    ].iloc[0]
                )
                for label in LABELS
            },
            "science_boundary": config["science_boundary"],
        }
        atomic_write_json(build_summary, paths["build_summary"])
        freeze_hashes = dict(science_hashes)
        freeze_hashes[paths["build_summary"].name] = sha256_file(paths["build_summary"])
        freeze_manifest = {
            "stage": "4B inference freeze",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": utc_now(),
            "candidate_id_sha256": ids_sha256(ids),
            "input_sha256": observed_hashes,
            "output_sha256": freeze_hashes,
            "counts": counts,
            "science_boundary": config["science_boundary"],
        }
        atomic_write_json(freeze_manifest, paths["freeze_manifest"])
        logger.info(
            "Stage 4B fit complete: labels=%s sensitivity_models=%s draws=%s",
            len(global_frame),
            len(sensitivity_frame),
            len(draws_frame),
        )
        print(
            "Stage 4B fit complete: "
            f"labels={len(global_frame)} sensitivity_models={len(sensitivity_frame)} "
            f"bootstrap_draw_rows={len(draws_frame)}"
        )
        return 0
    finally:
        close_logger(logger)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
