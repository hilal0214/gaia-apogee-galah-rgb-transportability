from __future__ import annotations

import argparse
import math
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from stage1_common import (
    atomic_write_json,
    chunked,
    configured_paths,
    ensure_columns,
    gaia_upload_query,
    load_config,
    lower_columns,
    normalise_id_series,
    read_frame,
    read_json,
    setup_logger,
    table_suffix,
    utc_now,
    write_frame,
)


OUTPUT_COLUMNS = (
    "input_order",
    "requested_dr2_source_id",
    "dr2_source_id",
    "dr3_source_id",
    "angular_distance",
    "magnitude_difference",
)


def mapping_query(table_name: str) -> str:
    return f"""
SELECT
    u.input_order AS input_order,
    u.source_id AS requested_dr2_source_id,
    x.dr2_source_id AS dr2_source_id,
    x.dr3_source_id AS dr3_source_id,
    x.angular_distance AS angular_distance,
    x.magnitude_difference AS magnitude_difference
FROM tap_upload.ids AS u
JOIN {table_name} AS x
  ON u.source_id = x.dr2_source_id
"""


def query_with_retries(
    ids: np.ndarray,
    upload_path: Path,
    table_candidates: list[str],
    max_retries: int,
    retry_base_seconds: int,
    logger,
) -> tuple[pd.DataFrame, str]:
    errors: list[str] = []
    for table_name in table_candidates:
        query = mapping_query(table_name)
        for attempt in range(1, max_retries + 1):
            try:
                frame = gaia_upload_query(ids, query, upload_path)
                for column in OUTPUT_COLUMNS:
                    if column not in frame:
                        frame[column] = pd.Series(dtype="float64")
                frame = frame.loc[:, list(OUTPUT_COLUMNS)]
                for column in (
                    "input_order",
                    "requested_dr2_source_id",
                    "dr2_source_id",
                    "dr3_source_id",
                ):
                    frame[column] = normalise_id_series(frame[column])
                return frame, table_name
            except Exception as exc:
                message = (
                    f"{table_name} attempt {attempt}/{max_retries}: "
                    f"{type(exc).__name__}: {exc}"
                )
                errors.append(message)
                logger.warning(message)
                if attempt < max_retries:
                    time.sleep(min(60, retry_base_seconds * 2 ** (attempt - 1)))
    raise RuntimeError("All Gaia mapping attempts failed:\n" + "\n".join(errors[-10:]))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/stage1.yml")
    parser.add_argument("--chunk-size", type=int)
    parser.add_argument("--max-chunks", type=int)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    config, root = load_config(args.config)
    paths = configured_paths(config, root)
    logger = setup_logger(
        paths["log_dir"] / "02_map_apogee_dr2_to_dr3.log", "stage1.dr2map"
    )
    suffix = table_suffix(config)
    apogee_path = paths["interim_dir"] / "ingest" / f"apogee_rows{suffix}"
    if not apogee_path.exists():
        raise FileNotFoundError(f"Missing {apogee_path}; run ingestion first.")
    apogee = read_frame(apogee_path, columns=["gaia_dr2_source_id"])
    ensure_columns(apogee, ["gaia_dr2_source_id"], "APOGEE ingest")
    ids = np.sort(
        apogee.loc[apogee["gaia_dr2_source_id"].gt(0), "gaia_dr2_source_id"]
        .drop_duplicates()
        .astype("int64")
        .to_numpy()
    )
    chunk_size = int(args.chunk_size or config["gaia"]["dr2_mapping_chunk_size"])
    total_chunks = int(math.ceil(len(ids) / chunk_size))
    logger.info(
        "Mapping %,d unique APOGEE Gaia DR2 IDs in %d chunks of up to %,d",
        len(ids),
        total_chunks,
        chunk_size,
    )

    mapping_root = paths["interim_dir"] / "dr2_to_dr3"
    candidates_dir = mapping_root / "candidates"
    uploads_dir = mapping_root / "uploads"
    candidates_dir.mkdir(parents=True, exist_ok=True)
    uploads_dir.mkdir(parents=True, exist_ok=True)
    tables = list(config["gaia"]["dr2_neighbourhood_tables"])
    preferred_table: str | None = None
    completed = 0
    candidate_rows = 0

    for chunk_index, chunk_ids in chunked(ids, chunk_size):
        if args.max_chunks is not None and completed >= args.max_chunks:
            logger.info("Stopped at --max-chunks=%d", args.max_chunks)
            break
        stem = f"chunk_{chunk_index:05d}"
        output_path = candidates_dir / f"{stem}{suffix}"
        meta_path = candidates_dir / f"{stem}.json"
        if args.force:
            output_path.unlink(missing_ok=True)
            meta_path.unlink(missing_ok=True)
        if output_path.exists() and meta_path.exists():
            metadata = read_json(meta_path)
            if int(metadata.get("requested_ids", -1)) == len(chunk_ids):
                completed += 1
                candidate_rows += int(metadata.get("candidate_rows", 0))
                preferred_table = metadata.get("table_name") or preferred_table
                logger.info("Skipping cached %s", stem)
                continue
        table_order = (
            [preferred_table] + [name for name in tables if name != preferred_table]
            if preferred_table
            else tables
        )
        upload_path = uploads_dir / f"{stem}.xml"
        frame, used_table = query_with_retries(
            chunk_ids,
            upload_path,
            table_order,
            int(config["gaia"]["max_retries"]),
            int(config["gaia"]["retry_base_seconds"]),
            logger,
        )
        preferred_table = used_table
        write_frame(frame, output_path)
        upload_path.unlink(missing_ok=True)
        metadata = {
            "chunk_index": chunk_index,
            "requested_ids": int(len(chunk_ids)),
            "first_requested_id": int(chunk_ids[0]),
            "last_requested_id": int(chunk_ids[-1]),
            "candidate_rows": int(len(frame)),
            "matched_requested_ids": int(frame["dr2_source_id"].nunique()),
            "table_name": used_table,
            "created_utc": utc_now(),
        }
        atomic_write_json(metadata, meta_path)
        completed += 1
        candidate_rows += len(frame)
        logger.info(
            "%s complete: %,d requested, %,d candidates",
            stem,
            len(chunk_ids),
            len(frame),
        )

    state = {
        "stage": "1B APOGEE Gaia DR2-to-DR3 candidate mapping",
        "protocol_version": config["project"]["version"],
        "updated_utc": utc_now(),
        "unique_dr2_ids": int(len(ids)),
        "chunk_size": chunk_size,
        "planned_chunks": total_chunks,
        "completed_chunks": completed,
        "candidate_rows_in_completed_chunks": int(candidate_rows),
        "complete": completed == total_chunks,
        "table_name": preferred_table,
    }
    atomic_write_json(state, paths["output_dir"] / "dr2_to_dr3_mapping_state.json")
    if completed != total_chunks:
        logger.warning("Mapping is partial: %d/%d chunks", completed, total_chunks)
        return 2
    logger.info("All mapping chunks complete.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted; completed chunks were retained.", file=sys.stderr)
        raise SystemExit(130)
