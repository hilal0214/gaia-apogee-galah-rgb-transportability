from __future__ import annotations

import argparse
import gc
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from stage4a_common import (
    LABELS,
    SOURCE_GROUPS,
    atomic_write_json,
    close_logger,
    common_support,
    covariate_balance,
    design_definition,
    flag,
    healpix_from_source_id,
    ids_sha256,
    label_outcome_available,
    load_config,
    number,
    project_path,
    radial_domain,
    read_json,
    setup_logger,
    sha256_file,
    source_column,
    spatial_block_summary,
    stage2c_columns,
    stage3b_columns,
    stage3c_columns,
    utc_now,
    write_frame,
)


def resolve_paths(config: dict[str, Any], root: Path) -> dict[str, Path]:
    stage2c_dir = project_path(root, config["paths"]["stage2c_output_dir"])
    stage3b_dir = project_path(root, config["paths"]["stage3b_output_dir"])
    stage3c_dir = project_path(root, config["paths"]["stage3c_output_dir"])
    output_dir = project_path(root, config["paths"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    a = config["stage2c_frozen"]
    b = config["stage3b_frozen"]
    c = config["stage3c_frozen"]
    o = config["outputs"]
    return {
        "stage2c_atlas": stage2c_dir / a["atlas_file"],
        "stage2c_summary": stage2c_dir / a["build_summary_file"],
        "stage2c_freeze": stage2c_dir / a["freeze_manifest_file"],
        "stage2c_validation": stage2c_dir / a["validation_file"],
        "stage2c_report": stage2c_dir / a["validation_report_file"],
        "stage2c_package": stage2c_dir / a["package_manifest_file"],
        "stage3b_phase": stage3b_dir / b["phase_space_layer_file"],
        "stage3b_summary": stage3b_dir / b["build_summary_file"],
        "stage3b_freeze": stage3b_dir / b["freeze_manifest_file"],
        "stage3b_validation": stage3b_dir / b["validation_file"],
        "stage3c_layer": stage3c_dir / c["uncertainty_layer_file"],
        "stage3c_summary": stage3c_dir / c["build_summary_file"],
        "stage3c_freeze": stage3c_dir / c["freeze_manifest_file"],
        "stage3c_validation": stage3c_dir / c["validation_file"],
        "stage3c_method": stage3c_dir / c["method_definition_file"],
        "stage3c_package": stage3c_dir / c["package_manifest_file"],
        "design_layer": output_dir / o["design_layer_file"],
        "cohort_flow": output_dir / o["cohort_flow_file"],
        "support_bounds": output_dir / o["common_support_bounds_file"],
        "balance": output_dir / o["covariate_balance_file"],
        "block_summary": output_dir / o["spatial_block_summary_file"],
        "population_flow": output_dir / o["population_feature_flow_file"],
        "definition": output_dir / o["design_definition_file"],
        "build_summary": output_dir / o["build_summary_file"],
        "freeze": output_dir / o["freeze_manifest_file"],
    }


def expected_input_hashes(config: dict[str, Any]) -> dict[str, str]:
    a = config["stage2c_frozen"]
    b = config["stage3b_frozen"]
    c = config["stage3c_frozen"]
    return {
        "stage2c_atlas": a["atlas_sha256"],
        "stage2c_summary": a["build_summary_sha256"],
        "stage2c_freeze": a["freeze_manifest_sha256"],
        "stage2c_validation": a["validation_sha256"],
        "stage2c_report": a["validation_report_sha256"],
        "stage2c_package": a["package_manifest_sha256"],
        "stage3b_phase": b["phase_space_layer_sha256"],
        "stage3b_summary": b["build_summary_sha256"],
        "stage3b_freeze": b["freeze_manifest_sha256"],
        "stage3b_validation": b["validation_sha256"],
        "stage3c_layer": c["uncertainty_layer_sha256"],
        "stage3c_summary": c["build_summary_sha256"],
        "stage3c_freeze": c["freeze_manifest_sha256"],
        "stage3c_validation": c["validation_sha256"],
        "stage3c_method": c["method_definition_sha256"],
        "stage3c_package": c["package_manifest_sha256"],
    }


def source_counts(frame: pd.DataFrame, selected: np.ndarray, column: str) -> dict[str, int]:
    values = frame[column].astype("string").fillna("NOT_AVAILABLE").to_numpy(str)
    return {
        "APOGEE_NATIVE": int((selected & (values == "APOGEE_NATIVE")).sum()),
        "GALAH_CORRECTED": int((selected & (values == "GALAH_CORRECTED")).sum()),
        "MIXED_OR_OTHER": int(
            (selected & ~np.isin(values, np.asarray(SOURCE_GROUPS, dtype=str))).sum()
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Build Stage 4A analysis-design layer")
    parser.add_argument("--config", default="config/stage4a.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    paths = resolve_paths(config, root)
    log_path = project_path(root, config["paths"]["log_dir"]) / "25_build_stage4a.log"
    logger = setup_logger(log_path, "stage4a.build")
    try:
        required = [path for key, path in paths.items() if key.startswith("stage")]
        missing = [str(path) for path in required if not path.exists()]
        if missing:
            raise FileNotFoundError("Missing Stage 4A inputs: " + "; ".join(missing))

        expected_hashes = expected_input_hashes(config)
        observed_hashes = {key: sha256_file(paths[key]) for key in expected_hashes}
        if observed_hashes != expected_hashes:
            differences = {
                key: {"expected": expected_hashes[key], "observed": observed_hashes[key]}
                for key in expected_hashes
                if observed_hashes[key] != expected_hashes[key]
            }
            raise ValueError(f"Frozen upstream hash mismatch: {differences}")

        validations = {
            "stage2c": read_json(paths["stage2c_validation"]),
            "stage3b": read_json(paths["stage3b_validation"]),
            "stage3c": read_json(paths["stage3c_validation"]),
        }
        for key, frozen_key in (
            ("stage2c", "stage2c_frozen"),
            ("stage3b", "stage3b_frozen"),
            ("stage3c", "stage3c_frozen"),
        ):
            payload = validations[key]
            expected_gates = int(config[frozen_key]["expected_validation_gates"])
            if not (
                bool(payload.get("overall_passed"))
                and int(payload.get("n_passed", -1)) == expected_gates
                and int(payload.get("n_gates", -1)) == expected_gates
            ):
                raise ValueError(f"{key} is not frozen PASS")

        meta2c = pq.ParquetFile(paths["stage2c_atlas"]).metadata
        meta3b = pq.ParquetFile(paths["stage3b_phase"]).metadata
        meta3c = pq.ParquetFile(paths["stage3c_layer"]).metadata
        metadata_observed = {
            "stage2c_rows": int(meta2c.num_rows),
            "stage2c_columns": int(meta2c.num_columns),
            "stage3b_rows": int(meta3b.num_rows),
            "stage3b_columns": int(meta3b.num_columns),
            "stage3c_rows": int(meta3c.num_rows),
            "stage3c_columns": int(meta3c.num_columns),
        }
        metadata_expected = {
            "stage2c_rows": int(config["stage2c_frozen"]["expected_rows"]),
            "stage2c_columns": int(config["stage2c_frozen"]["expected_columns"]),
            "stage3b_rows": int(config["stage3b_frozen"]["expected_rows"]),
            "stage3b_columns": int(config["stage3b_frozen"]["expected_columns"]),
            "stage3c_rows": int(config["stage3c_frozen"]["expected_rows"]),
            "stage3c_columns": int(config["stage3c_frozen"]["expected_columns"]),
        }
        if metadata_observed != metadata_expected:
            raise ValueError(
                f"Frozen upstream Parquet metadata mismatch: {metadata_observed} != {metadata_expected}"
            )

        logger.info("Reading Stage 3B and Stage 3C candidate vectors")
        stage3b = pd.read_parquet(paths["stage3b_phase"], columns=stage3b_columns())
        stage3c = pd.read_parquet(paths["stage3c_layer"], columns=stage3c_columns())
        ids3b = pd.to_numeric(stage3b["gaia_dr3_source_id"], errors="raise").to_numpy(np.int64)
        ids3c = pd.to_numeric(stage3c["gaia_dr3_source_id"], errors="raise").to_numpy(np.int64)
        expected_candidate_hash = str(config["analysis_contract"]["candidate_id_sha256"])
        if not (
            np.array_equal(ids3b, ids3c)
            and len(np.unique(ids3b)) == len(ids3b)
            and np.all(np.diff(ids3b) > 0)
            and ids_sha256(ids3b) == expected_candidate_hash
        ):
            raise ValueError("Stage 3B/3C candidate identity is not exact")
        if not np.array_equal(
            flag(stage3b, "phase_space_6d_primary_ok"),
            flag(stage3c, "phase_space_6d_primary_ok"),
        ):
            raise ValueError("Stage 3B/3C primary 6D flags differ")

        logger.info("Reading selected Stage 2C columns for 1,509,277 sources")
        stage2c_full = pd.read_parquet(paths["stage2c_atlas"], columns=stage2c_columns())
        ids2c = pd.to_numeric(stage2c_full["gaia_dr3_source_id"], errors="raise").to_numpy(
            np.int64
        )
        if not (
            len(np.unique(ids2c)) == len(ids2c)
            and np.all(np.diff(ids2c) > 0)
            and ids_sha256(ids2c)
            == str(config["stage2c_frozen"]["expected_source_id_sha256"])
        ):
            raise ValueError("Stage 2C full source-ID vector is not exact")
        stage2c = stage2c_full.set_index("gaia_dr3_source_id").loc[ids3b].reset_index()
        del stage2c_full, ids2c
        gc.collect()
        ids2c_candidate = pd.to_numeric(
            stage2c["gaia_dr3_source_id"], errors="raise"
        ).to_numpy(np.int64)
        if not np.array_equal(ids2c_candidate, ids3b):
            raise ValueError("Stage 2C does not cover the candidate vector one to one")
        if not stage2c["survey_origin"].astype("string").equals(
            stage3b["survey_origin"].astype("string")
        ):
            raise ValueError("Stage 2C and Stage 3B survey origins differ")

        stage3b_payload = stage3b.drop(columns=["gaia_dr3_source_id", "survey_origin"])
        stage3c_payload = stage3c.drop(
            columns=["gaia_dr3_source_id", "phase_space_6d_primary_ok"]
        )
        layer = pd.concat(
            [
                stage2c.reset_index(drop=True),
                stage3b_payload.reset_index(drop=True),
                stage3c_payload.reset_index(drop=True),
            ],
            axis=1,
        )
        if layer.columns.duplicated().any():
            duplicates = layer.columns[layer.columns.duplicated()].tolist()
            raise ValueError(f"Duplicate Stage 4A columns: {duplicates}")

        layer["abs_z_gc_kpc"] = np.abs(number(layer, "z_gc_kpc"))
        block_policy = config["analysis_contract"]["spatial_block"]
        layer["gaia_healpix5"] = healpix_from_source_id(
            ids3b,
            level=int(block_policy["healpix_level"]),
            source_level=int(block_policy["source_id_level"]),
            low_bits=int(block_policy["source_id_low_bits"]),
        )
        radial = radial_domain(
            number(layer, "r_cyl_gc_kpc"),
            config["analysis_contract"]["radial_domain"],
        )
        layer["radial_domain_primary"] = radial
        max_abs_z = float(
            config["analysis_contract"]["disc_height_sensitivity"]["maximum_abs_z_kpc"]
        )
        disc5 = radial & np.isfinite(number(layer, "abs_z_gc_kpc")) & (
            number(layer, "abs_z_gc_kpc") <= max_abs_z
        )
        layer["disc5_domain_sensitivity"] = disc5
        geo_radial = radial_domain(
            number(layer, "r_cyl_gc_kpc_geo_alt"),
            config["analysis_contract"]["radial_domain"],
        )
        paired_geo = flag(layer, "geo_estimator_paired")

        for label in LABELS:
            available = label_outcome_available(layer, label)
            primary = flag(layer, f"{label}_phase_space_primary_ok") & radial & available
            core = flag(layer, f"{label}_phase_space_core_ok") & radial & available
            sensitivity = (
                flag(layer, f"{label}_phase_space_sensitivity_ok") & radial & available
            )
            layer[f"{label}_gradient_primary_ok"] = primary
            layer[f"{label}_gradient_core_ok"] = core
            layer[f"{label}_gradient_disc5_ok"] = primary & disc5
            layer[f"{label}_gradient_geo_paired_ok"] = primary & paired_geo & geo_radial
            layer[f"{label}_gradient_sensitivity_ok"] = sensitivity

        support_rows: list[dict[str, Any]] = []
        balance_rows: list[dict[str, Any]] = []
        support_policy = config["analysis_contract"]["common_support"]
        for label in LABELS:
            selected, rows = common_support(layer, label, support_policy)
            layer[f"{label}_gradient_common_support_ok"] = selected
            support_rows.extend(rows)
            balance_rows.extend(covariate_balance(layer, label, support_policy))

        population_primary = (
            flag(layer, "phase_space_6d_primary_ok")
            & flag(layer, "fe_h_phase_space_primary_ok")
            & flag(layer, "alpha3_phase_space_primary_ok")
        )
        population_frame = population_primary & flag(layer, "frame_vrot_sign_stable")
        population_gradient_common = (
            population_primary
            & flag(layer, "fe_h_gradient_common_support_ok")
            & flag(layer, "alpha3_gradient_common_support_ok")
        )
        layer["population_feature_primary_ok"] = population_primary
        layer["population_feature_frame_stable_ok"] = population_frame
        layer["population_feature_gradient_common_support_sensitivity_ok"] = (
            population_gradient_common
        )

        flow_rows: list[dict[str, Any]] = []
        for label in LABELS:
            primary = flag(layer, f"{label}_gradient_primary_ok")
            common = flag(layer, f"{label}_gradient_common_support_ok")
            primary_sources = source_counts(layer, primary, source_column(label))
            common_sources = source_counts(layer, common, source_column(label))
            flow_rows.append(
                {
                    "label": label,
                    "phase_space_primary_rows": int(
                        flag(layer, f"{label}_phase_space_primary_ok").sum()
                    ),
                    "gradient_primary_rows": int(primary.sum()),
                    "gradient_core_rows": int(
                        flag(layer, f"{label}_gradient_core_ok").sum()
                    ),
                    "gradient_common_support_rows": int(common.sum()),
                    "gradient_disc5_rows": int(
                        flag(layer, f"{label}_gradient_disc5_ok").sum()
                    ),
                    "gradient_geo_paired_rows": int(
                        flag(layer, f"{label}_gradient_geo_paired_ok").sum()
                    ),
                    "gradient_sensitivity_rows": int(
                        flag(layer, f"{label}_gradient_sensitivity_ok").sum()
                    ),
                    "primary_apogee_native_rows": primary_sources["APOGEE_NATIVE"],
                    "primary_galah_corrected_rows": primary_sources["GALAH_CORRECTED"],
                    "primary_mixed_or_other_rows": primary_sources["MIXED_OR_OTHER"],
                    "common_apogee_native_rows": common_sources["APOGEE_NATIVE"],
                    "common_galah_corrected_rows": common_sources["GALAH_CORRECTED"],
                    "common_mixed_or_other_rows": common_sources["MIXED_OR_OTHER"],
                }
            )

        population_flow = pd.DataFrame(
            [
                {"stage": "candidate_vector", "rows": int(len(layer))},
                {
                    "stage": "primary_6d",
                    "rows": int(flag(layer, "phase_space_6d_primary_ok").sum()),
                },
                {
                    "stage": "fe_h_primary_6d",
                    "rows": int(flag(layer, "fe_h_phase_space_primary_ok").sum()),
                },
                {
                    "stage": "alpha3_primary_6d",
                    "rows": int(flag(layer, "alpha3_phase_space_primary_ok").sum()),
                },
                {"stage": "population_feature_primary", "rows": int(population_primary.sum())},
                {
                    "stage": "population_feature_frame_stable_sensitivity",
                    "rows": int(population_frame.sum()),
                },
                {
                    "stage": "population_feature_gradient_common_support_sensitivity",
                    "rows": int(population_gradient_common.sum()),
                },
            ]
        )

        support_frame = pd.DataFrame(support_rows).sort_values(
            ["label", "covariate"], kind="mergesort"
        )
        balance_frame = pd.DataFrame(balance_rows).sort_values(
            ["label", "scope", "covariate"], kind="mergesort"
        )
        flow_frame = pd.DataFrame(flow_rows).sort_values("label", kind="mergesort")
        block_frame = spatial_block_summary(layer)

        output_columns = list(layer.columns)
        definition = design_definition(config, output_columns)
        write_frame(layer, paths["design_layer"])
        write_frame(flow_frame, paths["cohort_flow"])
        write_frame(support_frame, paths["support_bounds"])
        write_frame(balance_frame, paths["balance"])
        write_frame(block_frame, paths["block_summary"])
        write_frame(population_flow, paths["population_flow"])
        atomic_write_json(definition, paths["definition"])

        science_paths = [
            paths["design_layer"],
            paths["cohort_flow"],
            paths["support_bounds"],
            paths["balance"],
            paths["block_summary"],
            paths["population_flow"],
            paths["definition"],
        ]
        science_hashes = {path.name: sha256_file(path) for path in science_paths}
        counts = {
            "rows": int(len(layer)),
            "columns": int(len(layer.columns)),
            "candidate_ids": int(len(np.unique(ids3b))),
            "primary_6d": int(flag(layer, "phase_space_6d_primary_ok").sum()),
            "uncertainty_propagated": int(flag(layer, "uncertainty_propagation_ok").sum()),
            "population_feature_primary": int(population_primary.sum()),
            "population_feature_frame_stable": int(population_frame.sum()),
            "population_feature_gradient_common_support_sensitivity": int(
                population_gradient_common.sum()
            ),
        }
        build_summary = {
            "stage": "4A outcome-free analysis fusion and transportability contract",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": utc_now(),
            "candidate_id_sha256": ids_sha256(ids3b),
            "counts": counts,
            "label_cohort_flow": flow_frame.to_dict(orient="records"),
            "upstream_metadata": metadata_observed,
            "input_sha256": observed_hashes,
            "output_sha256": science_hashes,
            "design_definition_sha256": science_hashes[paths["definition"].name],
            "science_boundary": dict(config["science_boundary"]),
        }
        atomic_write_json(build_summary, paths["build_summary"])
        freeze_hashes = dict(science_hashes)
        freeze_hashes[paths["build_summary"].name] = sha256_file(paths["build_summary"])
        freeze = {
            "stage": "4A analysis-design freeze",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": utc_now(),
            "candidate_id_sha256": ids_sha256(ids3b),
            "input_sha256": observed_hashes,
            "output_sha256": freeze_hashes,
            "counts": counts,
            "science_boundary": dict(config["science_boundary"]),
        }
        atomic_write_json(freeze, paths["freeze"])
        logger.info(
            "Stage 4A build complete: rows=%s columns=%s primary_6d=%s population_features=%s",
            counts["rows"],
            counts["columns"],
            counts["primary_6d"],
            counts["population_feature_primary"],
        )
        print(
            "Stage 4A build complete: "
            f"rows={counts['rows']}; columns={counts['columns']}; "
            f"population_feature_primary={counts['population_feature_primary']}"
        )
        return 0
    finally:
        close_logger(logger)


if __name__ == "__main__":
    raise SystemExit(main())
