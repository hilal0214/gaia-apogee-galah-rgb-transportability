from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from stage2a_common import (
    assignment_sha256,
    atomic_write_json,
    close_logger,
    coordinate_decision_sha256,
    frozen_folds,
    ids_sha256,
    load_config,
    membership_sha256,
    project_path,
    read_json,
    setup_logger,
    sha256_file,
    utc_now,
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate the frozen Stage 2A products")
    parser.add_argument("--config", default="config/stage2a.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    output_dir = project_path(root, config["paths"]["output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "08_validate_stage2a.log", "stage2a.validate")

    table_path = output_dir / "overlap_stage2a_frozen.parquet"
    summary_path = output_dir / "stage2a_build_summary.json"
    freeze_path = output_dir / "stage2a_freeze_manifest.json"
    support_path = output_dir / "element_support_counts.csv"
    fold_balance_path = output_dir / "fold_balance_by_element.csv"
    anomaly_path = output_dir / "coordinate_hard_mismatches.csv"
    assignment_path = output_dir / "heldout_fold_assignments.parquet"
    required_paths = (
        table_path,
        summary_path,
        freeze_path,
        support_path,
        fold_balance_path,
        anomaly_path,
        assignment_path,
    )
    missing = [str(path) for path in required_paths if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Stage 2A outputs are missing: {missing}")

    frame = pd.read_parquet(table_path)
    summary = read_json(summary_path)
    freeze = read_json(freeze_path)
    support = pd.read_csv(support_path)
    fold_balance = pd.read_csv(fold_balance_path)
    anomalies = pd.read_csv(anomaly_path, dtype={"galah_field": "string", "galah_observing_date": "string"})
    assignments = pd.read_parquet(assignment_path)

    gates: list[dict[str, Any]] = []

    def gate(name: str, observed: Any, expected: Any, passed: bool, detail: str) -> None:
        gates.append(
            {
                "name": name,
                "observed": observed,
                "expected": expected,
                "passed": bool(passed),
                "detail": detail,
            }
        )

    frozen = config["stage1_frozen"]
    expected_counts = frozen["expected_counts"]
    gate(
        "overlap_rows",
        int(len(frame)),
        int(expected_counts["overlap"]),
        len(frame) == int(expected_counts["overlap"]),
        "frozen same-ID overlap denominator",
    )
    ids = pd.to_numeric(frame["gaia_dr3_source_id"], errors="coerce").fillna(0).astype(
        "int64"
    )
    identity_observed = {
        "positive": int(ids.gt(0).sum()),
        "duplicates": int(ids.duplicated().sum()),
        "monotonic": bool(ids.is_monotonic_increasing),
    }
    identity_expected = {
        "positive": int(expected_counts["overlap"]),
        "duplicates": 0,
        "monotonic": True,
    }
    gate(
        "overlap_identity",
        identity_observed,
        identity_expected,
        identity_observed == identity_expected,
        "positive unique Gaia DR3 IDs in frozen order",
    )
    observed_id_hash = ids_sha256(ids)
    expected_id_hash = str(config["fold_freeze"]["id_vector_sha256"])
    gate(
        "overlap_id_vector_sha256",
        observed_id_hash,
        expected_id_hash,
        observed_id_hash == expected_id_hash,
        "platform-independent ordered source-ID identity",
    )

    source_kind = summary.get("gaia_coordinate_source", {}).get("kind")
    require_cache = bool(config["validation"]["require_stage1_joined_cache"])
    gate(
        "gaia_coordinate_source",
        source_kind,
        "stage1_joined_cache" if require_cache else "stage1_joined_cache or override_table",
        source_kind == "stage1_joined_cache"
        if require_cache
        else source_kind in {"stage1_joined_cache", "override_table"},
        "actual Gaia DR3 RA/Dec provenance",
    )

    coord_expected = config["coordinate_adjudication"]["expected"]
    coordinate_complete = int(frame["coordinate_complete"].astype(bool).sum())
    gate(
        "coordinate_complete",
        coordinate_complete,
        int(coord_expected["coordinate_complete"]),
        coordinate_complete == int(coord_expected["coordinate_complete"]),
        "finite APOGEE, GALAH, and Gaia coordinate comparisons",
    )
    hard = frame["coordinate_hard_mismatch"].astype(bool)
    hard_count = int(hard.sum())
    gate(
        "hard_coordinate_mismatch",
        hard_count,
        int(coord_expected["hard_mismatch"]),
        hard_count == int(coord_expected["hard_mismatch"]),
        "APOGEE-GALAH separation above frozen 300-arcsec threshold",
    )
    status_counts = frame["coordinate_status"].astype("string").value_counts().to_dict()
    status_observed = {
        "APOGEE_COORDINATE_CONFIRMED": int(
            status_counts.get("APOGEE_COORDINATE_CONFIRMED", 0)
        ),
        "GALAH_COORDINATE_CONFIRMED": int(
            status_counts.get("GALAH_COORDINATE_CONFIRMED", 0)
        ),
        "HARD_MISMATCH_UNRESOLVED": int(
            status_counts.get("HARD_MISMATCH_UNRESOLVED", 0)
        ),
    }
    status_expected = {
        "APOGEE_COORDINATE_CONFIRMED": int(
            coord_expected["apogee_coordinate_confirmed"]
        ),
        "GALAH_COORDINATE_CONFIRMED": int(
            coord_expected["galah_coordinate_confirmed"]
        ),
        "HARD_MISMATCH_UNRESOLVED": int(
            coord_expected["unresolved_hard_mismatch"]
        ),
    }
    gate(
        "gaia_coordinate_adjudication",
        status_observed,
        status_expected,
        status_observed == status_expected,
        "hard mismatches resolved against actual Gaia DR3 coordinates",
    )
    joint = frame["joint_broad_rg_and_quality"].astype(bool)
    affected_joint = int((hard & joint).sum())
    gate(
        "hard_mismatch_joint_rgb_quality",
        affected_joint,
        int(coord_expected["hard_mismatch_joint_rgb_quality"]),
        affected_joint == int(coord_expected["hard_mismatch_joint_rgb_quality"]),
        "primary-support coordinate exclusions before element validity",
    )

    anomaly_pattern_observed = {
        "rows": int(len(anomalies)),
        "survey_names": sorted(anomalies["galah_survey_name"].dropna().astype(str).unique()),
        "fields": sorted(anomalies["galah_field"].dropna().astype(str).unique()),
        "dates": sorted(anomalies["galah_observing_date"].dropna().astype(str).unique()),
    }
    anomaly_pattern_expected = {
        "rows": int(coord_expected["hard_mismatch"]),
        "survey_names": [str(coord_expected["galah_survey_name"])],
        "fields": [str(coord_expected["galah_field"])],
        "dates": sorted(map(str, coord_expected["observing_dates"])),
    }
    gate(
        "coordinate_anomaly_pattern",
        anomaly_pattern_observed,
        anomaly_pattern_expected,
        anomaly_pattern_observed == anomaly_pattern_expected,
        "known GALAH kerr/field=-9 observing-block metadata anomaly",
    )

    n_folds = int(config["fold_freeze"]["n_folds"])
    ranks_expected, folds_expected = frozen_folds(
        ids,
        seed=int(config["fold_freeze"]["seed"]),
        n_folds=n_folds,
    )
    stored_folds = frame["heldout_fold"].to_numpy(dtype=np.int8)
    stored_ranks = frame["heldout_rank_uint64"].to_numpy(dtype=np.uint64)
    deterministic = np.array_equal(stored_folds, folds_expected) and np.array_equal(
        stored_ranks, ranks_expected
    )
    assignment_hash = assignment_sha256(ids, stored_folds)
    expected_assignment_hash = str(config["fold_freeze"]["assignment_sha256"])
    gate(
        "deterministic_heldout_assignment",
        {
            "recomputed_exact": bool(deterministic),
            "sha256": assignment_hash,
        },
        {"recomputed_exact": True, "sha256": expected_assignment_hash},
        deterministic and assignment_hash == expected_assignment_hash,
        "SplitMix64 source-ID folds are independent of row order and Python RNG",
    )
    expected_fold_counts = {
        int(key): int(value)
        for key, value in config["fold_freeze"]["expected_all_overlap_fold_counts"].items()
    }
    observed_fold_counts = {
        fold: int((stored_folds == fold).sum()) for fold in range(n_folds)
    }
    gate(
        "all_overlap_fold_balance",
        observed_fold_counts,
        expected_fold_counts,
        observed_fold_counts == expected_fold_counts,
        "fold assignment frozen before any support exclusions",
    )

    assignment_identity = assignments.sort_values(
        "gaia_dr3_source_id", kind="mergesort"
    ).reset_index(drop=True)
    assignment_exact = (
        len(assignment_identity) == len(frame)
        and np.array_equal(
            assignment_identity["gaia_dr3_source_id"].to_numpy(dtype=np.int64),
            ids.to_numpy(dtype=np.int64),
        )
        and np.array_equal(
            assignment_identity["heldout_fold"].to_numpy(dtype=np.int8), stored_folds
        )
    )
    gate(
        "assignment_table_exact",
        bool(assignment_exact),
        True,
        bool(assignment_exact),
        "standalone fold table matches the frozen overlap table",
    )

    joint_expected = int(config["expected_support"]["joint_broad_rgb_and_quality"])
    gate(
        "joint_broad_rgb_and_quality",
        int(joint.sum()),
        joint_expected,
        int(joint.sum()) == joint_expected,
        "both surveys pass frozen broad-RGB and survey-quality gates",
    )

    support_observed: dict[str, dict[str, int]] = {}
    support_expected: dict[str, dict[str, int]] = {}
    support_hashes_match = True
    summary_hashes = summary.get("support_membership_sha256", {})
    for element in config["selection_freeze"]["elements"]:
        element = str(element)
        support_observed[element] = {}
        support_expected[element] = {
            key: int(value) for key, value in config["expected_support"][element].items()
        }
        for analysis_set in ("precoordinate", "primary", "sensitivity"):
            key = "pre_coordinate" if analysis_set == "precoordinate" else analysis_set
            mask = frame[f"eligible_{element}_{analysis_set}"].astype(bool)
            support_observed[element][key] = int(mask.sum())
            observed_hash = membership_sha256(ids, mask)
            support_hashes_match &= (
                observed_hash
                == summary_hashes.get(element, {}).get(analysis_set)
                == freeze.get("support_membership_sha256", {})
                .get(element, {})
                .get(analysis_set)
            )
    gate(
        "element_support_counts",
        support_observed,
        support_expected,
        support_observed == support_expected,
        "element-valid support before and after the frozen coordinate policy",
    )
    gate(
        "support_membership_hashes",
        bool(support_hashes_match),
        True,
        bool(support_hashes_match),
        "source-level support identities match both frozen manifests",
    )

    minimum_required = int(
        config["validation"]["minimum_primary_support_per_element_fold"]
    )
    primary_fold_rows = fold_balance.loc[
        fold_balance["analysis_set"].eq("primary")
    ]
    minimum_observed = int(primary_fold_rows["heldout_n"].min())
    gate(
        "minimum_primary_support_per_element_fold",
        minimum_observed,
        f">={minimum_required}",
        minimum_observed >= minimum_required,
        "each held-out element fold has adequate support for Stage 2B",
    )

    coordinate_hash = coordinate_decision_sha256(frame)
    coordinate_hash_expected = freeze.get("coordinate_decision_sha256")
    gate(
        "coordinate_decision_sha256",
        coordinate_hash,
        coordinate_hash_expected,
        coordinate_hash == coordinate_hash_expected,
        "source-level primary/sensitivity coordinate decisions are frozen",
    )

    forbidden_column_prefixes = (
        "calibrated_",
        "corrected_",
        "crossfit_",
        "predicted_",
        "calibration_residual_",
    )
    forbidden_columns = sorted(
        column
        for column in frame.columns
        if column.lower().startswith(forbidden_column_prefixes)
    )
    boundary_observed = {
        "summary_stage2b_performed": summary.get(
            "stage2b_cross_fitted_abundance_calibration_performed"
        ),
        "freeze_stage2b_performed": freeze.get("stage2b_boundary", {}).get(
            "cross_fitted_abundance_calibration_performed"
        ),
        "forbidden_columns": forbidden_columns,
    }
    boundary_expected = {
        "summary_stage2b_performed": False,
        "freeze_stage2b_performed": False,
        "forbidden_columns": [],
    }
    gate(
        "stage2b_boundary",
        boundary_observed,
        boundary_expected,
        boundary_observed == boundary_expected,
        "Stage 2A contains support/folds only, not abundance calibration",
    )

    table_hash = sha256_file(table_path)
    gate(
        "frozen_table_hash_recorded",
        table_hash,
        summary.get("outputs", {}).get("frozen_overlap_table_sha256"),
        table_hash == summary.get("outputs", {}).get("frozen_overlap_table_sha256"),
        "byte identity of the Stage 2A frozen overlap table",
    )

    overall = all(gate_item["passed"] for gate_item in gates)
    report = {
        "stage": "Stage 2A validation",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": utc_now(),
        "overall_passed": overall,
        "n_gates": len(gates),
        "n_passed": sum(int(item["passed"]) for item in gates),
        "gates": gates,
        "stage2b_cross_fitted_abundance_calibration_performed": False,
    }
    atomic_write_json(report, output_dir / "stage2a_validation.json")

    markdown = [
        "# Stage 2A validation report",
        "",
        f"Overall: **{'PASS' if overall else 'FAIL'}**",
        "",
        f"Protocol: `{config['project']['version']}`",
        "",
        "| Gate | Result | Detail |",
        "|---|---:|---|",
    ]
    for item in gates:
        markdown.append(
            f"| `{item['name']}` | {'PASS' if item['passed'] else 'FAIL'} | {item['detail']} |"
        )
    markdown.extend(
        [
            "",
            "Stage 2B cross-fitted abundance calibration was not performed.",
            "",
        ]
    )
    report_path = output_dir / "stage2a_validation_report.md"
    report_path.write_text("\n".join(markdown), encoding="utf-8")

    logger.info(
        "Stage 2A validation passed=%s; gates=%d/%d; report=%s",
        overall,
        report["n_passed"],
        report["n_gates"],
        report_path,
    )
    close_logger(logger)
    return 0 if overall else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
