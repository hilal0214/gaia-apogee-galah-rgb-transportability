from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from stage4a_common import (
    LABELS,
    common_support,
    covariate_balance,
    design_definition,
    healpix_from_source_id,
    ids_sha256,
    label_outcome_available,
    load_config,
    radial_domain,
    source_column,
    spatial_block_summary,
    stage2c_columns,
    stage3b_columns,
    stage3c_columns,
)


def check(condition: bool, message: str, passed: list[str]) -> None:
    if not condition:
        raise AssertionError(message)
    passed.append(message)


def main() -> int:
    config_path = Path(__file__).resolve().parents[1] / "config" / "stage4a.yml"
    config, _ = load_config(config_path)
    passed: list[str] = []

    values = np.asarray([3.0, 3.0001, 8.0, 14.9999, 15.0, np.nan])
    observed = radial_domain(values, config["analysis_contract"]["radial_domain"])
    check(
        observed.tolist() == [False, True, True, True, False, False],
        "strict radial-domain boundaries",
        passed,
    )

    source_ids = np.asarray([(17 << 49) + 123, (18 << 49) + 456], dtype=np.int64)
    blocks = healpix_from_source_id(source_ids, level=5, source_level=12, low_bits=35)
    check(blocks.tolist() == [17, 18], "Gaia source-ID HEALPix coarsening", passed)

    check(
        ids_sha256(source_ids) != ids_sha256(source_ids[::-1]),
        "source-ID hash is order-sensitive",
        passed,
    )

    count = 2400
    source = np.repeat(["APOGEE_NATIVE", "GALAH_CORRECTED"], count // 2)
    index = np.arange(count, dtype=float)
    frame = pd.DataFrame(
        {
            "fe_h_gradient_primary_ok": np.ones(count, dtype=bool),
            "fe_h_hom_source": source,
            "r_cyl_gc_kpc": np.r_[
                np.linspace(3.2, 13.2, count // 2),
                np.linspace(3.8, 12.0, count // 2),
            ],
            "abs_z_gc_kpc": np.r_[
                np.linspace(0.0, 4.0, count // 2),
                np.linspace(0.2, 3.2, count // 2),
            ],
            "analysis_teff": np.r_[
                np.linspace(3600.0, 5200.0, count // 2),
                np.linspace(3750.0, 5100.0, count // 2),
            ],
            "analysis_logg": np.r_[
                np.linspace(0.2, 3.45, count // 2),
                np.linspace(0.6, 3.30, count // 2),
            ],
            "gaia_dr3_source_id": ((index.astype(np.int64) + 1) << 49) + 11,
            "gaia_healpix5": index.astype(np.int32) + 1,
            "phase_space_6d_primary_ok": np.ones(count, dtype=bool),
            "survey_origin": np.where(
                source == "APOGEE_NATIVE", "APOGEE_only", "GALAH_only"
            ),
        }
    )
    policy = dict(config["analysis_contract"]["common_support"])
    policy["minimum_source_rows"] = 100
    selected, rows = common_support(frame, "fe_h", policy)
    frame["fe_h_gradient_common_support_ok"] = selected
    check(len(rows) == 4 and all(row["overlap_valid"] for row in rows), "four valid support intervals", passed)
    check(0 < int(selected.sum()) < count, "common support excludes covariate tails", passed)
    check(np.all(~selected | frame["fe_h_gradient_primary_ok"]), "common support is nested in nominal cohort", passed)

    balance = covariate_balance(frame, "fe_h", policy)
    check(len(balance) == 8, "nominal and common-support balance table", passed)

    blocks_summary = spatial_block_summary(frame)
    check(
        int(blocks_summary.loc[blocks_summary["scope"] == "ALL_PRIMARY_6D", "stars"].iloc[0])
        == count,
        "spatial-block summary preserves primary count",
        passed,
    )

    check(
        source_column("alpha3") == "alpha3_source"
        and source_column("fe_h") == "fe_h_hom_source",
        "label-specific provenance columns",
        passed,
    )

    availability_fixture = pd.DataFrame(
        {
            "alpha3_hom": [0.2, np.nan, 0.1, 0.3],
            "alpha3_hom_error_proxy": [0.04, np.nan, -0.01, np.inf],
        }
    )
    check(
        label_outcome_available(availability_fixture, "alpha3").tolist()
        == [True, False, False, False],
        "finite label and non-negative error-proxy guard",
        passed,
    )

    all_input_columns = stage2c_columns() + stage3b_columns() + stage3c_columns()
    check(
        all(column == "gaia_dr3_source_id" or all_input_columns.count(column) <= 2 for column in all_input_columns),
        "frozen input schemas contain only expected shared keys/flags",
        passed,
    )

    definition = design_definition(config, ["gaia_dr3_source_id"])
    convergence = definition["upstream_stage3c_convergence"]
    check(
        convergence["short_draws"] == 128 and convergence["full_draws"] == 256,
        "Stage 3C convergence nomenclature is corrected to 128-to-256",
        passed,
    )

    population = np.asarray([True, True, False, True])
    frame_stable = np.asarray([True, False, True, True])
    common = np.asarray([True, True, True, False])
    check(
        np.all((population & frame_stable) <= population)
        and np.all((population & common) <= population),
        "population sensitivity flags are nested in feature completeness",
        passed,
    )

    check(
        tuple(config["analysis_contract"]["labels"]) == LABELS
        and "c_n" in set(config["analysis_contract"]["forbidden_labels"]),
        "validated six-label contract excludes C/N",
        passed,
    )

    if len(passed) != 14:
        raise AssertionError(f"Internal self-test count is {len(passed)}, expected 14")
    print("Stage 4A logic self-test passed: 14/14")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
