from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


ELEMENTS = ("fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe")
ANALYSIS_SETS = ("primary", "sensitivity")
COEFFICIENT_NAMES = (
    "intercept_dex",
    "coef_teff_per_1000k",
    "coef_logg_per_dex",
    "coef_feh_per_dex",
)
MAD_TO_SIGMA = 1.482602218505602


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_config(path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {config_path}")
    return config, config_path.parent.parent


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def setup_logger(path: Path, name: str) -> logging.Logger:
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def close_logger(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        handler.flush()
        handler.close()
        logger.removeHandler(handler)


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        temporary = Path(handle.name)
    os.replace(temporary, path)


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(block_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def canonical_line_sha256(lines: Iterable[str]) -> str:
    digest = hashlib.sha256()
    for line in lines:
        digest.update(line.encode("ascii"))
    return digest.hexdigest()


def ids_sha256(values: Sequence[int] | np.ndarray | pd.Series) -> str:
    values_array = np.asarray(values, dtype=np.int64)
    return canonical_line_sha256(f"{int(value)}\n" for value in values_array)


def assignment_sha256(
    source_ids: Sequence[int] | np.ndarray | pd.Series,
    folds: Sequence[int] | np.ndarray | pd.Series,
) -> str:
    ids = np.asarray(source_ids, dtype=np.int64)
    fold_values = np.asarray(folds, dtype=np.int16)
    if len(ids) != len(fold_values):
        raise ValueError("ID and fold vectors have different lengths")
    return canonical_line_sha256(
        f"{int(source_id)},{int(fold)}\n"
        for source_id, fold in zip(ids, fold_values)
    )


def canonical_json_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def ensure_columns(frame: pd.DataFrame, required: Sequence[str], label: str) -> None:
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise KeyError(f"{label} is missing required columns: {missing}")


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    if path.suffix == ".parquet":
        frame.to_parquet(temporary, index=False, compression="zstd")
    elif path.suffix == ".csv":
        frame.to_csv(temporary, index=False)
    else:
        raise ValueError(f"Unsupported table format: {path}")
    os.replace(temporary, path)


def design_matrix(frame: pd.DataFrame, config: Mapping[str, Any]) -> np.ndarray:
    ensure_columns(frame, ("galah_teff", "galah_logg", "galah_fe_h"), "predictors")
    centres = config["calibration"]["predictor_centres"]
    scales = config["calibration"]["predictor_scales"]
    teff = (
        pd.to_numeric(frame["galah_teff"], errors="coerce").to_numpy(dtype=float)
        - float(centres["galah_teff_k"])
    ) / float(scales["galah_teff_k"])
    logg = (
        pd.to_numeric(frame["galah_logg"], errors="coerce").to_numpy(dtype=float)
        - float(centres["galah_logg_dex"])
    ) / float(scales["galah_logg_dex"])
    feh = pd.to_numeric(frame["galah_fe_h"], errors="coerce").to_numpy(
        dtype=float
    ) / float(scales["galah_fe_h_dex"])
    matrix = np.column_stack([np.ones(len(frame), dtype=float), teff, logg, feh])
    if not np.isfinite(matrix).all():
        raise ValueError("Calibration design matrix contains a non-finite value")
    return matrix


def fit_huber_irls(
    matrix: np.ndarray,
    response: np.ndarray,
    *,
    huber_c: float,
    mad_to_sigma: float,
    minimum_scale: float,
    maximum_iterations: int,
    coefficient_tolerance: float,
) -> dict[str, Any]:
    x = np.asarray(matrix, dtype=float)
    y = np.asarray(response, dtype=float)
    if x.ndim != 2 or y.ndim != 1 or len(x) != len(y):
        raise ValueError("Invalid design/response shapes")
    if len(y) <= x.shape[1] or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("Insufficient or non-finite calibration data")
    if np.linalg.matrix_rank(x) != x.shape[1]:
        raise ValueError("Calibration design matrix is rank deficient")

    coefficients = np.linalg.lstsq(x, y, rcond=None)[0]
    converged = False
    scale = float(minimum_scale)
    iterations = 0
    for iterations in range(1, int(maximum_iterations) + 1):
        residual = y - x @ coefficients
        centre = float(np.median(residual))
        mad = float(np.median(np.abs(residual - centre)))
        scale = max(float(minimum_scale), float(mad_to_sigma) * mad)
        standardized = np.abs((residual - centre) / scale)
        weights = np.ones_like(standardized)
        tail = standardized > float(huber_c)
        weights[tail] = float(huber_c) / standardized[tail]
        root_weight = np.sqrt(weights)
        updated = np.linalg.lstsq(x * root_weight[:, None], y * root_weight, rcond=None)[0]
        threshold = float(coefficient_tolerance) * (
            1.0 + float(np.max(np.abs(coefficients)))
        )
        if float(np.max(np.abs(updated - coefficients))) <= threshold:
            coefficients = updated
            converged = True
            break
        coefficients = updated

    residual = y - x @ coefficients
    residual_centre = float(np.median(residual))
    residual_mad = float(np.median(np.abs(residual - residual_centre)))
    scale = max(float(minimum_scale), float(mad_to_sigma) * residual_mad)
    return {
        "coefficients": coefficients,
        "converged": converged,
        "n_iterations": int(iterations),
        "robust_scale": float(scale),
        "condition_number": float(np.linalg.cond(x)),
    }


def calibration_metrics(raw_delta: np.ndarray, residual: np.ndarray) -> dict[str, float]:
    raw = np.asarray(raw_delta, dtype=float)
    post = np.asarray(residual, dtype=float)
    if len(raw) == 0 or len(raw) != len(post):
        raise ValueError("Metric vectors are empty or have different lengths")
    raw_median = float(np.median(raw))
    raw_centered = raw - raw_median
    raw_mad = float(np.median(np.abs(raw_centered)))
    raw_rmse = float(np.sqrt(np.mean(raw_centered**2)))
    post_median = float(np.median(post))
    post_centered = post - post_median
    post_mad = float(np.median(np.abs(post_centered)))
    post_rmse = float(np.sqrt(np.mean(post**2)))
    return {
        "raw_median_offset_dex": raw_median,
        "raw_centered_mad_dex": raw_mad,
        "raw_centered_sigma_mad_dex": MAD_TO_SIGMA * raw_mad,
        "raw_centered_rmse_dex": raw_rmse,
        "post_crossfit_median_residual_dex": post_median,
        "post_crossfit_mad_dex": post_mad,
        "post_crossfit_sigma_mad_dex": MAD_TO_SIGMA * post_mad,
        "post_crossfit_rmse_dex": post_rmse,
        "post_to_raw_mad_ratio": post_mad / raw_mad if raw_mad > 0 else float("nan"),
        "post_to_raw_rmse_ratio": post_rmse / raw_rmse if raw_rmse > 0 else float("nan"),
    }


def feature_support_summary(frame: pd.DataFrame, config: Mapping[str, Any]) -> dict[str, Any]:
    matrix = design_matrix(frame, config)
    names = ("intercept", "galah_teff_scaled", "galah_logg_centered", "galah_fe_h")
    result: dict[str, Any] = {}
    for index, name in enumerate(names[1:], start=1):
        values = matrix[:, index]
        quantiles = np.quantile(values, [0.005, 0.01, 0.5, 0.99, 0.995])
        result[name] = {
            "minimum": float(np.min(values)),
            "q0_005": float(quantiles[0]),
            "q0_01": float(quantiles[1]),
            "median": float(quantiles[2]),
            "q0_99": float(quantiles[3]),
            "q0_995": float(quantiles[4]),
            "maximum": float(np.max(values)),
        }
    return result


def to_python(value: Any) -> Any:
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, dict):
        return {str(key): to_python(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_python(item) for item in value]
    return value
