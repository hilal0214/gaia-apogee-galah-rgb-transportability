from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from stage4b_common import (
    COHORTS,
    LABELS,
    cluster_inference,
    cohort_mask,
    convergence_record,
    coordinate_features,
    fit_huber,
    ids_sha256,
    influence_records,
    interaction_transform,
    label_error_column,
    label_source_column,
    label_value_column,
    load_config,
    read_json,
    sha256_file,
    stable_seed,
    summarize_draws,
)


def check(condition: bool, message: str, passed: list[str]) -> None:
    if not condition:
        raise AssertionError(message)
    passed.append(message)


def main() -> int:
    config_path = Path(__file__).resolve().parents[1] / "config" / "stage4b.yml"
    config, root = load_config(config_path)
    passed: list[str] = []
    patch_manifest = read_json(root / "STAGE4B_PATCH_MANIFEST.json")
    manifest_errors = []
    for entry in patch_manifest["files"]:
        path = root / entry["path"]
        if (
            not path.is_file()
            or path.stat().st_size != int(entry["bytes"])
            or sha256_file(path) != str(entry["sha256"])
        ):
            manifest_errors.append(str(entry["path"]))
    check(
        len(patch_manifest["files"]) == 13 and not manifest_errors,
        "overlay patch manifest size and SHA-256 identity",
        passed,
    )
    model = config["analysis_contract"]["nominal_model"]
    fit_kwargs = {
        "tuning_constant": float(model["huber_tuning_constant"]),
        "relative_tolerance": float(model["convergence_relative_tolerance"]),
        "maximum_iterations": int(model["maximum_iterations"]),
        "minimum_scale": float(model["minimum_scale"]),
    }

    generator = np.random.Generator(np.random.PCG64DXSM(20260803))
    rows = 6000
    blocks = np.repeat(np.arange(200, dtype=np.int64), rows // 200)
    radius = generator.uniform(-4.5, 4.5, rows)
    height = generator.uniform(0.0, 4.0, rows)
    block_offset = generator.normal(0.0, 0.025, 200)[blocks]
    truth = np.asarray([0.12, -0.040, 0.065])
    response = truth[0] + truth[1] * radius + truth[2] * height
    response += block_offset + generator.normal(0.0, 0.035, rows)
    contaminated = radius > 3.7
    response[contaminated] += 1.5
    features = np.column_stack([radius, height])
    fit = fit_huber(features, response, **fit_kwargs)
    check(
        fit.converged and fit.rank == 3 and fit.score_max_abs_per_row < 1.0e-8,
        "Huber IRLS converges at full rank with a closed estimating equation",
        passed,
    )
    check(
        np.max(np.abs(fit.beta[1:] - truth[1:])) < 0.012,
        "Huber slopes resist the synthetic covariate-tail contamination",
        passed,
    )
    ordinary = np.linalg.lstsq(np.column_stack([np.ones(rows), features]), response, rcond=None)[0]
    check(
        np.linalg.norm(fit.beta[1:] - truth[1:])
        < np.linalg.norm(ordinary[1:] - truth[1:]),
        "Huber slope error is smaller than OLS under structured outliers",
        passed,
    )

    seed = stable_seed("stage4b-selftest", "synthetic-global")
    inference = cluster_inference(
        features,
        response,
        blocks,
        fit,
        n_draws=1024,
        seed=seed,
        finite_cluster_correction=True,
    )
    check(
        inference.draws is not None
        and inference.draws.shape == (1024, 3)
        and len(inference.block_ids) == 200,
        "cluster multiplier draw and block dimensions",
        passed,
    )
    half = 512
    check(
        np.allclose(
            (inference.draws[:half] + inference.draws[half:]) / 2.0,
            fit.beta[None, :],
            rtol=0.0,
            atol=1.0e-14,
        ),
        "Rademacher multiplier draws are exactly antithetic",
        passed,
    )
    draw_sd = np.std(inference.draws, axis=0, ddof=1)
    check(
        np.max(
            np.abs(draw_sd - inference.standard_errors)
            / np.maximum(inference.standard_errors, 1.0e-15)
        )
        < 0.15,
        "finite-draw dispersion matches the cluster sandwich standard error",
        passed,
    )
    repeated = cluster_inference(
        features,
        response,
        blocks,
        fit,
        n_draws=1024,
        seed=seed,
        finite_cluster_correction=True,
    )
    check(
        np.array_equal(inference.draws, repeated.draws)
        and stable_seed("stage4b-selftest", "synthetic-global") == seed
        and stable_seed("stage4b-selftest", "other-model") != seed,
        "model-specific seeded resampling is byte-deterministic",
        passed,
    )
    convergence = convergence_record(
        label="fe_h",
        model_id="GLOBAL_PRIMARY",
        parameter="BETA_R",
        draws=inference.draws[:, 1],
        convergence_draws=512,
    )
    check(
        convergence["relative_halfwidth_difference"] < 0.20
        and convergence["median_absolute_difference"] < 1.0e-14,
        "paired antithetic convergence diagnostic",
        passed,
    )
    summary = summarize_draws(
        fit.beta[1],
        inference.standard_errors[1],
        inference.draws[:, 1],
        (0.025, 0.16, 0.50, 0.84, 0.975),
    )
    check(
        summary["q025"] <= summary["q16"] <= summary["q50"] <= summary["q84"] <= summary["q975"],
        "bootstrap quantiles are ordered",
        passed,
    )
    influence = influence_records(
        label="fe_h",
        model_id="GLOBAL_PRIMARY",
        parameter_names=("INTERCEPT", "BETA_R", "BETA_Z"),
        transform=np.eye(3),
        inference=inference,
        standard_errors=inference.standard_errors,
        top_blocks=3,
    )
    check(
        len(influence) == 9
        and all(np.isfinite(row["absolute_delta_over_cluster_se"]) for row in influence),
        "delete-one-block influence ranking is finite and complete",
        passed,
    )

    transform = interaction_transform()
    raw = np.asarray([0.1, -0.02, 0.05, 0.03, 0.01, -0.015])
    derived = transform @ raw
    check(
        np.allclose(derived[3:6], derived[:3] + derived[6:9]),
        "APOGEE-plus-contrast interaction algebra",
        passed,
    )

    fixture = pd.DataFrame(
        {
            "fe_h_gradient_primary_ok": [True, False, True],
            "fe_h_gradient_core_ok": [True, False, False],
            "fe_h_gradient_common_support_ok": [False, False, True],
            "fe_h_gradient_disc5_ok": [True, False, True],
            "fe_h_gradient_geo_paired_ok": [True, False, True],
            "fe_h_gradient_sensitivity_ok": [True, True, True],
            "r_cyl_gc_kpc": [7.0, 8.0, 9.0],
            "abs_z_gc_kpc": [0.2, 0.4, 0.6],
            "r_cyl_gc_kpc_geo_alt": [7.1, 8.2, 9.3],
            "z_gc_kpc_geo_alt": [-0.25, 0.45, -0.65],
        }
    )
    check(
        [int(cohort_mask(fixture, "fe_h", cohort, config).sum()) for cohort in COHORTS]
        == [2, 1, 1, 2, 2, 3],
        "six-rung cohort flag routing",
        passed,
    )
    nominal = coordinate_features(fixture, np.ones(3, dtype=bool), "PRIMARY", 8.2)
    geometric = coordinate_features(fixture, np.ones(3, dtype=bool), "GEO_PAIRED", 8.2)
    check(
        not np.array_equal(nominal, geometric)
        and np.all(geometric[:, 1] >= 0.0),
        "geometric sensitivity uses alternate R and absolute Z",
        passed,
    )
    check(
        label_value_column("alpha3") == "alpha3_hom"
        and label_error_column("alpha3") == "alpha3_hom_error_proxy"
        and label_source_column("alpha3") == "alpha3_source"
        and label_value_column("fe_h") == "fe_h_hom",
        "label-specific value, error, and provenance routing",
        passed,
    )
    source_ids = np.asarray([1001, 1002, 1003], dtype=np.int64)
    check(
        ids_sha256(source_ids) != ids_sha256(source_ids[::-1]),
        "candidate hash is order-sensitive",
        passed,
    )
    boundary = config["science_boundary"]
    check(
        tuple(config["analysis_contract"]["labels"]) == LABELS
        and "c_n" in set(config["analysis_contract"]["forbidden_labels"])
        and not boundary["population_model_fitted"]
        and not boundary["selection_function_corrected"]
        and not boundary["abundance_error_proxy_used_as_regression_weight"],
        "six-label inference and claim boundary excludes C/N, populations, and selection weights",
        passed,
    )

    if len(passed) != 17:
        raise AssertionError(f"Internal self-test count is {len(passed)}, expected 17")
    print("Stage 4B logic self-test passed: 17/17")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
