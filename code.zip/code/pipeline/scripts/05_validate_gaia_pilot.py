from __future__ import annotations

import argparse
import json
import sys

import pandas as pd

from gaia_query_logic import (
    DISTANCE_COLUMNS,
    GAIA_COLUMNS,
    PILOT_ORIGINS,
    exact_source_recovery,
    ids_sha256,
    query_signature,
    validate_source_chunk,
)
from stage1_common import (
    atomic_write_json,
    configured_paths,
    load_config,
    normalise_id_series,
    read_frame,
    read_json,
    setup_logger,
    table_suffix,
    utc_now,
)


def gate(name: str, passed: bool, observed, expected, detail: str) -> dict:
    return {
        "name": name,
        "passed": bool(passed),
        "observed": observed,
        "expected": expected,
        "detail": detail,
    }


def interval_audit(frame: pd.DataFrame, low: str, median: str, high: str) -> dict:
    triplet = frame[[low, median, high]].apply(pd.to_numeric, errors="coerce")
    complete = triplet.notna().all(axis=1)
    partial = triplet.notna().any(axis=1) & ~complete
    values = triplet.loc[complete]
    nonpositive = (values <= 0).any(axis=1)
    unordered = (values[low] > values[median]) | (values[median] > values[high])
    return {
        "complete_rows": int(complete.sum()),
        "partial_rows": int(partial.sum()),
        "nonpositive_complete_rows": int(nonpositive.sum()),
        "unordered_complete_rows": int(unordered.sum()),
    }


def census_adjudication(config: dict, ingest: dict, identifier: dict, census: dict, duplicate: pd.DataFrame) -> dict:
    raw_total = int(ingest["raw_catalogue_rows"]["concatenated_total"])
    direct_overlap = int(identifier["raw_unique_id_sets"]["intersection"])
    legacy = int(config["legacy_benchmarks"]["cross_survey_union_rows_reported"])
    true_union = int(census["mutually_exclusive_gaia_dr3_union"]["union"])
    within_removed = int(duplicate["removed_duplicate_rows"].sum())
    deduplicated_records = census["deduplicated_survey_records"]
    positive_ids = identifier["raw_unique_id_sets"]
    deduplicated_without_positive_id = (
        int(deduplicated_records["apogee"])
        - int(positive_ids["apogee_unique"])
        + int(deduplicated_records["galah"])
        - int(positive_ids["galah_unique"])
    )
    return {
        "stage": "Stage 1 census interpretation adjudication",
        "created_utc": utc_now(),
        "raw_row_sum": raw_total,
        "direct_cross_survey_overlap": direct_overlap,
        "legacy_value": legacy,
        "legacy_equals_raw_sum_minus_direct_overlap": bool(
            legacy == raw_total - direct_overlap
        ),
        "true_unique_positive_gaia_union": true_union,
        "legacy_minus_true_union": legacy - true_union,
        "difference_decomposition": {
            "within_survey_duplicate_rows_removed": within_removed,
            "deduplicated_records_without_positive_gaia_id": (
                deduplicated_without_positive_id
            ),
            "sum": within_removed + deduplicated_without_positive_id,
        },
        "decomposition_closes": bool(
            legacy - true_union
            == within_removed + deduplicated_without_positive_id
        ),
        "interpretation": (
            "The legacy value is raw-row arithmetic after subtracting only the "
            "direct cross-survey overlap. It is not a unique-star union."
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/stage1.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    paths = configured_paths(config, root)
    logger = setup_logger(
        paths["log_dir"] / "05_validate_gaia_pilot.log",
        "stage1.gaia.pilot.validate",
    )
    suffix = table_suffix(config)
    required = {
        "selection": paths["output_dir"] / f"gaia_pilot_selection{suffix}",
        "selection_manifest": paths["output_dir"]
        / "gaia_pilot_selection_manifest.json",
        "query_summary": paths["output_dir"] / "gaia_pilot_query_summary.json",
        "ingest": paths["output_dir"] / "catalogue_ingest_summary.json",
        "identifier": paths["output_dir"] / "gaia_identifier_audit.json",
        "census": paths["output_dir"] / "stage1_census_summary.json",
        "census_validation": paths["output_dir"] / "stage1_validation.json",
        "duplicates": paths["output_dir"] / "within_survey_duplicate_audit.csv",
    }
    missing = [str(path) for path in required.values() if not path.exists()]
    if missing:
        raise FileNotFoundError(
            "Missing pilot/census products:\n" + "\n".join(missing)
        )

    selection = read_frame(required["selection"])
    selection["gaia_dr3_source_id"] = normalise_id_series(
        selection["gaia_dr3_source_id"]
    )
    selection_manifest = read_json(required["selection_manifest"])
    summary = read_json(required["query_summary"])
    ingest = read_json(required["ingest"])
    identifier = read_json(required["identifier"])
    census = read_json(required["census"])
    census_validation = read_json(required["census_validation"])
    duplicate = pd.read_csv(required["duplicates"])

    pilot_config = config["gaia"]["pilot"]
    expected_size = int(pilot_config["size"])
    expected_origins = {
        origin: int(pilot_config["strata"][origin]) for origin in PILOT_ORIGINS
    }
    selection_ids = selection["gaia_dr3_source_id"].to_numpy(dtype="int64")
    selection_hash = ids_sha256(selection_ids)
    namespace = selection_hash[:16]
    joined_dir = paths["interim_dir"] / "gaia_dr3_pilot" / namespace / "joined"
    planned_chunks = int(summary.get("planned_chunks", 0))
    joined_paths = [
        joined_dir / f"chunk_{index:05d}{suffix}"
        for index in range(planned_chunks)
    ]
    missing_joined = [str(path) for path in joined_paths if not path.exists()]
    if missing_joined:
        raise FileNotFoundError(
            "Missing joined pilot chunks:\n" + "\n".join(missing_joined)
        )
    joined = pd.concat([read_frame(path) for path in joined_paths], ignore_index=True)
    joined["source_id"] = normalise_id_series(joined["source_id"])

    expected_columns = list(dict.fromkeys(["input_order", *GAIA_COLUMNS, *DISTANCE_COLUMNS]))
    missing_columns = [column for column in expected_columns if column not in joined]
    joined_stats = validate_source_chunk(joined, selection_ids)
    origin_counts = {
        origin: int(selection["survey_origin"].eq(origin).sum())
        for origin in PILOT_ORIGINS
    }
    totals = summary["totals_for_completed_chunks"]
    source_summary_stats = {
        key: int(totals[key])
        for key in ("requested", "returned", "missing", "unexpected", "duplicate_rows")
    }
    distance_identity = {
        "requested": int(totals["requested"]),
        "returned": int(totals["distance_rows"]),
        "not_in_distance_table": int(totals["not_in_distance_table"]),
        "unexpected": int(totals["distance_unexpected"]),
        "duplicate_rows": int(totals["distance_duplicate_rows"]),
    }
    geometric = interval_audit(joined, "r_lo_geo", "r_med_geo", "r_hi_geo")
    photogeometric = interval_audit(
        joined,
        "r_lo_photogeo",
        "r_med_photogeo",
        "r_hi_photogeo",
    )
    core_non_null = {
        column: int(joined[column].notna().sum())
        for column in ("source_id", "ra", "dec")
        if column in joined
    }

    adjudication = census_adjudication(
        config,
        ingest,
        identifier,
        census,
        duplicate,
    )
    adjudication_path = (
        paths["output_dir"] / "stage1_census_adjudication_v0_1_2.json"
    )
    atomic_write_json(adjudication, adjudication_path)

    gates = [
        gate(
            "census_checkpoint_passed",
            census_validation.get("overall_passed") is True,
            census_validation.get("overall_passed"),
            True,
            "frozen Stage 1 census gate",
        ),
        gate(
            "legacy_count_adjudicated",
            adjudication["legacy_equals_raw_sum_minus_direct_overlap"]
            and adjudication["decomposition_closes"],
            adjudication,
            {
                "legacy_equals_raw_sum_minus_direct_overlap": True,
                "decomposition_closes": True,
            },
            "legacy 1,591,571 is not treated as a unique-star union",
        ),
        gate(
            "pilot_size",
            len(selection) == expected_size,
            len(selection),
            expected_size,
            "frozen infrastructure-pilot size",
        ),
        gate(
            "pilot_strata",
            origin_counts == expected_origins,
            origin_counts,
            expected_origins,
            "all three mutually exclusive survey origins are exercised",
        ),
        gate(
            "pilot_selection_identity",
            selection["gaia_dr3_source_id"].gt(0).all()
            and not selection["gaia_dr3_source_id"].duplicated().any()
            and selection_hash == selection_manifest.get("selection_sha256")
            and selection_hash == summary.get("selection_sha256"),
            {
                "positive": int(selection["gaia_dr3_source_id"].gt(0).sum()),
                "duplicates": int(selection["gaia_dr3_source_id"].duplicated().sum()),
                "sha256": selection_hash,
            },
            {"positive": expected_size, "duplicates": 0, "sha256_consistent": True},
            "deterministic pilot identity",
        ),
        gate(
            "pilot_scientific_role",
            selection_manifest.get("scientific_role")
            == "infrastructure and schema audit only; not a scientific subsample",
            selection_manifest.get("scientific_role"),
            "infrastructure and schema audit only; not a scientific subsample",
            "prevents pilot results from being used as gradient evidence",
        ),
        gate(
            "query_protocol",
            summary.get("query_protocol_version")
            == config["gaia"]["query_protocol_version"]
            and summary.get("query_signature_sha256") == query_signature(config),
            {
                "version": summary.get("query_protocol_version"),
                "signature": summary.get("query_signature_sha256"),
            },
            {
                "version": config["gaia"]["query_protocol_version"],
                "signature": query_signature(config),
            },
            "cache-safe query schema",
        ),
        gate(
            "pilot_query_complete",
            summary.get("mode") == "pilot"
            and summary.get("complete") is True
            and int(summary.get("unique_requested_ids", -1)) == expected_size
            and int(summary.get("completed_chunks", -1)) == planned_chunks,
            {
                "mode": summary.get("mode"),
                "complete": summary.get("complete"),
                "unique_requested_ids": summary.get("unique_requested_ids"),
                "completed_chunks": summary.get("completed_chunks"),
            },
            {
                "mode": "pilot",
                "complete": True,
                "unique_requested_ids": expected_size,
                "completed_chunks": planned_chunks,
            },
            "all deterministic pilot chunks completed",
        ),
        gate(
            "pilot_source_recovery",
            exact_source_recovery(source_summary_stats)
            and source_summary_stats["requested"] == expected_size
            and source_summary_stats["returned"] == expected_size,
            source_summary_stats,
            {
                "requested": expected_size,
                "returned": expected_size,
                "missing": 0,
                "unexpected": 0,
                "duplicate_rows": 0,
            },
            "exact Gaia source-ID recovery",
        ),
        gate(
            "joined_schema",
            not missing_columns,
            {"missing_columns": missing_columns, "observed_columns": len(joined.columns)},
            {"missing_columns": [], "required_columns": len(expected_columns)},
            "requested Gaia and Bailer-Jones columns are materialized",
        ),
        gate(
            "joined_identity",
            exact_source_recovery(joined_stats),
            joined_stats,
            {
                "requested": expected_size,
                "returned": expected_size,
                "missing": 0,
                "unexpected": 0,
                "duplicate_rows": 0,
            },
            "joined pilot table preserves the requested ID set exactly",
        ),
        gate(
            "core_astrometry_present",
            core_non_null == {
                "source_id": expected_size,
                "ra": expected_size,
                "dec": expected_size,
            },
            core_non_null,
            {"source_id": expected_size, "ra": expected_size, "dec": expected_size},
            "Gaia identity and sky position fields are complete",
        ),
        gate(
            "distance_identity_accounting",
            distance_identity["returned"]
            + distance_identity["not_in_distance_table"]
            == distance_identity["requested"]
            and distance_identity["unexpected"] == 0
            and distance_identity["duplicate_rows"] == 0,
            distance_identity,
            {
                "returned_plus_not_in_table_equals_requested": True,
                "unexpected": 0,
                "duplicate_rows": 0,
            },
            "missing distance rows are counted rather than silently removed",
        ),
        gate(
            "geometric_distance_intervals",
            geometric["partial_rows"] == 0
            and geometric["nonpositive_complete_rows"] == 0
            and geometric["unordered_complete_rows"] == 0,
            geometric,
            {"partial_rows": 0, "nonpositive_complete_rows": 0, "unordered_complete_rows": 0},
            "geometric posterior intervals are positive and ordered",
        ),
        gate(
            "photogeometric_distance_intervals",
            photogeometric["partial_rows"] == 0
            and photogeometric["nonpositive_complete_rows"] == 0
            and photogeometric["unordered_complete_rows"] == 0,
            photogeometric,
            {"partial_rows": 0, "nonpositive_complete_rows": 0, "unordered_complete_rows": 0},
            "photogeometric posterior intervals are positive and ordered",
        ),
    ]

    column_rows = []
    for column in expected_columns:
        non_null = int(joined[column].notna().sum()) if column in joined else 0
        column_rows.append(
            {
                "column": column,
                "non_null": non_null,
                "total": int(len(joined)),
                "fraction": non_null / len(joined) if len(joined) else 0.0,
            }
        )
    pd.DataFrame(column_rows).to_csv(
        paths["output_dir"] / "gaia_pilot_column_completeness.csv",
        index=False,
    )
    pd.DataFrame(
        [
            {
                "survey_origin": origin,
                "selected": origin_counts[origin],
                "configured_quota": expected_origins[origin],
            }
            for origin in PILOT_ORIGINS
        ]
    ).to_csv(paths["output_dir"] / "gaia_pilot_origin_flow.csv", index=False)

    overall = all(item["passed"] for item in gates)
    validation = {
        "stage": "Stage 1D-P deterministic Gaia/Bailer-Jones pilot validation",
        "query_protocol_version": config["gaia"]["query_protocol_version"],
        "created_utc": utc_now(),
        "overall_passed": overall,
        "gates": gates,
        "pilot_counts": {
            "selected": int(len(selection)),
            "origins": origin_counts,
            "geometric_distance_available": geometric["complete_rows"],
            "photogeometric_distance_available": photogeometric["complete_rows"],
        },
        "overlap_label_context": census.get("overlap_valid_label_counts", {}),
        "scientific_caution": (
            "The 59,918 identifier-level overlap is not the calibration-ready "
            "sample. Per-element valid-label overlap is about 19.6k-20.5k before "
            "stricter joint RGB and quality gates."
        ),
        "census_adjudication": adjudication,
    }
    validation_path = paths["output_dir"] / "gaia_pilot_validation.json"
    atomic_write_json(validation, validation_path)

    lines = [
        "# Stage 1D-P Gaia/Bailer-Jones pilot validation",
        "",
        f"- Query protocol: `{config['gaia']['query_protocol_version']}`",
        f"- Overall passed: **{overall}**",
        f"- Pilot sources: {len(selection):,}",
        f"- Geometric distances: {geometric['complete_rows']:,}",
        f"- Photogeometric distances: {photogeometric['complete_rows']:,}",
        "",
        "## Gates",
        "",
        "| Gate | Passed | Observed | Expected |",
        "|---|---:|---|---|",
    ]
    for item in gates:
        observed = json.dumps(item["observed"], sort_keys=True)
        expected = json.dumps(item["expected"], sort_keys=True)
        lines.append(
            f"| {item['name']} | {'yes' if item['passed'] else 'NO'} | "
            f"`{observed}` | `{expected}` |"
        )
    lines.extend(
        [
            "",
            "## Interpretation locks",
            "",
            "- The pilot is an infrastructure/schema audit, not a scientific sample.",
            "- The legacy 1,591,571 value is not a unique-star union.",
            "- The 59,918 same-ID overlap is not the calibration-ready sample.",
            "",
        ]
    )
    report_path = paths["output_dir"] / "gaia_pilot_validation_report.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")
    logger.info("Pilot validation passed=%s; report=%s", overall, report_path)
    return 0 if overall else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
