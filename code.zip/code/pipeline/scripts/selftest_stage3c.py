from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from stage3c_common import (
    CORRELATION_PAIRS,
    METRIC_SPECS,
    array_sha256,
    correlation_matrices,
    deterministic_subset_positions,
    explicit_frame,
    fixed_antithetic_normals,
    frame_definition,
    load_config,
    piecewise_log_distance,
    propagate_chunk,
    resolve_frame_variants,
)


EXPECTED_ENSEMBLE_SHA256 = (
    "e1f1374e49e49efd05ec31d65a0ce8fcd5edeac6031f4fc50bf2af7ed8af850b"
)


def synthetic_frame() -> pd.DataFrame:
    row = {
        "gaia_dr3_source_id": 123456789012345678,
        "ra": 120.0,
        "dec": 30.0,
        "pmra": 4.0,
        "pmdec": -2.0,
        "ra_error": 0.05,
        "dec_error": 0.04,
        "parallax_error": 0.03,
        "pmra_error": 0.05,
        "pmdec_error": 0.05,
        "gaia_covariance_valid": True,
        "distance_primary_lo_pc": 900.0,
        "distance_primary_pc": 1000.0,
        "distance_primary_hi_pc": 1120.0,
        "analysis_rv_kms": 25.0,
        "analysis_rv_error_kms": 0.5,
        "clean_6d_primary_ok": True,
    }
    for _, _, name in CORRELATION_PAIRS:
        row[name] = 0.0
    row["ra_pmra_corr"] = 0.2
    row["parallax_pmra_corr"] = -0.15
    return pd.DataFrame([row])


def main() -> int:
    root = Path(__file__).resolve().parent.parent
    config, _ = load_config(root / "config/stage3c.yml")
    policy = config["uncertainty_policy"]
    tests: list[tuple[str, bool]] = []
    normals = fixed_antithetic_normals(policy)
    tests.append(
        (
            "ensemble_shape_and_frozen_digest",
            normals.shape == (256, 6)
            and array_sha256(normals) == EXPECTED_ENSEMBLE_SHA256,
        )
    )
    tests.append(("antithetic_pairs", bool(np.array_equal(normals[0::2], -normals[1::2]))))
    tests.append(
        (
            "nested_128_draw_antithetic_prefix",
            bool(np.array_equal(normals[:128:2], -normals[1:128:2])),
        )
    )

    anchors = piecewise_log_distance(
        np.array([[-1.0, 0.0, 1.0]]),
        np.array([900.0]),
        np.array([1000.0]),
        np.array([1120.0]),
    )
    tests.append(
        (
            "distance_quantile_anchors",
            bool(np.allclose(anchors, [[900.0, 1000.0, 1120.0]], rtol=0.0, atol=1e-10)),
        )
    )

    frame = synthetic_frame()
    correlation = correlation_matrices(frame)[0]
    tests.append(
        (
            "gaia_correlation_reconstruction",
            bool(
                np.allclose(np.diag(correlation), 1.0)
                and np.allclose(correlation, correlation.T)
                and correlation[0, 3] == 0.2
                and correlation[2, 3] == -0.15
            ),
        )
    )
    invalid = frame.copy()
    invalid.loc[0, "ra_dec_corr"] = 1.2
    rejected = False
    try:
        propagate_chunk(
            invalid,
            policy,
            config["frame_policy"]["base"],
            normals,
        )
    except (RuntimeError, np.linalg.LinAlgError):
        rejected = True
    tests.append(("non_psd_covariance_rejected", rejected))

    astropy_frame = explicit_frame(config["frame_policy"]["base"])
    definition = frame_definition(config["frame_policy"]["base"])
    tests.append(
        (
            "explicit_frame_exact",
            bool(
                np.isclose(astropy_frame.galcen_distance.to_value("kpc"), 8.122)
                and np.isclose(astropy_frame.z_sun.to_value("pc"), 20.8)
                and definition["galcen_v_sun_kms"] == [12.9, 245.6, 7.78]
            ),
        )
    )
    variants = resolve_frame_variants(config["frame_policy"])
    tests.append(
        (
            "six_unique_frame_variants",
            len(variants) == 6 and len({item["name"] for item in variants}) == 6,
        )
    )

    output, convergence = propagate_chunk(
        frame,
        policy,
        config["frame_policy"]["base"],
        normals,
    )
    tests.append(
        (
            "synthetic_propagation_finite",
            all(
                np.isfinite(output[f"{metric}__halfwidth"]).all()
                and output[f"{metric}__halfwidth"][0] >= 0.0
                for metric in METRIC_SPECS
            ),
        )
    )
    tests.append(
        (
            "synthetic_quantiles_ordered",
            all(
                output[f"{metric}__q16"][0]
                <= output[f"{metric}__q50"][0]
                <= output[f"{metric}__q84"][0]
                for metric in METRIC_SPECS
            ),
        )
    )
    tests.append(
        (
            "vrot_quantile_sign_identity",
            bool(
                np.allclose(
                    output["v_rot_gc_kms__q16"],
                    -output["v_phi_gc_kms__q84"],
                )
                and np.allclose(
                    output["v_rot_gc_kms__q84"],
                    -output["v_phi_gc_kms__q16"],
                )
            ),
        )
    )
    tests.append(
        (
            "diagnostic_probabilities_bounded",
            bool(
                0.0 <= output["mc_plausibility_fraction"][0] <= 1.0
                and 0.0 <= output["mc_prograde_probability"][0] <= 1.0
            ),
        )
    )
    tests.append(
        (
            "convergence_vectors_complete",
            len(convergence) == 2 * len(METRIC_SPECS)
            and all(len(values) == 1 for values in convergence.values()),
        )
    )
    mask = np.zeros(100, dtype=bool)
    mask[[1, 3, 10, 50, 99]] = True
    tests.append(
        (
            "deterministic_subset_preserves_primary_positions",
            bool(np.array_equal(deterministic_subset_positions(mask, 3), [1, 10, 99])),
        )
    )

    passed = sum(bool(value) for _, value in tests)
    for name, value in tests:
        if not value:
            print(f"FAIL: {name}")
    if len(tests) != 14:
        raise RuntimeError(f"Self-test definition error: tests={len(tests)}; expected 14")
    print(f"Stage 3C logic self-test passed: {passed}/{len(tests)}")
    return 0 if passed == len(tests) else 1


if __name__ == "__main__":
    raise SystemExit(main())
