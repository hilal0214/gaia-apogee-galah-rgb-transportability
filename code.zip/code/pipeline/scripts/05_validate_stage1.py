from __future__ import annotations

import argparse
import json
import sys

import pandas as pd

from stage1_common import (
    atomic_write_json,
    configured_paths,
    load_config,
    read_frame,
    read_json,
    setup_logger,
    table_suffix,
    utc_now,
)


def gate(name: str, passed: bool, observed, expected, detail: str) -> dict:
    return {
        "name": name,
        "passed": bool(passed),
        "observed": observed,
        "expected": expected,
        "detail": detail,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/stage1.yml")
    parser.add_argument("--level", choices=("census", "full"), default="full")
    args = parser.parse_args()

    config, root = load_config(args.config)
    paths = configured_paths(config, root)
    logger = setup_logger(
        paths["log_dir"] / "05_validate_stage1.log", "stage1.validate"
    )
    suffix = table_suffix(config)
    raw_manifest_path = paths["raw_dir"] / "raw_manifest.json"
    ingest_path = paths["output_dir"] / "catalogue_ingest_summary.json"
    identifier_audit_path = paths["output_dir"] / "gaia_identifier_audit.json"
    census_path = paths["output_dir"] / "stage1_census_summary.json"
    master_path = paths["output_dir"] / f"spectroscopic_source_master{suffix}"
    required = [
        raw_manifest_path,
        ingest_path,
        identifier_audit_path,
        census_path,
        master_path,
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing Stage 1 products:\n" + "\n".join(missing))

    raw = read_json(raw_manifest_path)
    ingest = read_json(ingest_path)
    identifier_audit = read_json(identifier_audit_path)
    census = read_json(census_path)
    master = read_frame(
        master_path,
        columns=[
            "gaia_dr3_source_id",
            "has_apogee",
            "has_galah",
            "survey_origin",
        ],
    )
    gates: list[dict] = []

    for survey in ("apogee", "galah"):
        expected_rows = int(config["catalogues"][survey]["expected_rows"])
        observed_rows = int(raw.get("files", {}).get(survey, {}).get("rows", -1))
        gates.append(
            gate(
                f"{survey}_raw_rows",
                observed_rows == expected_rows,
                observed_rows,
                expected_rows,
                "official FITS row count",
            )
        )
    concatenated = int(ingest["raw_catalogue_rows"]["concatenated_total"])
    expected_concat = sum(
        int(config["catalogues"][survey]["expected_rows"])
        for survey in ("apogee", "galah")
    )
    gates.append(
        gate(
            "raw_concatenated_accounting",
            concatenated == expected_concat,
            concatenated,
            expected_concat,
            "APOGEE rows plus GALAH rows before cross-survey collapse",
        )
    )
    gates.append(
        gate(
            "galah_flag_fe_h_not_used",
            ingest.get("galah_flag_fe_h_used") is False,
            ingest.get("galah_flag_fe_h_used"),
            False,
            "GALAH DR4 release caveat is honoured",
        )
    )
    gates.append(
        gate(
            "direct_gaia_identifier_audit_complete",
            identifier_audit.get("complete") is True,
            identifier_audit.get("complete"),
            True,
            "APOGEE EDR3 and GALAH DR3 identifiers audited before de-duplication",
        )
    )
    apogee_semantics = ingest.get("gaia_identifier_semantics", {}).get("apogee", {})
    gates.append(
        gate(
            "apogee_edr3_identifier_provenance",
            apogee_semantics.get("catalogue_column") == "GAIAEDR3_SOURCE_ID"
            and apogee_semantics.get("catalogue_release") == "Gaia EDR3",
            apogee_semantics,
            {
                "catalogue_column": "GAIAEDR3_SOURCE_ID",
                "catalogue_release": "Gaia EDR3",
            },
            "physical synspec_rev1 FITS identifier semantics",
        )
    )
    positive_ids = master["gaia_dr3_source_id"].gt(0)
    duplicate_ids = int(master.loc[positive_ids, "gaia_dr3_source_id"].duplicated().sum())
    gates.append(
        gate(
            "unique_positive_gaia_dr3_ids",
            positive_ids.all() and duplicate_ids == 0,
            {"positive": int(positive_ids.sum()), "duplicates": duplicate_ids},
            {"positive": len(master), "duplicates": 0},
            "source master identity invariant",
        )
    )
    origin_counts = master["survey_origin"].value_counts().to_dict()
    origin_sum = sum(
        int(origin_counts.get(origin, 0))
        for origin in ("APOGEE_only", "GALAH_only", "overlap")
    )
    gates.append(
        gate(
            "mutually_exclusive_union_accounting",
            origin_sum == len(master),
            origin_sum,
            len(master),
            "APOGEE-only + GALAH-only + overlap equals union",
        )
    )
    minimum_overlap = int(
        config["legacy_benchmarks"]["minimum_expected_overlap_for_audit"]
    )
    overlap = int(origin_counts.get("overlap", 0))
    gates.append(
        gate(
            "identifier_overlap_support",
            overlap >= minimum_overlap,
            overlap,
            f">={minimum_overlap}",
            (
                "identity-level overlap for the downstream calibration audit; "
                "this is not the element-specific calibration-ready sample"
            ),
        )
    )
    gaia_summary = None
    if args.level == "full":
        pilot_validation_path = paths["output_dir"] / "gaia_pilot_validation.json"
        if not pilot_validation_path.exists():
            gates.append(
                gate(
                    "gaia_pilot_validation_present",
                    False,
                    None,
                    True,
                    "run 05a, 05b, and 05c before the full Gaia query",
                )
            )
        else:
            pilot_validation = read_json(pilot_validation_path)
            gates.append(
                gate(
                    "gaia_pilot_validation_passed",
                    pilot_validation.get("overall_passed") is True,
                    pilot_validation.get("overall_passed"),
                    True,
                    "mandatory 20,000-source infrastructure pilot",
                )
            )
        gaia_path = paths["output_dir"] / "gaia_query_summary.json"
        if not gaia_path.exists():
            gates.append(
                gate(
                    "gaia_query_summary_present",
                    False,
                    None,
                    True,
                    "run 05_query_gaia_dr3.bat",
                )
            )
        else:
            gaia_summary = read_json(gaia_path)
            totals = gaia_summary["totals_for_completed_chunks"]
            gates.extend(
                [
                    gate(
                        "gaia_query_protocol",
                        gaia_summary.get("query_protocol_version")
                        == config["gaia"]["query_protocol_version"],
                        gaia_summary.get("query_protocol_version"),
                        config["gaia"]["query_protocol_version"],
                        "cache-safe Gaia query protocol",
                    ),
                    gate(
                        "gaia_chunks_complete",
                        gaia_summary.get("complete") is True,
                        gaia_summary.get("completed_chunks"),
                        gaia_summary.get("planned_chunks"),
                        "all planned Gaia chunks completed",
                    ),
                    gate(
                        "gaia_source_retrieval_complete",
                        int(totals["missing"]) == 0
                        and int(totals["unexpected"]) == 0
                        and int(totals["duplicate_rows"]) == 0
                        and int(totals["returned"]) == int(totals["requested"]),
                        totals,
                        {
                            "missing": 0,
                            "unexpected": 0,
                            "duplicate_rows": 0,
                            "returned_equals_requested": True,
                        },
                        "exact Gaia source identity recovery",
                    ),
                ]
            )

    overall = all(item["passed"] for item in gates)
    validation = {
        "stage": f"Stage 1 validation ({args.level})",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "overall_passed": overall,
        "gates": gates,
        "key_counts": census["mutually_exclusive_gaia_dr3_union"],
        "gaia_query": gaia_summary,
    }
    validation_path = paths["output_dir"] / "stage1_validation.json"
    atomic_write_json(validation, validation_path)

    lines = [
        "# Stage 1 validation report",
        "",
        f"- Protocol: `{config['project']['version']}`",
        f"- Level: `{args.level}`",
        f"- Overall passed: **{overall}**",
        "",
        "## Gates",
        "",
        "| Gate | Passed | Observed | Expected |",
        "|---|---:|---|---|",
    ]
    for item in gates:
        observed = json.dumps(item["observed"], sort_keys=True)
        expected = json.dumps(item["expected"], sort_keys=True)
        lines.append(
            f"| {item['name']} | {'yes' if item['passed'] else 'NO'} | "
            f"`{observed}` | `{expected}` |"
        )
    lines.extend(
        [
            "",
            "## Key census",
            "",
            f"- APOGEE-only: {origin_counts.get('APOGEE_only', 0):,}",
            f"- GALAH-only: {origin_counts.get('GALAH_only', 0):,}",
            f"- Overlap: {origin_counts.get('overlap', 0):,}",
            f"- Union: {len(master):,}",
            "",
        ]
    )
    report_path = paths["output_dir"] / "stage1_validation_report.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")
    logger.info("Validation passed=%s; report=%s", overall, report_path)
    return 0 if overall else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
