from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

from stage5b_common import atomic_write_json, load_config, project_path, read_json, sha256_file


def main() -> int:
    parser = argparse.ArgumentParser(description="Package Stage 5B outputs")
    parser.add_argument("--config", default="config/stage5b.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    outputs = config["outputs"]
    output_dir = project_path(root, config["paths"]["output_dir"])
    validation = read_json(output_dir / outputs["validation_file"])
    expected_gates = int(config["validation"]["expected_gates"])
    if not bool(validation.get("overall_passed")) or [
        int(validation.get("n_passed", -1)),
        int(validation.get("n_gates", -1)),
    ] != [expected_gates, expected_gates]:
        raise RuntimeError(
            f"Stage 5B validation is not {expected_gates}/{expected_gates} PASS; packaging is forbidden"
        )

    relative_files = [
        Path("34_fit_stage5b.bat"),
        Path("35_validate_stage5b.bat"),
        Path("36_package_stage5b.bat"),
        Path("99_stage5b_selftest.bat"),
        Path("run_stage5b_all.bat"),
        Path("STAGE5B_PROTOCOL.md"),
        Path("STAGE5B_README_UZ.md"),
        Path("STAGE5B_PATCH_MANIFEST.json"),
        Path("config/stage5b.yml"),
        Path("scripts/34_fit_stage5b.py"),
        Path("scripts/35_validate_stage5b.py"),
        Path("scripts/36_package_stage5b.py"),
        Path("scripts/selftest_stage5b.py"),
        Path("scripts/stage5b_common.py"),
        Path("logs/34_fit_stage5b.log"),
        Path("logs/35_validate_stage5b.log"),
    ]
    stage5a = config["stage5a_frozen"]
    relative_files.extend(
        Path("outputs/stage5a") / stage5a[key]
        for key in (
            "design_contract_file",
            "cohort_flow_file",
            "feature_scaling_file",
            "spatial_fold_map_file",
            "spatial_fold_summary_file",
            "survey_feature_balance_file",
            "feature_correlation_file",
            "leakage_audit_file",
            "build_summary_file",
            "freeze_manifest_file",
            "validation_file",
            "validation_report_file",
            "package_manifest_file",
        )
    )
    relative_files.extend(
        Path("outputs/stage5b") / outputs[key]
        for key in (
            "responsibility_layer_file",
            "model_parameters_file",
            "fit_diagnostics_file",
            "restart_audit_file",
            "responsibility_summary_file",
            "component_stability_file",
            "crossview_stability_file",
            "model_viability_file",
            "method_definition_file",
            "claim_ledger_file",
            "build_summary_file",
            "freeze_manifest_file",
            "validation_file",
            "validation_report_file",
        )
    )
    missing = [str(path) for path in relative_files if not (root / path).is_file()]
    if missing:
        raise FileNotFoundError("Missing Stage 5B package file: " + "; ".join(missing))

    manifest = {
        "package": outputs["package_name"].removesuffix(".zip"),
        "stage": "5B",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": str(config["project"]["frozen_created_utc"]),
        "files": [
            {
                "path": path.as_posix(),
                "bytes": int((root / path).stat().st_size),
                "sha256": sha256_file(root / path),
            }
            for path in relative_files
        ],
        "upstream": {
            "stage4a_release_name": config["stage4a_frozen"]["release_name"],
            "stage4a_release_sha256": config["stage4a_frozen"]["release_sha256"],
            "stage4a_design_layer_sha256": config["stage4a_frozen"]["design_layer_sha256"],
            "stage5a_release_name": stage5a["release_name"],
            "stage5a_release_sha256": stage5a["release_sha256"],
        },
        "excluded": [
            "official raw survey catalogues and Gaia query cache chunks",
            "the 184 MB Stage 4A design layer, referenced by exact release and file SHA-256",
            "semantic or calibrated Galactic memberships and hard population labels",
            "population-resolved abundance gradients and selection-function weights",
            "C/N, C, N, Al, and Ti population features",
        ],
        "science_boundary": config["science_boundary"],
    }
    manifest_path = output_dir / outputs["package_manifest_file"]
    atomic_write_json(manifest, manifest_path)
    package_files = [*relative_files, manifest_path.relative_to(root)]
    package_path = root / outputs["package_name"]
    temporary = package_path.with_name(f".{package_path.name}.tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(
        temporary,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
        allowZip64=True,
    ) as archive:
        for path in package_files:
            archive.write(root / path, arcname=path.as_posix())
    temporary.replace(package_path)
    with zipfile.ZipFile(package_path, mode="r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"Packaged ZIP failed integrity at {bad}")
    print(f"Output bundle created: {package_path}")
    print(f"SHA-256: {sha256_file(package_path)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
