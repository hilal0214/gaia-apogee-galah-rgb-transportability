from __future__ import annotations

import argparse
import math
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from gaia_query_logic import (
    DISTANCE_COLUMNS,
    GAIA_COLUMNS,
    exact_source_recovery,
    ids_sha256,
    query_signature,
    select_stratified_pilot,
    validate_distance_chunk,
    validate_source_chunk,
)
from stage1_common import (
    atomic_write_json,
    chunked,
    configured_paths,
    ensure_columns,
    gaia_upload_query,
    load_config,
    normalise_id_series,
    read_frame,
    read_json,
    setup_logger,
    table_suffix,
    utc_now,
    write_frame,
)


def source_query(table_name: str) -> str:
    fields = ",\n    ".join(f"g.{column} AS {column}" for column in GAIA_COLUMNS)
    return f"""
SELECT
    u.input_order AS input_order,
    {fields}
FROM tap_upload.ids AS u
JOIN {table_name} AS g
  ON u.source_id = g.source_id
"""


def distance_query(table_name: str) -> str:
    fields = ",\n    ".join(f"d.{column} AS {column}" for column in DISTANCE_COLUMNS)
    return f"""
SELECT
    u.input_order AS input_order,
    {fields}
FROM tap_upload.ids AS u
JOIN {table_name} AS d
  ON u.source_id = d.source_id
"""


def query_with_retries(
    ids: np.ndarray,
    query: str,
    upload_path: Path,
    max_retries: int,
    retry_base_seconds: int,
    logger,
    label: str,
) -> pd.DataFrame:
    errors: list[str] = []
    for attempt in range(1, max_retries + 1):
        try:
            return gaia_upload_query(ids, query, upload_path)
        except Exception as exc:
            message = (
                f"{label} attempt {attempt}/{max_retries}: "
                f"{type(exc).__name__}: {exc}"
            )
            errors.append(message)
            logger.warning(message)
            if attempt < max_retries:
                time.sleep(min(60, retry_base_seconds * 2 ** (attempt - 1)))
    raise RuntimeError(f"{label} query failed:\n" + "\n".join(errors))


def load_request_ids(config: dict, root: Path, paths: dict, mode: str):
    suffix = table_suffix(config)
    if mode == "full":
        ids_path = paths["output_dir"] / f"gaia_dr3_source_ids{suffix}"
        if not ids_path.exists():
            raise FileNotFoundError(f"Missing {ids_path}; build full census first.")
        ids_frame = read_frame(ids_path, columns=["gaia_dr3_source_id"])
        ids = np.sort(
            ids_frame.loc[
                ids_frame["gaia_dr3_source_id"].gt(0), "gaia_dr3_source_id"
            ]
            .drop_duplicates()
            .astype("int64")
            .to_numpy()
        )
        return ids, {
            "mode": "full",
            "selected_total": int(len(ids)),
            "selection_sha256": ids_sha256(ids),
            "selection_manifest": None,
        }

    master_path = paths["output_dir"] / f"spectroscopic_source_master{suffix}"
    if not master_path.exists():
        raise FileNotFoundError(f"Missing {master_path}; build full census first.")
    master = read_frame(
        master_path,
        columns=["gaia_dr3_source_id", "survey_origin"],
    )
    pilot_config = config["gaia"]["pilot"]
    quotas = {key: int(value) for key, value in pilot_config["strata"].items()}
    expected_size = int(pilot_config["size"])
    if sum(quotas.values()) != expected_size:
        raise ValueError(
            "Configured pilot strata do not sum to gaia.pilot.size: "
            f"{sum(quotas.values())} != {expected_size}"
        )
    selection, audit = select_stratified_pilot(
        master,
        quotas=quotas,
        seed=int(pilot_config["seed"]),
    )
    if len(selection) != expected_size:
        raise RuntimeError(
            f"Pilot selection size mismatch: {len(selection)} != {expected_size}"
        )
    selection_path = paths["output_dir"] / f"gaia_pilot_selection{suffix}"
    write_frame(selection, selection_path)
    manifest = {
        "stage": "1D-P deterministic Gaia/Bailer-Jones pilot selection",
        "census_protocol_version": config["project"]["version"],
        "query_protocol_version": config["gaia"]["query_protocol_version"],
        "created_utc": utc_now(),
        **audit,
        "selection_table": str(selection_path.relative_to(root)).replace("\\", "/"),
        "scientific_role": (
            "infrastructure and schema audit only; not a scientific subsample"
        ),
    }
    manifest_path = paths["output_dir"] / "gaia_pilot_selection_manifest.json"
    atomic_write_json(manifest, manifest_path)
    ids = selection["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
    return ids, {
        "mode": "pilot",
        "selected_total": int(len(ids)),
        "selection_sha256": audit["selection_sha256"],
        "selection_manifest": str(manifest_path.relative_to(root)).replace(
            "\\", "/"
        ),
        "selected_by_origin": audit["selected_by_origin"],
    }


def metadata_matches(
    metadata: dict,
    *,
    mode: str,
    chunk_index: int,
    chunk_ids: np.ndarray,
    selection_sha256: str,
    query_sha256: str,
) -> bool:
    return (
        metadata.get("mode") == mode
        and int(metadata.get("chunk_index", -1)) == chunk_index
        and int(metadata.get("requested_ids", -1)) == len(chunk_ids)
        and metadata.get("requested_ids_sha256") == ids_sha256(chunk_ids)
        and metadata.get("selection_sha256") == selection_sha256
        and metadata.get("query_signature_sha256") == query_sha256
    )


def require_exact_cached_source(
    frame: pd.DataFrame,
    requested: np.ndarray,
    label: str,
) -> dict[str, int]:
    ensure_columns(frame, ["input_order", *GAIA_COLUMNS], label)
    stats = validate_source_chunk(frame, requested)
    if not exact_source_recovery(stats):
        raise RuntimeError(
            f"{label} does not match the requested ID set: {stats}. "
            "Rerun this mode with --force to replace only its cache namespace."
        )
    input_order = pd.to_numeric(frame["input_order"], errors="coerce")
    if (
        input_order.isna().any()
        or input_order.duplicated().any()
        or set(input_order.astype(int)) != set(range(len(requested)))
    ):
        raise RuntimeError(f"{label} has an invalid input_order permutation")
    return stats


def require_valid_cached_distance(
    frame: pd.DataFrame,
    requested: np.ndarray,
    label: str,
) -> dict[str, int]:
    ensure_columns(frame, ["input_order", *DISTANCE_COLUMNS], label)
    stats = validate_distance_chunk(frame, requested)
    if int(stats["unexpected"]) or int(stats["duplicate_rows"]):
        raise RuntimeError(
            f"{label} does not match the requested ID set: {stats}. "
            "Rerun this mode with --force to replace only its cache namespace."
        )
    return stats


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/stage1.yml")
    parser.add_argument("--mode", choices=("pilot", "full"), default="full")
    parser.add_argument("--chunk-size", type=int)
    parser.add_argument("--max-chunks", type=int)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    config, root = load_config(args.config)
    paths = configured_paths(config, root)
    log_name = (
        "04_query_gaia_pilot.log"
        if args.mode == "pilot"
        else "04_query_gaia_dr3.log"
    )
    logger = setup_logger(paths["log_dir"] / log_name, f"stage1.gaia.{args.mode}")
    suffix = table_suffix(config)
    ids, selection_info = load_request_ids(config, root, paths, args.mode)
    if len(ids) == 0:
        raise RuntimeError("The requested Gaia ID set is empty")
    if args.mode == "pilot":
        default_chunk_size = int(config["gaia"]["pilot"]["chunk_size"])
    else:
        default_chunk_size = int(config["gaia"]["dr3_query_chunk_size"])
    chunk_size = int(args.chunk_size or default_chunk_size)
    if chunk_size <= 0:
        raise ValueError("Chunk size must be positive")
    total_chunks = int(math.ceil(len(ids) / chunk_size))
    selection_sha256 = str(selection_info["selection_sha256"])
    query_sha256 = query_signature(config)
    logger.info(
        "Mode=%s; querying %s unique Gaia DR3 sources in %d chunk(s)",
        args.mode,
        f"{len(ids):,}",
        total_chunks,
    )

    namespace = selection_sha256[:16]
    base_name = "gaia_dr3_pilot" if args.mode == "pilot" else "gaia_dr3"
    gaia_root = paths["interim_dir"] / base_name / namespace
    source_dir = gaia_root / "source"
    distance_dir = gaia_root / "distance"
    joined_dir = gaia_root / "joined"
    uploads_dir = gaia_root / "uploads"
    metadata_dir = gaia_root / "metadata"
    for directory in (source_dir, distance_dir, joined_dir, uploads_dir, metadata_dir):
        directory.mkdir(parents=True, exist_ok=True)

    max_retries = int(config["gaia"]["max_retries"])
    retry_base = int(config["gaia"]["retry_base_seconds"])
    chunks_considered = 0
    for chunk_index, chunk_ids in chunked(ids, chunk_size):
        if args.max_chunks is not None and chunks_considered >= args.max_chunks:
            logger.info("Stopped at --max-chunks=%d", args.max_chunks)
            break
        chunks_considered += 1
        stem = f"chunk_{chunk_index:05d}"
        source_path = source_dir / f"{stem}{suffix}"
        distance_path = distance_dir / f"{stem}{suffix}"
        joined_path = joined_dir / f"{stem}{suffix}"
        meta_path = metadata_dir / f"{stem}.json"
        upload_path = uploads_dir / f"{stem}.xml"
        if args.force:
            for path in (
                source_path,
                distance_path,
                joined_path,
                meta_path,
                upload_path,
            ):
                path.unlink(missing_ok=True)

        if joined_path.exists() and meta_path.exists():
            metadata = read_json(meta_path)
            if metadata_matches(
                metadata,
                mode=args.mode,
                chunk_index=chunk_index,
                chunk_ids=chunk_ids,
                selection_sha256=selection_sha256,
                query_sha256=query_sha256,
            ):
                cached_joined = read_frame(joined_path, columns=["source_id"])
                cached_stats = validate_source_chunk(cached_joined, chunk_ids)
                if exact_source_recovery(cached_stats):
                    logger.info("Skipping verified cached %s", stem)
                    continue
                raise RuntimeError(
                    f"Verified metadata but mismatched joined cache for {stem}: "
                    f"{cached_stats}. Rerun with --force."
                )
            raise RuntimeError(
                f"Stale cache metadata detected for {stem}. "
                "Rerun this mode with --force; the other mode is isolated."
            )

        if source_path.exists():
            source = read_frame(source_path)
            source_stats = require_exact_cached_source(
                source, chunk_ids, f"cached {stem} Gaia source"
            )
        else:
            logger.info("%s: querying Gaia DR3 source table", stem)
            source = query_with_retries(
                chunk_ids,
                source_query(config["gaia"]["source_table"]),
                upload_path,
                max_retries,
                retry_base,
                logger,
                f"{stem} gaia_source",
            )
            source_stats = require_exact_cached_source(
                source, chunk_ids, f"returned {stem} Gaia source"
            )
            write_frame(source, source_path)

        if distance_path.exists():
            distance = read_frame(distance_path)
            distance_stats = require_valid_cached_distance(
                distance, chunk_ids, f"cached {stem} distance"
            )
        else:
            logger.info("%s: querying Bailer-Jones distance table", stem)
            distance = query_with_retries(
                chunk_ids,
                distance_query(config["gaia"]["distance_table"]),
                upload_path,
                max_retries,
                retry_base,
                logger,
                f"{stem} distance",
            )
            distance_stats = require_valid_cached_distance(
                distance, chunk_ids, f"returned {stem} distance"
            )
            write_frame(distance, distance_path)

        source = source.copy()
        distance = distance.copy()
        source["source_id"] = normalise_id_series(source["source_id"])
        distance["source_id"] = normalise_id_series(distance["source_id"])
        distance = distance.drop(columns=["input_order"], errors="ignore")
        joined = source.merge(
            distance,
            on="source_id",
            how="left",
            validate="one_to_one",
            suffixes=("", "_distance"),
        )
        joined_stats = validate_source_chunk(joined, chunk_ids)
        if not exact_source_recovery(joined_stats):
            raise RuntimeError(f"{stem} joined identity mismatch: {joined_stats}")
        write_frame(joined, joined_path)

        non_null_counts = {
            column: int(joined[column].notna().sum())
            for column in joined.columns
            if column != "input_order"
        }
        distance_available = int(joined["r_med_geo"].notna().sum())
        photogeometric_available = int(joined["r_med_photogeo"].notna().sum())
        metadata = {
            "mode": args.mode,
            "query_protocol_version": config["gaia"]["query_protocol_version"],
            "chunk_index": chunk_index,
            "requested_ids": int(len(chunk_ids)),
            "requested_ids_sha256": ids_sha256(chunk_ids),
            "selection_sha256": selection_sha256,
            "query_signature_sha256": query_sha256,
            "first_requested_id": int(chunk_ids[0]),
            "last_requested_id": int(chunk_ids[-1]),
            "source_stats": source_stats,
            "distance_stats": distance_stats,
            "joined_stats": joined_stats,
            "geometric_distance_available": distance_available,
            "photogeometric_distance_available": photogeometric_available,
            "column_non_null_counts": non_null_counts,
            "created_utc": utc_now(),
        }
        atomic_write_json(metadata, meta_path)
        upload_path.unlink(missing_ok=True)
        logger.info(
            "%s complete: %s/%s Gaia rows; %s geometric; %s photogeometric",
            stem,
            f"{source_stats['returned']:,}",
            f"{source_stats['requested']:,}",
            f"{distance_available:,}",
            f"{photogeometric_available:,}",
        )

    completed_indices: list[int] = []
    totals = {
        "requested": 0,
        "returned": 0,
        "missing": 0,
        "unexpected": 0,
        "duplicate_rows": 0,
        "distance_rows": 0,
        "not_in_distance_table": 0,
        "distance_unexpected": 0,
        "distance_duplicate_rows": 0,
        "geometric_distance_available": 0,
        "photogeometric_distance_available": 0,
    }
    column_non_null_totals: dict[str, int] = {}
    for chunk_index, chunk_ids in chunked(ids, chunk_size):
        meta_path = metadata_dir / f"chunk_{chunk_index:05d}.json"
        joined_path = joined_dir / f"chunk_{chunk_index:05d}{suffix}"
        if not meta_path.exists() or not joined_path.exists():
            continue
        item = read_json(meta_path)
        if not metadata_matches(
            item,
            mode=args.mode,
            chunk_index=chunk_index,
            chunk_ids=chunk_ids,
            selection_sha256=selection_sha256,
            query_sha256=query_sha256,
        ):
            continue
        completed_indices.append(chunk_index)
        source_stats = item["source_stats"]
        distance_stats = item["distance_stats"]
        for key in ("requested", "returned", "missing", "unexpected", "duplicate_rows"):
            totals[key] += int(source_stats[key])
        totals["distance_rows"] += int(distance_stats["returned"])
        totals["not_in_distance_table"] += int(
            distance_stats["not_in_distance_table"]
        )
        totals["distance_unexpected"] += int(distance_stats["unexpected"])
        totals["distance_duplicate_rows"] += int(
            distance_stats["duplicate_rows"]
        )
        totals["geometric_distance_available"] += int(
            item["geometric_distance_available"]
        )
        totals["photogeometric_distance_available"] += int(
            item["photogeometric_distance_available"]
        )
        for column, count in item["column_non_null_counts"].items():
            column_non_null_totals[column] = column_non_null_totals.get(column, 0) + int(
                count
            )

    complete = completed_indices == list(range(total_chunks))
    summary_name = (
        "gaia_pilot_query_summary.json"
        if args.mode == "pilot"
        else "gaia_query_summary.json"
    )
    summary = {
        "stage": (
            "1D-P Gaia DR3 and distance pilot retrieval"
            if args.mode == "pilot"
            else "1D Gaia DR3 and distance full retrieval"
        ),
        "mode": args.mode,
        "census_protocol_version": config["project"]["version"],
        "query_protocol_version": config["gaia"]["query_protocol_version"],
        "updated_utc": utc_now(),
        "unique_requested_ids": int(len(ids)),
        "selection_sha256": selection_sha256,
        "selection_info": selection_info,
        "query_signature_sha256": query_sha256,
        "chunk_size": chunk_size,
        "planned_chunks": total_chunks,
        "completed_chunks": len(completed_indices),
        "completed_chunk_indices": completed_indices,
        "complete": complete,
        "totals_for_completed_chunks": totals,
        "column_non_null_totals": column_non_null_totals,
        "source_table": config["gaia"]["source_table"],
        "distance_table": config["gaia"]["distance_table"],
        "cache_namespace": str(gaia_root.relative_to(root)).replace("\\", "/"),
    }
    atomic_write_json(summary, paths["output_dir"] / summary_name)
    if not complete:
        logger.warning(
            "%s Gaia query is partial: %d/%d chunks",
            args.mode,
            len(completed_indices),
            total_chunks,
        )
        return 2
    logger.info("All %s Gaia query chunks complete.", args.mode)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted; completed chunks were retained.", file=sys.stderr)
        raise SystemExit(130)
