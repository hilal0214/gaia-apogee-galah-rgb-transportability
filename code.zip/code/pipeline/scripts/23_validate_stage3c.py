from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from stage3c_common import (
    LABELS,
    METRIC_SPECS,
    STAGE3A_COLUMNS,
    STAGE3B_COLUMNS,
    array_sha256,
    atomic_write_json,
    canonical_json_sha256,
    central_transform,
    close_logger,
    deterministic_subset_positions,
    fixed_antithetic_normals,
    flag,
    frame_stress,
    ids_sha256,
    load_config,
    max_abs,
    method_definition,
    metric_decimals,
    number,
    project_path,
    propagate_chunk,
    read_json,
    setup_logger,
    sha256_file,
    utc_now,
)


def add_gate(
    gates: list[dict[str, Any]],
    name: str,
    passed: bool,
    observed: Any,
    expected: Any,
    detail: str,
) -> None:
    gates.append(
        {
            "name": name,
            "passed": bool(passed),
            "observed": observed,
            "expected": expected,
            "detail": detail,
        }
    )


def frame_close(left: pd.DataFrame, right: pd.DataFrame, atol: float) -> bool:
    if list(left.columns) != list(right.columns) or left.shape != right.shape:
        return False
    for column in left.columns:
        if pd.api.types.is_numeric_dtype(left[column]):
            if not np.allclose(
                pd.to_numeric(left[column], errors="coerce").to_numpy(float),
                pd.to_numeric(right[column], errors="coerce").to_numpy(float),
                rtol=0.0,
                atol=atol,
                equal_nan=True,
            ):
                return False
        elif not left[column].astype("string").fillna("<NA>").equals(
            right[column].astype("string").fillna("<NA>")
        ):
            return False
    return True


def recompute_uncertainty_summary(
    layer: pd.DataFrame, stage3b: pd.DataFrame, primary: np.ndarray
) -> pd.DataFrame:
    rows = []
    for metric in METRIC_SPECS:
        half_width = number(layer, f"{metric}__halfwidth")[primary]
        median_bias = number(layer, f"{metric}__q50")[primary] - number(
            stage3b, metric
        )[primary]
        rows.append(
            {
                "quantity": metric,
                "rows": int(len(half_width)),
                "halfwidth_median": float(np.quantile(half_width, 0.50)),
                "halfwidth_q84": float(np.quantile(half_width, 0.84)),
                "halfwidth_q95": float(np.quantile(half_width, 0.95)),
                "halfwidth_q99": float(np.quantile(half_width, 0.99)),
                "median_bias_median": float(np.quantile(median_bias, 0.50)),
                "absolute_median_bias_q95": float(
                    np.quantile(np.abs(median_bias), 0.95)
                ),
            }
        )
    return pd.DataFrame(rows)


def validation_report(payload: dict[str, Any]) -> str:
    lines = [
        "# Stage 3C validation report",
        "",
        f"Overall passed: **{payload['overall_passed']}**",
        "",
        f"Gates: **{payload['n_passed']}/{payload['n_gates']}**",
        "",
        "| Gate | Result | Detail |",
        "|---|---:|---|",
    ]
    for gate in payload["gates"]:
        lines.append(
            f"| `{gate['name']}` | {'PASS' if gate['passed'] else 'FAIL'} | "
            f"{gate['detail'].replace('|', '/')} |"
        )
    lines.extend(
        [
            "",
            "Stage 3C propagates formal random phase-space uncertainty and records "
            "distance/frame stress. It creates no new science-sample gate and does not "
            "fit gradients, orbits, or populations.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Stage 3C uncertainty layer")
    parser.add_argument("--config", default="config/stage3c.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    stage3a_dir = project_path(root, config["paths"]["stage3a_output_dir"])
    stage3b_dir = project_path(root, config["paths"]["stage3b_output_dir"])
    output_dir = project_path(root, config["paths"]["output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "23_validate_stage3c.log", "stage3c.validate")
    a_frozen = config["stage3a_frozen"]
    b_frozen = config["stage3b_frozen"]
    outputs = config["outputs"]
    paths = {
        "stage3a_quality": stage3a_dir / a_frozen["quality_layer_file"],
        "stage3b_phase": stage3b_dir / b_frozen["phase_space_layer_file"],
        "stage3b_summary": stage3b_dir / b_frozen["build_summary_file"],
        "stage3b_freeze": stage3b_dir / b_frozen["freeze_manifest_file"],
        "stage3b_validation": stage3b_dir / b_frozen["validation_file"],
        "stage3b_report": stage3b_dir / b_frozen["validation_report_file"],
        "stage3b_frame": stage3b_dir / b_frozen["frame_definition_file"],
        "stage3b_package_manifest": stage3b_dir / b_frozen["package_manifest_file"],
        "layer": output_dir / outputs["uncertainty_layer_file"],
        "uncertainty_summary": output_dir / outputs["uncertainty_summary_file"],
        "convergence": output_dir / outputs["convergence_file"],
        "frame_stress": output_dir / outputs["frame_stress_file"],
        "estimator_stress": output_dir / outputs["estimator_stress_file"],
        "label_flow": output_dir / outputs["label_flow_file"],
        "method": output_dir / outputs["method_definition_file"],
        "summary": output_dir / outputs["build_summary_file"],
        "freeze": output_dir / outputs["freeze_manifest_file"],
    }
    missing = [str(path) for path in paths.values() if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing Stage 3C validation inputs: " + "; ".join(missing))
    gates: list[dict[str, Any]] = []
    tolerance = float(config["validation"]["numeric_absolute_tolerance"])

    upstream_expected = {
        "stage3a_quality_layer": a_frozen["quality_layer_sha256"],
        "stage3b_phase_space_layer": b_frozen["phase_space_layer_sha256"],
        "stage3b_build_summary": b_frozen["build_summary_sha256"],
        "stage3b_freeze_manifest": b_frozen["freeze_manifest_sha256"],
        "stage3b_validation": b_frozen["validation_sha256"],
        "stage3b_validation_report": b_frozen["validation_report_sha256"],
        "stage3b_frame_definition": b_frozen["frame_definition_sha256"],
        "stage3b_package_manifest": b_frozen["package_manifest_sha256"],
    }
    upstream_observed = {
        key: sha256_file(paths[key.replace("_layer", "")] if key == "stage3a_quality_layer" else {
            "stage3b_phase_space_layer": paths["stage3b_phase"],
            "stage3b_build_summary": paths["stage3b_summary"],
            "stage3b_freeze_manifest": paths["stage3b_freeze"],
            "stage3b_validation": paths["stage3b_validation"],
            "stage3b_validation_report": paths["stage3b_report"],
            "stage3b_frame_definition": paths["stage3b_frame"],
            "stage3b_package_manifest": paths["stage3b_package_manifest"],
        }[key])
        for key in upstream_expected
    }
    add_gate(
        gates,
        "upstream_byte_identity",
        upstream_observed == upstream_expected,
        upstream_observed,
        upstream_expected,
        "the accepted Stage 3A covariance and Stage 3B products are byte-identical",
    )

    stage3b_validation = read_json(paths["stage3b_validation"])
    upstream_pass = {
        "overall_passed": bool(stage3b_validation.get("overall_passed", False)),
        "n_passed": int(stage3b_validation.get("n_passed", -1)),
        "n_gates": int(stage3b_validation.get("n_gates", -1)),
    }
    upstream_pass_expected = {
        "overall_passed": True,
        "n_passed": int(b_frozen["expected_validation_gates"]),
        "n_gates": int(b_frozen["expected_validation_gates"]),
    }
    add_gate(
        gates,
        "upstream_validation",
        upstream_pass == upstream_pass_expected,
        upstream_pass,
        upstream_pass_expected,
        "Stage 3B remains frozen PASS",
    )

    stage3a_meta = pq.ParquetFile(paths["stage3a_quality"])
    stage3b_meta = pq.ParquetFile(paths["stage3b_phase"])
    stage3a = pd.read_parquet(paths["stage3a_quality"], columns=list(STAGE3A_COLUMNS))
    stage3b = pd.read_parquet(paths["stage3b_phase"], columns=list(STAGE3B_COLUMNS))
    ids_a = stage3a["gaia_dr3_source_id"].to_numpy(np.int64)
    ids_b = stage3b["gaia_dr3_source_id"].to_numpy(np.int64)
    input_observed = {
        "rows": int(len(ids_a)),
        "stage3a_columns": int(stage3a_meta.metadata.num_columns),
        "stage3b_columns": int(stage3b_meta.metadata.num_columns),
        "ids_equal": bool(np.array_equal(ids_a, ids_b)),
        "strictly_increasing": bool(np.all(np.diff(ids_a) > 0)),
        "duplicates": int(pd.Series(ids_a).duplicated().sum()),
        "candidate_id_sha256": ids_sha256(ids_a),
    }
    input_expected = {
        "rows": int(b_frozen["expected_rows"]),
        "stage3a_columns": int(a_frozen["expected_columns"]),
        "stage3b_columns": int(b_frozen["expected_columns"]),
        "ids_equal": True,
        "strictly_increasing": True,
        "duplicates": 0,
        "candidate_id_sha256": b_frozen["expected_candidate_id_sha256"],
    }
    add_gate(
        gates,
        "input_identity",
        input_observed == input_expected,
        input_observed,
        input_expected,
        "the complete frozen candidate vector and both schemas are preserved",
    )

    layer_meta = pq.ParquetFile(paths["layer"])
    layer = pd.read_parquet(paths["layer"])
    output_ids = layer["gaia_dr3_source_id"].to_numpy(np.int64)
    output_identity = {
        "rows": int(len(layer)),
        "columns": int(layer_meta.metadata.num_columns),
        "ids_equal_input": bool(np.array_equal(output_ids, ids_a)),
        "strictly_increasing": bool(np.all(np.diff(output_ids) > 0)),
        "candidate_id_sha256": ids_sha256(output_ids),
    }
    summary = read_json(paths["summary"])
    output_expected = {
        "rows": int(b_frozen["expected_rows"]),
        "columns": int(summary["counts"]["columns"]),
        "ids_equal_input": True,
        "strictly_increasing": True,
        "candidate_id_sha256": b_frozen["expected_candidate_id_sha256"],
    }
    add_gate(
        gates,
        "output_identity",
        output_identity == output_expected,
        output_identity,
        output_expected,
        "Stage 3C is a one-to-one augmentation of the Stage 3B candidate layer",
    )

    primary = flag(stage3b, "phase_space_6d_primary_ok")
    propagated = flag(layer, "uncertainty_propagation_ok")
    coverage = {
        "stage3b_primary": int(primary.sum()),
        "propagated": int(propagated.sum()),
        "set_equal": bool(np.array_equal(primary, propagated)),
        "status_propagated": int((layer["uncertainty_status"] == "PROPAGATED").sum()),
        "draws_exact": bool(
            np.all(number(layer, "mc_draws")[primary] == config["uncertainty_policy"]["draws"])
        ),
    }
    coverage_expected = {
        "stage3b_primary": int(b_frozen["expected_primary_6d"]),
        "propagated": int(b_frozen["expected_primary_6d"]),
        "set_equal": True,
        "status_propagated": int(b_frozen["expected_primary_6d"]),
        "draws_exact": True,
    }
    add_gate(
        gates,
        "exact_primary_coverage",
        coverage == coverage_expected,
        coverage,
        coverage_expected,
        "formal uncertainty covers exactly the frozen primary 6D set",
    )

    expected_method = method_definition(config)
    observed_method = read_json(paths["method"])
    normals = fixed_antithetic_normals(config["uncertainty_policy"])
    method_checks = {
        "definition_exact": observed_method == expected_method,
        "ensemble_sha256": array_sha256(normals),
        "uncertainty_policy_sha256": canonical_json_sha256(
            config["uncertainty_policy"]
        ),
        "frame_policy_sha256": canonical_json_sha256(config["frame_policy"]),
    }
    method_expected = {
        "definition_exact": True,
        "ensemble_sha256": observed_method["ensemble"][
            "sha256_little_endian_float64"
        ],
        "uncertainty_policy_sha256": summary["uncertainty_policy_sha256"],
        "frame_policy_sha256": summary["frame_policy_sha256"],
    }
    add_gate(
        gates,
        "method_and_ensemble_freeze",
        method_checks == method_expected,
        method_checks,
        method_expected,
        "the MC ensemble, approximation, frame variants, and runtime are explicit",
    )

    distance_ok = valid = (
        np.isfinite(number(stage3a, "distance_primary_lo_pc"))
        & np.isfinite(number(stage3a, "distance_primary_pc"))
        & np.isfinite(number(stage3a, "distance_primary_hi_pc"))
        & (number(stage3a, "distance_primary_lo_pc") > 0.0)
        & (number(stage3a, "distance_primary_lo_pc") <= number(stage3a, "distance_primary_pc"))
        & (number(stage3a, "distance_primary_pc") <= number(stage3a, "distance_primary_hi_pc"))
    )
    rv_error = number(stage3a, "analysis_rv_error_kms")
    input_validity = {
        "distance_valid_primary": int(np.count_nonzero(primary & distance_ok)),
        "rv_error_valid_primary": int(
            np.count_nonzero(primary & np.isfinite(rv_error) & (rv_error > 0.0))
        ),
        "covariance_psd_output": int(
            np.count_nonzero(primary & flag(layer, "covariance_psd_ok"))
        ),
        "minimum_covariance_eigenvalue": float(
            np.nanmin(number(layer, "covariance_min_eigenvalue")[primary])
        ),
        "covariance_repairs": int(flag(layer, "covariance_repaired").sum()),
    }
    input_validity_expected = {
        "distance_valid_primary": int(primary.sum()),
        "rv_error_valid_primary": int(primary.sum()),
        "covariance_psd_output": int(primary.sum()),
        "minimum_covariance_eigenvalue": summary["diagnostics"][
            "minimum_covariance_eigenvalue"
        ],
        "covariance_repairs": 0,
    }
    add_gate(
        gates,
        "measurement_input_validity",
        input_validity == input_validity_expected
        and input_validity["minimum_covariance_eigenvalue"] > 0.0,
        input_validity,
        input_validity_expected,
        "all primary distance/RV/covariance inputs are valid and no covariance is repaired",
    )

    quantile_violations = 0
    nonfinite = 0
    for metric in METRIC_SPECS:
        q16 = number(layer, f"{metric}__q16")[primary]
        q50 = number(layer, f"{metric}__q50")[primary]
        q84 = number(layer, f"{metric}__q84")[primary]
        half = number(layer, f"{metric}__halfwidth")[primary]
        nonfinite += int(
            np.count_nonzero(~(np.isfinite(q16) & np.isfinite(q50) & np.isfinite(q84) & np.isfinite(half)))
        )
        quantile_violations += int(np.count_nonzero((q16 > q50) | (q50 > q84) | (half < 0.0)))
    add_gate(
        gates,
        "quantile_order_and_finiteness",
        nonfinite == 0 and quantile_violations == 0,
        {"nonfinite": nonfinite, "ordering_violations": quantile_violations},
        {"nonfinite": 0, "ordering_violations": 0},
        "all eight primary uncertainty summaries are finite and ordered",
    )

    sign_checks = {
        "q16_vrot_plus_q84_vphi_max_abs": max_abs(
            number(layer, "v_rot_gc_kms__q16")[primary]
            + number(layer, "v_phi_gc_kms__q84")[primary]
        ),
        "q50_vrot_plus_q50_vphi_max_abs": max_abs(
            number(layer, "v_rot_gc_kms__q50")[primary]
            + number(layer, "v_phi_gc_kms__q50")[primary]
        ),
        "q84_vrot_plus_q16_vphi_max_abs": max_abs(
            number(layer, "v_rot_gc_kms__q84")[primary]
            + number(layer, "v_phi_gc_kms__q16")[primary]
        ),
        "halfwidth_max_abs_difference": max_abs(
            number(layer, "v_rot_gc_kms__halfwidth")[primary]
            - number(layer, "v_phi_gc_kms__halfwidth")[primary]
        ),
    }
    add_gate(
        gates,
        "rotation_sign_quantiles",
        max(sign_checks.values()) <= tolerance,
        sign_checks,
        {"maximum_allowed_absolute_difference": tolerance},
        "the manuscript v_rot=-v_phi convention remains exact under propagation",
    )

    plausibility = number(layer, "mc_plausibility_fraction")[primary]
    plausibility_checks = {
        "minimum": float(np.min(plausibility)),
        "maximum": float(np.max(plausibility)),
        "out_of_range": int(np.count_nonzero((plausibility < 0.0) | (plausibility > 1.0))),
        "new_primary_gate_created": bool(
            config["uncertainty_policy"]["plausibility_diagnostic"][
                "creates_new_primary_gate"
            ]
        ),
    }
    add_gate(
        gates,
        "plausibility_is_diagnostic_only",
        plausibility_checks["out_of_range"] == 0
        and not plausibility_checks["new_primary_gate_created"],
        plausibility_checks,
        {"out_of_range": 0, "new_primary_gate_created": False},
        "MC plausibility fractions are valid and do not redefine the sample",
    )

    observed_uncertainty_summary = pd.read_csv(paths["uncertainty_summary"])
    expected_uncertainty_summary = recompute_uncertainty_summary(layer, stage3b, primary)
    uncertainty_summary_ok = frame_close(
        observed_uncertainty_summary, expected_uncertainty_summary, atol=5.0e-6
    )
    add_gate(
        gates,
        "uncertainty_summary_recomputation",
        uncertainty_summary_ok,
        {"exact_within_tolerance": uncertainty_summary_ok, "rows": len(observed_uncertainty_summary)},
        {"exact_within_tolerance": True, "rows": len(METRIC_SPECS)},
        "aggregate half-width and median-bias summaries recompute from the star layer",
    )

    convergence = pd.read_csv(paths["convergence"])
    limits = config["validation"]["convergence_limits"]
    convergence_checks = {
        "rows": int(len(convergence)),
        "maximum_median_relative_halfwidth_difference": float(
            convergence["relative_halfwidth_difference_median"].max()
        ),
        "maximum_q95_relative_halfwidth_difference": float(
            convergence["relative_halfwidth_difference_q95"].max()
        ),
    }
    convergence_pass = (
        convergence_checks["rows"] == len(METRIC_SPECS)
        and convergence_checks["maximum_median_relative_halfwidth_difference"]
        <= float(limits["median_relative_halfwidth_difference_max"])
        and convergence_checks["maximum_q95_relative_halfwidth_difference"]
        <= float(limits["p95_relative_halfwidth_difference_max"])
    )
    add_gate(
        gates,
        "mc_64_to_128_convergence",
        convergence_pass,
        convergence_checks,
        {
            "rows": len(METRIC_SPECS),
            "maximum_median_relative_halfwidth_difference": limits[
                "median_relative_halfwidth_difference_max"
            ],
            "maximum_q95_relative_halfwidth_difference": limits[
                "p95_relative_halfwidth_difference_max"
            ],
        },
        "nested antithetic 64-draw summaries converge to the frozen 128-draw summaries",
    )

    subset_positions = deterministic_subset_positions(
        primary, int(config["validation"]["audit_subset_rows"])
    )
    subset_input = stage3a.iloc[subset_positions].reset_index(drop=True)
    subset_output, _ = propagate_chunk(
        subset_input,
        config["uncertainty_policy"],
        config["frame_policy"]["base"],
        normals,
    )
    subset_differences: dict[str, float] = {}
    for metric in METRIC_SPECS:
        decimals = metric_decimals(metric, config["uncertainty_policy"])
        for suffix in ("q16", "q50", "q84", "halfwidth"):
            expected = np.round(subset_output[f"{metric}__{suffix}"], decimals=decimals)
            observed = number(layer.iloc[subset_positions], f"{metric}__{suffix}")
            subset_differences[f"{metric}__{suffix}"] = max_abs(observed - expected)
    subset_differences["covariance_min_eigenvalue"] = max_abs(
        number(layer.iloc[subset_positions], "covariance_min_eigenvalue")
        - np.round(subset_output["covariance_min_eigenvalue"], decimals=10)
    )
    subset_differences["mc_plausibility_fraction"] = max_abs(
        number(layer.iloc[subset_positions], "mc_plausibility_fraction")
        - np.round(
            subset_output["mc_plausibility_fraction"],
            decimals=int(config["uncertainty_policy"]["output_rounding"]["probability_decimals"]),
        )
    )
    subset_differences["mc_prograde_probability"] = max_abs(
        number(layer.iloc[subset_positions], "mc_prograde_probability")
        - np.round(
            subset_output["mc_prograde_probability"],
            decimals=int(config["uncertainty_policy"]["output_rounding"]["probability_decimals"]),
        )
    )
    subset_max = max(subset_differences.values())
    add_gate(
        gates,
        "deterministic_mc_subset_recomputation",
        subset_max <= tolerance,
        {"rows": len(subset_positions), "maximum_absolute_difference": subset_max},
        {"rows": int(config["validation"]["audit_subset_rows"]), "maximum_absolute_difference": tolerance},
        "a source-ID-deterministic primary subset independently reproduces every MC output",
    )

    subset_b = stage3b.iloc[subset_positions].reset_index(drop=True)
    base_subset = central_transform(subset_input, config["frame_policy"]["base"])
    base_diffs = {
        metric: max_abs(base_subset[metric] - number(subset_b, metric))
        for metric in METRIC_SPECS
    }
    add_gate(
        gates,
        "base_frame_subset_recomputation",
        max(base_diffs.values()) <= tolerance,
        base_diffs,
        {"maximum_allowed_absolute_difference": tolerance},
        "the frozen Stage 3B nominal frame recomputes before any frame stress",
    )

    _, subset_envelopes, subset_sign_stable, _ = frame_stress(
        subset_input, subset_b, config["frame_policy"]
    )
    frame_diffs = {}
    for metric in METRIC_SPECS:
        observed = number(
            layer.iloc[subset_positions], f"{metric}__frame_abs_envelope"
        )
        expected = np.round(
            subset_envelopes[metric],
            decimals=metric_decimals(metric, config["uncertainty_policy"]),
        )
        frame_diffs[metric] = max_abs(observed - expected)
    frame_sign_equal = bool(
        np.array_equal(
            flag(layer.iloc[subset_positions], "frame_vrot_sign_stable"),
            subset_sign_stable,
        )
    )
    frame_table = pd.read_csv(paths["frame_stress"])
    expected_frame_rows = len(config["frame_policy"]["variants"]) * len(METRIC_SPECS)
    frame_checks = {
        "summary_rows": int(len(frame_table)),
        "subset_max_abs_difference": max(frame_diffs.values()),
        "subset_sign_equal": frame_sign_equal,
    }
    add_gate(
        gates,
        "frame_stress_recomputation",
        frame_checks["summary_rows"] == expected_frame_rows
        and frame_checks["subset_max_abs_difference"] <= tolerance
        and frame_checks["subset_sign_equal"],
        frame_checks,
        {
            "summary_rows": expected_frame_rows,
            "subset_max_abs_difference": tolerance,
            "subset_sign_equal": True,
        },
        "all six explicit frame variants and per-star envelopes reproduce on the audit subset",
    )

    paired = primary & flag(stage3b, "phase_space_6d_geo_alternative_ok")
    estimator_differences = {}
    for metric in METRIC_SPECS:
        expected_delta = number(stage3b, f"{metric}_geo_alt")[paired] - number(
            stage3b, metric
        )[paired]
        observed_delta = number(layer, f"{metric}__geo_minus_photo")[paired]
        estimator_differences[metric] = max_abs(
            observed_delta
            - np.round(
                expected_delta,
                decimals=metric_decimals(metric, config["uncertainty_policy"]),
            )
        )
    estimator_table = pd.read_csv(paths["estimator_stress"])
    estimator_checks = {
        "paired_rows": int(paired.sum()),
        "summary_rows": int(len(estimator_table)),
        "maximum_delta_difference": max(estimator_differences.values()),
    }
    add_gate(
        gates,
        "distance_estimator_stress_recomputation",
        estimator_checks["paired_rows"] == int(summary["counts"]["geo_estimator_paired_primary"])
        and estimator_checks["summary_rows"] == len(METRIC_SPECS)
        and estimator_checks["maximum_delta_difference"] <= tolerance,
        estimator_checks,
        {
            "paired_rows": int(summary["counts"]["geo_estimator_paired_primary"]),
            "summary_rows": len(METRIC_SPECS),
            "maximum_delta_difference": tolerance,
        },
        "geometric-minus-photogeometric shifts reproduce for every paired primary star",
    )

    observed_label_flow = pd.read_csv(paths["label_flow"])
    expected_label_rows = []
    for label in LABELS:
        selected = flag(stage3b, f"{label}_phase_space_primary_ok")
        expected_label_rows.append(
            {
                "label": label,
                "stage3b_primary_rows": int(selected.sum()),
                "stage3c_propagated_rows": int(np.count_nonzero(selected & propagated)),
                "lost_rows": int(np.count_nonzero(selected & ~propagated)),
            }
        )
    expected_label_flow = pd.DataFrame(expected_label_rows)
    label_equal = observed_label_flow.equals(expected_label_flow)
    add_gate(
        gates,
        "label_specific_coverage",
        label_equal and int(observed_label_flow["lost_rows"].sum()) == 0,
        {
            "exact_table": label_equal,
            "labels": int(len(observed_label_flow)),
            "lost_rows": int(observed_label_flow["lost_rows"].sum()),
        },
        {"exact_table": True, "labels": len(LABELS), "lost_rows": 0},
        "all six frozen abundance-label primary sets retain uncertainty summaries",
    )

    summary_counts = {
        "rows": int(len(layer)),
        "columns": int(len(layer.columns)),
        "stage3b_primary_6d": int(primary.sum()),
        "uncertainty_propagated": int(propagated.sum()),
        "covariance_repairs": int(flag(layer, "covariance_repaired").sum()),
        "geo_estimator_paired_primary": int(flag(layer, "geo_estimator_paired").sum()),
        "frame_vrot_sign_stable": int(
            np.count_nonzero(primary & flag(layer, "frame_vrot_sign_stable"))
        ),
    }
    add_gate(
        gates,
        "summary_count_recomputation",
        summary_counts == summary["counts"],
        summary_counts,
        summary["counts"],
        "all Stage 3C headline counts recompute from the star-level product",
    )

    freeze = read_json(paths["freeze"])
    hash_paths = [
        paths["layer"],
        paths["uncertainty_summary"],
        paths["convergence"],
        paths["frame_stress"],
        paths["estimator_stress"],
        paths["label_flow"],
        paths["method"],
        paths["summary"],
    ]
    observed_hashes = {path.name: sha256_file(path) for path in hash_paths}
    expected_hashes = freeze["output_sha256"]
    add_gate(
        gates,
        "output_hash_freeze",
        observed_hashes == expected_hashes,
        observed_hashes,
        expected_hashes,
        "every Stage 3C science output and build summary is byte-frozen",
    )

    forbidden_tokens = {"orbit", "orbits", "action", "actions", "gradient", "gradients", "population", "populations", "escape"}
    forbidden_columns = [
        column
        for column in layer.columns
        if forbidden_tokens.intersection(column.lower().split("_"))
    ]
    boundary = config["science_boundary"]
    boundary_checks = {
        "summary_exact": summary["science_boundary"] == boundary,
        "freeze_exact": freeze["science_boundary"] == boundary,
        "forbidden_columns": forbidden_columns,
        "new_primary_gate_created": bool(boundary["new_science_sample_gate_created"]),
        "gradients_fitted": bool(boundary["galactic_gradients_fitted"]),
        "populations_fitted": bool(boundary["population_model_fitted"]),
        "orbits_integrated": bool(boundary["orbit_integration_performed"]),
    }
    boundary_pass = (
        boundary_checks["summary_exact"]
        and boundary_checks["freeze_exact"]
        and not forbidden_columns
        and not boundary_checks["new_primary_gate_created"]
        and not boundary_checks["gradients_fitted"]
        and not boundary_checks["populations_fitted"]
        and not boundary_checks["orbits_integrated"]
    )
    add_gate(
        gates,
        "stage3c_science_boundary",
        boundary_pass,
        boundary_checks,
        {
            "summary_exact": True,
            "freeze_exact": True,
            "forbidden_columns": [],
            "new_primary_gate_created": False,
            "gradients_fitted": False,
            "populations_fitted": False,
            "orbits_integrated": False,
        },
        "Stage 3C stops at uncertainty/stress and introduces no downstream science inference",
    )

    if len(gates) != 20:
        raise RuntimeError(f"Internal validator definition error: gates={len(gates)}; expected 20")
    passed = sum(bool(gate["passed"]) for gate in gates)
    payload = {
        "stage": "3C validation",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "overall_passed": passed == len(gates),
        "n_passed": int(passed),
        "n_gates": int(len(gates)),
        "gates": gates,
    }
    validation_path = output_dir / outputs["validation_file"]
    report_path = output_dir / outputs["validation_report_file"]
    atomic_write_json(payload, validation_path)
    report_path.write_text(validation_report(payload), encoding="utf-8", newline="\n")
    logger.info(
        "Stage 3C validation passed=%s; gates=%s/%s",
        payload["overall_passed"],
        passed,
        len(gates),
    )
    close_logger(logger)
    print(
        f"Stage 3C validation passed={payload['overall_passed']}; "
        f"gates={passed}/{len(gates)}"
    )
    return 0 if payload["overall_passed"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
