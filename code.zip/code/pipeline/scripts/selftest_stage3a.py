from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from stage3a_common import (
    CANDIDATE_COLUMNS,
    GAIA_JOINED_COLUMNS,
    LABELS,
    canonicalise_joined_chunk,
    compute_quality_layer,
    gate_flow_table,
    ids_sha256,
    label_flow_table,
    origin_flow_table,
)


def fixtures() -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    root = Path(__file__).resolve().parent.parent
    with (root / "config" / "stage3a.yml").open("r", encoding="utf-8") as handle:
        policy = yaml.safe_load(handle)["quality_policy"]
    ids = np.arange(1, 9, dtype=np.int64)
    candidate = pd.DataFrame(index=np.arange(len(ids)))
    candidate["gaia_dr3_source_id"] = ids
    candidate["survey_origin"] = [
        "APOGEE_only",
        "GALAH_only",
        "overlap",
        "APOGEE_only",
        "GALAH_only",
        "overlap",
        "APOGEE_only",
        "GALAH_only",
    ]
    candidate["preferred_spectroscopic_survey"] = "APOGEE"
    candidate["spectroscopic_rgb_quality_any"] = True
    candidate["spectroscopic_primary_ok"] = True
    candidate["spectroscopic_sensitivity_ok"] = True
    candidate["analysis_teff"] = 4800.0
    candidate["analysis_teff_err"] = 50.0
    candidate["analysis_logg"] = 2.5
    candidate["analysis_logg_err"] = 0.1
    candidate["spectroscopic_ra"] = ids.astype(float)
    candidate["spectroscopic_dec"] = ids.astype(float) / 10.0
    candidate["spectroscopic_rv"] = 20.0
    candidate["spectroscopic_rv_err"] = 0.2
    candidate.loc[5, ["spectroscopic_rv", "spectroscopic_rv_err"]] = np.nan
    for label in LABELS:
        prefix = "alpha3" if label == "alpha3" else f"{label}_hom"
        candidate[f"{prefix}_primary_ok"] = True
        candidate[f"{prefix}_core_ok"] = True
        candidate[f"{prefix}_sensitivity_ok"] = True
    candidate = candidate.loc[:, CANDIDATE_COLUMNS]

    gaia = pd.DataFrame(index=np.arange(len(ids)))
    gaia["source_id"] = ids
    defaults = {
        "ra": ids.astype(float),
        "ra_error": 0.1,
        "dec": ids.astype(float) / 10.0,
        "dec_error": 0.1,
        "parallax": 1.0,
        "parallax_error": 0.05,
        "parallax_over_error": 20.0,
        "pmra": 2.0,
        "pmra_error": 0.1,
        "pmdec": -1.0,
        "pmdec_error": 0.1,
        "astrometric_params_solved": 31,
        "astrometric_n_good_obs_al": 100,
        "astrometric_gof_al": 0.0,
        "astrometric_excess_noise": 0.0,
        "visibility_periods_used": 12,
        "ruwe": 1.0,
        "duplicated_source": False,
        "ipd_frac_multi_peak": 0.0,
        "phot_g_mean_mag": 12.0,
        "phot_bp_mean_mag": 13.0,
        "phot_rp_mean_mag": 11.0,
        "bp_rp": 2.0,
        "phot_bp_rp_excess_factor": 1.2,
        "radial_velocity": 20.5,
        "radial_velocity_error": 1.0,
        "rv_nb_transits": 10,
        "grvs_mag": 11.0,
        "r_med_geo": 1000.0,
        "r_lo_geo": 900.0,
        "r_hi_geo": 1100.0,
        "r_med_photogeo": 1000.0,
        "r_lo_photogeo": 900.0,
        "r_hi_photogeo": 1100.0,
    }
    for column in GAIA_JOINED_COLUMNS:
        if column == "source_id":
            continue
        if column.endswith("_corr"):
            gaia[column] = 0.0
        else:
            gaia[column] = defaults[column]
    gaia.loc[1, "ruwe"] = 1.6
    gaia.loc[2, "ipd_frac_multi_peak"] = 3.0
    gaia.loc[3, ["r_lo_photogeo", "r_hi_photogeo"]] = [750.0, 1250.0]
    gaia.loc[4, ["r_lo_photogeo", "r_hi_photogeo"]] = [650.0, 1350.0]
    gaia.loc[6, "radial_velocity"] = 100.0
    gaia.loc[7, "duplicated_source"] = True
    gaia = gaia.rename(columns={"source_id": "gaia_dr3_source_id"})
    return candidate, gaia, policy


def main() -> int:
    candidate, gaia, policy = fixtures()
    layer = compute_quality_layer(candidate, gaia, policy)
    checks: list[tuple[str, bool]] = []
    checks.append(
        (
            "identity",
            layer["gaia_dr3_source_id"].tolist() == list(range(1, 9))
            and not layer["gaia_dr3_source_id"].duplicated().any(),
        )
    )
    checks.append(
        (
            "primary_astrometry_is_stricter",
            not bool(layer.loc[1, "gaia_astrometry_primary_ok"])
            and bool(layer.loc[1, "gaia_astrometry_sensitivity_ok"])
            and not bool(layer.loc[2, "gaia_astrometry_primary_ok"])
            and bool(layer.loc[2, "gaia_astrometry_sensitivity_ok"]),
        )
    )
    checks.append(
        (
            "distance_width_tiers",
            not bool(layer.loc[3, "distance_photogeo_primary_ok"])
            and bool(layer.loc[3, "distance_photogeo_sensitivity_ok"])
            and not bool(layer.loc[4, "distance_photogeo_sensitivity_ok"])
            and bool(layer.loc[4, "distance_geo_alternative_ok"]),
        )
    )
    checks.append(
        (
            "gaia_rv_fallback",
            layer.loc[5, "analysis_rv_source"] == "GAIA_PRIMARY"
            and bool(layer.loc[5, "rv_primary_ok"]),
        )
    )
    checks.append(
        (
            "rv_disagreement_policy",
            bool(layer.loc[6, "rv_cross_source_disagreement"])
            and not bool(layer.loc[6, "rv_primary_ok"])
            and bool(layer.loc[6, "rv_sensitivity_ok"]),
        )
    )
    checks.append(
        (
            "duplicate_source_rejected",
            not bool(layer.loc[7, "gaia_astrometry_primary_ok"])
            and not bool(layer.loc[7, "gaia_astrometry_sensitivity_ok"]),
        )
    )
    checks.append(
        (
            "nested_clean_sets",
            bool(
                np.all(
                    ~layer["clean_5d_primary_ok"].to_numpy(bool)
                    | layer["clean_5d_sensitivity_ok"].to_numpy(bool)
                )
                and np.all(
                    ~layer["clean_6d_primary_ok"].to_numpy(bool)
                    | layer["clean_6d_sensitivity_ok"].to_numpy(bool)
                )
            ),
        )
    )
    checks.append(
        (
            "flow_tables",
            len(gate_flow_table(layer, 10)) == 15
            and len(origin_flow_table(layer)) == 3
            and len(label_flow_table(layer)) == 6,
        )
    )
    joined = gaia.rename(columns={"gaia_dr3_source_id": "source_id"})
    shuffled = joined.iloc[[5, 0, 7, 2, 4, 1, 6, 3]].reset_index(drop=True)
    ordered_ids = np.arange(1, 9, dtype=np.int64)
    canonical, canonical_ids = canonicalise_joined_chunk(
        shuffled,
        {
            "requested_ids": len(ordered_ids),
            "requested_ids_sha256": ids_sha256(ordered_ids),
            "first_requested_id": int(ordered_ids[0]),
            "last_requested_id": int(ordered_ids[-1]),
        },
        "shuffled Gaia cache fixture",
    )
    checks.append(
        (
            "unordered_cache_canonicalisation",
            np.array_equal(canonical_ids, ordered_ids)
            and canonical["source_id"].tolist() == ordered_ids.tolist(),
        )
    )
    tampered = shuffled.copy()
    tampered.loc[0, "source_id"] = 999
    tampered_rejected = False
    try:
        canonicalise_joined_chunk(
            tampered,
            {
                "requested_ids": len(ordered_ids),
                "requested_ids_sha256": ids_sha256(ordered_ids),
                "first_requested_id": int(ordered_ids[0]),
                "last_requested_id": int(ordered_ids[-1]),
            },
            "tampered Gaia cache fixture",
        )
    except RuntimeError:
        tampered_rejected = True
    checks.append(("tampered_cache_rejected", tampered_rejected))
    failed = [name for name, passed in checks if not passed]
    if failed:
        raise AssertionError("Stage 3A self-test failed: " + ", ".join(failed))
    print(f"Stage 3A logic self-test passed: {len(checks)}/{len(checks)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
