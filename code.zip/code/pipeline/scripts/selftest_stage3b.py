from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from stage3b_common import (
    INPUT_COLUMNS,
    LABELS,
    build_phase_space_layer,
    estimator_sensitivity_table,
    explicit_frame,
    extreme_audit_table,
    frame_equal,
    galcen_velocity_xyz,
    gate_flow_table,
    label_flow_table,
    origin_flow_table,
)


def fixture() -> tuple[pd.DataFrame, dict]:
    root = Path(__file__).resolve().parent.parent
    with (root / "config" / "stage3b.yml").open("r", encoding="utf-8") as handle:
        policy = yaml.safe_load(handle)["phase_space_policy"]
    rows = 8
    frame = pd.DataFrame(index=np.arange(rows))
    frame["gaia_dr3_source_id"] = np.arange(1, rows + 1, dtype=np.int64)
    frame["survey_origin"] = [
        "APOGEE_only",
        "GALAH_only",
        "overlap",
        "APOGEE_only",
        "GALAH_only",
        "overlap",
        "APOGEE_only",
        "GALAH_only",
    ]
    frame["preferred_spectroscopic_survey"] = "APOGEE"
    frame["spectroscopic_primary_ok"] = True
    frame["spectroscopic_sensitivity_ok"] = True
    frame["ra"] = [89.014303, 120.0, 45.0, 210.0, 20.0, 300.0, 15.0, 270.0]
    frame["dec"] = [13.924912, -20.0, 10.0, 30.0, -40.0, 5.0, 25.0, -30.0]
    frame["pmra"] = [372.72, 2.0, 100.0, 0.01, 3.0, -2.0, 1.0, 2.0]
    frame["pmdec"] = [-483.69, -1.0, 100.0, 0.01, -4.0, 1.0, 2.0, -3.0]
    frame["distance_primary_pc"] = [
        1000.0 / 37.59,
        1000.0,
        10000.0,
        250000.0,
        1500.0,
        8000.0,
        np.nan,
        5000.0,
    ]
    frame["r_med_geo"] = [
        1000.0 / 37.59,
        1100.0,
        9000.0,
        240000.0,
        3000.0,
        8500.0,
        np.nan,
        5200.0,
    ]
    frame["analysis_rv_kms"] = [0.37, np.nan, 20.0, 30.0, -10.0, 50.0, 5.0, 10.0]
    frame["analysis_rv_error_kms"] = [0.2, np.nan, 1.0, 2.0, 1.0, 1.0, 1.0, 1.0]
    frame["analysis_rv_source"] = [
        "SPECTROSCOPIC_PRIMARY",
        "UNAVAILABLE",
        "SPECTROSCOPIC_PRIMARY",
        "SPECTROSCOPIC_PRIMARY",
        "SPECTROSCOPIC_PRIMARY",
        "SPECTROSCOPIC_PRIMARY",
        "SPECTROSCOPIC_PRIMARY",
        "SPECTROSCOPIC_PRIMARY",
    ]
    frame["clean_5d_primary_ok"] = [True, True, True, True, True, True, False, True]
    frame["clean_5d_sensitivity_ok"] = [True, True, True, True, True, True, False, True]
    frame["clean_6d_primary_ok"] = [True, False, True, True, True, True, False, True]
    frame["clean_6d_sensitivity_ok"] = [True, False, True, True, True, True, False, True]
    frame["clean_6d_geo_alternative_ok"] = [True, False, True, True, True, True, False, True]
    for label in LABELS:
        frame[f"{label}_clean6d_primary_ok"] = frame["clean_6d_primary_ok"]
        frame[f"{label}_clean6d_core_ok"] = frame["clean_6d_primary_ok"]
        frame[f"{label}_clean6d_sensitivity_ok"] = frame["clean_6d_sensitivity_ok"]
        frame[f"{label}_clean6d_geo_alternative_ok"] = frame[
            "clean_6d_geo_alternative_ok"
        ]
    return frame.loc[:, INPUT_COLUMNS], policy


def main() -> int:
    input_layer, policy = fixture()
    layer = build_phase_space_layer(input_layer, policy)
    checks: list[tuple[str, bool]] = []
    frame = explicit_frame(policy["frame"])
    checks.append(
        (
            "explicit_frame",
            np.isclose(frame.galcen_distance.to_value("kpc"), 8.122)
            and np.isclose(frame.z_sun.to_value("pc"), 20.8)
            and np.allclose(
                galcen_velocity_xyz(frame).to_value("km/s"),
                [12.9, 245.6, 7.78],
            ),
        )
    )
    checks.append(
        (
            "identity",
            layer["gaia_dr3_source_id"].tolist() == list(range(1, 9))
            and not layer["gaia_dr3_source_id"].duplicated().any(),
        )
    )
    checks.append(
        (
            "astropy_documentation_reference",
            np.allclose(
                layer.loc[0, ["v_x_gc_kms", "v_y_gc_kms", "v_z_gc_kms"]].to_numpy(float),
                [30.25468472, 171.29916086, 18.19390627],
                atol=1.0e-7,
                rtol=0.0,
            ),
        )
    )
    synthetic_x, synthetic_y, synthetic_vx, synthetic_vy = -8.0, 0.0, 0.0, 220.0
    synthetic_r = np.hypot(synthetic_x, synthetic_y)
    synthetic_v_phi = (
        synthetic_x * synthetic_vy - synthetic_y * synthetic_vx
    ) / synthetic_r
    checks.append(
        (
            "prograde_sign_convention",
            np.isclose(synthetic_v_phi, -220.0)
            and np.isclose(-synthetic_v_phi, 220.0)
            and np.allclose(
                layer.loc[layer["photo_velocity_finite"], "v_rot_gc_kms"],
                -layer.loc[layer["photo_velocity_finite"], "v_phi_gc_kms"],
            ),
        )
    )
    checks.append(
        (
            "position_without_rv",
            bool(layer.loc[1, "photo_position_finite"])
            and not bool(layer.loc[1, "photo_velocity_finite"])
            and bool(layer.loc[1, "phase_space_5d_primary_ok"])
            and not bool(layer.loc[1, "phase_space_6d_primary_ok"]),
        )
    )
    checks.append(
        (
            "speed_guard",
            layer.loc[2, "v_total_gc_kms"] > 1500.0
            and not bool(layer.loc[2, "phase_space_6d_primary_ok"])
            and not bool(layer.loc[2, "phase_space_6d_sensitivity_ok"]),
        )
    )
    checks.append(
        (
            "radius_tiers",
            layer.loc[3, "r_sph_gc_kpc"] > 200.0
            and layer.loc[3, "r_sph_gc_kpc"] <= 300.0
            and not bool(layer.loc[3, "phase_space_6d_primary_ok"])
            and bool(layer.loc[3, "phase_space_6d_sensitivity_ok"]),
        )
    )
    primary = layer["phase_space_6d_primary_ok"].to_numpy(bool)
    sensitivity = layer["phase_space_6d_sensitivity_ok"].to_numpy(bool)
    primary5 = layer["phase_space_5d_primary_ok"].to_numpy(bool)
    sensitivity5 = layer["phase_space_5d_sensitivity_ok"].to_numpy(bool)
    checks.append(
        (
            "nested_sets",
            bool(
                np.all(~primary | sensitivity)
                and np.all(~primary5 | sensitivity5)
                and np.all(~primary | primary5)
            ),
        )
    )
    checks.append(
        (
            "geometric_estimator_layer",
            not np.isclose(layer.loc[4, "r_cyl_gc_kpc"], layer.loc[4, "r_cyl_gc_kpc_geo_alt"])
            and bool(layer.loc[4, "phase_space_6d_geo_alternative_ok"]),
        )
    )
    label_ok = True
    for label in LABELS:
        label_ok &= bool(
            np.array_equal(
                layer[f"{label}_phase_space_primary_ok"].to_numpy(bool), primary
            )
        )
    checks.append(("label_inheritance", label_ok))
    checks.append(
        (
            "audit_tables",
            len(gate_flow_table(layer)) == 18
            and len(origin_flow_table(layer)) == 3
            and len(label_flow_table(layer)) == 6
            and len(estimator_sensitivity_table(layer)) == 6
            and len(extreme_audit_table(layer)) >= 2,
        )
    )
    repeated = build_phase_space_layer(input_layer, policy)
    checks.append(
        (
            "deterministic_recomputation",
            frame_equal(layer, repeated, ["gaia_dr3_source_id"], atol=0.0),
        )
    )
    failed = [name for name, passed in checks if not passed]
    if failed:
        raise AssertionError("Stage 3B self-test failed: " + ", ".join(failed))
    print(f"Stage 3B logic self-test passed: {len(checks)}/{len(checks)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
