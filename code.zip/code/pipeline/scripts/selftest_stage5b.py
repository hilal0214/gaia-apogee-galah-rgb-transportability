from __future__ import annotations

import argparse
import copy
import sys

import numpy as np
import pandas as pd

from stage5b_common import (
    BASE_FEATURES,
    canonicalize_components,
    claim_ledger,
    fit_with_deterministic_screening,
    k4_diagnostic_columns,
    load_config,
    normalized_entropy,
    parameter_records,
    predict_responsibilities,
    reconstruct_standardized_parameters,
    responsibility_probability_columns,
    robust_scaler,
    view_inventory,
)


def require(condition: bool, message: str, checks: list[str]) -> None:
    if not bool(condition):
        raise AssertionError(message)
    checks.append(message)


def main() -> int:
    parser = argparse.ArgumentParser(description="Stage 5B logic self-test")
    parser.add_argument("--config", default="config/stage5b.yml")
    args = parser.parse_args()
    config, _ = load_config(args.config)
    checks: list[str] = []

    require(config["project"]["version"] == "0.11.0", "version contract", checks)
    inventory = view_inventory(config)
    require(len(inventory) == 10, "ten view/K variants", checks)
    require(
        len(responsibility_probability_columns(config)) == 40
        and len(k4_diagnostic_columns(config)) == 20,
        "responsibility schema inventory",
        checks,
    )
    target_map = {"fe_h": "fe_h_hom", "alpha3": "alpha3_hom"}
    leakage_safe = True
    for view in config["population_inference"]["model_views"]:
        features = set(view["features"])
        leakage_safe &= {"r_cyl_gc_kpc", "abs_z_gc_kpc"}.isdisjoint(features)
        if bool(view["allowed_for_population_gradient"]):
            for target in view["targets"]:
                if target in target_map:
                    leakage_safe &= target_map[target] not in features
    require(leakage_safe, "target and spatial leakage exclusion", checks)
    require(
        config["population_inference"]["mixture"]["family"]
        == "multivariate_student_t_mixture"
        and config["population_inference"]["mixture"]["degrees_of_freedom"] == 5.0,
        "fixed Student-t family",
        checks,
    )

    generator = np.random.Generator(np.random.PCG64DXSM(20260804))
    component_rows = [900, 1050, 1100, 950]
    centers = np.asarray(
        [
            [-1.6, 0.30, 15.0, -120.0, 20.0],
            [-0.8, 0.24, -10.0, 35.0, -15.0],
            [-0.25, 0.10, 5.0, 165.0, 8.0],
            [0.05, 0.03, -3.0, 232.0, -4.0],
        ]
    )
    scales = np.asarray([0.18, 0.04, 32.0, 24.0, 26.0])
    chunks = []
    for rows, center in zip(component_rows, centers, strict=True):
        normal = generator.normal(size=(rows, len(BASE_FEATURES))) * scales
        tail = np.sqrt(5.0 / generator.chisquare(5.0, size=rows))[:, None]
        chunks.append(center + normal * tail)
    values = np.vstack(chunks)
    generator.shuffle(values, axis=0)
    require(np.isfinite(values).all(), "finite heavy-tailed fixture", checks)

    center, scale = robust_scaler(values, 1.482602218505602, 1.0e-8)
    standardized = (values - center) / scale
    test_config = copy.deepcopy(config)
    mixture = test_config["population_inference"]["mixture"]
    mixture["screen_rows"] = 1800
    mixture["screen_maximum_iterations"] = 24
    mixture["maximum_iterations"] = 180
    mixture["relative_tolerance"] = 1.0e-6
    first, first_audit, _, first_valid = fit_with_deterministic_screening(
        standardized, 4, test_config, "SELFTEST|K4"
    )
    second, second_audit, _, second_valid = fit_with_deterministic_screening(
        standardized, 4, test_config, "SELFTEST|K4"
    )
    first = canonicalize_components(
        first,
        BASE_FEATURES,
        center,
        scale,
        test_config["population_inference"]["component_alignment"]["order_features"],
    )
    second = canonicalize_components(
        second,
        BASE_FEATURES,
        center,
        scale,
        test_config["population_inference"]["component_alignment"]["order_features"],
    )
    require(
        first_valid and second_valid and first.converged and first.monotonic,
        "mixture convergence and monotonicity",
        checks,
    )
    require(
        np.allclose(first.weights, second.weights, rtol=0.0, atol=1.0e-12)
        and np.allclose(first.means, second.means, rtol=0.0, atol=1.0e-12)
        and np.allclose(first.covariances, second.covariances, rtol=0.0, atol=1.0e-12),
        "deterministic repeated fit",
        checks,
    )
    require(
        len(first_audit) == 16
        and sum(bool(row["selected_for_full_refinement"]) for row in first_audit) == 2
        and sum(bool(row["selected_final"]) for row in first_audit) == 1
        and first_audit == second_audit,
        "restart and refinement audit",
        checks,
    )
    require(
        abs(float(first.weights.sum()) - 1.0) < 1.0e-12
        and float(first.weights.min()) >= 0.01,
        "mixture weight contract",
        checks,
    )
    eigenvalues = np.asarray(
        [np.linalg.eigvalsh(covariance) for covariance in first.covariances]
    )
    require(float(eigenvalues.min()) >= 5.0e-5, "positive covariance floor", checks)
    original_means = first.means * scale[None, :] + center[None, :]
    require(
        np.all(np.diff(original_means[:, BASE_FEATURES.index("v_rot_gc_kms")]) > 0.0),
        "fold-local anonymous component ordering",
        checks,
    )
    probability, log_density = predict_responsibilities(
        standardized,
        first.weights,
        first.means,
        first.covariances,
        5.0,
    )
    require(np.isfinite(probability).all() and np.isfinite(log_density).all(), "finite predictions", checks)
    require(
        np.max(np.abs(probability.sum(axis=1) - 1.0)) < 1.0e-12,
        "responsibility simplex",
        checks,
    )
    entropy = normalized_entropy(probability)
    require(np.all((entropy >= 0.0) & (entropy <= 1.0 + 1.0e-12)), "normalized entropy bounds", checks)

    records = pd.DataFrame(
        parameter_records("SELFTEST", 4, 0, BASE_FEATURES, center, scale, first)
    )
    rebuilt = reconstruct_standardized_parameters(
        records, "SELFTEST", 4, 0, BASE_FEATURES
    )
    rebuilt_probability, _ = predict_responsibilities(
        standardized, rebuilt[2], rebuilt[3], rebuilt[4], 5.0
    )
    require(
        np.allclose(rebuilt[0], center, rtol=0.0, atol=0.0)
        and np.allclose(rebuilt[1], scale, rtol=0.0, atol=0.0),
        "parameter scaler round trip",
        checks,
    )
    require(
        np.allclose(rebuilt_probability, probability, rtol=0.0, atol=1.0e-14),
        "parameter prediction round trip",
        checks,
    )

    blocks = np.repeat(np.arange(100, dtype=np.int64), 40)
    folds = blocks % 5
    require(
        all(
            np.intersect1d(np.unique(blocks[folds == fold]), np.unique(blocks[folds != fold])).size
            == 0
            for fold in range(5)
        ),
        "spatial block fold exclusion",
        checks,
    )
    require(
        not config["science_boundary"]["hard_population_labels_created"]
        and not config["science_boundary"]["calibrated_galactic_memberships_claimed"]
        and not config["science_boundary"]["population_resolved_gradients_fitted"],
        "science boundary",
        checks,
    )
    claims = claim_ledger(config)
    require(int((claims.status == "FORBIDDEN").sum()) >= 5, "claim ledger guardrails", checks)

    expected_checks = 20
    if len(checks) != expected_checks:
        raise AssertionError(f"Self-test gate count changed: {len(checks)} != {expected_checks}")
    print(f"Stage 5B logic self-test passed: {len(checks)}/{expected_checks}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
