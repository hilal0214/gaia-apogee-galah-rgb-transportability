from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

from stage4a_common import (
    atomic_write_json,
    load_config,
    project_path,
    read_json,
    sha256_file,
    utc_now,
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Package Stage 4A outputs")
    parser.add_argument("--config", default="config/stage4a.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    outputs = config["outputs"]
    output_dir = project_path(root, config["paths"]["output_dir"])
    validation_path = output_dir / outputs["validation_file"]
    validation = read_json(validation_path)
    expected_gates = int(config["validation"]["expected_gates"])
    if not bool(validation.get("overall_passed", False)):
        raise RuntimeError("Stage 4A validation is not PASS; packaging is forbidden")
    if [int(validation.get("n_passed", -1)), int(validation.get("n_gates", -1))] != [
        expected_gates,
        expected_gates,
    ]:
        raise RuntimeError(
            f"Stage 4A validation gate count is not {expected_gates}/{expected_gates}"
        )

    relative_files = [
        Path("25_build_stage4a.bat"),
        Path("26_validate_stage4a.bat"),
        Path("27_package_stage4a.bat"),
        Path("99_stage4a_selftest.bat"),
        Path("run_stage4a_all.bat"),
        Path("STAGE4A_PROTOCOL.md"),
        Path("STAGE4A_README_UZ.md"),
        Path("STAGE4A_HOTFIX_V0_8_1_README_UZ.md"),
        Path("config/stage4a.yml"),
        Path("scripts/25_build_stage4a.py"),
        Path("scripts/26_validate_stage4a.py"),
        Path("scripts/27_package_stage4a.py"),
        Path("scripts/selftest_stage4a.py"),
        Path("scripts/stage4a_common.py"),
        Path("logs/25_build_stage4a.log"),
        Path("logs/26_validate_stage4a.log"),
    ]

    a = config["stage2c_frozen"]
    relative_files.extend(
        Path("outputs/stage2c") / name
        for name in (
            a["build_summary_file"],
            a["freeze_manifest_file"],
            a["validation_file"],
            a["validation_report_file"],
            a["package_manifest_file"],
        )
    )
    b = config["stage3b_frozen"]
    relative_files.extend(
        Path("outputs/stage3b") / name
        for name in (
            b["build_summary_file"],
            b["freeze_manifest_file"],
            b["validation_file"],
        )
    )
    c = config["stage3c_frozen"]
    relative_files.extend(
        Path("outputs/stage3c") / name
        for name in (
            c["build_summary_file"],
            c["freeze_manifest_file"],
            c["validation_file"],
            c["method_definition_file"],
            c["package_manifest_file"],
        )
    )
    relative_files.extend(
        Path("outputs/stage4a") / outputs[key]
        for key in (
            "design_layer_file",
            "cohort_flow_file",
            "common_support_bounds_file",
            "covariate_balance_file",
            "spatial_block_summary_file",
            "population_feature_flow_file",
            "design_definition_file",
            "build_summary_file",
            "freeze_manifest_file",
            "validation_file",
            "validation_report_file",
        )
    )
    missing = [str(path) for path in relative_files if not (root / path).exists()]
    if missing:
        raise FileNotFoundError("Missing Stage 4A package files: " + "; ".join(missing))

    manifest = {
        "package": outputs["package_name"].removesuffix(".zip"),
        "stage": "4A",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": utc_now(),
        "files": [
            {
                "path": path.as_posix(),
                "bytes": int((root / path).stat().st_size),
                "sha256": sha256_file(root / path),
            }
            for path in relative_files
        ],
        "upstream": {
            "stage2c_release_sha256": a["release_sha256"],
            "stage2c_transport_atlas_sha256": a["atlas_sha256"],
            "stage3b_release_sha256": b["release_sha256"],
            "stage3b_phase_space_layer_sha256": b["phase_space_layer_sha256"],
            "stage3c_release_sha256": c["release_sha256"],
            "stage3c_uncertainty_layer_sha256": c["uncertainty_layer_sha256"],
        },
        "excluded": [
            "official raw survey catalogues and the 76 frozen Gaia cache chunks",
            "the Stage 2C transport atlas, referenced by exact SHA-256",
            "the Stage 3B phase-space layer, referenced by exact SHA-256",
            "the Stage 3C uncertainty layer, referenced by exact SHA-256",
            "gradient coefficients, bootstrap outputs, population labels, and weights",
        ],
        "science_boundary": config["science_boundary"],
    }
    manifest_path = output_dir / outputs["package_manifest_file"]
    atomic_write_json(manifest, manifest_path)
    package_files = [*relative_files, manifest_path.relative_to(root)]
    package_path = root / outputs["package_name"]
    temporary = package_path.with_name(f".{package_path.name}.tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(
        temporary,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
        allowZip64=True,
    ) as archive:
        for path in package_files:
            archive.write(root / path, arcname=path.as_posix())
    temporary.replace(package_path)
    with zipfile.ZipFile(package_path, mode="r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"Packaged ZIP failed integrity at {bad}")
    print(f"Output bundle created: {package_path}")
    print(f"SHA-256: {sha256_file(package_path)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
