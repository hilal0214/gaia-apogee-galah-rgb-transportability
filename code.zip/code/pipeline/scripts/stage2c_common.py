from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


ELEMENTS = ("fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe")
ALPHA3_ELEMENTS = ("mg_fe", "si_fe", "ca_fe")
COEFFICIENT_COLUMNS = (
    "intercept_dex",
    "coef_teff_per_1000k",
    "coef_logg_per_dex",
    "coef_feh_per_dex",
)
SUPPORT_TIERS = (
    "NOT_ELIGIBLE",
    "CORE_99",
    "EDGE_OBSERVED",
    "EXTRAPOLATED",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_config(path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {config_path}")
    return config, config_path.parent.parent


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def setup_logger(path: Path, name: str) -> logging.Logger:
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def close_logger(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        handler.flush()
        handler.close()
        logger.removeHandler(handler)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(block_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def canonical_line_sha256(lines: Iterable[str]) -> str:
    digest = hashlib.sha256()
    for line in lines:
        digest.update(line.encode("ascii"))
    return digest.hexdigest()


def ids_sha256(values: Sequence[int] | np.ndarray | pd.Series) -> str:
    array = np.asarray(values, dtype=np.int64)
    return canonical_line_sha256(f"{int(value)}\n" for value in array)


def canonical_json_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        temporary = Path(handle.name)
    os.replace(temporary, path)


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    if path.suffix == ".parquet":
        frame.to_parquet(temporary, index=False, compression="zstd")
    elif path.suffix == ".csv":
        frame.to_csv(temporary, index=False)
    else:
        raise ValueError(f"Unsupported table format: {path}")
    os.replace(temporary, path)


def ensure_columns(frame: pd.DataFrame, required: Sequence[str], label: str) -> None:
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise KeyError(f"{label} is missing required columns: {missing}")


def finite_numeric(series: pd.Series) -> np.ndarray:
    return np.isfinite(pd.to_numeric(series, errors="coerce").to_numpy(float))


def prefix_columns(frame: pd.DataFrame, prefix: str) -> pd.DataFrame:
    return frame.rename(
        columns={
            column: f"{prefix}_{column}"
            for column in frame.columns
            if column != "gaia_dr3_source_id"
        }
    )


def predictor_matrix(frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    required = ("galah_teff", "galah_logg", "galah_fe_h")
    ensure_columns(frame, required, "GALAH transport predictors")
    teff = pd.to_numeric(frame["galah_teff"], errors="coerce").to_numpy(float)
    logg = pd.to_numeric(frame["galah_logg"], errors="coerce").to_numpy(float)
    feh = pd.to_numeric(frame["galah_fe_h"], errors="coerce").to_numpy(float)
    matrix = np.column_stack(
        [
            np.ones(len(frame), dtype=float),
            (teff - 4800.0) / 1000.0,
            logg - 2.5,
            feh,
        ]
    )
    finite = np.isfinite(matrix).all(axis=1)
    return matrix, finite


def coefficient_vector(record: Mapping[str, Any]) -> np.ndarray:
    return np.asarray([float(record[name]) for name in COEFFICIENT_COLUMNS])


def support_tiers(
    matrix: np.ndarray,
    eligible: np.ndarray,
    feature_support: Mapping[str, Mapping[str, float]],
) -> np.ndarray:
    tiers = np.full(len(matrix), "NOT_ELIGIBLE", dtype=object)
    if not eligible.any():
        return tiers
    features = {
        "galah_teff_scaled": matrix[:, 1],
        "galah_logg_centered": matrix[:, 2],
        "galah_fe_h": matrix[:, 3],
    }
    observed = eligible.copy()
    core = eligible.copy()
    for name, values in features.items():
        bounds = feature_support[name]
        observed &= values >= float(bounds["minimum"])
        observed &= values <= float(bounds["maximum"])
        core &= values >= float(bounds["q0_005"])
        core &= values <= float(bounds["q0_995"])
    tiers[eligible] = "EXTRAPOLATED"
    tiers[observed] = "EDGE_OBSERVED"
    tiers[core] = "CORE_99"
    return tiers


def load_models_and_metrics(
    deploy_path: Path,
    coefficient_path: Path,
    metric_path: Path,
) -> tuple[dict[str, Any], pd.DataFrame, pd.DataFrame]:
    deploy = read_json(deploy_path)
    coefficients = pd.read_csv(coefficient_path)
    metrics = pd.read_csv(metric_path)
    ensure_columns(
        coefficients,
        (
            "element",
            "analysis_set",
            "model_role",
            "heldout_fold",
            *COEFFICIENT_COLUMNS,
        ),
        "Stage 2B coefficients",
    )
    ensure_columns(
        metrics,
        (
            "element",
            "analysis_set",
            "post_crossfit_sigma_mad_dex",
        ),
        "Stage 2B metrics",
    )
    return deploy, coefficients, metrics


def _bool_column(frame: pd.DataFrame, name: str) -> np.ndarray:
    return frame[name].astype("boolean").fillna(False).to_numpy(dtype=bool)


def _float_column(frame: pd.DataFrame, name: str) -> np.ndarray:
    return pd.to_numeric(frame[name], errors="coerce").to_numpy(float)


def add_preferred_spectroscopic_layer(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    apogee_ok = _bool_column(result, "apogee_broad_rg_and_quality")
    galah_ok = _bool_column(result, "galah_broad_rg_and_quality")
    has_apogee = _bool_column(result, "has_apogee")
    has_galah = _bool_column(result, "has_galah")
    coordinate_primary = _bool_column(result, "coordinate_primary_ok")
    coordinate_sensitivity = _bool_column(result, "coordinate_sensitivity_ok")

    choose_apogee = apogee_ok | (~galah_ok & has_apogee)
    choose_galah = ~choose_apogee & has_galah
    result["preferred_spectroscopic_survey"] = pd.Series(
        np.select(
            [choose_apogee, choose_galah],
            ["APOGEE", "GALAH"],
            default="UNAVAILABLE",
        ),
        dtype="string",
    )
    result["spectroscopic_rgb_quality_any"] = apogee_ok | galah_ok
    result["spectroscopic_primary_ok"] = apogee_ok | (
        ~apogee_ok & galah_ok & coordinate_primary
    )
    result["spectroscopic_sensitivity_ok"] = apogee_ok | (
        ~apogee_ok & galah_ok & coordinate_sensitivity
    )

    mappings = (
        ("teff", "analysis_teff"),
        ("teff_err", "analysis_teff_err"),
        ("logg", "analysis_logg"),
        ("logg_err", "analysis_logg_err"),
        ("ra", "spectroscopic_ra"),
        ("dec", "spectroscopic_dec"),
        ("rv", "spectroscopic_rv"),
        ("rv_err", "spectroscopic_rv_err"),
    )
    for native, output in mappings:
        apogee = _float_column(result, f"apogee_{native}")
        galah = _float_column(result, f"galah_{native}")
        result[output] = np.where(choose_apogee, apogee, np.where(choose_galah, galah, np.nan))
    return result


def element_transport_columns(
    frame: pd.DataFrame,
    element: str,
    deploy: Mapping[str, Any],
    coefficients: pd.DataFrame,
    metrics: pd.DataFrame,
) -> dict[str, Any]:
    if element not in ELEMENTS:
        raise ValueError(f"Unsupported transport element: {element}")
    required = (
        f"apogee_{element}",
        f"apogee_{element}_err",
        f"apogee_valid_{element}",
        f"galah_{element}",
        f"galah_{element}_err",
        f"galah_valid_{element}",
        "apogee_broad_rg_and_quality",
        "galah_broad_rg_and_quality",
        "coordinate_primary_ok",
        "coordinate_sensitivity_ok",
    )
    ensure_columns(frame, required, f"{element} transport input")

    matrix, predictors_finite = predictor_matrix(frame)
    apogee_value = _float_column(frame, f"apogee_{element}")
    apogee_error = _float_column(frame, f"apogee_{element}_err")
    galah_value = _float_column(frame, f"galah_{element}")
    galah_error = _float_column(frame, f"galah_{element}_err")

    apogee_eligible = (
        _bool_column(frame, "apogee_broad_rg_and_quality")
        & _bool_column(frame, f"apogee_valid_{element}")
        & np.isfinite(apogee_value)
        & np.isfinite(apogee_error)
        & (apogee_error > 0)
    )
    galah_eligible = (
        _bool_column(frame, "galah_broad_rg_and_quality")
        & _bool_column(frame, f"galah_valid_{element}")
        & predictors_finite
        & np.isfinite(galah_value)
        & np.isfinite(galah_error)
        & (galah_error > 0)
    )

    model = deploy["models"]["primary"][element]
    beta = coefficient_vector(model["coefficients"])
    predicted_offset = np.full(len(frame), np.nan, dtype=float)
    corrected = np.full(len(frame), np.nan, dtype=float)
    predicted_offset[galah_eligible] = matrix[galah_eligible] @ beta
    corrected[galah_eligible] = (
        galah_value[galah_eligible] - predicted_offset[galah_eligible]
    )

    fold_rows = coefficients.loc[
        coefficients["element"].eq(element)
        & coefficients["analysis_set"].eq("primary")
        & coefficients["model_role"].eq("crossfit_fold")
    ].sort_values("heldout_fold")
    if len(fold_rows) != 5 or list(fold_rows["heldout_fold"].astype(int)) != list(range(5)):
        raise RuntimeError(f"Stage 2B primary fold coefficients are incomplete for {element}")
    fold_betas = fold_rows.loc[:, COEFFICIENT_COLUMNS].to_numpy(float)
    fold_model_sd = np.full(len(frame), np.nan, dtype=float)
    if galah_eligible.any():
        fold_predictions = matrix[galah_eligible] @ fold_betas.T
        fold_model_sd[galah_eligible] = np.std(fold_predictions, axis=1, ddof=1)

    tiers = support_tiers(matrix, galah_eligible, model["feature_support"])
    observed_support = np.isin(tiers, ("CORE_99", "EDGE_OBSERVED"))
    core_support = tiers == "CORE_99"
    coordinate_primary = _bool_column(frame, "coordinate_primary_ok")
    coordinate_sensitivity = _bool_column(frame, "coordinate_sensitivity_ok")
    galah_primary_ok = galah_eligible & observed_support & coordinate_primary
    galah_core_ok = galah_eligible & core_support & coordinate_primary
    galah_sensitivity_ok = galah_eligible & coordinate_sensitivity

    metric_row = metrics.loc[
        metrics["element"].eq(element)
        & metrics["analysis_set"].eq("primary")
    ]
    if len(metric_row) != 1:
        raise RuntimeError(f"Stage 2B primary metric row is missing for {element}")
    scatter = float(metric_row.iloc[0]["post_crossfit_sigma_mad_dex"])
    transport_error_proxy = np.full(len(frame), np.nan, dtype=float)
    transport_error_proxy[galah_eligible] = np.sqrt(
        galah_error[galah_eligible] ** 2
        + scatter**2
        + fold_model_sd[galah_eligible] ** 2
    )

    use_apogee = apogee_eligible
    use_galah = ~use_apogee & galah_eligible
    hom_value = np.where(use_apogee, apogee_value, np.where(use_galah, corrected, np.nan))
    hom_formal_error = np.where(
        use_apogee,
        apogee_error,
        np.where(use_galah, galah_error, np.nan),
    )
    hom_error_proxy = np.where(
        use_apogee,
        apogee_error,
        np.where(use_galah, transport_error_proxy, np.nan),
    )
    hom_source = np.select(
        [use_apogee, use_galah],
        ["APOGEE_NATIVE", "GALAH_CORRECTED"],
        default="UNAVAILABLE",
    )
    hom_primary_ok = use_apogee | (use_galah & galah_primary_ok)
    hom_core_ok = use_apogee | (use_galah & galah_core_ok)
    hom_sensitivity_ok = use_apogee | (use_galah & galah_sensitivity_ok)
    hom_support_tier = np.select(
        [use_apogee, use_galah],
        ["REFERENCE_NATIVE", tiers],
        default="UNAVAILABLE",
    )

    return {
        f"{element}_apogee_eligible": apogee_eligible,
        f"{element}_galah_transport_eligible": galah_eligible,
        f"{element}_galah_predicted_offset": predicted_offset,
        f"{element}_galah_corrected": corrected,
        f"{element}_galah_fold_model_sd": fold_model_sd,
        f"{element}_galah_cross_survey_sigma_mad": np.where(
            galah_eligible, scatter, np.nan
        ),
        f"{element}_galah_transport_error_proxy": transport_error_proxy,
        f"{element}_galah_support_tier": pd.Series(tiers, dtype="string"),
        f"{element}_galah_primary_ok": galah_primary_ok,
        f"{element}_galah_core_ok": galah_core_ok,
        f"{element}_galah_sensitivity_ok": galah_sensitivity_ok,
        f"{element}_hom": hom_value,
        f"{element}_hom_formal_error": hom_formal_error,
        f"{element}_hom_error_proxy": hom_error_proxy,
        f"{element}_hom_source": pd.Series(hom_source, dtype="string"),
        f"{element}_hom_support_tier": pd.Series(hom_support_tier, dtype="string"),
        f"{element}_hom_primary_ok": hom_primary_ok,
        f"{element}_hom_core_ok": hom_core_ok,
        f"{element}_hom_sensitivity_ok": hom_sensitivity_ok,
    }


def add_alpha3_layer(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    values = np.column_stack(
        [_float_column(result, f"{element}_hom") for element in ALPHA3_ELEMENTS]
    )
    errors = np.column_stack(
        [
            _float_column(result, f"{element}_hom_error_proxy")
            for element in ALPHA3_ELEMENTS
        ]
    )
    primary = np.column_stack(
        [_bool_column(result, f"{element}_hom_primary_ok") for element in ALPHA3_ELEMENTS]
    )
    core = np.column_stack(
        [_bool_column(result, f"{element}_hom_core_ok") for element in ALPHA3_ELEMENTS]
    )
    sensitivity = np.column_stack(
        [
            _bool_column(result, f"{element}_hom_sensitivity_ok")
            for element in ALPHA3_ELEMENTS
        ]
    )
    finite = np.isfinite(values)
    primary &= finite
    core &= finite
    sensitivity &= finite
    n_primary = primary.sum(axis=1).astype(np.int8)
    n_core = core.sum(axis=1).astype(np.int8)
    n_sensitivity = sensitivity.sum(axis=1).astype(np.int8)
    result["alpha3_n_primary"] = n_primary
    result["alpha3_n_core"] = n_core
    result["alpha3_n_sensitivity"] = n_sensitivity

    alpha3 = np.full(len(result), np.nan, dtype=float)
    alpha3_error = np.full(len(result), np.nan, dtype=float)
    complete = n_primary == len(ALPHA3_ELEMENTS)
    alpha3[complete] = np.mean(values[complete], axis=1)
    alpha3_error[complete] = np.sqrt(np.sum(errors[complete] ** 2, axis=1)) / len(
        ALPHA3_ELEMENTS
    )
    result["alpha3_hom"] = alpha3
    result["alpha3_hom_error_proxy"] = alpha3_error
    result["alpha3_primary_ok"] = complete
    result["alpha3_core_ok"] = n_core == len(ALPHA3_ELEMENTS)
    result["alpha3_sensitivity_ok"] = n_sensitivity == len(ALPHA3_ELEMENTS)

    available_mean = np.full(len(result), np.nan, dtype=float)
    at_least_two = n_primary >= 2
    if at_least_two.any():
        sums = np.where(primary, values, 0.0).sum(axis=1)
        available_mean[at_least_two] = sums[at_least_two] / n_primary[at_least_two]
    result["alpha_available_mean_hom"] = available_mean

    sources = np.column_stack(
        [result[f"{element}_hom_source"].astype(str).to_numpy() for element in ALPHA3_ELEMENTS]
    )
    alpha_source = np.full(len(result), "UNAVAILABLE", dtype=object)
    all_apogee = complete & np.all(sources == "APOGEE_NATIVE", axis=1)
    all_galah = complete & np.all(sources == "GALAH_CORRECTED", axis=1)
    mixed = complete & ~all_apogee & ~all_galah
    alpha_source[all_apogee] = "APOGEE_NATIVE"
    alpha_source[all_galah] = "GALAH_CORRECTED"
    alpha_source[mixed] = "MIXED"
    result["alpha3_source"] = pd.Series(alpha_source, dtype="string")
    return result


def build_transport_atlas(
    master: pd.DataFrame,
    apogee: pd.DataFrame,
    galah: pd.DataFrame,
    coordinate_decisions: pd.DataFrame,
    deploy: Mapping[str, Any],
    coefficients: pd.DataFrame,
    metrics: pd.DataFrame,
) -> pd.DataFrame:
    ensure_columns(
        master,
        ("gaia_dr3_source_id", "has_apogee", "has_galah", "survey_origin"),
        "Stage 1 source master",
    )
    result = master.copy()
    result["gaia_dr3_source_id"] = pd.to_numeric(
        result["gaia_dr3_source_id"], errors="raise"
    ).astype("int64")
    if result["gaia_dr3_source_id"].duplicated().any():
        raise RuntimeError("Stage 1 source master contains duplicate IDs")
    if not result["gaia_dr3_source_id"].gt(0).all():
        raise RuntimeError("Stage 1 source master contains a non-positive ID")

    for label, survey_frame in (("apogee", apogee), ("galah", galah)):
        ids = pd.to_numeric(survey_frame["gaia_dr3_source_id"], errors="coerce").fillna(0).astype("int64")
        selected = survey_frame.loc[ids.gt(0)].copy()
        selected["gaia_dr3_source_id"] = ids.loc[ids.gt(0)].to_numpy()
        if selected["gaia_dr3_source_id"].duplicated().any():
            raise RuntimeError(f"{label.upper()} star-level table contains duplicate positive IDs")
        result = result.merge(
            prefix_columns(selected, label),
            on="gaia_dr3_source_id",
            how="left",
            validate="one_to_one",
        )

    coordinate_required = (
        "gaia_dr3_source_id",
        "coordinate_status",
        "coordinate_hard_mismatch",
        "coordinate_primary_ok",
        "coordinate_sensitivity_ok",
    )
    ensure_columns(coordinate_decisions, coordinate_required, "Stage 2A coordinates")
    coordinates = coordinate_decisions.loc[:, coordinate_required].copy()
    if coordinates["gaia_dr3_source_id"].duplicated().any():
        raise RuntimeError("Stage 2A coordinate table contains duplicate IDs")
    result = result.merge(
        coordinates,
        on="gaia_dr3_source_id",
        how="left",
        validate="one_to_one",
    )
    overlap = result["survey_origin"].eq("overlap")
    if result.loc[overlap, "coordinate_status"].isna().any():
        raise RuntimeError("An overlap source is missing its Stage 2A coordinate decision")
    result["coordinate_status"] = result["coordinate_status"].fillna("NOT_APPLICABLE").astype("string")
    result["coordinate_hard_mismatch"] = (
        result["coordinate_hard_mismatch"].astype("boolean").fillna(False).astype(bool)
    )
    result["coordinate_primary_ok"] = (
        result["coordinate_primary_ok"].astype("boolean").fillna(True).astype(bool)
    )
    result["coordinate_sensitivity_ok"] = (
        result["coordinate_sensitivity_ok"].astype("boolean").fillna(True).astype(bool)
    )

    result = add_preferred_spectroscopic_layer(result)
    generated: dict[str, Any] = {}
    for element in ELEMENTS:
        generated.update(
            element_transport_columns(result, element, deploy, coefficients, metrics)
        )
    result = pd.concat([result, pd.DataFrame(generated, index=result.index)], axis=1)
    result = add_alpha3_layer(result)
    result = result.sort_values("gaia_dr3_source_id", kind="mergesort").reset_index(drop=True)
    return result


def element_flow_table(atlas: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for element in ELEMENTS:
        source = atlas[f"{element}_hom_source"].astype(str)
        tier = atlas[f"{element}_galah_support_tier"].astype(str)
        rows.append(
            {
                "element": element,
                "apogee_eligible": int(atlas[f"{element}_apogee_eligible"].sum()),
                "galah_transport_eligible": int(
                    atlas[f"{element}_galah_transport_eligible"].sum()
                ),
                "galah_core_99": int((tier == "CORE_99").sum()),
                "galah_edge_observed": int((tier == "EDGE_OBSERVED").sum()),
                "galah_extrapolated": int((tier == "EXTRAPOLATED").sum()),
                "hom_available": int(source.ne("UNAVAILABLE").sum()),
                "hom_from_apogee": int(source.eq("APOGEE_NATIVE").sum()),
                "hom_from_galah": int(source.eq("GALAH_CORRECTED").sum()),
                "hom_primary_ok": int(atlas[f"{element}_hom_primary_ok"].sum()),
                "hom_core_ok": int(atlas[f"{element}_hom_core_ok"].sum()),
                "hom_sensitivity_ok": int(
                    atlas[f"{element}_hom_sensitivity_ok"].sum()
                ),
            }
        )
    return pd.DataFrame(rows)


def origin_element_flow_table(atlas: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for origin in ("APOGEE_only", "GALAH_only", "overlap"):
        selected = atlas.loc[atlas["survey_origin"].eq(origin)]
        for element in ELEMENTS:
            source = selected[f"{element}_hom_source"].astype(str)
            rows.append(
                {
                    "survey_origin": origin,
                    "element": element,
                    "source_rows": int(len(selected)),
                    "hom_available": int(source.ne("UNAVAILABLE").sum()),
                    "hom_from_apogee": int(source.eq("APOGEE_NATIVE").sum()),
                    "hom_from_galah": int(source.eq("GALAH_CORRECTED").sum()),
                    "hom_primary_ok": int(selected[f"{element}_hom_primary_ok"].sum()),
                    "hom_core_ok": int(selected[f"{element}_hom_core_ok"].sum()),
                    "hom_sensitivity_ok": int(
                        selected[f"{element}_hom_sensitivity_ok"].sum()
                    ),
                }
            )
    return pd.DataFrame(rows)


def support_bounds_table(deploy: Mapping[str, Any]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for element in ELEMENTS:
        support = deploy["models"]["primary"][element]["feature_support"]
        for predictor, values in support.items():
            rows.append({"element": element, "predictor": predictor, **values})
    return pd.DataFrame(rows)
