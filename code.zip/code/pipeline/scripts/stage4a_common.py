from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import pyarrow
import yaml


LABELS = ("fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe", "alpha3")
ELEMENT_LABELS = LABELS[:-1]
SOURCE_GROUPS = ("APOGEE_NATIVE", "GALAH_CORRECTED")

CENTRAL_METRICS = (
    "r_cyl_gc_kpc",
    "z_gc_kpc",
    "v_R_gc_kms",
    "v_rot_gc_kms",
    "v_z_gc_kms",
    "v_total_gc_kms",
    "l_z_gc_kpc_kms",
)

STAGE3C_METRICS = CENTRAL_METRICS


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_config(path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {config_path}")
    return config, config_path.parent.parent


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def setup_logger(path: Path, name: str) -> logging.Logger:
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def close_logger(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        handler.flush()
        handler.close()
        logger.removeHandler(handler)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def ids_sha256(values: Sequence[int] | np.ndarray | pd.Series) -> str:
    digest = hashlib.sha256()
    for value in np.asarray(values, dtype=np.int64):
        digest.update(f"{int(value)}\n".encode("ascii"))
    return digest.hexdigest()


def canonical_json_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        temporary = Path(handle.name)
    os.replace(temporary, path)


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.unlink(missing_ok=True)
    if path.suffix.lower() == ".parquet":
        frame.to_parquet(temporary, index=False, compression="zstd")
    elif path.suffix.lower() == ".csv":
        frame.to_csv(temporary, index=False, lineterminator="\n")
    else:
        raise ValueError(f"Unsupported table format: {path}")
    os.replace(temporary, path)


def flag(frame: pd.DataFrame, column: str) -> np.ndarray:
    return frame[column].astype("boolean").fillna(False).to_numpy(dtype=bool)


def number(frame: pd.DataFrame, column: str) -> np.ndarray:
    return pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=float)


def stage2c_columns() -> list[str]:
    columns = [
        "gaia_dr3_source_id",
        "survey_origin",
        "preferred_spectroscopic_survey",
        "spectroscopic_primary_ok",
        "spectroscopic_sensitivity_ok",
        "analysis_teff",
        "analysis_teff_err",
        "analysis_logg",
        "analysis_logg_err",
    ]
    for label in ELEMENT_LABELS:
        columns.extend(
            [
                f"{label}_hom",
                f"{label}_hom_formal_error",
                f"{label}_hom_error_proxy",
                f"{label}_hom_source",
                f"{label}_hom_support_tier",
                f"{label}_hom_primary_ok",
                f"{label}_hom_core_ok",
                f"{label}_hom_sensitivity_ok",
            ]
        )
    columns.extend(
        [
            "alpha3_hom",
            "alpha3_hom_error_proxy",
            "alpha3_source",
            "alpha3_primary_ok",
            "alpha3_core_ok",
            "alpha3_sensitivity_ok",
        ]
    )
    return columns


def stage3b_columns() -> list[str]:
    columns = [
        "gaia_dr3_source_id",
        "survey_origin",
        "phase_space_6d_primary_ok",
        "phase_space_6d_sensitivity_ok",
        "phase_space_6d_geo_alternative_ok",
        *CENTRAL_METRICS,
        "r_cyl_gc_kpc_geo_alt",
        "z_gc_kpc_geo_alt",
        "v_rot_gc_kms_geo_alt",
    ]
    for label in LABELS:
        columns.extend(
            [
                f"{label}_phase_space_primary_ok",
                f"{label}_phase_space_core_ok",
                f"{label}_phase_space_sensitivity_ok",
                f"{label}_phase_space_geo_alternative_ok",
            ]
        )
    return columns


def stage3c_columns() -> list[str]:
    columns = [
        "gaia_dr3_source_id",
        "phase_space_6d_primary_ok",
        "uncertainty_propagation_ok",
        "frame_vrot_sign_stable",
        "geo_estimator_paired",
    ]
    for metric in STAGE3C_METRICS:
        columns.extend(
            [
                f"{metric}__halfwidth",
                f"{metric}__frame_abs_envelope",
                f"{metric}__frame_envelope_over_mc_halfwidth",
                f"{metric}__geo_minus_photo",
                f"{metric}__geo_abs_shift_over_mc_halfwidth",
            ]
        )
    return columns


def source_column(label: str) -> str:
    return "alpha3_source" if label == "alpha3" else f"{label}_hom_source"


def label_value_column(label: str) -> str:
    return "alpha3_hom" if label == "alpha3" else f"{label}_hom"


def label_error_proxy_column(label: str) -> str:
    return "alpha3_hom_error_proxy" if label == "alpha3" else f"{label}_hom_error_proxy"


def label_outcome_available(frame: pd.DataFrame, label: str) -> np.ndarray:
    """Return the frozen finite-outcome guard for an analysis label.

    Stage 2C deliberately defines ``alpha3_hom`` only when all three component
    labels are primary. Its ``alpha3_sensitivity_ok`` flag can nevertheless be
    true when all components are sensitivity-eligible. Downstream gradient
    cohorts therefore require an actually stored value and a finite,
    non-negative transport-error proxy in addition to the upstream flag.
    """

    values = number(frame, label_value_column(label))
    errors = number(frame, label_error_proxy_column(label))
    return np.isfinite(values) & np.isfinite(errors) & (errors >= 0.0)


def radial_domain(values: np.ndarray, policy: Mapping[str, Any]) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    lower = float(policy["lower_kpc"])
    upper = float(policy["upper_kpc"])
    lower_ok = values >= lower if bool(policy["lower_inclusive"]) else values > lower
    upper_ok = values <= upper if bool(policy["upper_inclusive"]) else values < upper
    return np.isfinite(values) & lower_ok & upper_ok


def healpix_from_source_id(
    values: Sequence[int] | np.ndarray | pd.Series,
    *,
    level: int,
    source_level: int = 12,
    low_bits: int = 35,
) -> np.ndarray:
    if not (0 <= int(level) <= int(source_level)):
        raise ValueError("HEALPix level must lie between zero and the source-ID level")
    ids = np.asarray(values, dtype=np.int64)
    if np.any(ids <= 0):
        raise ValueError("Gaia source IDs must be positive")
    shift = int(low_bits) + 2 * (int(source_level) - int(level))
    return np.right_shift(ids, shift).astype(np.int32)


def common_support(
    frame: pd.DataFrame,
    label: str,
    policy: Mapping[str, Any],
) -> tuple[np.ndarray, list[dict[str, Any]]]:
    base = flag(frame, f"{label}_gradient_primary_ok")
    sources = frame[source_column(label)].astype("string").fillna("NOT_AVAILABLE")
    lower_q = float(policy["lower_quantile"])
    upper_q = float(policy["upper_quantile"])
    minimum = int(policy["minimum_source_rows"])
    groups = tuple(str(value) for value in policy["source_groups"])
    if groups != SOURCE_GROUPS:
        raise ValueError(f"Unexpected source groups: {groups}")

    output = base.copy()
    rows: list[dict[str, Any]] = []
    for covariate in policy["covariates"]:
        values = number(frame, str(covariate))
        bounds: dict[str, tuple[int, float, float]] = {}
        for group in groups:
            selected = base & (sources.to_numpy(dtype=str) == group) & np.isfinite(values)
            group_values = values[selected]
            if len(group_values) < minimum:
                raise ValueError(
                    f"{label}/{covariate}/{group} has {len(group_values)} rows; "
                    f"minimum={minimum}"
                )
            bounds[group] = (
                int(len(group_values)),
                float(np.quantile(group_values, lower_q)),
                float(np.quantile(group_values, upper_q)),
            )
        intersection_low = max(bounds[group][1] for group in groups)
        intersection_high = min(bounds[group][2] for group in groups)
        valid = bool(np.isfinite(intersection_low) and intersection_low < intersection_high)
        if not valid:
            raise ValueError(f"Empty common-support interval for {label}/{covariate}")
        output &= np.isfinite(values) & (values >= intersection_low) & (values <= intersection_high)
        rows.append(
            {
                "label": label,
                "covariate": str(covariate),
                "lower_quantile": lower_q,
                "upper_quantile": upper_q,
                "apogee_rows": bounds[groups[0]][0],
                "apogee_q_low": bounds[groups[0]][1],
                "apogee_q_high": bounds[groups[0]][2],
                "galah_rows": bounds[groups[1]][0],
                "galah_q_low": bounds[groups[1]][1],
                "galah_q_high": bounds[groups[1]][2],
                "intersection_low": intersection_low,
                "intersection_high": intersection_high,
                "overlap_valid": valid,
            }
        )
    return output, rows


def covariate_balance(
    frame: pd.DataFrame,
    label: str,
    policy: Mapping[str, Any],
) -> list[dict[str, Any]]:
    sources = frame[source_column(label)].astype("string").fillna("NOT_AVAILABLE").to_numpy(str)
    scopes = {
        "NOMINAL": flag(frame, f"{label}_gradient_primary_ok"),
        "COMMON_SUPPORT": flag(frame, f"{label}_gradient_common_support_ok"),
    }
    rows: list[dict[str, Any]] = []
    for scope_name, scope in scopes.items():
        for covariate in policy["covariates"]:
            values = number(frame, str(covariate))
            group_values: dict[str, np.ndarray] = {}
            for group in SOURCE_GROUPS:
                selected = scope & (sources == group) & np.isfinite(values)
                group_values[group] = values[selected]
            left = group_values[SOURCE_GROUPS[0]]
            right = group_values[SOURCE_GROUPS[1]]
            if len(left) < 2 or len(right) < 2:
                raise ValueError(f"Insufficient balance rows for {label}/{scope_name}/{covariate}")
            pooled = float(np.sqrt((np.var(left, ddof=1) + np.var(right, ddof=1)) / 2.0))
            smd = float((np.mean(right) - np.mean(left)) / pooled) if pooled > 0.0 else 0.0
            rows.append(
                {
                    "label": label,
                    "scope": scope_name,
                    "covariate": str(covariate),
                    "apogee_rows": int(len(left)),
                    "galah_rows": int(len(right)),
                    "apogee_mean": float(np.mean(left)),
                    "galah_mean": float(np.mean(right)),
                    "apogee_median": float(np.median(left)),
                    "galah_median": float(np.median(right)),
                    "apogee_q10": float(np.quantile(left, 0.10)),
                    "apogee_q90": float(np.quantile(left, 0.90)),
                    "galah_q10": float(np.quantile(right, 0.10)),
                    "galah_q90": float(np.quantile(right, 0.90)),
                    "standardized_mean_difference_galah_minus_apogee": smd,
                }
            )
    return rows


def spatial_block_summary(frame: pd.DataFrame) -> pd.DataFrame:
    primary = flag(frame, "phase_space_6d_primary_ok")
    origins = frame["survey_origin"].astype("string").fillna("UNKNOWN").to_numpy(str)
    scopes: list[tuple[str, np.ndarray]] = [("ALL_PRIMARY_6D", primary)]
    for origin in sorted(set(origins[primary])):
        scopes.append((str(origin), primary & (origins == origin)))
    rows: list[dict[str, Any]] = []
    blocks = pd.to_numeric(frame["gaia_healpix5"], errors="raise").to_numpy(np.int32)
    for scope_name, selected in scopes:
        counts = pd.Series(blocks[selected]).value_counts(sort=False).to_numpy(dtype=int)
        rows.append(
            {
                "scope": scope_name,
                "stars": int(selected.sum()),
                "occupied_blocks": int(len(counts)),
                "minimum_stars_per_block": int(np.min(counts)),
                "q10_stars_per_block": float(np.quantile(counts, 0.10)),
                "q25_stars_per_block": float(np.quantile(counts, 0.25)),
                "median_stars_per_block": float(np.quantile(counts, 0.50)),
                "q75_stars_per_block": float(np.quantile(counts, 0.75)),
                "q90_stars_per_block": float(np.quantile(counts, 0.90)),
                "q95_stars_per_block": float(np.quantile(counts, 0.95)),
                "q99_stars_per_block": float(np.quantile(counts, 0.99)),
                "maximum_stars_per_block": int(np.max(counts)),
            }
        )
    return pd.DataFrame(rows)


def runtime_definition() -> dict[str, str]:
    import pandas
    import numpy
    import yaml as pyyaml

    return {
        "numpy": numpy.__version__,
        "pandas": pandas.__version__,
        "pyarrow": pyarrow.__version__,
        "pyyaml": pyyaml.__version__,
    }


def design_definition(config: Mapping[str, Any], output_columns: Sequence[str]) -> dict[str, Any]:
    contract = config["analysis_contract"]
    return {
        "stage": "4A outcome-free analysis fusion and transportability contract",
        "protocol_version": str(config["project"]["version"]),
        "labels": list(contract["labels"]),
        "radial_domain": dict(contract["radial_domain"]),
        "disc_height_sensitivity": dict(contract["disc_height_sensitivity"]),
        "common_support": dict(contract["common_support"]),
        "label_outcome_availability": dict(contract["label_outcome_availability"]),
        "spatial_block": dict(contract["spatial_block"]),
        "population_feature_contract": dict(contract["population_feature_contract"]),
        "forbidden_labels": list(contract["forbidden_labels"]),
        "upstream_stage3c_convergence": {
            "short_draws": int(config["stage3c_frozen"]["convergence_draws"]),
            "full_draws": int(config["stage3c_frozen"]["full_draws"]),
            "note": (
                "Stage 3C v0.7.0 validation gate text says 64-to-128, but the "
                "frozen method and convergence table correctly use 128-to-256. "
                "Stage 4A records the numerical contract without altering Stage 3C science."
            ),
        },
        "runtime": runtime_definition(),
        "output_columns": list(output_columns),
        "science_boundary": dict(config["science_boundary"]),
    }
