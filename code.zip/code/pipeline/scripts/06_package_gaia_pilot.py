from __future__ import annotations

import argparse
import os
import zipfile
from pathlib import Path

from stage1_common import (
    atomic_write_json,
    configured_paths,
    load_config,
    read_json,
    setup_logger,
    sha256_file,
    utc_now,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/stage1.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    paths = configured_paths(config, root)
    logger = setup_logger(
        paths["log_dir"] / "06_package_gaia_pilot.log",
        "stage1.gaia.pilot.package",
    )
    validation_path = paths["output_dir"] / "gaia_pilot_validation.json"
    if not validation_path.exists():
        raise FileNotFoundError("Pilot validation output is missing.")
    validation = read_json(validation_path)
    if not validation.get("overall_passed", False):
        raise RuntimeError(
            "Gaia pilot validation did not pass; checkpoint was not created."
        )
    summary_path = paths["output_dir"] / "gaia_pilot_query_summary.json"
    summary = read_json(summary_path)
    namespace = str(summary["selection_sha256"])[:16]
    metadata_dir = (
        paths["interim_dir"] / "gaia_dr3_pilot" / namespace / "metadata"
    )

    output_names = (
        "catalogue_ingest_summary.json",
        "gaia_identifier_audit.json",
        "stage1_census_summary.json",
        "sample_flow_stage1.csv",
        "within_survey_duplicate_audit.csv",
        "stage1_validation.json",
        "stage1_validation_report.md",
        "gaia_pilot_selection_manifest.json",
        "gaia_pilot_query_summary.json",
        "gaia_pilot_validation.json",
        "gaia_pilot_validation_report.md",
        "gaia_pilot_column_completeness.csv",
        "gaia_pilot_origin_flow.csv",
        "stage1_census_adjudication_v0_1_2.json",
    )
    include: list[Path] = [paths["output_dir"] / name for name in output_names]
    include.extend(sorted(metadata_dir.glob("chunk_*.json")))
    include.extend(
        paths["log_dir"] / name
        for name in (
            "04_query_gaia_pilot.log",
            "05_validate_gaia_pilot.log",
        )
    )
    include.extend(
        root / relative
        for relative in (
            "config/stage1.yml",
            "scripts/04_query_gaia_dr3.py",
            "scripts/05_validate_gaia_pilot.py",
            "scripts/gaia_query_logic.py",
            "PROTOCOL.md",
            "PILOT_README_UZ.md",
            "HOTFIX_V0_1_2_README_UZ.md",
        )
    )
    missing = [str(path) for path in include if not path.exists()]
    if missing:
        raise FileNotFoundError(
            "Checkpoint inputs are missing:\n" + "\n".join(missing)
        )
    include = sorted({path.resolve() for path in include})

    query_version = str(config["gaia"]["query_protocol_version"])
    version_token = query_version.replace(".", "_")
    package_name = f"stage1_gaia_pilot_checkpoint_v{version_token}"
    manifest = {
        "package": package_name,
        "census_protocol_version": config["project"]["version"],
        "query_protocol_version": query_version,
        "created_utc": utc_now(),
        "selection_sha256": summary["selection_sha256"],
        "files": [
            {
                "path": str(path.relative_to(root)).replace("\\", "/"),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
            for path in include
        ],
        "excluded": [
            "official raw FITS catalogues",
            "survey-level and star-level parquet tables",
            "20,000-row Gaia/Bailer-Jones pilot parquet tables",
            "full-query cache",
        ],
    }
    manifest_path = paths["output_dir"] / "gaia_pilot_package_manifest.json"
    atomic_write_json(manifest, manifest_path)
    include.append(manifest_path.resolve())

    output_zip = root / f"{package_name}.zip"
    temporary = output_zip.with_suffix(".zip.tmp")
    with zipfile.ZipFile(
        temporary,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
    ) as archive:
        for path in sorted(include):
            archive.write(
                path,
                arcname=str(path.relative_to(root)).replace("\\", "/"),
            )
    os.replace(temporary, output_zip)
    logger.info(
        "Pilot checkpoint created: %s (%.2f MiB)",
        output_zip,
        output_zip.stat().st_size / 2**20,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
