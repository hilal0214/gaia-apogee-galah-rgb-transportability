from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from stage1_common import (
    atomic_write_json,
    clean_string_series,
    configured_paths,
    finite_count,
    frame_counts,
    load_config,
    normalise_id_series,
    numeric_series,
    read_fits_columns,
    setup_logger,
    table_suffix,
    utc_now,
    write_frame,
)


LABELS = ("fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe")


APOGEE_COLUMNS = {
    "apogee_id": ("APOGEE_ID",),
    # The physical DR17 synspec_rev1 FITS header uses GAIAEDR3_SOURCE_ID.
    # Gaia EDR3 and DR3 have an identical source list, so this identifier can
    # be joined directly to gaiadr3.gaia_source.
    "gaia_dr3_source_id": ("GAIAEDR3_SOURCE_ID",),
    "ra": ("RA",),
    "dec": ("DEC",),
    "l": ("GLON",),
    "b": ("GLAT",),
    "telescope": ("TELESCOPE",),
    "field": ("FIELD",),
    "survey_name": ("SURVEY",),
    "nvisits": ("NVISITS",),
    "snr": ("SNR",),
    "snrev": ("SNREV",),
    "starflag": ("STARFLAG",),
    "aspcapflag": ("ASPCAPFLAG",),
    "teff": ("TEFF",),
    "teff_err": ("TEFF_ERR",),
    "logg": ("LOGG",),
    "logg_err": ("LOGG_ERR",),
    "fe_h": ("FE_H",),
    "fe_h_err": ("FE_H_ERR",),
    "fe_h_flag": ("FE_H_FLAG",),
    "mg_fe": ("MG_FE",),
    "mg_fe_err": ("MG_FE_ERR",),
    "mg_fe_flag": ("MG_FE_FLAG",),
    "si_fe": ("SI_FE",),
    "si_fe_err": ("SI_FE_ERR",),
    "si_fe_flag": ("SI_FE_FLAG",),
    "ca_fe": ("CA_FE",),
    "ca_fe_err": ("CA_FE_ERR",),
    "ca_fe_flag": ("CA_FE_FLAG",),
    "ni_fe": ("NI_FE",),
    "ni_fe_err": ("NI_FE_ERR",),
    "ni_fe_flag": ("NI_FE_FLAG",),
    "j_mag": ("J",),
    "h_mag": ("H",),
    "ks_mag": ("K",),
    "rv": ("VHELIO_AVG",),
    "rv_err": ("VERR",),
}


GALAH_COLUMNS = {
    "sobject_id": ("sobject_id",),
    "gaia_dr3_source_id": ("gaiadr3_source_id",),
    "ra": ("ra",),
    "dec": ("dec",),
    "field": ("field_id",),
    "survey_name": ("survey_name",),
    "setup": ("setup",),
    "snr_px_ccd3": ("snr_px_ccd3",),
    "flag_sp": ("flag_sp",),
    "flag_sp_fit": ("flag_sp_fit",),
    "flag_red": ("flag_red",),
    "teff": ("teff",),
    "teff_err": ("e_teff",),
    "logg": ("logg",),
    "logg_err": ("e_logg",),
    "fe_h": ("fe_h",),
    "fe_h_err": ("e_fe_h",),
    "fe_h_flag": ("flag_fe_h",),
    "mg_fe": ("mg_fe",),
    "mg_fe_err": ("e_mg_fe",),
    "mg_fe_flag": ("flag_mg_fe",),
    "si_fe": ("si_fe",),
    "si_fe_err": ("e_si_fe",),
    "si_fe_flag": ("flag_si_fe",),
    "ca_fe": ("ca_fe",),
    "ca_fe_err": ("e_ca_fe",),
    "ca_fe_flag": ("flag_ca_fe",),
    "ni_fe": ("ni_fe",),
    "ni_fe_err": ("e_ni_fe",),
    "ni_fe_flag": ("flag_ni_fe",),
    "phot_g_mean_mag": ("phot_g_mean_mag",),
    "bp_rp": ("bp_rp",),
    "j_mag": ("j_m",),
    "h_mag": ("h_m",),
    "ks_mag": ("ks_m",),
    "ruwe_catalogue": ("ruwe",),
    "parallax_catalogue": ("parallax",),
    "parallax_error_catalogue": ("parallax_error",),
    "r_med_catalogue_pc": ("r_med",),
    "r_lo_catalogue_pc": ("r_lo",),
    "r_hi_catalogue_pc": ("r_hi",),
    "rv": ("rv_comp_1",),
    "rv_err": ("e_rv_comp_1",),
}


def normalise_common(frame: pd.DataFrame, survey: str) -> pd.DataFrame:
    frame = frame.copy()
    frame.insert(0, "survey_row_index", np.arange(len(frame), dtype=np.int64))
    frame.insert(1, "survey", survey)
    frame.insert(
        2,
        "gaia_identifier_release",
        "EDR3" if survey == "APOGEE" else "DR3",
    )
    for column in frame.columns:
        if column in {
            "survey",
            "gaia_identifier_release",
            "apogee_id",
            "telescope",
            "field",
            "survey_name",
            "setup",
        }:
            frame[column] = clean_string_series(frame[column])
        elif column not in {"survey_row_index"}:
            frame[column] = numeric_series(frame[column])
    if "gaia_dr3_source_id" in frame:
        frame["gaia_dr3_source_id"] = normalise_id_series(frame["gaia_dr3_source_id"])
    for identifier in ("sobject_id",):
        if identifier in frame:
            frame[identifier] = normalise_id_series(frame[identifier])
    return frame


def add_audit_flags(
    frame: pd.DataFrame, survey: str, selection: dict
) -> pd.DataFrame:
    result = frame.copy()
    gate = selection["broad_red_giant"]
    result["broad_red_giant"] = (
        result["teff"].gt(float(gate["teff_min_k"]))
        & result["teff"].lt(float(gate["teff_max_k"]))
        & result["logg"].gt(float(gate["logg_min_dex"]))
        & result["logg"].lt(float(gate["logg_max_dex"]))
    )
    result["finite_primary_label_count"] = finite_count(
        result, ["fe_h", "mg_fe", "si_fe", "ca_fe"]
    )
    quality = selection["quality_audit"]
    if survey == "APOGEE":
        result["has_gaia_input_id"] = result["gaia_dr3_source_id"].gt(0)
        result["stellar_parameter_quality"] = (
            result["aspcapflag"].fillna(-1).eq(0)
            & result["starflag"].fillna(-1).eq(0)
            & result["snrev"].ge(float(quality["apogee_snrev_min"]))
        )
        for label in LABELS:
            result[f"valid_{label}"] = (
                result[label].notna()
                & result[f"{label}_err"].notna()
                & result[f"{label}_err"].gt(0)
                & result[f"{label}_flag"].fillna(-1).eq(0)
                & result["aspcapflag"].fillna(-1).eq(0)
            )
    else:
        result["has_gaia_input_id"] = result["gaia_dr3_source_id"].gt(0)
        result["stellar_parameter_quality"] = (
            result["flag_sp"].fillna(-1).eq(0)
            & result["snr_px_ccd3"].gt(float(quality["galah_snr_px_ccd3_min"]))
        )
        # GALAH DR4 documentation explicitly says not to use flag_fe_h.
        result["valid_fe_h"] = (
            result["fe_h"].notna()
            & result["fe_h_err"].notna()
            & result["fe_h_err"].gt(0)
            & result["flag_sp"].fillna(-1).eq(0)
        )
        for label in ("mg_fe", "si_fe", "ca_fe", "ni_fe"):
            result[f"valid_{label}"] = (
                result[label].notna()
                & result[f"{label}_err"].notna()
                & result[f"{label}_err"].gt(0)
                & result[f"{label}_flag"].fillna(-1).eq(0)
                & result["flag_sp"].fillna(-1).eq(0)
            )
    result["broad_rg_and_quality"] = (
        result["broad_red_giant"] & result["stellar_parameter_quality"]
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/stage1.yml")
    parser.add_argument("--allow-row-count-mismatch", action="store_true")
    args = parser.parse_args()

    config, root = load_config(args.config)
    paths = configured_paths(config, root)
    logger = setup_logger(paths["log_dir"] / "01_ingest_catalogues.log", "stage1.ingest")
    suffix = table_suffix(config)
    ingest_dir = paths["interim_dir"] / "ingest"
    ingest_dir.mkdir(parents=True, exist_ok=True)

    products: dict[str, pd.DataFrame] = {}
    resolutions = {}
    definitions = {
        "apogee": (APOGEE_COLUMNS, ("apogee_id", "gaia_dr3_source_id", "teff", "logg")),
        "galah": (GALAH_COLUMNS, ("sobject_id", "gaia_dr3_source_id", "teff", "logg")),
    }
    for name, (column_map, required) in definitions.items():
        spec = config["catalogues"][name]
        raw_path = paths["raw_dir"] / spec["filename"]
        if not raw_path.exists():
            raise FileNotFoundError(
                f"Missing {raw_path}. Run 01_download_catalogues.bat first."
            )
        logger.info("Reading selected %s columns from %s", name.upper(), raw_path.name)
        frame, resolved, rows = read_fits_columns(
            raw_path, int(spec["hdu"]), column_map, required
        )
        expected = int(spec["expected_rows"])
        if rows != expected and not args.allow_row_count_mismatch:
            raise RuntimeError(f"{name} rows changed: {rows:,} != {expected:,}")
        frame = normalise_common(frame, name.upper())
        frame = add_audit_flags(frame, name.upper(), config["selection"])
        output = ingest_dir / f"{name}_rows{suffix}"
        write_frame(frame, output)
        logger.info("Wrote %s: %s rows", output, f"{len(frame):,}")
        products[name] = frame
        resolutions[name] = resolved

    flags = [
        "has_gaia_input_id",
        "broad_red_giant",
        "stellar_parameter_quality",
        "broad_rg_and_quality",
        "valid_fe_h",
        "valid_mg_fe",
        "valid_si_fe",
        "valid_ca_fe",
        "valid_ni_fe",
    ]
    summary = {
        "stage": "1A catalogue ingestion",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "raw_catalogue_rows": {
            "apogee": int(len(products["apogee"])),
            "galah": int(len(products["galah"])),
            "concatenated_total": int(len(products["apogee"]) + len(products["galah"])),
        },
        "counts": {
            name: frame_counts(frame, flags) for name, frame in products.items()
        },
        "column_resolution": resolutions,
        "gaia_identifier_semantics": {
            "apogee": {
                "catalogue_column": resolutions["apogee"]["gaia_dr3_source_id"],
                "catalogue_release": "Gaia EDR3",
                "join_target": "Gaia DR3",
                "join_rule": (
                    "direct source_id equality because the Gaia EDR3 and DR3 "
                    "source lists are identical"
                ),
            },
            "galah": {
                "catalogue_column": resolutions["galah"]["gaia_dr3_source_id"],
                "catalogue_release": "Gaia DR3",
                "join_target": "Gaia DR3",
                "join_rule": "direct source_id equality",
            },
        },
        "important_note": (
            "concatenated_total is not a unique-star union; cross-survey overlap is "
            "collapsed only after within-survey de-duplication on direct EDR3/DR3 IDs"
        ),
        "galah_flag_fe_h_used": False,
    }
    output_summary = paths["output_dir"] / "catalogue_ingest_summary.json"
    atomic_write_json(summary, output_summary)
    logger.info("Ingest summary written: %s", output_summary)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
