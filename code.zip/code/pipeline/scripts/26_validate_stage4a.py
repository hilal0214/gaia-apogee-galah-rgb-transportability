from __future__ import annotations

import argparse
import gc
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from stage4a_common import (
    LABELS,
    SOURCE_GROUPS,
    atomic_write_json,
    close_logger,
    common_support,
    covariate_balance,
    flag,
    healpix_from_source_id,
    ids_sha256,
    label_outcome_available,
    load_config,
    number,
    project_path,
    radial_domain,
    read_json,
    setup_logger,
    sha256_file,
    source_column,
    spatial_block_summary,
    stage2c_columns,
    stage3b_columns,
    stage3c_columns,
    utc_now,
)


def add_gate(
    gates: list[dict[str, Any]],
    name: str,
    passed: bool,
    observed: Any,
    expected: Any,
    detail: str,
) -> None:
    gates.append(
        {
            "name": name,
            "passed": bool(passed),
            "observed": observed,
            "expected": expected,
            "detail": detail,
        }
    )


def frame_equal(left: pd.DataFrame, right: pd.DataFrame, atol: float = 0.0) -> bool:
    if left.shape != right.shape or list(left.columns) != list(right.columns):
        return False
    for column in left.columns:
        if pd.api.types.is_numeric_dtype(left[column]) and pd.api.types.is_numeric_dtype(
            right[column]
        ):
            if not np.allclose(
                pd.to_numeric(left[column], errors="coerce").to_numpy(float),
                pd.to_numeric(right[column], errors="coerce").to_numpy(float),
                rtol=0.0,
                atol=atol,
                equal_nan=True,
            ):
                return False
        elif not left[column].astype("string").fillna("<NA>").equals(
            right[column].astype("string").fillna("<NA>")
        ):
            return False
    return True


def resolve_paths(config: dict[str, Any], root: Path) -> dict[str, Path]:
    a_dir = project_path(root, config["paths"]["stage2c_output_dir"])
    b_dir = project_path(root, config["paths"]["stage3b_output_dir"])
    c_dir = project_path(root, config["paths"]["stage3c_output_dir"])
    out = project_path(root, config["paths"]["output_dir"])
    a = config["stage2c_frozen"]
    b = config["stage3b_frozen"]
    c = config["stage3c_frozen"]
    o = config["outputs"]
    return {
        "stage2c_atlas": a_dir / a["atlas_file"],
        "stage2c_summary": a_dir / a["build_summary_file"],
        "stage2c_freeze": a_dir / a["freeze_manifest_file"],
        "stage2c_validation": a_dir / a["validation_file"],
        "stage2c_report": a_dir / a["validation_report_file"],
        "stage2c_package": a_dir / a["package_manifest_file"],
        "stage3b_phase": b_dir / b["phase_space_layer_file"],
        "stage3b_summary": b_dir / b["build_summary_file"],
        "stage3b_freeze": b_dir / b["freeze_manifest_file"],
        "stage3b_validation": b_dir / b["validation_file"],
        "stage3c_layer": c_dir / c["uncertainty_layer_file"],
        "stage3c_summary": c_dir / c["build_summary_file"],
        "stage3c_freeze": c_dir / c["freeze_manifest_file"],
        "stage3c_validation": c_dir / c["validation_file"],
        "stage3c_method": c_dir / c["method_definition_file"],
        "stage3c_package": c_dir / c["package_manifest_file"],
        "design_layer": out / o["design_layer_file"],
        "cohort_flow": out / o["cohort_flow_file"],
        "support_bounds": out / o["common_support_bounds_file"],
        "balance": out / o["covariate_balance_file"],
        "block_summary": out / o["spatial_block_summary_file"],
        "population_flow": out / o["population_feature_flow_file"],
        "definition": out / o["design_definition_file"],
        "build_summary": out / o["build_summary_file"],
        "freeze": out / o["freeze_manifest_file"],
        "validation": out / o["validation_file"],
        "report": out / o["validation_report_file"],
    }


def expected_input_hashes(config: dict[str, Any]) -> dict[str, str]:
    a = config["stage2c_frozen"]
    b = config["stage3b_frozen"]
    c = config["stage3c_frozen"]
    return {
        "stage2c_atlas": a["atlas_sha256"],
        "stage2c_summary": a["build_summary_sha256"],
        "stage2c_freeze": a["freeze_manifest_sha256"],
        "stage2c_validation": a["validation_sha256"],
        "stage2c_report": a["validation_report_sha256"],
        "stage2c_package": a["package_manifest_sha256"],
        "stage3b_phase": b["phase_space_layer_sha256"],
        "stage3b_summary": b["build_summary_sha256"],
        "stage3b_freeze": b["freeze_manifest_sha256"],
        "stage3b_validation": b["validation_sha256"],
        "stage3c_layer": c["uncertainty_layer_sha256"],
        "stage3c_summary": c["build_summary_sha256"],
        "stage3c_freeze": c["freeze_manifest_sha256"],
        "stage3c_validation": c["validation_sha256"],
        "stage3c_method": c["method_definition_sha256"],
        "stage3c_package": c["package_manifest_sha256"],
    }


def source_counts(frame: pd.DataFrame, selected: np.ndarray, column: str) -> dict[str, int]:
    values = frame[column].astype("string").fillna("NOT_AVAILABLE").to_numpy(str)
    return {
        "APOGEE_NATIVE": int((selected & (values == "APOGEE_NATIVE")).sum()),
        "GALAH_CORRECTED": int((selected & (values == "GALAH_CORRECTED")).sum()),
        "MIXED_OR_OTHER": int(
            (selected & ~np.isin(values, np.asarray(SOURCE_GROUPS, dtype=str))).sum()
        ),
    }


def recompute_cohort_flow(layer: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for label in LABELS:
        primary = flag(layer, f"{label}_gradient_primary_ok")
        common = flag(layer, f"{label}_gradient_common_support_ok")
        primary_sources = source_counts(layer, primary, source_column(label))
        common_sources = source_counts(layer, common, source_column(label))
        rows.append(
            {
                "label": label,
                "phase_space_primary_rows": int(
                    flag(layer, f"{label}_phase_space_primary_ok").sum()
                ),
                "gradient_primary_rows": int(primary.sum()),
                "gradient_core_rows": int(flag(layer, f"{label}_gradient_core_ok").sum()),
                "gradient_common_support_rows": int(common.sum()),
                "gradient_disc5_rows": int(flag(layer, f"{label}_gradient_disc5_ok").sum()),
                "gradient_geo_paired_rows": int(
                    flag(layer, f"{label}_gradient_geo_paired_ok").sum()
                ),
                "gradient_sensitivity_rows": int(
                    flag(layer, f"{label}_gradient_sensitivity_ok").sum()
                ),
                "primary_apogee_native_rows": primary_sources["APOGEE_NATIVE"],
                "primary_galah_corrected_rows": primary_sources["GALAH_CORRECTED"],
                "primary_mixed_or_other_rows": primary_sources["MIXED_OR_OTHER"],
                "common_apogee_native_rows": common_sources["APOGEE_NATIVE"],
                "common_galah_corrected_rows": common_sources["GALAH_CORRECTED"],
                "common_mixed_or_other_rows": common_sources["MIXED_OR_OTHER"],
            }
        )
    return pd.DataFrame(rows).sort_values("label", kind="mergesort").reset_index(drop=True)


def recompute_population_flow(layer: pd.DataFrame) -> pd.DataFrame:
    primary = (
        flag(layer, "phase_space_6d_primary_ok")
        & flag(layer, "fe_h_phase_space_primary_ok")
        & flag(layer, "alpha3_phase_space_primary_ok")
    )
    frame = primary & flag(layer, "frame_vrot_sign_stable")
    common = (
        primary
        & flag(layer, "fe_h_gradient_common_support_ok")
        & flag(layer, "alpha3_gradient_common_support_ok")
    )
    return pd.DataFrame(
        [
            {"stage": "candidate_vector", "rows": int(len(layer))},
            {"stage": "primary_6d", "rows": int(flag(layer, "phase_space_6d_primary_ok").sum())},
            {"stage": "fe_h_primary_6d", "rows": int(flag(layer, "fe_h_phase_space_primary_ok").sum())},
            {"stage": "alpha3_primary_6d", "rows": int(flag(layer, "alpha3_phase_space_primary_ok").sum())},
            {"stage": "population_feature_primary", "rows": int(primary.sum())},
            {"stage": "population_feature_frame_stable_sensitivity", "rows": int(frame.sum())},
            {
                "stage": "population_feature_gradient_common_support_sensitivity",
                "rows": int(common.sum()),
            },
        ]
    )


def validation_report(payload: dict[str, Any]) -> str:
    lines = [
        "# Stage 4A validation report",
        "",
        f"Overall passed: **{payload['overall_passed']}**",
        "",
        f"Gates: **{payload['n_passed']}/{payload['n_gates']}**",
        "",
        "| Gate | Result | Detail |",
        "|---|---:|---|",
    ]
    for gate in payload["gates"]:
        lines.append(
            f"| `{gate['name']}` | {'PASS' if gate['passed'] else 'FAIL'} | "
            f"{gate['detail'].replace('|', '/')} |"
        )
    lines.extend(
        [
            "",
            "Stage 4A freezes an outcome-free join and downstream cohort contract. "
            "It fits no abundance gradient or population model, performs no bootstrap, "
            "and creates no selection or regression weight.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Stage 4A analysis-design layer")
    parser.add_argument("--config", default="config/stage4a.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    paths = resolve_paths(config, root)
    output_dir = project_path(root, config["paths"]["output_dir"])
    logger = setup_logger(
        project_path(root, config["paths"]["log_dir"]) / "26_validate_stage4a.log",
        "stage4a.validate",
    )
    try:
        required_keys = [key for key in paths if key not in {"validation", "report"}]
        missing = [str(paths[key]) for key in required_keys if not paths[key].exists()]
        if missing:
            raise FileNotFoundError("Missing Stage 4A validation inputs: " + "; ".join(missing))
        gates: list[dict[str, Any]] = []
        tolerance = float(config["validation"]["numeric_absolute_tolerance"])

        expected_hashes = expected_input_hashes(config)
        observed_hashes = {key: sha256_file(paths[key]) for key in expected_hashes}
        add_gate(
            gates,
            "upstream_byte_identity",
            observed_hashes == expected_hashes,
            observed_hashes,
            expected_hashes,
            "all accepted Stage 2C, 3B, and 3C inputs are byte-identical",
        )

        upstream_validation_observed: dict[str, dict[str, Any]] = {}
        upstream_validation_expected: dict[str, dict[str, Any]] = {}
        for stage, config_key, path_key in (
            ("stage2c", "stage2c_frozen", "stage2c_validation"),
            ("stage3b", "stage3b_frozen", "stage3b_validation"),
            ("stage3c", "stage3c_frozen", "stage3c_validation"),
        ):
            payload = read_json(paths[path_key])
            expected_n = int(config[config_key]["expected_validation_gates"])
            upstream_validation_observed[stage] = {
                "overall_passed": bool(payload.get("overall_passed", False)),
                "n_passed": int(payload.get("n_passed", -1)),
                "n_gates": int(payload.get("n_gates", -1)),
            }
            upstream_validation_expected[stage] = {
                "overall_passed": True,
                "n_passed": expected_n,
                "n_gates": expected_n,
            }
        add_gate(
            gates,
            "upstream_validation",
            upstream_validation_observed == upstream_validation_expected,
            upstream_validation_observed,
            upstream_validation_expected,
            "Stages 2C, 3B, and 3C remain frozen PASS",
        )

        metadata_observed = {
            "stage2c": [
                int(pq.ParquetFile(paths["stage2c_atlas"]).metadata.num_rows),
                int(pq.ParquetFile(paths["stage2c_atlas"]).metadata.num_columns),
            ],
            "stage3b": [
                int(pq.ParquetFile(paths["stage3b_phase"]).metadata.num_rows),
                int(pq.ParquetFile(paths["stage3b_phase"]).metadata.num_columns),
            ],
            "stage3c": [
                int(pq.ParquetFile(paths["stage3c_layer"]).metadata.num_rows),
                int(pq.ParquetFile(paths["stage3c_layer"]).metadata.num_columns),
            ],
        }
        metadata_expected = {
            "stage2c": [
                int(config["stage2c_frozen"]["expected_rows"]),
                int(config["stage2c_frozen"]["expected_columns"]),
            ],
            "stage3b": [
                int(config["stage3b_frozen"]["expected_rows"]),
                int(config["stage3b_frozen"]["expected_columns"]),
            ],
            "stage3c": [
                int(config["stage3c_frozen"]["expected_rows"]),
                int(config["stage3c_frozen"]["expected_columns"]),
            ],
        }
        add_gate(
            gates,
            "frozen_input_metadata",
            metadata_observed == metadata_expected,
            metadata_observed,
            metadata_expected,
            "upstream Parquet row and column counts are exact",
        )

        logger.info("Reading Stage 4A and frozen source layers")
        layer = pd.read_parquet(paths["design_layer"])
        stage3b = pd.read_parquet(paths["stage3b_phase"], columns=stage3b_columns())
        stage3c = pd.read_parquet(paths["stage3c_layer"], columns=stage3c_columns())
        ids = pd.to_numeric(layer["gaia_dr3_source_id"], errors="raise").to_numpy(np.int64)
        ids3b = pd.to_numeric(stage3b["gaia_dr3_source_id"], errors="raise").to_numpy(np.int64)
        ids3c = pd.to_numeric(stage3c["gaia_dr3_source_id"], errors="raise").to_numpy(np.int64)

        logger.info("Reading Stage 2C selected columns and reconstructing the candidate join")
        stage2c_full = pd.read_parquet(paths["stage2c_atlas"], columns=stage2c_columns())
        ids2c_full = pd.to_numeric(
            stage2c_full["gaia_dr3_source_id"], errors="raise"
        ).to_numpy(np.int64)
        full_identity = (
            len(np.unique(ids2c_full)) == len(ids2c_full)
            and np.all(np.diff(ids2c_full) > 0)
            and ids_sha256(ids2c_full)
            == str(config["stage2c_frozen"]["expected_source_id_sha256"])
        )
        stage2c = stage2c_full.set_index("gaia_dr3_source_id").loc[ids3b].reset_index()
        del stage2c_full, ids2c_full
        gc.collect()
        candidate_hash = ids_sha256(ids)
        identity_observed = {
            "rows": int(len(ids)),
            "unique": int(len(np.unique(ids))),
            "strictly_sorted": bool(np.all(np.diff(ids) > 0)),
            "candidate_sha256": candidate_hash,
            "stage2c_full_identity": bool(full_identity),
            "stage2c_join_exact": bool(
                np.array_equal(
                    pd.to_numeric(stage2c["gaia_dr3_source_id"]).to_numpy(np.int64), ids
                )
            ),
            "stage3b_exact": bool(np.array_equal(ids3b, ids)),
            "stage3c_exact": bool(np.array_equal(ids3c, ids)),
        }
        identity_expected = {
            "rows": int(config["stage3b_frozen"]["expected_rows"]),
            "unique": int(config["stage3b_frozen"]["expected_rows"]),
            "strictly_sorted": True,
            "candidate_sha256": str(config["analysis_contract"]["candidate_id_sha256"]),
            "stage2c_full_identity": True,
            "stage2c_join_exact": True,
            "stage3b_exact": True,
            "stage3c_exact": True,
        }
        add_gate(
            gates,
            "candidate_identity_and_join",
            identity_observed == identity_expected,
            identity_observed,
            identity_expected,
            "393,834 source IDs join one to one across all three frozen layers",
        )

        definition = read_json(paths["definition"])
        build_summary = read_json(paths["build_summary"])
        freeze = read_json(paths["freeze"])
        schema_observed = {
            "rows": int(len(layer)),
            "columns": int(len(layer.columns)),
            "duplicate_columns": int(layer.columns.duplicated().sum()),
            "definition_columns_exact": list(layer.columns)
            == list(definition.get("output_columns", [])),
            "metadata_rows": int(pq.ParquetFile(paths["design_layer"]).metadata.num_rows),
            "metadata_columns": int(
                pq.ParquetFile(paths["design_layer"]).metadata.num_columns
            ),
        }
        schema_expected = {
            "rows": int(config["stage3b_frozen"]["expected_rows"]),
            "columns": int(len(layer.columns)),
            "duplicate_columns": 0,
            "definition_columns_exact": True,
            "metadata_rows": int(config["stage3b_frozen"]["expected_rows"]),
            "metadata_columns": int(len(layer.columns)),
        }
        add_gate(
            gates,
            "output_identity_and_schema",
            schema_observed == schema_expected,
            schema_observed,
            schema_expected,
            "the design layer has the exact frozen ID order and declared schema",
        )

        stage2c_preserved = frame_equal(layer[stage2c_columns()], stage2c[stage2c_columns()])
        add_gate(
            gates,
            "stage2c_semantic_preservation",
            stage2c_preserved,
            {"selected_columns": len(stage2c_columns()), "exact": stage2c_preserved},
            {"selected_columns": len(stage2c_columns()), "exact": True},
            "abundances, errors, support tiers, and provenance are copied without mutation",
        )

        stage3b_preserved = frame_equal(layer[stage3b_columns()], stage3b[stage3b_columns()])
        add_gate(
            gates,
            "stage3b_semantic_preservation",
            stage3b_preserved,
            {"selected_columns": len(stage3b_columns()), "exact": stage3b_preserved},
            {"selected_columns": len(stage3b_columns()), "exact": True},
            "nominal and alternative phase-space values and flags are unchanged",
        )

        stage3c_preserved = frame_equal(layer[stage3c_columns()], stage3c[stage3c_columns()])
        add_gate(
            gates,
            "stage3c_semantic_preservation",
            stage3c_preserved,
            {"selected_columns": len(stage3c_columns()), "exact": stage3c_preserved},
            {"selected_columns": len(stage3c_columns()), "exact": True},
            "formal uncertainty and frame/distance stress fields are unchanged",
        )
        del stage2c, stage3b, stage3c
        gc.collect()

        radial = radial_domain(
            number(layer, "r_cyl_gc_kpc"), config["analysis_contract"]["radial_domain"]
        )
        max_abs_z = float(
            config["analysis_contract"]["disc_height_sensitivity"]["maximum_abs_z_kpc"]
        )
        abs_z = np.abs(number(layer, "z_gc_kpc"))
        disc5 = radial & np.isfinite(abs_z) & (abs_z <= max_abs_z)
        domain_mismatches = {
            "abs_z": int(
                (~np.isclose(number(layer, "abs_z_gc_kpc"), abs_z, rtol=0.0, atol=tolerance, equal_nan=True)).sum()
            ),
            "radial": int((flag(layer, "radial_domain_primary") != radial).sum()),
            "disc5": int((flag(layer, "disc5_domain_sensitivity") != disc5).sum()),
        }
        add_gate(
            gates,
            "domain_formulas",
            sum(domain_mismatches.values()) == 0,
            domain_mismatches,
            {"abs_z": 0, "radial": 0, "disc5": 0},
            "strict 3<R<15 kpc and inclusive |Z|<=5 kpc flags are exact",
        )

        geo_radial = radial_domain(
            number(layer, "r_cyl_gc_kpc_geo_alt"),
            config["analysis_contract"]["radial_domain"],
        )
        paired_geo = flag(layer, "geo_estimator_paired")
        formula_mismatches: dict[str, int] = {}
        for label in LABELS:
            available = label_outcome_available(layer, label)
            formulas = {
                "primary": flag(layer, f"{label}_phase_space_primary_ok")
                & radial
                & available,
                "core": flag(layer, f"{label}_phase_space_core_ok")
                & radial
                & available,
                "disc5": flag(layer, f"{label}_phase_space_primary_ok")
                & disc5
                & available,
                "geo_paired": flag(layer, f"{label}_phase_space_primary_ok")
                & radial
                & paired_geo
                & geo_radial
                & available,
                "sensitivity": flag(layer, f"{label}_phase_space_sensitivity_ok")
                & radial
                & available,
            }
            for suffix, expected in formulas.items():
                formula_mismatches[f"{label}_{suffix}"] = int(
                    (flag(layer, f"{label}_gradient_{suffix}_ok") != expected).sum()
                )
        add_gate(
            gates,
            "label_cohort_formulas",
            sum(formula_mismatches.values()) == 0,
            {"total_mismatches": int(sum(formula_mismatches.values())), **formula_mismatches},
            {"total_mismatches": 0},
            "all six label-specific nominal and sensitivity cohorts are recomputed exactly",
        )

        availability_failures: dict[str, int] = {}
        for label in LABELS:
            available = label_outcome_available(layer, label)
            for suffix in (
                "primary",
                "core",
                "disc5",
                "geo_paired",
                "sensitivity",
                "common_support",
            ):
                selected = flag(layer, f"{label}_gradient_{suffix}_ok")
                availability_failures[f"{label}_{suffix}"] = int(
                    (selected & ~available).sum()
                )
        add_gate(
            gates,
            "label_outcome_availability",
            sum(availability_failures.values()) == 0,
            {
                "total_violations": int(sum(availability_failures.values())),
                **availability_failures,
            },
            {"total_violations": 0},
            "every gradient cohort has a finite label and finite non-negative error proxy",
        )

        nesting_failures: dict[str, int] = {}
        for label in LABELS:
            primary = flag(layer, f"{label}_gradient_primary_ok")
            for suffix in ("core", "disc5", "geo_paired", "common_support"):
                selected = flag(layer, f"{label}_gradient_{suffix}_ok")
                nesting_failures[f"{label}_{suffix}"] = int((selected & ~primary).sum())
        population_primary = flag(layer, "population_feature_primary_ok")
        nesting_failures["population_frame_stable"] = int(
            (flag(layer, "population_feature_frame_stable_ok") & ~population_primary).sum()
        )
        nesting_failures["population_gradient_common"] = int(
            (
                flag(
                    layer,
                    "population_feature_gradient_common_support_sensitivity_ok",
                )
                & ~population_primary
            ).sum()
        )
        add_gate(
            gates,
            "nested_cohort_contract",
            sum(nesting_failures.values()) == 0,
            {"total_violations": int(sum(nesting_failures.values())), **nesting_failures},
            {"total_violations": 0},
            "core, disc-height, geometric, common-support, and population sensitivities are nested",
        )

        support_policy = config["analysis_contract"]["common_support"]
        support_rows: list[dict[str, Any]] = []
        support_flag_mismatches: dict[str, int] = {}
        for label in LABELS:
            selected, rows = common_support(layer, label, support_policy)
            support_flag_mismatches[label] = int(
                (selected != flag(layer, f"{label}_gradient_common_support_ok")).sum()
            )
            support_rows.extend(rows)
        recomputed_support = pd.DataFrame(support_rows).sort_values(
            ["label", "covariate"], kind="mergesort"
        ).reset_index(drop=True)
        stored_support = pd.read_csv(paths["support_bounds"]).sort_values(
            ["label", "covariate"], kind="mergesort"
        ).reset_index(drop=True)
        support_table_exact = frame_equal(stored_support, recomputed_support, atol=tolerance)
        add_gate(
            gates,
            "common_support_recompute",
            sum(support_flag_mismatches.values()) == 0 and support_table_exact,
            {
                "flag_mismatches": int(sum(support_flag_mismatches.values())),
                "table_rows": int(len(stored_support)),
                "table_exact": support_table_exact,
            },
            {"flag_mismatches": 0, "table_rows": 24, "table_exact": True},
            "1st-to-99th percentile rectangular survey-overlap bounds are reproduced",
        )

        balance_rows: list[dict[str, Any]] = []
        for label in LABELS:
            balance_rows.extend(covariate_balance(layer, label, support_policy))
        recomputed_balance = pd.DataFrame(balance_rows).sort_values(
            ["label", "scope", "covariate"], kind="mergesort"
        ).reset_index(drop=True)
        stored_balance = pd.read_csv(paths["balance"]).sort_values(
            ["label", "scope", "covariate"], kind="mergesort"
        ).reset_index(drop=True)
        balance_exact = frame_equal(stored_balance, recomputed_balance, atol=tolerance)
        add_gate(
            gates,
            "covariate_balance_recompute",
            balance_exact and len(stored_balance) == 48,
            {"rows": int(len(stored_balance)), "exact": balance_exact},
            {"rows": 48, "exact": True},
            "nominal and common-support source balance diagnostics are reproduced",
        )

        stored_flow = pd.read_csv(paths["cohort_flow"]).sort_values(
            "label", kind="mergesort"
        ).reset_index(drop=True)
        recomputed_flow = recompute_cohort_flow(layer)
        flow_exact = frame_equal(stored_flow, recomputed_flow)
        add_gate(
            gates,
            "label_and_source_flow_recompute",
            flow_exact and len(stored_flow) == len(LABELS),
            {"rows": int(len(stored_flow)), "exact": flow_exact},
            {"rows": int(len(LABELS)), "exact": True},
            "label cohorts and APOGEE/GALAH provenance counts are exact",
        )

        block_policy = config["analysis_contract"]["spatial_block"]
        expected_blocks = healpix_from_source_id(
            ids,
            level=int(block_policy["healpix_level"]),
            source_level=int(block_policy["source_id_level"]),
            low_bits=int(block_policy["source_id_low_bits"]),
        )
        block_mismatches = int(
            (pd.to_numeric(layer["gaia_healpix5"]).to_numpy(np.int32) != expected_blocks).sum()
        )
        stored_blocks = pd.read_csv(paths["block_summary"])
        recomputed_blocks = spatial_block_summary(layer)
        block_table_exact = frame_equal(stored_blocks, recomputed_blocks, atol=tolerance)
        add_gate(
            gates,
            "healpix_and_spatial_block_summary",
            block_mismatches == 0 and block_table_exact,
            {
                "id_formula_mismatches": block_mismatches,
                "summary_rows": int(len(stored_blocks)),
                "summary_exact": block_table_exact,
            },
            {
                "id_formula_mismatches": 0,
                "summary_rows": int(len(recomputed_blocks)),
                "summary_exact": True,
            },
            "nested Gaia HEALPix-5 identifiers and occupancy summaries are exact",
        )

        expected_population_primary = (
            flag(layer, "phase_space_6d_primary_ok")
            & flag(layer, "fe_h_phase_space_primary_ok")
            & flag(layer, "alpha3_phase_space_primary_ok")
        )
        expected_population_frame = expected_population_primary & flag(
            layer, "frame_vrot_sign_stable"
        )
        expected_population_common = (
            expected_population_primary
            & flag(layer, "fe_h_gradient_common_support_ok")
            & flag(layer, "alpha3_gradient_common_support_ok")
        )
        population_mismatches = {
            "primary": int(
                (flag(layer, "population_feature_primary_ok") != expected_population_primary).sum()
            ),
            "frame": int(
                (
                    flag(layer, "population_feature_frame_stable_ok")
                    != expected_population_frame
                ).sum()
            ),
            "gradient_common": int(
                (
                    flag(
                        layer,
                        "population_feature_gradient_common_support_sensitivity_ok",
                    )
                    != expected_population_common
                ).sum()
            ),
        }
        stored_population = pd.read_csv(paths["population_flow"])
        recomputed_population = recompute_population_flow(layer)
        population_flow_exact = frame_equal(stored_population, recomputed_population)
        add_gate(
            gates,
            "population_feature_formula_and_flow",
            sum(population_mismatches.values()) == 0 and population_flow_exact,
            {
                "flag_mismatches": int(sum(population_mismatches.values())),
                "flow_rows": int(len(stored_population)),
                "flow_exact": population_flow_exact,
            },
            {"flag_mismatches": 0, "flow_rows": 7, "flow_exact": True},
            "feature completeness and its sensitivity flags are exact; no labels are assigned",
        )

        science_paths = [
            paths["design_layer"],
            paths["cohort_flow"],
            paths["support_bounds"],
            paths["balance"],
            paths["block_summary"],
            paths["population_flow"],
            paths["definition"],
        ]
        science_hashes = {path.name: sha256_file(path) for path in science_paths}
        freeze_hashes = dict(science_hashes)
        freeze_hashes[paths["build_summary"].name] = sha256_file(paths["build_summary"])
        counts = build_summary.get("counts", {})
        hash_checks = {
            "build_outputs": build_summary.get("output_sha256") == science_hashes,
            "freeze_outputs": freeze.get("output_sha256") == freeze_hashes,
            "build_inputs": build_summary.get("input_sha256") == expected_hashes,
            "freeze_inputs": freeze.get("input_sha256") == expected_hashes,
            "candidate_hashes": build_summary.get("candidate_id_sha256")
            == candidate_hash
            == freeze.get("candidate_id_sha256"),
            "row_count": int(counts.get("rows", -1)) == len(layer),
            "column_count": int(counts.get("columns", -1)) == len(layer.columns),
            "primary_6d": int(counts.get("primary_6d", -1))
            == int(flag(layer, "phase_space_6d_primary_ok").sum()),
        }
        add_gate(
            gates,
            "output_hashes_and_freeze",
            all(hash_checks.values()),
            hash_checks,
            {key: True for key in hash_checks},
            "science-output hashes, build summary, and freeze manifest are internally exact",
        )

        boundary = config["science_boundary"]
        forbidden_fragments = (
            "coefficient",
            "intercept",
            "slope",
            "p_value",
            "pvalue",
            "bootstrap",
            "population_label",
            "population_probability",
            "membership_probability",
            "inverse_probability",
            "selection_weight",
            "regression_weight",
            "thin_disk",
            "thick_disk",
            "halo_probability",
        )
        forbidden_columns = [
            column
            for column in layer.columns
            if any(fragment in column.lower() for fragment in forbidden_fragments)
        ]
        forbidden_label_columns = [
            column
            for column in layer.columns
            if any(
                column.lower().startswith(f"{label}_")
                for label in config["analysis_contract"]["forbidden_labels"]
            )
        ]
        inferential_files = [
            path.name
            for path in output_dir.iterdir()
            if any(
                fragment in path.name.lower()
                for fragment in ("gradient_fit", "coefficient", "bootstrap", "population_label", "weight")
            )
        ]
        convergence = definition.get("upstream_stage3c_convergence", {})
        boundary_checks = {
            "definition_exact": definition.get("science_boundary") == boundary,
            "build_exact": build_summary.get("science_boundary") == boundary,
            "freeze_exact": freeze.get("science_boundary") == boundary,
            "all_inference_flags_false": all(
                not bool(boundary[key])
                for key in (
                    "abundance_gradients_fitted",
                    "gradient_coefficients_estimated",
                    "bootstrap_performed",
                    "population_model_fitted",
                    "population_labels_assigned",
                    "selection_function_corrected",
                    "inverse_probability_weights_created",
                    "abundance_uncertainty_used_as_regression_weight",
                )
            ),
            "forbidden_columns_absent": not forbidden_columns,
            "forbidden_labels_absent": not forbidden_label_columns,
            "inferential_files_absent": not inferential_files,
            "stage3c_convergence_corrected": int(convergence.get("short_draws", -1)) == 128
            and int(convergence.get("full_draws", -1)) == 256,
        }
        add_gate(
            gates,
            "science_boundary",
            all(boundary_checks.values()),
            {
                **boundary_checks,
                "forbidden_columns": forbidden_columns,
                "forbidden_label_columns": forbidden_label_columns,
                "inferential_files": inferential_files,
            },
            {key: True for key in boundary_checks},
            "Stage 4A stops before coefficients, bootstrap, population inference, or weights",
        )

        expected_gates = int(config["validation"]["expected_gates"])
        if len(gates) != expected_gates:
            raise RuntimeError(
                f"Internal validator definition error: gates={len(gates)}; expected={expected_gates}"
            )
        passed = sum(bool(gate["passed"]) for gate in gates)
        payload = {
            "stage": "4A validation",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": utc_now(),
            "overall_passed": passed == len(gates),
            "n_passed": int(passed),
            "n_gates": int(len(gates)),
            "gates": gates,
        }
        atomic_write_json(payload, paths["validation"])
        paths["report"].write_text(
            validation_report(payload), encoding="utf-8", newline="\n"
        )
        logger.info(
            "Stage 4A validation passed=%s; gates=%s/%s",
            payload["overall_passed"],
            passed,
            len(gates),
        )
        print(
            f"Stage 4A validation passed={payload['overall_passed']}; "
            f"gates={passed}/{len(gates)}"
        )
        return 0 if payload["overall_passed"] else 1
    finally:
        close_logger(logger)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
