from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

import numpy as np
import pandas as pd

from stage1_common import ensure_columns, normalise_id_series


GAIA_COLUMNS = (
    "source_id",
    "ra",
    "ra_error",
    "dec",
    "dec_error",
    "parallax",
    "parallax_error",
    "parallax_over_error",
    "pmra",
    "pmra_error",
    "pmdec",
    "pmdec_error",
    "ra_dec_corr",
    "ra_parallax_corr",
    "ra_pmra_corr",
    "ra_pmdec_corr",
    "dec_parallax_corr",
    "dec_pmra_corr",
    "dec_pmdec_corr",
    "parallax_pmra_corr",
    "parallax_pmdec_corr",
    "pmra_pmdec_corr",
    "astrometric_params_solved",
    "astrometric_n_good_obs_al",
    "astrometric_gof_al",
    "astrometric_excess_noise",
    "visibility_periods_used",
    "ruwe",
    "duplicated_source",
    "ipd_frac_multi_peak",
    "phot_g_mean_mag",
    "phot_bp_mean_mag",
    "phot_rp_mean_mag",
    "bp_rp",
    "phot_bp_rp_excess_factor",
    "radial_velocity",
    "radial_velocity_error",
    "rv_nb_transits",
    "grvs_mag",
)


DISTANCE_COLUMNS = (
    "source_id",
    "r_med_geo",
    "r_lo_geo",
    "r_hi_geo",
    "r_med_photogeo",
    "r_lo_photogeo",
    "r_hi_photogeo",
)


PILOT_ORIGINS = ("APOGEE_only", "GALAH_only", "overlap")


def ids_sha256(ids: np.ndarray | pd.Series) -> str:
    """Hash an ordered ID vector without platform-dependent byte order."""

    digest = hashlib.sha256()
    values = np.asarray(ids, dtype=np.int64)
    for value in values:
        digest.update(str(int(value)).encode("ascii"))
        digest.update(b"\n")
    return digest.hexdigest()


def query_signature(config: Mapping[str, Any]) -> str:
    payload = {
        "query_protocol_version": config["gaia"]["query_protocol_version"],
        "source_table": config["gaia"]["source_table"],
        "source_columns": list(GAIA_COLUMNS),
        "distance_table": config["gaia"]["distance_table"],
        "distance_columns": list(DISTANCE_COLUMNS),
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )
    return hashlib.sha256(encoded).hexdigest()


def splitmix64(values: np.ndarray, seed: int) -> np.ndarray:
    """Return deterministic 64-bit ranks for positive Gaia source IDs."""

    z = np.asarray(values, dtype=np.uint64).copy()
    with np.errstate(over="ignore"):
        z += np.uint64(seed) + np.uint64(0x9E3779B97F4A7C15)
        z = (z ^ (z >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)
        z ^= z >> np.uint64(31)
    return z


def select_stratified_pilot(
    master: pd.DataFrame,
    quotas: Mapping[str, int],
    seed: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    ensure_columns(
        master,
        ["gaia_dr3_source_id", "survey_origin"],
        "spectroscopic source master",
    )
    unknown = sorted(set(quotas) - set(PILOT_ORIGINS))
    if unknown:
        raise ValueError(f"Unknown pilot strata: {unknown}")
    missing = [origin for origin in PILOT_ORIGINS if origin not in quotas]
    if missing:
        raise ValueError(f"Pilot quotas missing strata: {missing}")

    working = master[["gaia_dr3_source_id", "survey_origin"]].copy()
    working["gaia_dr3_source_id"] = normalise_id_series(
        working["gaia_dr3_source_id"]
    )
    if not working["gaia_dr3_source_id"].gt(0).all():
        raise ValueError("Pilot source master contains non-positive Gaia IDs")
    if working["gaia_dr3_source_id"].duplicated().any():
        raise ValueError("Pilot source master contains duplicate Gaia IDs")

    selected: list[pd.DataFrame] = []
    available_counts: dict[str, int] = {}
    selected_counts: dict[str, int] = {}
    for origin in PILOT_ORIGINS:
        quota = int(quotas[origin])
        if quota <= 0:
            raise ValueError(f"Pilot quota for {origin} must be positive")
        stratum = working.loc[working["survey_origin"].eq(origin)].copy()
        available_counts[origin] = int(len(stratum))
        if len(stratum) < quota:
            raise ValueError(
                f"Pilot stratum {origin} has {len(stratum):,} rows; "
                f"quota is {quota:,}"
            )
        ids = stratum["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
        ranks = splitmix64(ids, seed)
        order = np.lexsort((ids, ranks))
        chosen = stratum.iloc[order[:quota]].copy()
        chosen["pilot_rank_uint64"] = ranks[order[:quota]]
        selected.append(chosen)
        selected_counts[origin] = int(len(chosen))

    result = pd.concat(selected, ignore_index=True)
    result = result.sort_values("gaia_dr3_source_id", kind="mergesort").reset_index(
        drop=True
    )
    ids = result["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
    audit = {
        "method": "stratified SplitMix64 rank; source_id tie-break; final source_id sort",
        "seed": int(seed),
        "available_by_origin": available_counts,
        "selected_by_origin": selected_counts,
        "selected_total": int(len(result)),
        "selection_sha256": ids_sha256(ids),
        "first_selected_id": int(ids[0]),
        "last_selected_id": int(ids[-1]),
    }
    return result, audit


def validate_source_chunk(frame: pd.DataFrame, requested: np.ndarray) -> dict[str, int]:
    ensure_columns(frame, ["source_id"], "Gaia source chunk")
    source_id = normalise_id_series(frame["source_id"])
    duplicates = int(source_id[source_id.gt(0)].duplicated().sum())
    returned = set(source_id.loc[source_id.gt(0)].astype(int))
    wanted = set(map(int, requested))
    return {
        "requested": len(wanted),
        "returned": len(returned),
        "missing": len(wanted - returned),
        "unexpected": len(returned - wanted),
        "duplicate_rows": duplicates,
    }


def validate_distance_chunk(
    frame: pd.DataFrame, requested: np.ndarray
) -> dict[str, int]:
    ensure_columns(frame, ["source_id"], "Bailer-Jones distance chunk")
    source_id = normalise_id_series(frame["source_id"])
    positive = source_id.loc[source_id.gt(0)]
    returned = set(positive.astype(int))
    wanted = set(map(int, requested))
    return {
        "requested": len(wanted),
        "returned": len(returned),
        "not_in_distance_table": len(wanted - returned),
        "unexpected": len(returned - wanted),
        "duplicate_rows": int(positive.duplicated().sum()),
    }


def exact_source_recovery(stats: Mapping[str, int]) -> bool:
    return (
        int(stats["missing"]) == 0
        and int(stats["unexpected"]) == 0
        and int(stats["duplicate_rows"]) == 0
        and int(stats["returned"]) == int(stats["requested"])
    )
