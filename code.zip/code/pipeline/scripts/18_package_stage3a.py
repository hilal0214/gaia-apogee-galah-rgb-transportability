from __future__ import annotations

import argparse
import os
import sys
import zipfile
from pathlib import Path
from typing import Any

from stage3a_common import (
    atomic_write_json,
    load_config,
    project_path,
    read_json,
    sha256_file,
    utc_now,
)


def file_record(root: Path, path: Path) -> dict[str, Any]:
    return {
        "path": str(path.relative_to(root)).replace("\\", "/"),
        "bytes": int(path.stat().st_size),
        "sha256": sha256_file(path),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Package Stage 3A outputs")
    parser.add_argument("--config", default="config/stage3a.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    outputs = config["outputs"]
    output_dir = project_path(root, config["paths"]["output_dir"])
    stage1_dir = project_path(root, config["paths"]["stage1_output_dir"])
    stage2c_dir = project_path(root, config["paths"]["stage2c_output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])

    validation_path = output_dir / outputs["validation_file"]
    validation = read_json(validation_path)
    if not validation.get("overall_passed", False):
        raise RuntimeError("Stage 3A validation is not PASS; refusing to package")

    relative_files = [
        "16_build_stage3a.bat",
        "17_validate_stage3a.bat",
        "18_package_stage3a.bat",
        "99_stage3a_selftest.bat",
        "run_stage3a_all.bat",
        "STAGE3A_PROTOCOL.md",
        "STAGE3A_README_UZ.md",
        "config/stage3a.yml",
        "scripts/16_build_stage3a.py",
        "scripts/17_validate_stage3a.py",
        "scripts/18_package_stage3a.py",
        "scripts/selftest_stage3a.py",
        "scripts/stage3a_common.py",
    ]
    files = [root / value for value in relative_files]
    files.extend(
        [
            log_dir / "16_build_stage3a.log",
            log_dir / "17_validate_stage3a.log",
            stage1_dir / config["stage1_frozen"]["query_summary_file"],
            stage1_dir / config["stage1_frozen"]["validation_file"],
            stage2c_dir / config["stage2c_frozen"]["build_summary_file"],
            stage2c_dir / config["stage2c_frozen"]["freeze_manifest_file"],
            stage2c_dir / config["stage2c_frozen"]["validation_file"],
            output_dir / outputs["quality_layer_file"],
            output_dir / outputs["cache_audit_file"],
            output_dir / outputs["gate_flow_file"],
            output_dir / outputs["origin_flow_file"],
            output_dir / outputs["label_flow_file"],
            output_dir / outputs["build_summary_file"],
            output_dir / outputs["freeze_manifest_file"],
            output_dir / outputs["validation_file"],
            output_dir / outputs["validation_report_file"],
        ]
    )
    missing = [str(path) for path in files if not path.exists()]
    if missing:
        raise FileNotFoundError("Cannot package missing files: " + "; ".join(missing))

    manifest = {
        "package": outputs["package_name"].removesuffix(".zip"),
        "stage": "3A",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "files": [file_record(root, path) for path in files],
        "upstream": {
            "stage1_release_sha256": config["stage1_frozen"]["release_sha256"],
            "stage2c_release_sha256": config["stage2c_frozen"]["release_sha256"],
        },
        "excluded": [
            "official raw FITS catalogues",
            "the 76 restartable Gaia cache Parquet chunks, frozen by per-file SHA-256",
            "the 333-MB Stage 2C transport atlas, referenced by exact SHA-256",
            "direct inverse-parallax distances",
            "Galactocentric phase space, speed cuts, gradients, and populations",
        ],
        "science_boundary": config["science_boundary"],
    }
    manifest_path = output_dir / outputs["package_manifest_file"]
    atomic_write_json(manifest, manifest_path)
    files_with_manifest = [*files, manifest_path]

    package_path = root / outputs["package_name"]
    temporary = package_path.with_name(f".{package_path.name}.tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(temporary, mode="w", allowZip64=True) as archive:
        for path in files_with_manifest:
            compress_type = (
                zipfile.ZIP_STORED
                if path.suffix.lower() == ".parquet"
                else zipfile.ZIP_DEFLATED
            )
            archive.write(
                path,
                arcname=str(path.relative_to(root)).replace("\\", "/"),
                compress_type=compress_type,
                compresslevel=None if compress_type == zipfile.ZIP_STORED else 6,
            )
    os.replace(temporary, package_path)
    print(f"Output bundle created: {package_path}")
    print(f"SHA-256: {sha256_file(package_path)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
