from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from stage2b_common import (
    ANALYSIS_SETS,
    COEFFICIENT_NAMES,
    ELEMENTS,
    assignment_sha256,
    atomic_write_json,
    calibration_metrics,
    canonical_json_sha256,
    close_logger,
    design_matrix,
    ids_sha256,
    load_config,
    project_path,
    read_json,
    setup_logger,
    sha256_file,
    to_python,
    utc_now,
)


def close_enough(observed: float, expected: float, tolerance: float = 1.0e-12) -> bool:
    return bool(np.isclose(float(observed), float(expected), atol=tolerance, rtol=0.0))


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate frozen Stage 2B products")
    parser.add_argument("--config", default="config/stage2b.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    stage2a_dir = project_path(root, config["paths"]["stage2a_output_dir"])
    output_dir = project_path(root, config["paths"]["output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "11_validate_stage2b.log", "stage2b.validate")

    upstream_paths = {
        "table": stage2a_dir / str(config["stage2a_frozen"]["frozen_overlap_file"]),
        "assignments": stage2a_dir / str(config["stage2a_frozen"]["assignment_file"]),
        "freeze": stage2a_dir / str(config["stage2a_frozen"]["freeze_manifest_file"]),
        "validation": stage2a_dir / "stage2a_validation.json",
    }
    output_paths = {
        "predictions": output_dir / "crossfit_predictions.parquet",
        "coefficients": output_dir / "calibration_coefficients.csv",
        "metrics": output_dir / "crossfit_metrics.csv",
        "fold_metrics": output_dir / "crossfit_fold_metrics.csv",
        "deploy": output_dir / "deployable_calibration_models.json",
        "summary": output_dir / "stage2b_build_summary.json",
        "freeze": output_dir / "stage2b_freeze_manifest.json",
    }
    missing = [
        str(path)
        for path in [*upstream_paths.values(), *output_paths.values()]
        if not path.exists()
    ]
    if missing:
        raise FileNotFoundError(f"Stage 2B validation inputs are missing: {missing}")

    upstream = pd.read_parquet(upstream_paths["table"])
    predictions = pd.read_parquet(output_paths["predictions"])
    coefficients = pd.read_csv(output_paths["coefficients"])
    metrics = pd.read_csv(output_paths["metrics"])
    fold_metrics = pd.read_csv(output_paths["fold_metrics"])
    deploy = read_json(output_paths["deploy"])
    summary = read_json(output_paths["summary"])
    freeze = read_json(output_paths["freeze"])
    stage2a_validation = read_json(upstream_paths["validation"])

    gates: list[dict[str, Any]] = []

    def gate(name: str, observed: Any, expected: Any, passed: bool, detail: str) -> None:
        gates.append(
            {
                "name": name,
                "observed": to_python(observed),
                "expected": to_python(expected),
                "passed": bool(passed),
                "detail": detail,
            }
        )

    frozen = config["stage2a_frozen"]
    upstream_hashes = {
        "frozen_overlap": sha256_file(upstream_paths["table"]),
        "assignments": sha256_file(upstream_paths["assignments"]),
        "freeze_manifest": sha256_file(upstream_paths["freeze"]),
    }
    expected_upstream_hashes = {
        "frozen_overlap": str(frozen["frozen_overlap_sha256"]),
        "assignments": str(frozen["assignment_file_sha256"]),
        "freeze_manifest": str(frozen["freeze_manifest_sha256"]),
    }
    gate(
        "stage2a_byte_identity",
        upstream_hashes,
        expected_upstream_hashes,
        upstream_hashes == expected_upstream_hashes,
        "accepted Stage 2A table, fold table, and freeze manifest",
    )
    required_stage2a_gates = int(config["validation"]["require_stage2a_passed_gates"])
    stage2a_status = {
        "overall_passed": stage2a_validation.get("overall_passed"),
        "n_gates": stage2a_validation.get("n_gates"),
        "n_passed": stage2a_validation.get("n_passed"),
    }
    stage2a_expected = {
        "overall_passed": True,
        "n_gates": required_stage2a_gates,
        "n_passed": required_stage2a_gates,
    }
    gate(
        "stage2a_validation",
        stage2a_status,
        stage2a_expected,
        stage2a_status == stage2a_expected,
        "upstream overlap/fold/coordinate freeze passed",
    )

    ids = upstream["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
    folds_all = upstream["heldout_fold"].to_numpy(dtype=np.int8)
    upstream_identity = {
        "rows": int(len(upstream)),
        "positive": int((ids > 0).sum()),
        "duplicates": int(pd.Series(ids).duplicated().sum()),
        "monotonic": bool(np.all(ids[1:] > ids[:-1])),
        "id_sha256": ids_sha256(ids),
        "fold_sha256": assignment_sha256(ids, folds_all),
    }
    upstream_identity_expected = {
        "rows": int(frozen["overlap_rows"]),
        "positive": int(frozen["overlap_rows"]),
        "duplicates": 0,
        "monotonic": True,
        "id_sha256": str(frozen["id_vector_sha256"]),
        "fold_sha256": str(frozen["fold_assignment_sha256"]),
    }
    gate(
        "stage2a_identity_and_folds",
        upstream_identity,
        upstream_identity_expected,
        upstream_identity == upstream_identity_expected,
        "59,918 exact source identities and pre-frozen five-fold assignment",
    )

    expected_prediction_rows = sum(
        int(config["expected_support"][analysis_set][element])
        for analysis_set in ANALYSIS_SETS
        for element in ELEMENTS
    )
    output_counts = {
        "prediction_rows": int(len(predictions)),
        "coefficient_rows": int(len(coefficients)),
        "crossfit_models": int(coefficients["model_role"].eq("crossfit_fold").sum()),
        "deploy_models": int(coefficients["model_role"].eq("deploy_full").sum()),
        "metric_rows": int(len(metrics)),
        "fold_metric_rows": int(len(fold_metrics)),
    }
    output_counts_expected = {
        "prediction_rows": expected_prediction_rows,
        "coefficient_rows": len(ELEMENTS) * len(ANALYSIS_SETS) * 6,
        "crossfit_models": len(ELEMENTS) * len(ANALYSIS_SETS) * 5,
        "deploy_models": len(ELEMENTS) * len(ANALYSIS_SETS),
        "metric_rows": len(ELEMENTS) * len(ANALYSIS_SETS),
        "fold_metric_rows": len(ELEMENTS) * len(ANALYSIS_SETS) * 5,
    }
    gate(
        "output_row_counts",
        output_counts,
        output_counts_expected,
        output_counts == output_counts_expected,
        "complete prediction, coefficient, and metric products",
    )

    observed_domains = {
        "prediction_elements": sorted(predictions["element"].astype(str).unique()),
        "prediction_sets": sorted(predictions["analysis_set"].astype(str).unique()),
        "coefficient_elements": sorted(coefficients["element"].astype(str).unique()),
        "coefficient_sets": sorted(coefficients["analysis_set"].astype(str).unique()),
    }
    expected_domains = {
        "prediction_elements": sorted(ELEMENTS),
        "prediction_sets": sorted(ANALYSIS_SETS),
        "coefficient_elements": sorted(ELEMENTS),
        "coefficient_sets": sorted(ANALYSIS_SETS),
    }
    gate(
        "frozen_element_and_set_domain",
        observed_domains,
        expected_domains,
        observed_domains == expected_domains,
        "no unplanned label or analysis-set expansion",
    )

    model_spec = {
        "target_definition": config["calibration"]["target_definition"],
        "correction_definition": config["calibration"]["correction_definition"],
        "predictors": config["calibration"]["predictors"],
        "predictor_centres": config["calibration"]["predictor_centres"],
        "predictor_scales": config["calibration"]["predictor_scales"],
        "estimator": config["calibration"]["estimator"],
        "crossfit": config["calibration"]["crossfit"],
        "elements": list(ELEMENTS),
        "analysis_sets": list(ANALYSIS_SETS),
    }
    expected_spec_hash = canonical_json_sha256(model_spec)
    observed_spec_hashes = sorted(coefficients["model_spec_sha256"].astype(str).unique())
    spec_observed = {
        "summary": summary.get("model_spec_sha256"),
        "freeze": freeze.get("model_spec_sha256"),
        "deploy": deploy.get("model_spec_sha256"),
        "coefficient_values": observed_spec_hashes,
    }
    spec_expected = {
        "summary": expected_spec_hash,
        "freeze": expected_spec_hash,
        "deploy": expected_spec_hash,
        "coefficient_values": [expected_spec_hash],
    }
    gate(
        "model_specification_freeze",
        spec_observed,
        spec_expected,
        spec_observed == spec_expected,
        "fixed GALAH-side linear predictor and deterministic Huber estimator",
    )

    membership_exact = True
    fold_exact = True
    value_exact = True
    formal_errors_positive = True
    duplicate_prediction_keys = int(
        predictions.duplicated(["element", "analysis_set", "gaia_dr3_source_id"]).sum()
    )
    for analysis_set in ANALYSIS_SETS:
        for element in ELEMENTS:
            expected = upstream.loc[
                upstream[f"eligible_{element}_{analysis_set}"].astype(bool)
            ].copy()
            observed = predictions.loc[
                predictions["element"].eq(element)
                & predictions["analysis_set"].eq(analysis_set)
            ].sort_values("gaia_dr3_source_id", kind="mergesort")
            expected = expected.sort_values("gaia_dr3_source_id", kind="mergesort")
            membership_exact &= np.array_equal(
                observed["gaia_dr3_source_id"].to_numpy(dtype=np.int64),
                expected["gaia_dr3_source_id"].to_numpy(dtype=np.int64),
            )
            fold_exact &= np.array_equal(
                observed["heldout_fold"].to_numpy(dtype=np.int8),
                expected["heldout_fold"].to_numpy(dtype=np.int8),
            )
            comparisons = (
                ("apogee_value", f"apogee_{element}"),
                ("galah_value", f"galah_{element}"),
                ("apogee_formal_error", f"apogee_{element}_err"),
                ("galah_formal_error", f"galah_{element}_err"),
                ("galah_teff", "galah_teff"),
                ("galah_logg", "galah_logg"),
                ("galah_fe_h_predictor", "galah_fe_h"),
            )
            for observed_column, expected_column in comparisons:
                value_exact &= np.array_equal(
                    observed[observed_column].to_numpy(dtype=float),
                    expected[expected_column].to_numpy(dtype=float),
                )
            formal_errors_positive &= bool(
                observed["apogee_formal_error"].gt(0).all()
                and observed["galah_formal_error"].gt(0).all()
                and observed["delta_formal_error"].gt(0).all()
            )
    support_observed = {
        "membership_exact": bool(membership_exact),
        "fold_exact": bool(fold_exact),
        "upstream_values_exact": bool(value_exact),
        "formal_errors_positive": bool(formal_errors_positive),
        "duplicate_prediction_keys": duplicate_prediction_keys,
    }
    support_expected = {
        "membership_exact": True,
        "fold_exact": True,
        "upstream_values_exact": True,
        "formal_errors_positive": True,
        "duplicate_prediction_keys": 0,
    }
    gate(
        "prediction_support_and_provenance",
        support_observed,
        support_expected,
        support_observed == support_expected,
        "predictions use exactly the frozen element/set memberships and values",
    )

    algebra_errors = {
        "raw_delta": float(
            np.max(
                np.abs(
                    predictions["raw_delta_galah_minus_apogee"].to_numpy(float)
                    - (
                        predictions["galah_value"].to_numpy(float)
                        - predictions["apogee_value"].to_numpy(float)
                    )
                )
            )
        ),
        "corrected_value": float(
            np.max(
                np.abs(
                    predictions["corrected_galah_apogee_scale"].to_numpy(float)
                    - (
                        predictions["galah_value"].to_numpy(float)
                        - predictions[
                            "predicted_offset_galah_minus_apogee"
                        ].to_numpy(float)
                    )
                )
            )
        ),
        "heldout_residual": float(
            np.max(
                np.abs(
                    predictions[
                        "heldout_residual_corrected_minus_apogee"
                    ].to_numpy(float)
                    - (
                        predictions["corrected_galah_apogee_scale"].to_numpy(float)
                        - predictions["apogee_value"].to_numpy(float)
                    )
                )
            )
        ),
        "formal_delta_error": float(
            np.max(
                np.abs(
                    predictions["delta_formal_error"].to_numpy(float)
                    - np.sqrt(
                        predictions["apogee_formal_error"].to_numpy(float) ** 2
                        + predictions["galah_formal_error"].to_numpy(float) ** 2
                    )
                )
            )
        ),
    }
    tolerance = float(config["validation"]["prediction_absolute_tolerance"])
    gate(
        "calibration_algebra",
        algebra_errors,
        f"all <= {tolerance}",
        max(algebra_errors.values()) <= tolerance,
        "delta, correction, residual, and formal-error identities",
    )

    coefficient_keys_unique = not coefficients.duplicated(
        ["element", "analysis_set", "model_role", "heldout_fold"]
    ).any()
    training_hashes_exact = True
    evaluation_hashes_exact = True
    prediction_equation_max_error = 0.0
    n_folds = int(frozen["n_folds"])
    for analysis_set in ANALYSIS_SETS:
        for element in ELEMENTS:
            expected = upstream.loc[
                upstream[f"eligible_{element}_{analysis_set}"].astype(bool)
            ].copy()
            expected_ids = expected["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
            expected_folds = expected["heldout_fold"].to_numpy(dtype=np.int8)
            matrix = design_matrix(expected, config)
            observed_predictions = predictions.loc[
                predictions["element"].eq(element)
                & predictions["analysis_set"].eq(analysis_set)
            ].sort_values("gaia_dr3_source_id", kind="mergesort")
            for heldout_fold in range(n_folds):
                row = coefficients.loc[
                    coefficients["element"].eq(element)
                    & coefficients["analysis_set"].eq(analysis_set)
                    & coefficients["model_role"].eq("crossfit_fold")
                    & coefficients["heldout_fold"].eq(heldout_fold)
                ]
                if len(row) != 1:
                    training_hashes_exact = False
                    evaluation_hashes_exact = False
                    continue
                row = row.iloc[0]
                eval_mask = expected_folds == heldout_fold
                train_mask = ~eval_mask
                training_hashes_exact &= (
                    str(row["training_id_sha256"]) == ids_sha256(expected_ids[train_mask])
                    and int(row["n_train"]) == int(train_mask.sum())
                )
                evaluation_hashes_exact &= (
                    str(row["evaluation_id_sha256"])
                    == ids_sha256(expected_ids[eval_mask])
                    and int(row["n_eval"]) == int(eval_mask.sum())
                )
                beta = row.loc[list(COEFFICIENT_NAMES)].to_numpy(dtype=float)
                expected_prediction = matrix[eval_mask] @ beta
                observed_prediction = observed_predictions.loc[
                    observed_predictions["heldout_fold"].eq(heldout_fold),
                    "predicted_offset_galah_minus_apogee",
                ].to_numpy(dtype=float)
                if len(expected_prediction) != len(observed_prediction):
                    prediction_equation_max_error = float("inf")
                else:
                    prediction_equation_max_error = max(
                        prediction_equation_max_error,
                        float(np.max(np.abs(expected_prediction - observed_prediction))),
                    )
            deploy_row = coefficients.loc[
                coefficients["element"].eq(element)
                & coefficients["analysis_set"].eq(analysis_set)
                & coefficients["model_role"].eq("deploy_full")
                & coefficients["heldout_fold"].eq(-1)
            ]
            if len(deploy_row) != 1:
                training_hashes_exact = False
            else:
                deploy_row = deploy_row.iloc[0]
                training_hashes_exact &= (
                    str(deploy_row["training_id_sha256"]) == ids_sha256(expected_ids)
                    and int(deploy_row["n_train"]) == len(expected_ids)
                    and int(deploy_row["n_eval"]) == 0
                )
    leakage_observed = {
        "coefficient_keys_unique": bool(coefficient_keys_unique),
        "training_hashes_exact": bool(training_hashes_exact),
        "evaluation_hashes_exact": bool(evaluation_hashes_exact),
        "prediction_equation_max_abs_error": prediction_equation_max_error,
    }
    leakage_expected = {
        "coefficient_keys_unique": True,
        "training_hashes_exact": True,
        "evaluation_hashes_exact": True,
        "prediction_equation_max_abs_error": f"<= {tolerance}",
    }
    gate(
        "heldout_no_leakage_and_prediction_equation",
        leakage_observed,
        leakage_expected,
        coefficient_keys_unique
        and training_hashes_exact
        and evaluation_hashes_exact
        and prediction_equation_max_error <= tolerance,
        "each fold is predicted only by its complementary training folds",
    )

    converged_values = coefficients["converged"]
    if converged_values.dtype == bool:
        all_converged = bool(converged_values.all())
    else:
        all_converged = bool(
            converged_values.astype(str).str.lower().isin(["true", "1"]).all()
        )
    max_condition = float(coefficients["design_condition_number"].max())
    max_allowed_condition = float(
        config["validation"]["maximum_design_condition_number"]
    )
    estimator_observed = {
        "all_converged": all_converged,
        "maximum_design_condition_number": max_condition,
    }
    estimator_expected = {
        "all_converged": True,
        "maximum_design_condition_number": f"<= {max_allowed_condition}",
    }
    gate(
        "estimator_convergence_and_condition",
        estimator_observed,
        estimator_expected,
        all_converged and max_condition <= max_allowed_condition,
        "all 50 fold fits and 10 deploy fits are numerically stable",
    )

    recomputed_metric_rows: list[dict[str, Any]] = []
    recomputed_fold_rows: list[dict[str, Any]] = []
    for analysis_set in ANALYSIS_SETS:
        for element in ELEMENTS:
            subset = predictions.loc[
                predictions["element"].eq(element)
                & predictions["analysis_set"].eq(analysis_set)
            ]
            raw = subset["raw_delta_galah_minus_apogee"].to_numpy(dtype=float)
            residual = subset[
                "heldout_residual_corrected_minus_apogee"
            ].to_numpy(dtype=float)
            recomputed_metric_rows.append(
                {
                    "element": element,
                    "analysis_set": analysis_set,
                    "n": int(len(subset)),
                    **calibration_metrics(raw, residual),
                }
            )
            for heldout_fold in range(n_folds):
                fold_subset = subset.loc[subset["heldout_fold"].eq(heldout_fold)]
                recomputed_fold_rows.append(
                    {
                        "element": element,
                        "analysis_set": analysis_set,
                        "heldout_fold": heldout_fold,
                        "n": int(len(fold_subset)),
                        **calibration_metrics(
                            fold_subset["raw_delta_galah_minus_apogee"].to_numpy(float),
                            fold_subset[
                                "heldout_residual_corrected_minus_apogee"
                            ].to_numpy(float),
                        ),
                    }
                )
    recomputed_metrics = pd.DataFrame(recomputed_metric_rows)
    recomputed_folds = pd.DataFrame(recomputed_fold_rows)
    metric_columns = [
        column
        for column in recomputed_metrics.columns
        if column not in {"element", "analysis_set", "n"}
    ]
    metrics_merged = metrics.merge(
        recomputed_metrics,
        on=["element", "analysis_set", "n"],
        suffixes=("_stored", "_recomputed"),
        validate="one_to_one",
    )
    fold_merged = fold_metrics.merge(
        recomputed_folds,
        on=["element", "analysis_set", "heldout_fold", "n"],
        suffixes=("_stored", "_recomputed"),
        validate="one_to_one",
    )
    metric_max_error = max(
        float(
            np.max(
                np.abs(
                    metrics_merged[f"{column}_stored"].to_numpy(float)
                    - metrics_merged[f"{column}_recomputed"].to_numpy(float)
                )
            )
        )
        for column in metric_columns
    )
    fold_metric_max_error = max(
        float(
            np.max(
                np.abs(
                    fold_merged[f"{column}_stored"].to_numpy(float)
                    - fold_merged[f"{column}_recomputed"].to_numpy(float)
                )
            )
        )
        for column in metric_columns
    )
    gate(
        "metric_recomputation",
        {
            "overall_max_abs_error": metric_max_error,
            "fold_max_abs_error": fold_metric_max_error,
        },
        f"both <= {tolerance}",
        metric_max_error <= tolerance and fold_metric_max_error <= tolerance,
        "headline and fold metrics recompute from held-out rows",
    )

    max_abs_bias = float(
        metrics["post_crossfit_median_residual_dex"].abs().max()
    )
    max_abs_bias_allowed = float(
        config["validation"]["maximum_abs_crossfit_median_residual_dex"]
    )
    gate(
        "heldout_bias_control",
        max_abs_bias,
        f"<= {max_abs_bias_allowed} dex",
        max_abs_bias <= max_abs_bias_allowed,
        "absolute held-out median residual across every element and set",
    )
    max_mad_ratio = float(metrics["post_to_raw_mad_ratio"].max())
    max_mad_ratio_allowed = float(
        config["validation"]["maximum_post_to_raw_centered_mad_ratio"]
    )
    gate(
        "heldout_non_degradation",
        max_mad_ratio,
        f"<= {max_mad_ratio_allowed}",
        max_mad_ratio <= max_mad_ratio_allowed,
        "cross-fitted MAD is not materially worse than median-only calibration",
    )
    fold_ranges = (
        fold_metrics.groupby(["element", "analysis_set"])[
            "post_crossfit_median_residual_dex"
        ]
        .agg(lambda values: float(values.max() - values.min()))
        .reset_index(name="fold_median_range_dex")
    )
    max_fold_range = float(fold_ranges["fold_median_range_dex"].max())
    max_fold_range_allowed = float(
        config["validation"]["maximum_fold_median_range_dex"]
    )
    gate(
        "heldout_fold_stability",
        max_fold_range,
        f"<= {max_fold_range_allowed} dex",
        max_fold_range <= max_fold_range_allowed,
        "range of held-out median residuals across the five frozen folds",
    )

    primary = metrics.loc[metrics["analysis_set"].eq("primary")].set_index("element")
    sensitivity = metrics.loc[
        metrics["analysis_set"].eq("sensitivity")
    ].set_index("element")
    sensitivity_shifts = {
        element: {
            "median_residual_shift_dex": float(
                abs(
                    primary.loc[element, "post_crossfit_median_residual_dex"]
                    - sensitivity.loc[element, "post_crossfit_median_residual_dex"]
                )
            ),
            "mad_shift_dex": float(
                abs(
                    primary.loc[element, "post_crossfit_mad_dex"]
                    - sensitivity.loc[element, "post_crossfit_mad_dex"]
                )
            ),
        }
        for element in ELEMENTS
    }
    max_sensitivity_shift = max(
        value
        for shifts in sensitivity_shifts.values()
        for value in shifts.values()
    )
    max_sensitivity_shift_allowed = float(
        config["validation"]["maximum_primary_sensitivity_metric_shift_dex"]
    )
    gate(
        "coordinate_sensitivity_stability",
        {
            "maximum_metric_shift_dex": max_sensitivity_shift,
            "by_element": sensitivity_shifts,
        },
        f"maximum <= {max_sensitivity_shift_allowed} dex",
        max_sensitivity_shift <= max_sensitivity_shift_allowed,
        "reinstating Gaia-adjudicated coordinate anomalies does not move calibration metrics",
    )

    coordinate_policy_exact = True
    coordinate_counts: dict[str, Any] = {}
    for element in ELEMENTS:
        primary_rows = predictions.loc[
            predictions["element"].eq(element)
            & predictions["analysis_set"].eq("primary")
        ]
        sensitivity_rows = predictions.loc[
            predictions["element"].eq(element)
            & predictions["analysis_set"].eq("sensitivity")
        ]
        primary_hard = int(primary_rows["coordinate_hard_mismatch"].astype(bool).sum())
        sensitivity_hard = int(
            sensitivity_rows["coordinate_hard_mismatch"].astype(bool).sum()
        )
        expected_reincluded = int(len(sensitivity_rows) - len(primary_rows))
        coordinate_counts[element] = {
            "primary_hard": primary_hard,
            "sensitivity_hard": sensitivity_hard,
            "expected_reincluded": expected_reincluded,
        }
        coordinate_policy_exact &= (
            primary_hard == 0 and sensitivity_hard == expected_reincluded
        )
    gate(
        "coordinate_analysis_set_policy",
        coordinate_counts,
        "primary_hard=0 and sensitivity_hard=sensitivity_n-primary_n",
        coordinate_policy_exact,
        "Stage 2A primary/sensitivity coordinate decision is preserved",
    )

    deploy_exact = True
    deploy_count = 0
    for analysis_set in ANALYSIS_SETS:
        for element in ELEMENTS:
            deploy_count += 1
            model = deploy.get("models", {}).get(analysis_set, {}).get(element)
            row = coefficients.loc[
                coefficients["element"].eq(element)
                & coefficients["analysis_set"].eq(analysis_set)
                & coefficients["model_role"].eq("deploy_full")
            ]
            if model is None or len(row) != 1:
                deploy_exact = False
                continue
            row = row.iloc[0]
            deploy_exact &= int(model["n_training"]) == int(row["n_train"])
            deploy_exact &= str(model["training_id_sha256"]) == str(
                row["training_id_sha256"]
            )
            for name in COEFFICIENT_NAMES:
                deploy_exact &= close_enough(
                    model["coefficients"][name], row[name], tolerance
                )
    gate(
        "deployable_model_identity",
        {"models_checked": deploy_count, "exact": bool(deploy_exact)},
        {"models_checked": 10, "exact": True},
        deploy_count == 10 and deploy_exact,
        "JSON deploy models exactly match all-support coefficient rows",
    )

    current_output_hashes = {
        "crossfit_predictions.parquet": sha256_file(output_paths["predictions"]),
        "calibration_coefficients.csv": sha256_file(output_paths["coefficients"]),
        "crossfit_metrics.csv": sha256_file(output_paths["metrics"]),
        "crossfit_fold_metrics.csv": sha256_file(output_paths["fold_metrics"]),
        "deployable_calibration_models.json": sha256_file(output_paths["deploy"]),
    }
    recorded_hashes = summary.get("outputs", {})
    freeze_hashes = freeze.get("output_sha256", {})
    hashes_exact = current_output_hashes == recorded_hashes and all(
        freeze_hashes.get(name) == value
        for name, value in current_output_hashes.items()
    )
    hashes_exact &= freeze_hashes.get("stage2b_build_summary.json") == sha256_file(
        output_paths["summary"]
    )
    gate(
        "output_hash_freeze",
        {"current": current_output_hashes, "summary": recorded_hashes},
        "current hashes equal summary and freeze manifest",
        hashes_exact,
        "byte identity of all calibration products",
    )

    expected_boundary = {
        "cross_fitted_overlap_calibration_performed": True,
        "union_catalogue_calibration_applied": False,
        "clean_atlas_constructed": False,
        "galactic_gradients_fitted": False,
        "population_model_fitted": False,
    }
    boundary_observed = {
        "summary": summary.get("science_boundary"),
        "freeze": freeze.get("science_boundary"),
    }
    boundary_expected = {
        "summary": expected_boundary,
        "freeze": expected_boundary,
    }
    gate(
        "stage2b_science_boundary",
        boundary_observed,
        boundary_expected,
        boundary_observed == boundary_expected,
        "overlap calibration only; no parent transport, atlas, gradients, or populations",
    )

    overall = all(item["passed"] for item in gates)
    report = {
        "stage": "Stage 2B validation",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": utc_now(),
        "overall_passed": overall,
        "n_gates": len(gates),
        "n_passed": sum(int(item["passed"]) for item in gates),
        "gates": gates,
        "science_boundary": expected_boundary,
    }
    validation_path = output_dir / "stage2b_validation.json"
    atomic_write_json(report, validation_path)

    markdown = [
        "# Stage 2B validation report",
        "",
        f"Overall: **{'PASS' if overall else 'FAIL'}**",
        "",
        f"Protocol: `{config['project']['version']}`",
        "",
        "| Gate | Result | Detail |",
        "|---|---:|---|",
    ]
    for item in gates:
        markdown.append(
            f"| `{item['name']}` | {'PASS' if item['passed'] else 'FAIL'} | {item['detail']} |"
        )
    markdown.extend(
        [
            "",
            "Stage 2B performed held-out overlap calibration only. Parent-catalogue "
            "transport, the final atlas, gradients, and population inference were not performed.",
            "",
        ]
    )
    report_path = output_dir / "stage2b_validation_report.md"
    report_path.write_text("\n".join(markdown), encoding="utf-8")
    logger.info(
        "Stage 2B validation passed=%s; gates=%d/%d; report=%s",
        overall,
        report["n_passed"],
        report["n_gates"],
        report_path,
    )
    close_logger(logger)
    return 0 if overall else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
