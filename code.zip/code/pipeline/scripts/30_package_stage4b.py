from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

from stage4b_common import (
    atomic_write_json,
    load_config,
    project_path,
    read_json,
    sha256_file,
    utc_now,
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Package Stage 4B outputs")
    parser.add_argument("--config", default="config/stage4b.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    outputs = config["outputs"]
    output_dir = project_path(root, config["paths"]["output_dir"])
    validation_path = output_dir / outputs["validation_file"]
    validation = read_json(validation_path)
    expected_gates = int(config["validation"]["expected_gates"])
    if not bool(validation.get("overall_passed", False)):
        raise RuntimeError("Stage 4B validation is not PASS; packaging is forbidden")
    if [int(validation.get("n_passed", -1)), int(validation.get("n_gates", -1))] != [
        expected_gates,
        expected_gates,
    ]:
        raise RuntimeError(
            f"Stage 4B validation gate count is not {expected_gates}/{expected_gates}"
        )

    relative_files = [
        Path("28_fit_stage4b.bat"),
        Path("29_validate_stage4b.bat"),
        Path("30_package_stage4b.bat"),
        Path("99_stage4b_selftest.bat"),
        Path("run_stage4b_all.bat"),
        Path("STAGE4B_PROTOCOL.md"),
        Path("STAGE4B_README_UZ.md"),
        Path("STAGE4B_PATCH_MANIFEST.json"),
        Path("config/stage4b.yml"),
        Path("scripts/28_fit_stage4b.py"),
        Path("scripts/29_validate_stage4b.py"),
        Path("scripts/30_package_stage4b.py"),
        Path("scripts/selftest_stage4b.py"),
        Path("scripts/stage4b_common.py"),
        Path("logs/28_fit_stage4b.log"),
        Path("logs/29_validate_stage4b.log"),
    ]
    frozen = config["stage4a_frozen"]
    relative_files.extend(
        Path("outputs/stage4a") / frozen[key]
        for key in (
            "design_definition_file",
            "cohort_flow_file",
            "build_summary_file",
            "freeze_manifest_file",
            "validation_file",
            "validation_report_file",
            "package_manifest_file",
        )
    )
    relative_files.extend(
        Path("outputs/stage4b") / outputs[key]
        for key in (
            "global_estimates_file",
            "sensitivity_ladder_file",
            "transportability_file",
            "bootstrap_draws_file",
            "model_diagnostics_file",
            "bootstrap_convergence_file",
            "influence_audit_file",
            "claim_ledger_file",
            "method_definition_file",
            "build_summary_file",
            "freeze_manifest_file",
            "validation_file",
            "validation_report_file",
        )
    )
    missing = [str(path) for path in relative_files if not (root / path).is_file()]
    if missing:
        raise FileNotFoundError("Missing Stage 4B package file: " + "; ".join(missing))

    manifest = {
        "package": outputs["package_name"].removesuffix(".zip"),
        "stage": "4B",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": utc_now(),
        "files": [
            {
                "path": path.as_posix(),
                "bytes": int((root / path).stat().st_size),
                "sha256": sha256_file(root / path),
            }
            for path in relative_files
        ],
        "upstream": {
            "stage4a_release_name": frozen["release_name"],
            "stage4a_release_sha256": frozen["release_sha256"],
            "stage4a_design_layer_sha256": frozen["design_layer_sha256"],
            "stage4a_candidate_id_sha256": frozen["expected_candidate_id_sha256"],
        },
        "excluded": [
            "official raw survey catalogues and Gaia cache chunks",
            "the 184 MB Stage 4A design layer, referenced by exact release and file SHA-256",
            "population labels, probabilities, population-resolved gradients, and selection weights",
            "unvalidated C/N, C, N, Al, and Ti abundance transports",
        ],
        "science_boundary": config["science_boundary"],
    }
    manifest_path = output_dir / outputs["package_manifest_file"]
    atomic_write_json(manifest, manifest_path)
    package_files = [*relative_files, manifest_path.relative_to(root)]
    package_path = root / outputs["package_name"]
    temporary = package_path.with_name(f".{package_path.name}.tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(
        temporary,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
        allowZip64=True,
    ) as archive:
        for path in package_files:
            archive.write(root / path, arcname=path.as_posix())
    temporary.replace(package_path)
    with zipfile.ZipFile(package_path, mode="r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"Packaged ZIP failed integrity at {bad}")
    print(f"Output bundle created: {package_path}")
    print(f"SHA-256: {sha256_file(package_path)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
