from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path
from typing import Any

from stage2a_common import (
    atomic_write_json,
    load_config,
    project_path,
    read_json,
    sha256_file,
    utc_now,
)


FIXED_ZIP_TIME = (2026, 8, 1, 0, 0, 0)


def payload_paths(root: Path, output_dir: Path, log_dir: Path) -> list[Path]:
    relative_paths = [
        Path("config/stage2a.yml"),
        Path("scripts/stage2a_common.py"),
        Path("scripts/07_build_stage2a.py"),
        Path("scripts/08_validate_stage2a.py"),
        Path("scripts/09_package_stage2a.py"),
        Path("scripts/selftest_stage2a.py"),
        Path("07_build_stage2a.bat"),
        Path("08_validate_stage2a.bat"),
        Path("09_package_stage2a.bat"),
        Path("99_stage2a_selftest.bat"),
        Path("run_stage2a_all.bat"),
        Path("STAGE2A_PROTOCOL.md"),
        Path("STAGE2A_README_UZ.md"),
    ]
    required_outputs = [
        "overlap_stage2a_frozen.parquet",
        "heldout_fold_assignments.parquet",
        "coordinate_hard_mismatches.csv",
        "element_support_counts.csv",
        "fold_balance_by_element.csv",
        "stage2a_build_summary.json",
        "stage2a_freeze_manifest.json",
        "stage2a_validation.json",
        "stage2a_validation_report.md",
    ]
    files = [root / path for path in relative_paths]
    files.extend(output_dir / name for name in required_outputs)
    files.extend(
        [
            log_dir / "07_build_stage2a.log",
            log_dir / "08_validate_stage2a.log",
        ]
    )
    missing = [str(path) for path in files if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Stage 2A package inputs are missing: {missing}")
    return files


def write_deterministic_zip(root: Path, files: list[Path], destination: Path) -> None:
    temporary = destination.with_name(f".{destination.name}.tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(
        temporary,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for path in sorted(files, key=lambda item: item.relative_to(root).as_posix()):
            arcname = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(arcname, FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            with path.open("rb") as handle:
                archive.writestr(info, handle.read(), compresslevel=9)
    temporary.replace(destination)


def main() -> int:
    parser = argparse.ArgumentParser(description="Package accepted Stage 2A products")
    parser.add_argument("--config", default="config/stage2a.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    output_dir = project_path(root, config["paths"]["output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])
    validation_path = output_dir / "stage2a_validation.json"
    if not validation_path.exists():
        raise FileNotFoundError("Run 08_validate_stage2a.bat before packaging")
    validation = read_json(validation_path)
    if not validation.get("overall_passed", False):
        raise RuntimeError("Stage 2A validation is not PASS; refusing to package")

    files = payload_paths(root, output_dir, log_dir)
    manifest_path = output_dir / "stage2a_package_manifest.json"
    manifest = {
        "package": "RGB_transportability_stage2a_outputs_v0_2_0",
        "stage": "2A",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": utc_now(),
        "stage1_release_sha256": config["stage1_frozen"]["release_sha256"],
        "stage2b_cross_fitted_abundance_calibration_performed": False,
        "excluded": [
            "official raw FITS catalogues",
            "Stage 1 restartable Gaia cache",
            "Stage 2B calibration coefficients or corrected abundances",
        ],
        "files": [
            {
                "path": path.relative_to(root).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
            for path in sorted(files, key=lambda item: item.relative_to(root).as_posix())
        ],
    }
    atomic_write_json(manifest, manifest_path)
    files.append(manifest_path)

    destination = root / "RGB_transportability_stage2a_outputs_v0_2_0.zip"
    write_deterministic_zip(root, files, destination)
    print(f"Output bundle created: {destination}")
    print(f"SHA-256: {sha256_file(destination)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
