from __future__ import annotations

import argparse
import platform
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from stage2b_common import (
    ANALYSIS_SETS,
    COEFFICIENT_NAMES,
    ELEMENTS,
    assignment_sha256,
    atomic_write_json,
    calibration_metrics,
    canonical_json_sha256,
    close_logger,
    design_matrix,
    ensure_columns,
    feature_support_summary,
    fit_huber_irls,
    ids_sha256,
    load_config,
    project_path,
    read_json,
    setup_logger,
    sha256_file,
    to_python,
    utc_now,
    write_frame,
)


def require_stage2a(config: dict[str, Any], root: Path) -> tuple[pd.DataFrame, dict[str, Path]]:
    stage2a_dir = project_path(root, config["paths"]["stage2a_output_dir"])
    frozen = config["stage2a_frozen"]
    paths = {
        "table": stage2a_dir / str(frozen["frozen_overlap_file"]),
        "assignments": stage2a_dir / str(frozen["assignment_file"]),
        "freeze": stage2a_dir / str(frozen["freeze_manifest_file"]),
        "validation": stage2a_dir / "stage2a_validation.json",
        "summary": stage2a_dir / "stage2a_build_summary.json",
    }
    missing = [str(path) for path in paths.values() if not path.exists()]
    if missing:
        raise FileNotFoundError(
            "Accepted Stage 2A outputs are missing. Extract this overlay into the "
            f"original Stage 1/2A project directory. Missing: {missing}"
        )
    observed_hashes = {
        "table": sha256_file(paths["table"]),
        "assignments": sha256_file(paths["assignments"]),
        "freeze": sha256_file(paths["freeze"]),
    }
    expected_hashes = {
        "table": str(frozen["frozen_overlap_sha256"]),
        "assignments": str(frozen["assignment_file_sha256"]),
        "freeze": str(frozen["freeze_manifest_sha256"]),
    }
    if observed_hashes != expected_hashes:
        raise RuntimeError(
            f"Stage 2A byte identity changed: observed={observed_hashes}, "
            f"expected={expected_hashes}"
        )
    validation = read_json(paths["validation"])
    required_gates = int(config["validation"]["require_stage2a_passed_gates"])
    if not validation.get("overall_passed", False):
        raise RuntimeError("Stage 2A validation is not PASS")
    if int(validation.get("n_gates", -1)) != required_gates or int(
        validation.get("n_passed", -1)
    ) != required_gates:
        raise RuntimeError("Stage 2A validation is not the accepted 19/19 result")
    freeze = read_json(paths["freeze"])
    if str(freeze.get("protocol_version")) != str(frozen["protocol_version"]):
        raise RuntimeError("Stage 2A protocol version changed")
    if freeze.get("stage2b_boundary", {}).get(
        "cross_fitted_abundance_calibration_performed"
    ) is not False:
        raise RuntimeError("Stage 2A boundary is not clean")

    frame = pd.read_parquet(paths["table"])
    ensure_columns(
        frame,
        (
            "gaia_dr3_source_id",
            "heldout_fold",
            "heldout_rank_uint64",
            "coordinate_hard_mismatch",
        ),
        "Stage 2A frozen overlap",
    )
    ids = pd.to_numeric(frame["gaia_dr3_source_id"], errors="coerce").fillna(0).astype(
        "int64"
    )
    if len(frame) != int(frozen["overlap_rows"]):
        raise RuntimeError("Stage 2A overlap row count changed")
    if not ids.gt(0).all() or ids.duplicated().any() or not ids.is_monotonic_increasing:
        raise RuntimeError("Stage 2A overlap identity/order changed")
    if ids_sha256(ids) != str(frozen["id_vector_sha256"]):
        raise RuntimeError("Stage 2A source-ID vector hash changed")
    if assignment_sha256(ids, frame["heldout_fold"]) != str(
        frozen["fold_assignment_sha256"]
    ):
        raise RuntimeError("Stage 2A fold assignment changed")
    n_folds = int(frozen["n_folds"])
    if sorted(frame["heldout_fold"].astype(int).unique().tolist()) != list(
        range(n_folds)
    ):
        raise RuntimeError("Stage 2A fold domain changed")
    return frame, paths


def estimator_options(config: dict[str, Any]) -> dict[str, Any]:
    estimator = config["calibration"]["estimator"]
    return {
        "huber_c": float(estimator["huber_c"]),
        "mad_to_sigma": float(estimator["mad_to_sigma"]),
        "minimum_scale": float(estimator["minimum_scale"]),
        "maximum_iterations": int(estimator["maximum_iterations"]),
        "coefficient_tolerance": float(estimator["coefficient_tolerance"]),
    }


def coefficient_record(
    *,
    element: str,
    analysis_set: str,
    role: str,
    heldout_fold: int,
    train_ids: np.ndarray,
    eval_ids: np.ndarray,
    fit: dict[str, Any],
    model_spec_sha256: str,
) -> dict[str, Any]:
    coefficients = np.asarray(fit["coefficients"], dtype=float)
    record: dict[str, Any] = {
        "element": element,
        "analysis_set": analysis_set,
        "model_role": role,
        "heldout_fold": int(heldout_fold),
        "n_train": int(len(train_ids)),
        "n_eval": int(len(eval_ids)),
        "training_id_sha256": ids_sha256(train_ids),
        "evaluation_id_sha256": ids_sha256(eval_ids) if len(eval_ids) else "",
        "converged": bool(fit["converged"]),
        "n_iterations": int(fit["n_iterations"]),
        "robust_scale_dex": float(fit["robust_scale"]),
        "design_condition_number": float(fit["condition_number"]),
        "model_spec_sha256": model_spec_sha256,
    }
    for name, value in zip(COEFFICIENT_NAMES, coefficients):
        record[name] = float(value)
    return record


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run Stage 2B held-out APOGEE-GALAH abundance calibration"
    )
    parser.add_argument("--config", default="config/stage2b.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    output_dir = project_path(root, config["paths"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "10_run_stage2b.log", "stage2b.build")
    logger.info("Starting Stage 2B protocol v%s", config["project"]["version"])

    frame, upstream_paths = require_stage2a(config, root)
    elements = tuple(str(value) for value in config["calibration"]["elements"])
    analysis_sets = tuple(
        str(value) for value in config["calibration"]["analysis_sets"]
    )
    if elements != ELEMENTS:
        raise RuntimeError(f"Element freeze changed: {elements} != {ELEMENTS}")
    if analysis_sets != ANALYSIS_SETS:
        raise RuntimeError(
            f"Analysis-set freeze changed: {analysis_sets} != {ANALYSIS_SETS}"
        )

    model_spec = {
        "target_definition": config["calibration"]["target_definition"],
        "correction_definition": config["calibration"]["correction_definition"],
        "predictors": config["calibration"]["predictors"],
        "predictor_centres": config["calibration"]["predictor_centres"],
        "predictor_scales": config["calibration"]["predictor_scales"],
        "estimator": config["calibration"]["estimator"],
        "crossfit": config["calibration"]["crossfit"],
        "elements": list(elements),
        "analysis_sets": list(analysis_sets),
    }
    model_spec_hash = canonical_json_sha256(model_spec)
    options = estimator_options(config)
    n_folds = int(config["stage2a_frozen"]["n_folds"])

    prediction_parts: list[pd.DataFrame] = []
    coefficient_rows: list[dict[str, Any]] = []
    metric_rows: list[dict[str, Any]] = []
    fold_metric_rows: list[dict[str, Any]] = []
    deploy_models: dict[str, Any] = {
        "stage": "2B deployable overlap calibration models",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": utc_now(),
        "reference_scale": config["calibration"]["reference_scale"],
        "target_survey": config["calibration"]["target_survey"],
        "model_spec": model_spec,
        "model_spec_sha256": model_spec_hash,
        "models": {},
    }

    for analysis_set in analysis_sets:
        deploy_models["models"][analysis_set] = {}
        for element in elements:
            support_column = f"eligible_{element}_{analysis_set}"
            ensure_columns(frame, (support_column,), f"{element} {analysis_set} support")
            selected = frame.loc[frame[support_column].astype(bool)].copy()
            expected_n = int(config["expected_support"][analysis_set][element])
            if len(selected) != expected_n:
                raise RuntimeError(
                    f"Frozen support changed for {element}/{analysis_set}: "
                    f"{len(selected)} != {expected_n}"
                )
            required = (
                "gaia_dr3_source_id",
                "heldout_fold",
                "coordinate_hard_mismatch",
                "galah_teff",
                "galah_logg",
                "galah_fe_h",
                f"apogee_{element}",
                f"galah_{element}",
                f"apogee_{element}_err",
                f"galah_{element}_err",
            )
            ensure_columns(selected, required, f"{element} calibration support")
            source_ids = selected["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
            folds = selected["heldout_fold"].to_numpy(dtype=np.int8)
            matrix = design_matrix(selected, config)
            apogee = selected[f"apogee_{element}"].to_numpy(dtype=float)
            galah = selected[f"galah_{element}"].to_numpy(dtype=float)
            apogee_error = selected[f"apogee_{element}_err"].to_numpy(dtype=float)
            galah_error = selected[f"galah_{element}_err"].to_numpy(dtype=float)
            raw_delta = galah - apogee
            if not np.isfinite(
                np.column_stack(
                    [matrix, apogee, galah, apogee_error, galah_error, raw_delta]
                )
            ).all():
                raise RuntimeError(f"Non-finite input for {element}/{analysis_set}")
            if not (apogee_error > 0).all() or not (galah_error > 0).all():
                raise RuntimeError(f"Non-positive formal error for {element}/{analysis_set}")

            crossfit_prediction = np.full(len(selected), np.nan, dtype=float)
            for heldout_fold in range(n_folds):
                eval_mask = folds == heldout_fold
                train_mask = ~eval_mask
                if not eval_mask.any() or not train_mask.any():
                    raise RuntimeError(
                        f"Empty train/evaluation split for {element}/{analysis_set}/fold {heldout_fold}"
                    )
                fit = fit_huber_irls(
                    matrix[train_mask], raw_delta[train_mask], **options
                )
                crossfit_prediction[eval_mask] = (
                    matrix[eval_mask] @ np.asarray(fit["coefficients"], dtype=float)
                )
                coefficient_rows.append(
                    coefficient_record(
                        element=element,
                        analysis_set=analysis_set,
                        role="crossfit_fold",
                        heldout_fold=heldout_fold,
                        train_ids=source_ids[train_mask],
                        eval_ids=source_ids[eval_mask],
                        fit=fit,
                        model_spec_sha256=model_spec_hash,
                    )
                )
            if not np.isfinite(crossfit_prediction).all():
                raise RuntimeError(f"Incomplete cross-fit predictions for {element}/{analysis_set}")

            heldout_residual = raw_delta - crossfit_prediction
            corrected_galah = galah - crossfit_prediction
            delta_error = np.sqrt(apogee_error**2 + galah_error**2)
            predictions = pd.DataFrame(
                {
                    "gaia_dr3_source_id": source_ids,
                    "element": element,
                    "analysis_set": analysis_set,
                    "heldout_fold": folds,
                    "coordinate_hard_mismatch": selected[
                        "coordinate_hard_mismatch"
                    ].to_numpy(dtype=bool),
                    "galah_teff": selected["galah_teff"].to_numpy(dtype=float),
                    "galah_logg": selected["galah_logg"].to_numpy(dtype=float),
                    "galah_fe_h_predictor": selected["galah_fe_h"].to_numpy(
                        dtype=float
                    ),
                    "apogee_value": apogee,
                    "galah_value": galah,
                    "apogee_formal_error": apogee_error,
                    "galah_formal_error": galah_error,
                    "delta_formal_error": delta_error,
                    "raw_delta_galah_minus_apogee": raw_delta,
                    "predicted_offset_galah_minus_apogee": crossfit_prediction,
                    "corrected_galah_apogee_scale": corrected_galah,
                    "heldout_residual_corrected_minus_apogee": heldout_residual,
                }
            )
            prediction_parts.append(predictions)

            overall_metrics = calibration_metrics(raw_delta, heldout_residual)
            metric_rows.append(
                {
                    "element": element,
                    "analysis_set": analysis_set,
                    "n": int(len(selected)),
                    **overall_metrics,
                }
            )
            for heldout_fold in range(n_folds):
                mask = folds == heldout_fold
                fold_metric_rows.append(
                    {
                        "element": element,
                        "analysis_set": analysis_set,
                        "heldout_fold": heldout_fold,
                        "n": int(mask.sum()),
                        **calibration_metrics(raw_delta[mask], heldout_residual[mask]),
                    }
                )

            deploy_fit = fit_huber_irls(matrix, raw_delta, **options)
            coefficient_rows.append(
                coefficient_record(
                    element=element,
                    analysis_set=analysis_set,
                    role="deploy_full",
                    heldout_fold=-1,
                    train_ids=source_ids,
                    eval_ids=np.array([], dtype=np.int64),
                    fit=deploy_fit,
                    model_spec_sha256=model_spec_hash,
                )
            )
            deploy_models["models"][analysis_set][element] = {
                "n_training": int(len(selected)),
                "training_id_sha256": ids_sha256(source_ids),
                "coefficients": {
                    name: float(value)
                    for name, value in zip(
                        COEFFICIENT_NAMES,
                        np.asarray(deploy_fit["coefficients"], dtype=float),
                    )
                },
                "converged": bool(deploy_fit["converged"]),
                "n_iterations": int(deploy_fit["n_iterations"]),
                "robust_training_scale_dex": float(deploy_fit["robust_scale"]),
                "design_condition_number": float(deploy_fit["condition_number"]),
                "crossfit_metrics": overall_metrics,
                "feature_support": feature_support_summary(selected, config),
            }
            logger.info(
                "%s/%s: n=%d, raw median=%+.6f, held-out median=%+.6f, "
                "MAD ratio=%.4f",
                analysis_set,
                element,
                len(selected),
                overall_metrics["raw_median_offset_dex"],
                overall_metrics["post_crossfit_median_residual_dex"],
                overall_metrics["post_to_raw_mad_ratio"],
            )

    element_order = {value: index for index, value in enumerate(elements)}
    set_order = {value: index for index, value in enumerate(analysis_sets)}
    predictions_all = pd.concat(prediction_parts, ignore_index=True)
    predictions_all["_element_order"] = predictions_all["element"].map(element_order)
    predictions_all["_set_order"] = predictions_all["analysis_set"].map(set_order)
    predictions_all = predictions_all.sort_values(
        ["_set_order", "_element_order", "gaia_dr3_source_id"], kind="mergesort"
    ).drop(columns=["_element_order", "_set_order"]).reset_index(drop=True)
    coefficients = pd.DataFrame(coefficient_rows)
    coefficients["_element_order"] = coefficients["element"].map(element_order)
    coefficients["_set_order"] = coefficients["analysis_set"].map(set_order)
    coefficients = coefficients.sort_values(
        ["_set_order", "_element_order", "model_role", "heldout_fold"],
        kind="mergesort",
    ).drop(columns=["_element_order", "_set_order"]).reset_index(drop=True)
    metrics = pd.DataFrame(metric_rows)
    metrics["_element_order"] = metrics["element"].map(element_order)
    metrics["_set_order"] = metrics["analysis_set"].map(set_order)
    metrics = metrics.sort_values(
        ["_set_order", "_element_order"], kind="mergesort"
    ).drop(columns=["_element_order", "_set_order"]).reset_index(drop=True)
    fold_metrics = pd.DataFrame(fold_metric_rows)
    fold_metrics["_element_order"] = fold_metrics["element"].map(element_order)
    fold_metrics["_set_order"] = fold_metrics["analysis_set"].map(set_order)
    fold_metrics = fold_metrics.sort_values(
        ["_set_order", "_element_order", "heldout_fold"], kind="mergesort"
    ).drop(columns=["_element_order", "_set_order"]).reset_index(drop=True)

    predictions_path = output_dir / "crossfit_predictions.parquet"
    coefficients_path = output_dir / "calibration_coefficients.csv"
    metrics_path = output_dir / "crossfit_metrics.csv"
    fold_metrics_path = output_dir / "crossfit_fold_metrics.csv"
    deploy_path = output_dir / "deployable_calibration_models.json"
    write_frame(predictions_all, predictions_path)
    write_frame(coefficients, coefficients_path)
    write_frame(metrics, metrics_path)
    write_frame(fold_metrics, fold_metrics_path)
    atomic_write_json(to_python(deploy_models), deploy_path)

    output_hashes = {
        "crossfit_predictions.parquet": sha256_file(predictions_path),
        "calibration_coefficients.csv": sha256_file(coefficients_path),
        "crossfit_metrics.csv": sha256_file(metrics_path),
        "crossfit_fold_metrics.csv": sha256_file(fold_metrics_path),
        "deployable_calibration_models.json": sha256_file(deploy_path),
    }
    primary_metrics = metrics.loc[metrics["analysis_set"].eq("primary")].to_dict(
        orient="records"
    )
    sensitivity_metrics = metrics.loc[
        metrics["analysis_set"].eq("sensitivity")
    ].to_dict(orient="records")
    summary = {
        "stage": "2B cross-fitted APOGEE-GALAH abundance calibration",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": utc_now(),
        "upstream": {
            "stage2a_release_name": config["stage2a_frozen"]["release_name"],
            "stage2a_release_sha256": config["stage2a_frozen"]["release_sha256"],
            "stage2a_frozen_overlap_sha256": sha256_file(upstream_paths["table"]),
            "stage2a_assignment_file_sha256": sha256_file(
                upstream_paths["assignments"]
            ),
            "stage2a_freeze_manifest_sha256": sha256_file(upstream_paths["freeze"]),
            "overlap_rows": int(len(frame)),
            "id_vector_sha256": ids_sha256(frame["gaia_dr3_source_id"]),
            "fold_assignment_sha256": assignment_sha256(
                frame["gaia_dr3_source_id"], frame["heldout_fold"]
            ),
        },
        "model_spec": model_spec,
        "model_spec_sha256": model_spec_hash,
        "counts": {
            "prediction_rows": int(len(predictions_all)),
            "coefficient_rows": int(len(coefficients)),
            "crossfit_fold_models": int(
                coefficients["model_role"].eq("crossfit_fold").sum()
            ),
            "deploy_full_models": int(
                coefficients["model_role"].eq("deploy_full").sum()
            ),
            "overall_metric_rows": int(len(metrics)),
            "fold_metric_rows": int(len(fold_metrics)),
        },
        "primary_metrics": primary_metrics,
        "sensitivity_metrics": sensitivity_metrics,
        "outputs": output_hashes,
        "software": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
        },
        "science_boundary": {
            "cross_fitted_overlap_calibration_performed": True,
            "union_catalogue_calibration_applied": False,
            "clean_atlas_constructed": False,
            "galactic_gradients_fitted": False,
            "population_model_fitted": False,
        },
    }
    summary_path = output_dir / "stage2b_build_summary.json"
    atomic_write_json(to_python(summary), summary_path)

    freeze_manifest = {
        "stage": "2B calibration freeze",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": utc_now(),
        "upstream": summary["upstream"],
        "model_spec_sha256": model_spec_hash,
        "output_sha256": {
            **output_hashes,
            "stage2b_build_summary.json": sha256_file(summary_path),
        },
        "primary_model_role": "deploy_full fitted on all frozen primary support",
        "headline_validation_role": "strictly held-out crossfit predictions",
        "science_boundary": summary["science_boundary"],
    }
    atomic_write_json(
        to_python(freeze_manifest), output_dir / "stage2b_freeze_manifest.json"
    )

    logger.info(
        "Stage 2B build complete: prediction rows=%d, fold models=%d, deploy models=%d",
        len(predictions_all),
        int(coefficients["model_role"].eq("crossfit_fold").sum()),
        int(coefficients["model_role"].eq("deploy_full").sum()),
    )
    logger.info("No union-catalogue application, gradient, or population fit was performed")
    close_logger(logger)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
