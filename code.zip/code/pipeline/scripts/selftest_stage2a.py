from __future__ import annotations

import unittest

import numpy as np
import pandas as pd

from stage2a_common import (
    add_support_flags,
    assignment_sha256,
    coordinate_adjudication,
    frozen_folds,
    spherical_separation_arcsec,
)


class Stage2ALogicTests(unittest.TestCase):
    def test_splitmix64_fold_vector_is_frozen(self) -> None:
        source_ids = np.array(
            [1, 42, 1234567890123456789, 5855590877609289856], dtype=np.int64
        )
        ranks, folds = frozen_folds(source_ids, seed=20260801, n_folds=5)
        self.assertEqual(
            [int(value) for value in ranks],
            [
                10294310307618741294,
                9949652290880499609,
                12168212348145227100,
                15496016279535089019,
            ],
        )
        self.assertEqual(folds.tolist(), [4, 4, 0, 4])
        self.assertEqual(
            assignment_sha256(source_ids, folds),
            "4f8442c0bf06e979af8becb05d539c378a78ec728fdf0e5c4ff2efb131b8638e",
        )

    def test_fold_for_each_source_is_row_order_independent(self) -> None:
        source_ids = np.array([11, 22, 33, 44, 55, 66], dtype=np.int64)
        _, original = frozen_folds(source_ids, seed=20260801, n_folds=5)
        permutation = np.array([4, 0, 5, 2, 1, 3])
        _, shuffled = frozen_folds(source_ids[permutation], seed=20260801, n_folds=5)
        original_map = dict(zip(source_ids.tolist(), original.tolist()))
        shuffled_map = dict(zip(source_ids[permutation].tolist(), shuffled.tolist()))
        self.assertEqual(original_map, shuffled_map)

    def test_spherical_separation_wraps_right_ascension(self) -> None:
        separation = spherical_separation_arcsec(
            [359.999], [0.0], [0.001], [0.0]
        )
        self.assertAlmostEqual(float(separation[0]), 7.2, places=6)

    def test_coordinate_adjudication_categories(self) -> None:
        frame = pd.DataFrame(
            {
                "apogee_ra": [10.0, 0.0, 0.25, 0.0, np.nan],
                "apogee_dec": [0.0, 0.0, 0.0, 0.0, 0.0],
                "galah_ra": [10.00001, 0.25, 0.0, 0.25, 0.0],
                "galah_dec": [0.0, 0.0, 0.0, 0.0, 0.0],
                "gaia_ra": [10.0, 0.0, 0.0, 0.125, 0.0],
                "gaia_dec": [0.0, 0.0, 0.0, 0.0, 0.0],
            }
        )
        result = coordinate_adjudication(
            frame,
            pair_hard_mismatch_arcsec=300.0,
            gaia_confirmation_arcsec=10.0,
            gaia_far_arcsec=300.0,
        )
        self.assertEqual(
            result["coordinate_status"].tolist(),
            [
                "IDENTITY_CONSISTENT",
                "APOGEE_COORDINATE_CONFIRMED",
                "GALAH_COORDINATE_CONFIRMED",
                "HARD_MISMATCH_UNRESOLVED",
                "GAIA_COORDINATE_INCOMPLETE",
            ],
        )
        self.assertEqual(
            result["coordinate_primary_ok"].tolist(),
            [True, False, False, False, False],
        )
        self.assertEqual(
            result["coordinate_sensitivity_ok"].tolist(),
            [True, True, True, False, False],
        )

    def test_element_support_respects_coordinate_boundary(self) -> None:
        frame = pd.DataFrame(
            {
                "apogee_broad_rg_and_quality": [True, True, False],
                "galah_broad_rg_and_quality": [True, True, True],
                "coordinate_primary_ok": [True, False, True],
                "coordinate_sensitivity_ok": [True, True, True],
                "apogee_valid_fe_h": [True, True, True],
                "galah_valid_fe_h": [True, True, True],
            }
        )
        result = add_support_flags(frame, ["fe_h"])
        self.assertEqual(result["eligible_fe_h_precoordinate"].tolist(), [True, True, False])
        self.assertEqual(result["eligible_fe_h_primary"].tolist(), [True, False, False])
        self.assertEqual(
            result["eligible_fe_h_sensitivity"].tolist(), [True, True, False]
        )


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Stage2ALogicTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        print("Stage 2A logic self-test passed.")
    raise SystemExit(0 if result.wasSuccessful() else 1)
