from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

from stage3c_common import (
    atomic_write_json,
    load_config,
    project_path,
    read_json,
    sha256_file,
    utc_now,
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Package Stage 3C outputs")
    parser.add_argument("--config", default="config/stage3c.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    outputs = config["outputs"]
    output_dir = project_path(root, config["paths"]["output_dir"])
    stage3b_dir = project_path(root, config["paths"]["stage3b_output_dir"])
    validation_path = output_dir / outputs["validation_file"]
    validation = read_json(validation_path)
    if not bool(validation.get("overall_passed", False)):
        raise RuntimeError("Stage 3C validation is not PASS; packaging is forbidden")
    if [int(validation.get("n_passed", -1)), int(validation.get("n_gates", -1))] != [20, 20]:
        raise RuntimeError("Stage 3C validation gate count is not 20/20")

    relative_files = [
        Path("22_build_stage3c.bat"),
        Path("23_validate_stage3c.bat"),
        Path("24_package_stage3c.bat"),
        Path("99_stage3c_selftest.bat"),
        Path("run_stage3c_all.bat"),
        Path("STAGE3C_PROTOCOL.md"),
        Path("STAGE3C_README_UZ.md"),
        Path("config/stage3c.yml"),
        Path("scripts/22_build_stage3c.py"),
        Path("scripts/23_validate_stage3c.py"),
        Path("scripts/24_package_stage3c.py"),
        Path("scripts/selftest_stage3c.py"),
        Path("scripts/stage3c_common.py"),
        Path("logs/22_build_stage3c.log"),
        Path("logs/23_validate_stage3c.log"),
    ]
    b = config["stage3b_frozen"]
    relative_files.extend(
        Path("outputs/stage3b") / name
        for name in (
            b["build_summary_file"],
            b["freeze_manifest_file"],
            b["validation_file"],
            b["validation_report_file"],
            b["frame_definition_file"],
            b["package_manifest_file"],
        )
    )
    relative_files.extend(
        Path("outputs/stage3c") / outputs[key]
        for key in (
            "uncertainty_layer_file",
            "uncertainty_summary_file",
            "convergence_file",
            "frame_stress_file",
            "estimator_stress_file",
            "label_flow_file",
            "method_definition_file",
            "build_summary_file",
            "freeze_manifest_file",
            "validation_file",
            "validation_report_file",
        )
    )
    missing = [str(path) for path in relative_files if not (root / path).exists()]
    if missing:
        raise FileNotFoundError("Missing Stage 3C package files: " + "; ".join(missing))
    manifest = {
        "package": outputs["package_name"].removesuffix(".zip"),
        "stage": "3C",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "files": [
            {
                "path": path.as_posix(),
                "bytes": int((root / path).stat().st_size),
                "sha256": sha256_file(root / path),
            }
            for path in relative_files
        ],
        "upstream": {
            "stage3a_quality_layer_sha256": config["stage3a_frozen"][
                "quality_layer_sha256"
            ],
            "stage3b_release_sha256": b["release_sha256"],
            "stage3b_phase_space_layer_sha256": b["phase_space_layer_sha256"],
        },
        "excluded": [
            "official raw survey catalogues and the 76 frozen Gaia cache chunks",
            "the 333-MB Stage 2C transport atlas",
            "the 122-MB Stage 3A quality layer, referenced by exact SHA-256",
            "the 116-MB Stage 3B phase-space layer, referenced by exact SHA-256",
            "orbit integration, gradients, populations, and abundance inference",
        ],
        "science_boundary": config["science_boundary"],
    }
    manifest_path = output_dir / outputs["package_manifest_file"]
    atomic_write_json(manifest, manifest_path)
    package_files = [*relative_files, manifest_path.relative_to(root)]
    package_path = root / outputs["package_name"]
    temporary = package_path.with_name(f".{package_path.name}.tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(
        temporary, mode="w", compression=zipfile.ZIP_DEFLATED, compresslevel=6
    ) as archive:
        for path in package_files:
            archive.write(root / path, arcname=path.as_posix())
    temporary.replace(package_path)
    with zipfile.ZipFile(package_path, mode="r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"Packaged ZIP failed integrity at {bad}")
    print(f"Output bundle created: {package_path}")
    print(f"SHA-256: {sha256_file(package_path)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)

