from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path
from typing import Any

from stage5a_common import atomic_write_json, load_config, project_path, read_json, sha256_file


def main() -> int:
    parser = argparse.ArgumentParser(description="Package Stage 5A outputs")
    parser.add_argument("--config", default="config/stage5a.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    output = project_path(root, config["paths"]["output_dir"])
    validation = read_json(output / config["outputs"]["validation_file"])
    if not bool(validation.get("overall_passed")) or [validation.get("n_passed"), validation.get("n_gates")] != [20, 20]:
        raise RuntimeError("Stage 5A must be 20/20 PASS before packaging")
    root_files = [
        "31_build_stage5a.bat", "32_validate_stage5a.bat", "33_package_stage5a.bat",
        "99_stage5a_selftest.bat", "run_stage5a_all.bat", "STAGE5A_PROTOCOL.md",
        "STAGE5A_README_UZ.md", "STAGE5A_PATCH_MANIFEST.json", "config/stage5a.yml",
        "scripts/31_build_stage5a.py", "scripts/32_validate_stage5a.py",
        "scripts/33_package_stage5a.py", "scripts/selftest_stage5a.py", "scripts/stage5a_common.py",
    ]
    optional_logs = ["logs/31_build_stage5a.log", "logs/32_validate_stage5a.log"]
    upstream = [
        "outputs/stage4a/stage4a_design_definition.json",
        "outputs/stage4a/stage4a_population_feature_flow.csv",
        "outputs/stage4a/stage4a_build_summary.json",
        "outputs/stage4a/stage4a_freeze_manifest.json",
        "outputs/stage4a/stage4a_validation.json",
        "outputs/stage4a/stage4a_package_manifest.json",
        "outputs/stage4b/stage4b_global_gradient_estimates.csv",
        "outputs/stage4b/stage4b_gradient_sensitivity_ladder.csv",
        "outputs/stage4b/stage4b_transportability_interactions.csv",
        "outputs/stage4b/stage4b_claim_ledger.csv",
        "outputs/stage4b/stage4b_method_definition.json",
        "outputs/stage4b/stage4b_build_summary.json",
        "outputs/stage4b/stage4b_freeze_manifest.json",
        "outputs/stage4b/stage4b_validation.json",
        "outputs/stage4b/stage4b_validation_report.md",
        "outputs/stage4b/stage4b_package_manifest.json",
    ]
    stage5a = [f"outputs/stage5a/{value}" for key, value in config["outputs"].items() if key.endswith("_file") and key != "package_manifest_file"]
    files = [Path(value) for value in root_files + optional_logs + upstream + stage5a]
    missing = [str(path) for path in files if not (root / path).is_file()]
    if missing:
        raise FileNotFoundError("Missing Stage 5A package input: " + "; ".join(missing))
    manifest_path = output / config["outputs"]["package_manifest_file"]
    manifest = {
        "package": "RGB_transportability_stage5a_outputs_v0_10_0",
        "stage": "5A",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": str(config["project"]["frozen_created_utc"]),
        "upstream": {
            "stage4a_release_name": config["stage4a_frozen"]["release_name"],
            "stage4a_release_sha256": config["stage4a_frozen"]["release_sha256"],
            "stage4a_design_layer_sha256": config["stage4a_frozen"]["design_layer_sha256"],
            "stage4b_release_name": config["stage4b_frozen"]["release_name"],
            "stage4b_release_sha256": config["stage4b_frozen"]["release_sha256"],
        },
        "files": [
            {"path": path.as_posix(), "bytes": int((root / path).stat().st_size), "sha256": sha256_file(root / path)}
            for path in files
        ],
        "excluded": [
            "official raw survey catalogues and Gaia query cache chunks",
            "the 184 MB Stage 4A design layer, referenced by exact release and file SHA-256",
            "population mixture parameters, responsibilities, labels, and population-resolved gradients",
            "selection-function or inverse-probability weights",
            "C/N, C, N, Al, and Ti population features",
        ],
        "science_boundary": config["science_boundary"],
    }
    atomic_write_json(manifest, manifest_path)
    archive_files = files + [manifest_path.relative_to(root)]
    archive_path = root / config["outputs"]["package_name"]
    timestamp = (2026, 8, 3, 0, 0, 0)
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for relative in archive_files:
            source = root / relative
            info = zipfile.ZipInfo(relative.as_posix(), timestamp)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, source.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    print(f"Output bundle created: {archive_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
