from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


BASE_FEATURES = ("fe_h_hom", "alpha3_hom", "v_R_gc_kms", "v_rot_gc_kms", "v_z_gc_kms")
SOURCE_GROUPS = ("APOGEE_NATIVE", "GALAH_CORRECTED")
MAD_TO_SIGMA = 1.482602218505602


def load_config(path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {config_path}")
    return config, config_path.parent.parent


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def setup_logger(path: Path, name: str) -> logging.Logger:
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def close_logger(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        handler.flush()
        handler.close()
        logger.removeHandler(handler)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def ids_sha256(values: Sequence[int] | np.ndarray | pd.Series) -> str:
    digest = hashlib.sha256()
    for value in np.asarray(values, dtype=np.int64):
        digest.update(f"{int(value)}\n".encode("ascii"))
    return digest.hexdigest()


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="\n", dir=path.parent,
        prefix=f".{path.name}.", delete=False,
    ) as handle:
        temporary = Path(handle.name)
        json.dump(payload, handle, indent=2, sort_keys=True, ensure_ascii=True, allow_nan=False)
        handle.write("\n")
    temporary.replace(path)


def atomic_write_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="", dir=path.parent,
        prefix=f".{path.name}.", delete=False,
    ) as handle:
        temporary = Path(handle.name)
        frame.to_csv(handle, index=False, lineterminator="\n", float_format="%.17g")
    temporary.replace(path)


def flag(frame: pd.DataFrame, column: str) -> np.ndarray:
    return frame[column].fillna(False).astype(bool).to_numpy()


def number(frame: pd.DataFrame, column: str) -> np.ndarray:
    return pd.to_numeric(frame[column], errors="coerce").to_numpy(float)


def selected_input_columns() -> list[str]:
    return [
        "gaia_dr3_source_id",
        "survey_origin",
        "preferred_spectroscopic_survey",
        "analysis_teff",
        "analysis_logg",
        "fe_h_hom",
        "fe_h_hom_error_proxy",
        "fe_h_hom_source",
        "fe_h_hom_support_tier",
        "alpha3_hom",
        "alpha3_hom_error_proxy",
        "alpha3_source",
        "v_R_gc_kms",
        "v_rot_gc_kms",
        "v_z_gc_kms",
        "v_rot_gc_kms_geo_alt",
        "v_R_gc_kms__halfwidth",
        "v_rot_gc_kms__halfwidth",
        "v_z_gc_kms__halfwidth",
        "frame_vrot_sign_stable",
        "gaia_healpix5",
        "r_cyl_gc_kpc",
        "abs_z_gc_kpc",
        "population_feature_primary_ok",
        "population_feature_frame_stable_ok",
        "population_feature_gradient_common_support_sensitivity_ok",
    ]


def read_layer(path: Path, columns: Sequence[str], input_tsv: Path | None = None) -> pd.DataFrame:
    if input_tsv is not None:
        frame = pd.read_csv(input_tsv, sep="\t", low_memory=False)
        missing = [column for column in columns if column not in frame.columns]
        if missing:
            raise ValueError(f"TSV test input misses columns: {missing}")
        return frame.loc[:, list(columns)].copy()
    import pyarrow.parquet as pq

    return pq.read_table(path, columns=list(columns)).to_pandas()


def population_source_group(frame: pd.DataFrame) -> np.ndarray:
    fe = frame["fe_h_hom_source"].astype("string").fillna("NOT_AVAILABLE").to_numpy(str)
    alpha = frame["alpha3_source"].astype("string").fillna("NOT_AVAILABLE").to_numpy(str)
    output = np.full(len(frame), "MIXED_OR_OTHER", dtype=object)
    for group in SOURCE_GROUPS:
        output[(fe == group) & (alpha == group)] = group
    return output.astype(str)


def fold_for_block(block: int, namespace: str, folds: int) -> int:
    payload = f"{namespace}|{int(block)}".encode("ascii")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "little") % int(folds)


def _feature_scaling(frame: pd.DataFrame, primary: np.ndarray, config: Mapping[str, Any]) -> pd.DataFrame:
    policy = config["population_design"]["feature_scaling"]
    minimum = float(policy["minimum_scale"])
    rows: list[dict[str, Any]] = []
    for feature in BASE_FEATURES:
        values = number(frame, feature)[primary]
        if not np.isfinite(values).all():
            raise ValueError(f"Non-finite primary population feature: {feature}")
        median = float(np.median(values))
        mad = float(np.median(np.abs(values - median)))
        scale = max(float(policy["mad_to_sigma"]) * mad, minimum)
        quantiles = np.quantile(values, [0.005, 0.01, 0.10, 0.50, 0.90, 0.99, 0.995])
        rows.append({
            "feature": feature,
            "rows": int(len(values)),
            "mean": float(np.mean(values)),
            "standard_deviation": float(np.std(values, ddof=0)),
            "median": median,
            "mad": mad,
            "robust_scale": scale,
            "q005": float(quantiles[0]),
            "q01": float(quantiles[1]),
            "q10": float(quantiles[2]),
            "q50": float(quantiles[3]),
            "q90": float(quantiles[4]),
            "q99": float(quantiles[5]),
            "q995": float(quantiles[6]),
            "minimum": float(np.min(values)),
            "maximum": float(np.max(values)),
        })
    return pd.DataFrame(rows)


def _fold_tables(frame: pd.DataFrame, primary: np.ndarray, frame_stable: np.ndarray, common: np.ndarray, config: Mapping[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame]:
    blocks = pd.to_numeric(frame["gaia_healpix5"], errors="raise").to_numpy(np.int64)
    policy = config["population_design"]["cross_fitting"]
    namespace = str(policy["assignment_namespace"])
    folds = int(policy["folds"])
    unique, inverse = np.unique(blocks, return_inverse=True)
    assigned = np.asarray(
        [fold_for_block(int(block), namespace, folds) for block in unique], dtype=np.int8
    )
    fold_vector = assigned[inverse]
    candidate_counts = np.bincount(inverse, minlength=len(unique)).astype(np.int64)
    primary_counts = np.bincount(inverse, weights=primary.astype(np.int8), minlength=len(unique)).astype(np.int64)
    frame_counts = np.bincount(inverse, weights=frame_stable.astype(np.int8), minlength=len(unique)).astype(np.int64)
    common_counts = np.bincount(inverse, weights=common.astype(np.int8), minlength=len(unique)).astype(np.int64)
    fold_map = pd.DataFrame({
        "gaia_healpix5": unique.astype(np.int64),
        "fold": assigned,
        "candidate_rows": candidate_counts,
        "primary_rows": primary_counts,
        "frame_stable_rows": frame_counts,
        "common_support_rows": common_counts,
    })
    summary_rows: list[dict[str, Any]] = []
    primary_total = max(int(primary.sum()), 1)
    for fold in range(folds):
        mask = fold_vector == fold
        summary_rows.append({
            "fold": fold,
            "candidate_blocks": int(np.sum(fold_map.fold.to_numpy() == fold)),
            "primary_blocks": int(np.sum((assigned == fold) & (primary_counts > 0))),
            "candidate_rows": int(mask.sum()),
            "primary_rows": int(np.sum(mask & primary)),
            "frame_stable_rows": int(np.sum(mask & frame_stable)),
            "common_support_rows": int(np.sum(mask & common)),
            "primary_fraction": float(np.sum(mask & primary) / primary_total),
        })
    return fold_map, pd.DataFrame(summary_rows)


def _survey_balance(frame: pd.DataFrame, source_group: np.ndarray, masks: Mapping[str, np.ndarray]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for scope, scope_mask in masks.items():
        a_mask = scope_mask & (source_group == SOURCE_GROUPS[0])
        g_mask = scope_mask & (source_group == SOURCE_GROUPS[1])
        for feature in BASE_FEATURES:
            a = number(frame, feature)[a_mask]
            g = number(frame, feature)[g_mask]
            if len(a) == 0 or len(g) == 0 or not np.isfinite(a).all() or not np.isfinite(g).all():
                raise ValueError(f"Invalid survey-balance input: {scope}/{feature}")
            pooled = np.sqrt((np.var(a, ddof=0) + np.var(g, ddof=0)) / 2.0)
            rows.append({
                "scope": scope,
                "feature": feature,
                "apogee_rows": int(len(a)),
                "galah_rows": int(len(g)),
                "apogee_mean": float(np.mean(a)),
                "galah_mean": float(np.mean(g)),
                "apogee_median": float(np.median(a)),
                "galah_median": float(np.median(g)),
                "apogee_q10": float(np.quantile(a, 0.10)),
                "apogee_q90": float(np.quantile(a, 0.90)),
                "galah_q10": float(np.quantile(g, 0.10)),
                "galah_q90": float(np.quantile(g, 0.90)),
                "standardized_mean_difference_galah_minus_apogee": float((np.mean(g) - np.mean(a)) / max(pooled, 1.0e-15)),
            })
    return pd.DataFrame(rows)


def _correlations(frame: pd.DataFrame, primary: np.ndarray) -> pd.DataFrame:
    values = frame.loc[primary, list(BASE_FEATURES)].apply(pd.to_numeric, errors="coerce")
    pearson = values.corr(method="pearson")
    spearman = values.rank(method="average").corr(method="pearson")
    rows: list[dict[str, Any]] = []
    for left_index, left in enumerate(BASE_FEATURES):
        for right in BASE_FEATURES[left_index:]:
            rows.append({
                "feature_1": left,
                "feature_2": right,
                "rows": int(primary.sum()),
                "pearson_correlation": float(pearson.loc[left, right]),
                "spearman_correlation": float(spearman.loc[left, right]),
            })
    return pd.DataFrame(rows)


def _leakage_audit(config: Mapping[str, Any]) -> pd.DataFrame:
    spatial = set(config["population_design"]["spatial_gradient_covariates"])
    rows: list[dict[str, Any]] = []
    target_to_column = {"fe_h": "fe_h_hom", "alpha3": "alpha3_hom"}
    for view in config["population_design"]["model_views"]:
        features = tuple(str(value) for value in view["features"])
        for target in view["targets"]:
            target = str(target)
            target_column = target_to_column.get(target)
            target_excluded = True if target_column is None else target_column not in features
            spatial_excluded = spatial.isdisjoint(features)
            rows.append({
                "model_view": str(view["name"]),
                "target": target,
                "features": "|".join(features),
                "target_feature_excluded": bool(target_excluded),
                "spatial_gradient_covariates_excluded": bool(spatial_excluded),
                "allowed_for_population_gradient": bool(view["allowed_for_population_gradient"]),
                "passes_leakage_contract": bool(spatial_excluded and (target_excluded or not view["allowed_for_population_gradient"])),
            })
    return pd.DataFrame(rows)


def compute_design_outputs(frame: pd.DataFrame, config: Mapping[str, Any]) -> dict[str, pd.DataFrame]:
    missing = [column for column in selected_input_columns() if column not in frame.columns]
    if missing:
        raise ValueError(f"Missing Stage 5A input columns: {missing}")
    primary = flag(frame, "population_feature_primary_ok")
    frame_stable = flag(frame, "population_feature_frame_stable_ok")
    common = flag(frame, "population_feature_gradient_common_support_sensitivity_ok")
    if np.any(frame_stable & ~primary) or np.any(common & ~primary):
        raise ValueError("Population sensitivity cohorts must be subsets of the primary cohort")
    for feature in BASE_FEATURES:
        if not np.isfinite(number(frame, feature)[primary]).all():
            raise ValueError(f"Primary cohort has non-finite {feature}")
    for error in ("fe_h_hom_error_proxy", "alpha3_hom_error_proxy", "v_R_gc_kms__halfwidth", "v_rot_gc_kms__halfwidth", "v_z_gc_kms__halfwidth"):
        values = number(frame, error)[primary]
        if not np.isfinite(values).all() or np.any(values < 0):
            raise ValueError(f"Primary cohort has invalid uncertainty guard: {error}")
    source_group = population_source_group(frame)
    cohort_rows = [
        {"stage": "candidate_vector", "rows": int(len(frame))},
        {"stage": "population_feature_primary", "rows": int(primary.sum())},
        {"stage": "population_feature_frame_stable_sensitivity", "rows": int(frame_stable.sum())},
        {"stage": "population_feature_common_support_sensitivity", "rows": int(common.sum())},
    ]
    for scope_name, scope_mask in (("primary", primary), ("common_support", common)):
        for group in (*SOURCE_GROUPS, "MIXED_OR_OTHER"):
            cohort_rows.append({"stage": f"{scope_name}_{group.lower()}", "rows": int(np.sum(scope_mask & (source_group == group)))})
    cohort_flow = pd.DataFrame(cohort_rows)
    scaling = _feature_scaling(frame, primary, config)
    fold_map, fold_summary = _fold_tables(frame, primary, frame_stable, common, config)
    balance = _survey_balance(frame, source_group, {"PRIMARY": primary, "COMMON_SUPPORT": common})
    correlation = _correlations(frame, primary)
    leakage = _leakage_audit(config)
    return {
        "cohort_flow": cohort_flow,
        "feature_scaling": scaling,
        "spatial_fold_map": fold_map,
        "spatial_fold_summary": fold_summary,
        "survey_feature_balance": balance,
        "feature_correlation": correlation,
        "leakage_audit": leakage,
    }


def design_contract(config: Mapping[str, Any], input_hashes: Mapping[str, str], counts: Mapping[str, int]) -> dict[str, Any]:
    return {
        "stage": "5A leakage-safe population-inference design freeze",
        "protocol_version": str(config["project"]["version"]),
        "population_design": config["population_design"],
        "input_sha256": dict(input_hashes),
        "counts": dict(counts),
        "science_boundary": config["science_boundary"],
        "interpretive_boundary": {
            "descriptive_full_view": "catalogue description only; never used for a target abundance gradient",
            "target_safe_views": "exclude the fitted target abundance and all spatial gradient covariates",
            "cross_fitted_responsibilities": "future empirical held-out-block responsibilities, not calibrated Galactic memberships",
            "ambiguous_category": "low-responsibility diagnostic state, not a fifth physical mixture component",
        },
    }


def validation_report(payload: Mapping[str, Any]) -> str:
    lines = [
        "# Stage 5A validation report",
        "",
        f"Overall passed: **{payload['overall_passed']}**",
        "",
        f"Gates: **{payload['n_passed']}/{payload['n_gates']}**",
        "",
        "| Gate | Result | Detail |",
        "|---|---:|---|",
    ]
    for gate in payload["gates"]:
        lines.append(f"| `{gate['name']}` | {'PASS' if gate['passed'] else 'FAIL'} | {gate['detail']} |")
    lines.extend([
        "",
        "Stage 5A freezes the population-inference design only. It does not fit a mixture,",
        "assign a population label, create a component responsibility, or estimate a",
        "population-resolved gradient.",
    ])
    return "\n".join(lines) + "\n"
