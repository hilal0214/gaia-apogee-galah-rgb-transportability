from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


GAIA_SOURCE_COLUMNS = (
    "source_id",
    "ra",
    "ra_error",
    "dec",
    "dec_error",
    "parallax",
    "parallax_error",
    "parallax_over_error",
    "pmra",
    "pmra_error",
    "pmdec",
    "pmdec_error",
    "ra_dec_corr",
    "ra_parallax_corr",
    "ra_pmra_corr",
    "ra_pmdec_corr",
    "dec_parallax_corr",
    "dec_pmra_corr",
    "dec_pmdec_corr",
    "parallax_pmra_corr",
    "parallax_pmdec_corr",
    "pmra_pmdec_corr",
    "astrometric_params_solved",
    "astrometric_n_good_obs_al",
    "astrometric_gof_al",
    "astrometric_excess_noise",
    "visibility_periods_used",
    "ruwe",
    "duplicated_source",
    "ipd_frac_multi_peak",
    "phot_g_mean_mag",
    "phot_bp_mean_mag",
    "phot_rp_mean_mag",
    "bp_rp",
    "phot_bp_rp_excess_factor",
    "radial_velocity",
    "radial_velocity_error",
    "rv_nb_transits",
    "grvs_mag",
)

DISTANCE_COLUMNS = (
    "source_id",
    "r_med_geo",
    "r_lo_geo",
    "r_hi_geo",
    "r_med_photogeo",
    "r_lo_photogeo",
    "r_hi_photogeo",
)

GAIA_JOINED_COLUMNS = tuple(dict.fromkeys((*GAIA_SOURCE_COLUMNS, *DISTANCE_COLUMNS)))
CORRELATION_COLUMNS = (
    "ra_dec_corr",
    "ra_parallax_corr",
    "ra_pmra_corr",
    "ra_pmdec_corr",
    "dec_parallax_corr",
    "dec_pmra_corr",
    "dec_pmdec_corr",
    "parallax_pmra_corr",
    "parallax_pmdec_corr",
    "pmra_pmdec_corr",
)
LABELS = ("fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe", "alpha3")

CANDIDATE_COLUMNS = (
    "gaia_dr3_source_id",
    "survey_origin",
    "preferred_spectroscopic_survey",
    "spectroscopic_rgb_quality_any",
    "spectroscopic_primary_ok",
    "spectroscopic_sensitivity_ok",
    "analysis_teff",
    "analysis_teff_err",
    "analysis_logg",
    "analysis_logg_err",
    "spectroscopic_ra",
    "spectroscopic_dec",
    "spectroscopic_rv",
    "spectroscopic_rv_err",
    "fe_h_hom_primary_ok",
    "fe_h_hom_core_ok",
    "fe_h_hom_sensitivity_ok",
    "mg_fe_hom_primary_ok",
    "mg_fe_hom_core_ok",
    "mg_fe_hom_sensitivity_ok",
    "si_fe_hom_primary_ok",
    "si_fe_hom_core_ok",
    "si_fe_hom_sensitivity_ok",
    "ca_fe_hom_primary_ok",
    "ca_fe_hom_core_ok",
    "ca_fe_hom_sensitivity_ok",
    "ni_fe_hom_primary_ok",
    "ni_fe_hom_core_ok",
    "ni_fe_hom_sensitivity_ok",
    "alpha3_primary_ok",
    "alpha3_core_ok",
    "alpha3_sensitivity_ok",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_config(path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {config_path}")
    return config, config_path.parent.parent


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def setup_logger(path: Path, name: str) -> logging.Logger:
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def close_logger(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        handler.flush()
        handler.close()
        logger.removeHandler(handler)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(block_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def ids_sha256(values: Sequence[int] | np.ndarray | pd.Series) -> str:
    digest = hashlib.sha256()
    for value in np.asarray(values, dtype=np.int64):
        digest.update(f"{int(value)}\n".encode("ascii"))
    return digest.hexdigest()


def canonicalise_joined_chunk(
    frame: pd.DataFrame,
    metadata: Mapping[str, Any],
    label: str,
) -> tuple[pd.DataFrame, np.ndarray]:
    """Verify a Gaia cache chunk and return it in canonical source-ID order.

    Gaia TAP does not guarantee that uploaded-source matches are returned in the
    same order as the upload table.  Stage 1 therefore froze each chunk as an
    exact ID *set* while hashing its sorted request vector.  Canonicalising here
    preserves that frozen identity contract without treating a harmless row
    permutation as a cache failure.
    """

    ensure_columns(frame, GAIA_JOINED_COLUMNS, label)
    ids = pd.to_numeric(frame["source_id"], errors="raise").astype("int64").to_numpy()
    if len(ids) != int(metadata["requested_ids"]):
        raise RuntimeError(f"{label}: row count does not match metadata")
    if not np.all(ids > 0) or pd.Series(ids).duplicated().any():
        raise RuntimeError(f"{label}: invalid or duplicate source IDs")

    if np.all(np.diff(ids) > 0):
        canonical = frame
        canonical_ids = ids
    else:
        order = np.argsort(ids, kind="stable")
        canonical = frame.iloc[order].reset_index(drop=True)
        canonical_ids = ids[order]
    if ids_sha256(canonical_ids) != metadata["requested_ids_sha256"]:
        raise RuntimeError(f"{label}: requested-ID hash mismatch")
    if int(canonical_ids[0]) != int(metadata["first_requested_id"]) or int(
        canonical_ids[-1]
    ) != int(metadata["last_requested_id"]):
        raise RuntimeError(f"{label}: first/last source ID mismatch")
    return canonical, canonical_ids


def canonical_json_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        temporary = Path(handle.name)
    os.replace(temporary, path)


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.unlink(missing_ok=True)
    if path.suffix == ".parquet":
        frame.to_parquet(temporary, index=False, compression="zstd")
    elif path.suffix == ".csv":
        frame.to_csv(temporary, index=False)
    else:
        raise ValueError(f"Unsupported table format: {path}")
    os.replace(temporary, path)


def ensure_columns(frame: pd.DataFrame, required: Iterable[str], label: str) -> None:
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise KeyError(f"{label} is missing required columns: {missing}")


def _number(frame: pd.DataFrame, column: str) -> np.ndarray:
    return pd.to_numeric(frame[column], errors="coerce").to_numpy(float)


def _flag(frame: pd.DataFrame, column: str, missing: bool = False) -> np.ndarray:
    return (
        frame[column]
        .astype("boolean")
        .fillna(bool(missing))
        .to_numpy(dtype=bool)
    )


def valid_distance_interval(
    low: np.ndarray, median: np.ndarray, high: np.ndarray
) -> np.ndarray:
    return (
        np.isfinite(low)
        & np.isfinite(median)
        & np.isfinite(high)
        & (low > 0.0)
        & (low <= median)
        & (median <= high)
    )


def fractional_half_width(
    low: np.ndarray, median: np.ndarray, high: np.ndarray
) -> np.ndarray:
    result = np.full(len(median), np.nan, dtype=float)
    valid = valid_distance_interval(low, median, high)
    result[valid] = np.maximum(
        median[valid] - low[valid], high[valid] - median[valid]
    ) / median[valid]
    return result


def compute_quality_layer(
    candidates: pd.DataFrame,
    gaia: pd.DataFrame,
    policy: Mapping[str, Any],
) -> pd.DataFrame:
    ensure_columns(candidates, CANDIDATE_COLUMNS, "Stage 2C candidate layer")
    ensure_columns(gaia, ("gaia_dr3_source_id", *GAIA_JOINED_COLUMNS[1:]), "Gaia cache")
    if candidates["gaia_dr3_source_id"].duplicated().any():
        raise RuntimeError("Stage 2C candidate layer contains duplicate source IDs")
    if gaia["gaia_dr3_source_id"].duplicated().any():
        raise RuntimeError("Gaia candidate layer contains duplicate source IDs")

    left = candidates.sort_values("gaia_dr3_source_id", kind="mergesort").reset_index(drop=True)
    right = gaia.sort_values("gaia_dr3_source_id", kind="mergesort").reset_index(drop=True)
    if not np.array_equal(
        left["gaia_dr3_source_id"].to_numpy(np.int64),
        right["gaia_dr3_source_id"].to_numpy(np.int64),
    ):
        raise RuntimeError("Gaia candidate IDs do not exactly equal Stage 2C candidate IDs")
    result = left.merge(right, on="gaia_dr3_source_id", how="left", validate="one_to_one")

    astrometry = policy["astrometry"]
    params = _number(result, "astrometric_params_solved")
    accepted_solution = np.isin(
        params,
        np.asarray(astrometry["accepted_astrometric_params_solved"], dtype=float),
    )
    basic_values = ("ra", "dec", "parallax", "pmra", "pmdec")
    basic_errors = ("ra_error", "dec_error", "parallax_error", "pmra_error", "pmdec_error")
    finite_astrometry = np.ones(len(result), dtype=bool)
    for column in basic_values:
        finite_astrometry &= np.isfinite(_number(result, column))
    for column in basic_errors:
        values = _number(result, column)
        finite_astrometry &= np.isfinite(values) & (values > 0.0)
    finite_astrometry &= np.isfinite(_number(result, "parallax_over_error"))
    covariance_valid = np.ones(len(result), dtype=bool)
    for column in CORRELATION_COLUMNS:
        values = _number(result, column)
        covariance_valid &= np.isfinite(values) & (np.abs(values) <= 1.0)
    if astrometry.get("require_finite_five_parameter_covariance", True):
        finite_astrometry &= covariance_valid

    ruwe = _number(result, "ruwe")
    visibility = _number(result, "visibility_periods_used")
    ipd = _number(result, "ipd_frac_multi_peak")
    explicitly_not_duplicated = ~_flag(result, "duplicated_source", missing=True)
    primary_ast = astrometry["primary"]
    sensitivity_ast = astrometry["sensitivity"]
    primary_astrometry = (
        accepted_solution
        & finite_astrometry
        & np.isfinite(ruwe)
        & (ruwe < float(primary_ast["ruwe_max_exclusive"]))
        & np.isfinite(visibility)
        & (visibility >= int(primary_ast["visibility_periods_min"]))
        & np.isfinite(ipd)
        & (ipd <= float(primary_ast["ipd_frac_multi_peak_max"]))
        & explicitly_not_duplicated
    )
    sensitivity_astrometry = (
        accepted_solution
        & finite_astrometry
        & np.isfinite(ruwe)
        & (ruwe < float(sensitivity_ast["ruwe_max_exclusive"]))
        & np.isfinite(visibility)
        & (visibility >= int(sensitivity_ast["visibility_periods_min"]))
        & np.isfinite(ipd)
        & (ipd <= float(sensitivity_ast["ipd_frac_multi_peak_max"]))
        & explicitly_not_duplicated
    )

    distance = policy["distance"]
    geo_lo = _number(result, "r_lo_geo")
    geo_med = _number(result, "r_med_geo")
    geo_hi = _number(result, "r_hi_geo")
    photo_lo = _number(result, "r_lo_photogeo")
    photo_med = _number(result, "r_med_photogeo")
    photo_hi = _number(result, "r_hi_photogeo")
    geo_valid = valid_distance_interval(geo_lo, geo_med, geo_hi)
    photo_valid = valid_distance_interval(photo_lo, photo_med, photo_hi)
    geo_fraction = fractional_half_width(geo_lo, geo_med, geo_hi)
    photo_fraction = fractional_half_width(photo_lo, photo_med, photo_hi)
    photo_primary = photo_valid & (
        photo_fraction <= float(distance["primary_max_fractional_half_width"])
    )
    photo_sensitivity = photo_valid & (
        photo_fraction <= float(distance["sensitivity_max_fractional_half_width"])
    )
    geo_alternative = geo_valid & (
        geo_fraction
        <= float(distance["geometric_alternative_max_fractional_half_width"])
    )
    geo_photo_difference = np.full(len(result), np.nan, dtype=float)
    both_distance = geo_valid & photo_valid
    geo_photo_difference[both_distance] = (
        np.abs(geo_med[both_distance] - photo_med[both_distance])
        / photo_med[both_distance]
    )

    rv_policy = policy["radial_velocity"]
    spectro_rv = _number(result, "spectroscopic_rv")
    spectro_error = _number(result, "spectroscopic_rv_err")
    gaia_rv = _number(result, "radial_velocity")
    gaia_error = _number(result, "radial_velocity_error")
    gaia_transits = _number(result, "rv_nb_transits")
    spectro_finite = (
        np.isfinite(spectro_rv)
        & np.isfinite(spectro_error)
        & (spectro_error > 0.0)
    )
    gaia_finite = (
        np.isfinite(gaia_rv) & np.isfinite(gaia_error) & (gaia_error > 0.0)
    )
    spectro_primary = (
        _flag(result, "spectroscopic_primary_ok")
        & spectro_finite
        & (spectro_error <= float(rv_policy["spectroscopic_primary_error_max_kms"]))
    )
    spectro_sensitivity = (
        _flag(result, "spectroscopic_sensitivity_ok")
        & spectro_finite
        & (spectro_error <= float(rv_policy["spectroscopic_sensitivity_error_max_kms"]))
    )
    gaia_primary = (
        gaia_finite
        & (gaia_error <= float(rv_policy["gaia_primary_error_max_kms"]))
        & np.isfinite(gaia_transits)
        & (gaia_transits >= int(rv_policy["gaia_primary_transits_min"]))
    )
    gaia_sensitivity = (
        gaia_finite
        & (gaia_error <= float(rv_policy["gaia_sensitivity_error_max_kms"]))
        & np.isfinite(gaia_transits)
        & (gaia_transits >= int(rv_policy["gaia_sensitivity_transits_min"]))
    )
    rv_delta = np.full(len(result), np.nan, dtype=float)
    rv_threshold = np.full(len(result), np.nan, dtype=float)
    both_rv = spectro_sensitivity & gaia_sensitivity
    rv_delta[both_rv] = spectro_rv[both_rv] - gaia_rv[both_rv]
    rv_threshold[both_rv] = np.maximum(
        float(rv_policy["disagreement_floor_kms"]),
        float(rv_policy["disagreement_sigma"])
        * np.sqrt(spectro_error[both_rv] ** 2 + gaia_error[both_rv] ** 2),
    )
    rv_disagreement = both_rv & (np.abs(rv_delta) > rv_threshold)
    rv_primary = (spectro_primary | gaia_primary) & ~rv_disagreement
    rv_sensitivity = spectro_sensitivity | gaia_sensitivity

    choose_spectro_primary = spectro_primary
    choose_gaia_primary = ~choose_spectro_primary & gaia_primary
    choose_spectro_sensitivity = (
        ~choose_spectro_primary & ~choose_gaia_primary & spectro_sensitivity
    )
    choose_gaia_sensitivity = (
        ~choose_spectro_primary
        & ~choose_gaia_primary
        & ~choose_spectro_sensitivity
        & gaia_sensitivity
    )
    preferred_rv = np.select(
        [
            choose_spectro_primary,
            choose_gaia_primary,
            choose_spectro_sensitivity,
            choose_gaia_sensitivity,
        ],
        [spectro_rv, gaia_rv, spectro_rv, gaia_rv],
        default=np.nan,
    )
    preferred_error = np.select(
        [
            choose_spectro_primary,
            choose_gaia_primary,
            choose_spectro_sensitivity,
            choose_gaia_sensitivity,
        ],
        [spectro_error, gaia_error, spectro_error, gaia_error],
        default=np.nan,
    )
    preferred_source = np.select(
        [
            choose_spectro_primary,
            choose_gaia_primary,
            choose_spectro_sensitivity,
            choose_gaia_sensitivity,
        ],
        [
            "SPECTROSCOPIC_PRIMARY",
            "GAIA_PRIMARY",
            "SPECTROSCOPIC_SENSITIVITY",
            "GAIA_SENSITIVITY",
        ],
        default="UNAVAILABLE",
    )

    spectro_primary_gate = _flag(result, "spectroscopic_primary_ok")
    spectro_sensitivity_gate = _flag(result, "spectroscopic_sensitivity_ok")
    clean_5d_primary = spectro_primary_gate & primary_astrometry & photo_primary
    clean_5d_sensitivity = (
        spectro_sensitivity_gate & sensitivity_astrometry & photo_sensitivity
    )
    clean_6d_primary = clean_5d_primary & rv_primary
    clean_6d_sensitivity = clean_5d_sensitivity & rv_sensitivity
    clean_6d_geo_alternative = (
        spectro_sensitivity_gate
        & sensitivity_astrometry
        & geo_alternative
        & rv_sensitivity
    )

    result["gaia_astrometric_solution_ok"] = accepted_solution
    result["gaia_astrometric_values_finite"] = finite_astrometry
    result["gaia_covariance_valid"] = covariance_valid
    result["gaia_astrometry_primary_ok"] = primary_astrometry
    result["gaia_astrometry_sensitivity_ok"] = sensitivity_astrometry
    result["distance_photogeo_valid"] = photo_valid
    result["distance_photogeo_fractional_half_width"] = photo_fraction
    result["distance_photogeo_primary_ok"] = photo_primary
    result["distance_photogeo_sensitivity_ok"] = photo_sensitivity
    result["distance_geo_valid"] = geo_valid
    result["distance_geo_fractional_half_width"] = geo_fraction
    result["distance_geo_alternative_ok"] = geo_alternative
    result["distance_photo_geo_fractional_difference"] = geo_photo_difference
    result["distance_primary_pc"] = np.where(photo_valid, photo_med, np.nan)
    result["distance_primary_lo_pc"] = np.where(photo_valid, photo_lo, np.nan)
    result["distance_primary_hi_pc"] = np.where(photo_valid, photo_hi, np.nan)
    result["distance_primary_estimator"] = pd.Series(
        np.where(photo_valid, "PHOTOGEOMETRIC", "UNAVAILABLE"), dtype="string"
    )
    result["spectroscopic_rv_primary_ok"] = spectro_primary
    result["spectroscopic_rv_sensitivity_ok"] = spectro_sensitivity
    result["gaia_rv_primary_ok"] = gaia_primary
    result["gaia_rv_sensitivity_ok"] = gaia_sensitivity
    result["rv_spectro_minus_gaia_kms"] = rv_delta
    result["rv_disagreement_threshold_kms"] = rv_threshold
    result["rv_cross_source_disagreement"] = rv_disagreement
    result["analysis_rv_kms"] = preferred_rv
    result["analysis_rv_error_kms"] = preferred_error
    result["analysis_rv_source"] = pd.Series(preferred_source, dtype="string")
    result["rv_primary_ok"] = rv_primary
    result["rv_sensitivity_ok"] = rv_sensitivity
    result["clean_5d_primary_ok"] = clean_5d_primary
    result["clean_5d_sensitivity_ok"] = clean_5d_sensitivity
    result["clean_6d_primary_ok"] = clean_6d_primary
    result["clean_6d_sensitivity_ok"] = clean_6d_sensitivity
    result["clean_6d_geo_alternative_ok"] = clean_6d_geo_alternative

    for label in LABELS:
        prefix = "alpha3" if label == "alpha3" else f"{label}_hom"
        label_primary = _flag(result, f"{prefix}_primary_ok")
        label_core = _flag(result, f"{prefix}_core_ok")
        label_sensitivity = _flag(result, f"{prefix}_sensitivity_ok")
        result[f"{label}_clean5d_primary_ok"] = clean_5d_primary & label_primary
        result[f"{label}_clean6d_primary_ok"] = clean_6d_primary & label_primary
        result[f"{label}_clean6d_core_ok"] = clean_6d_primary & label_core
        result[f"{label}_clean6d_sensitivity_ok"] = (
            clean_6d_sensitivity & label_sensitivity
        )
        result[f"{label}_clean6d_geo_alternative_ok"] = (
            clean_6d_geo_alternative & label_sensitivity
        )

    return result.sort_values("gaia_dr3_source_id", kind="mergesort").reset_index(drop=True)


def load_verified_gaia_candidates(
    cache_namespace: Path,
    all_expected_ids: np.ndarray,
    candidate_ids: np.ndarray,
    stage1: Mapping[str, Any],
    query_summary: Mapping[str, Any],
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    joined_dir = cache_namespace / "joined"
    metadata_dir = cache_namespace / "metadata"
    expected_chunks = int(stage1["expected_chunks"])
    expected_indices = list(range(expected_chunks))
    joined_files = sorted(joined_dir.glob("chunk_*.parquet"))
    metadata_files = sorted(metadata_dir.glob("chunk_*.json"))
    expected_joined_names = [f"chunk_{index:05d}.parquet" for index in expected_indices]
    expected_metadata_names = [f"chunk_{index:05d}.json" for index in expected_indices]
    if [path.name for path in joined_files] != expected_joined_names:
        raise RuntimeError("Gaia joined-cache chunk set is not exactly 76 frozen chunks")
    if [path.name for path in metadata_files] != expected_metadata_names:
        raise RuntimeError("Gaia metadata chunk set is not exactly 76 frozen chunks")

    expected_all_ids = np.asarray(all_expected_ids, dtype=np.int64)
    candidate_ids = np.asarray(candidate_ids, dtype=np.int64)
    if not np.all(np.diff(expected_all_ids) > 0):
        raise RuntimeError("Expected full source-ID vector is not strictly increasing")
    if not np.all(np.diff(candidate_ids) > 0):
        raise RuntimeError("Expected candidate source-ID vector is not strictly increasing")
    candidate_index = pd.Index(candidate_ids)
    id_parts: list[np.ndarray] = []
    candidate_parts: list[pd.DataFrame] = []
    audit_rows: list[dict[str, Any]] = []
    aggregate_non_null = {column: 0 for column in GAIA_JOINED_COLUMNS}

    for index, (joined_path, metadata_path) in enumerate(
        zip(joined_files, metadata_files, strict=True)
    ):
        metadata = read_json(metadata_path)
        required_meta = {
            "mode": "full",
            "query_protocol_version": str(stage1["expected_query_protocol_version"]),
            "chunk_index": index,
            "selection_sha256": str(stage1["expected_selection_sha256"]),
            "query_signature_sha256": str(stage1["expected_query_signature_sha256"]),
        }
        for key, expected in required_meta.items():
            if metadata.get(key) != expected:
                raise RuntimeError(
                    f"{metadata_path.name}: {key}={metadata.get(key)!r}, expected {expected!r}"
                )
        frame = pd.read_parquet(joined_path, columns=list(GAIA_JOINED_COLUMNS))
        frame, ids = canonicalise_joined_chunk(frame, metadata, joined_path.name)
        metadata_non_null = metadata["column_non_null_counts"]
        for column in GAIA_JOINED_COLUMNS:
            observed = int(frame[column].notna().sum())
            expected = int(metadata_non_null[column])
            if observed != expected:
                raise RuntimeError(
                    f"{joined_path.name}: {column} non-null={observed}, expected={expected}"
                )
            aggregate_non_null[column] += observed
        selected = frame.loc[pd.Index(ids).isin(candidate_index)].copy()
        selected = selected.rename(columns={"source_id": "gaia_dr3_source_id"})
        candidate_parts.append(selected)
        id_parts.append(ids)
        audit_rows.append(
            {
                "chunk_index": index,
                "rows": int(len(frame)),
                "candidate_rows": int(len(selected)),
                "first_source_id": int(ids[0]),
                "last_source_id": int(ids[-1]),
                "requested_ids_sha256": metadata["requested_ids_sha256"],
                "joined_sha256": sha256_file(joined_path),
                "metadata_sha256": sha256_file(metadata_path),
                "geometric_distance_available": int(
                    metadata["geometric_distance_available"]
                ),
                "photogeometric_distance_available": int(
                    metadata["photogeometric_distance_available"]
                ),
            }
        )

    recovered_ids = np.concatenate(id_parts)
    if not np.array_equal(recovered_ids, expected_all_ids):
        raise RuntimeError("Reconstructed Gaia cache source-ID vector differs from Stage 2C")
    if ids_sha256(recovered_ids) != str(stage1["expected_selection_sha256"]):
        raise RuntimeError("Reconstructed full Gaia source-ID hash is not frozen selection hash")

    expected_non_null = query_summary["column_non_null_totals"]
    for column, observed in aggregate_non_null.items():
        if observed != int(expected_non_null[column]):
            raise RuntimeError(
                f"Full Gaia cache {column} non-null={observed}, expected={expected_non_null[column]}"
            )

    gaia_candidates = pd.concat(candidate_parts, ignore_index=True)
    gaia_candidates = gaia_candidates.sort_values(
        "gaia_dr3_source_id", kind="mergesort"
    ).reset_index(drop=True)
    if not np.array_equal(
        gaia_candidates["gaia_dr3_source_id"].to_numpy(np.int64), candidate_ids
    ):
        raise RuntimeError("Candidate Gaia cache extraction is not exact")

    cache_audit = pd.DataFrame(audit_rows)
    summary = {
        "cache_namespace": str(cache_namespace).replace("\\", "/"),
        "chunks": len(audit_rows),
        "full_rows": int(len(recovered_ids)),
        "candidate_rows": int(len(gaia_candidates)),
        "source_id_sha256": ids_sha256(recovered_ids),
        "aggregate_non_null": aggregate_non_null,
        "joined_chunk_set_sha256": canonical_json_sha256(
            cache_audit[["chunk_index", "joined_sha256"]].to_dict(orient="records")
        ),
        "metadata_chunk_set_sha256": canonical_json_sha256(
            cache_audit[["chunk_index", "metadata_sha256"]].to_dict(orient="records")
        ),
    }
    return gaia_candidates, cache_audit, summary


def gate_flow_table(layer: pd.DataFrame, parent_rows: int) -> pd.DataFrame:
    stages = [
        ("stage2c_parent", int(parent_rows)),
        ("spectroscopic_rgb_quality_any", int(len(layer))),
        ("spectroscopic_primary_ok", int(layer["spectroscopic_primary_ok"].sum())),
        ("gaia_astrometry_primary_ok", int(layer["gaia_astrometry_primary_ok"].sum())),
        (
            "gaia_astrometry_sensitivity_ok",
            int(layer["gaia_astrometry_sensitivity_ok"].sum()),
        ),
        ("distance_photogeo_primary_ok", int(layer["distance_photogeo_primary_ok"].sum())),
        (
            "distance_photogeo_sensitivity_ok",
            int(layer["distance_photogeo_sensitivity_ok"].sum()),
        ),
        ("distance_geo_alternative_ok", int(layer["distance_geo_alternative_ok"].sum())),
        ("rv_primary_ok", int(layer["rv_primary_ok"].sum())),
        ("rv_sensitivity_ok", int(layer["rv_sensitivity_ok"].sum())),
        ("clean_5d_primary_ok", int(layer["clean_5d_primary_ok"].sum())),
        ("clean_5d_sensitivity_ok", int(layer["clean_5d_sensitivity_ok"].sum())),
        ("clean_6d_primary_ok", int(layer["clean_6d_primary_ok"].sum())),
        ("clean_6d_sensitivity_ok", int(layer["clean_6d_sensitivity_ok"].sum())),
        (
            "clean_6d_geo_alternative_ok",
            int(layer["clean_6d_geo_alternative_ok"].sum()),
        ),
    ]
    return pd.DataFrame(stages, columns=["gate", "rows"])


def origin_flow_table(layer: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for origin in ("APOGEE_only", "GALAH_only", "overlap"):
        selected = layer.loc[layer["survey_origin"].eq(origin)]
        rows.append(
            {
                "survey_origin": origin,
                "candidate_rows": int(len(selected)),
                "spectroscopic_primary_ok": int(selected["spectroscopic_primary_ok"].sum()),
                "clean_5d_primary_ok": int(selected["clean_5d_primary_ok"].sum()),
                "clean_5d_sensitivity_ok": int(selected["clean_5d_sensitivity_ok"].sum()),
                "clean_6d_primary_ok": int(selected["clean_6d_primary_ok"].sum()),
                "clean_6d_sensitivity_ok": int(selected["clean_6d_sensitivity_ok"].sum()),
                "clean_6d_geo_alternative_ok": int(
                    selected["clean_6d_geo_alternative_ok"].sum()
                ),
            }
        )
    return pd.DataFrame(rows)


def label_flow_table(layer: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for label in LABELS:
        rows.append(
            {
                "label": label,
                "clean5d_primary": int(layer[f"{label}_clean5d_primary_ok"].sum()),
                "clean6d_primary": int(layer[f"{label}_clean6d_primary_ok"].sum()),
                "clean6d_core": int(layer[f"{label}_clean6d_core_ok"].sum()),
                "clean6d_sensitivity": int(
                    layer[f"{label}_clean6d_sensitivity_ok"].sum()
                ),
                "clean6d_geo_alternative": int(
                    layer[f"{label}_clean6d_geo_alternative_ok"].sum()
                ),
            }
        )
    return pd.DataFrame(rows)


def frame_equal(
    left: pd.DataFrame,
    right: pd.DataFrame,
    sort: Sequence[str],
    atol: float = 1.0e-12,
) -> bool:
    try:
        pd.testing.assert_frame_equal(
            left.sort_values(list(sort)).reset_index(drop=True),
            right.sort_values(list(sort)).reset_index(drop=True),
            check_dtype=False,
            check_exact=False,
            rtol=0.0,
            atol=atol,
        )
    except AssertionError:
        return False
    return True
