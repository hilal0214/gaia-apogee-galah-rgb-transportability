from __future__ import annotations

import unittest

import numpy as np
import pandas as pd

from stage2b_common import calibration_metrics, design_matrix, fit_huber_irls


TEST_CONFIG = {
    "calibration": {
        "predictor_centres": {"galah_teff_k": 4800.0, "galah_logg_dex": 2.5},
        "predictor_scales": {
            "galah_teff_k": 1000.0,
            "galah_logg_dex": 1.0,
            "galah_fe_h_dex": 1.0,
        },
    }
}


class Stage2BLogicTests(unittest.TestCase):
    def test_design_matrix_uses_galah_side_predictors(self) -> None:
        frame = pd.DataFrame(
            {
                "galah_teff": [4800.0, 5300.0],
                "galah_logg": [2.5, 3.0],
                "galah_fe_h": [-0.2, 0.1],
            }
        )
        observed = design_matrix(frame, TEST_CONFIG)
        expected = np.array([[1.0, 0.0, 0.0, -0.2], [1.0, 0.5, 0.5, 0.1]])
        self.assertTrue(np.array_equal(observed, expected))

    def test_huber_recovers_linear_relation_with_outlier_resistance(self) -> None:
        rng = np.random.default_rng(20260801)
        n = 800
        frame = pd.DataFrame(
            {
                "galah_teff": rng.uniform(3600.0, 5400.0, n),
                "galah_logg": rng.uniform(0.3, 3.4, n),
                "galah_fe_h": rng.uniform(-2.0, 0.4, n),
            }
        )
        matrix = design_matrix(frame, TEST_CONFIG)
        truth = np.array([0.02, 0.03, -0.015, 0.04])
        response = matrix @ truth + rng.normal(0.0, 0.006, n)
        response[:12] += 0.8
        fit = fit_huber_irls(
            matrix,
            response,
            huber_c=1.345,
            mad_to_sigma=1.482602218505602,
            minimum_scale=1.0e-8,
            maximum_iterations=200,
            coefficient_tolerance=1.0e-9,
        )
        self.assertTrue(fit["converged"])
        self.assertTrue(np.allclose(fit["coefficients"], truth, atol=0.0025))

    def test_huber_fit_is_row_order_invariant(self) -> None:
        rng = np.random.default_rng(77)
        matrix = np.column_stack([np.ones(300), rng.normal(size=(300, 3))])
        response = matrix @ np.array([0.1, -0.2, 0.05, 0.3]) + rng.normal(0, 0.02, 300)
        options = dict(
            huber_c=1.345,
            mad_to_sigma=1.482602218505602,
            minimum_scale=1.0e-8,
            maximum_iterations=200,
            coefficient_tolerance=1.0e-9,
        )
        first = fit_huber_irls(matrix, response, **options)["coefficients"]
        order = rng.permutation(len(response))
        second = fit_huber_irls(matrix[order], response[order], **options)["coefficients"]
        self.assertTrue(np.allclose(first, second, atol=1.0e-12, rtol=0.0))

    def test_metric_baseline_is_median_centered(self) -> None:
        raw = np.array([0.09, 0.10, 0.11, 0.12])
        residual = np.array([-0.01, 0.0, 0.0, 0.01])
        metrics = calibration_metrics(raw, residual)
        self.assertAlmostEqual(metrics["raw_median_offset_dex"], 0.105)
        self.assertAlmostEqual(metrics["post_crossfit_median_residual_dex"], 0.0)
        self.assertLess(metrics["post_to_raw_rmse_ratio"], 1.0)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Stage2BLogicTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        print("Stage 2B logic self-test passed.")
    raise SystemExit(0 if result.wasSuccessful() else 1)
