from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from stage3b_common import (
    INPUT_COLUMNS,
    atomic_write_json,
    build_phase_space_layer,
    canonical_json_sha256,
    close_logger,
    estimator_sensitivity_table,
    extreme_audit_table,
    frame_definition,
    gate_flow_table,
    ids_sha256,
    label_flow_table,
    load_config,
    origin_flow_table,
    phase_space_counts,
    project_path,
    read_json,
    setup_logger,
    sha256_file,
    utc_now,
    write_frame,
)


def require_hash(path: Path, expected: str, label: str) -> str:
    if not path.exists():
        raise FileNotFoundError(f"Missing frozen {label}: {path}")
    observed = sha256_file(path)
    if observed != expected:
        raise RuntimeError(
            f"Frozen {label} SHA-256 mismatch: {observed}; expected {expected}"
        )
    return observed


def main() -> int:
    parser = argparse.ArgumentParser(description="Build Stage 3B phase-space layer")
    parser.add_argument("--config", default="config/stage3b.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    upstream_dir = project_path(root, config["paths"]["stage3a_output_dir"])
    output_dir = project_path(root, config["paths"]["output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "19_build_stage3b.log", "stage3b.build")
    frozen = config["stage3a_frozen"]
    outputs = config["outputs"]
    paths = {
        "quality_layer": upstream_dir / frozen["quality_layer_file"],
        "stage3a_summary": upstream_dir / frozen["build_summary_file"],
        "stage3a_freeze": upstream_dir / frozen["freeze_manifest_file"],
        "stage3a_validation": upstream_dir / frozen["validation_file"],
        "stage3a_validation_report": upstream_dir / frozen["validation_report_file"],
    }
    input_hashes = {
        "stage3a_quality_layer": require_hash(
            paths["quality_layer"], frozen["quality_layer_sha256"], "Stage 3A quality layer"
        ),
        "stage3a_build_summary": require_hash(
            paths["stage3a_summary"], frozen["build_summary_sha256"], "Stage 3A build summary"
        ),
        "stage3a_freeze_manifest": require_hash(
            paths["stage3a_freeze"], frozen["freeze_manifest_sha256"], "Stage 3A freeze manifest"
        ),
        "stage3a_validation": require_hash(
            paths["stage3a_validation"], frozen["validation_sha256"], "Stage 3A validation"
        ),
        "stage3a_validation_report": require_hash(
            paths["stage3a_validation_report"],
            frozen["validation_report_sha256"],
            "Stage 3A validation report",
        ),
    }
    validation = read_json(paths["stage3a_validation"])
    if not validation.get("overall_passed", False):
        raise RuntimeError("Frozen Stage 3A validation is not PASS")
    if [int(validation.get("n_passed", -1)), int(validation.get("n_gates", -1))] != [
        int(frozen["expected_validation_gates"]),
        int(frozen["expected_validation_gates"]),
    ]:
        raise RuntimeError("Frozen Stage 3A gate count changed")

    logger.info("Reading frozen Stage 3A candidate quality layer")
    input_layer = pd.read_parquet(paths["quality_layer"], columns=list(INPUT_COLUMNS))
    if len(input_layer) != int(frozen["expected_rows"]):
        raise RuntimeError(f"Stage 3A rows={len(input_layer)}")
    ids = input_layer["gaia_dr3_source_id"].to_numpy(np.int64)
    if not np.all(np.diff(ids) > 0):
        raise RuntimeError("Stage 3A source IDs are not strictly increasing")
    if ids_sha256(ids) != frozen["expected_candidate_id_sha256"]:
        raise RuntimeError("Stage 3A candidate source-ID hash changed")
    expected_counts = {
        "clean_5d_primary_ok": int(frozen["expected_clean_5d_primary"]),
        "clean_5d_sensitivity_ok": int(frozen["expected_clean_5d_sensitivity"]),
        "clean_6d_primary_ok": int(frozen["expected_clean_6d_primary"]),
        "clean_6d_sensitivity_ok": int(frozen["expected_clean_6d_sensitivity"]),
        "clean_6d_geo_alternative_ok": int(frozen["expected_clean_6d_geo_alternative"]),
    }
    observed_counts = {
        name: int(input_layer[name].astype("boolean").fillna(False).sum())
        for name in expected_counts
    }
    if observed_counts != expected_counts:
        raise RuntimeError(
            f"Frozen Stage 3A clean counts changed: {observed_counts}; expected {expected_counts}"
        )

    logger.info("Transforming photogeometric and geometric-distance phase space")
    policy = config["phase_space_policy"]
    layer = build_phase_space_layer(input_layer, policy)
    gate_flow = gate_flow_table(layer)
    origin_flow = origin_flow_table(layer)
    label_flow = label_flow_table(layer)
    extreme_audit = extreme_audit_table(layer)
    estimator_sensitivity = estimator_sensitivity_table(layer)
    definition = frame_definition(policy["frame"])
    definition.update(
        {
            "estimator_policy": policy["estimator_policy"],
            "plausibility_policy": policy["plausibility"],
        }
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    science_paths = {
        "phase_space_layer": output_dir / outputs["phase_space_layer_file"],
        "gate_flow": output_dir / outputs["gate_flow_file"],
        "origin_flow": output_dir / outputs["origin_flow_file"],
        "label_flow": output_dir / outputs["label_flow_file"],
        "extreme_audit": output_dir / outputs["extreme_audit_file"],
        "estimator_sensitivity": output_dir / outputs["estimator_sensitivity_file"],
    }
    write_frame(layer, science_paths["phase_space_layer"])
    write_frame(gate_flow, science_paths["gate_flow"])
    write_frame(origin_flow, science_paths["origin_flow"])
    write_frame(label_flow, science_paths["label_flow"])
    write_frame(extreme_audit, science_paths["extreme_audit"])
    write_frame(estimator_sensitivity, science_paths["estimator_sensitivity"])
    definition_path = output_dir / outputs["frame_definition_file"]
    atomic_write_json(definition, definition_path)
    output_hashes = {
        path.name: sha256_file(path)
        for path in (*science_paths.values(), definition_path)
    }

    counts = phase_space_counts(layer)
    counts.update(
        {
            "extreme_primary_rejections": int(len(extreme_audit)),
            "paired_estimator_sensitivity_rows": int(
                estimator_sensitivity["paired_rows"].min()
            ),
        }
    )
    reference = layer.loc[
        layer["phase_space_6d_primary_ok"].astype(bool)
        & layer["r_cyl_gc_kpc"].between(7.0, 9.0, inclusive="both")
        & (layer["z_gc_kpc"].abs() <= 1.0),
        "v_rot_gc_kms",
    ]
    sign_diagnostic = {
        "selection": "phase_space_6d_primary_ok & 7<=R<=9 kpc & |Z|<=1 kpc",
        "rows": int(len(reference)),
        "median_v_rot_kms": float(reference.median()),
        "expected_prograde_sign": "positive v_rot = negative v_phi",
    }
    summary = {
        "stage": "3B explicit Galactocentric phase-space freeze",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "counts": counts,
        "candidate_id_sha256": ids_sha256(ids),
        "input_sha256": input_hashes,
        "output_sha256": output_hashes,
        "frame_definition": definition,
        "phase_space_policy_sha256": canonical_json_sha256(policy),
        "sign_diagnostic": sign_diagnostic,
        "upstream": {
            "stage3a_release_sha256": frozen["release_sha256"],
            "stage3a_quality_layer_sha256": frozen["quality_layer_sha256"],
        },
        "interpretation": {
            "v_phi": "Astropy right-handed cylindrical convention; prograde disc rotation is negative near the Sun",
            "v_rot": "defined exactly as -v_phi for manuscript population diagnostics",
            "plausibility": policy["plausibility"]["interpretation"],
            "uncertainty": "nominal transforms only; uncertainty propagation is explicitly deferred",
        },
        "science_boundary": config["science_boundary"],
    }
    summary_path = output_dir / outputs["build_summary_file"]
    atomic_write_json(summary, summary_path)
    freeze = {
        "stage": "3B phase-space freeze",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "candidate_id_sha256": ids_sha256(ids),
        "phase_space_policy_sha256": summary["phase_space_policy_sha256"],
        "input_sha256": input_hashes,
        "output_sha256": {
            **output_hashes,
            summary_path.name: sha256_file(summary_path),
        },
        "science_boundary": config["science_boundary"],
    }
    atomic_write_json(freeze, output_dir / outputs["freeze_manifest_file"])
    logger.info(
        "Stage 3B build complete: rows=%s; primary6D=%s; sensitivity6D=%s; primary extremes=%s",
        f"{len(layer):,}",
        f"{counts['phase_space_6d_primary_ok']:,}",
        f"{counts['phase_space_6d_sensitivity_ok']:,}",
        f"{counts['extreme_primary_rejections']:,}",
    )
    close_logger(logger)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
