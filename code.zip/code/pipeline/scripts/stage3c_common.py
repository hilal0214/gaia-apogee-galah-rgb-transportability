from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import astropy
import astropy.units as u
import numpy as np
import pandas as pd
import scipy
import yaml
from astropy.coordinates import CartesianDifferential, Galactocentric, ICRS, SkyCoord
from scipy.special import ndtri
from scipy.stats import qmc


LABELS = ("fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe", "alpha3")

METRIC_SPECS: dict[str, dict[str, Any]] = {
    "r_cyl_gc_kpc": {"kind": "position", "floor": 1.0e-4},
    "z_gc_kpc": {"kind": "position", "floor": 1.0e-4},
    "v_R_gc_kms": {"kind": "velocity", "floor": 1.0e-2},
    "v_phi_gc_kms": {"kind": "velocity", "floor": 1.0e-2},
    "v_rot_gc_kms": {"kind": "velocity", "floor": 1.0e-2},
    "v_z_gc_kms": {"kind": "velocity", "floor": 1.0e-2},
    "v_total_gc_kms": {"kind": "velocity", "floor": 1.0e-2},
    "l_z_gc_kpc_kms": {"kind": "angular_momentum", "floor": 1.0e-1},
}

ASTROMETRIC_ERROR_COLUMNS = (
    "ra_error",
    "dec_error",
    "parallax_error",
    "pmra_error",
    "pmdec_error",
)

CORRELATION_PAIRS = (
    (0, 1, "ra_dec_corr"),
    (0, 2, "ra_parallax_corr"),
    (0, 3, "ra_pmra_corr"),
    (0, 4, "ra_pmdec_corr"),
    (1, 2, "dec_parallax_corr"),
    (1, 3, "dec_pmra_corr"),
    (1, 4, "dec_pmdec_corr"),
    (2, 3, "parallax_pmra_corr"),
    (2, 4, "parallax_pmdec_corr"),
    (3, 4, "pmra_pmdec_corr"),
)

STAGE3A_COLUMNS = (
    "gaia_dr3_source_id",
    "ra",
    "dec",
    "pmra",
    "pmdec",
    *ASTROMETRIC_ERROR_COLUMNS,
    *(name for _, _, name in CORRELATION_PAIRS),
    "gaia_covariance_valid",
    "distance_primary_pc",
    "distance_primary_lo_pc",
    "distance_primary_hi_pc",
    "analysis_rv_kms",
    "analysis_rv_error_kms",
    "clean_6d_primary_ok",
)

STAGE3B_COLUMNS = (
    "gaia_dr3_source_id",
    "phase_space_6d_primary_ok",
    "phase_space_6d_sensitivity_ok",
    "phase_space_6d_geo_alternative_ok",
    *(metric for metric in METRIC_SPECS),
    *(f"{metric}_geo_alt" for metric in METRIC_SPECS),
    *(f"{label}_phase_space_primary_ok" for label in LABELS),
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_config(path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {config_path}")
    return config, config_path.parent.parent


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def setup_logger(path: Path, name: str) -> logging.Logger:
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def close_logger(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        handler.flush()
        handler.close()
        logger.removeHandler(handler)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def ids_sha256(values: Sequence[int] | np.ndarray | pd.Series) -> str:
    digest = hashlib.sha256()
    for value in np.asarray(values, dtype=np.int64):
        digest.update(f"{int(value)}\n".encode("ascii"))
    return digest.hexdigest()


def canonical_json_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def array_sha256(values: np.ndarray) -> str:
    array = np.asarray(values, dtype="<f8", order="C")
    return hashlib.sha256(array.tobytes(order="C")).hexdigest()


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        temporary = Path(handle.name)
    os.replace(temporary, path)


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.unlink(missing_ok=True)
    if path.suffix.lower() == ".parquet":
        frame.to_parquet(temporary, index=False, compression="zstd")
    elif path.suffix.lower() == ".csv":
        frame.to_csv(temporary, index=False)
    else:
        raise ValueError(f"Unsupported table format: {path}")
    os.replace(temporary, path)


def flag(frame: pd.DataFrame, column: str) -> np.ndarray:
    return frame[column].astype("boolean").fillna(False).to_numpy(dtype=bool)


def number(frame: pd.DataFrame, column: str) -> np.ndarray:
    return pd.to_numeric(frame[column], errors="coerce").to_numpy(float)


def max_abs(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    return 0.0 if len(values) == 0 else float(np.max(np.abs(values)))


def fixed_antithetic_normals(policy: Mapping[str, Any]) -> np.ndarray:
    draws = int(policy["draws"])
    pairs = draws // 2
    if draws <= 0 or draws % 2 or pairs & (pairs - 1):
        raise ValueError("Stage 3C draws/2 must be a positive power of two")
    if str(policy["generator"]) != "scipy_sobol_owen_scrambled":
        raise ValueError("Only the frozen scrambled-Sobol generator is supported")
    sampler = qmc.Sobol(d=6, scramble=True, seed=int(policy["seed"]))
    uniforms = sampler.random_base2(m=int(np.log2(pairs)))
    positive = ndtri(uniforms)
    output = np.empty((draws, 6), dtype=np.float64)
    output[0::2] = positive
    output[1::2] = -positive
    return output


def explicit_frame(policy: Mapping[str, Any]) -> Galactocentric:
    return Galactocentric(
        galcen_coord=ICRS(
            ra=float(policy["galcen_coord_ra_deg"]) * u.deg,
            dec=float(policy["galcen_coord_dec_deg"]) * u.deg,
        ),
        galcen_distance=float(policy["galcen_distance_kpc"]) * u.kpc,
        galcen_v_sun=CartesianDifferential(
            np.asarray(policy["galcen_v_sun_kms"], dtype=float) * u.km / u.s
        ),
        z_sun=float(policy["z_sun_pc"]) * u.pc,
        roll=float(policy["roll_deg"]) * u.deg,
    )


def galcen_velocity_xyz(frame: Galactocentric) -> u.Quantity:
    velocity = frame.galcen_v_sun
    if hasattr(velocity, "d_xyz"):
        return velocity.d_xyz
    if hasattr(velocity, "xyz"):
        return velocity.xyz
    raise TypeError(
        "Unsupported galcen_v_sun object: expected d_xyz or xyz components; "
        f"got {type(velocity).__name__}"
    )


def frame_definition(policy: Mapping[str, Any]) -> dict[str, Any]:
    frame = explicit_frame(policy)
    velocity = galcen_velocity_xyz(frame).to_value(u.km / u.s)
    return {
        "name": str(policy["name"]),
        "astropy_version": astropy.__version__,
        "galcen_coord_ra_deg": float(frame.galcen_coord.ra.to_value(u.deg)),
        "galcen_coord_dec_deg": float(frame.galcen_coord.dec.to_value(u.deg)),
        "galcen_distance_kpc": float(frame.galcen_distance.to_value(u.kpc)),
        "galcen_v_sun_kms": [float(item) for item in velocity],
        "z_sun_pc": float(frame.z_sun.to_value(u.pc)),
        "roll_deg": float(frame.roll.to_value(u.deg)),
    }


def resolve_frame_variants(frame_policy: Mapping[str, Any]) -> list[dict[str, Any]]:
    base = dict(frame_policy["base"])
    variants: list[dict[str, Any]] = []
    for override in frame_policy["variants"]:
        variant = dict(base)
        variant.update(dict(override))
        variants.append(variant)
    names = [item["name"] for item in variants]
    if len(names) != len(set(names)):
        raise ValueError("Frame stress variant names are not unique")
    return variants


def correlation_matrices(frame: pd.DataFrame) -> np.ndarray:
    count = len(frame)
    matrices = np.broadcast_to(np.eye(5), (count, 5, 5)).copy()
    for left, right, column in CORRELATION_PAIRS:
        values = number(frame, column)
        matrices[:, left, right] = values
        matrices[:, right, left] = values
    return matrices


def valid_distance_quantiles(frame: pd.DataFrame) -> np.ndarray:
    lower = number(frame, "distance_primary_lo_pc")
    median = number(frame, "distance_primary_pc")
    upper = number(frame, "distance_primary_hi_pc")
    return (
        np.isfinite(lower)
        & np.isfinite(median)
        & np.isfinite(upper)
        & (lower > 0.0)
        & (lower <= median)
        & (median <= upper)
    )


def piecewise_log_distance(
    latent: np.ndarray,
    lower: np.ndarray,
    median: np.ndarray,
    upper: np.ndarray,
) -> np.ndarray:
    latent = np.asarray(latent, dtype=float)
    lower = np.asarray(lower, dtype=float)[:, None]
    median = np.asarray(median, dtype=float)[:, None]
    upper = np.asarray(upper, dtype=float)[:, None]
    sigma_lower = np.log(median / lower)
    sigma_upper = np.log(upper / median)
    sigma = np.where(latent < 0.0, sigma_lower, sigma_upper)
    return np.exp(np.log(median) + sigma * latent)


def transformed_metrics(
    ra_deg: np.ndarray,
    dec_deg: np.ndarray,
    distance_pc: np.ndarray,
    pmra_masyr: np.ndarray,
    pmdec_masyr: np.ndarray,
    rv_kms: np.ndarray,
    frame_policy: Mapping[str, Any],
) -> dict[str, np.ndarray]:
    sky = SkyCoord(
        ra=np.asarray(ra_deg, dtype=float) * u.deg,
        dec=np.asarray(dec_deg, dtype=float) * u.deg,
        distance=np.asarray(distance_pc, dtype=float) * u.pc,
        pm_ra_cosdec=np.asarray(pmra_masyr, dtype=float) * u.mas / u.yr,
        pm_dec=np.asarray(pmdec_masyr, dtype=float) * u.mas / u.yr,
        radial_velocity=np.asarray(rv_kms, dtype=float) * u.km / u.s,
        frame="icrs",
    )
    gc = sky.transform_to(explicit_frame(frame_policy))
    x = gc.x.to_value(u.kpc)
    y = gc.y.to_value(u.kpc)
    z = gc.z.to_value(u.kpc)
    vx = gc.v_x.to_value(u.km / u.s)
    vy = gc.v_y.to_value(u.km / u.s)
    vz = gc.v_z.to_value(u.km / u.s)
    radius = np.hypot(x, y)
    radial = (x * vx + y * vy) / radius
    azimuthal = (x * vy - y * vx) / radius
    return {
        "r_cyl_gc_kpc": radius,
        "z_gc_kpc": z,
        "v_R_gc_kms": radial,
        "v_phi_gc_kms": azimuthal,
        "v_rot_gc_kms": -azimuthal,
        "v_z_gc_kms": vz,
        "v_total_gc_kms": np.sqrt(vx**2 + vy**2 + vz**2),
        "l_z_gc_kpc_kms": x * vy - y * vx,
        "r_sph_gc_kpc": np.sqrt(radius**2 + z**2),
    }


def propagate_chunk(
    frame: pd.DataFrame,
    uncertainty_policy: Mapping[str, Any],
    base_frame_policy: Mapping[str, Any],
    standard_draws: np.ndarray | None = None,
) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
    if standard_draws is None:
        standard_draws = fixed_antithetic_normals(uncertainty_policy)
    standard_draws = np.asarray(standard_draws, dtype=float)
    convergence_draws = int(uncertainty_policy["convergence_draws"])
    if convergence_draws <= 0 or convergence_draws >= len(standard_draws):
        raise ValueError("convergence_draws must be positive and smaller than draws")

    distance_ok = valid_distance_quantiles(frame)
    radial_error = number(frame, "analysis_rv_error_kms")
    rv_ok = np.isfinite(radial_error) & (radial_error > 0.0)
    errors = frame.loc[:, ASTROMETRIC_ERROR_COLUMNS].apply(
        pd.to_numeric, errors="coerce"
    ).to_numpy(float)
    error_ok = np.all(np.isfinite(errors) & (errors > 0.0), axis=1)
    matrices = correlation_matrices(frame)
    finite_corr = np.all(np.isfinite(matrices), axis=(1, 2))
    eigenvalues = np.linalg.eigvalsh(matrices)
    min_eigenvalue = eigenvalues[:, 0]
    psd_ok = finite_corr & (min_eigenvalue > 0.0)
    catalogue_cov_ok = flag(frame, "gaia_covariance_valid")
    valid = distance_ok & rv_ok & error_ok & psd_ok & catalogue_cov_ok
    if not np.all(valid):
        bad = int(np.count_nonzero(~valid))
        raise RuntimeError(
            f"Stage 3C primary chunk has {bad} invalid distance/RV/covariance rows; "
            "covariance repair is forbidden"
        )

    cholesky = np.linalg.cholesky(matrices)
    correlated = np.einsum(
        "dj,nkj->ndk", standard_draws[:, :5], cholesky, optimize=True
    )
    perturbation = correlated * errors[:, None, :]
    ra0 = number(frame, "ra")
    dec0 = number(frame, "dec")
    cosine = np.cos(np.deg2rad(dec0))
    if np.any(np.abs(cosine) < 1.0e-8):
        raise RuntimeError("A primary source is too close to a celestial pole")
    ra = ra0[:, None] + perturbation[:, :, 0] / (3.6e6 * cosine[:, None])
    dec = dec0[:, None] + perturbation[:, :, 1] / 3.6e6
    pmra = number(frame, "pmra")[:, None] + perturbation[:, :, 3]
    pmdec = number(frame, "pmdec")[:, None] + perturbation[:, :, 4]
    distance_latent = -correlated[:, :, 2]
    distance = piecewise_log_distance(
        distance_latent,
        number(frame, "distance_primary_lo_pc"),
        number(frame, "distance_primary_pc"),
        number(frame, "distance_primary_hi_pc"),
    )
    rv = number(frame, "analysis_rv_kms")[:, None] + (
        radial_error[:, None] * standard_draws[None, :, 5]
    )
    shape = ra.shape
    transformed = transformed_metrics(
        ra.ravel(),
        dec.ravel(),
        distance.ravel(),
        pmra.ravel(),
        pmdec.ravel(),
        rv.ravel(),
        base_frame_policy,
    )
    transformed = {name: values.reshape(shape) for name, values in transformed.items()}

    output: dict[str, np.ndarray] = {
        "covariance_min_eigenvalue": min_eigenvalue,
        "mc_plausibility_fraction": np.mean(
            (transformed["r_sph_gc_kpc"] <= float(
                uncertainty_policy["plausibility_diagnostic"][
                    "max_galactocentric_radius_kpc"
                ]
            ))
            & (transformed["v_total_gc_kms"] <= float(
                uncertainty_policy["plausibility_diagnostic"]["max_total_speed_kms"]
            )),
            axis=1,
        ),
        "mc_prograde_probability": np.mean(
            transformed["v_rot_gc_kms"] > 0.0, axis=1
        ),
    }
    convergence: dict[str, np.ndarray] = {}
    for metric in METRIC_SPECS:
        values = transformed[metric]
        quantiles = np.quantile(values, [0.16, 0.50, 0.84], axis=1, method="linear")
        half_width = 0.5 * (quantiles[2] - quantiles[0])
        short = np.quantile(
            values[:, :convergence_draws],
            [0.16, 0.50, 0.84],
            axis=1,
            method="linear",
        )
        short_half_width = 0.5 * (short[2] - short[0])
        floor = float(METRIC_SPECS[metric]["floor"])
        convergence[f"{metric}__median_abs_difference"] = np.abs(
            quantiles[1] - short[1]
        )
        convergence[f"{metric}__relative_halfwidth_difference"] = np.abs(
            half_width - short_half_width
        ) / np.maximum(half_width, floor)
        output[f"{metric}__q16"] = quantiles[0]
        output[f"{metric}__q50"] = quantiles[1]
        output[f"{metric}__q84"] = quantiles[2]
        output[f"{metric}__halfwidth"] = half_width
    return output, convergence


def metric_decimals(metric: str, policy: Mapping[str, Any]) -> int:
    rounding = policy["output_rounding"]
    kind = METRIC_SPECS[metric]["kind"]
    if kind == "position":
        return int(rounding["position_decimals"])
    if kind == "velocity":
        return int(rounding["velocity_decimals"])
    return int(rounding["angular_momentum_decimals"])


def central_transform(
    frame: pd.DataFrame,
    frame_policy: Mapping[str, Any],
    chunk_size: int = 100_000,
) -> dict[str, np.ndarray]:
    output = {name: np.full(len(frame), np.nan, dtype=float) for name in METRIC_SPECS}
    for start in range(0, len(frame), chunk_size):
        stop = min(start + chunk_size, len(frame))
        selected = frame.iloc[start:stop]
        values = transformed_metrics(
            number(selected, "ra"),
            number(selected, "dec"),
            number(selected, "distance_primary_pc"),
            number(selected, "pmra"),
            number(selected, "pmdec"),
            number(selected, "analysis_rv_kms"),
            frame_policy,
        )
        for metric in METRIC_SPECS:
            output[metric][start:stop] = values[metric]
    return output


def frame_stress(
    stage3a_primary: pd.DataFrame,
    stage3b_primary: pd.DataFrame,
    frame_policy: Mapping[str, Any],
) -> tuple[pd.DataFrame, dict[str, np.ndarray], np.ndarray, dict[str, float]]:
    base = central_transform(stage3a_primary, frame_policy["base"])
    base_differences = {
        metric: max_abs(base[metric] - number(stage3b_primary, metric))
        for metric in METRIC_SPECS
    }
    envelopes = {
        metric: np.zeros(len(stage3a_primary), dtype=float) for metric in METRIC_SPECS
    }
    nominal_vrot = number(stage3b_primary, "v_rot_gc_kms")
    sign_stable = np.ones(len(stage3a_primary), dtype=bool)
    rows: list[dict[str, Any]] = []
    for variant in resolve_frame_variants(frame_policy):
        transformed = central_transform(stage3a_primary, variant)
        for metric in METRIC_SPECS:
            delta = transformed[metric] - number(stage3b_primary, metric)
            absolute = np.abs(delta)
            envelopes[metric] = np.maximum(envelopes[metric], absolute)
            rows.append(
                {
                    "variant": variant["name"],
                    "quantity": metric,
                    "rows": int(len(delta)),
                    "signed_delta_q16": float(np.quantile(delta, 0.16)),
                    "signed_delta_median": float(np.quantile(delta, 0.50)),
                    "signed_delta_q84": float(np.quantile(delta, 0.84)),
                    "absolute_delta_median": float(np.quantile(absolute, 0.50)),
                    "absolute_delta_q95": float(np.quantile(absolute, 0.95)),
                    "absolute_delta_q99": float(np.quantile(absolute, 0.99)),
                    "absolute_delta_max": float(np.max(absolute)),
                }
            )
        sign_stable &= np.sign(transformed["v_rot_gc_kms"]) == np.sign(nominal_vrot)
    return pd.DataFrame(rows), envelopes, sign_stable, base_differences


def estimator_stress(
    stage3b: pd.DataFrame,
    primary_mask: np.ndarray,
    uncertainty_columns: Mapping[str, np.ndarray],
) -> tuple[pd.DataFrame, dict[str, np.ndarray]]:
    paired = primary_mask & flag(stage3b, "phase_space_6d_geo_alternative_ok")
    output: dict[str, np.ndarray] = {"paired": paired}
    rows: list[dict[str, Any]] = []
    for metric in METRIC_SPECS:
        delta_all = np.full(len(stage3b), np.nan, dtype=float)
        ratio_all = np.full(len(stage3b), np.nan, dtype=float)
        delta = number(stage3b, f"{metric}_geo_alt")[paired] - number(stage3b, metric)[paired]
        half_width = np.asarray(uncertainty_columns[f"{metric}__halfwidth"], dtype=float)[paired]
        ratio = np.abs(delta) / np.maximum(half_width, float(METRIC_SPECS[metric]["floor"]))
        delta_all[paired] = delta
        ratio_all[paired] = ratio
        output[f"{metric}__geo_minus_photo"] = delta_all
        output[f"{metric}__geo_abs_shift_over_mc_halfwidth"] = ratio_all
        absolute = np.abs(delta)
        rows.append(
            {
                "quantity": metric,
                "paired_rows": int(len(delta)),
                "signed_delta_q16": float(np.quantile(delta, 0.16)),
                "signed_delta_median": float(np.quantile(delta, 0.50)),
                "signed_delta_q84": float(np.quantile(delta, 0.84)),
                "absolute_delta_median": float(np.quantile(absolute, 0.50)),
                "absolute_delta_q95": float(np.quantile(absolute, 0.95)),
                "absolute_delta_q99": float(np.quantile(absolute, 0.99)),
                "shift_over_mc_halfwidth_median": float(np.quantile(ratio, 0.50)),
                "shift_over_mc_halfwidth_q95": float(np.quantile(ratio, 0.95)),
                "fraction_over_one_halfwidth": float(np.mean(ratio > 1.0)),
                "fraction_over_two_halfwidths": float(np.mean(ratio > 2.0)),
            }
        )
    return pd.DataFrame(rows), output


def method_definition(config: Mapping[str, Any]) -> dict[str, Any]:
    normals = fixed_antithetic_normals(config["uncertainty_policy"])
    return {
        "stage": "3C formal-random phase-space uncertainty and transport stress",
        "protocol_version": config["project"]["version"],
        "runtime": {
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scipy": scipy.__version__,
            "astropy": astropy.__version__,
        },
        "ensemble": {
            "draws": int(len(normals)),
            "dimensions": int(normals.shape[1]),
            "sha256_little_endian_float64": array_sha256(normals),
            "policy": config["uncertainty_policy"],
        },
        "base_frame": frame_definition(config["frame_policy"]["base"]),
        "frame_stress_variants": [
            frame_definition(item) for item in resolve_frame_variants(config["frame_policy"])
        ],
        "frame_stress_interpretation": config["frame_policy"]["stress_interpretation"],
        "metrics": list(METRIC_SPECS),
        "distance_formula": {
            "latent": "z_distance = -z_correlated_parallax",
            "lower_branch": "r = r_med * exp(log(r_med/r_lo) * z_distance)",
            "upper_branch": "r = r_med * exp(log(r_hi/r_med) * z_distance)",
            "interpretation": "three-quantile Gaussian-copula approximation, not the exact posterior",
        },
        "new_primary_gate_created": False,
        "science_boundary": config["science_boundary"],
    }


def deterministic_subset_positions(primary_mask: np.ndarray, rows: int) -> np.ndarray:
    primary = np.flatnonzero(np.asarray(primary_mask, dtype=bool))
    if len(primary) <= rows:
        return primary
    positions = np.linspace(0, len(primary) - 1, num=rows, dtype=np.int64)
    return primary[positions]


def science_output_hashes(paths: Iterable[Path]) -> dict[str, str]:
    return {path.name: sha256_file(path) for path in paths}
