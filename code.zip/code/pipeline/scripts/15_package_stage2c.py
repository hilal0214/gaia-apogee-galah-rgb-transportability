from __future__ import annotations

import argparse
import os
import sys
import zipfile
from pathlib import Path
from typing import Any

from stage2c_common import (
    atomic_write_json,
    load_config,
    project_path,
    read_json,
    sha256_file,
    utc_now,
)


def file_record(root: Path, path: Path) -> dict[str, Any]:
    return {
        "path": str(path.relative_to(root)).replace("\\", "/"),
        "bytes": int(path.stat().st_size),
        "sha256": sha256_file(path),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Package Stage 2C outputs")
    parser.add_argument("--config", default="config/stage2c.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    outputs = config["outputs"]
    output_dir = project_path(root, config["paths"]["output_dir"])
    stage1_dir = project_path(root, config["paths"]["stage1_output_dir"])
    stage2a_dir = project_path(root, config["paths"]["stage2a_output_dir"])
    stage2b_dir = project_path(root, config["paths"]["stage2b_output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])

    validation_path = output_dir / outputs["validation_file"]
    validation = read_json(validation_path)
    if not validation.get("overall_passed", False):
        raise RuntimeError("Stage 2C validation is not PASS; refusing to package")

    relative_files = [
        "13_run_stage2c.bat",
        "14_validate_stage2c.bat",
        "15_package_stage2c.bat",
        "99_stage2c_selftest.bat",
        "run_stage2c_all.bat",
        "STAGE2C_PROTOCOL.md",
        "STAGE2C_README_UZ.md",
        "config/stage2c.yml",
        "scripts/13_run_stage2c.py",
        "scripts/14_validate_stage2c.py",
        "scripts/15_package_stage2c.py",
        "scripts/selftest_stage2c.py",
        "scripts/stage2c_common.py",
    ]
    files = [root / value for value in relative_files]
    files.extend(
        [
            log_dir / "13_run_stage2c.log",
            log_dir / "14_validate_stage2c.log",
            stage1_dir / config["stage1_frozen"]["census_summary_file"],
            stage1_dir / config["stage1_frozen"]["validation_file"],
            stage2a_dir / config["stage2a_frozen"]["validation_file"],
            stage2b_dir / config["stage2b_frozen"]["deploy_models_file"],
            stage2b_dir / config["stage2b_frozen"]["coefficients_file"],
            stage2b_dir / config["stage2b_frozen"]["metrics_file"],
            stage2b_dir / config["stage2b_frozen"]["freeze_manifest_file"],
            stage2b_dir / config["stage2b_frozen"]["validation_file"],
            output_dir / outputs["atlas_file"],
            output_dir / outputs["element_flow_file"],
            output_dir / outputs["origin_element_flow_file"],
            output_dir / outputs["support_bounds_file"],
            output_dir / outputs["build_summary_file"],
            output_dir / outputs["freeze_manifest_file"],
            output_dir / outputs["validation_file"],
            output_dir / outputs["validation_report_file"],
        ]
    )
    missing = [str(path) for path in files if not path.exists()]
    if missing:
        raise FileNotFoundError("Cannot package missing files: " + "; ".join(missing))

    manifest = {
        "package": outputs["package_name"].removesuffix(".zip"),
        "stage": "2C",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "files": [file_record(root, path) for path in files],
        "upstream": {
            "stage1_release_sha256": config["stage1_frozen"]["release_sha256"],
            "stage2a_release_sha256": config["stage2a_frozen"]["release_sha256"],
            "stage2b_release_sha256": config["stage2b_frozen"]["release_sha256"],
        },
        "excluded": [
            "official raw FITS catalogues",
            "Stage 1 restartable Gaia cache",
            "Stage 1 full survey-level interim tables",
            "Stage 2A 24-MiB overlap table, referenced by exact SHA-256",
            "Stage 2B 120,005-row held-out prediction table, referenced by exact SHA-256",
            "Gaia clean selection, Galactocentric phase space, gradients, and population products",
        ],
        "science_boundary": config["science_boundary"],
    }
    manifest_path = output_dir / outputs["package_manifest_file"]
    atomic_write_json(manifest, manifest_path)
    files_with_manifest = [*files, manifest_path]

    package_path = root / outputs["package_name"]
    temporary = package_path.with_name(f".{package_path.name}.tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(
        temporary,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
        allowZip64=True,
    ) as archive:
        for path in files_with_manifest:
            archive.write(path, arcname=str(path.relative_to(root)).replace("\\", "/"))
    os.replace(temporary, package_path)
    print(f"Output bundle created: {package_path}")
    print(f"SHA-256: {sha256_file(package_path)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)

