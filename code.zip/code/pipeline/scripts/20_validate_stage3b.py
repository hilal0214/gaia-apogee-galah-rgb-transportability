from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from stage3b_common import (
    INPUT_COLUMNS,
    LABELS,
    atomic_write_json,
    build_phase_space_layer,
    canonical_json_sha256,
    close_logger,
    estimator_sensitivity_table,
    explicit_frame,
    extreme_audit_table,
    frame_definition,
    frame_equal,
    gate_flow_table,
    ids_sha256,
    label_flow_table,
    load_config,
    origin_flow_table,
    phase_space_counts,
    project_path,
    read_json,
    setup_logger,
    sha256_file,
    utc_now,
)


def add_gate(
    gates: list[dict[str, Any]],
    name: str,
    passed: bool,
    observed: Any,
    expected: Any,
    detail: str,
) -> None:
    gates.append(
        {
            "name": name,
            "passed": bool(passed),
            "observed": observed,
            "expected": expected,
            "detail": detail,
        }
    )


def flag(frame: pd.DataFrame, column: str) -> np.ndarray:
    return frame[column].astype("boolean").fillna(False).to_numpy(dtype=bool)


def number(frame: pd.DataFrame, column: str) -> np.ndarray:
    return pd.to_numeric(frame[column], errors="coerce").to_numpy(float)


def max_abs(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    return 0.0 if len(values) == 0 else float(np.max(np.abs(values)))


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Stage 3B phase-space layer")
    parser.add_argument("--config", default="config/stage3b.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    upstream_dir = project_path(root, config["paths"]["stage3a_output_dir"])
    output_dir = project_path(root, config["paths"]["output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "20_validate_stage3b.log", "stage3b.validate")
    frozen = config["stage3a_frozen"]
    outputs = config["outputs"]
    paths = {
        "quality_layer": upstream_dir / frozen["quality_layer_file"],
        "stage3a_summary": upstream_dir / frozen["build_summary_file"],
        "stage3a_freeze": upstream_dir / frozen["freeze_manifest_file"],
        "stage3a_validation": upstream_dir / frozen["validation_file"],
        "stage3a_validation_report": upstream_dir / frozen["validation_report_file"],
        "phase_space_layer": output_dir / outputs["phase_space_layer_file"],
        "gate_flow": output_dir / outputs["gate_flow_file"],
        "origin_flow": output_dir / outputs["origin_flow_file"],
        "label_flow": output_dir / outputs["label_flow_file"],
        "extreme_audit": output_dir / outputs["extreme_audit_file"],
        "estimator_sensitivity": output_dir / outputs["estimator_sensitivity_file"],
        "frame_definition": output_dir / outputs["frame_definition_file"],
        "summary": output_dir / outputs["build_summary_file"],
        "freeze": output_dir / outputs["freeze_manifest_file"],
    }
    missing = [str(path) for path in paths.values() if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing Stage 3B validation inputs: " + "; ".join(missing))
    gates: list[dict[str, Any]] = []

    upstream_observed = {
        "stage3a_quality_layer": sha256_file(paths["quality_layer"]),
        "stage3a_build_summary": sha256_file(paths["stage3a_summary"]),
        "stage3a_freeze_manifest": sha256_file(paths["stage3a_freeze"]),
        "stage3a_validation": sha256_file(paths["stage3a_validation"]),
        "stage3a_validation_report": sha256_file(paths["stage3a_validation_report"]),
    }
    upstream_expected = {
        "stage3a_quality_layer": frozen["quality_layer_sha256"],
        "stage3a_build_summary": frozen["build_summary_sha256"],
        "stage3a_freeze_manifest": frozen["freeze_manifest_sha256"],
        "stage3a_validation": frozen["validation_sha256"],
        "stage3a_validation_report": frozen["validation_report_sha256"],
    }
    add_gate(
        gates,
        "upstream_byte_identity",
        upstream_observed == upstream_expected,
        upstream_observed,
        upstream_expected,
        "the accepted Stage 3A products are byte-identical",
    )

    stage3a_validation = read_json(paths["stage3a_validation"])
    validation_observed = {
        "overall_passed": bool(stage3a_validation.get("overall_passed", False)),
        "n_passed": int(stage3a_validation.get("n_passed", -1)),
        "n_gates": int(stage3a_validation.get("n_gates", -1)),
    }
    validation_expected = {
        "overall_passed": True,
        "n_passed": int(frozen["expected_validation_gates"]),
        "n_gates": int(frozen["expected_validation_gates"]),
    }
    add_gate(
        gates,
        "upstream_validation",
        validation_observed == validation_expected,
        validation_observed,
        validation_expected,
        "Stage 3A remains frozen PASS",
    )

    parquet_metadata = pq.ParquetFile(paths["quality_layer"])
    input_layer = pd.read_parquet(paths["quality_layer"], columns=list(INPUT_COLUMNS))
    input_ids = input_layer["gaia_dr3_source_id"].to_numpy(np.int64)
    input_observed = {
        "rows": int(len(input_layer)),
        "columns": int(len(parquet_metadata.schema_arrow.names)),
        "strictly_increasing": bool(np.all(np.diff(input_ids) > 0)),
        "duplicates": int(pd.Series(input_ids).duplicated().sum()),
        "candidate_id_sha256": ids_sha256(input_ids),
        "clean_5d_primary": int(flag(input_layer, "clean_5d_primary_ok").sum()),
        "clean_5d_sensitivity": int(flag(input_layer, "clean_5d_sensitivity_ok").sum()),
        "clean_6d_primary": int(flag(input_layer, "clean_6d_primary_ok").sum()),
        "clean_6d_sensitivity": int(flag(input_layer, "clean_6d_sensitivity_ok").sum()),
        "clean_6d_geo_alternative": int(flag(input_layer, "clean_6d_geo_alternative_ok").sum()),
    }
    input_expected = {
        "rows": int(frozen["expected_rows"]),
        "columns": int(frozen["expected_columns"]),
        "strictly_increasing": True,
        "duplicates": 0,
        "candidate_id_sha256": frozen["expected_candidate_id_sha256"],
        "clean_5d_primary": int(frozen["expected_clean_5d_primary"]),
        "clean_5d_sensitivity": int(frozen["expected_clean_5d_sensitivity"]),
        "clean_6d_primary": int(frozen["expected_clean_6d_primary"]),
        "clean_6d_sensitivity": int(frozen["expected_clean_6d_sensitivity"]),
        "clean_6d_geo_alternative": int(frozen["expected_clean_6d_geo_alternative"]),
    }
    add_gate(
        gates,
        "stage3a_input_identity",
        input_observed == input_expected,
        input_observed,
        input_expected,
        "the complete 393,834-row Stage 3A candidate vector is preserved",
    )

    policy = config["phase_space_policy"]
    definition = read_json(paths["frame_definition"])
    expected_definition = frame_definition(policy["frame"])
    frame_keys = tuple(expected_definition)
    frame_observed = {key: definition.get(key) for key in frame_keys}
    frame_runtime = explicit_frame(policy["frame"])
    frame_checks = {
        "definition_exact": frame_observed == expected_definition,
        "policy_sha256": canonical_json_sha256(policy["frame"]),
        "runtime_distance_kpc": float(frame_runtime.galcen_distance.to_value("kpc")),
        "runtime_z_sun_pc": float(frame_runtime.z_sun.to_value("pc")),
    }
    frame_expected = {
        "definition_exact": True,
        "policy_sha256": expected_definition["policy_sha256"],
        "runtime_distance_kpc": 8.122,
        "runtime_z_sun_pc": 20.8,
    }
    add_gate(
        gates,
        "explicit_frame_freeze",
        frame_checks == frame_expected,
        frame_checks,
        frame_expected,
        "all Galactocentric frame parameters are explicit and version-recorded",
    )

    observed_layer = pd.read_parquet(paths["phase_space_layer"])
    output_ids = observed_layer["gaia_dr3_source_id"].to_numpy(np.int64)
    output_identity = {
        "rows": int(len(observed_layer)),
        "columns": int(len(observed_layer.columns)),
        "strictly_increasing": bool(np.all(np.diff(output_ids) > 0)),
        "candidate_id_sha256": ids_sha256(output_ids),
        "ids_equal_input": bool(np.array_equal(output_ids, input_ids)),
    }
    summary = read_json(paths["summary"])
    output_identity_expected = {
        "rows": int(frozen["expected_rows"]),
        "columns": int(summary["counts"]["columns"]),
        "strictly_increasing": True,
        "candidate_id_sha256": frozen["expected_candidate_id_sha256"],
        "ids_equal_input": True,
    }
    add_gate(
        gates,
        "phase_space_output_identity",
        output_identity == output_identity_expected,
        output_identity,
        output_identity_expected,
        "Stage 3B is a one-to-one augmentation of the Stage 3A candidate layer",
    )

    logger.info("Independently recomputing both Galactocentric transforms and all flags")
    expected_layer = build_phase_space_layer(input_layer, policy)
    layer_exact = frame_equal(
        observed_layer,
        expected_layer,
        ["gaia_dr3_source_id"],
        atol=float(config["validation"]["numeric_absolute_tolerance"]),
    )
    add_gate(
        gates,
        "complete_transform_recomputation",
        layer_exact,
        {"exact_within_tolerance": layer_exact, "rows": int(len(observed_layer))},
        {"exact_within_tolerance": True, "rows": int(frozen["expected_rows"])},
        "photogeometric and geometric transforms plus eligibility flags recompute",
    )

    finite = flag(observed_layer, "photo_velocity_finite")
    x = number(observed_layer, "x_gc_kpc")
    y = number(observed_layer, "y_gc_kpc")
    z = number(observed_layer, "z_gc_kpc")
    vx = number(observed_layer, "v_x_gc_kms")
    vy = number(observed_layer, "v_y_gc_kms")
    vz = number(observed_layer, "v_z_gc_kms")
    radius = number(observed_layer, "r_cyl_gc_kpc")
    spherical = number(observed_layer, "r_sph_gc_kpc")
    v_r = number(observed_layer, "v_R_gc_kms")
    v_phi = number(observed_layer, "v_phi_gc_kms")
    v_rot = number(observed_layer, "v_rot_gc_kms")
    speed = number(observed_layer, "v_total_gc_kms")
    angular_momentum = number(observed_layer, "l_z_gc_kpc_kms")
    safe = finite & (radius > 0.0)
    algebra = {
        "r_cyl_max_absdiff": max_abs(radius[safe] - np.hypot(x[safe], y[safe])),
        "r_sph_max_absdiff": max_abs(
            spherical[safe] - np.sqrt(x[safe] ** 2 + y[safe] ** 2 + z[safe] ** 2)
        ),
        "v_R_max_absdiff": max_abs(
            v_r[safe] - (x[safe] * vx[safe] + y[safe] * vy[safe]) / radius[safe]
        ),
        "v_phi_max_absdiff": max_abs(
            v_phi[safe] - (x[safe] * vy[safe] - y[safe] * vx[safe]) / radius[safe]
        ),
        "v_rot_plus_v_phi_max_abs": max_abs(v_rot[safe] + v_phi[safe]),
        "speed_max_absdiff": max_abs(
            speed[safe] - np.sqrt(vx[safe] ** 2 + vy[safe] ** 2 + vz[safe] ** 2)
        ),
        "l_z_max_absdiff": max_abs(
            angular_momentum[safe] - (x[safe] * vy[safe] - y[safe] * vx[safe])
        ),
    }
    algebra_tolerance = float(config["validation"]["algebra_absolute_tolerance"])
    algebra_pass = all(value <= algebra_tolerance for value in algebra.values())
    add_gate(
        gates,
        "cylindrical_algebra",
        algebra_pass,
        algebra,
        {"maximum_allowed_absolute_difference": algebra_tolerance},
        "Cartesian, cylindrical, speed, angular-momentum, and sign identities hold",
    )

    sign_policy = config["validation"]["solar_cylinder_sign_audit"]
    reference = (
        flag(observed_layer, "phase_space_6d_primary_ok")
        & (radius >= float(sign_policy["r_min_kpc"]))
        & (radius <= float(sign_policy["r_max_kpc"]))
        & (np.abs(z) <= float(sign_policy["abs_z_max_kpc"]))
    )
    sign_observed = {
        "rows": int(reference.sum()),
        "median_v_phi_kms": float(np.nanmedian(v_phi[reference])),
        "median_v_rot_kms": float(np.nanmedian(v_rot[reference])),
        "v_rot_equals_negative_v_phi": bool(np.all(v_rot[finite] == -v_phi[finite])),
    }
    sign_pass = bool(
        sign_observed["rows"] >= int(sign_policy["minimum_rows"])
        and float(sign_policy["median_vrot_min_kms"])
        <= sign_observed["median_v_rot_kms"]
        <= float(sign_policy["median_vrot_max_kms"])
        and sign_observed["median_v_phi_kms"] < 0.0
        and sign_observed["v_rot_equals_negative_v_phi"]
    )
    add_gate(
        gates,
        "rotation_sign_audit",
        sign_pass,
        sign_observed,
        {
            "minimum_rows": int(sign_policy["minimum_rows"]),
            "median_v_phi_sign": "negative",
            "median_v_rot_range_kms": [
                float(sign_policy["median_vrot_min_kms"]),
                float(sign_policy["median_vrot_max_kms"]),
            ],
            "v_rot_equals_negative_v_phi": True,
        },
        "the manuscript v_rot=-v_phi convention correctly maps prograde disc rotation positive",
    )

    primary = flag(observed_layer, "phase_space_6d_primary_ok")
    sensitivity = flag(observed_layer, "phase_space_6d_sensitivity_ok")
    primary5 = flag(observed_layer, "phase_space_5d_primary_ok")
    sensitivity5 = flag(observed_layer, "phase_space_5d_sensitivity_ok")
    geo = flag(observed_layer, "phase_space_6d_geo_alternative_ok")
    nested = {
        "primary6_not_sensitivity6": int((primary & ~sensitivity).sum()),
        "primary5_not_sensitivity5": int((primary5 & ~sensitivity5).sum()),
        "primary6_not_primary5": int((primary & ~primary5).sum()),
        "geo_rows": int(geo.sum()),
    }
    nested_pass = all(nested[key] == 0 for key in nested if key != "geo_rows")
    add_gate(
        gates,
        "nested_phase_space_sets",
        nested_pass,
        nested,
        {
            "primary6_not_sensitivity6": 0,
            "primary5_not_sensitivity5": 0,
            "primary6_not_primary5": 0,
        },
        "primary, sensitivity, 5D, and 6D phase-space sets preserve nesting",
    )

    cuts = policy["plausibility"]
    plausibility_observed = {
        "primary_radius_violations": int(
            (primary & (spherical > float(cuts["primary_max_galactocentric_radius_kpc"]))).sum()
        ),
        "primary_speed_violations": int(
            (primary & (speed > float(cuts["primary_max_total_speed_kms"]))).sum()
        ),
        "escape_speed_model_used": bool(cuts["escape_speed_model_used"]),
        "potential_boundness_claimed": bool(cuts["potential_boundness_claimed"]),
        "policy_sha256": canonical_json_sha256(policy),
    }
    plausibility_expected = {
        "primary_radius_violations": 0,
        "primary_speed_violations": 0,
        "escape_speed_model_used": False,
        "potential_boundness_claimed": False,
        "policy_sha256": summary["phase_space_policy_sha256"],
    }
    add_gate(
        gates,
        "catastrophic_plausibility_policy",
        plausibility_observed == plausibility_expected,
        plausibility_observed,
        plausibility_expected,
        "broad radius/speed guards are exact and are not presented as escape-speed cuts",
    )

    label_nested = True
    label_counts: dict[str, Any] = {}
    for label in LABELS:
        core = flag(observed_layer, f"{label}_phase_space_core_ok")
        label_primary = flag(observed_layer, f"{label}_phase_space_primary_ok")
        label_sensitivity = flag(observed_layer, f"{label}_phase_space_sensitivity_ok")
        label_nested &= bool(
            np.all(~core | label_primary) and np.all(~label_primary | label_sensitivity)
        )
        label_counts[label] = {
            "core": int(core.sum()),
            "primary": int(label_primary.sum()),
            "sensitivity": int(label_sensitivity.sum()),
            "geo_alternative": int(
                flag(observed_layer, f"{label}_phase_space_geo_alternative_ok").sum()
            ),
        }
    add_gate(
        gates,
        "label_specific_phase_space",
        label_nested,
        {"nested": label_nested, "counts": label_counts},
        {"nested": True},
        "all six abundance-label supports inherit the frozen phase-space gates",
    )

    expected_gate_flow = gate_flow_table(expected_layer)
    expected_origin_flow = origin_flow_table(expected_layer)
    expected_label_flow = label_flow_table(expected_layer)
    flows_exact = frame_equal(pd.read_csv(paths["gate_flow"]), expected_gate_flow, ["gate"])
    flows_exact &= frame_equal(
        pd.read_csv(paths["origin_flow"]), expected_origin_flow, ["survey_origin"]
    )
    flows_exact &= frame_equal(pd.read_csv(paths["label_flow"]), expected_label_flow, ["label"])
    add_gate(
        gates,
        "flow_table_recomputation",
        flows_exact,
        {"exact": flows_exact, "tables": 3},
        {"exact": True, "tables": 3},
        "gate, survey-origin, and label flow tables recompute from the phase-space layer",
    )

    expected_sensitivity = estimator_sensitivity_table(expected_layer)
    sensitivity_exact = frame_equal(
        pd.read_csv(paths["estimator_sensitivity"]),
        expected_sensitivity,
        ["quantity"],
        atol=1.0e-12,
    )
    add_gate(
        gates,
        "distance_estimator_sensitivity",
        sensitivity_exact,
        {"exact": sensitivity_exact, "quantities": int(len(expected_sensitivity))},
        {"exact": True, "quantities": 6},
        "paired photogeometric-versus-geometric diagnostics recompute",
    )

    expected_extreme = extreme_audit_table(expected_layer)
    extreme_exact = frame_equal(
        pd.read_csv(paths["extreme_audit"]),
        expected_extreme,
        ["gaia_dr3_source_id"],
        atol=float(config["validation"]["numeric_absolute_tolerance"]),
    )
    add_gate(
        gates,
        "extreme_row_audit",
        extreme_exact,
        {"exact": extreme_exact, "rows": int(len(expected_extreme))},
        {"exact": True, "rows": int(len(expected_extreme))},
        "every Stage 3A primary row rejected by the broad plausibility guard is listed",
    )

    counts = phase_space_counts(observed_layer)
    counts_exact = all(counts[key] == int(summary["counts"][key]) for key in counts)
    add_gate(
        gates,
        "summary_count_recomputation",
        counts_exact,
        counts,
        {key: int(summary["counts"][key]) for key in counts},
        "all principal phase-space counts reproduce from the Parquet layer",
    )

    freeze = read_json(paths["freeze"])
    current_outputs = {
        paths["phase_space_layer"].name: sha256_file(paths["phase_space_layer"]),
        paths["gate_flow"].name: sha256_file(paths["gate_flow"]),
        paths["origin_flow"].name: sha256_file(paths["origin_flow"]),
        paths["label_flow"].name: sha256_file(paths["label_flow"]),
        paths["extreme_audit"].name: sha256_file(paths["extreme_audit"]),
        paths["estimator_sensitivity"].name: sha256_file(paths["estimator_sensitivity"]),
        paths["frame_definition"].name: sha256_file(paths["frame_definition"]),
        paths["summary"].name: sha256_file(paths["summary"]),
    }
    output_hash_exact = current_outputs == freeze["output_sha256"]
    output_hash_exact &= all(
        current_outputs[name] == digest
        for name, digest in summary["output_sha256"].items()
    )
    add_gate(
        gates,
        "output_hash_freeze",
        output_hash_exact,
        current_outputs,
        freeze["output_sha256"],
        "all Stage 3B science products retain frozen byte identities",
    )

    forbidden_patterns = (
        "gradient_",
        "population_class",
        "orbit_",
        "action_",
        "bound_probability",
        "escape_speed",
        "mc_",
    )
    forbidden_present = sorted(
        column
        for column in observed_layer.columns
        if any(pattern in column.lower() for pattern in forbidden_patterns)
    )
    boundary_observed = {
        "summary": summary["science_boundary"],
        "freeze": freeze["science_boundary"],
        "forbidden_columns_present": forbidden_present,
    }
    boundary_expected = {
        "summary": config["science_boundary"],
        "freeze": config["science_boundary"],
        "forbidden_columns_present": [],
    }
    add_gate(
        gates,
        "stage3b_science_boundary",
        boundary_observed == boundary_expected,
        boundary_observed,
        boundary_expected,
        "phase-space construction only; no potential, orbit, uncertainty, gradient, or population inference",
    )

    n_passed = sum(bool(item["passed"]) for item in gates)
    result = {
        "stage": "3B validation",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "overall_passed": n_passed == len(gates),
        "n_gates": len(gates),
        "n_passed": n_passed,
        "gates": gates,
    }
    validation_path = output_dir / outputs["validation_file"]
    atomic_write_json(result, validation_path)
    report_lines = [
        "# Stage 3B validation report",
        "",
        f"Overall: **{'PASS' if result['overall_passed'] else 'FAIL'}**",
        "",
        f"Protocol: `{config['project']['version']}`",
        "",
        "| Gate | Result | Detail |",
        "|---|---:|---|",
    ]
    for item in gates:
        report_lines.append(
            f"| `{item['name']}` | {'PASS' if item['passed'] else 'FAIL'} | {item['detail']} |"
        )
    report_lines.extend(
        [
            "",
            "Stage 3B freezes explicit nominal Galactocentric phase space and a broad catastrophic-transform guard. Potential-dependent boundness, orbit integration, uncertainty propagation, gradients, and population inference remain outside this stage.",
            "",
        ]
    )
    (output_dir / outputs["validation_report_file"]).write_text(
        "\n".join(report_lines), encoding="utf-8"
    )
    logger.info(
        "Stage 3B validation passed=%s; gates=%d/%d",
        result["overall_passed"],
        n_passed,
        len(gates),
    )
    close_logger(logger)
    return 0 if result["overall_passed"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
