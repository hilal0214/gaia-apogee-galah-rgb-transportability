from __future__ import annotations

import argparse
import json
import os
import zipfile
from pathlib import Path

from stage1_common import (
    atomic_write_json,
    configured_paths,
    load_config,
    read_json,
    setup_logger,
    sha256_file,
    utc_now,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/stage1.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    paths = configured_paths(config, root)
    logger = setup_logger(
        paths["log_dir"] / "06_package_outputs.log", "stage1.package"
    )
    validation_path = paths["output_dir"] / "stage1_validation.json"
    if not validation_path.exists():
        raise FileNotFoundError("Validation output is missing.")
    validation = read_json(validation_path)
    if not validation.get("overall_passed", False):
        raise RuntimeError("Stage 1 validation did not pass; output bundle was not created.")

    include: list[Path] = []
    include.extend(
        path
        for path in paths["output_dir"].rglob("*")
        if path.is_file()
    )
    include.extend(
        path
        for path in paths["log_dir"].glob("*.log")
        if path.is_file()
    )
    for relative in (
        "config/stage1.yml",
        "environment.yml",
        "PROTOCOL.md",
        "DATA_PROVENANCE.md",
        "README.md",
        "START_HERE_UZ.md",
        "HOTFIX_README_UZ.md",
        "HOTFIX_V0_1_2_README_UZ.md",
        "PILOT_README_UZ.md",
    ):
        include.append(root / relative)
    include.extend(sorted((root / "scripts").glob("*.py")))
    include.extend(sorted(root.glob("*.bat")))
    include = sorted({path.resolve() for path in include if path.exists()})

    query_version = str(config["gaia"]["query_protocol_version"])
    version_token = query_version.replace(".", "_")
    package_name = f"RGB_transportability_stage1_outputs_v{version_token}"
    manifest = {
        "package": package_name,
        "census_protocol_version": config["project"]["version"],
        "query_protocol_version": query_version,
        "created_utc": utc_now(),
        "files": [
            {
                "path": str(path.relative_to(root)).replace("\\", "/"),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
            for path in include
        ],
        "excluded": [
            "official raw FITS catalogues",
            "restartable Gaia chunk cache",
            "full survey-level interim tables",
        ],
    }
    manifest_path = paths["output_dir"] / "stage1_package_manifest.json"
    atomic_write_json(manifest, manifest_path)
    if manifest_path.resolve() not in include:
        include.append(manifest_path.resolve())

    output_zip = root / f"{package_name}.zip"
    temporary = output_zip.with_suffix(".zip.tmp")
    with zipfile.ZipFile(
        temporary, mode="w", compression=zipfile.ZIP_DEFLATED, compresslevel=6
    ) as archive:
        for path in sorted(include):
            archive.write(path, arcname=str(path.relative_to(root)).replace("\\", "/"))
    os.replace(temporary, output_zip)
    logger.info(
        "Output bundle created: %s (%.2f MiB)",
        output_zip,
        output_zip.stat().st_size / 2**20,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
