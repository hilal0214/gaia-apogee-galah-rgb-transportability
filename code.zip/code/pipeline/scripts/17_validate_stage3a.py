from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from stage3a_common import (
    CANDIDATE_COLUMNS,
    LABELS,
    atomic_write_json,
    canonical_json_sha256,
    close_logger,
    compute_quality_layer,
    frame_equal,
    gate_flow_table,
    ids_sha256,
    label_flow_table,
    load_config,
    load_verified_gaia_candidates,
    origin_flow_table,
    project_path,
    read_json,
    setup_logger,
    sha256_file,
    utc_now,
)


def add_gate(
    gates: list[dict[str, Any]],
    name: str,
    passed: bool,
    observed: Any,
    expected: Any,
    detail: str,
) -> None:
    gates.append(
        {
            "name": name,
            "passed": bool(passed),
            "observed": observed,
            "expected": expected,
            "detail": detail,
        }
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Stage 3A Gaia quality layer")
    parser.add_argument("--config", default="config/stage3a.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    stage1_dir = project_path(root, config["paths"]["stage1_output_dir"])
    stage2c_dir = project_path(root, config["paths"]["stage2c_output_dir"])
    output_dir = project_path(root, config["paths"]["output_dir"])
    cache_namespace = (
        project_path(root, config["paths"]["gaia_cache_root"])
        / config["stage1_frozen"]["expected_cache_namespace"]
    )
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "17_validate_stage3a.log", "stage3a.validate")
    stage1 = config["stage1_frozen"]
    stage2c = config["stage2c_frozen"]
    outputs = config["outputs"]
    paths = {
        "stage1_validation": stage1_dir / stage1["validation_file"],
        "query_summary": stage1_dir / stage1["query_summary_file"],
        "atlas": stage2c_dir / stage2c["atlas_file"],
        "stage2c_summary": stage2c_dir / stage2c["build_summary_file"],
        "stage2c_freeze": stage2c_dir / stage2c["freeze_manifest_file"],
        "stage2c_validation": stage2c_dir / stage2c["validation_file"],
        "quality_layer": output_dir / outputs["quality_layer_file"],
        "cache_audit": output_dir / outputs["cache_audit_file"],
        "gate_flow": output_dir / outputs["gate_flow_file"],
        "origin_flow": output_dir / outputs["origin_flow_file"],
        "label_flow": output_dir / outputs["label_flow_file"],
        "summary": output_dir / outputs["build_summary_file"],
        "freeze": output_dir / outputs["freeze_manifest_file"],
    }
    missing = [str(path) for path in paths.values() if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing Stage 3A validation inputs: " + "; ".join(missing))

    gates: list[dict[str, Any]] = []
    upstream_observed = {
        "stage1_validation": sha256_file(paths["stage1_validation"]),
        "gaia_query_summary": sha256_file(paths["query_summary"]),
        "stage2c_atlas": sha256_file(paths["atlas"]),
        "stage2c_build_summary": sha256_file(paths["stage2c_summary"]),
        "stage2c_freeze_manifest": sha256_file(paths["stage2c_freeze"]),
        "stage2c_validation": sha256_file(paths["stage2c_validation"]),
    }
    upstream_expected = {
        "stage1_validation": stage1["validation_sha256"],
        "gaia_query_summary": stage1["query_summary_sha256"],
        "stage2c_atlas": stage2c["atlas_sha256"],
        "stage2c_build_summary": stage2c["build_summary_sha256"],
        "stage2c_freeze_manifest": stage2c["freeze_manifest_sha256"],
        "stage2c_validation": stage2c["validation_sha256"],
    }
    add_gate(
        gates,
        "upstream_byte_identity",
        upstream_observed == upstream_expected,
        upstream_observed,
        upstream_expected,
        "Stage 1 and Stage 2C frozen files are byte-identical",
    )
    stage1_validation = read_json(paths["stage1_validation"])
    stage2c_validation = read_json(paths["stage2c_validation"])
    validation_observed = {
        "stage1": bool(stage1_validation.get("overall_passed", False)),
        "stage2c": bool(stage2c_validation.get("overall_passed", False)),
        "stage2c_gates": [
            int(stage2c_validation.get("n_passed", 0)),
            int(stage2c_validation.get("n_gates", 0)),
        ],
    }
    add_gate(
        gates,
        "upstream_validation",
        validation_observed
        == {"stage1": True, "stage2c": True, "stage2c_gates": [18, 18]},
        validation_observed,
        {"stage1": True, "stage2c": True, "stage2c_gates": [18, 18]},
        "accepted upstream validation state is preserved",
    )

    query_summary = read_json(paths["query_summary"])
    query_observed = {
        "complete": bool(query_summary.get("complete", False)),
        "rows": int(query_summary.get("unique_requested_ids", -1)),
        "chunks": int(query_summary.get("completed_chunks", -1)),
        "selection_sha256": query_summary.get("selection_sha256"),
        "query_signature_sha256": query_summary.get("query_signature_sha256"),
        "geometric": int(
            query_summary["totals_for_completed_chunks"][
                "geometric_distance_available"
            ]
        ),
        "photogeometric": int(
            query_summary["totals_for_completed_chunks"][
                "photogeometric_distance_available"
            ]
        ),
    }
    query_expected = {
        "complete": True,
        "rows": int(stage1["expected_rows"]),
        "chunks": int(stage1["expected_chunks"]),
        "selection_sha256": stage1["expected_selection_sha256"],
        "query_signature_sha256": stage1["expected_query_signature_sha256"],
        "geometric": int(stage1["expected_geometric_distances"]),
        "photogeometric": int(stage1["expected_photogeometric_distances"]),
    }
    add_gate(
        gates,
        "gaia_query_freeze",
        query_observed == query_expected,
        query_observed,
        query_expected,
        "full Gaia query namespace, signature, and distance accounting are frozen",
    )

    atlas = pd.read_parquet(paths["atlas"], columns=list(CANDIDATE_COLUMNS))
    all_ids = atlas["gaia_dr3_source_id"].to_numpy(np.int64)
    candidates = atlas.loc[atlas[config["quality_policy"]["candidate_rule"]].astype(bool)].copy()
    candidates = candidates.reset_index(drop=True)
    candidate_ids = candidates["gaia_dr3_source_id"].to_numpy(np.int64)
    identity_observed = {
        "atlas_rows": int(len(atlas)),
        "candidate_rows": int(len(candidates)),
        "atlas_id_sha256": ids_sha256(all_ids),
        "candidate_id_sha256": ids_sha256(candidate_ids),
        "atlas_strictly_increasing": bool(np.all(np.diff(all_ids) > 0)),
        "candidate_strictly_increasing": bool(np.all(np.diff(candidate_ids) > 0)),
    }
    summary = read_json(paths["summary"])
    identity_expected = {
        "atlas_rows": int(stage2c["expected_atlas_rows"]),
        "candidate_rows": int(stage2c["expected_candidate_rows"]),
        "atlas_id_sha256": stage1["expected_selection_sha256"],
        "candidate_id_sha256": summary["candidate_id_sha256"],
        "atlas_strictly_increasing": True,
        "candidate_strictly_increasing": True,
    }
    add_gate(
        gates,
        "candidate_identity",
        identity_observed == identity_expected,
        identity_observed,
        identity_expected,
        "candidate restriction is exact and independent of Gaia quality outcome",
    )

    logger.info("Independently re-reading and verifying all Gaia cache chunks")
    gaia_candidates, expected_cache_audit, cache_summary = load_verified_gaia_candidates(
        cache_namespace,
        all_ids,
        candidate_ids,
        stage1,
        query_summary,
    )
    cache_observed = {
        "chunks": cache_summary["chunks"],
        "full_rows": cache_summary["full_rows"],
        "candidate_rows": cache_summary["candidate_rows"],
        "source_id_sha256": cache_summary["source_id_sha256"],
    }
    cache_expected = {
        "chunks": int(stage1["expected_chunks"]),
        "full_rows": int(stage1["expected_rows"]),
        "candidate_rows": int(stage2c["expected_candidate_rows"]),
        "source_id_sha256": stage1["expected_selection_sha256"],
    }
    add_gate(
        gates,
        "full_cache_identity",
        cache_observed == cache_expected,
        cache_observed,
        cache_expected,
        "all 76 joined chunks reconstruct the exact 1,509,277-source vector",
    )
    observed_cache_audit = pd.read_csv(paths["cache_audit"])
    cache_audit_exact = frame_equal(
        observed_cache_audit, expected_cache_audit, ["chunk_index"]
    )
    cache_set_hashes_exact = bool(
        cache_summary["joined_chunk_set_sha256"]
        == summary["cache"]["joined_chunk_set_sha256"]
        and cache_summary["metadata_chunk_set_sha256"]
        == summary["cache"]["metadata_chunk_set_sha256"]
    )
    add_gate(
        gates,
        "cache_byte_freeze",
        cache_audit_exact and cache_set_hashes_exact,
        {
            "rows": int(len(observed_cache_audit)),
            "audit_exact": cache_audit_exact,
            "joined_set_sha256": cache_summary["joined_chunk_set_sha256"],
            "metadata_set_sha256": cache_summary["metadata_chunk_set_sha256"],
        },
        {
            "rows": int(stage1["expected_chunks"]),
            "audit_exact": True,
            "joined_set_sha256": summary["cache"]["joined_chunk_set_sha256"],
            "metadata_set_sha256": summary["cache"][
                "metadata_chunk_set_sha256"
            ],
        },
        "per-chunk rows, source hashes, and file hashes independently reproduce",
    )

    logger.info("Recomputing the complete Stage 3A quality layer")
    expected_layer = compute_quality_layer(
        candidates, gaia_candidates, config["quality_policy"]
    )
    observed_layer = pd.read_parquet(paths["quality_layer"])
    raw_columns = ["gaia_dr3_source_id", *[column for column in gaia_candidates.columns if column != "gaia_dr3_source_id"]]
    raw_exact = frame_equal(
        observed_layer.loc[:, raw_columns],
        expected_layer.loc[:, raw_columns],
        ["gaia_dr3_source_id"],
    )
    add_gate(
        gates,
        "gaia_column_transport",
        raw_exact,
        {"rows": int(len(observed_layer)), "raw_columns_exact": raw_exact},
        {"rows": int(len(expected_layer)), "raw_columns_exact": True},
        "candidate Gaia and distance columns are copied without alteration",
    )
    tolerance = float(config["validation"]["numeric_absolute_tolerance"])
    complete_layer_exact = frame_equal(
        observed_layer,
        expected_layer,
        ["gaia_dr3_source_id"],
        atol=tolerance,
    )
    add_gate(
        gates,
        "quality_equation_recomputation",
        complete_layer_exact,
        {
            "columns": int(len(observed_layer.columns)),
            "complete_layer_exact": complete_layer_exact,
        },
        {
            "columns": int(len(expected_layer.columns)),
            "complete_layer_exact": True,
        },
        "astrometric, distance, RV, clean-set, and label flags all recompute",
    )

    primary_ast = observed_layer["gaia_astrometry_primary_ok"].to_numpy(bool)
    sensitivity_ast = observed_layer["gaia_astrometry_sensitivity_ok"].to_numpy(bool)
    primary_distance = observed_layer["distance_photogeo_primary_ok"].to_numpy(bool)
    sensitivity_distance = observed_layer[
        "distance_photogeo_sensitivity_ok"
    ].to_numpy(bool)
    primary_rv = observed_layer["rv_primary_ok"].to_numpy(bool)
    sensitivity_rv = observed_layer["rv_sensitivity_ok"].to_numpy(bool)
    primary_5d = observed_layer["clean_5d_primary_ok"].to_numpy(bool)
    sensitivity_5d = observed_layer["clean_5d_sensitivity_ok"].to_numpy(bool)
    primary_6d = observed_layer["clean_6d_primary_ok"].to_numpy(bool)
    sensitivity_6d = observed_layer["clean_6d_sensitivity_ok"].to_numpy(bool)
    nested = bool(
        np.all(~primary_ast | sensitivity_ast)
        and np.all(~primary_distance | sensitivity_distance)
        and np.all(~primary_rv | sensitivity_rv)
        and np.all(~primary_5d | sensitivity_5d)
        and np.all(~primary_6d | sensitivity_6d)
    )
    add_gate(
        gates,
        "nested_primary_and_sensitivity_sets",
        nested,
        {"nested": nested},
        {"nested": True},
        "every primary astrometric, distance, RV, 5D, and 6D set is nested",
    )

    rv_disagreement = observed_layer["rv_cross_source_disagreement"].to_numpy(bool)
    rv_policy_exact = bool(
        not np.any(rv_disagreement & primary_rv)
        and np.all(~rv_disagreement | sensitivity_rv)
    )
    source_counts = {
        str(key): int(value)
        for key, value in observed_layer["analysis_rv_source"].astype(str).value_counts().sort_index().items()
    }
    add_gate(
        gates,
        "radial_velocity_hierarchy_and_disagreement",
        rv_policy_exact,
        {
            "source_counts": source_counts,
            "disagreements": int(rv_disagreement.sum()),
            "disagreement_primary": int((rv_disagreement & primary_rv).sum()),
        },
        {"disagreement_primary": 0, "disagreement_retained_in_sensitivity": True},
        "spectroscopic-first hierarchy and binary/catalogue disagreement policy hold",
    )

    policy = config["quality_policy"]
    distance_policy = {
        "primary_estimator": policy["distance"]["primary_estimator"],
        "direct_inverse_parallax_used": policy["distance"][
            "direct_inverse_parallax_used"
        ],
        "parallax_signal_to_noise_cut_used": policy["distance"][
            "parallax_signal_to_noise_cut_used"
        ],
        "policy_sha256": canonical_json_sha256(policy),
    }
    distance_expected = {
        "primary_estimator": "photogeometric",
        "direct_inverse_parallax_used": False,
        "parallax_signal_to_noise_cut_used": False,
        "policy_sha256": summary["quality_policy_sha256"],
    }
    add_gate(
        gates,
        "distance_estimator_policy",
        distance_policy == distance_expected,
        distance_policy,
        distance_expected,
        "Bayesian photogeometric primary and geometric sensitivity are frozen without 1/parallax",
    )

    label_nested = True
    label_counts: dict[str, Any] = {}
    for label in LABELS:
        primary = observed_layer[f"{label}_clean6d_primary_ok"].to_numpy(bool)
        core = observed_layer[f"{label}_clean6d_core_ok"].to_numpy(bool)
        sensitivity = observed_layer[f"{label}_clean6d_sensitivity_ok"].to_numpy(bool)
        label_nested &= bool(np.all(~core | primary) and np.all(~primary | sensitivity))
        label_counts[label] = {
            "core": int(core.sum()),
            "primary": int(primary.sum()),
            "sensitivity": int(sensitivity.sum()),
        }
    add_gate(
        gates,
        "label_specific_eligibility",
        label_nested,
        {"nested": label_nested, "counts": label_counts},
        {"nested": True},
        "all six label-specific 6D gates preserve core-primary-sensitivity nesting",
    )

    expected_gate_flow = gate_flow_table(expected_layer, len(atlas))
    expected_origin_flow = origin_flow_table(expected_layer)
    expected_label_flow = label_flow_table(expected_layer)
    flow_exact = frame_equal(
        pd.read_csv(paths["gate_flow"]), expected_gate_flow, ["gate"]
    )
    flow_exact &= frame_equal(
        pd.read_csv(paths["origin_flow"]), expected_origin_flow, ["survey_origin"]
    )
    flow_exact &= frame_equal(
        pd.read_csv(paths["label_flow"]), expected_label_flow, ["label"]
    )
    add_gate(
        gates,
        "flow_table_recomputation",
        flow_exact,
        {"exact": flow_exact, "tables": 3},
        {"exact": True, "tables": 3},
        "gate, survey-origin, and label flow tables recompute from the quality layer",
    )

    freeze = read_json(paths["freeze"])
    current_outputs = {
        paths["quality_layer"].name: sha256_file(paths["quality_layer"]),
        paths["cache_audit"].name: sha256_file(paths["cache_audit"]),
        paths["gate_flow"].name: sha256_file(paths["gate_flow"]),
        paths["origin_flow"].name: sha256_file(paths["origin_flow"]),
        paths["label_flow"].name: sha256_file(paths["label_flow"]),
        paths["summary"].name: sha256_file(paths["summary"]),
    }
    output_hash_exact = current_outputs == freeze["output_sha256"]
    output_hash_exact &= all(
        current_outputs[name] == digest
        for name, digest in summary["output_sha256"].items()
    )
    add_gate(
        gates,
        "output_hash_freeze",
        output_hash_exact,
        current_outputs,
        freeze["output_sha256"],
        "all Stage 3A science products retain frozen byte identities",
    )

    forbidden = {
        "galactocentric_x_kpc",
        "galactocentric_y_kpc",
        "galactocentric_z_kpc",
        "galactocentric_r_kpc",
        "v_r_kms",
        "v_phi_kms",
        "v_z_kms",
        "total_velocity_kms",
        "population_class",
        "gradient_beta_r",
        "gradient_beta_z",
    }
    boundary_observed = {
        "summary": summary["science_boundary"],
        "freeze": freeze["science_boundary"],
        "forbidden_columns_present": sorted(forbidden.intersection(observed_layer.columns)),
    }
    boundary_expected = {
        "summary": config["science_boundary"],
        "freeze": config["science_boundary"],
        "forbidden_columns_present": [],
    }
    add_gate(
        gates,
        "stage3a_science_boundary",
        boundary_observed == boundary_expected,
        boundary_observed,
        boundary_expected,
        "quality eligibility only; no phase-space, speed cut, gradients, or populations",
    )

    n_passed = sum(bool(item["passed"]) for item in gates)
    result = {
        "stage": "3A validation",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "overall_passed": n_passed == len(gates),
        "n_gates": len(gates),
        "n_passed": n_passed,
        "gates": gates,
    }
    validation_path = output_dir / outputs["validation_file"]
    atomic_write_json(result, validation_path)
    report_lines = [
        "# Stage 3A validation report",
        "",
        f"Overall: **{'PASS' if result['overall_passed'] else 'FAIL'}**",
        "",
        f"Protocol: `{config['project']['version']}`",
        "",
        "| Gate | Result | Detail |",
        "|---|---:|---|",
    ]
    for item in gates:
        report_lines.append(
            f"| `{item['name']}` | {'PASS' if item['passed'] else 'FAIL'} | {item['detail']} |"
        )
    report_lines.extend(
        [
            "",
            "Stage 3A freezes Gaia astrometric, Bailer-Jones distance, and radial-velocity eligibility. Galactocentric phase space and scientific inference remain outside this stage.",
            "",
        ]
    )
    (output_dir / outputs["validation_report_file"]).write_text(
        "\n".join(report_lines), encoding="utf-8"
    )
    logger.info(
        "Stage 3A validation passed=%s; gates=%d/%d",
        result["overall_passed"],
        n_passed,
        len(gates),
    )
    close_logger(logger)
    return 0 if result["overall_passed"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
