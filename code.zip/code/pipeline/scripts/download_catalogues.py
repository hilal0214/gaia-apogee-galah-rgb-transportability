from __future__ import annotations

import argparse
import os
import shutil
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from stage1_common import (
    atomic_write_json,
    configured_paths,
    load_config,
    setup_logger,
    sha256_file,
    utc_now,
)


def download_with_resume(url: str, destination: Path, logger) -> None:
    partial = destination.with_suffix(destination.suffix + ".part")
    destination.parent.mkdir(parents=True, exist_ok=True)
    existing = partial.stat().st_size if partial.exists() else 0
    headers = {
        "User-Agent": "Gaia-APOGEE-GALAH-transportability-stage1/0.1.1",
        "Accept-Encoding": "identity",
    }
    if existing:
        headers["Range"] = f"bytes={existing}-"
        logger.info("Resuming %s at %s bytes", destination.name, f"{existing:,}")
    request = urllib.request.Request(url, headers=headers)
    try:
        response = urllib.request.urlopen(request, timeout=300)
    except urllib.error.HTTPError as exc:
        if exc.code == 416 and partial.exists():
            os.replace(partial, destination)
            return
        raise
    status = getattr(response, "status", response.getcode())
    append = bool(existing and status == 206)
    if existing and not append:
        logger.info("Server ignored Range; restarting %s", destination.name)
        existing = 0
    total_header = response.headers.get("Content-Length")
    remaining = int(total_header) if total_header and total_header.isdigit() else None
    total = existing + remaining if remaining is not None else None
    mode = "ab" if append else "wb"
    downloaded = existing
    next_report = time.monotonic() + 10
    with partial.open(mode) as handle:
        while True:
            block = response.read(8 * 1024 * 1024)
            if not block:
                break
            handle.write(block)
            downloaded += len(block)
            if time.monotonic() >= next_report:
                if total:
                    logger.info(
                        "%s: %.1f%% (%.2f / %.2f GiB)",
                        destination.name,
                        100.0 * downloaded / total,
                        downloaded / 2**30,
                        total / 2**30,
                    )
                else:
                    logger.info("%s: %.2f GiB", destination.name, downloaded / 2**30)
                next_report = time.monotonic() + 10
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(partial, destination)


def fits_row_count(path: Path, hdu: int) -> int:
    from astropy.io import fits

    with fits.open(path, memmap=True, lazy_load_hdus=True) as hdul:
        return int(len(hdul[hdu].data))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/stage1.yml")
    parser.add_argument("--only", choices=("apogee", "galah"))
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    config, root = load_config(args.config)
    paths = configured_paths(config, root)
    logger = setup_logger(paths["log_dir"] / "download_catalogues.log", "stage1.download")

    free_bytes = shutil.disk_usage(paths["raw_dir"]).free
    if free_bytes < 10 * 2**30:
        logger.warning(
            "Only %.2f GiB free; at least 10 GiB is recommended.", free_bytes / 2**30
        )

    selected = [args.only] if args.only else ["apogee", "galah"]
    manifest = {
        "project_version": config["project"]["version"],
        "created_utc": utc_now(),
        "files": {},
    }
    for name in selected:
        spec = config["catalogues"][name]
        destination = paths["raw_dir"] / spec["filename"]
        if args.force and destination.exists():
            destination.unlink()
        if not destination.exists():
            logger.info("Downloading %s from official release", name.upper())
            download_with_resume(spec["url"], destination, logger)
        size = destination.stat().st_size
        if size < int(spec["minimum_bytes"]):
            raise RuntimeError(
                f"{destination.name} is too small: {size:,} bytes; "
                f"minimum={int(spec['minimum_bytes']):,}"
            )
        rows = fits_row_count(destination, int(spec["hdu"]))
        if rows != int(spec["expected_rows"]):
            raise RuntimeError(
                f"{destination.name} row count changed: {rows:,} != "
                f"{int(spec['expected_rows']):,}"
            )
        logger.info("Hashing %s", destination.name)
        manifest["files"][name] = {
            "release": spec["release"],
            "filename": spec["filename"],
            "url": spec["url"],
            "bytes": size,
            "rows": rows,
            "sha256": sha256_file(destination),
            "verified_utc": utc_now(),
        }
        logger.info(
            "Verified %s: %s rows, %.2f GiB",
            name,
            f"{rows:,}",
            size / 2**30,
        )

    manifest_path = paths["raw_dir"] / "raw_manifest.json"
    if manifest_path.exists() and len(selected) == 1:
        from stage1_common import read_json

        existing_manifest = read_json(manifest_path)
        existing_manifest.setdefault("files", {}).update(manifest["files"])
        existing_manifest["updated_utc"] = utc_now()
        manifest = existing_manifest
    atomic_write_json(manifest, manifest_path)
    logger.info("Raw manifest written: %s", manifest_path)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted; partial download was retained for resume.", file=sys.stderr)
        raise SystemExit(130)
