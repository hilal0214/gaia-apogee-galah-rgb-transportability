from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import yaml


LABELS = ("fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe", "alpha3")
COHORTS = (
    "PRIMARY",
    "CORE",
    "COMMON_SUPPORT",
    "DISC5",
    "GEO_PAIRED",
    "SENSITIVITY",
)
GLOBAL_PARAMETERS = ("INTERCEPT", "BETA_R", "BETA_Z")
INTERACTION_RAW_PARAMETERS = (
    "INTERCEPT",
    "BETA_R",
    "BETA_Z",
    "DELTA_INTERCEPT",
    "DELTA_BETA_R",
    "DELTA_BETA_Z",
)
INTERACTION_DERIVED_PARAMETERS = (
    "APOGEE_INTERCEPT",
    "APOGEE_BETA_R",
    "APOGEE_BETA_Z",
    "GALAH_INTERCEPT",
    "GALAH_BETA_R",
    "GALAH_BETA_Z",
    "DELTA_INTERCEPT",
    "DELTA_BETA_R",
    "DELTA_BETA_Z",
)
MAD_TO_SIGMA = 1.482602218505602


@dataclass
class HuberFit:
    beta: np.ndarray
    scale: float
    residual_mad: float
    iterations: int
    converged: bool
    downweight_fraction: float
    rank: int
    condition_number: float
    score_max_abs_per_row: float
    residuals: np.ndarray
    psi: np.ndarray
    active: np.ndarray


@dataclass
class ClusterInference:
    block_ids: np.ndarray
    block_counts: np.ndarray
    cluster_scores: np.ndarray
    bread_inverse: np.ndarray
    covariance: np.ndarray
    standard_errors: np.ndarray
    draws: np.ndarray | None
    delete_one_delta: np.ndarray
    finite_cluster_correction: float


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_config(path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {config_path}")
    return config, config_path.parent.parent


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def setup_logger(path: Path, name: str) -> logging.Logger:
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def close_logger(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        handler.flush()
        handler.close()
        logger.removeHandler(handler)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def ids_sha256(values: Sequence[int] | np.ndarray | pd.Series) -> str:
    digest = hashlib.sha256()
    for value in np.asarray(values, dtype=np.int64):
        digest.update(f"{int(value)}\n".encode("ascii"))
    return digest.hexdigest()


def stable_seed(namespace: str, model_id: str) -> int:
    payload = f"{namespace}|{model_id}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "little")


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="\n",
        dir=path.parent,
        prefix=f".{path.name}.",
        delete=False,
    ) as handle:
        temporary = Path(handle.name)
        json.dump(payload, handle, indent=2, sort_keys=True, ensure_ascii=True, allow_nan=False)
        handle.write("\n")
    temporary.replace(path)


def atomic_write_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="",
        dir=path.parent,
        prefix=f".{path.name}.",
        delete=False,
    ) as handle:
        temporary = Path(handle.name)
        frame.to_csv(
            handle,
            index=False,
            lineterminator="\n",
            float_format="%.17g",
        )
    temporary.replace(path)


def atomic_write_parquet(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="wb",
        dir=path.parent,
        prefix=f".{path.name}.",
        delete=False,
    ) as handle:
        temporary = Path(handle.name)
    table = pa.Table.from_pandas(frame, preserve_index=False)
    pq.write_table(
        table,
        temporary,
        compression="zstd",
        compression_level=9,
        use_dictionary=True,
        write_statistics=True,
        version="2.6",
    )
    temporary.replace(path)


def flag(frame: pd.DataFrame, column: str) -> np.ndarray:
    return frame[column].fillna(False).astype(bool).to_numpy()


def number(frame: pd.DataFrame, column: str) -> np.ndarray:
    return pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=float)


def label_value_column(label: str) -> str:
    return "alpha3_hom" if label == "alpha3" else f"{label}_hom"


def label_error_column(label: str) -> str:
    return "alpha3_hom_error_proxy" if label == "alpha3" else f"{label}_hom_error_proxy"


def label_source_column(label: str) -> str:
    return "alpha3_source" if label == "alpha3" else f"{label}_hom_source"


def selected_input_columns(config: Mapping[str, Any]) -> list[str]:
    columns = [
        "gaia_dr3_source_id",
        "gaia_healpix5",
        "r_cyl_gc_kpc",
        "abs_z_gc_kpc",
        "r_cyl_gc_kpc_geo_alt",
        "z_gc_kpc_geo_alt",
    ]
    for label in LABELS:
        columns.extend(
            [
                label_value_column(label),
                label_error_column(label),
                label_source_column(label),
            ]
        )
        for row in config["analysis_contract"]["sensitivity_ladder"]:
            columns.append(f"{label}_gradient_{row['flag_suffix']}_ok")
    return list(dict.fromkeys(columns))


def cohort_mask(frame: pd.DataFrame, label: str, cohort: str, config: Mapping[str, Any]) -> np.ndarray:
    entries = {
        str(row["name"]): str(row["flag_suffix"])
        for row in config["analysis_contract"]["sensitivity_ladder"]
    }
    if cohort not in entries:
        raise KeyError(f"Unknown Stage 4B cohort: {cohort}")
    return flag(frame, f"{label}_gradient_{entries[cohort]}_ok")


def coordinate_features(
    frame: pd.DataFrame,
    mask: np.ndarray,
    cohort: str,
    radial_pivot: float,
) -> np.ndarray:
    if cohort == "GEO_PAIRED":
        radius = number(frame, "r_cyl_gc_kpc_geo_alt")
        height = np.abs(number(frame, "z_gc_kpc_geo_alt"))
    else:
        radius = number(frame, "r_cyl_gc_kpc")
        height = number(frame, "abs_z_gc_kpc")
    output = np.column_stack([radius[mask] - radial_pivot, height[mask]])
    if not np.isfinite(output).all():
        raise ValueError(f"Non-finite coordinate in {cohort} model")
    return output


def interaction_features(
    frame: pd.DataFrame,
    mask: np.ndarray,
    label: str,
    radial_pivot: float,
    comparison_group: str,
) -> tuple[np.ndarray, np.ndarray]:
    radius = number(frame, "r_cyl_gc_kpc")[mask] - radial_pivot
    height = number(frame, "abs_z_gc_kpc")[mask]
    sources = (
        frame.loc[mask, label_source_column(label)]
        .astype("string")
        .fillna("NOT_AVAILABLE")
        .to_numpy(dtype=str)
    )
    comparison = (sources == comparison_group).astype(float)
    features = np.column_stack(
        [radius, height, comparison, comparison * radius, comparison * height]
    )
    if not np.isfinite(features).all():
        raise ValueError(f"Non-finite coordinate in {label} survey interaction")
    return features, sources


def robust_scale(residuals: np.ndarray, minimum_scale: float) -> tuple[float, float]:
    residuals = np.asarray(residuals, dtype=float)
    median = float(np.median(residuals))
    mad = float(np.median(np.abs(residuals - median)))
    scale = max(MAD_TO_SIGMA * mad, float(minimum_scale))
    return scale, mad


def fit_huber(
    features: np.ndarray,
    response: np.ndarray,
    *,
    tuning_constant: float,
    relative_tolerance: float,
    maximum_iterations: int,
    minimum_scale: float,
) -> HuberFit:
    features = np.asarray(features, dtype=float)
    response = np.asarray(response, dtype=float)
    if features.ndim != 2 or response.ndim != 1 or len(features) != len(response):
        raise ValueError("Huber inputs have incompatible shapes")
    if len(response) <= features.shape[1] + 1:
        raise ValueError("Huber model has too few rows")
    if not np.isfinite(features).all() or not np.isfinite(response).all():
        raise ValueError("Huber inputs must be finite")

    centers = features.mean(axis=0)
    scales = features.std(axis=0)
    scales = np.where(scales > 1.0e-12, scales, 1.0)
    standardized = (features - centers) / scales
    design_standardized = np.column_stack([np.ones(len(response)), standardized])
    beta_standardized = np.linalg.lstsq(design_standardized, response, rcond=None)[0]
    converged = False
    iterations = 0
    for iterations in range(1, int(maximum_iterations) + 1):
        residuals = response - design_standardized @ beta_standardized
        scale, _ = robust_scale(residuals, minimum_scale)
        standardized_residual = residuals / scale
        weights = np.minimum(
            1.0,
            float(tuning_constant) / np.maximum(np.abs(standardized_residual), 1.0e-300),
        )
        square_root = np.sqrt(weights)
        updated = np.linalg.lstsq(
            design_standardized * square_root[:, None],
            response * square_root,
            rcond=None,
        )[0]
        change = float(
            np.max(np.abs(updated - beta_standardized) / (1.0 + np.abs(beta_standardized)))
        )
        beta_standardized = updated
        if change < float(relative_tolerance):
            converged = True
            break

    slopes = beta_standardized[1:] / scales
    intercept = beta_standardized[0] - float(np.dot(slopes, centers))
    beta = np.concatenate([[intercept], slopes])
    design = np.column_stack([np.ones(len(response)), features])
    residuals = response - design @ beta
    scale, mad = robust_scale(residuals, minimum_scale)
    standardized_residual = residuals / scale
    psi = np.clip(standardized_residual, -float(tuning_constant), float(tuning_constant))
    active = np.abs(standardized_residual) < float(tuning_constant)
    score = design.T @ psi
    cross_product = design_standardized.T @ design_standardized / len(response)
    return HuberFit(
        beta=beta,
        scale=float(scale),
        residual_mad=float(mad),
        iterations=int(iterations),
        converged=bool(converged),
        downweight_fraction=float(np.mean(~active)),
        rank=int(np.linalg.matrix_rank(design_standardized)),
        condition_number=float(np.linalg.cond(cross_product)),
        score_max_abs_per_row=float(np.max(np.abs(score)) / len(response)),
        residuals=residuals,
        psi=psi,
        active=active,
    )


def cluster_inference(
    features: np.ndarray,
    response: np.ndarray,
    clusters: np.ndarray,
    fit: HuberFit,
    *,
    n_draws: int,
    seed: int,
    finite_cluster_correction: bool,
    draw_chunk_size: int = 256,
) -> ClusterInference:
    features = np.asarray(features, dtype=float)
    response = np.asarray(response, dtype=float)
    clusters = np.asarray(clusters, dtype=np.int64)
    design = np.column_stack([np.ones(len(response)), features])
    if len(clusters) != len(response):
        raise ValueError("Cluster vector has the wrong length")
    block_ids, inverse, block_counts = np.unique(
        clusters, return_inverse=True, return_counts=True
    )
    cluster_scores = np.zeros((len(block_ids), design.shape[1]), dtype=float)
    np.add.at(cluster_scores, inverse, design * fit.psi[:, None])
    bread = (design.T * fit.active.astype(float)) @ design / fit.scale
    if np.linalg.matrix_rank(bread) != design.shape[1]:
        raise ValueError("Huber bread matrix is rank deficient")
    bread_inverse = np.linalg.inv(bread)
    correction = 1.0
    if finite_cluster_correction:
        correction = (len(block_ids) / (len(block_ids) - 1.0)) * (
            (len(response) - 1.0) / (len(response) - design.shape[1])
        )
    corrected_scores = cluster_scores * np.sqrt(correction)
    covariance = bread_inverse @ (corrected_scores.T @ corrected_scores) @ bread_inverse.T
    covariance = (covariance + covariance.T) / 2.0
    standard_errors = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    delete_one_delta = -(cluster_scores @ bread_inverse.T)

    draws: np.ndarray | None = None
    if int(n_draws) > 0:
        if int(n_draws) % 2 != 0:
            raise ValueError("Antithetic draw count must be even")
        half = int(n_draws) // 2
        delta = np.empty((int(n_draws), design.shape[1]), dtype=float)
        generator = np.random.Generator(np.random.PCG64DXSM(int(seed)))
        for start in range(0, half, int(draw_chunk_size)):
            stop = min(start + int(draw_chunk_size), half)
            multipliers = generator.integers(
                0,
                2,
                size=(stop - start, len(block_ids)),
                dtype=np.int8,
            )
            multipliers = multipliers.astype(float) * 2.0 - 1.0
            perturbation = (multipliers @ corrected_scores) @ bread_inverse.T
            delta[start:stop] = perturbation
            delta[half + start : half + stop] = -perturbation
        draws = fit.beta[None, :] + delta

    return ClusterInference(
        block_ids=block_ids,
        block_counts=block_counts.astype(np.int64),
        cluster_scores=cluster_scores,
        bread_inverse=bread_inverse,
        covariance=covariance,
        standard_errors=standard_errors,
        draws=draws,
        delete_one_delta=delete_one_delta,
        finite_cluster_correction=float(correction),
    )


def interaction_transform() -> np.ndarray:
    return np.asarray(
        [
            [1, 0, 0, 0, 0, 0],
            [0, 1, 0, 0, 0, 0],
            [0, 0, 1, 0, 0, 0],
            [1, 0, 0, 1, 0, 0],
            [0, 1, 0, 0, 1, 0],
            [0, 0, 1, 0, 0, 1],
            [0, 0, 0, 1, 0, 0],
            [0, 0, 0, 0, 1, 0],
            [0, 0, 0, 0, 0, 1],
        ],
        dtype=float,
    )


def summarize_draws(
    point: float,
    standard_error: float,
    draws: np.ndarray,
    quantiles: Sequence[float],
) -> dict[str, Any]:
    draws = np.asarray(draws, dtype=float)
    values = np.quantile(draws, np.asarray(quantiles, dtype=float))
    if len(values) != 5:
        raise ValueError("Stage 4B requires five frozen confidence quantiles")
    draw_sd = float(np.std(draws, ddof=1))
    denominator = max(abs(float(standard_error)), abs(draw_sd), 1.0e-15)
    return {
        "point": float(point),
        "cluster_standard_error": float(standard_error),
        "draw_standard_deviation": draw_sd,
        "standard_error_draw_sd_relative_difference": float(
            abs(draw_sd - float(standard_error)) / denominator
        ),
        "q025": float(values[0]),
        "q16": float(values[1]),
        "q50": float(values[2]),
        "q84": float(values[3]),
        "q975": float(values[4]),
        "sign_stability": float(max(np.mean(draws > 0.0), np.mean(draws < 0.0))),
        "interval95_excludes_zero": bool(values[0] > 0.0 or values[4] < 0.0),
    }


def summary_fields(prefix: str, summary: Mapping[str, Any]) -> dict[str, Any]:
    return {
        prefix: summary["point"],
        f"{prefix}_cluster_se": summary["cluster_standard_error"],
        f"{prefix}_draw_sd": summary["draw_standard_deviation"],
        f"{prefix}_se_draw_relative_difference": summary[
            "standard_error_draw_sd_relative_difference"
        ],
        f"{prefix}_q025": summary["q025"],
        f"{prefix}_q16": summary["q16"],
        f"{prefix}_q50": summary["q50"],
        f"{prefix}_q84": summary["q84"],
        f"{prefix}_q975": summary["q975"],
        f"{prefix}_sign_stability": summary["sign_stability"],
        f"{prefix}_interval95_excludes_zero": summary["interval95_excludes_zero"],
    }


def ordered_frame(
    frame: pd.DataFrame,
    order_columns: list[tuple[str, tuple[str, ...]]],
) -> pd.DataFrame:
    output = frame.copy()
    temporary: list[str] = []
    for column, values in order_columns:
        helper = f"__order_{column}"
        mapping = {value: index for index, value in enumerate(values)}
        mapped = output[column].map(mapping)
        if mapped.isna().any():
            missing = sorted(set(output.loc[mapped.isna(), column].astype(str)))
            raise ValueError(f"Unknown ordering values in {column}: {missing}")
        output[helper] = mapped.astype(int)
        temporary.append(helper)
    output = output.sort_values(temporary, kind="mergesort").drop(columns=temporary)
    return output.reset_index(drop=True)


def paired_convergence_subset(draws: np.ndarray, convergence_draws: int) -> np.ndarray:
    draws = np.asarray(draws, dtype=float)
    if len(draws) % 2 != 0 or int(convergence_draws) % 2 != 0:
        raise ValueError("Antithetic convergence counts must be even")
    if int(convergence_draws) > len(draws):
        raise ValueError("Convergence draw count exceeds the full draw count")
    full_half = len(draws) // 2
    short_half = int(convergence_draws) // 2
    return np.concatenate([draws[:short_half], draws[full_half : full_half + short_half]])


def convergence_record(
    *,
    label: str,
    model_id: str,
    parameter: str,
    draws: np.ndarray,
    convergence_draws: int,
) -> dict[str, Any]:
    full = np.asarray(draws, dtype=float)
    short = paired_convergence_subset(full, convergence_draws)
    q_full = np.quantile(full, [0.16, 0.50, 0.84])
    q_short = np.quantile(short, [0.16, 0.50, 0.84])
    full_halfwidth = float((q_full[2] - q_full[0]) / 2.0)
    short_halfwidth = float((q_short[2] - q_short[0]) / 2.0)
    denominator = max(abs(full_halfwidth), 1.0e-15)
    return {
        "label": label,
        "model_id": model_id,
        "parameter": parameter,
        "convergence_draws": int(convergence_draws),
        "full_draws": int(len(full)),
        "convergence_q16": float(q_short[0]),
        "convergence_q50": float(q_short[1]),
        "convergence_q84": float(q_short[2]),
        "full_q16": float(q_full[0]),
        "full_q50": float(q_full[1]),
        "full_q84": float(q_full[2]),
        "convergence_halfwidth": short_halfwidth,
        "full_halfwidth": full_halfwidth,
        "relative_halfwidth_difference": float(
            abs(short_halfwidth - full_halfwidth) / denominator
        ),
        "median_absolute_difference": float(abs(q_short[1] - q_full[1])),
    }


def diagnostic_record(
    *,
    label: str,
    model_id: str,
    cohort: str,
    coordinate_estimator: str,
    rows: int,
    blocks: int,
    parameters: int,
    fit: HuberFit,
    inference: ClusterInference,
) -> dict[str, Any]:
    return {
        "label": label,
        "model_id": model_id,
        "cohort": cohort,
        "coordinate_estimator": coordinate_estimator,
        "rows": int(rows),
        "spatial_blocks": int(blocks),
        "parameters": int(parameters),
        "rank": int(fit.rank),
        "iterations": int(fit.iterations),
        "converged": bool(fit.converged),
        "condition_number_standardized": float(fit.condition_number),
        "residual_mad": float(fit.residual_mad),
        "huber_scale": float(fit.scale),
        "downweight_fraction": float(fit.downweight_fraction),
        "score_max_abs_per_row": float(fit.score_max_abs_per_row),
        "finite_cluster_correction": float(inference.finite_cluster_correction),
    }


def influence_records(
    *,
    label: str,
    model_id: str,
    parameter_names: Sequence[str],
    transform: np.ndarray,
    inference: ClusterInference,
    standard_errors: np.ndarray,
    top_blocks: int,
) -> list[dict[str, Any]]:
    transformed = inference.delete_one_delta @ np.asarray(transform, dtype=float).T
    records: list[dict[str, Any]] = []
    for column, parameter in enumerate(parameter_names):
        standard_error = float(standard_errors[column])
        ratio = np.abs(transformed[:, column]) / max(standard_error, 1.0e-15)
        ordering = np.lexsort((inference.block_ids, -ratio))[: int(top_blocks)]
        for rank, index in enumerate(ordering, start=1):
            records.append(
                {
                    "label": label,
                    "model_id": model_id,
                    "parameter": str(parameter),
                    "influence_rank": int(rank),
                    "gaia_healpix5": int(inference.block_ids[index]),
                    "stars_in_model_block": int(inference.block_counts[index]),
                    "approximate_delete_one_delta": float(transformed[index, column]),
                    "absolute_delta_over_cluster_se": float(ratio[index]),
                }
            )
    return records


def method_definition(config: Mapping[str, Any], input_hashes: Mapping[str, str]) -> dict[str, Any]:
    return {
        "stage": "4B robust global gradients and conditional survey transportability",
        "protocol_version": str(config["project"]["version"]),
        "labels": list(LABELS),
        "forbidden_labels": list(config["analysis_contract"]["forbidden_labels"]),
        "nominal_model": dict(config["analysis_contract"]["nominal_model"]),
        "sensitivity_ladder": list(config["analysis_contract"]["sensitivity_ladder"]),
        "survey_interaction": dict(config["analysis_contract"]["survey_interaction"]),
        "spatial_resampling": dict(config["analysis_contract"]["spatial_resampling"]),
        "influence_audit": dict(config["analysis_contract"]["influence_audit"]),
        "response_error_policy": dict(config["analysis_contract"]["response_error_policy"]),
        "input_sha256": dict(input_hashes),
        "science_boundary": dict(config["science_boundary"]),
        "runtime": {
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "pyarrow": pa.__version__,
            "pyyaml": yaml.__version__,
        },
    }


def validation_report(payload: Mapping[str, Any]) -> str:
    lines = [
        "# Stage 4B validation report",
        "",
        f"Overall passed: **{payload['overall_passed']}**",
        "",
        f"Gates: **{payload['n_passed']}/{payload['n_gates']}**",
        "",
        "| Gate | Result | Detail |",
        "|---|---:|---|",
    ]
    for gate in payload["gates"]:
        result = "PASS" if gate["passed"] else "FAIL"
        lines.append(f"| `{gate['name']}` | {result} | {gate['detail']} |")
    lines.extend(
        [
            "",
            "Stage 4B reports gradients within the frozen cross-survey RGB analysis sample. ",
            "Its common-support interactions are conditional survey contrasts, not a ",
            "selection-function correction or a volume-complete Milky-Way inference.",
        ]
    )
    return "\n".join(lines) + "\n"
