from __future__ import annotations

import sys

import numpy as np
import pandas as pd

from stage2c_common import (
    COEFFICIENT_COLUMNS,
    ELEMENTS,
    build_transport_atlas,
    element_flow_table,
    predictor_matrix,
    support_tiers,
)


def survey_frame(ids: list[int], survey: str) -> pd.DataFrame:
    frame = pd.DataFrame(
        {
            "survey_row_index": np.arange(len(ids), dtype=np.int64),
            "gaia_dr3_source_id": ids,
            "ra": np.asarray(ids, dtype=float),
            "dec": np.asarray(ids, dtype=float) / 10.0,
            "teff": 4800.0,
            "teff_err": 50.0,
            "logg": 2.5,
            "logg_err": 0.1,
            "rv": 20.0,
            "rv_err": 0.5,
            "broad_red_giant": True,
            "stellar_parameter_quality": True,
            "broad_rg_and_quality": True,
        }
    )
    if survey == "apogee":
        frame["apogee_id"] = [f"A{value}" for value in ids]
    else:
        frame["sobject_id"] = np.asarray(ids, dtype=np.int64) + 1000
    for index, element in enumerate(ELEMENTS):
        frame[element] = 0.01 * np.asarray(ids, dtype=float) + 0.02 * index
        frame[f"{element}_err"] = 0.01
        frame[f"valid_{element}"] = True
    return frame


def fixtures():
    master = pd.DataFrame(
        {
            "gaia_dr3_source_id": [1, 2, 3, 4, 5],
            "has_apogee": [True, False, True, False, True],
            "has_galah": [False, True, True, True, True],
            "survey_origin": [
                "APOGEE_only",
                "GALAH_only",
                "overlap",
                "GALAH_only",
                "overlap",
            ],
        }
    )
    apogee = survey_frame([1, 3, 5], "apogee")
    galah = survey_frame([2, 3, 4, 5], "galah")
    for element in ELEMENTS:
        galah[element] += 0.1
    galah.loc[galah["gaia_dr3_source_id"].eq(4), "teff"] = 6000.0
    apogee.loc[apogee["gaia_dr3_source_id"].eq(5), "broad_rg_and_quality"] = False
    coordinate = pd.DataFrame(
        {
            "gaia_dr3_source_id": [3, 5],
            "coordinate_status": ["IDENTITY_CONSISTENT", "APOGEE_COORDINATE_CONFIRMED"],
            "coordinate_hard_mismatch": [False, True],
            "coordinate_primary_ok": [True, False],
            "coordinate_sensitivity_ok": [True, True],
        }
    )
    support = {
        "galah_teff_scaled": {
            "minimum": -1.0,
            "q0_005": -0.8,
            "q0_01": -0.7,
            "median": 0.0,
            "q0_99": 0.3,
            "q0_995": 0.4,
            "maximum": 0.5,
        },
        "galah_logg_centered": {
            "minimum": -2.0,
            "q0_005": -1.5,
            "q0_01": -1.4,
            "median": 0.0,
            "q0_99": 0.8,
            "q0_995": 0.9,
            "maximum": 1.0,
        },
        "galah_fe_h": {
            "minimum": -2.5,
            "q0_005": -2.0,
            "q0_01": -1.8,
            "median": 0.0,
            "q0_99": 0.4,
            "q0_995": 0.5,
            "maximum": 0.6,
        },
    }
    models = {}
    coefficient_rows = []
    metric_rows = []
    for element in ELEMENTS:
        models[element] = {
            "coefficients": {
                "intercept_dex": 0.1,
                "coef_teff_per_1000k": 0.0,
                "coef_logg_per_dex": 0.0,
                "coef_feh_per_dex": 0.0,
            },
            "feature_support": support,
        }
        for fold in range(5):
            coefficient_rows.append(
                {
                    "element": element,
                    "analysis_set": "primary",
                    "model_role": "crossfit_fold",
                    "heldout_fold": fold,
                    "intercept_dex": 0.1 + fold * 0.001,
                    "coef_teff_per_1000k": 0.0,
                    "coef_logg_per_dex": 0.0,
                    "coef_feh_per_dex": 0.0,
                }
            )
        metric_rows.append(
            {
                "element": element,
                "analysis_set": "primary",
                "post_crossfit_sigma_mad_dex": 0.02,
            }
        )
    deploy = {"models": {"primary": models}}
    return (
        master,
        apogee,
        galah,
        coordinate,
        deploy,
        pd.DataFrame(coefficient_rows),
        pd.DataFrame(metric_rows),
    )


def main() -> int:
    checks = []
    master, apogee, galah, coordinate, deploy, coefficients, metrics = fixtures()
    atlas = build_transport_atlas(
        master, apogee, galah, coordinate, deploy, coefficients, metrics
    )

    checks.append(
        (
            "identity",
            atlas["gaia_dr3_source_id"].tolist() == [1, 2, 3, 4, 5]
            and not atlas["gaia_dr3_source_id"].duplicated().any(),
        )
    )
    checks.append(
        (
            "apogee_priority",
            atlas.loc[atlas["gaia_dr3_source_id"].eq(3), "fe_h_hom_source"].iloc[0]
            == "APOGEE_NATIVE",
        )
    )
    row2 = atlas.loc[atlas["gaia_dr3_source_id"].eq(2)].iloc[0]
    checks.append(
        (
            "galah_correction",
            abs(row2["fe_h_hom"] - (row2["galah_fe_h"] - 0.1)) < 1.0e-14
            and row2["fe_h_hom_primary_ok"],
        )
    )
    row4 = atlas.loc[atlas["gaia_dr3_source_id"].eq(4)].iloc[0]
    row5 = atlas.loc[atlas["gaia_dr3_source_id"].eq(5)].iloc[0]
    checks.append(
        (
            "extrapolation_and_coordinate_policy",
            row4["fe_h_galah_support_tier"] == "EXTRAPOLATED"
            and not row4["fe_h_hom_primary_ok"]
            and row4["fe_h_hom_sensitivity_ok"]
            and not row5["fe_h_hom_primary_ok"]
            and row5["fe_h_hom_sensitivity_ok"],
        )
    )
    expected_alpha = np.mean(
        [row2["mg_fe_hom"], row2["si_fe_hom"], row2["ca_fe_hom"]]
    )
    checks.append(
        (
            "alpha3_definition",
            row2["alpha3_primary_ok"]
            and abs(row2["alpha3_hom"] - expected_alpha) < 1.0e-14,
        )
    )
    checks.append(("flow_rows", len(element_flow_table(atlas)) == 5))

    failed = [name for name, passed in checks if not passed]
    if failed:
        raise AssertionError("Stage 2C self-test failed: " + ", ".join(failed))
    print(f"Stage 2C logic self-test passed: {len(checks)}/{len(checks)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)

