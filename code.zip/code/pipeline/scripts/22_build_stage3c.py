from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from stage3c_common import (
    LABELS,
    METRIC_SPECS,
    STAGE3A_COLUMNS,
    STAGE3B_COLUMNS,
    array_sha256,
    atomic_write_json,
    canonical_json_sha256,
    close_logger,
    estimator_stress,
    fixed_antithetic_normals,
    flag,
    frame_stress,
    ids_sha256,
    load_config,
    max_abs,
    method_definition,
    metric_decimals,
    number,
    project_path,
    propagate_chunk,
    read_json,
    science_output_hashes,
    setup_logger,
    sha256_file,
    utc_now,
    valid_distance_quantiles,
    write_frame,
)


def require_hash(path: Path, expected: str, label: str) -> str:
    if not path.exists():
        raise FileNotFoundError(f"Missing frozen {label}: {path}")
    observed = sha256_file(path)
    if observed != expected:
        raise RuntimeError(
            f"Frozen {label} SHA-256 mismatch: {observed}; expected {expected}"
        )
    return observed


def allocate_float(rows: int) -> np.ndarray:
    return np.full(rows, np.nan, dtype=np.float64)


def uncertainty_summary(
    output: dict[str, np.ndarray],
    stage3b: pd.DataFrame,
    primary: np.ndarray,
) -> pd.DataFrame:
    rows: list[dict[str, float | int | str]] = []
    for metric in METRIC_SPECS:
        half_width = output[f"{metric}__halfwidth"][primary]
        median_bias = (
            output[f"{metric}__q50"][primary] - number(stage3b, metric)[primary]
        )
        rows.append(
            {
                "quantity": metric,
                "rows": int(len(half_width)),
                "halfwidth_median": float(np.quantile(half_width, 0.50)),
                "halfwidth_q84": float(np.quantile(half_width, 0.84)),
                "halfwidth_q95": float(np.quantile(half_width, 0.95)),
                "halfwidth_q99": float(np.quantile(half_width, 0.99)),
                "median_bias_median": float(np.quantile(median_bias, 0.50)),
                "absolute_median_bias_q95": float(
                    np.quantile(np.abs(median_bias), 0.95)
                ),
            }
        )
    return pd.DataFrame(rows)


def convergence_summary(
    convergence: dict[str, np.ndarray],
    primary: np.ndarray,
    short_draws: int,
    full_draws: int,
) -> pd.DataFrame:
    rows: list[dict[str, float | int | str]] = []
    for metric in METRIC_SPECS:
        median_difference = convergence[f"{metric}__median_abs_difference"][primary]
        relative_width = convergence[
            f"{metric}__relative_halfwidth_difference"
        ][primary]
        rows.append(
            {
                "quantity": metric,
                "rows": int(len(median_difference)),
                "short_draws": int(short_draws),
                "full_draws": int(full_draws),
                "absolute_median_difference_median": float(
                    np.quantile(median_difference, 0.50)
                ),
                "absolute_median_difference_q95": float(
                    np.quantile(median_difference, 0.95)
                ),
                "relative_halfwidth_difference_median": float(
                    np.quantile(relative_width, 0.50)
                ),
                "relative_halfwidth_difference_q95": float(
                    np.quantile(relative_width, 0.95)
                ),
                "fraction_relative_halfwidth_within_10pct": float(
                    np.mean(relative_width <= 0.10)
                ),
                "fraction_relative_halfwidth_within_20pct": float(
                    np.mean(relative_width <= 0.20)
                ),
            }
        )
    return pd.DataFrame(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build Stage 3C uncertainty layer")
    parser.add_argument("--config", default="config/stage3c.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    stage3a_dir = project_path(root, config["paths"]["stage3a_output_dir"])
    stage3b_dir = project_path(root, config["paths"]["stage3b_output_dir"])
    output_dir = project_path(root, config["paths"]["output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "22_build_stage3c.log", "stage3c.build")
    stage3a_frozen = config["stage3a_frozen"]
    stage3b_frozen = config["stage3b_frozen"]
    outputs = config["outputs"]

    paths = {
        "stage3a_quality": stage3a_dir / stage3a_frozen["quality_layer_file"],
        "stage3b_phase": stage3b_dir / stage3b_frozen["phase_space_layer_file"],
        "stage3b_summary": stage3b_dir / stage3b_frozen["build_summary_file"],
        "stage3b_freeze": stage3b_dir / stage3b_frozen["freeze_manifest_file"],
        "stage3b_validation": stage3b_dir / stage3b_frozen["validation_file"],
        "stage3b_report": stage3b_dir / stage3b_frozen["validation_report_file"],
        "stage3b_frame": stage3b_dir / stage3b_frozen["frame_definition_file"],
        "stage3b_package_manifest": stage3b_dir
        / stage3b_frozen["package_manifest_file"],
    }
    input_hashes = {
        "stage3a_quality_layer": require_hash(
            paths["stage3a_quality"],
            stage3a_frozen["quality_layer_sha256"],
            "Stage 3A quality layer",
        ),
        "stage3b_phase_space_layer": require_hash(
            paths["stage3b_phase"],
            stage3b_frozen["phase_space_layer_sha256"],
            "Stage 3B phase-space layer",
        ),
        "stage3b_build_summary": require_hash(
            paths["stage3b_summary"],
            stage3b_frozen["build_summary_sha256"],
            "Stage 3B build summary",
        ),
        "stage3b_freeze_manifest": require_hash(
            paths["stage3b_freeze"],
            stage3b_frozen["freeze_manifest_sha256"],
            "Stage 3B freeze manifest",
        ),
        "stage3b_validation": require_hash(
            paths["stage3b_validation"],
            stage3b_frozen["validation_sha256"],
            "Stage 3B validation",
        ),
        "stage3b_validation_report": require_hash(
            paths["stage3b_report"],
            stage3b_frozen["validation_report_sha256"],
            "Stage 3B validation report",
        ),
        "stage3b_frame_definition": require_hash(
            paths["stage3b_frame"],
            stage3b_frozen["frame_definition_sha256"],
            "Stage 3B frame definition",
        ),
        "stage3b_package_manifest": require_hash(
            paths["stage3b_package_manifest"],
            stage3b_frozen["package_manifest_sha256"],
            "Stage 3B package manifest",
        ),
    }
    stage3b_validation = read_json(paths["stage3b_validation"])
    if not bool(stage3b_validation.get("overall_passed", False)):
        raise RuntimeError("Frozen Stage 3B validation is not PASS")
    if [
        int(stage3b_validation.get("n_passed", -1)),
        int(stage3b_validation.get("n_gates", -1)),
    ] != [
        int(stage3b_frozen["expected_validation_gates"]),
        int(stage3b_frozen["expected_validation_gates"]),
    ]:
        raise RuntimeError("Frozen Stage 3B validation gate count changed")

    logger.info("Reading frozen Stage 3A covariance and Stage 3B phase space")
    stage3a_meta = pq.ParquetFile(paths["stage3a_quality"])
    stage3b_meta = pq.ParquetFile(paths["stage3b_phase"])
    stage3a = pd.read_parquet(paths["stage3a_quality"], columns=list(STAGE3A_COLUMNS))
    stage3b = pd.read_parquet(paths["stage3b_phase"], columns=list(STAGE3B_COLUMNS))
    ids_a = stage3a["gaia_dr3_source_id"].to_numpy(np.int64)
    ids_b = stage3b["gaia_dr3_source_id"].to_numpy(np.int64)
    if not np.array_equal(ids_a, ids_b):
        raise RuntimeError("Stage 3A and Stage 3B source-ID vectors differ")
    if not np.all(np.diff(ids_a) > 0):
        raise RuntimeError("Candidate source IDs are not strictly increasing")
    expected_id_hash = stage3b_frozen["expected_candidate_id_sha256"]
    if ids_sha256(ids_a) != expected_id_hash:
        raise RuntimeError("Candidate source-ID hash changed")
    if [len(stage3a), stage3a_meta.metadata.num_columns] != [
        int(stage3a_frozen["expected_rows"]),
        int(stage3a_frozen["expected_columns"]),
    ]:
        raise RuntimeError("Stage 3A shape changed")
    if [len(stage3b), stage3b_meta.metadata.num_columns] != [
        int(stage3b_frozen["expected_rows"]),
        int(stage3b_frozen["expected_columns"]),
    ]:
        raise RuntimeError("Stage 3B shape changed")

    primary = flag(stage3b, "phase_space_6d_primary_ok")
    if int(primary.sum()) != int(stage3b_frozen["expected_primary_6d"]):
        raise RuntimeError("Stage 3B primary 6D count changed")
    if not np.array_equal(primary, flag(stage3a, "clean_6d_primary_ok")):
        raise RuntimeError("Stage 3B primary set differs from frozen Stage 3A primary set")

    rows = len(stage3a)
    uncertainty_policy = config["uncertainty_policy"]
    standard_draws = fixed_antithetic_normals(uncertainty_policy)
    output: dict[str, np.ndarray] = {
        "gaia_dr3_source_id": ids_a.copy(),
        "phase_space_6d_primary_ok": primary.copy(),
        "uncertainty_propagation_ok": np.zeros(rows, dtype=bool),
        "uncertainty_status": np.full(rows, "NOT_PRIMARY_6D", dtype=object),
        "mc_draws": np.zeros(rows, dtype=np.int16),
        "distance_quantile_valid": np.zeros(rows, dtype=bool),
        "rv_uncertainty_valid": np.zeros(rows, dtype=bool),
        "covariance_psd_ok": np.zeros(rows, dtype=bool),
        "covariance_repaired": np.zeros(rows, dtype=bool),
        "covariance_min_eigenvalue": allocate_float(rows),
        "mc_plausibility_fraction": allocate_float(rows),
        "mc_prograde_probability": allocate_float(rows),
        "frame_vrot_sign_stable": np.zeros(rows, dtype=bool),
    }
    convergence: dict[str, np.ndarray] = {}
    for metric in METRIC_SPECS:
        for suffix in ("q16", "q50", "q84", "halfwidth"):
            output[f"{metric}__{suffix}"] = allocate_float(rows)
        convergence[f"{metric}__median_abs_difference"] = allocate_float(rows)
        convergence[f"{metric}__relative_halfwidth_difference"] = allocate_float(rows)

    primary_indices = np.flatnonzero(primary)
    chunk_size = int(uncertainty_policy["star_chunk_size"])
    logger.info(
        "Propagating formal uncertainty: primary=%s; draws=%s; chunks=%s",
        f"{len(primary_indices):,}",
        len(standard_draws),
        int(np.ceil(len(primary_indices) / chunk_size)),
    )
    for chunk_number, start in enumerate(range(0, len(primary_indices), chunk_size), 1):
        selected_indices = primary_indices[start : start + chunk_size]
        selected = stage3a.iloc[selected_indices].reset_index(drop=True)
        chunk_output, chunk_convergence = propagate_chunk(
            selected,
            uncertainty_policy,
            config["frame_policy"]["base"],
            standard_draws,
        )
        output["uncertainty_propagation_ok"][selected_indices] = True
        output["uncertainty_status"][selected_indices] = "PROPAGATED"
        output["mc_draws"][selected_indices] = len(standard_draws)
        output["distance_quantile_valid"][selected_indices] = valid_distance_quantiles(
            selected
        )
        rv_error = number(selected, "analysis_rv_error_kms")
        output["rv_uncertainty_valid"][selected_indices] = np.isfinite(rv_error) & (
            rv_error > 0.0
        )
        output["covariance_psd_ok"][selected_indices] = (
            chunk_output["covariance_min_eigenvalue"] > 0.0
        )
        for name, values in chunk_output.items():
            output[name][selected_indices] = values
        for name, values in chunk_convergence.items():
            convergence[name][selected_indices] = values
        if chunk_number == 1 or chunk_number % 20 == 0 or start + chunk_size >= len(primary_indices):
            logger.info(
                "Uncertainty progress: %s/%s primary stars",
                f"{min(start + chunk_size, len(primary_indices)):,}",
                f"{len(primary_indices):,}",
            )

    if not np.array_equal(output["uncertainty_propagation_ok"], primary):
        raise RuntimeError("Formal uncertainty propagation did not cover the exact primary set")
    if np.any(output["covariance_repaired"]):
        raise RuntimeError("A covariance repair was applied despite the frozen prohibition")

    logger.info("Computing six explicit Galactocentric frame stress variants")
    stage3a_primary = stage3a.loc[primary].reset_index(drop=True)
    stage3b_primary = stage3b.loc[primary].reset_index(drop=True)
    frame_table, frame_envelopes, sign_stable, base_differences = frame_stress(
        stage3a_primary, stage3b_primary, config["frame_policy"]
    )
    if max(base_differences.values()) > 2.0e-6:
        raise RuntimeError(
            f"Stage 3C base-frame recomputation differs from Stage 3B: {base_differences}"
        )
    output["frame_vrot_sign_stable"][primary_indices] = sign_stable
    for metric in METRIC_SPECS:
        envelope_name = f"{metric}__frame_abs_envelope"
        ratio_name = f"{metric}__frame_envelope_over_mc_halfwidth"
        output[envelope_name] = allocate_float(rows)
        output[ratio_name] = allocate_float(rows)
        output[envelope_name][primary_indices] = frame_envelopes[metric]
        output[ratio_name][primary_indices] = frame_envelopes[metric] / np.maximum(
            output[f"{metric}__halfwidth"][primary_indices],
            float(METRIC_SPECS[metric]["floor"]),
        )

    logger.info("Computing geometric-versus-photogeometric estimator stress")
    estimator_table, estimator_columns = estimator_stress(stage3b, primary, output)
    output["geo_estimator_paired"] = estimator_columns.pop("paired")
    output.update(estimator_columns)

    uncertainty_table = uncertainty_summary(output, stage3b, primary)
    convergence_table = convergence_summary(
        convergence,
        primary,
        int(uncertainty_policy["convergence_draws"]),
        int(uncertainty_policy["draws"]),
    )
    label_rows = []
    for label in LABELS:
        selected = flag(stage3b, f"{label}_phase_space_primary_ok")
        label_rows.append(
            {
                "label": label,
                "stage3b_primary_rows": int(selected.sum()),
                "stage3c_propagated_rows": int(
                    np.count_nonzero(selected & output["uncertainty_propagation_ok"])
                ),
                "lost_rows": int(
                    np.count_nonzero(selected & ~output["uncertainty_propagation_ok"])
                ),
            }
        )
    label_table = pd.DataFrame(label_rows)

    rounding = uncertainty_policy["output_rounding"]
    for metric in METRIC_SPECS:
        decimals = metric_decimals(metric, uncertainty_policy)
        for suffix in (
            "q16",
            "q50",
            "q84",
            "halfwidth",
            "frame_abs_envelope",
            "geo_minus_photo",
        ):
            name = f"{metric}__{suffix}"
            output[name] = np.round(output[name], decimals=decimals)
        for suffix in (
            "frame_envelope_over_mc_halfwidth",
            "geo_abs_shift_over_mc_halfwidth",
        ):
            name = f"{metric}__{suffix}"
            output[name] = np.round(
                output[name], decimals=int(rounding["ratio_decimals"])
            )
    output["covariance_min_eigenvalue"] = np.round(
        output["covariance_min_eigenvalue"], decimals=10
    )
    for name in ("mc_plausibility_fraction", "mc_prograde_probability"):
        output[name] = np.round(
            output[name], decimals=int(rounding["probability_decimals"])
        )

    output_order = [
        "gaia_dr3_source_id",
        "phase_space_6d_primary_ok",
        "uncertainty_propagation_ok",
        "uncertainty_status",
        "mc_draws",
        "distance_quantile_valid",
        "rv_uncertainty_valid",
        "covariance_psd_ok",
        "covariance_repaired",
        "covariance_min_eigenvalue",
        "mc_plausibility_fraction",
        "mc_prograde_probability",
        "frame_vrot_sign_stable",
        "geo_estimator_paired",
    ]
    for metric in METRIC_SPECS:
        output_order.extend(
            [
                f"{metric}__q16",
                f"{metric}__q50",
                f"{metric}__q84",
                f"{metric}__halfwidth",
                f"{metric}__frame_abs_envelope",
                f"{metric}__frame_envelope_over_mc_halfwidth",
                f"{metric}__geo_minus_photo",
                f"{metric}__geo_abs_shift_over_mc_halfwidth",
            ]
        )
    layer = pd.DataFrame({name: output[name] for name in output_order})

    definition = method_definition(config)
    output_dir.mkdir(parents=True, exist_ok=True)
    science_paths = {
        "uncertainty_layer": output_dir / outputs["uncertainty_layer_file"],
        "uncertainty_summary": output_dir / outputs["uncertainty_summary_file"],
        "convergence": output_dir / outputs["convergence_file"],
        "frame_stress": output_dir / outputs["frame_stress_file"],
        "estimator_stress": output_dir / outputs["estimator_stress_file"],
        "label_flow": output_dir / outputs["label_flow_file"],
    }
    write_frame(layer, science_paths["uncertainty_layer"])
    write_frame(uncertainty_table, science_paths["uncertainty_summary"])
    write_frame(convergence_table, science_paths["convergence"])
    write_frame(frame_table, science_paths["frame_stress"])
    write_frame(estimator_table, science_paths["estimator_stress"])
    write_frame(label_table, science_paths["label_flow"])
    definition_path = output_dir / outputs["method_definition_file"]
    atomic_write_json(definition, definition_path)
    output_hashes = science_output_hashes([*science_paths.values(), definition_path])

    summary = {
        "stage": "3C formal-random phase-space uncertainty and transport stress",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "candidate_id_sha256": ids_sha256(ids_a),
        "counts": {
            "rows": int(len(layer)),
            "columns": int(len(layer.columns)),
            "stage3b_primary_6d": int(primary.sum()),
            "uncertainty_propagated": int(flag(layer, "uncertainty_propagation_ok").sum()),
            "covariance_repairs": int(flag(layer, "covariance_repaired").sum()),
            "geo_estimator_paired_primary": int(flag(layer, "geo_estimator_paired").sum()),
            "frame_vrot_sign_stable": int(
                np.count_nonzero(primary & flag(layer, "frame_vrot_sign_stable"))
            ),
        },
        "diagnostics": {
            "minimum_covariance_eigenvalue": float(
                np.nanmin(number(layer, "covariance_min_eigenvalue")[primary])
            ),
            "minimum_mc_plausibility_fraction": float(
                np.nanmin(number(layer, "mc_plausibility_fraction")[primary])
            ),
            "median_mc_plausibility_fraction": float(
                np.nanmedian(number(layer, "mc_plausibility_fraction")[primary])
            ),
            "frame_base_recomputation_max_abs_difference": base_differences,
            "ensemble_sha256": array_sha256(standard_draws),
        },
        "input_sha256": input_hashes,
        "output_sha256": output_hashes,
        "uncertainty_policy_sha256": canonical_json_sha256(uncertainty_policy),
        "frame_policy_sha256": canonical_json_sha256(config["frame_policy"]),
        "method_definition_sha256": sha256_file(definition_path),
        "upstream": {
            "stage3b_release_sha256": stage3b_frozen["release_sha256"],
            "stage3a_quality_layer_sha256": stage3a_frozen["quality_layer_sha256"],
            "stage3b_phase_space_layer_sha256": stage3b_frozen[
                "phase_space_layer_sha256"
            ],
        },
        "science_boundary": config["science_boundary"],
    }
    summary_path = output_dir / outputs["build_summary_file"]
    atomic_write_json(summary, summary_path)
    freeze = {
        "stage": "3C uncertainty freeze",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "candidate_id_sha256": ids_sha256(ids_a),
        "uncertainty_policy_sha256": summary["uncertainty_policy_sha256"],
        "frame_policy_sha256": summary["frame_policy_sha256"],
        "input_sha256": input_hashes,
        "output_sha256": {
            **output_hashes,
            summary_path.name: sha256_file(summary_path),
        },
        "science_boundary": config["science_boundary"],
    }
    atomic_write_json(freeze, output_dir / outputs["freeze_manifest_file"])
    logger.info(
        "Stage 3C build complete: rows=%s; propagated=%s; draws=%s; geo-paired=%s",
        f"{len(layer):,}",
        f"{primary.sum():,}",
        len(standard_draws),
        f"{flag(layer, 'geo_estimator_paired').sum():,}",
    )
    close_logger(logger)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)

