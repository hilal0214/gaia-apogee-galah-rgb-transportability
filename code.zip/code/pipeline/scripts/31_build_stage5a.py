from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from stage5a_common import (
    atomic_write_csv,
    atomic_write_json,
    close_logger,
    compute_design_outputs,
    design_contract,
    ids_sha256,
    load_config,
    project_path,
    read_json,
    read_layer,
    selected_input_columns,
    setup_logger,
    sha256_file,
)


def resolve_paths(config: dict[str, Any], root: Path) -> dict[str, Path]:
    stage4a = project_path(root, config["paths"]["stage4a_output_dir"])
    stage4b = project_path(root, config["paths"]["stage4b_output_dir"])
    output = project_path(root, config["paths"]["output_dir"])
    a = config["stage4a_frozen"]
    b = config["stage4b_frozen"]
    paths = {
        "design_layer": stage4a / a["design_layer_file"],
        "stage4a_definition": stage4a / a["design_definition_file"],
        "stage4a_population_flow": stage4a / a["population_feature_flow_file"],
        "stage4a_summary": stage4a / a["build_summary_file"],
        "stage4a_freeze": stage4a / a["freeze_manifest_file"],
        "stage4a_validation": stage4a / a["validation_file"],
        "stage4a_package": stage4a / a["package_manifest_file"],
        "stage4b_global": stage4b / b["global_estimates_file"],
        "stage4b_sensitivity": stage4b / b["sensitivity_ladder_file"],
        "stage4b_transport": stage4b / b["transportability_file"],
        "stage4b_claims": stage4b / b["claim_ledger_file"],
        "stage4b_method": stage4b / b["method_definition_file"],
        "stage4b_summary": stage4b / b["build_summary_file"],
        "stage4b_freeze": stage4b / b["freeze_manifest_file"],
        "stage4b_validation": stage4b / b["validation_file"],
        "stage4b_report": stage4b / b["validation_report_file"],
        "stage4b_package": stage4b / b["package_manifest_file"],
    }
    for key, value in config["outputs"].items():
        if key.endswith("_file"):
            paths[key.removesuffix("_file")] = output / value
    return paths


def expected_hashes(config: dict[str, Any]) -> dict[str, str]:
    a = config["stage4a_frozen"]
    b = config["stage4b_frozen"]
    return {
        "design_layer": a["design_layer_sha256"],
        "stage4a_definition": a["design_definition_sha256"],
        "stage4a_population_flow": a["population_feature_flow_sha256"],
        "stage4a_summary": a["build_summary_sha256"],
        "stage4a_freeze": a["freeze_manifest_sha256"],
        "stage4a_validation": a["validation_sha256"],
        "stage4a_package": a["package_manifest_sha256"],
        "stage4b_global": b["global_estimates_sha256"],
        "stage4b_sensitivity": b["sensitivity_ladder_sha256"],
        "stage4b_transport": b["transportability_sha256"],
        "stage4b_claims": b["claim_ledger_sha256"],
        "stage4b_method": b["method_definition_sha256"],
        "stage4b_summary": b["build_summary_sha256"],
        "stage4b_freeze": b["freeze_manifest_sha256"],
        "stage4b_validation": b["validation_sha256"],
        "stage4b_report": b["validation_report_sha256"],
        "stage4b_package": b["package_manifest_sha256"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Freeze Stage 5A leakage-safe population design")
    parser.add_argument("--config", default="config/stage5a.yml")
    parser.add_argument("--input-tsv", default=None, help=argparse.SUPPRESS)
    args = parser.parse_args()
    config, root = load_config(args.config)
    paths = resolve_paths(config, root)
    output_dir = project_path(root, config["paths"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    logger = setup_logger(project_path(root, config["paths"]["log_dir"]) / "31_build_stage5a.log", "stage5a.build")
    try:
        expected = expected_hashes(config)
        missing = [str(paths[key]) for key in expected if not paths[key].is_file()]
        if missing:
            raise FileNotFoundError("Missing frozen Stage 4A/4B input: " + "; ".join(missing))
        observed = {key: sha256_file(paths[key]) for key in expected}
        if observed != expected:
            mismatch = {key: {"expected": expected[key], "observed": observed[key]} for key in expected if expected[key] != observed[key]}
            raise RuntimeError(f"Frozen upstream byte identity failed: {mismatch}")
        a_validation = read_json(paths["stage4a_validation"])
        b_validation = read_json(paths["stage4b_validation"])
        if not bool(a_validation.get("overall_passed")) or [a_validation.get("n_passed"), a_validation.get("n_gates")] != [19, 19]:
            raise RuntimeError("Stage 4A is not frozen 19/19 PASS")
        if not bool(b_validation.get("overall_passed")) or [b_validation.get("n_passed"), b_validation.get("n_gates")] != [20, 20]:
            raise RuntimeError("Stage 4B is not frozen 20/20 PASS")
        if args.input_tsv is None:
            import pyarrow.parquet as pq

            metadata = pq.ParquetFile(paths["design_layer"]).metadata
            expected_shape = [int(config["stage4a_frozen"]["expected_rows"]), int(config["stage4a_frozen"]["expected_columns"])]
            if [metadata.num_rows, metadata.num_columns] != expected_shape:
                raise RuntimeError("Stage 4A design-layer metadata differs from the frozen contract")
        input_tsv = Path(args.input_tsv).resolve() if args.input_tsv else None
        logger.info("Reading Stage 5A population-design columns")
        layer = read_layer(paths["design_layer"], selected_input_columns(), input_tsv)
        ids = pd.to_numeric(layer["gaia_dr3_source_id"], errors="raise").to_numpy(np.int64)
        candidate_hash = ids_sha256(ids)
        if (
            len(ids) != int(config["stage4a_frozen"]["expected_rows"])
            or candidate_hash != str(config["stage4a_frozen"]["expected_candidate_id_sha256"])
            or len(np.unique(ids)) != len(ids)
            or not np.all(ids > 0)
            or not np.all(ids[1:] > ids[:-1])
        ):
            raise RuntimeError("Stage 4A candidate identity/order is not frozen")
        frames = compute_design_outputs(layer, config)
        counts = {
            "candidate_rows": int(len(layer)),
            "population_feature_primary": int(frames["cohort_flow"].loc[frames["cohort_flow"].stage == "population_feature_primary", "rows"].iloc[0]),
            "population_feature_frame_stable": int(frames["cohort_flow"].loc[frames["cohort_flow"].stage == "population_feature_frame_stable_sensitivity", "rows"].iloc[0]),
            "population_feature_common_support": int(frames["cohort_flow"].loc[frames["cohort_flow"].stage == "population_feature_common_support_sensitivity", "rows"].iloc[0]),
            "spatial_blocks": int(len(frames["spatial_fold_map"])),
            "crossfit_folds": int(len(frames["spatial_fold_summary"])),
            "model_views": int(len(config["population_design"]["model_views"])),
            "target_safe_view_rows": int(len(frames["leakage_audit"])),
        }
        if counts["population_feature_primary"] != int(config["stage4a_frozen"]["expected_population_feature_primary"]):
            raise RuntimeError("Primary population-feature count changed")
        if counts["population_feature_frame_stable"] != int(config["stage4a_frozen"]["expected_population_feature_frame_stable"]):
            raise RuntimeError("Frame-stable population-feature count changed")
        if counts["population_feature_common_support"] != int(config["stage4a_frozen"]["expected_population_feature_common_support"]):
            raise RuntimeError("Common-support population-feature count changed")
        contract = design_contract(config, observed, counts)
        atomic_write_json(contract, paths["design_contract"])
        for key, frame in frames.items():
            atomic_write_csv(frame, paths[key])
        science_keys = (
            "design_contract", "cohort_flow", "feature_scaling", "spatial_fold_map",
            "spatial_fold_summary", "survey_feature_balance", "feature_correlation", "leakage_audit",
        )
        science_hashes = {paths[key].name: sha256_file(paths[key]) for key in science_keys}
        build_summary = {
            "stage": "5A leakage-safe population-inference design freeze",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": str(config["project"]["frozen_created_utc"]),
            "candidate_id_sha256": candidate_hash,
            "input_sha256": observed,
            "output_sha256": science_hashes,
            "counts": counts,
            "maximum_absolute_survey_feature_smd": float(frames["survey_feature_balance"]["standardized_mean_difference_galah_minus_apogee"].abs().max()),
            "fold_primary_fractions": [float(value) for value in frames["spatial_fold_summary"]["primary_fraction"]],
            "science_boundary": config["science_boundary"],
            "runtime": {"numpy": np.__version__, "pandas": pd.__version__},
        }
        atomic_write_json(build_summary, paths["build_summary"])
        freeze_hashes = dict(science_hashes)
        freeze_hashes[paths["build_summary"].name] = sha256_file(paths["build_summary"])
        freeze = {
            "stage": "5A design freeze",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": str(config["project"]["frozen_created_utc"]),
            "candidate_id_sha256": candidate_hash,
            "input_sha256": observed,
            "output_sha256": freeze_hashes,
            "counts": counts,
            "science_boundary": config["science_boundary"],
        }
        atomic_write_json(freeze, paths["freeze_manifest"])
        logger.info("Stage 5A design build complete: primary=%s blocks=%s folds=%s", counts["population_feature_primary"], counts["spatial_blocks"], counts["crossfit_folds"])
        print(f"Stage 5A design build complete: primary={counts['population_feature_primary']} blocks={counts['spatial_blocks']} folds={counts['crossfit_folds']}")
        return 0
    finally:
        close_logger(logger)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
