from __future__ import annotations

import argparse
import os
import sys
import zipfile
from pathlib import Path
from typing import Any

from stage3b_common import (
    atomic_write_json,
    load_config,
    project_path,
    read_json,
    sha256_file,
    utc_now,
)


def file_record(root: Path, path: Path) -> dict[str, Any]:
    return {
        "path": str(path.relative_to(root)).replace("\\", "/"),
        "bytes": int(path.stat().st_size),
        "sha256": sha256_file(path),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Package Stage 3B outputs")
    parser.add_argument("--config", default="config/stage3b.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    frozen = config["stage3a_frozen"]
    outputs = config["outputs"]
    upstream_dir = project_path(root, config["paths"]["stage3a_output_dir"])
    output_dir = project_path(root, config["paths"]["output_dir"])
    log_dir = project_path(root, config["paths"]["log_dir"])
    validation = read_json(output_dir / outputs["validation_file"])
    if not validation.get("overall_passed", False):
        raise RuntimeError("Stage 3B validation is not PASS; refusing to package")

    relative_files = [
        "19_build_stage3b.bat",
        "20_validate_stage3b.bat",
        "21_package_stage3b.bat",
        "99_stage3b_selftest.bat",
        "run_stage3b_all.bat",
        "STAGE3B_PROTOCOL.md",
        "STAGE3B_README_UZ.md",
        "config/stage3b.yml",
        "scripts/19_build_stage3b.py",
        "scripts/20_validate_stage3b.py",
        "scripts/21_package_stage3b.py",
        "scripts/selftest_stage3b.py",
        "scripts/stage3b_common.py",
    ]
    files = [root / value for value in relative_files]
    files.extend(
        [
            log_dir / "19_build_stage3b.log",
            log_dir / "20_validate_stage3b.log",
            upstream_dir / frozen["build_summary_file"],
            upstream_dir / frozen["freeze_manifest_file"],
            upstream_dir / frozen["validation_file"],
            upstream_dir / frozen["validation_report_file"],
            output_dir / outputs["phase_space_layer_file"],
            output_dir / outputs["gate_flow_file"],
            output_dir / outputs["origin_flow_file"],
            output_dir / outputs["label_flow_file"],
            output_dir / outputs["extreme_audit_file"],
            output_dir / outputs["estimator_sensitivity_file"],
            output_dir / outputs["frame_definition_file"],
            output_dir / outputs["build_summary_file"],
            output_dir / outputs["freeze_manifest_file"],
            output_dir / outputs["validation_file"],
            output_dir / outputs["validation_report_file"],
        ]
    )
    missing = [str(path) for path in files if not path.exists()]
    if missing:
        raise FileNotFoundError("Cannot package missing files: " + "; ".join(missing))

    manifest = {
        "package": outputs["package_name"].removesuffix(".zip"),
        "stage": "3B",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "files": [file_record(root, path) for path in files],
        "upstream": {
            "stage3a_release_sha256": frozen["release_sha256"],
            "stage3a_quality_layer_sha256": frozen["quality_layer_sha256"],
        },
        "excluded": [
            "official raw survey catalogues",
            "the 76 frozen Gaia cache chunks",
            "the 333-MB Stage 2C transport atlas",
            "the 122-MB Stage 3A quality layer, referenced by exact SHA-256",
            "potential-dependent escape classification and orbit integration",
            "phase-space uncertainty propagation, gradients, and populations",
        ],
        "science_boundary": config["science_boundary"],
    }
    manifest_path = output_dir / outputs["package_manifest_file"]
    atomic_write_json(manifest, manifest_path)
    files_with_manifest = [*files, manifest_path]
    package_path = root / outputs["package_name"]
    temporary = package_path.with_name(f".{package_path.name}.tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(temporary, mode="w", allowZip64=True) as archive:
        for path in files_with_manifest:
            compress_type = (
                zipfile.ZIP_STORED
                if path.suffix.lower() == ".parquet"
                else zipfile.ZIP_DEFLATED
            )
            archive.write(
                path,
                arcname=str(path.relative_to(root)).replace("\\", "/"),
                compress_type=compress_type,
                compresslevel=None if compress_type == zipfile.ZIP_STORED else 6,
            )
    os.replace(temporary, package_path)
    print(f"Output bundle created: {package_path}")
    print(f"SHA-256: {sha256_file(package_path)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
