from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from stage2a_common import (
    ELEMENTS,
    add_support_flags,
    assignment_sha256,
    atomic_write_json,
    close_logger,
    coordinate_adjudication,
    coordinate_decision_sha256,
    ensure_columns,
    frozen_folds,
    ids_sha256,
    load_config,
    membership_sha256,
    project_path,
    read_json,
    setup_logger,
    sha256_file,
    to_python,
    utc_now,
    write_frame,
)


def require_frozen_stage1(config: dict[str, Any], root: Path) -> dict[str, Path]:
    stage1_dir = project_path(root, config["paths"]["stage1_output_dir"])
    frozen = config["stage1_frozen"]
    paths = {
        "overlap": stage1_dir / str(frozen["overlap_file"]),
        "source_master": stage1_dir / str(frozen["source_master_file"]),
        "query_summary": stage1_dir / str(frozen["query_summary_file"]),
        "validation": stage1_dir / str(frozen["validation_file"]),
    }
    for label, path in paths.items():
        if not path.exists():
            raise FileNotFoundError(
                f"Frozen Stage 1 {label} input is missing: {path}. "
                "Extract this Stage 2A patch into the original Stage 1 project directory."
            )
    observed_overlap_hash = sha256_file(paths["overlap"])
    if observed_overlap_hash != str(frozen["overlap_sha256"]):
        raise RuntimeError(
            "Stage 1 overlap file is not the accepted v0.1.2 input: "
            f"{observed_overlap_hash}"
        )
    observed_master_hash = sha256_file(paths["source_master"])
    if observed_master_hash != str(frozen["source_master_sha256"]):
        raise RuntimeError(
            "Stage 1 source master is not the accepted v0.1.2 input: "
            f"{observed_master_hash}"
        )
    validation = read_json(paths["validation"])
    if not validation.get("overall_passed", False):
        raise RuntimeError("Frozen Stage 1 validation is not PASS")
    expected = frozen["expected_counts"]
    counts = validation.get("key_counts", {})
    comparisons = {
        "union": counts.get("union"),
        "apogee_only": counts.get("apogee_only"),
        "galah_only": counts.get("galah_only"),
        "overlap": counts.get("overlap"),
    }
    for key, observed in comparisons.items():
        if int(observed or -1) != int(expected[key]):
            raise RuntimeError(
                f"Frozen Stage 1 count mismatch for {key}: {observed} != {expected[key]}"
            )
    query_summary = read_json(paths["query_summary"])
    if query_summary.get("selection_sha256") != str(frozen["selection_sha256"]):
        raise RuntimeError("Stage 1 Gaia selection hash changed")
    if query_summary.get("query_protocol_version") != str(
        frozen["query_protocol_version"]
    ):
        raise RuntimeError("Stage 1 Gaia query protocol changed")
    if not query_summary.get("complete", False):
        raise RuntimeError("Stage 1 Gaia query summary is incomplete")
    return paths


def normalise_gaia_coordinate_table(frame: pd.DataFrame, label: str) -> pd.DataFrame:
    source_column = (
        "source_id"
        if "source_id" in frame.columns
        else "gaia_dr3_source_id"
        if "gaia_dr3_source_id" in frame.columns
        else None
    )
    if source_column is None:
        raise KeyError(f"{label} has no source_id column")
    ensure_columns(frame, (source_column, "ra", "dec"), label)
    result = frame.loc[:, [source_column, "ra", "dec"]].copy()
    result.columns = ["gaia_dr3_source_id", "gaia_ra", "gaia_dec"]
    result["gaia_dr3_source_id"] = pd.to_numeric(
        result["gaia_dr3_source_id"], errors="coerce"
    ).fillna(0).astype("int64")
    result["gaia_ra"] = pd.to_numeric(result["gaia_ra"], errors="coerce")
    result["gaia_dec"] = pd.to_numeric(result["gaia_dec"], errors="coerce")
    return result


def load_gaia_coordinates_from_cache(
    config: dict[str, Any],
    root: Path,
    query_summary_path: Path,
    overlap_ids: np.ndarray,
    logger,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    summary = read_json(query_summary_path)
    cache_namespace = summary.get("cache_namespace")
    if not cache_namespace:
        raise RuntimeError("Stage 1 query summary has no cache namespace")
    joined_dir = project_path(root, str(cache_namespace)) / "joined"
    files = sorted(joined_dir.glob("chunk_*.parquet"))
    expected_chunks = int(config["stage1_frozen"]["expected_counts"]["gaia_chunks"])
    if len(files) != expected_chunks:
        raise FileNotFoundError(
            f"Expected {expected_chunks} Stage 1 joined Gaia chunks in {joined_dir}, "
            f"found {len(files)}. Do not re-query Gaia; restore/preserve the original "
            "data\\interim\\gaia_dr3 cache and rerun Stage 2A."
        )
    wanted = set(map(int, overlap_ids))
    parts: list[pd.DataFrame] = []
    for index, path in enumerate(files, start=1):
        chunk = pd.read_parquet(path, columns=["source_id", "ra", "dec"])
        source_ids = pd.to_numeric(chunk["source_id"], errors="coerce").fillna(0).astype(
            "int64"
        )
        mask = source_ids.isin(wanted)
        if mask.any():
            selected = chunk.loc[mask, ["source_id", "ra", "dec"]].copy()
            parts.append(normalise_gaia_coordinate_table(selected, path.name))
        if index % 10 == 0 or index == len(files):
            logger.info("Read Gaia coordinate cache chunks: %d/%d", index, len(files))
    if not parts:
        raise RuntimeError("No overlap source IDs were recovered from the Gaia joined cache")
    coordinates = pd.concat(parts, ignore_index=True)
    source_kind = "stage1_joined_cache"
    source_detail = {
        "kind": source_kind,
        "cache_namespace": str(cache_namespace).replace("\\", "/"),
        "joined_chunks": len(files),
        "stage1_selection_sha256": summary.get("selection_sha256"),
        "stage1_query_signature_sha256": summary.get("query_signature_sha256"),
    }
    return coordinates, source_detail


def load_gaia_coordinates(
    config: dict[str, Any],
    root: Path,
    query_summary_path: Path,
    overlap_ids: np.ndarray,
    override_path: str | None,
    logger,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    if override_path is None:
        coordinates, provenance = load_gaia_coordinates_from_cache(
            config, root, query_summary_path, overlap_ids, logger
        )
    else:
        path = project_path(root, override_path)
        if not path.exists():
            raise FileNotFoundError(f"Gaia coordinate override table is missing: {path}")
        coordinates = normalise_gaia_coordinate_table(
            pd.read_parquet(path), f"Gaia coordinate override {path}"
        )
        provenance = {
            "kind": "override_table",
            "path": str(path),
            "sha256": sha256_file(path),
        }
    coordinates = coordinates.loc[
        coordinates["gaia_dr3_source_id"].isin(set(map(int, overlap_ids)))
    ].copy()
    duplicate_count = int(coordinates["gaia_dr3_source_id"].duplicated().sum())
    if duplicate_count:
        raise RuntimeError(f"Gaia coordinate table has {duplicate_count} duplicate overlap IDs")
    recovered = set(map(int, coordinates["gaia_dr3_source_id"]))
    missing = set(map(int, overlap_ids)) - recovered
    unexpected = recovered - set(map(int, overlap_ids))
    if missing or unexpected:
        raise RuntimeError(
            "Gaia overlap coordinate recovery is not exact: "
            f"missing={len(missing)}, unexpected={len(unexpected)}"
        )
    finite = (
        np.isfinite(coordinates["gaia_ra"].to_numpy(dtype=float))
        & np.isfinite(coordinates["gaia_dec"].to_numpy(dtype=float))
    )
    if not finite.all():
        raise RuntimeError(f"Gaia coordinate table has {(~finite).sum()} non-finite rows")
    return coordinates, provenance


def build_support_counts(frame: pd.DataFrame, elements: list[str]) -> pd.DataFrame:
    rows = []
    joint = frame["joint_broad_rg_and_quality"].astype(bool)
    hard = frame["coordinate_hard_mismatch"].astype(bool)
    for element in elements:
        pre = frame[f"eligible_{element}_precoordinate"].astype(bool)
        primary = frame[f"eligible_{element}_primary"].astype(bool)
        sensitivity = frame[f"eligible_{element}_sensitivity"].astype(bool)
        rows.append(
            {
                "element": element,
                "identity_overlap": int(len(frame)),
                "joint_broad_rg_and_quality": int(joint.sum()),
                "pre_coordinate": int(pre.sum()),
                "primary": int(primary.sum()),
                "sensitivity": int(sensitivity.sum()),
                "primary_excluded_by_coordinate": int((pre & hard).sum()),
                "sensitivity_reincluded": int((sensitivity & hard).sum()),
            }
        )
    return pd.DataFrame(rows)


def build_fold_balance(frame: pd.DataFrame, elements: list[str], n_folds: int) -> pd.DataFrame:
    rows = []
    for element in elements:
        for analysis_set in ("primary", "sensitivity"):
            mask = frame[f"eligible_{element}_{analysis_set}"].astype(bool)
            total = int(mask.sum())
            for fold in range(n_folds):
                held_out = int((mask & frame["heldout_fold"].eq(fold)).sum())
                rows.append(
                    {
                        "element": element,
                        "analysis_set": analysis_set,
                        "heldout_fold": fold,
                        "heldout_n": held_out,
                        "training_n": total - held_out,
                        "total_n": total,
                    }
                )
    return pd.DataFrame(rows)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Freeze Stage 2A overlap support, coordinates, and held-out folds"
    )
    parser.add_argument("--config", default="config/stage2a.yml")
    parser.add_argument(
        "--gaia-coordinate-table",
        help="Testing/recovery override; production uses the frozen Stage 1 joined cache",
    )
    args = parser.parse_args()

    config, root = load_config(args.config)
    output_dir = project_path(root, config["paths"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "07_build_stage2a.log", "stage2a.build")
    logger.info("Starting Stage 2A protocol v%s", config["project"]["version"])

    stage1_paths = require_frozen_stage1(config, root)
    overlap = pd.read_parquet(stage1_paths["overlap"])
    ensure_columns(overlap, ("gaia_dr3_source_id",), "Stage 1 overlap")
    overlap["gaia_dr3_source_id"] = pd.to_numeric(
        overlap["gaia_dr3_source_id"], errors="coerce"
    ).fillna(0).astype("int64")
    overlap = overlap.sort_values("gaia_dr3_source_id", kind="mergesort").reset_index(
        drop=True
    )
    expected_overlap = int(
        config["stage1_frozen"]["expected_counts"]["overlap"]
    )
    if len(overlap) != expected_overlap:
        raise RuntimeError(f"Overlap rows changed: {len(overlap)} != {expected_overlap}")
    if not overlap["gaia_dr3_source_id"].gt(0).all():
        raise RuntimeError("Overlap contains a non-positive Gaia DR3 source ID")
    if overlap["gaia_dr3_source_id"].duplicated().any():
        raise RuntimeError("Overlap contains duplicate Gaia DR3 source IDs")

    overlap_ids = overlap["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
    observed_id_hash = ids_sha256(overlap_ids)
    expected_id_hash = str(config["fold_freeze"]["id_vector_sha256"])
    if observed_id_hash != expected_id_hash:
        raise RuntimeError(
            f"Frozen overlap ID vector changed: {observed_id_hash} != {expected_id_hash}"
        )

    gaia_coordinates, coordinate_source = load_gaia_coordinates(
        config,
        root,
        stage1_paths["query_summary"],
        overlap_ids,
        args.gaia_coordinate_table,
        logger,
    )
    frame = overlap.merge(
        gaia_coordinates,
        on="gaia_dr3_source_id",
        how="left",
        validate="one_to_one",
    )

    coordinate_policy = config["coordinate_adjudication"]
    coordinate_columns = coordinate_adjudication(
        frame,
        pair_hard_mismatch_arcsec=float(
            coordinate_policy["pair_hard_mismatch_arcsec"]
        ),
        gaia_confirmation_arcsec=float(coordinate_policy["gaia_confirmation_arcsec"]),
        gaia_far_arcsec=float(coordinate_policy["gaia_far_arcsec"]),
    )
    frame = pd.concat([frame, coordinate_columns], axis=1)

    fold_policy = config["fold_freeze"]
    ranks, folds = frozen_folds(
        frame["gaia_dr3_source_id"],
        seed=int(fold_policy["seed"]),
        n_folds=int(fold_policy["n_folds"]),
    )
    frame["heldout_rank_uint64"] = ranks
    frame["heldout_fold"] = folds
    frame["heldout_fold_label"] = pd.Series(
        [f"fold_{int(value)}" for value in folds], dtype="string"
    )

    elements = [str(value) for value in config["selection_freeze"]["elements"]]
    if tuple(elements) != ELEMENTS:
        raise RuntimeError(f"Element freeze changed: {elements} != {list(ELEMENTS)}")
    frame = add_support_flags(frame, elements)

    frozen_table_path = output_dir / "overlap_stage2a_frozen.parquet"
    write_frame(frame, frozen_table_path)
    assignments = frame.loc[
        :, ["gaia_dr3_source_id", "heldout_rank_uint64", "heldout_fold", "heldout_fold_label"]
    ].copy()
    write_frame(assignments, output_dir / "heldout_fold_assignments.parquet")

    support_counts = build_support_counts(frame, elements)
    write_frame(support_counts, output_dir / "element_support_counts.csv")
    fold_balance = build_fold_balance(frame, elements, int(fold_policy["n_folds"]))
    write_frame(fold_balance, output_dir / "fold_balance_by_element.csv")

    anomaly_columns = [
        "gaia_dr3_source_id",
        "apogee_apogee_id",
        "galah_sobject_id",
        "apogee_ra",
        "apogee_dec",
        "galah_ra",
        "galah_dec",
        "gaia_ra",
        "gaia_dec",
        "apogee_galah_sep_arcsec",
        "apogee_gaia_sep_arcsec",
        "galah_gaia_sep_arcsec",
        "coordinate_status",
        "coordinate_preferred_survey",
        "coordinate_primary_ok",
        "coordinate_sensitivity_ok",
        "galah_survey_name",
        "galah_field",
        "galah_setup",
        "joint_broad_rg_and_quality",
        "heldout_fold",
    ]
    anomalies = frame.loc[
        frame["coordinate_hard_mismatch"].astype(bool), anomaly_columns
    ].copy()
    anomalies["galah_observing_date"] = (
        anomalies["galah_sobject_id"].astype("int64").astype(str).str[:6]
    )
    write_frame(anomalies, output_dir / "coordinate_hard_mismatches.csv")

    assignment_hash = assignment_sha256(
        frame["gaia_dr3_source_id"], frame["heldout_fold"]
    )
    if assignment_hash != str(fold_policy["assignment_sha256"]):
        raise RuntimeError(
            f"Held-out assignment hash changed: {assignment_hash} != "
            f"{fold_policy['assignment_sha256']}"
        )

    status_counts = {
        str(key): int(value)
        for key, value in frame["coordinate_status"].value_counts().sort_index().items()
    }
    fold_counts = {
        str(int(key)): int(value)
        for key, value in frame["heldout_fold"].value_counts().sort_index().items()
    }
    support_hashes: dict[str, dict[str, str]] = {}
    for element in elements:
        support_hashes[element] = {
            analysis_set: membership_sha256(
                frame["gaia_dr3_source_id"],
                frame[f"eligible_{element}_{analysis_set}"],
            )
            for analysis_set in ("precoordinate", "primary", "sensitivity")
        }

    summary = {
        "stage": "2A overlap support, Gaia-coordinate adjudication, and fold freeze",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": utc_now(),
        "input": {
            "stage1_release_name": config["stage1_frozen"]["release_name"],
            "stage1_release_sha256": config["stage1_frozen"]["release_sha256"],
            "overlap_sha256": sha256_file(stage1_paths["overlap"]),
            "source_master_sha256": sha256_file(stage1_paths["source_master"]),
            "selection_sha256": config["stage1_frozen"]["selection_sha256"],
        },
        "gaia_coordinate_source": coordinate_source,
        "counts": {
            "identity_overlap": int(len(frame)),
            "coordinate_complete": int(frame["coordinate_complete"].sum()),
            "hard_coordinate_mismatch": int(
                frame["coordinate_hard_mismatch"].sum()
            ),
            "hard_mismatch_joint_broad_rg_and_quality": int(
                (
                    frame["coordinate_hard_mismatch"].astype(bool)
                    & frame["joint_broad_rg_and_quality"].astype(bool)
                ).sum()
            ),
            "joint_broad_rg_and_quality": int(
                frame["joint_broad_rg_and_quality"].sum()
            ),
        },
        "coordinate_status_counts": status_counts,
        "fold_freeze": {
            "algorithm": fold_policy["algorithm"],
            "seed": int(fold_policy["seed"]),
            "n_folds": int(fold_policy["n_folds"]),
            "all_overlap_fold_counts": fold_counts,
            "id_vector_sha256": observed_id_hash,
            "assignment_sha256": assignment_hash,
        },
        "support_counts": support_counts.to_dict(orient="records"),
        "support_membership_sha256": support_hashes,
        "coordinate_decision_sha256": coordinate_decision_sha256(frame),
        "outputs": {
            "frozen_overlap_table": frozen_table_path.name,
            "frozen_overlap_table_sha256": sha256_file(frozen_table_path),
        },
        "stage2b_cross_fitted_abundance_calibration_performed": False,
    }
    atomic_write_json(summary, output_dir / "stage2a_build_summary.json")

    freeze_manifest = {
        "stage": "2A deterministic freeze",
        "protocol_version": str(config["project"]["version"]),
        "created_utc": utc_now(),
        "input_identity": summary["input"],
        "coordinate_policy": {
            key: coordinate_policy[key]
            for key in (
                "pair_hard_mismatch_arcsec",
                "gaia_confirmation_arcsec",
                "gaia_far_arcsec",
                "primary_policy",
                "sensitivity_policy",
            )
        },
        "fold_policy": summary["fold_freeze"],
        "coordinate_decision_sha256": summary["coordinate_decision_sha256"],
        "support_membership_sha256": support_hashes,
        "stage2b_boundary": {
            "cross_fitted_abundance_calibration_performed": False,
            "calibration_coefficients_created": False,
            "corrected_abundances_created": False,
        },
    }
    atomic_write_json(freeze_manifest, output_dir / "stage2a_freeze_manifest.json")

    logger.info(
        "Stage 2A build complete: overlap=%s, hard mismatches=%s, joint RGB+quality=%s",
        f"{len(frame):,}",
        f"{int(frame['coordinate_hard_mismatch'].sum()):,}",
        f"{int(frame['joint_broad_rg_and_quality'].sum()):,}",
    )
    logger.info("No Stage 2B calibration was performed")
    close_logger(logger)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
