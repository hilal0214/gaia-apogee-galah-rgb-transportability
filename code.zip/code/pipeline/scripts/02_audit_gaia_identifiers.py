from __future__ import annotations

import argparse
import sys

import pandas as pd

from stage1_common import (
    atomic_write_json,
    configured_paths,
    ensure_columns,
    load_config,
    normalise_id_series,
    read_frame,
    setup_logger,
    table_suffix,
    utc_now,
)


def summarize_ids(series: pd.Series) -> dict[str, int]:
    ids = normalise_id_series(series)
    positive = ids.loc[ids.gt(0)]
    return {
        "rows": int(len(ids)),
        "positive_rows": int(len(positive)),
        "missing_or_nonpositive_rows": int(len(ids) - len(positive)),
        "unique_positive_ids": int(positive.nunique()),
        "repeated_positive_rows": int(len(positive) - positive.nunique()),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/stage1.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    paths = configured_paths(config, root)
    logger = setup_logger(
        paths["log_dir"] / "02_audit_gaia_identifiers.log",
        "stage1.identifier_audit",
    )
    suffix = table_suffix(config)
    ingest_dir = paths["interim_dir"] / "ingest"
    apogee_path = ingest_dir / f"apogee_rows{suffix}"
    galah_path = ingest_dir / f"galah_rows{suffix}"
    missing = [str(path) for path in (apogee_path, galah_path) if not path.exists()]
    if missing:
        raise FileNotFoundError(
            "Missing ingestion products; run 02_ingest_catalogues.bat first:\n"
            + "\n".join(missing)
        )

    apogee = read_frame(apogee_path, columns=["gaia_dr3_source_id"])
    galah = read_frame(galah_path, columns=["gaia_dr3_source_id"])
    ensure_columns(apogee, ["gaia_dr3_source_id"], "APOGEE ingest")
    ensure_columns(galah, ["gaia_dr3_source_id"], "GALAH ingest")

    apogee_ids = normalise_id_series(apogee["gaia_dr3_source_id"])
    galah_ids = normalise_id_series(galah["gaia_dr3_source_id"])
    apogee_unique = set(apogee_ids.loc[apogee_ids.gt(0)].astype(int))
    galah_unique = set(galah_ids.loc[galah_ids.gt(0)].astype(int))
    overlap = apogee_unique & galah_unique
    union = apogee_unique | galah_unique

    semantics = config["gaia"]["identifier_semantics"]
    audit = {
        "stage": "1B direct Gaia EDR3/DR3 identifier audit",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "complete": True,
        "identifier_semantics": semantics,
        "survey_counts": {
            "apogee": summarize_ids(apogee["gaia_dr3_source_id"]),
            "galah": summarize_ids(galah["gaia_dr3_source_id"]),
        },
        "raw_unique_id_sets": {
            "apogee_unique": int(len(apogee_unique)),
            "galah_unique": int(len(galah_unique)),
            "intersection": int(len(overlap)),
            "union": int(len(union)),
        },
        "scientific_note": (
            "APOGEE DR17 synspec_rev1 supplies GAIAEDR3_SOURCE_ID. Gaia EDR3 "
            "and DR3 have an identical source list, so no DR2-to-DR3 mapping "
            "or nearest-neighbour choice is applied."
        ),
    }
    output = paths["output_dir"] / "gaia_identifier_audit.json"
    atomic_write_json(audit, output)
    logger.info(
        "Identifier audit complete: %s APOGEE IDs, %s GALAH IDs, %s raw overlap",
        f"{len(apogee_unique):,}",
        f"{len(galah_unique):,}",
        f"{len(overlap):,}",
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
