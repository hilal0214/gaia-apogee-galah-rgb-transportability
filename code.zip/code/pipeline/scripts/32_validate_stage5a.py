from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from stage5a_common import (
    BASE_FEATURES,
    SOURCE_GROUPS,
    atomic_write_json,
    close_logger,
    compute_design_outputs,
    ids_sha256,
    load_config,
    population_source_group,
    project_path,
    read_json,
    read_layer,
    selected_input_columns,
    setup_logger,
    sha256_file,
    validation_report,
)


def resolve_paths(config: dict[str, Any], root: Path) -> dict[str, Path]:
    a_dir = project_path(root, config["paths"]["stage4a_output_dir"])
    b_dir = project_path(root, config["paths"]["stage4b_output_dir"])
    out = project_path(root, config["paths"]["output_dir"])
    a = config["stage4a_frozen"]
    b = config["stage4b_frozen"]
    paths = {
        "design_layer": a_dir / a["design_layer_file"],
        "stage4a_definition": a_dir / a["design_definition_file"],
        "stage4a_population_flow": a_dir / a["population_feature_flow_file"],
        "stage4a_summary": a_dir / a["build_summary_file"],
        "stage4a_freeze": a_dir / a["freeze_manifest_file"],
        "stage4a_validation": a_dir / a["validation_file"],
        "stage4a_package": a_dir / a["package_manifest_file"],
        "stage4b_global": b_dir / b["global_estimates_file"],
        "stage4b_sensitivity": b_dir / b["sensitivity_ladder_file"],
        "stage4b_transport": b_dir / b["transportability_file"],
        "stage4b_claims": b_dir / b["claim_ledger_file"],
        "stage4b_method": b_dir / b["method_definition_file"],
        "stage4b_summary": b_dir / b["build_summary_file"],
        "stage4b_freeze": b_dir / b["freeze_manifest_file"],
        "stage4b_validation": b_dir / b["validation_file"],
        "stage4b_report": b_dir / b["validation_report_file"],
        "stage4b_package": b_dir / b["package_manifest_file"],
    }
    for key, value in config["outputs"].items():
        if key.endswith("_file"):
            paths[key.removesuffix("_file")] = out / value
    return paths


def expected_hashes(config: dict[str, Any]) -> dict[str, str]:
    a = config["stage4a_frozen"]
    b = config["stage4b_frozen"]
    return {
        "design_layer": a["design_layer_sha256"],
        "stage4a_definition": a["design_definition_sha256"],
        "stage4a_population_flow": a["population_feature_flow_sha256"],
        "stage4a_summary": a["build_summary_sha256"],
        "stage4a_freeze": a["freeze_manifest_sha256"],
        "stage4a_validation": a["validation_sha256"],
        "stage4a_package": a["package_manifest_sha256"],
        "stage4b_global": b["global_estimates_sha256"],
        "stage4b_sensitivity": b["sensitivity_ladder_sha256"],
        "stage4b_transport": b["transportability_sha256"],
        "stage4b_claims": b["claim_ledger_sha256"],
        "stage4b_method": b["method_definition_sha256"],
        "stage4b_summary": b["build_summary_sha256"],
        "stage4b_freeze": b["freeze_manifest_sha256"],
        "stage4b_validation": b["validation_sha256"],
        "stage4b_report": b["validation_report_sha256"],
        "stage4b_package": b["package_manifest_sha256"],
    }


def frame_matches(actual: pd.DataFrame, expected: pd.DataFrame, tolerance: float) -> bool:
    if actual.shape != expected.shape or list(actual.columns) != list(expected.columns):
        return False
    for column in actual.columns:
        a_num = pd.to_numeric(actual[column], errors="coerce")
        e_num = pd.to_numeric(expected[column], errors="coerce")
        numeric = a_num.notna() | e_num.notna()
        if bool(numeric.any()):
            if not np.allclose(a_num[numeric].to_numpy(float), e_num[numeric].to_numpy(float), rtol=0.0, atol=tolerance, equal_nan=True):
                return False
            both_missing = a_num.isna() & e_num.isna()
            if not actual.loc[both_missing, column].astype("string").fillna("<NA>").equals(expected.loc[both_missing, column].astype("string").fillna("<NA>")):
                return False
        elif not actual[column].astype("string").fillna("<NA>").equals(expected[column].astype("string").fillna("<NA>")):
            return False
    return True


def gate(name: str, passed: bool, detail: str, expected: Any = None, observed: Any = None) -> dict[str, Any]:
    row = {"name": name, "passed": bool(passed), "detail": detail}
    if expected is not None:
        row["expected"] = expected
    if observed is not None:
        row["observed"] = observed
    return row


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Stage 5A population-design freeze")
    parser.add_argument("--config", default="config/stage5a.yml")
    parser.add_argument("--input-tsv", default=None, help=argparse.SUPPRESS)
    args = parser.parse_args()
    config, root = load_config(args.config)
    paths = resolve_paths(config, root)
    logger = setup_logger(project_path(root, config["paths"]["log_dir"]) / "32_validate_stage5a.log", "stage5a.validate")
    try:
        tolerance = float(config["validation"]["numeric_absolute_tolerance"])
        expected_upstream = expected_hashes(config)
        observed_upstream = {key: sha256_file(paths[key]) for key in expected_upstream}
        a_validation = read_json(paths["stage4a_validation"])
        b_validation = read_json(paths["stage4b_validation"])
        input_tsv = Path(args.input_tsv).resolve() if args.input_tsv else None
        layer = read_layer(paths["design_layer"], selected_input_columns(), input_tsv)
        ids = pd.to_numeric(layer["gaia_dr3_source_id"], errors="raise").to_numpy(np.int64)
        candidate_hash = ids_sha256(ids)
        recomputed = compute_design_outputs(layer, config)
        stored = {
            key: pd.read_csv(paths[key])
            for key in (
                "cohort_flow", "feature_scaling", "spatial_fold_map", "spatial_fold_summary",
                "survey_feature_balance", "feature_correlation", "leakage_audit",
            )
        }
        contract = read_json(paths["design_contract"])
        summary = read_json(paths["build_summary"])
        freeze = read_json(paths["freeze_manifest"])
        gates: list[dict[str, Any]] = []
        a_keys = [key for key in expected_upstream if key.startswith("stage4a") or key == "design_layer"]
        b_keys = [key for key in expected_upstream if key.startswith("stage4b")]
        gates.append(gate("upstream_stage4a_byte_identity", all(observed_upstream[key] == expected_upstream[key] for key in a_keys), "all accepted Stage 4A design/provenance bytes remain frozen"))
        gates.append(gate("upstream_stage4a_validation", bool(a_validation.get("overall_passed")) and [a_validation.get("n_passed"), a_validation.get("n_gates")] == [19, 19], "corrected Stage 4A remains 19/19 PASS"))
        gates.append(gate("upstream_stage4b_byte_identity", all(observed_upstream[key] == expected_upstream[key] for key in b_keys), "all accepted Stage 4B global-gradient/provenance bytes remain frozen"))
        gates.append(gate("upstream_stage4b_validation", bool(b_validation.get("overall_passed")) and [b_validation.get("n_passed"), b_validation.get("n_gates")] == [20, 20], "Stage 4B remains 20/20 PASS"))
        identity_ok = len(ids) == 393834 and candidate_hash == config["stage4a_frozen"]["expected_candidate_id_sha256"] and len(np.unique(ids)) == len(ids) and np.all(ids > 0) and np.all(ids[1:] > ids[:-1])
        gates.append(gate("candidate_identity_and_schema", identity_ok and list(layer.columns) == selected_input_columns(), "the 393,834-row candidate vector and selected population-design schema are exact"))
        flow = stored["cohort_flow"].set_index("stage")["rows"]
        count_ok = int(flow["population_feature_primary"]) == 323087 and int(flow["population_feature_frame_stable_sensitivity"]) == 321420 and int(flow["population_feature_common_support_sensitivity"]) == 269203
        gates.append(gate("population_cohort_counts", count_ok and frame_matches(stored["cohort_flow"], recomputed["cohort_flow"], tolerance), "primary, frame-stable, common-support, and survey-source cohort counts reproduce exactly"))
        primary = layer["population_feature_primary_ok"].fillna(False).astype(bool).to_numpy()
        finite_ok = all(np.isfinite(pd.to_numeric(layer.loc[primary, feature], errors="coerce").to_numpy(float)).all() for feature in BASE_FEATURES)
        uncertainty_columns = ["fe_h_hom_error_proxy", "alpha3_hom_error_proxy", "v_R_gc_kms__halfwidth", "v_rot_gc_kms__halfwidth", "v_z_gc_kms__halfwidth"]
        uncertainty_ok = all(np.isfinite(pd.to_numeric(layer.loc[primary, column], errors="coerce").to_numpy(float)).all() and np.all(pd.to_numeric(layer.loc[primary, column], errors="coerce").to_numpy(float) >= 0) for column in uncertainty_columns)
        gates.append(gate("primary_feature_and_uncertainty_finiteness", finite_ok and uncertainty_ok, "all primary model features and guard-only uncertainty columns are finite and non-negative where required"))
        source = population_source_group(layer)
        source_count = {group: int(np.sum(primary & (source == group))) for group in (*SOURCE_GROUPS, "MIXED_OR_OTHER")}
        source_flow = {group: int(flow[f"primary_{group.lower()}"]) for group in (*SOURCE_GROUPS, "MIXED_OR_OTHER")}
        gates.append(gate("source_group_contract", source_count == source_flow and sum(source_count.values()) == int(primary.sum()), "population survey-source groups are an exhaustive exact derivation of Fe/H and alpha3 provenance"))
        gates.append(gate("feature_scaling_identity", frame_matches(stored["feature_scaling"], recomputed["feature_scaling"], tolerance), "full-primary diagnostic median/MAD scalers and quantiles reproduce exactly"))
        gates.append(gate("fold_assignment_identity", frame_matches(stored["spatial_fold_map"], recomputed["spatial_fold_map"], tolerance), "every HEALPix-5 block has the deterministic namespace-derived fold"))
        fold_map = stored["spatial_fold_map"]
        fold_exclusive = fold_map.gaia_healpix5.nunique() == len(fold_map) and set(fold_map.fold.astype(int)) == set(range(5))
        gates.append(gate("fold_block_exclusivity", fold_exclusive, "a HEALPix-5 block appears in exactly one held-out fold"))
        fractions = stored["spatial_fold_summary"].primary_fraction.to_numpy(float)
        balance_ok = np.all(fractions >= float(config["validation"]["minimum_fold_primary_fraction"])) and np.all(fractions <= float(config["validation"]["maximum_fold_primary_fraction"])) and abs(float(fractions.sum()) - 1.0) <= tolerance
        gates.append(gate("fold_balance", balance_ok and frame_matches(stored["spatial_fold_summary"], recomputed["spatial_fold_summary"], tolerance), "five spatial folds satisfy the frozen primary-row balance envelope"))
        gates.append(gate("survey_balance_identity", frame_matches(stored["survey_feature_balance"], recomputed["survey_feature_balance"], tolerance), "APOGEE/GALAH population-feature balance summaries reproduce in primary and common support"))
        gates.append(gate("feature_correlation_identity", frame_matches(stored["feature_correlation"], recomputed["feature_correlation"], tolerance), "the 15 prespecified Pearson/Spearman feature pairs reproduce exactly"))
        leakage = stored["leakage_audit"]
        leakage_ok = frame_matches(leakage, recomputed["leakage_audit"], tolerance) and leakage.passes_leakage_contract.astype(bool).all()
        gates.append(gate("target_leakage_contract", leakage_ok, "R and abs(Z) are excluded from every classifier and each fitted target is excluded from its own gradient view"))
        mixture = contract["population_design"]["mixture_contract"]
        mixture_ok = mixture["family"] == "multivariate_student_t_mixture" and mixture["nominal_components"] == 4 and mixture["sensitivity_components"] == [3, 5] and mixture["canonical_component_names"] == ["C1", "C2", "C3", "C4"] and bool(mixture["semantic_names_are_postfit_descriptors"])
        gates.append(gate("mixture_design_contract", mixture_ok, "four anonymous nominal components, K=3/5 sensitivity, robust Student-t family, and post-fit semantics are frozen"))
        policy = contract["population_design"]
        boundary_ok = not policy["survey_support"]["common_support_is_selection_correction"] and not policy["uncertainty_policy"]["abundance_error_proxy_used_as_likelihood_sigma"] and not policy["uncertainty_policy"]["abundance_error_proxy_used_as_feature_weight"] and not policy["uncertainty_policy"]["velocity_halfwidth_used_as_likelihood_sigma"]
        gates.append(gate("uncertainty_and_selection_boundary", boundary_ok, "error proxies are guards/stress inputs only and common support is not a selection correction"))
        expected_shapes = {"cohort_flow": [10, 2], "feature_scaling": [5, 16], "spatial_fold_map": [len(stored["spatial_fold_map"]), 6], "spatial_fold_summary": [5, 8], "survey_feature_balance": [10, 13], "feature_correlation": [15, 5], "leakage_audit": [7, 7]}
        observed_shapes = {key: list(value.shape) for key, value in stored.items()}
        gates.append(gate("output_shapes_and_schemas", observed_shapes == expected_shapes and all(not frame.columns.duplicated().any() for frame in stored.values()), "all Stage 5A design tables have frozen schemas without duplicate fields", expected_shapes, observed_shapes))
        output_hashes = summary["output_sha256"]
        hashes_ok = all(paths[name.removeprefix("stage5a_").removesuffix(".csv").removesuffix(".json")].is_file() if False else True for name in [])
        for filename, expected_hash in output_hashes.items():
            file_path = project_path(root, config["paths"]["output_dir"]) / filename
            hashes_ok = hashes_ok and file_path.is_file() and sha256_file(file_path) == expected_hash
        hashes_ok = hashes_ok and freeze["input_sha256"] == expected_upstream and freeze["candidate_id_sha256"] == candidate_hash and freeze["counts"] == summary["counts"]
        for filename, expected_hash in freeze["output_sha256"].items():
            file_path = project_path(root, config["paths"]["output_dir"]) / filename
            hashes_ok = hashes_ok and file_path.is_file() and sha256_file(file_path) == expected_hash
        gates.append(gate("output_hashes_and_freeze", hashes_ok, "science-output hashes, counts, inputs, build summary, and freeze manifest are internally exact"))
        forbidden_names = ("responsibility", "probability", "population_label", "gradient_by_population")
        output_names = [path.name.lower() for path in project_path(root, config["paths"]["output_dir"]).iterdir() if path.is_file()]
        science_ok = contract["science_boundary"] == config["science_boundary"] and freeze["science_boundary"] == config["science_boundary"] and all(not bool(value) for key, value in config["science_boundary"].items() if isinstance(value, bool) and key not in {"spatial_block_cross_fitting_prespecified"}) and bool(config["science_boundary"]["spatial_block_cross_fitting_prespecified"]) and not any(any(token in name for token in forbidden_names) for name in output_names)
        gates.append(gate("science_boundary", science_ok, "Stage 5A stops before mixture fitting, responsibilities, labels, population gradients, selection weights, or physical membership claims"))
        payload = {
            "stage": "5A leakage-safe population-inference design freeze",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": str(config["project"]["frozen_created_utc"]),
            "overall_passed": bool(all(item["passed"] for item in gates)),
            "n_passed": int(sum(item["passed"] for item in gates)),
            "n_gates": int(len(gates)),
            "gates": gates,
        }
        if payload["n_gates"] != int(config["validation"]["expected_gates"]):
            raise RuntimeError(f"Validator gate count changed: {payload['n_gates']}")
        atomic_write_json(payload, paths["validation"])
        paths["validation_report"].write_text(validation_report(payload), encoding="utf-8", newline="\n")
        logger.info("Stage 5A validation passed=%s; gates=%s/%s", payload["overall_passed"], payload["n_passed"], payload["n_gates"])
        print(f"Stage 5A validation passed={payload['overall_passed']}; gates={payload['n_passed']}/{payload['n_gates']}")
        return 0 if payload["overall_passed"] else 1
    finally:
        close_logger(logger)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
