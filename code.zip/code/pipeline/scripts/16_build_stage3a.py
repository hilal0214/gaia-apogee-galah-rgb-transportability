from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from stage3a_common import (
    CANDIDATE_COLUMNS,
    atomic_write_json,
    canonical_json_sha256,
    close_logger,
    compute_quality_layer,
    gate_flow_table,
    ids_sha256,
    label_flow_table,
    load_config,
    load_verified_gaia_candidates,
    origin_flow_table,
    project_path,
    read_json,
    setup_logger,
    sha256_file,
    utc_now,
    write_frame,
)


def require_hash(path: Path, expected: str, label: str) -> str:
    if not path.exists():
        raise FileNotFoundError(f"Missing frozen {label}: {path}")
    observed = sha256_file(path)
    if observed != expected:
        raise RuntimeError(
            f"Frozen {label} SHA-256 mismatch: {observed}; expected {expected}"
        )
    return observed


def main() -> int:
    parser = argparse.ArgumentParser(description="Build Stage 3A Gaia quality layer")
    parser.add_argument("--config", default="config/stage3a.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    stage1_dir = project_path(root, config["paths"]["stage1_output_dir"])
    stage2c_dir = project_path(root, config["paths"]["stage2c_output_dir"])
    output_dir = project_path(root, config["paths"]["output_dir"])
    cache_root = project_path(root, config["paths"]["gaia_cache_root"])
    cache_namespace = cache_root / config["stage1_frozen"]["expected_cache_namespace"]
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "16_build_stage3a.log", "stage3a.build")

    stage1 = config["stage1_frozen"]
    stage2c = config["stage2c_frozen"]
    outputs = config["outputs"]
    paths = {
        "stage1_validation": stage1_dir / stage1["validation_file"],
        "query_summary": stage1_dir / stage1["query_summary_file"],
        "atlas": stage2c_dir / stage2c["atlas_file"],
        "stage2c_summary": stage2c_dir / stage2c["build_summary_file"],
        "stage2c_freeze": stage2c_dir / stage2c["freeze_manifest_file"],
        "stage2c_validation": stage2c_dir / stage2c["validation_file"],
    }
    input_hashes = {
        "stage1_validation": require_hash(
            paths["stage1_validation"], stage1["validation_sha256"], "Stage 1 validation"
        ),
        "gaia_query_summary": require_hash(
            paths["query_summary"], stage1["query_summary_sha256"], "Gaia query summary"
        ),
        "stage2c_atlas": require_hash(
            paths["atlas"], stage2c["atlas_sha256"], "Stage 2C atlas"
        ),
        "stage2c_build_summary": require_hash(
            paths["stage2c_summary"],
            stage2c["build_summary_sha256"],
            "Stage 2C build summary",
        ),
        "stage2c_freeze_manifest": require_hash(
            paths["stage2c_freeze"],
            stage2c["freeze_manifest_sha256"],
            "Stage 2C freeze manifest",
        ),
        "stage2c_validation": require_hash(
            paths["stage2c_validation"],
            stage2c["validation_sha256"],
            "Stage 2C validation",
        ),
    }
    stage1_validation = read_json(paths["stage1_validation"])
    stage2c_validation = read_json(paths["stage2c_validation"])
    if not stage1_validation.get("overall_passed", False):
        raise RuntimeError("Frozen Stage 1 validation is not PASS")
    if not stage2c_validation.get("overall_passed", False):
        raise RuntimeError("Frozen Stage 2C validation is not PASS")

    query_summary = read_json(paths["query_summary"])
    if not query_summary.get("complete", False):
        raise RuntimeError("Frozen Gaia full query summary is not complete")
    expected_query = {
        "mode": "full",
        "unique_requested_ids": int(stage1["expected_rows"]),
        "selection_sha256": stage1["expected_selection_sha256"],
        "query_signature_sha256": stage1["expected_query_signature_sha256"],
        "query_protocol_version": str(stage1["expected_query_protocol_version"]),
        "planned_chunks": int(stage1["expected_chunks"]),
        "completed_chunks": int(stage1["expected_chunks"]),
        "chunk_size": int(stage1["expected_chunk_size"]),
    }
    for key, expected in expected_query.items():
        if query_summary.get(key) != expected:
            raise RuntimeError(
                f"Gaia query summary {key}={query_summary.get(key)!r}, expected={expected!r}"
            )

    logger.info("Reading frozen Stage 2C candidate columns")
    atlas = pd.read_parquet(paths["atlas"], columns=list(CANDIDATE_COLUMNS))
    if len(atlas) != int(stage2c["expected_atlas_rows"]):
        raise RuntimeError(f"Stage 2C atlas rows={len(atlas)}")
    all_ids = pd.to_numeric(atlas["gaia_dr3_source_id"], errors="raise").astype(
        "int64"
    ).to_numpy()
    if not np.all(np.diff(all_ids) > 0):
        raise RuntimeError("Stage 2C atlas source IDs are not strictly increasing")
    if ids_sha256(all_ids) != stage1["expected_selection_sha256"]:
        raise RuntimeError("Stage 2C atlas source-ID hash is not the frozen Gaia selection")
    candidate_mask = atlas[config["quality_policy"]["candidate_rule"]].astype(bool)
    candidates = atlas.loc[candidate_mask].copy().reset_index(drop=True)
    if len(candidates) != int(stage2c["expected_candidate_rows"]):
        raise RuntimeError(
            f"Stage 3A candidates={len(candidates)}, expected={stage2c['expected_candidate_rows']}"
        )
    if int(candidates["spectroscopic_primary_ok"].sum()) != int(
        stage2c["expected_primary_spectroscopic_rows"]
    ):
        raise RuntimeError("Stage 2C spectroscopic-primary count changed")
    candidate_ids = candidates["gaia_dr3_source_id"].to_numpy(np.int64)

    logger.info("Verifying 76 Gaia cache chunks and extracting Stage 3A candidates")
    gaia_candidates, cache_audit, cache_summary = load_verified_gaia_candidates(
        cache_namespace,
        all_ids,
        candidate_ids,
        stage1,
        query_summary,
    )
    logger.info(
        "Gaia cache verified: full=%s; candidate=%s; chunks=%s",
        f"{cache_summary['full_rows']:,}",
        f"{cache_summary['candidate_rows']:,}",
        cache_summary["chunks"],
    )

    layer = compute_quality_layer(candidates, gaia_candidates, config["quality_policy"])
    gate_flow = gate_flow_table(layer, len(atlas))
    origin_flow = origin_flow_table(layer)
    label_flow = label_flow_table(layer)
    output_dir.mkdir(parents=True, exist_ok=True)
    science_paths = {
        "quality_layer": output_dir / outputs["quality_layer_file"],
        "cache_audit": output_dir / outputs["cache_audit_file"],
        "gate_flow": output_dir / outputs["gate_flow_file"],
        "origin_flow": output_dir / outputs["origin_flow_file"],
        "label_flow": output_dir / outputs["label_flow_file"],
    }
    write_frame(layer, science_paths["quality_layer"])
    write_frame(cache_audit, science_paths["cache_audit"])
    write_frame(gate_flow, science_paths["gate_flow"])
    write_frame(origin_flow, science_paths["origin_flow"])
    write_frame(label_flow, science_paths["label_flow"])
    output_hashes = {path.name: sha256_file(path) for path in science_paths.values()}

    counts = {
        "stage2c_parent_rows": int(len(atlas)),
        "candidate_rows": int(len(layer)),
        "quality_layer_columns": int(len(layer.columns)),
        "spectroscopic_primary_ok": int(layer["spectroscopic_primary_ok"].sum()),
        "astrometry_primary_ok": int(layer["gaia_astrometry_primary_ok"].sum()),
        "astrometry_sensitivity_ok": int(
            layer["gaia_astrometry_sensitivity_ok"].sum()
        ),
        "distance_photogeo_primary_ok": int(
            layer["distance_photogeo_primary_ok"].sum()
        ),
        "distance_photogeo_sensitivity_ok": int(
            layer["distance_photogeo_sensitivity_ok"].sum()
        ),
        "rv_primary_ok": int(layer["rv_primary_ok"].sum()),
        "rv_sensitivity_ok": int(layer["rv_sensitivity_ok"].sum()),
        "rv_cross_source_disagreement": int(
            layer["rv_cross_source_disagreement"].sum()
        ),
        "clean_5d_primary_ok": int(layer["clean_5d_primary_ok"].sum()),
        "clean_5d_sensitivity_ok": int(layer["clean_5d_sensitivity_ok"].sum()),
        "clean_6d_primary_ok": int(layer["clean_6d_primary_ok"].sum()),
        "clean_6d_sensitivity_ok": int(layer["clean_6d_sensitivity_ok"].sum()),
        "clean_6d_geo_alternative_ok": int(
            layer["clean_6d_geo_alternative_ok"].sum()
        ),
    }
    summary = {
        "stage": "3A Gaia quality and eligibility freeze",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "counts": counts,
        "cache": cache_summary,
        "input_sha256": input_hashes,
        "output_sha256": output_hashes,
        "source_id_sha256": ids_sha256(all_ids),
        "candidate_id_sha256": ids_sha256(candidate_ids),
        "quality_policy_sha256": canonical_json_sha256(config["quality_policy"]),
        "upstream": {
            "stage1_release_sha256": stage1["release_sha256"],
            "stage2c_release_sha256": stage2c["release_sha256"],
        },
        "distance_interpretation": (
            "Photogeometric posterior median is primary; the geometric posterior is "
            "retained as an estimator-sensitivity layer. Direct inverse parallax is unused."
        ),
        "rv_interpretation": (
            "Large spectroscopy-Gaia disagreements are excluded from primary 6D but "
            "retained in sensitivity; they may reflect binaries or catalogue failures."
        ),
        "science_boundary": config["science_boundary"],
    }
    summary_path = output_dir / outputs["build_summary_file"]
    atomic_write_json(summary, summary_path)
    freeze = {
        "stage": "3A Gaia quality freeze",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "source_id_sha256": ids_sha256(all_ids),
        "candidate_id_sha256": ids_sha256(candidate_ids),
        "quality_policy_sha256": summary["quality_policy_sha256"],
        "cache_joined_chunk_set_sha256": cache_summary["joined_chunk_set_sha256"],
        "cache_metadata_chunk_set_sha256": cache_summary[
            "metadata_chunk_set_sha256"
        ],
        "input_sha256": input_hashes,
        "output_sha256": {
            **output_hashes,
            summary_path.name: sha256_file(summary_path),
        },
        "science_boundary": config["science_boundary"],
    }
    atomic_write_json(freeze, output_dir / outputs["freeze_manifest_file"])
    logger.info(
        "Stage 3A build complete: candidates=%s; clean6D primary=%s; no phase-space transform",
        f"{len(layer):,}",
        f"{counts['clean_6d_primary_ok']:,}",
    )
    close_logger(logger)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
