from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd

from gaia_query_logic import (
    exact_source_recovery,
    ids_sha256,
    select_stratified_pilot,
    validate_distance_chunk,
    validate_source_chunk,
)


def load_module(filename: str, module_name: str):
    path = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    census = load_module("03_build_full_census.py", "stage1_census_module")
    identifier_audit = load_module(
        "02_audit_gaia_identifiers.py", "stage1_identifier_audit_module"
    )
    ingest = load_module("01_ingest_catalogues.py", "stage1_ingest_module")

    assert ingest.APOGEE_COLUMNS["gaia_dr3_source_id"] == (
        "GAIAEDR3_SOURCE_ID",
    )
    identifier_counts = identifier_audit.summarize_ids(
        pd.Series([101, 101, 202, 0, -1, None])
    )
    assert identifier_counts == {
        "rows": 6,
        "positive_rows": 3,
        "missing_or_nonpositive_rows": 3,
        "unique_positive_ids": 2,
        "repeated_positive_rows": 1,
    }

    apogee = pd.DataFrame(
        {
            "survey_row_index": [0, 1, 2],
            "gaia_dr3_source_id": [101, 101, 0],
            "apogee_id": ["A", "A", "B"],
            "aspcapflag": [1, 0, 0],
            "starflag": [0, 0, 0],
            "finite_primary_label_count": [4, 4, 3],
            "snrev": [200.0, 100.0, 80.0],
            "nvisits": [2, 2, 1],
        }
    )
    selected_apogee = census.deduplicate_apogee(apogee)
    assert len(selected_apogee) == 2
    assert int(
        selected_apogee.loc[
            selected_apogee["gaia_dr3_source_id"].eq(101), "survey_row_index"
        ].iloc[0]
    ) == 1

    galah = pd.DataFrame(
        {
            "survey_row_index": [0, 1, 2],
            "gaia_dr3_source_id": [501, 501, 0],
            "sobject_id": [9001, 9002, 9003],
            "flag_sp": [1, 0, 0],
            "finite_primary_label_count": [4, 4, 2],
            "snr_px_ccd3": [200.0, 100.0, 50.0],
        }
    )
    selected_galah = census.deduplicate_galah(galah)
    assert len(selected_galah) == 2
    assert int(
        selected_galah.loc[
            selected_galah["gaia_dr3_source_id"].eq(501), "survey_row_index"
        ].iloc[0]
    ) == 1

    pilot_master = pd.DataFrame(
        {
            "gaia_dr3_source_id": np.arange(1001, 1031, dtype=np.int64),
            "survey_origin": (
                ["APOGEE_only"] * 10
                + ["GALAH_only"] * 10
                + ["overlap"] * 10
            ),
        }
    )
    quotas = {"APOGEE_only": 4, "GALAH_only": 4, "overlap": 2}
    pilot_a, audit_a = select_stratified_pilot(pilot_master, quotas, seed=7)
    pilot_b, audit_b = select_stratified_pilot(pilot_master, quotas, seed=7)
    assert pilot_a.equals(pilot_b)
    assert audit_a == audit_b
    assert len(pilot_a) == 10
    assert not pilot_a["gaia_dr3_source_id"].duplicated().any()
    assert ids_sha256(pilot_a["gaia_dr3_source_id"]) == audit_a["selection_sha256"]

    requested = pilot_a["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
    source = pd.DataFrame({"source_id": requested})
    source_stats = validate_source_chunk(source, requested)
    assert exact_source_recovery(source_stats)
    distance = pd.DataFrame({"source_id": requested[:-2]})
    distance_stats = validate_distance_chunk(distance, requested)
    assert distance_stats["not_in_distance_table"] == 2
    assert distance_stats["unexpected"] == 0
    assert distance_stats["duplicate_rows"] == 0

    print("Stage 1 logic self-test passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
