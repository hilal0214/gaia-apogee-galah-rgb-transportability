from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from stage2c_common import (
    ALPHA3_ELEMENTS,
    ELEMENTS,
    atomic_write_json,
    build_transport_atlas,
    canonical_json_sha256,
    close_logger,
    element_flow_table,
    ids_sha256,
    load_config,
    load_models_and_metrics,
    origin_element_flow_table,
    project_path,
    read_json,
    setup_logger,
    sha256_file,
    support_bounds_table,
    utc_now,
    write_frame,
)


def require_sha(path: Path, expected: str, label: str) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Missing {label}: {path}")
    observed = sha256_file(path)
    if observed != expected:
        raise RuntimeError(f"Frozen {label} changed: {observed} != {expected}")


def survey_columns(survey: str) -> list[str]:
    base = [
        "survey_row_index",
        "gaia_dr3_source_id",
        "ra",
        "dec",
        "teff",
        "teff_err",
        "logg",
        "logg_err",
        "rv",
        "rv_err",
        "broad_red_giant",
        "stellar_parameter_quality",
        "broad_rg_and_quality",
    ]
    if survey == "apogee":
        base.extend(
            ["apogee_id", "snr", "snrev", "starflag", "aspcapflag"]
        )
    elif survey == "galah":
        base.extend(
            ["sobject_id", "snr_px_ccd3", "flag_sp", "flag_sp_fit", "flag_red"]
        )
    else:
        raise ValueError(f"Unknown survey: {survey}")
    for element in ELEMENTS:
        base.extend([element, f"{element}_err", f"valid_{element}"])
    return base


def require_upstream(config: dict[str, Any], root: Path) -> dict[str, Path]:
    stage1_dir = project_path(root, config["paths"]["stage1_output_dir"])
    star_dir = project_path(root, config["paths"]["stage1_star_level_dir"])
    stage2a_dir = project_path(root, config["paths"]["stage2a_output_dir"])
    stage2b_dir = project_path(root, config["paths"]["stage2b_output_dir"])

    s1 = config["stage1_frozen"]
    s2a = config["stage2a_frozen"]
    s2b = config["stage2b_frozen"]
    paths = {
        "master": stage1_dir / s1["source_master_file"],
        "stage1_validation": stage1_dir / s1["validation_file"],
        "census_summary": stage1_dir / s1["census_summary_file"],
        "apogee_star": star_dir / s1["apogee_star_level_file"],
        "galah_star": star_dir / s1["galah_star_level_file"],
        "stage2a_overlap": stage2a_dir / s2a["overlap_file"],
        "stage2a_validation": stage2a_dir / s2a["validation_file"],
        "deploy": stage2b_dir / s2b["deploy_models_file"],
        "coefficients": stage2b_dir / s2b["coefficients_file"],
        "metrics": stage2b_dir / s2b["metrics_file"],
        "stage2b_freeze": stage2b_dir / s2b["freeze_manifest_file"],
        "stage2b_validation": stage2b_dir / s2b["validation_file"],
    }
    require_sha(paths["master"], s1["source_master_sha256"], "Stage 1 source master")
    require_sha(
        paths["stage1_validation"],
        s1["validation_sha256"],
        "Stage 1 validation",
    )
    require_sha(
        paths["census_summary"],
        s1["census_summary_sha256"],
        "Stage 1 census summary",
    )
    require_sha(
        paths["stage2a_overlap"], s2a["overlap_sha256"], "Stage 2A overlap"
    )
    require_sha(
        paths["stage2a_validation"],
        s2a["validation_sha256"],
        "Stage 2A validation",
    )
    for key, sha_key, label in (
        ("deploy", "deploy_models_sha256", "Stage 2B deploy models"),
        ("coefficients", "coefficients_sha256", "Stage 2B coefficients"),
        ("metrics", "metrics_sha256", "Stage 2B metrics"),
        ("stage2b_freeze", "freeze_manifest_sha256", "Stage 2B freeze manifest"),
        ("stage2b_validation", "validation_sha256", "Stage 2B validation"),
    ):
        require_sha(paths[key], s2b[sha_key], label)
    for key in ("apogee_star", "galah_star"):
        if not paths[key].exists():
            raise FileNotFoundError(
                f"Missing {paths[key]}. Preserve the original Stage 1 interim star-level tables; "
                "do not rerun Gaia."
            )

    stage1_validation = read_json(paths["stage1_validation"])
    stage2a_validation = read_json(paths["stage2a_validation"])
    stage2b_validation = read_json(paths["stage2b_validation"])
    if not stage1_validation.get("overall_passed", False):
        raise RuntimeError("Frozen Stage 1 validation is not PASS")
    if not stage2a_validation.get("overall_passed", False):
        raise RuntimeError("Frozen Stage 2A validation is not PASS")
    if not stage2b_validation.get("overall_passed", False):
        raise RuntimeError("Frozen Stage 2B validation is not PASS")
    expected_gates = int(s2b["required_passed_gates"])
    if int(stage2b_validation.get("n_passed", -1)) != expected_gates:
        raise RuntimeError("Frozen Stage 2B passed-gate count changed")
    return paths


def validate_input_identity(
    config: dict[str, Any],
    master: pd.DataFrame,
    apogee: pd.DataFrame,
    galah: pd.DataFrame,
) -> dict[str, Any]:
    expected = config["stage1_frozen"]["expected_counts"]
    if len(master) != int(expected["source_master"]):
        raise RuntimeError(f"Source master rows changed: {len(master)}")
    ids = master["gaia_dr3_source_id"].to_numpy(dtype=np.int64)
    if not np.all(ids > 0) or not np.all(np.diff(ids) > 0):
        raise RuntimeError("Source master IDs are not positive and strictly increasing")
    if len(apogee) != int(expected["apogee_star_level"]):
        raise RuntimeError(f"APOGEE star-level rows changed: {len(apogee)}")
    if len(galah) != int(expected["galah_star_level"]):
        raise RuntimeError(f"GALAH star-level rows changed: {len(galah)}")

    apogee_ids = np.sort(
        pd.to_numeric(apogee["gaia_dr3_source_id"], errors="coerce")
        .fillna(0)
        .astype("int64")
        .loc[lambda value: value.gt(0)]
        .to_numpy()
    )
    galah_ids = np.sort(
        pd.to_numeric(galah["gaia_dr3_source_id"], errors="coerce")
        .fillna(0)
        .astype("int64")
        .loc[lambda value: value.gt(0)]
        .to_numpy()
    )
    if len(apogee_ids) != int(expected["apogee_positive_ids"]):
        raise RuntimeError("APOGEE positive-ID count changed")
    if len(galah_ids) != int(expected["galah_positive_ids"]):
        raise RuntimeError("GALAH positive-ID count changed")
    if len(np.unique(apogee_ids)) != len(apogee_ids):
        raise RuntimeError("APOGEE star-level positive IDs are not unique")
    if len(np.unique(galah_ids)) != len(galah_ids):
        raise RuntimeError("GALAH star-level positive IDs are not unique")
    expected_apogee = master.loc[master["has_apogee"].astype(bool), "gaia_dr3_source_id"].to_numpy(dtype=np.int64)
    expected_galah = master.loc[master["has_galah"].astype(bool), "gaia_dr3_source_id"].to_numpy(dtype=np.int64)
    if not np.array_equal(apogee_ids, expected_apogee):
        raise RuntimeError("APOGEE star-level ID set does not equal source-master membership")
    if not np.array_equal(galah_ids, expected_galah):
        raise RuntimeError("GALAH star-level ID set does not equal source-master membership")
    origins = master["survey_origin"].value_counts().to_dict()
    for origin in ("APOGEE_only", "GALAH_only", "overlap"):
        if int(origins.get(origin, 0)) != int(expected[origin]):
            raise RuntimeError(f"Source-master {origin} count changed")
    return {
        "source_master_rows": int(len(master)),
        "source_id_sha256": ids_sha256(ids),
        "apogee_star_rows": int(len(apogee)),
        "galah_star_rows": int(len(galah)),
        "apogee_positive_ids": int(len(apogee_ids)),
        "galah_positive_ids": int(len(galah_ids)),
        "origin_counts": {key: int(value) for key, value in origins.items()},
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Apply frozen Stage 2B abundance transport to the full spectroscopic census"
    )
    parser.add_argument("--config", default="config/stage2c.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    output_dir = project_path(root, config["paths"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    log_dir = project_path(root, config["paths"]["log_dir"])
    logger = setup_logger(log_dir / "13_run_stage2c.log", "stage2c.run")
    logger.info("Starting Stage 2C protocol v%s", config["project"]["version"])

    paths = require_upstream(config, root)
    master = pd.read_parquet(paths["master"])
    apogee = pd.read_parquet(paths["apogee_star"], columns=survey_columns("apogee"))
    galah = pd.read_parquet(paths["galah_star"], columns=survey_columns("galah"))
    input_identity = validate_input_identity(config, master, apogee, galah)
    logger.info(
        "Accepted frozen source master: %s rows; APOGEE IDs=%s; GALAH IDs=%s",
        f"{len(master):,}",
        f"{input_identity['apogee_positive_ids']:,}",
        f"{input_identity['galah_positive_ids']:,}",
    )

    coordinate_columns = [
        "gaia_dr3_source_id",
        "coordinate_status",
        "coordinate_hard_mismatch",
        "coordinate_primary_ok",
        "coordinate_sensitivity_ok",
    ]
    coordinates = pd.read_parquet(paths["stage2a_overlap"], columns=coordinate_columns)
    expected_overlap = int(config["stage2a_frozen"]["expected_overlap_rows"])
    if len(coordinates) != expected_overlap:
        raise RuntimeError(f"Stage 2A coordinate rows changed: {len(coordinates)}")
    hard = int(coordinates["coordinate_hard_mismatch"].sum())
    expected_hard = int(
        config["stage2a_frozen"]["expected_hard_coordinate_mismatches"]
    )
    if hard != expected_hard:
        raise RuntimeError(f"Stage 2A hard-coordinate count changed: {hard}")

    deploy, coefficients, metrics = load_models_and_metrics(
        paths["deploy"], paths["coefficients"], paths["metrics"]
    )
    if deploy.get("model_spec_sha256") != config["stage2b_frozen"]["model_spec_sha256"]:
        raise RuntimeError("Stage 2B model specification hash changed")
    elements = tuple(str(value) for value in config["transport"]["elements"])
    if elements != ELEMENTS:
        raise RuntimeError(f"Stage 2C element freeze changed: {elements}")
    alpha_elements = tuple(str(value) for value in config["alpha3"]["elements"])
    if alpha_elements != ALPHA3_ELEMENTS:
        raise RuntimeError(f"Stage 2C alpha3 freeze changed: {alpha_elements}")

    atlas = build_transport_atlas(
        master, apogee, galah, coordinates, deploy, coefficients, metrics
    )
    atlas_path = output_dir / config["outputs"]["atlas_file"]
    write_frame(atlas, atlas_path)
    logger.info("Wrote transport atlas: %s rows, %s columns", f"{len(atlas):,}", len(atlas.columns))

    element_flow = element_flow_table(atlas)
    origin_flow = origin_element_flow_table(atlas)
    support_bounds = support_bounds_table(deploy)
    element_flow_path = output_dir / config["outputs"]["element_flow_file"]
    origin_flow_path = output_dir / config["outputs"]["origin_element_flow_file"]
    bounds_path = output_dir / config["outputs"]["support_bounds_file"]
    write_frame(element_flow, element_flow_path)
    write_frame(origin_flow, origin_flow_path)
    write_frame(support_bounds, bounds_path)

    transport_spec = {
        "model_spec_sha256": deploy["model_spec_sha256"],
        "transport": config["transport"],
        "alpha3": config["alpha3"],
        "elements": list(ELEMENTS),
    }
    transport_spec_sha256 = canonical_json_sha256(transport_spec)
    output_hashes = {
        atlas_path.name: sha256_file(atlas_path),
        element_flow_path.name: sha256_file(element_flow_path),
        origin_flow_path.name: sha256_file(origin_flow_path),
        bounds_path.name: sha256_file(bounds_path),
    }
    input_hashes = {
        "source_master": sha256_file(paths["master"]),
        "apogee_star_level": sha256_file(paths["apogee_star"]),
        "galah_star_level": sha256_file(paths["galah_star"]),
        "stage2a_overlap": sha256_file(paths["stage2a_overlap"]),
        "stage2b_deploy_models": sha256_file(paths["deploy"]),
        "stage2b_coefficients": sha256_file(paths["coefficients"]),
        "stage2b_metrics": sha256_file(paths["metrics"]),
    }
    summary = {
        "stage": "2C full-census spectroscopic abundance transport",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "transport_spec_sha256": transport_spec_sha256,
        "upstream": {
            "stage1_release_sha256": config["stage1_frozen"]["release_sha256"],
            "stage2a_release_sha256": config["stage2a_frozen"]["release_sha256"],
            "stage2b_release_sha256": config["stage2b_frozen"]["release_sha256"],
            "stage2b_model_spec_sha256": deploy["model_spec_sha256"],
        },
        "input_identity": input_identity,
        "input_sha256": input_hashes,
        "counts": {
            "atlas_rows": int(len(atlas)),
            "atlas_columns": int(len(atlas.columns)),
            "spectroscopic_rgb_quality_any": int(
                atlas["spectroscopic_rgb_quality_any"].sum()
            ),
            "spectroscopic_primary_ok": int(atlas["spectroscopic_primary_ok"].sum()),
            "spectroscopic_sensitivity_ok": int(
                atlas["spectroscopic_sensitivity_ok"].sum()
            ),
            "alpha3_primary_ok": int(atlas["alpha3_primary_ok"].sum()),
            "alpha3_core_ok": int(atlas["alpha3_core_ok"].sum()),
            "alpha3_sensitivity_ok": int(atlas["alpha3_sensitivity_ok"].sum()),
            "hard_coordinate_mismatches": hard,
        },
        "element_flow": element_flow.to_dict(orient="records"),
        "output_sha256": output_hashes,
        "science_boundary": config["science_boundary"],
        "important_interpretation": (
            "Cross-survey sigma_MAD and fold-model dispersion are stored as an "
            "empirical transport-error proxy; they are not used as inverse-variance weights."
        ),
    }
    summary_path = output_dir / config["outputs"]["build_summary_file"]
    atomic_write_json(summary, summary_path)
    output_hashes[summary_path.name] = sha256_file(summary_path)

    freeze = {
        "stage": "2C spectroscopic transport freeze",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "transport_spec_sha256": transport_spec_sha256,
        "source_id_sha256": input_identity["source_id_sha256"],
        "input_sha256": input_hashes,
        "output_sha256": output_hashes,
        "science_boundary": config["science_boundary"],
    }
    freeze_path = output_dir / config["outputs"]["freeze_manifest_file"]
    atomic_write_json(freeze, freeze_path)
    logger.info(
        "Stage 2C build complete: alpha3 primary=%s; no Gaia clean gate, gradient, or population fit",
        f"{int(atlas['alpha3_primary_ok'].sum()):,}",
    )
    close_logger(logger)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)

