from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from stage4b_common import (
    COHORTS,
    GLOBAL_PARAMETERS,
    INTERACTION_DERIVED_PARAMETERS,
    LABELS,
    atomic_write_json,
    close_logger,
    cluster_inference,
    cohort_mask,
    convergence_record,
    coordinate_features,
    diagnostic_record,
    fit_huber,
    flag,
    ids_sha256,
    influence_records,
    interaction_features,
    interaction_transform,
    label_error_column,
    label_source_column,
    label_value_column,
    load_config,
    number,
    ordered_frame,
    project_path,
    read_json,
    selected_input_columns,
    setup_logger,
    sha256_file,
    stable_seed,
    summarize_draws,
    summary_fields,
    utc_now,
    validation_report,
)


def add_gate(
    gates: list[dict[str, Any]],
    name: str,
    passed: bool,
    observed: Any,
    expected: Any,
    detail: str,
) -> None:
    gates.append(
        {
            "name": name,
            "passed": bool(passed),
            "observed": observed,
            "expected": expected,
            "detail": detail,
        }
    )


def frame_equal(left: pd.DataFrame, right: pd.DataFrame, tolerance: float) -> bool:
    if left.shape != right.shape or list(left.columns) != list(right.columns):
        return False
    for column in left.columns:
        if pd.api.types.is_numeric_dtype(left[column]) and pd.api.types.is_numeric_dtype(
            right[column]
        ):
            if not np.allclose(
                pd.to_numeric(left[column], errors="coerce").to_numpy(float),
                pd.to_numeric(right[column], errors="coerce").to_numpy(float),
                rtol=0.0,
                atol=tolerance,
                equal_nan=True,
            ):
                return False
        else:
            left_values = left[column].astype("string").fillna("<NA>").to_numpy(dtype=str)
            right_values = right[column].astype("string").fillna("<NA>").to_numpy(dtype=str)
            if not np.array_equal(left_values, right_values):
                return False
    return True


def resolve_paths(config: dict[str, Any], root: Path) -> dict[str, Path]:
    stage4a = project_path(root, config["paths"]["stage4a_output_dir"])
    output = project_path(root, config["paths"]["output_dir"])
    frozen = config["stage4a_frozen"]
    outputs = config["outputs"]
    return {
        "design_layer": stage4a / frozen["design_layer_file"],
        "design_definition": stage4a / frozen["design_definition_file"],
        "cohort_flow": stage4a / frozen["cohort_flow_file"],
        "stage4a_summary": stage4a / frozen["build_summary_file"],
        "stage4a_freeze": stage4a / frozen["freeze_manifest_file"],
        "stage4a_validation": stage4a / frozen["validation_file"],
        "stage4a_report": stage4a / frozen["validation_report_file"],
        "stage4a_package": stage4a / frozen["package_manifest_file"],
        **{
            key.removesuffix("_file"): output / value
            for key, value in outputs.items()
            if key.endswith("_file")
        },
    }


def expected_input_hashes(config: Mapping[str, Any]) -> dict[str, str]:
    frozen = config["stage4a_frozen"]
    return {
        "design_layer": frozen["design_layer_sha256"],
        "design_definition": frozen["design_definition_sha256"],
        "cohort_flow": frozen["cohort_flow_sha256"],
        "stage4a_summary": frozen["build_summary_sha256"],
        "stage4a_freeze": frozen["freeze_manifest_sha256"],
        "stage4a_validation": frozen["validation_sha256"],
        "stage4a_report": frozen["validation_report_sha256"],
        "stage4a_package": frozen["package_manifest_sha256"],
    }


def claim_frame_from_tables(
    global_frame: pd.DataFrame,
    sensitivity_frame: pd.DataFrame,
    transport_frame: pd.DataFrame,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for label in LABELS:
        global_row = global_frame.loc[global_frame["label"] == label].iloc[0]
        ladder = sensitivity_frame.loc[sensitivity_frame["label"] == label]
        transport = transport_frame.loc[transport_frame["label"] == label].set_index(
            "parameter"
        )
        rows.append(
            {
                "label": label,
                "global_radial_point": float(global_row["beta_R"]),
                "global_radial_q025": float(global_row["beta_R_q025"]),
                "global_radial_q975": float(global_row["beta_R_q975"]),
                "global_radial_sign_stability": float(global_row["beta_R_sign_stability"]),
                "global_radial_interval95_excludes_zero": bool(
                    global_row["beta_R_interval95_excludes_zero"]
                ),
                "global_vertical_point": float(global_row["beta_Z"]),
                "global_vertical_q025": float(global_row["beta_Z_q025"]),
                "global_vertical_q975": float(global_row["beta_Z_q975"]),
                "global_vertical_sign_stability": float(global_row["beta_Z_sign_stability"]),
                "global_vertical_interval95_excludes_zero": bool(
                    global_row["beta_Z_interval95_excludes_zero"]
                ),
                "all_predefined_radial_signs_agree": bool(
                    ladder["radial_sign_agrees_with_primary"].all()
                ),
                "all_predefined_vertical_signs_agree": bool(
                    ladder["vertical_sign_agrees_with_primary"].all()
                ),
                "maximum_abs_radial_sensitivity_shift_over_nominal_se": float(
                    ladder["delta_beta_R_over_primary_cluster_se"].abs().max()
                ),
                "maximum_abs_vertical_sensitivity_shift_over_nominal_se": float(
                    ladder["delta_beta_Z_over_primary_cluster_se"].abs().max()
                ),
                "common_support_delta_beta_R": float(transport.loc["DELTA_BETA_R", "point"]),
                "common_support_delta_beta_R_q025": float(
                    transport.loc["DELTA_BETA_R", "q025"]
                ),
                "common_support_delta_beta_R_q975": float(
                    transport.loc["DELTA_BETA_R", "q975"]
                ),
                "common_support_radial_survey_contrast_detected_95": bool(
                    transport.loc["DELTA_BETA_R", "interval95_excludes_zero"]
                ),
                "common_support_delta_beta_Z": float(transport.loc["DELTA_BETA_Z", "point"]),
                "common_support_delta_beta_Z_q025": float(
                    transport.loc["DELTA_BETA_Z", "q025"]
                ),
                "common_support_delta_beta_Z_q975": float(
                    transport.loc["DELTA_BETA_Z", "q975"]
                ),
                "common_support_vertical_survey_contrast_detected_95": bool(
                    transport.loc["DELTA_BETA_Z", "interval95_excludes_zero"]
                ),
                "selection_corrected": False,
                "claim_scope": "frozen_cross_survey_RGB_analysis_sample_only",
            }
        )
    return ordered_frame(pd.DataFrame(rows), [("label", LABELS)])


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Stage 4B gradient inference")
    parser.add_argument("--config", default="config/stage4b.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    paths = resolve_paths(config, root)
    logger = setup_logger(
        project_path(root, config["paths"]["log_dir"]) / "29_validate_stage4b.log",
        "stage4b.validate",
    )
    try:
        required_keys = [
            *expected_input_hashes(config).keys(),
            "global_estimates",
            "sensitivity_ladder",
            "transportability",
            "bootstrap_draws",
            "model_diagnostics",
            "bootstrap_convergence",
            "influence_audit",
            "claim_ledger",
            "method_definition",
            "build_summary",
            "freeze_manifest",
        ]
        missing = [str(paths[key]) for key in required_keys if not paths[key].is_file()]
        if missing:
            raise FileNotFoundError("Missing Stage 4B validation input: " + "; ".join(missing))
        tolerance = float(config["validation"]["numeric_absolute_tolerance"])
        gates: list[dict[str, Any]] = []

        expected_hashes = expected_input_hashes(config)
        observed_hashes = {key: sha256_file(paths[key]) for key in expected_hashes}
        add_gate(
            gates,
            "upstream_byte_identity",
            observed_hashes == expected_hashes,
            observed_hashes,
            expected_hashes,
            "all accepted Stage 4A design and provenance files are byte-identical",
        )

        stage4a_validation = read_json(paths["stage4a_validation"])
        expected_stage4a_gates = int(config["stage4a_frozen"]["expected_validation_gates"])
        upstream_observed = {
            key: stage4a_validation.get(key)
            for key in ("overall_passed", "n_passed", "n_gates", "protocol_version")
        }
        upstream_expected = {
            "overall_passed": True,
            "n_passed": expected_stage4a_gates,
            "n_gates": expected_stage4a_gates,
            "protocol_version": "0.8.1",
        }
        add_gate(
            gates,
            "upstream_validation",
            upstream_observed == upstream_expected,
            upstream_observed,
            upstream_expected,
            "corrected Stage 4A remains frozen 19/19 PASS",
        )

        metadata = pq.ParquetFile(paths["design_layer"]).metadata
        logger.info("Reading Stage 4A design columns and Stage 4B outputs")
        layer = pq.read_table(
            paths["design_layer"], columns=selected_input_columns(config)
        ).to_pandas()
        ids = pd.to_numeric(layer["gaia_dr3_source_id"], errors="raise").to_numpy(np.int64)
        input_observed = {
            "rows": int(metadata.num_rows),
            "columns": int(metadata.num_columns),
            "candidate_sha256": ids_sha256(ids),
            "unique": int(len(np.unique(ids))),
            "strictly_sorted": bool(np.all(ids[1:] > ids[:-1])),
            "positive": bool(np.all(ids > 0)),
        }
        input_expected = {
            "rows": int(config["stage4a_frozen"]["expected_rows"]),
            "columns": int(config["stage4a_frozen"]["expected_columns"]),
            "candidate_sha256": str(
                config["stage4a_frozen"]["expected_candidate_id_sha256"]
            ),
            "unique": int(config["stage4a_frozen"]["expected_rows"]),
            "strictly_sorted": True,
            "positive": True,
        }
        add_gate(
            gates,
            "frozen_input_identity_and_schema",
            input_observed == input_expected,
            input_observed,
            input_expected,
            "the 393,834-row Stage 4A design layer retains its exact candidate vector and schema",
        )

        stored_global = pd.read_csv(paths["global_estimates"])
        stored_sensitivity = pd.read_csv(paths["sensitivity_ladder"])
        stored_transport = pd.read_csv(paths["transportability"])
        stored_draws = pq.read_table(paths["bootstrap_draws"]).to_pandas()
        stored_diagnostics = pd.read_csv(paths["model_diagnostics"])
        stored_convergence = pd.read_csv(paths["bootstrap_convergence"])
        stored_influence = pd.read_csv(paths["influence_audit"])
        stored_claims = pd.read_csv(paths["claim_ledger"])
        definition = read_json(paths["method_definition"])
        build_summary = read_json(paths["build_summary"])
        freeze = read_json(paths["freeze_manifest"])
        expected_shapes = {
            "global": [6, 43],
            "sensitivity": [36, 18],
            "transport": [54, 21],
            "draws": [49152, 12],
            "diagnostics": [42, 16],
            "convergence": [72, 15],
            "influence": [360, 8],
            "claims": [6, 25],
        }
        observed_shapes = {
            "global": list(stored_global.shape),
            "sensitivity": list(stored_sensitivity.shape),
            "transport": list(stored_transport.shape),
            "draws": list(stored_draws.shape),
            "diagnostics": list(stored_diagnostics.shape),
            "convergence": list(stored_convergence.shape),
            "influence": list(stored_influence.shape),
            "claims": list(stored_claims.shape),
        }
        duplicate_columns = sum(
            int(frame.columns.duplicated().sum())
            for frame in (
                stored_global,
                stored_sensitivity,
                stored_transport,
                stored_draws,
                stored_diagnostics,
                stored_convergence,
                stored_influence,
                stored_claims,
            )
        )
        add_gate(
            gates,
            "output_shapes_and_schemas",
            observed_shapes == expected_shapes and duplicate_columns == 0,
            {"shapes": observed_shapes, "duplicate_columns": duplicate_columns},
            {"shapes": expected_shapes, "duplicate_columns": 0},
            "all Stage 4B science tables have the frozen row/column shapes without duplicate fields",
        )

        model = config["analysis_contract"]["nominal_model"]
        resampling = config["analysis_contract"]["spatial_resampling"]
        interaction_policy = config["analysis_contract"]["survey_interaction"]
        radial_pivot = float(model["radial_pivot_kpc"])
        fit_kwargs = {
            "tuning_constant": float(model["huber_tuning_constant"]),
            "relative_tolerance": float(model["convergence_relative_tolerance"]),
            "maximum_iterations": int(model["maximum_iterations"]),
            "minimum_scale": float(model["minimum_scale"]),
        }
        full_draws = int(resampling["full_draws"])
        convergence_draws = int(resampling["convergence_draws"])
        quantiles = tuple(float(value) for value in resampling["confidence_quantiles"])
        namespace = str(resampling["random_seed_namespace"])
        finite_correction = bool(resampling["finite_cluster_correction"])
        top_blocks = int(config["analysis_contract"]["influence_audit"]["top_blocks_per_parameter"])
        blocks_all = pd.to_numeric(layer["gaia_healpix5"], errors="raise").to_numpy(np.int64)
        coordinate_lookup = {
            str(row["name"]): str(row["coordinate_estimator"])
            for row in config["analysis_contract"]["sensitivity_ladder"]
        }

        expected_global_rows: list[dict[str, Any]] = []
        expected_sensitivity_rows: list[dict[str, Any]] = []
        expected_transport_rows: list[dict[str, Any]] = []
        expected_draw_frames: list[pd.DataFrame] = []
        expected_diagnostic_rows: list[dict[str, Any]] = []
        expected_convergence_rows: list[dict[str, Any]] = []
        expected_influence_rows: list[dict[str, Any]] = []
        availability_violations = 0
        coordinate_contract_violations = 0
        source_contract_violations = 0
        core_inference: dict[tuple[str, str], Any] = {}
        core_fit: dict[tuple[str, str], Any] = {}

        for label in LABELS:
            response_all = number(layer, label_value_column(label))
            error_all = number(layer, label_error_column(label))
            nominal_beta: np.ndarray | None = None
            nominal_se: np.ndarray | None = None
            label_sensitivity: list[dict[str, Any]] = []
            for cohort in COHORTS:
                mask = cohort_mask(layer, label, cohort, config)
                availability_violations += int(
                    np.sum(mask & (~np.isfinite(response_all) | ~np.isfinite(error_all) | (error_all < 0.0)))
                )
                features = coordinate_features(layer, mask, cohort, radial_pivot)
                if cohort == "GEO_PAIRED":
                    nominal_features = np.column_stack(
                        [
                            number(layer, "r_cyl_gc_kpc")[mask] - radial_pivot,
                            number(layer, "abs_z_gc_kpc")[mask],
                        ]
                    )
                    coordinate_contract_violations += int(np.array_equal(features, nominal_features))
                response = response_all[mask]
                blocks = blocks_all[mask]
                fit = fit_huber(features, response, **fit_kwargs)
                model_id = f"GLOBAL_{cohort}"
                inference = cluster_inference(
                    features,
                    response,
                    blocks,
                    fit,
                    n_draws=full_draws if cohort == "PRIMARY" else 0,
                    seed=stable_seed(namespace, f"{label}|{model_id}"),
                    finite_cluster_correction=finite_correction,
                )
                core_fit[(label, model_id)] = fit
                core_inference[(label, model_id)] = inference
                expected_diagnostic_rows.append(
                    diagnostic_record(
                        label=label,
                        model_id=model_id,
                        cohort=cohort,
                        coordinate_estimator=coordinate_lookup[cohort],
                        rows=len(response),
                        blocks=len(inference.block_ids),
                        parameters=len(fit.beta),
                        fit=fit,
                        inference=inference,
                    )
                )
                record = {
                    "label": label,
                    "model_id": model_id,
                    "cohort": cohort,
                    "coordinate_estimator": coordinate_lookup[cohort],
                    "rows": int(len(response)),
                    "spatial_blocks": int(len(inference.block_ids)),
                    "beta_intercept": float(fit.beta[0]),
                    "beta_R": float(fit.beta[1]),
                    "beta_Z": float(fit.beta[2]),
                    "beta_intercept_cluster_se": float(inference.standard_errors[0]),
                    "beta_R_cluster_se": float(inference.standard_errors[1]),
                    "beta_Z_cluster_se": float(inference.standard_errors[2]),
                }
                label_sensitivity.append(record)
                if cohort == "PRIMARY":
                    if inference.draws is None:
                        raise RuntimeError("Validator failed to reconstruct nominal draws")
                    nominal_beta = fit.beta.copy()
                    nominal_se = inference.standard_errors.copy()
                    summaries = [
                        summarize_draws(
                            fit.beta[index],
                            inference.standard_errors[index],
                            inference.draws[:, index],
                            quantiles,
                        )
                        for index in range(3)
                    ]
                    global_row: dict[str, Any] = {
                        "label": label,
                        "model_id": model_id,
                        "rows": int(len(response)),
                        "spatial_blocks": int(len(inference.block_ids)),
                        "radial_pivot_kpc": radial_pivot,
                        "residual_mad": float(fit.residual_mad),
                        "huber_scale": float(fit.scale),
                        "downweight_fraction": float(fit.downweight_fraction),
                        "iterations": int(fit.iterations),
                        "converged": bool(fit.converged),
                    }
                    for prefix, summary in zip(
                        ("beta_intercept", "beta_R", "beta_Z"), summaries, strict=True
                    ):
                        global_row.update(summary_fields(prefix, summary))
                    expected_global_rows.append(global_row)
                    expected_draw_frames.append(
                        pd.DataFrame(
                            {
                                "label": label,
                                "model_id": model_id,
                                "draw_id": np.arange(full_draws, dtype=np.int32),
                                "beta_intercept": inference.draws[:, 0],
                                "beta_R": inference.draws[:, 1],
                                "beta_Z": inference.draws[:, 2],
                                "delta_intercept": np.nan,
                                "delta_beta_R": np.nan,
                                "delta_beta_Z": np.nan,
                                "galah_intercept": np.nan,
                                "galah_beta_R": np.nan,
                                "galah_beta_Z": np.nan,
                            }
                        )
                    )
                    for index, parameter in enumerate(GLOBAL_PARAMETERS):
                        expected_convergence_rows.append(
                            convergence_record(
                                label=label,
                                model_id=model_id,
                                parameter=parameter,
                                draws=inference.draws[:, index],
                                convergence_draws=convergence_draws,
                            )
                        )
                    expected_influence_rows.extend(
                        influence_records(
                            label=label,
                            model_id=model_id,
                            parameter_names=GLOBAL_PARAMETERS,
                            transform=np.eye(3),
                            inference=inference,
                            standard_errors=inference.standard_errors,
                            top_blocks=top_blocks,
                        )
                    )
            if nominal_beta is None or nominal_se is None:
                raise RuntimeError(f"Validator has no nominal fit for {label}")
            for record in label_sensitivity:
                record["delta_beta_R_from_primary"] = float(record["beta_R"] - nominal_beta[1])
                record["delta_beta_Z_from_primary"] = float(record["beta_Z"] - nominal_beta[2])
                record["delta_beta_R_over_primary_cluster_se"] = float(
                    (record["beta_R"] - nominal_beta[1]) / max(nominal_se[1], 1.0e-15)
                )
                record["delta_beta_Z_over_primary_cluster_se"] = float(
                    (record["beta_Z"] - nominal_beta[2]) / max(nominal_se[2], 1.0e-15)
                )
                record["radial_sign_agrees_with_primary"] = bool(
                    np.sign(record["beta_R"]) == np.sign(nominal_beta[1])
                )
                record["vertical_sign_agrees_with_primary"] = bool(
                    np.sign(record["beta_Z"]) == np.sign(nominal_beta[2])
                )
                expected_sensitivity_rows.append(record)

            common = cohort_mask(layer, label, "COMMON_SUPPORT", config)
            sources_all = (
                layer[label_source_column(label)]
                .astype("string")
                .fillna("NOT_AVAILABLE")
                .to_numpy(dtype=str)
            )
            reference = str(interaction_policy["reference_group"])
            comparison = str(interaction_policy["comparison_group"])
            accepted = np.isin(sources_all, [reference, comparison])
            interaction_mask = common & accepted
            interaction_x, interaction_sources = interaction_features(
                layer, interaction_mask, label, radial_pivot, comparison
            )
            source_contract_violations += int(
                np.sum(~np.isin(interaction_sources, [reference, comparison]))
            )
            interaction_y = response_all[interaction_mask]
            interaction_blocks = blocks_all[interaction_mask]
            interaction_fit = fit_huber(interaction_x, interaction_y, **fit_kwargs)
            interaction_model_id = "COMMON_SUPPORT_SURVEY_INTERACTION"
            interaction_inference_result = cluster_inference(
                interaction_x,
                interaction_y,
                interaction_blocks,
                interaction_fit,
                n_draws=full_draws,
                seed=stable_seed(namespace, f"{label}|{interaction_model_id}"),
                finite_cluster_correction=finite_correction,
            )
            core_fit[(label, interaction_model_id)] = interaction_fit
            core_inference[(label, interaction_model_id)] = interaction_inference_result
            if interaction_inference_result.draws is None:
                raise RuntimeError("Validator failed to reconstruct interaction draws")
            transform = interaction_transform()
            derived_point = transform @ interaction_fit.beta
            derived_covariance = (
                transform @ interaction_inference_result.covariance @ transform.T
            )
            derived_se = np.sqrt(np.maximum(np.diag(derived_covariance), 0.0))
            derived_draws = interaction_inference_result.draws @ transform.T
            reference_rows = int(np.sum(interaction_sources == reference))
            comparison_rows = int(np.sum(interaction_sources == comparison))
            excluded_rows = int(np.sum(common & ~accepted))
            for index, parameter in enumerate(INTERACTION_DERIVED_PARAMETERS):
                summary = summarize_draws(
                    derived_point[index], derived_se[index], derived_draws[:, index], quantiles
                )
                expected_transport_rows.append(
                    {
                        "label": label,
                        "model_id": interaction_model_id,
                        "parameter": parameter,
                        "rows": int(len(interaction_y)),
                        "spatial_blocks": int(len(interaction_inference_result.block_ids)),
                        "reference_group": reference,
                        "reference_rows": reference_rows,
                        "comparison_group": comparison,
                        "comparison_rows": comparison_rows,
                        "excluded_common_support_rows": excluded_rows,
                        **summary,
                    }
                )
                expected_convergence_rows.append(
                    convergence_record(
                        label=label,
                        model_id=interaction_model_id,
                        parameter=parameter,
                        draws=derived_draws[:, index],
                        convergence_draws=convergence_draws,
                    )
                )
            expected_diagnostic_rows.append(
                diagnostic_record(
                    label=label,
                    model_id=interaction_model_id,
                    cohort="COMMON_SUPPORT",
                    coordinate_estimator="PHOTOGEOMETRIC_NOMINAL",
                    rows=len(interaction_y),
                    blocks=len(interaction_inference_result.block_ids),
                    parameters=len(interaction_fit.beta),
                    fit=interaction_fit,
                    inference=interaction_inference_result,
                )
            )
            expected_influence_rows.extend(
                influence_records(
                    label=label,
                    model_id=interaction_model_id,
                    parameter_names=INTERACTION_DERIVED_PARAMETERS,
                    transform=transform,
                    inference=interaction_inference_result,
                    standard_errors=derived_se,
                    top_blocks=top_blocks,
                )
            )
            expected_draw_frames.append(
                pd.DataFrame(
                    {
                        "label": label,
                        "model_id": interaction_model_id,
                        "draw_id": np.arange(full_draws, dtype=np.int32),
                        "beta_intercept": interaction_inference_result.draws[:, 0],
                        "beta_R": interaction_inference_result.draws[:, 1],
                        "beta_Z": interaction_inference_result.draws[:, 2],
                        "delta_intercept": interaction_inference_result.draws[:, 3],
                        "delta_beta_R": interaction_inference_result.draws[:, 4],
                        "delta_beta_Z": interaction_inference_result.draws[:, 5],
                        "galah_intercept": derived_draws[:, 3],
                        "galah_beta_R": derived_draws[:, 4],
                        "galah_beta_Z": derived_draws[:, 5],
                    }
                )
            )

        expected_global = ordered_frame(pd.DataFrame(expected_global_rows), [("label", LABELS)])
        expected_sensitivity = ordered_frame(
            pd.DataFrame(expected_sensitivity_rows), [("label", LABELS), ("cohort", COHORTS)]
        )
        expected_transport = ordered_frame(
            pd.DataFrame(expected_transport_rows),
            [("label", LABELS), ("parameter", INTERACTION_DERIVED_PARAMETERS)],
        )
        expected_draws = ordered_frame(
            pd.concat(expected_draw_frames, ignore_index=True),
            [
                ("label", LABELS),
                ("model_id", ("GLOBAL_PRIMARY", "COMMON_SUPPORT_SURVEY_INTERACTION")),
            ],
        )
        expected_diagnostics = ordered_frame(
            pd.DataFrame(expected_diagnostic_rows),
            [
                ("label", LABELS),
                (
                    "model_id",
                    tuple([f"GLOBAL_{cohort}" for cohort in COHORTS])
                    + ("COMMON_SUPPORT_SURVEY_INTERACTION",),
                ),
            ],
        )
        expected_convergence = ordered_frame(
            pd.DataFrame(expected_convergence_rows),
            [
                ("label", LABELS),
                ("model_id", ("GLOBAL_PRIMARY", "COMMON_SUPPORT_SURVEY_INTERACTION")),
            ],
        )
        expected_influence = ordered_frame(
            pd.DataFrame(expected_influence_rows),
            [
                ("label", LABELS),
                ("model_id", ("GLOBAL_PRIMARY", "COMMON_SUPPORT_SURVEY_INTERACTION")),
            ],
        )
        expected_claims = claim_frame_from_tables(
            expected_global, expected_sensitivity, expected_transport
        )

        cohort_counts_exact = bool(
            np.array_equal(stored_sensitivity["rows"].to_numpy(int), expected_sensitivity["rows"].to_numpy(int))
        )
        add_gate(
            gates,
            "cohort_counts_and_outcome_guard",
            cohort_counts_exact and availability_violations == 0,
            {
                "cohort_counts_exact": cohort_counts_exact,
                "availability_violations": availability_violations,
            },
            {"cohort_counts_exact": True, "availability_violations": 0},
            "all 36 prespecified cohorts reproduce Stage 4A counts and retain finite outcomes/errors",
        )

        beta_columns = ["beta_intercept", "beta_R", "beta_Z"]
        sensitivity_beta_exact = frame_equal(
            stored_sensitivity[["label", "model_id", *beta_columns]],
            expected_sensitivity[["label", "model_id", *beta_columns]],
            tolerance,
        )
        transport_point_exact = frame_equal(
            stored_transport[["label", "model_id", "parameter", "point"]],
            expected_transport[["label", "model_id", "parameter", "point"]],
            tolerance,
        )
        add_gate(
            gates,
            "huber_refit_identity",
            sensitivity_beta_exact and transport_point_exact,
            {
                "sensitivity_beta_exact": sensitivity_beta_exact,
                "interaction_point_exact": transport_point_exact,
            },
            {"sensitivity_beta_exact": True, "interaction_point_exact": True},
            "independent Huber IRLS refits reproduce all global, sensitivity, and interaction coefficients",
        )

        diagnostics_exact = frame_equal(stored_diagnostics, expected_diagnostics, tolerance)
        quality = {
            "all_converged": bool(expected_diagnostics["converged"].all()),
            "all_full_rank": bool(
                (expected_diagnostics["rank"] == expected_diagnostics["parameters"]).all()
            ),
            "maximum_score_per_row": float(
                expected_diagnostics["score_max_abs_per_row"].max()
            ),
            "all_condition_numbers_finite": bool(
                np.isfinite(expected_diagnostics["condition_number_standardized"]).all()
            ),
            "diagnostics_exact": diagnostics_exact,
        }
        quality_passed = (
            quality["all_converged"]
            and quality["all_full_rank"]
            and quality["all_condition_numbers_finite"]
            and quality["maximum_score_per_row"]
            <= float(config["validation"]["score_absolute_tolerance_per_row"])
            and diagnostics_exact
        )
        add_gate(
            gates,
            "model_convergence_rank_and_scores",
            quality_passed,
            quality,
            {
                "all_converged": True,
                "all_full_rank": True,
                "maximum_score_per_row_at_most": float(
                    config["validation"]["score_absolute_tolerance_per_row"]
                ),
                "all_condition_numbers_finite": True,
                "diagnostics_exact": True,
            },
            "all 42 robust fits converge at full rank with negligible estimating-equation residuals",
        )

        coordinate_labels_exact = bool(
            np.array_equal(
                stored_sensitivity["coordinate_estimator"].astype(str).to_numpy(),
                expected_sensitivity["coordinate_estimator"].astype(str).to_numpy(),
            )
        )
        add_gate(
            gates,
            "sensitivity_coordinate_contract",
            coordinate_contract_violations == 0 and coordinate_labels_exact,
            {
                "geo_predictor_identity_violations": coordinate_contract_violations,
                "coordinate_labels_exact": coordinate_labels_exact,
            },
            {"geo_predictor_identity_violations": 0, "coordinate_labels_exact": True},
            "only GEO_PAIRED uses the geometric alternative; every other ladder rung uses nominal coordinates",
        )

        sensitivity_se_columns = [
            "beta_intercept_cluster_se",
            "beta_R_cluster_se",
            "beta_Z_cluster_se",
        ]
        sandwich_exact = frame_equal(
            stored_sensitivity[["label", "model_id", *sensitivity_se_columns]],
            expected_sensitivity[["label", "model_id", *sensitivity_se_columns]],
            tolerance,
        ) and frame_equal(
            stored_transport[
                ["label", "model_id", "parameter", "cluster_standard_error"]
            ],
            expected_transport[
                ["label", "model_id", "parameter", "cluster_standard_error"]
            ],
            tolerance,
        )
        add_gate(
            gates,
            "spatial_cluster_sandwich_identity",
            sandwich_exact,
            {"all_cluster_standard_errors_exact": sandwich_exact},
            {"all_cluster_standard_errors_exact": True},
            "HEALPix-5 cluster scores, bread matrices, finite-cluster corrections, and standard errors reproduce exactly",
        )

        draws_exact = frame_equal(stored_draws, expected_draws, tolerance)
        add_gate(
            gates,
            "bootstrap_draw_identity",
            draws_exact,
            {"rows": int(len(stored_draws)), "exact": draws_exact},
            {"rows": int(len(expected_draws)), "exact": True},
            "all 49,152 seeded antithetic cluster-multiplier draw rows reproduce exactly",
        )

        antithetic_max = 0.0
        for label in LABELS:
            for model_id in ("GLOBAL_PRIMARY", "COMMON_SUPPORT_SURVEY_INTERACTION"):
                selected = stored_draws.loc[
                    (stored_draws["label"] == label) & (stored_draws["model_id"] == model_id)
                ].sort_values("draw_id")
                half = len(selected) // 2
                columns = ["beta_intercept", "beta_R", "beta_Z"]
                if model_id == "COMMON_SUPPORT_SURVEY_INTERACTION":
                    columns += ["delta_intercept", "delta_beta_R", "delta_beta_Z"]
                values = selected[columns].to_numpy(float)
                center = (values[:half] + values[half:]) / 2.0
                antithetic_max = max(
                    antithetic_max,
                    float(np.max(np.abs(center - np.mean(values, axis=0)[None, :]))),
                )
        add_gate(
            gates,
            "antithetic_centering",
            antithetic_max <= tolerance,
            {"maximum_pair_center_difference": antithetic_max},
            {"maximum_pair_center_difference_at_most": tolerance},
            "every Rademacher draw has its exact antithetic partner around the fitted coefficient",
        )

        global_exact = frame_equal(stored_global, expected_global, tolerance)
        add_gate(
            gates,
            "global_gradient_summary_identity",
            global_exact,
            {"rows": int(len(stored_global)), "exact": global_exact},
            {"rows": len(LABELS), "exact": True},
            "nominal points, cluster errors, 68/95-percent intervals, and sign stability reproduce for six labels",
        )

        transport_exact = frame_equal(stored_transport, expected_transport, tolerance)
        add_gate(
            gates,
            "survey_interaction_summary_identity",
            transport_exact,
            {"rows": int(len(stored_transport)), "exact": transport_exact},
            {"rows": len(LABELS) * len(INTERACTION_DERIVED_PARAMETERS), "exact": True},
            "common-support APOGEE, GALAH, and slope-contrast summaries reproduce exactly",
        )

        convergence_exact = frame_equal(stored_convergence, expected_convergence, tolerance)
        maximum_halfwidth_difference = float(
            expected_convergence["relative_halfwidth_difference"].max()
        )
        convergence_limit = float(resampling["maximum_relative_halfwidth_difference"])
        add_gate(
            gates,
            "bootstrap_convergence",
            convergence_exact and maximum_halfwidth_difference <= convergence_limit,
            {
                "rows": int(len(stored_convergence)),
                "exact": convergence_exact,
                "maximum_relative_halfwidth_difference": maximum_halfwidth_difference,
            },
            {
                "rows": int(len(expected_convergence)),
                "exact": True,
                "maximum_relative_halfwidth_difference_at_most": convergence_limit,
            },
            "2,048-to-4,096 draw interval half-widths satisfy the frozen convergence gate",
        )

        algebra_mismatches = 0
        for label in LABELS:
            selected = stored_draws.loc[
                (stored_draws["label"] == label)
                & (stored_draws["model_id"] == "COMMON_SUPPORT_SURVEY_INTERACTION")
            ]
            algebra_mismatches += int(
                np.sum(
                    ~np.isclose(
                        selected["galah_intercept"],
                        selected["beta_intercept"] + selected["delta_intercept"],
                        rtol=0.0,
                        atol=tolerance,
                    )
                )
            )
            algebra_mismatches += int(
                np.sum(
                    ~np.isclose(
                        selected["galah_beta_R"],
                        selected["beta_R"] + selected["delta_beta_R"],
                        rtol=0.0,
                        atol=tolerance,
                    )
                )
            )
            algebra_mismatches += int(
                np.sum(
                    ~np.isclose(
                        selected["galah_beta_Z"],
                        selected["beta_Z"] + selected["delta_beta_Z"],
                        rtol=0.0,
                        atol=tolerance,
                    )
                )
            )
        add_gate(
            gates,
            "common_support_interaction_algebra_and_sources",
            algebra_mismatches == 0 and source_contract_violations == 0,
            {
                "draw_algebra_mismatches": algebra_mismatches,
                "unaccepted_source_rows_in_model": source_contract_violations,
            },
            {"draw_algebra_mismatches": 0, "unaccepted_source_rows_in_model": 0},
            "GALAH slopes equal APOGEE slopes plus frozen contrasts and only the two declared sources enter",
        )

        influence_exact = frame_equal(stored_influence, expected_influence, tolerance)
        add_gate(
            gates,
            "spatial_influence_identity",
            influence_exact,
            {"rows": int(len(stored_influence)), "exact": influence_exact},
            {"rows": int(len(expected_influence)), "exact": True},
            "the five most influential HEALPix-5 blocks per core-model parameter reproduce exactly",
        )

        claims_exact = frame_equal(stored_claims, expected_claims, tolerance)
        add_gate(
            gates,
            "claim_ledger_identity",
            claims_exact,
            {"rows": int(len(stored_claims)), "exact": claims_exact},
            {"rows": len(LABELS), "exact": True},
            "the claim-safe ledger is an exact derivation of nominal, ladder, and survey-contrast outputs",
        )

        finite_checks = {
            "global_numeric": bool(
                np.isfinite(stored_global.select_dtypes(include=[np.number]).to_numpy(float)).all()
            ),
            "sensitivity_numeric": bool(
                np.isfinite(
                    stored_sensitivity.select_dtypes(include=[np.number]).to_numpy(float)
                ).all()
            ),
            "transport_numeric": bool(
                np.isfinite(stored_transport.select_dtypes(include=[np.number]).to_numpy(float)).all()
            ),
            "diagnostic_numeric": bool(
                np.isfinite(
                    stored_diagnostics.select_dtypes(include=[np.number]).to_numpy(float)
                ).all()
            ),
            "influence_numeric": bool(
                np.isfinite(stored_influence.select_dtypes(include=[np.number]).to_numpy(float)).all()
            ),
            "global_quantile_order": bool(
                all(
                    (
                        stored_global[f"{prefix}_q025"]
                        <= stored_global[f"{prefix}_q16"]
                    ).all()
                    and (
                        stored_global[f"{prefix}_q16"]
                        <= stored_global[f"{prefix}_q50"]
                    ).all()
                    and (
                        stored_global[f"{prefix}_q50"]
                        <= stored_global[f"{prefix}_q84"]
                    ).all()
                    and (
                        stored_global[f"{prefix}_q84"]
                        <= stored_global[f"{prefix}_q975"]
                    ).all()
                    for prefix in ("beta_intercept", "beta_R", "beta_Z")
                )
            ),
            "transport_quantile_order": bool(
                (
                    (stored_transport["q025"] <= stored_transport["q16"])
                    & (stored_transport["q16"] <= stored_transport["q50"])
                    & (stored_transport["q50"] <= stored_transport["q84"])
                    & (stored_transport["q84"] <= stored_transport["q975"])
                ).all()
            ),
            "se_draw_consistency": bool(
                max(
                    float(
                        stored_global.filter(like="se_draw_relative_difference").max().max()
                    ),
                    float(stored_transport["standard_error_draw_sd_relative_difference"].max()),
                )
                <= float(resampling["maximum_standard_error_draw_sd_relative_difference"])
            ),
        }
        add_gate(
            gates,
            "numeric_finiteness_and_interval_order",
            all(finite_checks.values()),
            finite_checks,
            {key: True for key in finite_checks},
            "all reported numbers are finite, intervals are ordered, and draw dispersions match sandwich errors",
        )

        science_keys = (
            "global_estimates",
            "sensitivity_ladder",
            "transportability",
            "bootstrap_draws",
            "model_diagnostics",
            "bootstrap_convergence",
            "influence_audit",
            "claim_ledger",
            "method_definition",
        )
        science_hashes = {paths[key].name: sha256_file(paths[key]) for key in science_keys}
        freeze_hashes = dict(science_hashes)
        freeze_hashes[paths["build_summary"].name] = sha256_file(paths["build_summary"])
        hash_checks = {
            "build_outputs": build_summary.get("output_sha256") == science_hashes,
            "freeze_outputs": freeze.get("output_sha256") == freeze_hashes,
            "build_inputs": build_summary.get("input_sha256") == expected_hashes,
            "freeze_inputs": freeze.get("input_sha256") == expected_hashes,
            "candidate_identity": build_summary.get("candidate_id_sha256")
            == str(config["stage4a_frozen"]["expected_candidate_id_sha256"])
            == freeze.get("candidate_id_sha256"),
            "counts_match": build_summary.get("counts") == freeze.get("counts"),
        }
        add_gate(
            gates,
            "output_hashes_and_freeze",
            all(hash_checks.values()),
            hash_checks,
            {key: True for key in hash_checks},
            "science-output hashes, build summary, frozen inputs, counts, and freeze manifest are internally exact",
        )

        boundary = config["science_boundary"]
        stage4b_columns = {
            str(column).lower()
            for frame in (
                stored_global,
                stored_sensitivity,
                stored_transport,
                stored_draws,
                stored_diagnostics,
                stored_convergence,
                stored_influence,
                stored_claims,
            )
            for column in frame.columns
        }
        exact_forbidden_columns = {
            "population_label",
            "population_probability",
            "selection_weight",
            "inverse_probability_weight",
            "c_n",
            "c_fe",
            "n_fe",
            "al_fe",
            "ti_fe",
        }
        forbidden_files = [
            path.name
            for path in project_path(root, config["paths"]["output_dir"]).glob("*")
            if any(token in path.name.lower() for token in ("population", "selection_weight", "c_n"))
        ]
        boundary_checks = {
            "definition_exact": definition.get("science_boundary") == boundary,
            "build_exact": build_summary.get("science_boundary") == boundary,
            "freeze_exact": freeze.get("science_boundary") == boundary,
            "input_hashes_exact": definition.get("input_sha256") == expected_hashes,
            "validated_labels_exact": tuple(definition.get("labels", [])) == LABELS,
            "forbidden_columns_absent": not bool(stage4b_columns & exact_forbidden_columns),
            "forbidden_files_absent": not forbidden_files,
            "selection_and_population_flags_false": all(
                not bool(boundary[key])
                for key in (
                    "population_model_fitted",
                    "population_labels_assigned",
                    "population_resolved_gradients_fitted",
                    "selection_function_corrected",
                    "inverse_probability_weights_created",
                    "volume_complete_inference_claimed",
                    "abundance_error_proxy_used_as_regression_weight",
                    "abundance_error_proxy_treated_as_exact_Gaussian_sigma",
                    "full_distance_posterior_propagated_through_gradient_fit",
                    "common_support_interpreted_as_selection_correction",
                )
            ),
        }
        add_gate(
            gates,
            "science_boundary",
            all(boundary_checks.values()),
            {**boundary_checks, "forbidden_files": forbidden_files},
            {key: True for key in boundary_checks},
            "Stage 4B stops before population inference, selection correction, unvalidated labels, or exact posterior claims",
        )

        expected_gate_count = int(config["validation"]["expected_gates"])
        if len(gates) != expected_gate_count:
            raise RuntimeError(
                f"Internal Stage 4B validator gate count={len(gates)}; expected={expected_gate_count}"
            )
        passed = sum(bool(gate["passed"]) for gate in gates)
        payload = {
            "stage": "4B validation",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": utc_now(),
            "overall_passed": passed == len(gates),
            "n_passed": int(passed),
            "n_gates": int(len(gates)),
            "gates": gates,
        }
        atomic_write_json(payload, paths["validation"])
        paths["validation_report"].write_text(
            validation_report(payload), encoding="utf-8", newline="\n"
        )
        logger.info(
            "Stage 4B validation passed=%s; gates=%s/%s",
            payload["overall_passed"],
            passed,
            len(gates),
        )
        print(
            f"Stage 4B validation passed={payload['overall_passed']}; "
            f"gates={passed}/{len(gates)}"
        )
        return 0 if payload["overall_passed"] else 1
    finally:
        close_logger(logger)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
