from __future__ import annotations

import argparse
import sys

import numpy as np
import pandas as pd

from stage1_common import (
    atomic_write_json,
    configured_paths,
    ensure_columns,
    load_config,
    normalise_id_series,
    read_frame,
    read_json,
    setup_logger,
    table_suffix,
    utc_now,
    write_frame,
)


def make_record_key(
    frame: pd.DataFrame, gaia_column: str, fallback_column: str, prefix: str
) -> pd.Series:
    gaia = normalise_id_series(frame[gaia_column])
    fallback = frame[fallback_column].astype("string").fillna("").str.strip()
    fallback = fallback.where(fallback.ne(""), frame["survey_row_index"].astype(str))
    return pd.Series(
        np.where(
            gaia.gt(0),
            "G:" + gaia.astype(str),
            prefix + ":" + fallback.astype(str),
        ),
        index=frame.index,
        dtype="string",
    )


def deduplicate_apogee(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    result["record_key"] = make_record_key(
        result, "gaia_dr3_source_id", "apogee_id", "A"
    )
    result["_valid_gaia"] = result["gaia_dr3_source_id"].gt(0).astype("int8")
    result["_aspcap_good"] = result["aspcapflag"].fillna(-1).eq(0).astype("int8")
    result["_star_good"] = result["starflag"].fillna(-1).eq(0).astype("int8")
    result["_snrev"] = pd.to_numeric(result["snrev"], errors="coerce").fillna(-np.inf)
    result["_nvisits"] = (
        pd.to_numeric(result["nvisits"], errors="coerce").fillna(-1)
    )
    result = result.sort_values(
        [
            "record_key",
            "_valid_gaia",
            "_aspcap_good",
            "_star_good",
            "finite_primary_label_count",
            "_snrev",
            "_nvisits",
            "survey_row_index",
        ],
        ascending=[True, False, False, False, False, False, False, True],
        kind="mergesort",
    )
    result["within_survey_record_count"] = result.groupby(
        "record_key", sort=False
    )["record_key"].transform("size")
    result["selected_within_survey"] = ~result.duplicated("record_key", keep="first")
    selected = result.loc[result["selected_within_survey"]].copy()
    return selected.drop(
        columns=[
            "_valid_gaia",
            "_aspcap_good",
            "_star_good",
            "_snrev",
            "_nvisits",
        ]
    ).reset_index(drop=True)


def deduplicate_galah(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    result["record_key"] = make_record_key(
        result, "gaia_dr3_source_id", "sobject_id", "L"
    )
    result["_valid_gaia"] = result["gaia_dr3_source_id"].gt(0).astype("int8")
    result["_sp_good"] = result["flag_sp"].fillna(-1).eq(0).astype("int8")
    result["_snr"] = pd.to_numeric(
        result["snr_px_ccd3"], errors="coerce"
    ).fillna(-np.inf)
    result = result.sort_values(
        [
            "record_key",
            "_valid_gaia",
            "_sp_good",
            "finite_primary_label_count",
            "_snr",
            "survey_row_index",
        ],
        ascending=[True, False, False, False, False, True],
        kind="mergesort",
    )
    result["within_survey_record_count"] = result.groupby(
        "record_key", sort=False
    )["record_key"].transform("size")
    result["selected_within_survey"] = ~result.duplicated("record_key", keep="first")
    selected = result.loc[result["selected_within_survey"]].copy()
    return selected.drop(columns=["_valid_gaia", "_sp_good", "_snr"]).reset_index(
        drop=True
    )


def sample_flow_rows(
    apogee_raw: pd.DataFrame,
    galah_raw: pd.DataFrame,
    apogee_star: pd.DataFrame,
    galah_star: pd.DataFrame,
    master: pd.DataFrame,
) -> pd.DataFrame:
    rows: list[dict] = []

    def add(survey: str, stage: str, n: int, definition: str) -> None:
        rows.append(
            {"survey": survey, "stage": stage, "n": int(n), "definition": definition}
        )

    for name, raw, star in (
        ("APOGEE", apogee_raw, apogee_star),
        ("GALAH", galah_raw, galah_star),
    ):
        add(name, "raw_catalogue_rows", len(raw), "rows in official star catalogue")
        add(
            name,
            "positive_input_gaia_id",
            raw["has_gaia_input_id"].sum(),
            "positive survey-provided Gaia EDR3/DR3 identifier",
        )
        add(
            name,
            "broad_red_giant_rows",
            raw["broad_red_giant"].sum(),
            "3500<Teff<5500 K and 0<logg<3.5",
        )
        add(
            name,
            "broad_rg_and_quality_rows",
            raw["broad_rg_and_quality"].sum(),
            "broad red giant and survey-quality audit flag",
        )
        add(name, "deduplicated_survey_records", len(star), "deterministic star row")
        add(
            name,
            "deduplicated_positive_dr3_id",
            star["gaia_dr3_source_id"].gt(0).sum(),
            "deduplicated record with positive Gaia DR3 source_id",
        )
    for origin in ("APOGEE_only", "GALAH_only", "overlap"):
        add(
            "UNION",
            origin,
            master["survey_origin"].eq(origin).sum(),
            "mutually exclusive Gaia DR3 source category",
        )
    add(
        "UNION",
        "unique_gaia_dr3_sources",
        len(master),
        "union of positive unique Gaia DR3 source_id values",
    )
    return pd.DataFrame(rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/stage1.yml")
    args = parser.parse_args()

    config, root = load_config(args.config)
    paths = configured_paths(config, root)
    logger = setup_logger(
        paths["log_dir"] / "03_build_full_census.log", "stage1.census"
    )
    suffix = table_suffix(config)
    identifier_audit_path = paths["output_dir"] / "gaia_identifier_audit.json"
    if not identifier_audit_path.exists():
        raise FileNotFoundError(
            "Gaia identifier audit is missing; run 03_audit_gaia_identifiers.bat."
        )
    identifier_audit = read_json(identifier_audit_path)
    if not identifier_audit.get("complete", False):
        raise RuntimeError("Gaia identifier audit is incomplete.")

    ingest_dir = paths["interim_dir"] / "ingest"
    apogee_raw = read_frame(ingest_dir / f"apogee_rows{suffix}")
    galah_raw = read_frame(ingest_dir / f"galah_rows{suffix}")
    ensure_columns(apogee_raw, ["gaia_dr3_source_id"], "APOGEE ingest")
    ensure_columns(galah_raw, ["gaia_dr3_source_id"], "GALAH ingest")
    apogee = apogee_raw.copy()
    apogee["gaia_dr3_source_id"] = normalise_id_series(
        apogee["gaia_dr3_source_id"]
    )
    galah = galah_raw.copy()
    galah["gaia_dr3_source_id"] = normalise_id_series(
        galah["gaia_dr3_source_id"]
    )

    logger.info("Selecting deterministic survey-level star rows")
    apogee_star = deduplicate_apogee(apogee)
    galah_star = deduplicate_galah(galah)
    star_dir = paths["interim_dir"] / "star_level"
    star_dir.mkdir(parents=True, exist_ok=True)
    write_frame(apogee_star, star_dir / f"apogee_star_level{suffix}")
    write_frame(galah_star, star_dir / f"galah_star_level{suffix}")

    apo_ids = (
        apogee_star.loc[
            apogee_star["gaia_dr3_source_id"].gt(0), ["gaia_dr3_source_id"]
        ]
        .drop_duplicates()
        .assign(has_apogee=True)
    )
    gal_ids = (
        galah_star.loc[
            galah_star["gaia_dr3_source_id"].gt(0), ["gaia_dr3_source_id"]
        ]
        .drop_duplicates()
        .assign(has_galah=True)
    )
    master = apo_ids.merge(
        gal_ids, on="gaia_dr3_source_id", how="outer", validate="one_to_one"
    )
    master["has_apogee"] = master["has_apogee"].eq(True)
    master["has_galah"] = master["has_galah"].eq(True)
    master["survey_origin"] = np.select(
        [
            master["has_apogee"] & master["has_galah"],
            master["has_apogee"],
        ],
        ["overlap", "APOGEE_only"],
        default="GALAH_only",
    )
    master = master.sort_values("gaia_dr3_source_id").reset_index(drop=True)
    if master["gaia_dr3_source_id"].duplicated().any():
        raise RuntimeError("Source master contains duplicate Gaia DR3 source IDs.")
    write_frame(
        master, paths["output_dir"] / f"spectroscopic_source_master{suffix}"
    )
    write_frame(
        master[["gaia_dr3_source_id"]],
        paths["output_dir"] / f"gaia_dr3_source_ids{suffix}",
    )

    apo_pair = apogee_star.loc[apogee_star["gaia_dr3_source_id"].gt(0)].copy()
    gal_pair = galah_star.loc[galah_star["gaia_dr3_source_id"].gt(0)].copy()
    apo_pair = apo_pair.rename(
        columns={
            column: f"apogee_{column}"
            for column in apo_pair.columns
            if column != "gaia_dr3_source_id"
        }
    )
    gal_pair = gal_pair.rename(
        columns={
            column: f"galah_{column}"
            for column in gal_pair.columns
            if column != "gaia_dr3_source_id"
        }
    )
    overlap = apo_pair.merge(
        gal_pair,
        on="gaia_dr3_source_id",
        how="inner",
        validate="one_to_one",
    )
    write_frame(overlap, paths["output_dir"] / f"overlap_pairs{suffix}")

    flow = sample_flow_rows(apogee_raw, galah_raw, apogee_star, galah_star, master)
    flow.to_csv(paths["output_dir"] / "sample_flow_stage1.csv", index=False)
    duplicate_audit = pd.DataFrame(
        [
            {
                "survey": "APOGEE",
                "raw_rows": len(apogee_raw),
                "deduplicated_records": len(apogee_star),
                "removed_duplicate_rows": len(apogee_raw) - len(apogee_star),
                "selected_records_with_multiple_rows": int(
                    apogee_star["within_survey_record_count"].gt(1).sum()
                ),
            },
            {
                "survey": "GALAH",
                "raw_rows": len(galah_raw),
                "deduplicated_records": len(galah_star),
                "removed_duplicate_rows": len(galah_raw) - len(galah_star),
                "selected_records_with_multiple_rows": int(
                    galah_star["within_survey_record_count"].gt(1).sum()
                ),
            },
        ]
    )
    duplicate_audit.to_csv(
        paths["output_dir"] / "within_survey_duplicate_audit.csv", index=False
    )

    label_overlap_counts = {}
    for label in config["selection"]["primary_labels"] + config["selection"][
        "secondary_labels"
    ]:
        a = f"apogee_valid_{label}"
        g = f"galah_valid_{label}"
        label_overlap_counts[label] = int(
            (overlap[a].fillna(False) & overlap[g].fillna(False)).sum()
        )

    legacy_union = int(
        config["legacy_benchmarks"]["cross_survey_union_rows_reported"]
    )
    raw_total = len(apogee_raw) + len(galah_raw)
    origin_counts = master["survey_origin"].value_counts().to_dict()
    summary = {
        "stage": "1C full spectroscopic source census",
        "protocol_version": config["project"]["version"],
        "created_utc": utc_now(),
        "raw_rows": {
            "apogee": int(len(apogee_raw)),
            "galah": int(len(galah_raw)),
            "concatenated": int(raw_total),
        },
        "deduplicated_survey_records": {
            "apogee": int(len(apogee_star)),
            "galah": int(len(galah_star)),
        },
        "direct_gaia_identifier_audit": {
            "apogee_catalogue_column": config["gaia"]["identifier_semantics"][
                "apogee_catalogue_column"
            ],
            "apogee_catalogue_release": config["gaia"]["identifier_semantics"][
                "apogee_release"
            ],
            "unique_positive_apogee_ids": int(
                apogee_raw.loc[
                    apogee_raw["gaia_dr3_source_id"].gt(0), "gaia_dr3_source_id"
                ].nunique()
            ),
            "raw_unique_id_intersection": int(
                identifier_audit["raw_unique_id_sets"]["intersection"]
            ),
            "dr3_join_rule": (
                "direct source_id equality; Gaia EDR3 and DR3 source lists "
                "are identical"
            ),
        },
        "mutually_exclusive_gaia_dr3_union": {
            "apogee_only": int(origin_counts.get("APOGEE_only", 0)),
            "galah_only": int(origin_counts.get("GALAH_only", 0)),
            "overlap": int(origin_counts.get("overlap", 0)),
            "union": int(len(master)),
        },
        "overlap_valid_label_counts": label_overlap_counts,
        "legacy_comparison": {
            "reported_union": legacy_union,
            "observed_union": int(len(master)),
            "observed_minus_reported": int(len(master) - legacy_union),
            "raw_sum_minus_reported_union": int(raw_total - legacy_union),
            "raw_sum_minus_direct_overlap": int(
                raw_total
                - identifier_audit["raw_unique_id_sets"]["intersection"]
            ),
            "reported_equals_raw_sum_minus_direct_overlap": bool(
                legacy_union
                == raw_total
                - identifier_audit["raw_unique_id_sets"]["intersection"]
            ),
            "interpretation": (
                "The old 1,591,571 value equals the raw row sum minus the direct "
                "cross-survey overlap. It is neither the raw total nor a unique-star "
                "union because within-survey repeats and records without positive "
                "Gaia IDs remain."
            ),
        },
    }
    atomic_write_json(summary, paths["output_dir"] / "stage1_census_summary.json")
    atomic_write_json(
        {"stage": "1C sample flow", "rows": flow.to_dict(orient="records")},
        paths["output_dir"] / "sample_flow_stage1.json",
    )
    logger.info(
        "Census complete: %s unique Gaia DR3 sources; %s overlap",
        f"{len(master):,}",
        f"{len(overlap):,}",
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
