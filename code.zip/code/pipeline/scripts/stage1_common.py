from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def load_config(config_path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    path = Path(config_path).resolve()
    with path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {path}")
    root = path.parent.parent
    return config, root


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def configured_paths(config: Mapping[str, Any], root: Path) -> dict[str, Path]:
    result = {
        key: project_path(root, value)
        for key, value in config["paths"].items()
    }
    for path in result.values():
        path.mkdir(parents=True, exist_ok=True)
    return result


def setup_logger(log_path: Path, name: str) -> logging.Logger:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if logger.handlers:
        return logger
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        temporary = Path(handle.name)
    os.replace(temporary, path)


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(block_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def _native_array(values: Any) -> np.ndarray:
    if np.ma.isMaskedArray(values):
        if values.dtype.kind in "iu":
            values = values.filled(0)
        elif values.dtype.kind in "fc":
            values = values.filled(np.nan)
        else:
            values = values.filled("")
    array = np.asarray(values)
    if array.dtype.byteorder not in ("=", "|"):
        array = array.astype(array.dtype.newbyteorder("="), copy=True)
    else:
        array = np.array(array, copy=True)
    if array.dtype.kind == "S":
        array = np.char.decode(array, "utf-8", errors="replace")
    return array


def read_fits_columns(
    path: Path,
    hdu: int,
    column_map: Mapping[str, Sequence[str]],
    required: Iterable[str],
) -> tuple[pd.DataFrame, dict[str, str | None], int]:
    from astropy.io import fits

    with fits.open(path, memmap=True, lazy_load_hdus=True) as hdul:
        data = hdul[hdu].data
        names = list(hdul[hdu].columns.names)
        lookup = {name.lower(): name for name in names}
        selected: dict[str, np.ndarray] = {}
        resolved: dict[str, str | None] = {}
        required_set = set(required)
        for output_name, aliases in column_map.items():
            actual = next((lookup[a.lower()] for a in aliases if a.lower() in lookup), None)
            resolved[output_name] = actual
            if actual is None:
                if output_name in required_set:
                    related = [
                        name
                        for name in names
                        if any(
                            token in name.lower()
                            for token in ("gaia", "source", "identifier")
                        )
                    ][:20]
                    raise KeyError(
                        f"Required column {output_name!r} was not found in {path.name}; "
                        f"aliases={list(aliases)}; related available columns={related}"
                    )
                continue
            selected[output_name] = _native_array(data[actual])
        row_count = len(data)
    frame = pd.DataFrame(selected)
    if len(frame) != row_count:
        raise RuntimeError(f"FITS extraction row mismatch for {path}: {len(frame)} != {row_count}")
    return frame, resolved, row_count


def clean_string_series(series: pd.Series) -> pd.Series:
    return series.astype("string").fillna("").str.strip()


def normalise_id_series(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce").fillna(0)
    valid = numeric.where(numeric > 0, 0)
    return valid.astype("int64")


def numeric_series(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def lower_columns(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    result.columns = [str(column).lower() for column in result.columns]
    return result


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    if path.suffix == ".parquet":
        frame.to_parquet(temporary, index=False, compression="zstd")
    elif path.suffix in {".pkl", ".pickle"}:
        frame.to_pickle(temporary)
    elif path.name.endswith(".csv.gz"):
        frame.to_csv(temporary, index=False, compression="gzip")
    elif path.suffix == ".csv":
        frame.to_csv(temporary, index=False)
    else:
        raise ValueError(f"Unsupported table format: {path}")
    os.replace(temporary, path)


def read_frame(path: Path, columns: Sequence[str] | None = None) -> pd.DataFrame:
    if path.suffix == ".parquet":
        return pd.read_parquet(path, columns=columns)
    if path.suffix in {".pkl", ".pickle"}:
        frame = pd.read_pickle(path)
        return frame if columns is None else frame.loc[:, list(columns)]
    if path.name.endswith(".csv.gz") or path.suffix == ".csv":
        return pd.read_csv(path, usecols=columns)
    raise ValueError(f"Unsupported table format: {path}")


def table_suffix(config: Mapping[str, Any]) -> str:
    value = str(config["project"].get("table_format", "parquet")).lower()
    if value == "parquet":
        return ".parquet"
    if value in {"pickle", "pkl"}:
        return ".pkl"
    if value in {"csv.gz", "csv_gz"}:
        return ".csv.gz"
    raise ValueError(f"Unsupported project.table_format={value!r}")


def finite_count(frame: pd.DataFrame, columns: Sequence[str]) -> pd.Series:
    existing = [column for column in columns if column in frame.columns]
    if not existing:
        return pd.Series(0, index=frame.index, dtype="int16")
    matrix = np.column_stack(
        [np.isfinite(pd.to_numeric(frame[column], errors="coerce")) for column in existing]
    )
    return pd.Series(matrix.sum(axis=1), index=frame.index, dtype="int16")


def chunked(values: np.ndarray, size: int) -> Iterable[tuple[int, np.ndarray]]:
    if size <= 0:
        raise ValueError("Chunk size must be positive")
    for start in range(0, len(values), size):
        yield start // size, values[start : start + size]


def ensure_columns(frame: pd.DataFrame, required: Sequence[str], label: str) -> None:
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise KeyError(f"{label} is missing required columns: {missing}")


def to_python(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if pd.isna(value):
        return None
    return value


def frame_counts(frame: pd.DataFrame, flags: Sequence[str]) -> dict[str, int]:
    result = {"rows": int(len(frame))}
    for flag in flags:
        if flag in frame:
            result[flag] = int(frame[flag].fillna(False).astype(bool).sum())
    return result


def gaia_upload_query(
    ids: np.ndarray,
    query: str,
    upload_path: Path,
    upload_table_name: str = "ids",
) -> pd.DataFrame:
    from astropy.table import Table
    from astroquery.gaia import Gaia

    upload_path.parent.mkdir(parents=True, exist_ok=True)
    order = np.arange(len(ids), dtype=np.int64)
    table = Table(
        [order, np.asarray(ids, dtype=np.int64)],
        names=("input_order", "source_id"),
    )
    table.write(upload_path, format="votable", overwrite=True)
    Gaia.ROW_LIMIT = -1
    job = Gaia.launch_job_async(
        query=query,
        upload_resource=str(upload_path),
        upload_table_name=upload_table_name,
        output_format="votable_gzip",
        dump_to_file=False,
        verbose=False,
    )
    result = lower_columns(job.get_results().to_pandas())
    return result
