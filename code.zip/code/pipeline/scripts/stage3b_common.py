from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import astropy
import astropy.units as u
import numpy as np
import pandas as pd
import yaml
from astropy.coordinates import CartesianDifferential, Galactocentric, ICRS, SkyCoord


LABELS = ("fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe", "alpha3")

INPUT_COLUMNS = (
    "gaia_dr3_source_id",
    "survey_origin",
    "preferred_spectroscopic_survey",
    "spectroscopic_primary_ok",
    "spectroscopic_sensitivity_ok",
    "ra",
    "dec",
    "pmra",
    "pmdec",
    "distance_primary_pc",
    "r_med_geo",
    "analysis_rv_kms",
    "analysis_rv_error_kms",
    "analysis_rv_source",
    "clean_5d_primary_ok",
    "clean_5d_sensitivity_ok",
    "clean_6d_primary_ok",
    "clean_6d_sensitivity_ok",
    "clean_6d_geo_alternative_ok",
    *tuple(
        column
        for label in LABELS
        for column in (
            f"{label}_clean6d_primary_ok",
            f"{label}_clean6d_core_ok",
            f"{label}_clean6d_sensitivity_ok",
            f"{label}_clean6d_geo_alternative_ok",
        )
    ),
)

POSITION_COLUMNS = (
    "x_gc_kpc",
    "y_gc_kpc",
    "z_gc_kpc",
    "r_cyl_gc_kpc",
    "r_sph_gc_kpc",
    "phi_gc_rad",
)
VELOCITY_COLUMNS = (
    "v_x_gc_kms",
    "v_y_gc_kms",
    "v_z_gc_kms",
    "v_R_gc_kms",
    "v_phi_gc_kms",
    "v_rot_gc_kms",
    "v_total_gc_kms",
    "l_z_gc_kpc_kms",
)
GEO_POSITION_COLUMNS = tuple(f"{name}_geo_alt" for name in POSITION_COLUMNS)
GEO_VELOCITY_COLUMNS = tuple(f"{name}_geo_alt" for name in VELOCITY_COLUMNS)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_config(path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {config_path}")
    return config, config_path.parent.parent


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def setup_logger(path: Path, name: str) -> logging.Logger:
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def close_logger(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        handler.flush()
        handler.close()
        logger.removeHandler(handler)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def ids_sha256(values: Sequence[int] | np.ndarray | pd.Series) -> str:
    digest = hashlib.sha256()
    for value in np.asarray(values, dtype=np.int64):
        digest.update(f"{int(value)}\n".encode("ascii"))
    return digest.hexdigest()


def canonical_json_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        temporary = Path(handle.name)
    os.replace(temporary, path)


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.unlink(missing_ok=True)
    if path.suffix.lower() == ".parquet":
        frame.to_parquet(temporary, index=False, compression="zstd")
    elif path.suffix.lower() == ".csv":
        frame.to_csv(temporary, index=False)
    else:
        raise ValueError(f"Unsupported table format: {path}")
    os.replace(temporary, path)


def ensure_columns(frame: pd.DataFrame, required: Iterable[str], label: str) -> None:
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise KeyError(f"{label} is missing required columns: {missing}")


def frame_equal(
    observed: pd.DataFrame,
    expected: pd.DataFrame,
    sort_by: Sequence[str],
    atol: float = 1.0e-10,
) -> bool:
    if set(observed.columns) != set(expected.columns):
        return False
    observed = observed.loc[:, expected.columns].sort_values(list(sort_by)).reset_index(drop=True)
    expected = expected.sort_values(list(sort_by)).reset_index(drop=True)
    if observed.shape != expected.shape:
        return False
    for column in expected.columns:
        left = observed[column]
        right = expected[column]
        if pd.api.types.is_numeric_dtype(right) and not pd.api.types.is_bool_dtype(right):
            if not np.allclose(
                pd.to_numeric(left, errors="coerce").to_numpy(float),
                pd.to_numeric(right, errors="coerce").to_numpy(float),
                rtol=0.0,
                atol=atol,
                equal_nan=True,
            ):
                return False
        else:
            if not left.astype("string").fillna("<NA>").equals(
                right.astype("string").fillna("<NA>")
            ):
                return False
    return True


def explicit_frame(policy: Mapping[str, Any]) -> Galactocentric:
    return Galactocentric(
        galcen_coord=ICRS(
            ra=float(policy["galcen_coord_ra_deg"]) * u.deg,
            dec=float(policy["galcen_coord_dec_deg"]) * u.deg,
        ),
        galcen_distance=float(policy["galcen_distance_kpc"]) * u.kpc,
        galcen_v_sun=CartesianDifferential(
            np.asarray(policy["galcen_v_sun_kms"], dtype=float) * u.km / u.s
        ),
        z_sun=float(policy["z_sun_pc"]) * u.pc,
        roll=float(policy["roll_deg"]) * u.deg,
    )


def galcen_velocity_xyz(frame: Galactocentric) -> u.Quantity:
    """Return the solar Galactocentric velocity across Astropy API variants."""
    velocity = frame.galcen_v_sun
    if hasattr(velocity, "d_xyz"):
        return velocity.d_xyz
    if hasattr(velocity, "xyz"):
        return velocity.xyz
    raise TypeError(
        "Unsupported galcen_v_sun object: expected d_xyz or xyz components; "
        f"got {type(velocity).__name__}"
    )


def frame_definition(policy: Mapping[str, Any]) -> dict[str, Any]:
    frame = explicit_frame(policy)
    velocity = galcen_velocity_xyz(frame).to_value(u.km / u.s)
    return {
        "frame_name": str(policy["name"]),
        "astropy_version": astropy.__version__,
        "galcen_coord_ra_deg": float(frame.galcen_coord.ra.to_value(u.deg)),
        "galcen_coord_dec_deg": float(frame.galcen_coord.dec.to_value(u.deg)),
        "galcen_distance_kpc": float(frame.galcen_distance.to_value(u.kpc)),
        "galcen_v_sun_kms": [float(value) for value in velocity],
        "z_sun_pc": float(frame.z_sun.to_value(u.pc)),
        "roll_deg": float(frame.roll.to_value(u.deg)),
        "right_handed": True,
        "sun_at_negative_x": True,
        "prograde_disc_v_phi_sign": "negative",
        "v_rot_definition": "-v_phi",
        "policy_sha256": canonical_json_sha256(policy),
    }


def _number(frame: pd.DataFrame, column: str) -> np.ndarray:
    return pd.to_numeric(frame[column], errors="coerce").to_numpy(float)


def _flag(frame: pd.DataFrame, column: str) -> np.ndarray:
    return frame[column].astype("boolean").fillna(False).to_numpy(dtype=bool)


def _chunks(indices: np.ndarray, chunk_size: int) -> Iterable[np.ndarray]:
    for start in range(0, len(indices), chunk_size):
        yield indices[start : start + chunk_size]


def transform_icrs(
    frame: pd.DataFrame,
    distance_column: str,
    frame_policy: Mapping[str, Any],
    chunk_size: int,
) -> dict[str, np.ndarray]:
    n_rows = len(frame)
    values = {
        name: np.full(n_rows, np.nan, dtype=float)
        for name in (*POSITION_COLUMNS, *VELOCITY_COLUMNS)
    }
    ra = _number(frame, "ra")
    dec = _number(frame, "dec")
    distance = _number(frame, distance_column)
    pmra = _number(frame, "pmra")
    pmdec = _number(frame, "pmdec")
    radial_velocity = _number(frame, "analysis_rv_kms")
    position_mask = (
        np.isfinite(ra)
        & np.isfinite(dec)
        & np.isfinite(distance)
        & (distance > 0.0)
    )
    velocity_mask = (
        position_mask
        & np.isfinite(pmra)
        & np.isfinite(pmdec)
        & np.isfinite(radial_velocity)
    )
    gc_frame = explicit_frame(frame_policy)

    velocity_indices = np.flatnonzero(velocity_mask)
    for index in _chunks(velocity_indices, chunk_size):
        sky = SkyCoord(
            ra=ra[index] * u.deg,
            dec=dec[index] * u.deg,
            distance=distance[index] * u.pc,
            pm_ra_cosdec=pmra[index] * u.mas / u.yr,
            pm_dec=pmdec[index] * u.mas / u.yr,
            radial_velocity=radial_velocity[index] * u.km / u.s,
            frame="icrs",
        )
        gc = sky.transform_to(gc_frame)
        x = gc.x.to_value(u.kpc)
        y = gc.y.to_value(u.kpc)
        z = gc.z.to_value(u.kpc)
        vx = gc.v_x.to_value(u.km / u.s)
        vy = gc.v_y.to_value(u.km / u.s)
        vz = gc.v_z.to_value(u.km / u.s)
        _assign_phase_space(values, index, x, y, z, vx, vy, vz)

    position_only_indices = np.flatnonzero(position_mask & ~velocity_mask)
    for index in _chunks(position_only_indices, chunk_size):
        sky = SkyCoord(
            ra=ra[index] * u.deg,
            dec=dec[index] * u.deg,
            distance=distance[index] * u.pc,
            frame="icrs",
        )
        gc = sky.transform_to(gc_frame)
        x = gc.x.to_value(u.kpc)
        y = gc.y.to_value(u.kpc)
        z = gc.z.to_value(u.kpc)
        _assign_positions(values, index, x, y, z)

    return _quantize(values, frame_policy["quantization_decimals"])


def _assign_positions(
    values: dict[str, np.ndarray],
    index: np.ndarray,
    x: np.ndarray,
    y: np.ndarray,
    z: np.ndarray,
) -> None:
    r_cyl = np.hypot(x, y)
    values["x_gc_kpc"][index] = x
    values["y_gc_kpc"][index] = y
    values["z_gc_kpc"][index] = z
    values["r_cyl_gc_kpc"][index] = r_cyl
    values["r_sph_gc_kpc"][index] = np.sqrt(r_cyl**2 + z**2)
    values["phi_gc_rad"][index] = np.arctan2(y, x)


def _assign_phase_space(
    values: dict[str, np.ndarray],
    index: np.ndarray,
    x: np.ndarray,
    y: np.ndarray,
    z: np.ndarray,
    vx: np.ndarray,
    vy: np.ndarray,
    vz: np.ndarray,
) -> None:
    _assign_positions(values, index, x, y, z)
    r_cyl = np.hypot(x, y)
    safe = r_cyl > 0.0
    v_r = np.full(len(index), np.nan, dtype=float)
    v_phi = np.full(len(index), np.nan, dtype=float)
    v_r[safe] = (x[safe] * vx[safe] + y[safe] * vy[safe]) / r_cyl[safe]
    v_phi[safe] = (x[safe] * vy[safe] - y[safe] * vx[safe]) / r_cyl[safe]
    values["v_x_gc_kms"][index] = vx
    values["v_y_gc_kms"][index] = vy
    values["v_z_gc_kms"][index] = vz
    values["v_R_gc_kms"][index] = v_r
    values["v_phi_gc_kms"][index] = v_phi
    values["v_rot_gc_kms"][index] = -v_phi
    values["v_total_gc_kms"][index] = np.sqrt(vx**2 + vy**2 + vz**2)
    values["l_z_gc_kpc_kms"][index] = x * vy - y * vx


def _quantize(
    values: dict[str, np.ndarray], decimals: Mapping[str, int]
) -> dict[str, np.ndarray]:
    output: dict[str, np.ndarray] = {}
    for name, array in values.items():
        if name == "phi_gc_rad":
            places = int(decimals["angle"])
        elif name.startswith("v_") or name.startswith("l_z"):
            places = int(decimals["velocity"])
        else:
            places = int(decimals["position"])
        output[name] = np.round(array, decimals=places)
    # Preserve the manuscript sign convention exactly after quantization.
    output["v_rot_gc_kms"] = -output["v_phi_gc_kms"]
    return output


def build_phase_space_layer(
    input_layer: pd.DataFrame, policy: Mapping[str, Any]
) -> pd.DataFrame:
    ensure_columns(input_layer, INPUT_COLUMNS, "Stage 3A quality layer")
    result = input_layer.loc[:, INPUT_COLUMNS].copy()
    result = result.sort_values("gaia_dr3_source_id", kind="mergesort").reset_index(drop=True)
    if result["gaia_dr3_source_id"].duplicated().any():
        raise RuntimeError("Stage 3A quality layer contains duplicate source IDs")
    chunk_size = int(policy["transform_chunk_size"])
    primary = transform_icrs(
        result,
        "distance_primary_pc",
        policy["frame"],
        chunk_size,
    )
    geometric = transform_icrs(
        result,
        "r_med_geo",
        policy["frame"],
        chunk_size,
    )
    for name, array in primary.items():
        result[name] = array
    for name, array in geometric.items():
        result[f"{name}_geo_alt"] = array

    photo_position_finite = np.logical_and.reduce(
        [np.isfinite(_number(result, name)) for name in POSITION_COLUMNS]
    )
    photo_velocity_finite = np.logical_and.reduce(
        [np.isfinite(_number(result, name)) for name in VELOCITY_COLUMNS]
    )
    geo_position_finite = np.logical_and.reduce(
        [np.isfinite(_number(result, name)) for name in GEO_POSITION_COLUMNS]
    )
    geo_velocity_finite = np.logical_and.reduce(
        [np.isfinite(_number(result, name)) for name in GEO_VELOCITY_COLUMNS]
    )
    cuts = policy["plausibility"]
    radius = _number(result, "r_sph_gc_kpc")
    speed = _number(result, "v_total_gc_kms")
    radius_geo = _number(result, "r_sph_gc_kpc_geo_alt")
    speed_geo = _number(result, "v_total_gc_kms_geo_alt")
    radius_primary = photo_position_finite & (
        radius <= float(cuts["primary_max_galactocentric_radius_kpc"])
    )
    radius_sensitivity = photo_position_finite & (
        radius <= float(cuts["sensitivity_max_galactocentric_radius_kpc"])
    )
    speed_primary = photo_velocity_finite & (
        speed <= float(cuts["primary_max_total_speed_kms"])
    )
    speed_sensitivity = photo_velocity_finite & (
        speed <= float(cuts["sensitivity_max_total_speed_kms"])
    )
    radius_geo_sensitivity = geo_position_finite & (
        radius_geo <= float(cuts["sensitivity_max_galactocentric_radius_kpc"])
    )
    speed_geo_sensitivity = geo_velocity_finite & (
        speed_geo <= float(cuts["sensitivity_max_total_speed_kms"])
    )
    kinematic_primary = radius_primary & speed_primary
    kinematic_sensitivity = radius_sensitivity & speed_sensitivity
    kinematic_geo = radius_geo_sensitivity & speed_geo_sensitivity
    phase5_primary = _flag(result, "clean_5d_primary_ok") & radius_primary
    phase5_sensitivity = _flag(result, "clean_5d_sensitivity_ok") & radius_sensitivity
    phase6_primary = _flag(result, "clean_6d_primary_ok") & kinematic_primary
    phase6_sensitivity = _flag(result, "clean_6d_sensitivity_ok") & kinematic_sensitivity
    phase6_geo = _flag(result, "clean_6d_geo_alternative_ok") & kinematic_geo

    result["photo_position_finite"] = photo_position_finite
    result["photo_velocity_finite"] = photo_velocity_finite
    result["geo_position_finite"] = geo_position_finite
    result["geo_velocity_finite"] = geo_velocity_finite
    result["kinematic_radius_primary_ok"] = radius_primary
    result["kinematic_radius_sensitivity_ok"] = radius_sensitivity
    result["kinematic_speed_primary_ok"] = speed_primary
    result["kinematic_speed_sensitivity_ok"] = speed_sensitivity
    result["kinematic_geo_radius_sensitivity_ok"] = radius_geo_sensitivity
    result["kinematic_geo_speed_sensitivity_ok"] = speed_geo_sensitivity
    result["kinematic_primary_ok"] = kinematic_primary
    result["kinematic_sensitivity_ok"] = kinematic_sensitivity
    result["kinematic_geo_alternative_ok"] = kinematic_geo
    result["phase_space_5d_primary_ok"] = phase5_primary
    result["phase_space_5d_sensitivity_ok"] = phase5_sensitivity
    result["phase_space_6d_primary_ok"] = phase6_primary
    result["phase_space_6d_sensitivity_ok"] = phase6_sensitivity
    result["phase_space_6d_geo_alternative_ok"] = phase6_geo

    for label in LABELS:
        result[f"{label}_phase_space_primary_ok"] = (
            _flag(result, f"{label}_clean6d_primary_ok") & kinematic_primary
        )
        result[f"{label}_phase_space_core_ok"] = (
            _flag(result, f"{label}_clean6d_core_ok") & kinematic_primary
        )
        result[f"{label}_phase_space_sensitivity_ok"] = (
            _flag(result, f"{label}_clean6d_sensitivity_ok") & kinematic_sensitivity
        )
        result[f"{label}_phase_space_geo_alternative_ok"] = (
            _flag(result, f"{label}_clean6d_geo_alternative_ok") & kinematic_geo
        )
    return result


def gate_flow_table(layer: pd.DataFrame) -> pd.DataFrame:
    stages = (
        ("stage3a_candidates", len(layer)),
        ("clean_5d_primary_input", _flag(layer, "clean_5d_primary_ok").sum()),
        ("clean_5d_sensitivity_input", _flag(layer, "clean_5d_sensitivity_ok").sum()),
        ("clean_6d_primary_input", _flag(layer, "clean_6d_primary_ok").sum()),
        ("clean_6d_sensitivity_input", _flag(layer, "clean_6d_sensitivity_ok").sum()),
        ("clean_6d_geo_alternative_input", _flag(layer, "clean_6d_geo_alternative_ok").sum()),
        ("photo_position_finite", _flag(layer, "photo_position_finite").sum()),
        ("photo_velocity_finite", _flag(layer, "photo_velocity_finite").sum()),
        ("geo_position_finite", _flag(layer, "geo_position_finite").sum()),
        ("geo_velocity_finite", _flag(layer, "geo_velocity_finite").sum()),
        ("kinematic_primary_ok", _flag(layer, "kinematic_primary_ok").sum()),
        ("kinematic_sensitivity_ok", _flag(layer, "kinematic_sensitivity_ok").sum()),
        ("kinematic_geo_alternative_ok", _flag(layer, "kinematic_geo_alternative_ok").sum()),
        ("phase_space_5d_primary_ok", _flag(layer, "phase_space_5d_primary_ok").sum()),
        ("phase_space_5d_sensitivity_ok", _flag(layer, "phase_space_5d_sensitivity_ok").sum()),
        ("phase_space_6d_primary_ok", _flag(layer, "phase_space_6d_primary_ok").sum()),
        ("phase_space_6d_sensitivity_ok", _flag(layer, "phase_space_6d_sensitivity_ok").sum()),
        ("phase_space_6d_geo_alternative_ok", _flag(layer, "phase_space_6d_geo_alternative_ok").sum()),
    )
    return pd.DataFrame([{"gate": name, "rows": int(value)} for name, value in stages])


def origin_flow_table(layer: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for origin, selected in layer.groupby("survey_origin", sort=True, dropna=False):
        rows.append(
            {
                "survey_origin": str(origin),
                "candidate_rows": int(len(selected)),
                "phase_space_5d_primary_ok": int(_flag(selected, "phase_space_5d_primary_ok").sum()),
                "phase_space_5d_sensitivity_ok": int(_flag(selected, "phase_space_5d_sensitivity_ok").sum()),
                "phase_space_6d_primary_ok": int(_flag(selected, "phase_space_6d_primary_ok").sum()),
                "phase_space_6d_sensitivity_ok": int(_flag(selected, "phase_space_6d_sensitivity_ok").sum()),
                "phase_space_6d_geo_alternative_ok": int(_flag(selected, "phase_space_6d_geo_alternative_ok").sum()),
            }
        )
    return pd.DataFrame(rows)


def label_flow_table(layer: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for label in LABELS:
        rows.append(
            {
                "label": label,
                "primary": int(_flag(layer, f"{label}_phase_space_primary_ok").sum()),
                "core": int(_flag(layer, f"{label}_phase_space_core_ok").sum()),
                "sensitivity": int(_flag(layer, f"{label}_phase_space_sensitivity_ok").sum()),
                "geo_alternative": int(_flag(layer, f"{label}_phase_space_geo_alternative_ok").sum()),
            }
        )
    return pd.DataFrame(rows)


def extreme_audit_table(layer: pd.DataFrame) -> pd.DataFrame:
    input_primary = _flag(layer, "clean_6d_primary_ok")
    output_primary = _flag(layer, "phase_space_6d_primary_ok")
    selected = layer.loc[input_primary & ~output_primary].copy()
    columns = [
        "gaia_dr3_source_id",
        "survey_origin",
        "distance_primary_pc",
        "r_sph_gc_kpc",
        "z_gc_kpc",
        "v_R_gc_kms",
        "v_phi_gc_kms",
        "v_rot_gc_kms",
        "v_z_gc_kms",
        "v_total_gc_kms",
    ]
    if selected.empty:
        return pd.DataFrame(columns=[*columns, "failure_reason"])
    finite = _flag(selected, "photo_position_finite") & _flag(selected, "photo_velocity_finite")
    radius = _flag(selected, "kinematic_radius_primary_ok")
    speed = _flag(selected, "kinematic_speed_primary_ok")
    reasons = np.select(
        [
            ~finite,
            finite & ~radius & ~speed,
            finite & ~radius,
            finite & ~speed,
        ],
        ["NONFINITE", "RADIUS_AND_SPEED", "RADIUS", "SPEED"],
        default="OTHER",
    )
    output = selected.loc[:, columns].copy()
    output["failure_reason"] = reasons
    return output.sort_values("gaia_dr3_source_id", kind="mergesort").reset_index(drop=True)


def estimator_sensitivity_table(layer: pd.DataFrame) -> pd.DataFrame:
    paired = _flag(layer, "phase_space_6d_sensitivity_ok") & _flag(
        layer, "phase_space_6d_geo_alternative_ok"
    )
    metrics = (
        ("r_cyl_gc_kpc", "r_cyl_gc_kpc_geo_alt"),
        ("z_gc_kpc", "z_gc_kpc_geo_alt"),
        ("v_R_gc_kms", "v_R_gc_kms_geo_alt"),
        ("v_phi_gc_kms", "v_phi_gc_kms_geo_alt"),
        ("v_z_gc_kms", "v_z_gc_kms_geo_alt"),
        ("v_total_gc_kms", "v_total_gc_kms_geo_alt"),
    )
    rows: list[dict[str, Any]] = []
    for primary, alternative in metrics:
        delta = _number(layer, alternative)[paired] - _number(layer, primary)[paired]
        delta = delta[np.isfinite(delta)]
        absolute = np.abs(delta)
        rows.append(
            {
                "quantity": primary,
                "paired_rows": int(len(delta)),
                "delta_geo_minus_photo_q16": float(np.quantile(delta, 0.16)),
                "delta_geo_minus_photo_median": float(np.quantile(delta, 0.50)),
                "delta_geo_minus_photo_q84": float(np.quantile(delta, 0.84)),
                "absolute_delta_median": float(np.quantile(absolute, 0.50)),
                "absolute_delta_q95": float(np.quantile(absolute, 0.95)),
                "absolute_delta_q99": float(np.quantile(absolute, 0.99)),
            }
        )
    return pd.DataFrame(rows)


def phase_space_counts(layer: pd.DataFrame) -> dict[str, int]:
    return {
        "rows": int(len(layer)),
        "columns": int(len(layer.columns)),
        "photo_position_finite": int(_flag(layer, "photo_position_finite").sum()),
        "photo_velocity_finite": int(_flag(layer, "photo_velocity_finite").sum()),
        "geo_position_finite": int(_flag(layer, "geo_position_finite").sum()),
        "geo_velocity_finite": int(_flag(layer, "geo_velocity_finite").sum()),
        "phase_space_5d_primary_ok": int(_flag(layer, "phase_space_5d_primary_ok").sum()),
        "phase_space_5d_sensitivity_ok": int(_flag(layer, "phase_space_5d_sensitivity_ok").sum()),
        "phase_space_6d_primary_ok": int(_flag(layer, "phase_space_6d_primary_ok").sum()),
        "phase_space_6d_sensitivity_ok": int(_flag(layer, "phase_space_6d_sensitivity_ok").sum()),
        "phase_space_6d_geo_alternative_ok": int(_flag(layer, "phase_space_6d_geo_alternative_ok").sum()),
    }
