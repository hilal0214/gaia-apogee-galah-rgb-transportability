from __future__ import annotations

import argparse
import hashlib
import itertools
import os
import sys
from pathlib import Path
from typing import Any

for _thread_variable in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ.setdefault(_thread_variable, "1")

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from stage5b_common import (
    BASE_FEATURES,
    atomic_write_csv,
    atomic_write_json,
    atomic_write_parquet,
    canonicalize_components,
    claim_ledger,
    close_logger,
    fit_with_deterministic_screening,
    flag,
    ids_sha256,
    k4_diagnostic_columns,
    load_config,
    method_definition,
    normalized_entropy,
    number,
    parameter_records,
    population_source_group,
    predict_responsibilities,
    project_path,
    read_json,
    responsibility_probability_columns,
    robust_scaler,
    selected_input_columns,
    setup_logger,
    sha256_file,
    view_inventory,
)


def resolve_paths(config: dict[str, Any], root: Path) -> dict[str, Path]:
    stage4a = project_path(root, config["paths"]["stage4a_output_dir"])
    stage5a = project_path(root, config["paths"]["stage5a_output_dir"])
    output = project_path(root, config["paths"]["output_dir"])
    a = config["stage4a_frozen"]
    s = config["stage5a_frozen"]
    paths = {"design_layer": stage4a / a["design_layer_file"]}
    for key, value in s.items():
        if key.endswith("_file"):
            paths[f"stage5a_{key.removesuffix('_file')}"] = stage5a / value
    for key, value in config["outputs"].items():
        if key.endswith("_file"):
            paths[key.removesuffix("_file")] = output / value
    return paths


def expected_input_hashes(config: dict[str, Any]) -> dict[str, str]:
    s = config["stage5a_frozen"]
    hashes = {"design_layer": str(config["stage4a_frozen"]["design_layer_sha256"])}
    for key, value in s.items():
        if key.endswith("_sha256") and key != "release_sha256":
            base = key.removesuffix("_sha256")
            if f"{base}_file" in s:
                hashes[f"stage5a_{base}"] = str(value)
    return hashes


def _feature_signature(features: tuple[str, ...], components: int, fold: int) -> str:
    digest = hashlib.sha256("|".join(features).encode("ascii")).hexdigest()[:12]
    return f"FEATURES_{digest}|K{components}|F{fold}"


def _responsibility_summary(
    responsibilities: pd.DataFrame,
    viability: pd.DataFrame,
    config: dict[str, Any],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for variant in view_inventory(config):
        prefix = f"{variant['slug']}_k{variant['components']}"
        probability_columns = [
            f"{prefix}_c{component}_p"
            for component in range(1, variant["components"] + 1)
        ]
        model_valid = bool(
            viability.loc[
                (viability.view == variant["name"])
                & (viability.k.astype(int) == variant["components"]),
                "downstream_eligible",
            ].iloc[0]
        )
        probability = responsibilities[probability_columns].to_numpy(float)
        maximum = probability.max(axis=1) if model_valid else np.full(len(probability), np.nan)
        entropy = normalized_entropy(probability) if model_valid else np.full(len(probability), np.nan)
        for component in range(variant["components"]):
            values = probability[:, component]
            rows.append(
                {
                    "view": variant["name"],
                    "k": variant["components"],
                    "component": f"C{component + 1}",
                    "model_valid": model_valid,
                    "rows": int(len(values)) if model_valid else 0,
                    "mean_responsibility": float(values.mean()) if model_valid else np.nan,
                    "effective_rows": float(values.sum()) if model_valid else np.nan,
                    "q10_responsibility": float(np.quantile(values, 0.10)) if model_valid else np.nan,
                    "q50_responsibility": float(np.quantile(values, 0.50)) if model_valid else np.nan,
                    "q90_responsibility": float(np.quantile(values, 0.90)) if model_valid else np.nan,
                    "mean_max_responsibility": float(maximum.mean()) if model_valid else np.nan,
                    "mean_normalized_entropy": float(entropy.mean()) if model_valid else np.nan,
                    "secure60_fraction": float(np.mean(maximum >= 0.60)) if model_valid else np.nan,
                    "secure70_fraction": float(np.mean(maximum >= 0.70)) if model_valid else np.nan,
                    "secure80_fraction": float(np.mean(maximum >= 0.80)) if model_valid else np.nan,
                }
            )
    return pd.DataFrame(rows)


def _component_stability(
    parameters: pd.DataFrame,
    feature_scaling: pd.DataFrame,
    viability: pd.DataFrame,
    config: dict[str, Any],
) -> pd.DataFrame:
    global_scale = feature_scaling.set_index("feature")["robust_scale"].astype(float).to_dict()
    rows: list[dict[str, Any]] = []
    for variant in view_inventory(config):
        features = variant["features"]
        for component in range(1, variant["components"] + 1):
            label = f"C{component}"
            weights: list[float] = []
            centroids: list[np.ndarray] = []
            for fold in range(int(config["stage5a_frozen"]["expected_folds"])):
                selected = parameters.loc[
                    (parameters.view == variant["name"])
                    & (parameters.k.astype(int) == variant["components"])
                    & (parameters.fold.astype(int) == fold)
                    & (parameters.component.fillna("") == label)
                ]
                weights.append(
                    float(selected.loc[selected.parameter_type == "WEIGHT", "value"].iloc[0])
                )
                centroids.append(
                    np.asarray(
                        [
                            float(
                                selected.loc[
                                    (selected.parameter_type == "MEAN_ORIGINAL")
                                    & (selected.feature_1 == feature),
                                    "value",
                                ].iloc[0]
                            )
                            for feature in features
                        ],
                        dtype=float,
                    )
                )
            centroid_array = np.asarray(centroids)
            median = np.median(centroid_array, axis=0)
            scales = np.asarray([global_scale[feature] for feature in features], dtype=float)
            distances = np.sqrt(np.sum(((centroid_array - median) / scales) ** 2, axis=1))
            vrot_index = features.index("v_rot_gc_kms")
            rows.append(
                {
                    "view": variant["name"],
                    "k": variant["components"],
                    "component": label,
                    "model_valid": bool(
                        viability.loc[
                            (viability.view == variant["name"])
                            & (viability.k.astype(int) == variant["components"]),
                            "downstream_eligible",
                        ].iloc[0]
                    ),
                    "folds": len(centroids),
                    "mean_weight": float(np.mean(weights)),
                    "minimum_weight": float(np.min(weights)),
                    "maximum_weight": float(np.max(weights)),
                    "weight_range": float(np.max(weights) - np.min(weights)),
                    "maximum_standardized_centroid_distance": float(distances.max()),
                    "mean_vrot_kms": float(centroid_array[:, vrot_index].mean()),
                    "minimum_vrot_kms": float(centroid_array[:, vrot_index].min()),
                    "maximum_vrot_kms": float(centroid_array[:, vrot_index].max()),
                }
            )
    return pd.DataFrame(rows)


def _crossview_stability(
    responsibilities: pd.DataFrame, config: dict[str, Any]
) -> pd.DataFrame:
    views = [row for row in view_inventory(config) if row["components"] == 4]
    rows: list[dict[str, Any]] = []
    for left, right in itertools.combinations(views, 2):
        left_probability = responsibilities[
            [f"{left['slug']}_k4_c{component}_p" for component in range(1, 5)]
        ].to_numpy(float)
        right_probability = responsibilities[
            [f"{right['slug']}_k4_c{component}_p" for component in range(1, 5)]
        ].to_numpy(float)
        midpoint = 0.5 * (left_probability + right_probability)
        left_safe = np.clip(left_probability, 1.0e-300, 1.0)
        right_safe = np.clip(right_probability, 1.0e-300, 1.0)
        midpoint_safe = np.clip(midpoint, 1.0e-300, 1.0)
        divergence = 0.5 * np.sum(
            left_safe * np.log(left_safe / midpoint_safe)
            + right_safe * np.log(right_safe / midpoint_safe),
            axis=1,
        ) / np.log(2.0)
        left_max = left_probability.max(axis=1)
        right_max = right_probability.max(axis=1)
        rows.append(
            {
                "left_view": left["name"],
                "right_view": right["name"],
                "rows": int(len(divergence)),
                "mean_jensen_shannon_divergence": float(divergence.mean()),
                "median_jensen_shannon_divergence": float(np.median(divergence)),
                "p90_jensen_shannon_divergence": float(np.quantile(divergence, 0.90)),
                "p95_jensen_shannon_divergence": float(np.quantile(divergence, 0.95)),
                "ordered_argmax_agreement": float(
                    np.mean(np.argmax(left_probability, axis=1) == np.argmax(right_probability, axis=1))
                ),
                "both_secure70_fraction": float(np.mean((left_max >= 0.70) & (right_max >= 0.70))),
            }
        )
    return pd.DataFrame(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Fit Stage 5B cross-fitted Student-t mixtures")
    parser.add_argument("--config", default="config/stage5b.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    paths = resolve_paths(config, root)
    output_dir = project_path(root, config["paths"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    logger = setup_logger(
        project_path(root, config["paths"]["log_dir"]) / "34_fit_stage5b.log",
        "stage5b.fit",
    )
    try:
        expected_hashes = expected_input_hashes(config)
        missing = [str(paths[key]) for key in expected_hashes if not paths[key].is_file()]
        if missing:
            raise FileNotFoundError("Missing frozen Stage 4A/5A input: " + "; ".join(missing))
        observed_hashes = {key: sha256_file(paths[key]) for key in expected_hashes}
        if observed_hashes != expected_hashes:
            mismatch = {
                key: {"expected": expected_hashes[key], "observed": observed_hashes[key]}
                for key in expected_hashes
                if expected_hashes[key] != observed_hashes[key]
            }
            raise RuntimeError(f"Frozen upstream byte identity failed: {mismatch}")

        validation = read_json(paths["stage5a_validation"])
        expected_gates = int(config["stage5a_frozen"]["expected_validation_gates"])
        if not bool(validation.get("overall_passed")) or [
            int(validation.get("n_passed", -1)),
            int(validation.get("n_gates", -1)),
        ] != [expected_gates, expected_gates]:
            raise RuntimeError("Stage 5A is not frozen 20/20 PASS")

        metadata = pq.ParquetFile(paths["design_layer"]).metadata
        a = config["stage4a_frozen"]
        if [metadata.num_rows, metadata.num_columns] != [
            int(a["expected_rows"]),
            int(a["expected_columns"]),
        ]:
            raise RuntimeError("Stage 4A design-layer metadata differs from the frozen contract")
        logger.info("Reading Stage 5B feature columns for %s candidates", metadata.num_rows)
        layer = pq.read_table(paths["design_layer"], columns=selected_input_columns()).to_pandas()
        all_ids = pd.to_numeric(layer.gaia_dr3_source_id, errors="raise").to_numpy(np.int64)
        if (
            ids_sha256(all_ids) != str(a["expected_candidate_id_sha256"])
            or len(np.unique(all_ids)) != len(all_ids)
            or not np.all(all_ids > 0)
            or not np.all(all_ids[1:] > all_ids[:-1])
        ):
            raise RuntimeError("Stage 4A candidate identity/order is not frozen")

        primary = flag(layer, "population_feature_primary_ok")
        frame_stable = flag(layer, "population_feature_frame_stable_ok")
        common_support = flag(
            layer, "population_feature_gradient_common_support_sensitivity_ok"
        )
        if int(primary.sum()) != int(config["stage5a_frozen"]["expected_primary_rows"]):
            raise RuntimeError("Stage 5A primary cohort count changed")
        if np.any(frame_stable & ~primary) or np.any(common_support & ~primary):
            raise RuntimeError("Stage 5A sensitivity cohorts are not subsets of primary")
        for feature in BASE_FEATURES:
            if not np.isfinite(number(layer, feature)[primary]).all():
                raise RuntimeError(f"Primary feature is not finite: {feature}")

        fold_map = pd.read_csv(paths["stage5a_spatial_fold_map"])
        block_to_fold = dict(
            zip(
                pd.to_numeric(fold_map.gaia_healpix5, errors="raise").astype(np.int64),
                pd.to_numeric(fold_map.fold, errors="raise").astype(np.int8),
                strict=True,
            )
        )
        block_vector = pd.to_numeric(layer.gaia_healpix5, errors="raise").to_numpy(np.int64)
        try:
            fold_vector = np.asarray([block_to_fold[int(block)] for block in block_vector], dtype=np.int8)
        except KeyError as error:
            raise RuntimeError(f"Stage 5A fold map misses block {error}") from error
        folds = int(config["stage5a_frozen"]["expected_folds"])
        if set(np.unique(fold_vector)) != set(range(folds)):
            raise RuntimeError("Stage 5A fold map does not cover five folds")

        primary_index = np.flatnonzero(primary)
        primary_ids = all_ids[primary]
        primary_positions = np.full(len(layer), -1, dtype=np.int64)
        primary_positions[primary_index] = np.arange(len(primary_index), dtype=np.int64)
        source_group = population_source_group(layer)
        responsibility = pd.DataFrame(
            {
                "gaia_dr3_source_id": primary_ids,
                "gaia_healpix5": block_vector[primary],
                "crossfit_fold": fold_vector[primary],
                "population_source_group": source_group[primary],
                "frame_stable_sensitivity_ok": frame_stable[primary],
                "common_support_sensitivity_ok": common_support[primary],
            }
        )
        for column in responsibility_probability_columns(config):
            responsibility[column] = np.full(len(responsibility), np.nan, dtype=np.float32)

        parameter_rows: list[dict[str, Any]] = []
        diagnostic_rows: list[dict[str, Any]] = []
        restart_rows: list[dict[str, Any]] = []
        viability_rows: list[dict[str, Any]] = []
        fit_cache: dict[tuple[tuple[str, ...], int, int], dict[str, Any]] = {}
        policy = config["population_inference"]
        mixture = policy["mixture"]
        scaling = policy["scaling"]
        order_features = tuple(policy["component_alignment"]["order_features"])

        for variant in view_inventory(config):
            view = variant["name"]
            slug = variant["slug"]
            features = variant["features"]
            components = variant["components"]
            values_all = layer.loc[:, list(features)].apply(pd.to_numeric, errors="coerce").to_numpy(float)
            logger.info("Fitting %s K=%s with %s features", view, components, len(features))
            variant_strict_flags: list[bool] = []
            variant_failure_modes: list[str] = []
            for fold in range(folds):
                train = primary & (fold_vector != fold)
                holdout = primary & (fold_vector == fold)
                if np.any(train & holdout) or not np.all((train | holdout)[primary]):
                    raise RuntimeError(f"Cross-fit exclusion failed for fold {fold}")
                cache_key = (features, components, fold)
                model_id = f"{view}|K{components}|F{fold}"
                fit_signature = _feature_signature(features, components, fold)
                reused = cache_key in fit_cache
                if not reused:
                    center, scale = robust_scaler(
                        values_all[train],
                        float(scaling["mad_to_sigma"]),
                        float(scaling["minimum_scale"]),
                    )
                    train_standardized = (values_all[train] - center) / scale
                    fit, audit, screen_rows, strictly_valid = fit_with_deterministic_screening(
                        train_standardized, components, config, fit_signature
                    )
                    fit = canonicalize_components(
                        fit, features, center, scale, order_features
                    )
                    holdout_standardized = (values_all[holdout] - center) / scale
                    prediction, holdout_log_density = predict_responsibilities(
                        holdout_standardized,
                        fit.weights,
                        fit.means,
                        fit.covariances,
                        float(mixture["degrees_of_freedom"]),
                    )
                    fit_cache[cache_key] = {
                        "center": center,
                        "scale": scale,
                        "fit": fit,
                        "audit": audit,
                        "screen_rows": screen_rows,
                        "prediction": prediction,
                        "holdout_log_density": holdout_log_density,
                        "strictly_valid": strictly_valid,
                    }
                cached = fit_cache[cache_key]
                center = cached["center"]
                scale = cached["scale"]
                fit = cached["fit"]
                audit = cached["audit"]
                prediction = cached["prediction"]
                holdout_log_density = cached["holdout_log_density"]
                strictly_valid = bool(cached["strictly_valid"])
                variant_strict_flags.append(strictly_valid)
                if not strictly_valid:
                    failures: list[str] = []
                    if not fit.converged:
                        failures.append("NONCONVERGENCE")
                    if not fit.monotonic:
                        failures.append("NONMONOTONIC")
                    if float(fit.weights.min()) < float(mixture["minimum_component_fraction"]):
                        failures.append("COMPONENT_FLOOR")
                    variant_failure_modes.append(
                        f"F{fold}:" + "+".join(failures or ["UNKNOWN_VALIDITY_FAILURE"])
                    )

                positions = primary_positions[np.flatnonzero(holdout)]
                for component in range(components):
                    column = f"{slug}_k{components}_c{component + 1}_p"
                    responsibility.loc[positions, column] = prediction[:, component].astype(np.float32)

                parameter_rows.extend(
                    parameter_records(
                        view, components, fold, features, center, scale, fit
                    )
                )
                full_objectives = sorted(
                    [
                        float(row["full_log_likelihood"])
                        for row in audit
                        if bool(row["selected_for_full_refinement"])
                        and np.isfinite(float(row["full_log_likelihood"]))
                        and bool(row["full_converged"])
                        and bool(row["full_monotonic"])
                        and float(row["full_minimum_component_fraction"])
                        >= float(mixture["minimum_component_fraction"])
                    ],
                    reverse=True,
                )
                selected_restart = int(
                    next(row["restart"] for row in audit if bool(row["selected_final"]))
                )
                original_means = fit.means * scale[None, :] + center[None, :]
                vrot_index = features.index("v_rot_gc_kms")
                vrot_means = original_means[:, vrot_index]
                responsibility_error = float(
                    np.max(np.abs(prediction.sum(axis=1) - 1.0))
                )
                entropy = normalized_entropy(prediction)
                maximum = prediction.max(axis=1)
                diagnostic_rows.append(
                    {
                        "view": view,
                        "k": components,
                        "fold": fold,
                        "model_id": model_id,
                        "fit_signature": fit_signature,
                        "fit_reused": reused,
                        "strictly_valid": strictly_valid,
                        "features": "|".join(features),
                        "train_rows": int(train.sum()),
                        "holdout_rows": int(holdout.sum()),
                        "train_blocks": int(np.unique(block_vector[train]).size),
                        "holdout_blocks": int(np.unique(block_vector[holdout]).size),
                        "screen_rows": int(cached["screen_rows"]),
                        "selected_restart": selected_restart,
                        "full_refinement_count": int(
                            sum(bool(row["selected_for_full_refinement"]) for row in audit)
                        ),
                        "validity_rescue_refinement_count": int(
                            sum(bool(row["validity_rescue_refinement"]) for row in audit)
                        ),
                        "log_likelihood": fit.log_likelihood,
                        "log_likelihood_per_train_row": fit.log_likelihood / int(train.sum()),
                        "refinement_log_likelihood_gap_per_row": (
                            (full_objectives[0] - full_objectives[1]) / int(train.sum())
                            if len(full_objectives) > 1
                            else np.nan
                        ),
                        "iterations": fit.iterations,
                        "converged": fit.converged,
                        "monotonic": fit.monotonic,
                        "last_relative_improvement": fit.last_relative_improvement,
                        "minimum_component_fraction": float(fit.weights.min()),
                        "weight_sum_error": float(abs(fit.weights.sum() - 1.0)),
                        "minimum_covariance_eigenvalue": fit.minimum_eigenvalue,
                        "maximum_covariance_condition_number": fit.maximum_condition_number,
                        "minimum_adjacent_vrot_mean_gap_kms": float(np.min(np.diff(vrot_means))),
                        "holdout_mean_log_density": float(np.mean(holdout_log_density)),
                        "responsibility_sum_max_abs_error": responsibility_error,
                        "mean_normalized_entropy": float(entropy.mean()),
                        "secure60_fraction": float(np.mean(maximum >= 0.60)),
                        "secure70_fraction": float(np.mean(maximum >= 0.70)),
                        "secure80_fraction": float(np.mean(maximum >= 0.80)),
                    }
                )
                logger.info(
                    "Completed %s K=%s fold=%s converged=%s iterations=%s min_weight=%.6f refinements=%s reused=%s",
                    view,
                    components,
                    fold,
                    fit.converged,
                    fit.iterations,
                    float(fit.weights.min()),
                    int(sum(bool(row["selected_for_full_refinement"]) for row in audit)),
                    reused,
                )
                for row in audit:
                    copied = dict(row)
                    copied.update(
                        {
                            "view": view,
                            "k": components,
                            "fold": fold,
                            "fit_signature": fit_signature,
                            "fit_reused": reused,
                        }
                    )
                    restart_rows.append(copied)

            required_sensitivity = {
                int(value)
                for value in policy["responsibility_policy"]["required_sensitivity_components"]
            }
            optional_stress = {
                int(value)
                for value in policy["responsibility_policy"]["optional_stress_components"]
            }
            role = (
                "NOMINAL"
                if components == int(policy["responsibility_policy"]["nominal_components"])
                else "REQUIRED_SENSITIVITY"
                if components in required_sensitivity
                else "OPTIONAL_STRESS"
                if components in optional_stress
                else "UNDECLARED"
            )
            all_folds_valid = bool(all(variant_strict_flags))
            if role != "OPTIONAL_STRESS" and not all_folds_valid:
                raise RuntimeError(f"Required Stage 5B model failed strict validity: {view}/K{components}")
            variant_probability_columns = [
                f"{slug}_k{components}_c{component}_p"
                for component in range(1, components + 1)
            ]
            if not all_folds_valid:
                responsibility.loc[:, variant_probability_columns] = np.nan
                logger.warning(
                    "Marking %s K=%s downstream-ineligible: %s",
                    view,
                    components,
                    ";".join(variant_failure_modes),
                )
            viability_rows.append(
                {
                    "view": view,
                    "k": components,
                    "role": role,
                    "folds": folds,
                    "strictly_valid_folds": int(sum(variant_strict_flags)),
                    "invalid_folds": "|".join(
                        str(index)
                        for index, passed in enumerate(variant_strict_flags)
                        if not passed
                    ),
                    "failure_modes": "|".join(variant_failure_modes),
                    "all_folds_strictly_valid": all_folds_valid,
                    "responsibilities_released": all_folds_valid,
                    "downstream_eligible": all_folds_valid,
                }
            )

            if components == 4:
                prefix = f"{slug}_k4"
                probability = responsibility[
                    [f"{prefix}_c{component}_p" for component in range(1, 5)]
                ].to_numpy(float)
                if not np.isfinite(probability).all():
                    raise RuntimeError(f"Incomplete cross-fitted responsibilities for {view}")
                maximum = probability.max(axis=1)
                responsibility[f"{prefix}_max_p"] = maximum.astype(np.float32)
                responsibility[f"{prefix}_entropy_norm"] = normalized_entropy(probability).astype(np.float32)
                responsibility[f"{prefix}_secure60"] = maximum >= 0.60
                responsibility[f"{prefix}_secure70"] = maximum >= 0.70
                responsibility[f"{prefix}_secure80"] = maximum >= 0.80

        probability_columns = responsibility_probability_columns(config)
        diagnostic_columns = k4_diagnostic_columns(config)
        viability = pd.DataFrame(viability_rows)
        for variant in view_inventory(config):
            columns = [
                f"{variant['slug']}_k{variant['components']}_c{component}_p"
                for component in range(1, variant["components"] + 1)
            ]
            valid = bool(
                viability.loc[
                    (viability.view == variant["name"])
                    & (viability.k.astype(int) == variant["components"]),
                    "downstream_eligible",
                ].iloc[0]
            )
            if valid and responsibility[columns].isna().any().any():
                raise RuntimeError(f"Valid Stage 5B model has incomplete probabilities: {variant['name']}/K{variant['components']}")
            if not valid and not responsibility[columns].isna().all().all():
                raise RuntimeError(f"Invalid Stage 5B model leaked responsibilities: {variant['name']}/K{variant['components']}")
        expected_columns = [
            "gaia_dr3_source_id",
            "gaia_healpix5",
            "crossfit_fold",
            "population_source_group",
            "frame_stable_sensitivity_ok",
            "common_support_sensitivity_ok",
            *probability_columns,
            *diagnostic_columns,
        ]
        responsibility = responsibility.loc[:, expected_columns]
        parameters = pd.DataFrame(parameter_rows)
        diagnostics = pd.DataFrame(diagnostic_rows)
        restart_audit = pd.DataFrame(restart_rows)
        summary = _responsibility_summary(responsibility, viability, config)
        feature_scaling = pd.read_csv(paths["stage5a_feature_scaling"])
        stability = _component_stability(parameters, feature_scaling, viability, config)
        crossview = _crossview_stability(responsibility, config)
        method = method_definition(config, observed_hashes)
        claims = claim_ledger(config)

        atomic_write_parquet(responsibility, paths["responsibility_layer"])
        atomic_write_csv(parameters, paths["model_parameters"])
        atomic_write_csv(diagnostics, paths["fit_diagnostics"])
        atomic_write_csv(restart_audit, paths["restart_audit"])
        atomic_write_csv(summary, paths["responsibility_summary"])
        atomic_write_csv(stability, paths["component_stability"])
        atomic_write_csv(crossview, paths["crossview_stability"])
        atomic_write_csv(viability, paths["model_viability"])
        atomic_write_json(method, paths["method_definition"])
        atomic_write_csv(claims, paths["claim_ledger"])

        science_keys = (
            "responsibility_layer",
            "model_parameters",
            "fit_diagnostics",
            "restart_audit",
            "responsibility_summary",
            "component_stability",
            "crossview_stability",
            "model_viability",
            "method_definition",
            "claim_ledger",
        )
        output_hashes = {paths[key].name: sha256_file(paths[key]) for key in science_keys}
        counts = {
            "candidate_rows": int(len(layer)),
            "primary_rows": int(primary.sum()),
            "frame_stable_rows": int(frame_stable.sum()),
            "common_support_rows": int(common_support.sum()),
            "crossfit_folds": folds,
            "view_component_variants": int(len(view_inventory(config))),
            "view_fold_models": int(len(diagnostics)),
            "unique_fold_fits": int(diagnostics.fit_signature.nunique()),
            "restart_audit_rows": int(len(restart_audit)),
            "unique_restart_evaluations": int(
                restart_audit.loc[~restart_audit.fit_reused.astype(bool), ["fit_signature", "restart"]]
                .drop_duplicates()
                .shape[0]
            ),
            "model_parameter_rows": int(len(parameters)),
            "responsibility_rows": int(len(responsibility)),
            "responsibility_columns": int(len(responsibility.columns)),
            "probability_columns": int(len(probability_columns)),
            "k4_view_diagnostic_columns": int(len(diagnostic_columns)),
            "component_summary_rows": int(len(summary)),
            "crossview_pairs": int(len(crossview)),
            "model_viability_rows": int(len(viability)),
            "downstream_eligible_variants": int(viability.downstream_eligible.astype(bool).sum()),
            "downstream_ineligible_optional_stress_variants": int(
                ((viability.role == "OPTIONAL_STRESS") & ~viability.downstream_eligible.astype(bool)).sum()
            ),
        }
        required_diagnostics = diagnostics.loc[diagnostics.k.astype(int).isin([3, 4])]
        valid_stability = stability.loc[stability.model_valid.astype(bool)]
        build_summary = {
            "stage": "5B leakage-safe cross-fitted population inference",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": str(config["project"]["frozen_created_utc"]),
            "input_sha256": observed_hashes,
            "output_sha256": output_hashes,
            "candidate_id_sha256": ids_sha256(all_ids),
            "primary_id_sha256": ids_sha256(primary_ids),
            "counts": counts,
            "fit_quality": {
                "all_required_models_strictly_valid": bool(
                    required_diagnostics.strictly_valid.astype(bool).all()
                ),
                "all_required_models_converged": bool(
                    required_diagnostics.converged.astype(bool).all()
                ),
                "all_monotonic": bool(diagnostics.monotonic.astype(bool).all()),
                "minimum_required_component_fraction": float(
                    required_diagnostics.minimum_component_fraction.min()
                ),
                "maximum_covariance_condition_number": float(
                    diagnostics.maximum_covariance_condition_number.max()
                ),
                "minimum_covariance_eigenvalue": float(
                    diagnostics.minimum_covariance_eigenvalue.min()
                ),
                "maximum_responsibility_sum_error": float(
                    diagnostics.responsibility_sum_max_abs_error.max()
                ),
                "maximum_fold_centroid_distance": float(
                    valid_stability.maximum_standardized_centroid_distance.max()
                ),
                "downstream_ineligible_optional_stress_models": [
                    f"{row.view}/K{int(row.k)}"
                    for row in viability.loc[
                        (viability.role == "OPTIONAL_STRESS")
                        & ~viability.downstream_eligible.astype(bool)
                    ].itertuples()
                ],
            },
            "responsibility_quality": {
                row["name"]: {
                    "secure70_fraction": float(
                        responsibility[f"{row['slug']}_k4_secure70"].mean()
                    ),
                    "mean_normalized_entropy": float(
                        responsibility[f"{row['slug']}_k4_entropy_norm"].mean()
                    ),
                }
                for row in view_inventory(config)
                if row["components"] == 4
            },
            "maximum_crossview_p95_jsd": float(
                crossview.p95_jensen_shannon_divergence.max()
            ),
            "science_boundary": config["science_boundary"],
            "runtime": {
                "numpy": np.__version__,
                "pandas": pd.__version__,
                "scipy": __import__("scipy").__version__,
                "pyarrow": pa.__version__,
            },
        }
        atomic_write_json(build_summary, paths["build_summary"])
        freeze_hashes = dict(output_hashes)
        freeze_hashes[paths["build_summary"].name] = sha256_file(paths["build_summary"])
        freeze = {
            "stage": "5B responsibility freeze",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": str(config["project"]["frozen_created_utc"]),
            "input_sha256": observed_hashes,
            "output_sha256": freeze_hashes,
            "candidate_id_sha256": ids_sha256(all_ids),
            "primary_id_sha256": ids_sha256(primary_ids),
            "counts": counts,
            "science_boundary": config["science_boundary"],
        }
        atomic_write_json(freeze, paths["freeze_manifest"])
        logger.info(
            "Stage 5B fit complete: primary=%s variants=%s fold_models=%s restarts=%s",
            counts["primary_rows"],
            counts["view_component_variants"],
            counts["view_fold_models"],
            counts["restart_audit_rows"],
        )
        print(
            "Stage 5B fit complete: "
            f"primary={counts['primary_rows']} variants={counts['view_component_variants']} "
            f"fold_models={counts['view_fold_models']} restarts={counts['restart_audit_rows']}"
        )
        return 0
    finally:
        close_logger(logger)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
