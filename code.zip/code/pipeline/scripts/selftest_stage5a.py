from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from stage5a_common import (
    BASE_FEATURES,
    compute_design_outputs,
    fold_for_block,
    ids_sha256,
    load_config,
    population_source_group,
    selected_input_columns,
)


def fixture(rows: int = 6000) -> pd.DataFrame:
    rng = np.random.Generator(np.random.PCG64DXSM(5102026))
    ids = np.arange(10_000_000_000_000, 10_000_000_000_000 + rows, dtype=np.int64)
    source = np.where(np.arange(rows) % 2 == 0, "APOGEE_NATIVE", "GALAH_CORRECTED")
    primary = np.arange(rows) % 17 != 0
    frame = primary & (np.arange(rows) % 23 != 0)
    common = primary & (np.arange(rows) % 5 != 0)
    frame_data = pd.DataFrame({
        "gaia_dr3_source_id": ids,
        "survey_origin": np.where(source == "APOGEE_NATIVE", "APOGEE", "GALAH"),
        "preferred_spectroscopic_survey": np.where(source == "APOGEE_NATIVE", "APOGEE", "GALAH"),
        "analysis_teff": 4650 + rng.normal(0, 250, rows),
        "analysis_logg": 2.4 + rng.normal(0, 0.4, rows),
        "fe_h_hom": -0.3 + rng.normal(0, 0.5, rows),
        "fe_h_hom_error_proxy": np.full(rows, 0.05),
        "fe_h_hom_source": source,
        "fe_h_hom_support_tier": np.where(common, "COMMON_SUPPORT", "VALIDATED"),
        "alpha3_hom": 0.08 + rng.normal(0, 0.08, rows),
        "alpha3_hom_error_proxy": np.full(rows, 0.03),
        "alpha3_source": source,
        "v_R_gc_kms": rng.normal(0, 45, rows),
        "v_rot_gc_kms": rng.normal(190, 60, rows),
        "v_z_gc_kms": rng.normal(0, 35, rows),
        "v_rot_gc_kms_geo_alt": rng.normal(190, 60, rows),
        "v_R_gc_kms__halfwidth": np.full(rows, 0.8),
        "v_rot_gc_kms__halfwidth": np.full(rows, 0.9),
        "v_z_gc_kms__halfwidth": np.full(rows, 0.7),
        "frame_vrot_sign_stable": frame,
        "gaia_healpix5": np.arange(rows, dtype=np.int64) % 257,
        "r_cyl_gc_kpc": rng.uniform(3.1, 14.9, rows),
        "abs_z_gc_kpc": rng.uniform(0, 5, rows),
        "population_feature_primary_ok": primary,
        "population_feature_frame_stable_ok": frame,
        "population_feature_gradient_common_support_sensitivity_ok": common,
    })
    return frame_data.loc[:, selected_input_columns()]


def main() -> int:
    parser = argparse.ArgumentParser(description="Stage 5A logic self-test")
    parser.add_argument("--config", default="config/stage5a.yml")
    args = parser.parse_args()
    config, _ = load_config(args.config)
    frame = fixture()
    outputs = compute_design_outputs(frame, config)
    checks: list[bool] = []
    checks.append(list(frame.columns) == selected_input_columns())
    checks.append(len(np.unique(frame.gaia_dr3_source_id)) == len(frame))
    checks.append(len(ids_sha256(frame.gaia_dr3_source_id)) == 64)
    checks.append(tuple(outputs["feature_scaling"].feature) == BASE_FEATURES)
    checks.append(np.all(outputs["feature_scaling"].robust_scale > 0))
    checks.append(outputs["spatial_fold_map"].gaia_healpix5.nunique() == len(outputs["spatial_fold_map"]))
    checks.append(set(outputs["spatial_fold_summary"].fold.astype(int)) == set(range(5)))
    checks.append(abs(float(outputs["spatial_fold_summary"].primary_fraction.sum()) - 1.0) < 1.0e-12)
    checks.append(outputs["feature_correlation"].shape == (15, 5))
    checks.append(outputs["survey_feature_balance"].shape == (10, 13))
    checks.append(outputs["leakage_audit"].passes_leakage_contract.astype(bool).all())
    checks.append(not outputs["leakage_audit"].features.str.contains("r_cyl_gc_kpc|abs_z_gc_kpc", regex=True).any())
    checks.append("fe_h_hom" not in outputs["leakage_audit"].loc[outputs["leakage_audit"].target == "fe_h", "features"].iloc[0])
    checks.append("alpha3_hom" not in outputs["leakage_audit"].loc[outputs["leakage_audit"].target == "alpha3", "features"].iloc[0])
    block = int(frame.gaia_healpix5.iloc[0])
    policy = config["population_design"]["cross_fitting"]
    checks.append(fold_for_block(block, policy["assignment_namespace"], policy["folds"]) == fold_for_block(block, policy["assignment_namespace"], policy["folds"]))
    if not all(checks):
        failed = [index + 1 for index, value in enumerate(checks) if not value]
        raise AssertionError(f"Stage 5A self-test failures: {failed}")
    print(f"Stage 5A logic self-test passed: {sum(checks)}/{len(checks)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
