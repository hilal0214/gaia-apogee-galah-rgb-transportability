from __future__ import annotations

import argparse
import hashlib
import itertools
import os
import sys
from pathlib import Path
from typing import Any

for _thread_variable in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ.setdefault(_thread_variable, "1")

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from stage5b_common import (
    BASE_FEATURES,
    atomic_write_json,
    close_logger,
    flag,
    ids_sha256,
    k4_diagnostic_columns,
    load_config,
    normalized_entropy,
    number,
    population_source_group,
    predict_responsibilities,
    project_path,
    read_json,
    reconstruct_standardized_parameters,
    responsibility_probability_columns,
    robust_scaler,
    selected_input_columns,
    setup_logger,
    sha256_file,
    stable_seed,
    validation_report,
    view_inventory,
)


def resolve_paths(config: dict[str, Any], root: Path) -> dict[str, Path]:
    stage4a = project_path(root, config["paths"]["stage4a_output_dir"])
    stage5a = project_path(root, config["paths"]["stage5a_output_dir"])
    output = project_path(root, config["paths"]["output_dir"])
    paths = {
        "design_layer": stage4a / config["stage4a_frozen"]["design_layer_file"]
    }
    for key, value in config["stage5a_frozen"].items():
        if key.endswith("_file"):
            paths[f"stage5a_{key.removesuffix('_file')}"] = stage5a / value
    for key, value in config["outputs"].items():
        if key.endswith("_file"):
            paths[key.removesuffix("_file")] = output / value
    return paths


def expected_input_hashes(config: dict[str, Any]) -> dict[str, str]:
    stage5a = config["stage5a_frozen"]
    hashes = {"design_layer": str(config["stage4a_frozen"]["design_layer_sha256"])}
    for key, value in stage5a.items():
        if key.endswith("_sha256") and key != "release_sha256":
            base = key.removesuffix("_sha256")
            if f"{base}_file" in stage5a:
                hashes[f"stage5a_{base}"] = str(value)
    return hashes


def frame_matches(actual: pd.DataFrame, expected: pd.DataFrame, tolerance: float) -> bool:
    if actual.shape != expected.shape or list(actual.columns) != list(expected.columns):
        return False
    for column in actual.columns:
        actual_numeric = pd.to_numeric(actual[column], errors="coerce")
        expected_numeric = pd.to_numeric(expected[column], errors="coerce")
        numeric = actual_numeric.notna() | expected_numeric.notna()
        if bool(numeric.any()):
            if not np.allclose(
                actual_numeric[numeric].to_numpy(float),
                expected_numeric[numeric].to_numpy(float),
                rtol=0.0,
                atol=tolerance,
                equal_nan=True,
            ):
                return False
            missing = actual_numeric.isna() & expected_numeric.isna()
            if not actual.loc[missing, column].astype("string").fillna("<NA>").equals(
                expected.loc[missing, column].astype("string").fillna("<NA>")
            ):
                return False
        elif not actual[column].astype("string").fillna("<NA>").equals(
            expected[column].astype("string").fillna("<NA>")
        ):
            return False
    return True


def gate(
    name: str,
    passed: bool,
    detail: str,
    expected: Any = None,
    observed: Any = None,
) -> dict[str, Any]:
    row: dict[str, Any] = {"name": name, "passed": bool(passed), "detail": detail}
    if expected is not None:
        row["expected"] = expected
    if observed is not None:
        row["observed"] = observed
    return row


def _feature_signature(features: tuple[str, ...], components: int, fold: int) -> str:
    digest = hashlib.sha256("|".join(features).encode("ascii")).hexdigest()[:12]
    return f"FEATURES_{digest}|K{components}|F{fold}"


def _expected_summary(
    responsibility: pd.DataFrame,
    viability: pd.DataFrame,
    config: dict[str, Any],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for variant in view_inventory(config):
        prefix = f"{variant['slug']}_k{variant['components']}"
        columns = [
            f"{prefix}_c{component}_p"
            for component in range(1, variant["components"] + 1)
        ]
        model_valid = bool(
            viability.loc[
                (viability.view == variant["name"])
                & (viability.k.astype(int) == variant["components"]),
                "downstream_eligible",
            ].iloc[0]
        )
        probability = responsibility[columns].to_numpy(float)
        maximum = probability.max(axis=1) if model_valid else np.full(len(probability), np.nan)
        entropy = normalized_entropy(probability) if model_valid else np.full(len(probability), np.nan)
        for component in range(variant["components"]):
            values = probability[:, component]
            rows.append(
                {
                    "view": variant["name"],
                    "k": variant["components"],
                    "component": f"C{component + 1}",
                    "model_valid": model_valid,
                    "rows": int(len(values)) if model_valid else 0,
                    "mean_responsibility": float(values.mean()) if model_valid else np.nan,
                    "effective_rows": float(values.sum()) if model_valid else np.nan,
                    "q10_responsibility": float(np.quantile(values, 0.10)) if model_valid else np.nan,
                    "q50_responsibility": float(np.quantile(values, 0.50)) if model_valid else np.nan,
                    "q90_responsibility": float(np.quantile(values, 0.90)) if model_valid else np.nan,
                    "mean_max_responsibility": float(maximum.mean()) if model_valid else np.nan,
                    "mean_normalized_entropy": float(entropy.mean()) if model_valid else np.nan,
                    "secure60_fraction": float(np.mean(maximum >= 0.60)) if model_valid else np.nan,
                    "secure70_fraction": float(np.mean(maximum >= 0.70)) if model_valid else np.nan,
                    "secure80_fraction": float(np.mean(maximum >= 0.80)) if model_valid else np.nan,
                }
            )
    return pd.DataFrame(rows)


def _expected_stability(
    parameters: pd.DataFrame,
    feature_scaling: pd.DataFrame,
    viability: pd.DataFrame,
    config: dict[str, Any],
) -> pd.DataFrame:
    global_scale = feature_scaling.set_index("feature")["robust_scale"].astype(float).to_dict()
    rows: list[dict[str, Any]] = []
    folds = int(config["stage5a_frozen"]["expected_folds"])
    for variant in view_inventory(config):
        features = variant["features"]
        for component in range(1, variant["components"] + 1):
            label = f"C{component}"
            weights: list[float] = []
            centroids: list[np.ndarray] = []
            for fold in range(folds):
                selected = parameters.loc[
                    (parameters.view == variant["name"])
                    & (parameters.k.astype(int) == variant["components"])
                    & (parameters.fold.astype(int) == fold)
                    & (parameters.component.fillna("") == label)
                ]
                weights.append(
                    float(selected.loc[selected.parameter_type == "WEIGHT", "value"].iloc[0])
                )
                centroids.append(
                    np.asarray(
                        [
                            float(
                                selected.loc[
                                    (selected.parameter_type == "MEAN_ORIGINAL")
                                    & (selected.feature_1 == feature),
                                    "value",
                                ].iloc[0]
                            )
                            for feature in features
                        ]
                    )
                )
            centroid_array = np.asarray(centroids)
            median = np.median(centroid_array, axis=0)
            scales = np.asarray([global_scale[feature] for feature in features])
            distances = np.sqrt(np.sum(((centroid_array - median) / scales) ** 2, axis=1))
            vrot_index = features.index("v_rot_gc_kms")
            rows.append(
                {
                    "view": variant["name"],
                    "k": variant["components"],
                    "component": label,
                    "model_valid": bool(
                        viability.loc[
                            (viability.view == variant["name"])
                            & (viability.k.astype(int) == variant["components"]),
                            "downstream_eligible",
                        ].iloc[0]
                    ),
                    "folds": folds,
                    "mean_weight": float(np.mean(weights)),
                    "minimum_weight": float(np.min(weights)),
                    "maximum_weight": float(np.max(weights)),
                    "weight_range": float(np.max(weights) - np.min(weights)),
                    "maximum_standardized_centroid_distance": float(distances.max()),
                    "mean_vrot_kms": float(centroid_array[:, vrot_index].mean()),
                    "minimum_vrot_kms": float(centroid_array[:, vrot_index].min()),
                    "maximum_vrot_kms": float(centroid_array[:, vrot_index].max()),
                }
            )
    return pd.DataFrame(rows)


def _expected_crossview(
    responsibility: pd.DataFrame, config: dict[str, Any]
) -> pd.DataFrame:
    views = [row for row in view_inventory(config) if row["components"] == 4]
    rows: list[dict[str, Any]] = []
    for left, right in itertools.combinations(views, 2):
        left_probability = responsibility[
            [f"{left['slug']}_k4_c{component}_p" for component in range(1, 5)]
        ].to_numpy(float)
        right_probability = responsibility[
            [f"{right['slug']}_k4_c{component}_p" for component in range(1, 5)]
        ].to_numpy(float)
        midpoint = 0.5 * (left_probability + right_probability)
        left_safe = np.clip(left_probability, 1.0e-300, 1.0)
        right_safe = np.clip(right_probability, 1.0e-300, 1.0)
        midpoint_safe = np.clip(midpoint, 1.0e-300, 1.0)
        divergence = 0.5 * np.sum(
            left_safe * np.log(left_safe / midpoint_safe)
            + right_safe * np.log(right_safe / midpoint_safe),
            axis=1,
        ) / np.log(2.0)
        left_max = left_probability.max(axis=1)
        right_max = right_probability.max(axis=1)
        rows.append(
            {
                "left_view": left["name"],
                "right_view": right["name"],
                "rows": len(divergence),
                "mean_jensen_shannon_divergence": float(divergence.mean()),
                "median_jensen_shannon_divergence": float(np.median(divergence)),
                "p90_jensen_shannon_divergence": float(np.quantile(divergence, 0.90)),
                "p95_jensen_shannon_divergence": float(np.quantile(divergence, 0.95)),
                "ordered_argmax_agreement": float(
                    np.mean(np.argmax(left_probability, axis=1) == np.argmax(right_probability, axis=1))
                ),
                "both_secure70_fraction": float(np.mean((left_max >= 0.70) & (right_max >= 0.70))),
            }
        )
    return pd.DataFrame(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Stage 5B cross-fitted population inference")
    parser.add_argument("--config", default="config/stage5b.yml")
    args = parser.parse_args()
    config, root = load_config(args.config)
    paths = resolve_paths(config, root)
    logger = setup_logger(
        project_path(root, config["paths"]["log_dir"]) / "35_validate_stage5b.log",
        "stage5b.validate",
    )
    try:
        tolerance = float(config["validation"]["parameter_absolute_tolerance"])
        probability_tolerance = float(config["validation"]["probability_absolute_tolerance"])
        expected_hashes = expected_input_hashes(config)
        observed_hashes = {key: sha256_file(paths[key]) for key in expected_hashes}
        stage5a_validation = read_json(paths["stage5a_validation"])
        stage5a_contract = read_json(paths["stage5a_design_contract"])
        stage5a_summary = read_json(paths["stage5a_build_summary"])

        metadata = pq.ParquetFile(paths["design_layer"]).metadata
        layer = pq.read_table(paths["design_layer"], columns=selected_input_columns()).to_pandas()
        all_ids = pd.to_numeric(layer.gaia_dr3_source_id, errors="raise").to_numpy(np.int64)
        primary = flag(layer, "population_feature_primary_ok")
        frame_stable = flag(layer, "population_feature_frame_stable_ok")
        common_support = flag(
            layer, "population_feature_gradient_common_support_sensitivity_ok"
        )
        primary_ids = all_ids[primary]
        blocks = pd.to_numeric(layer.gaia_healpix5, errors="raise").to_numpy(np.int64)
        fold_map = pd.read_csv(paths["stage5a_spatial_fold_map"])
        block_to_fold = dict(
            zip(
                pd.to_numeric(fold_map.gaia_healpix5).astype(np.int64),
                pd.to_numeric(fold_map.fold).astype(np.int8),
                strict=True,
            )
        )
        fold_vector = np.asarray([block_to_fold[int(block)] for block in blocks], dtype=np.int8)
        source_group = population_source_group(layer)

        responsibility = pq.read_table(paths["responsibility_layer"]).to_pandas()
        parameters = pd.read_csv(paths["model_parameters"], keep_default_na=True)
        diagnostics = pd.read_csv(paths["fit_diagnostics"])
        restart_audit = pd.read_csv(paths["restart_audit"])
        stored_summary = pd.read_csv(paths["responsibility_summary"])
        stored_stability = pd.read_csv(paths["component_stability"])
        stored_crossview = pd.read_csv(paths["crossview_stability"])
        viability = pd.read_csv(paths["model_viability"])
        feature_scaling = pd.read_csv(paths["stage5a_feature_scaling"])
        method = read_json(paths["method_definition"])
        claims = pd.read_csv(paths["claim_ledger"])
        build_summary = read_json(paths["build_summary"])
        freeze = read_json(paths["freeze_manifest"])

        gates: list[dict[str, Any]] = []
        gates.append(
            gate(
                "upstream_design_layer_byte_identity",
                observed_hashes["design_layer"] == expected_hashes["design_layer"],
                "the 393,834-row Stage 4A design layer remains byte-frozen",
            )
        )
        stage5a_keys = [key for key in expected_hashes if key.startswith("stage5a_")]
        gates.append(
            gate(
                "upstream_stage5a_byte_identity",
                all(observed_hashes[key] == expected_hashes[key] for key in stage5a_keys),
                "all accepted Stage 5A design/provenance bytes remain frozen",
            )
        )
        expected_stage5a_gates = int(config["stage5a_frozen"]["expected_validation_gates"])
        gates.append(
            gate(
                "upstream_stage5a_validation",
                bool(stage5a_validation.get("overall_passed"))
                and [stage5a_validation.get("n_passed"), stage5a_validation.get("n_gates")]
                == [expected_stage5a_gates, expected_stage5a_gates],
                "Stage 5A remains 20/20 PASS",
            )
        )
        contract_ok = (
            stage5a_contract.get("protocol_version") == "0.10.0"
            and stage5a_contract.get("counts", {}).get("population_feature_primary")
            == int(config["stage5a_frozen"]["expected_primary_rows"])
            and stage5a_summary.get("counts", {}).get("spatial_blocks")
            == int(config["stage5a_frozen"]["expected_spatial_blocks"])
        )
        gates.append(
            gate(
                "stage5a_design_contract_link",
                contract_ok,
                "Stage 5B is linked to the accepted leakage-safe Stage 5A contract and counts",
            )
        )
        a = config["stage4a_frozen"]
        identity_ok = (
            [metadata.num_rows, metadata.num_columns]
            == [int(a["expected_rows"]), int(a["expected_columns"])]
            and ids_sha256(all_ids) == str(a["expected_candidate_id_sha256"])
            and len(np.unique(all_ids)) == len(all_ids)
            and np.all(all_ids > 0)
            and np.all(all_ids[1:] > all_ids[:-1])
        )
        gates.append(
            gate(
                "candidate_identity_and_input_schema",
                identity_ok and list(layer.columns) == selected_input_columns(),
                "candidate identity/order and selected Stage 5B feature schema are exact",
            )
        )
        cohort_ok = (
            int(primary.sum()) == int(config["stage5a_frozen"]["expected_primary_rows"])
            and int(frame_stable.sum()) == int(config["stage5a_frozen"]["expected_frame_stable_rows"])
            and int(common_support.sum()) == int(config["stage5a_frozen"]["expected_common_support_rows"])
            and not np.any(frame_stable & ~primary)
            and not np.any(common_support & ~primary)
            and all(np.isfinite(number(layer, feature)[primary]).all() for feature in BASE_FEATURES)
        )
        gates.append(
            gate(
                "primary_and_sensitivity_cohort_identity",
                cohort_ok,
                "primary, frame-stable, and common-support cohorts remain exact and finite",
            )
        )
        folds = int(config["stage5a_frozen"]["expected_folds"])
        fold_ok = (
            len(fold_map) == int(config["stage5a_frozen"]["expected_spatial_blocks"])
            and fold_map.gaia_healpix5.nunique() == len(fold_map)
            and set(np.unique(fold_vector)) == set(range(folds))
            and all(
                np.intersect1d(
                    np.unique(blocks[primary & (fold_vector == fold)]),
                    np.unique(blocks[primary & (fold_vector != fold)]),
                ).size
                == 0
                for fold in range(folds)
            )
        )
        gates.append(
            gate(
                "spatial_fold_identity_and_exclusion",
                fold_ok,
                "each HEALPix-5 block has one frozen fold and no train/holdout overlap",
            )
        )
        target_to_feature = {"fe_h": "fe_h_hom", "alpha3": "alpha3_hom"}
        spatial = {"r_cyl_gc_kpc", "abs_z_gc_kpc"}
        view_ok = True
        for view in config["population_inference"]["model_views"]:
            features = set(view["features"])
            view_ok &= spatial.isdisjoint(features)
            if bool(view["allowed_for_population_gradient"]):
                for target in view["targets"]:
                    if target in target_to_feature:
                        view_ok &= target_to_feature[target] not in features
        gates.append(
            gate(
                "target_safe_view_contract",
                bool(view_ok) and len(view_inventory(config)) == 10,
                "R/abs(Z) are absent and Fe/H or alpha3 is excluded from its own classifier view",
            )
        )

        probability_columns = responsibility_probability_columns(config)
        diagnostic_columns = k4_diagnostic_columns(config)
        expected_columns = [
            "gaia_dr3_source_id",
            "gaia_healpix5",
            "crossfit_fold",
            "population_source_group",
            "frame_stable_sensitivity_ok",
            "common_support_sensitivity_ok",
            *probability_columns,
            *diagnostic_columns,
        ]
        expected_shape = [int(primary.sum()), len(expected_columns)]
        gates.append(
            gate(
                "responsibility_layer_shape_and_schema",
                list(responsibility.shape) == expected_shape
                and list(responsibility.columns) == expected_columns
                and not responsibility.columns.duplicated().any(),
                "the cross-fitted responsibility layer has the frozen row/column schema",
                expected_shape,
                list(responsibility.shape),
            )
        )
        responsibility_identity = (
            np.array_equal(
                pd.to_numeric(responsibility.gaia_dr3_source_id).to_numpy(np.int64),
                primary_ids,
            )
            and np.array_equal(
                pd.to_numeric(responsibility.gaia_healpix5).to_numpy(np.int64),
                blocks[primary],
            )
            and np.array_equal(
                pd.to_numeric(responsibility.crossfit_fold).to_numpy(np.int8),
                fold_vector[primary],
            )
            and np.array_equal(
                responsibility.population_source_group.astype(str).to_numpy(),
                source_group[primary],
            )
            and np.array_equal(
                responsibility.frame_stable_sensitivity_ok.astype(bool).to_numpy(),
                frame_stable[primary],
            )
            and np.array_equal(
                responsibility.common_support_sensitivity_ok.astype(bool).to_numpy(),
                common_support[primary],
            )
        )
        gates.append(
            gate(
                "responsibility_row_identity_and_cohorts",
                responsibility_identity,
                "primary IDs, blocks, folds, source groups, and sensitivity flags are exact",
            )
        )
        probability_values = responsibility[probability_columns].to_numpy(float)
        finite_probability_values = probability_values[np.isfinite(probability_values)]
        viability_schema_ok = (
            len(viability) == len(view_inventory(config))
            and viability[["view", "k"]].drop_duplicates().shape[0] == len(viability)
            and set(viability.role)
            == {"NOMINAL", "REQUIRED_SENSITIVITY", "OPTIONAL_STRESS"}
            and viability.loc[
                viability.role.isin(["NOMINAL", "REQUIRED_SENSITIVITY"]),
                "downstream_eligible",
            ].astype(bool).all()
            and (
                viability.responsibilities_released.astype(bool)
                == viability.downstream_eligible.astype(bool)
            ).all()
        )
        model_probability_contract_ok = viability_schema_ok
        for variant in view_inventory(config):
            columns = [
                f"{variant['slug']}_k{variant['components']}_c{component}_p"
                for component in range(1, variant["components"] + 1)
            ]
            valid = bool(
                viability.loc[
                    (viability.view == variant["name"])
                    & (viability.k.astype(int) == variant["components"]),
                    "downstream_eligible",
                ].iloc[0]
            )
            model_probability_contract_ok &= (
                responsibility[columns].notna().all().all()
                if valid
                else responsibility[columns].isna().all().all()
            )
        gates.append(
            gate(
                "responsibility_finiteness_and_bounds",
                model_probability_contract_ok
                and len(finite_probability_values) > 0
                and np.all(finite_probability_values >= -probability_tolerance)
                and np.all(finite_probability_values <= 1.0 + probability_tolerance),
                "valid model responsibilities are finite/bounded and invalid optional-stress views are wholly null",
            )
        )
        sum_errors: list[float] = []
        for variant in view_inventory(config):
            columns = [
                f"{variant['slug']}_k{variant['components']}_c{component}_p"
                for component in range(1, variant["components"] + 1)
            ]
            valid = bool(
                viability.loc[
                    (viability.view == variant["name"])
                    & (viability.k.astype(int) == variant["components"]),
                    "downstream_eligible",
                ].iloc[0]
            )
            if valid:
                sum_errors.append(
                    float(
                        np.max(
                            np.abs(responsibility[columns].to_numpy(float).sum(axis=1) - 1.0)
                        )
                    )
                )
        gates.append(
            gate(
                "responsibility_simplex_identity",
                max(sum_errors) <= float(config["validation"]["probability_sum_tolerance"]),
                "every view/K responsibility vector sums to one",
                float(config["validation"]["probability_sum_tolerance"]),
                max(sum_errors),
            )
        )
        coverage_ok = all(
            int(np.sum(responsibility.crossfit_fold.astype(int).to_numpy() == fold))
            == int(np.sum(primary & (fold_vector == fold)))
            for fold in range(folds)
        )
        gates.append(
            gate(
                "heldout_prediction_coverage",
                coverage_ok,
                "each primary row receives predictions exactly in its held-out spatial fold",
            )
        )

        parameter_schema = [
            "view",
            "k",
            "fold",
            "component",
            "parameter_type",
            "feature_1",
            "feature_2",
            "value",
        ]
        expected_parameter_rows = 0
        for variant in view_inventory(config):
            dimensions = len(variant["features"])
            per_fold = 2 * dimensions + variant["components"] * (
                1 + 2 * dimensions + dimensions * (dimensions + 1)
            )
            expected_parameter_rows += folds * per_fold
        gates.append(
            gate(
                "model_parameter_inventory",
                list(parameters.columns) == parameter_schema
                and len(parameters) == expected_parameter_rows
                and not parameters.duplicated().any(),
                "all fold/view/K scalers, weights, means, and full covariances are present once",
                expected_parameter_rows,
                len(parameters),
            )
        )

        scaling_policy = config["population_inference"]["scaling"]
        scaler_ok = True
        prediction_max_difference = 0.0
        parameter_quality_ok = True
        order_ok = True
        for variant in view_inventory(config):
            features = variant["features"]
            variant_valid = bool(
                viability.loc[
                    (viability.view == variant["name"])
                    & (viability.k.astype(int) == variant["components"]),
                    "downstream_eligible",
                ].iloc[0]
            )
            values = layer.loc[:, list(features)].apply(pd.to_numeric, errors="coerce").to_numpy(float)
            for fold in range(folds):
                train = primary & (fold_vector != fold)
                holdout = primary & (fold_vector == fold)
                expected_center, expected_scale = robust_scaler(
                    values[train],
                    float(scaling_policy["mad_to_sigma"]),
                    float(scaling_policy["minimum_scale"]),
                )
                center, scale, weights, means, covariances = reconstruct_standardized_parameters(
                    parameters,
                    variant["name"],
                    variant["components"],
                    fold,
                    features,
                )
                scaler_ok &= np.allclose(center, expected_center, rtol=0.0, atol=tolerance)
                scaler_ok &= np.allclose(scale, expected_scale, rtol=0.0, atol=tolerance)
                predicted, _ = predict_responsibilities(
                    (values[holdout] - center) / scale,
                    weights,
                    means,
                    covariances,
                    float(config["population_inference"]["mixture"]["degrees_of_freedom"]),
                )
                positions = np.flatnonzero(fold_vector[primary] == fold)
                columns = [
                    f"{variant['slug']}_k{variant['components']}_c{component}_p"
                    for component in range(1, variant["components"] + 1)
                ]
                stored = responsibility.loc[positions, columns].to_numpy(float)
                if variant_valid:
                    prediction_max_difference = max(
                        prediction_max_difference, float(np.max(np.abs(predicted - stored)))
                    )
                else:
                    parameter_quality_ok &= bool(np.isnan(stored).all())
                eigenvalues = np.asarray(
                    [np.linalg.eigvalsh(covariance) for covariance in covariances]
                )
                condition = eigenvalues[:, -1] / np.maximum(eigenvalues[:, 0], 1.0e-300)
                covariance_ok = (
                    abs(float(weights.sum()) - 1.0) <= tolerance
                    and float(eigenvalues.min())
                    >= float(config["validation"]["minimum_covariance_eigenvalue"])
                    and float(condition.max())
                    <= float(config["validation"]["maximum_covariance_condition_number"])
                )
                if variant_valid:
                    parameter_quality_ok &= covariance_ok and float(weights.min()) >= float(
                        config["population_inference"]["mixture"]["minimum_component_fraction"]
                    )
                else:
                    parameter_quality_ok &= covariance_ok
                original_means = means * scale[None, :] + center[None, :]
                vrot = original_means[:, features.index("v_rot_gc_kms")]
                order_ok &= bool(np.all(np.diff(vrot) > 0.0))
        gates.append(
            gate(
                "training_fold_scaler_identity",
                scaler_ok,
                "every median/MAD scaler is recomputed from its training folds only",
            )
        )
        gates.append(
            gate(
                "stored_parameter_prediction_identity",
                prediction_max_difference <= probability_tolerance,
                "stored parameters independently reproduce every held-out responsibility",
                probability_tolerance,
                prediction_max_difference,
            )
        )

        expected_models = len(view_inventory(config)) * folds
        diagnostics_ok = (
            len(diagnostics) == expected_models
            and diagnostics[["view", "k", "fold"]].drop_duplicates().shape[0]
            == expected_models
            and int(diagnostics.fit_signature.nunique()) == 45
            and np.all(
                diagnostics.train_rows.astype(int).to_numpy()
                + diagnostics.holdout_rows.astype(int).to_numpy()
                == int(primary.sum())
            )
        )
        gates.append(
            gate(
                "fit_inventory_and_train_holdout_counts",
                diagnostics_ok,
                "50 view-fold records represent 45 unique training fits with exact held-out counts",
            )
        )
        required_components = {
            int(config["population_inference"]["responsibility_policy"]["nominal_components"]),
            *(
                int(value)
                for value in config["population_inference"]["responsibility_policy"][
                    "required_sensitivity_components"
                ]
            ),
        }
        required_diagnostics = diagnostics.loc[diagnostics.k.astype(int).isin(required_components)]
        viability_consistent = True
        for row in viability.itertuples():
            selected = diagnostics.loc[
                (diagnostics.view == row.view) & (diagnostics.k.astype(int) == int(row.k))
            ]
            strict_count = int(selected.strictly_valid.astype(bool).sum())
            viability_consistent &= strict_count == int(row.strictly_valid_folds)
            viability_consistent &= bool(row.all_folds_strictly_valid) == (strict_count == folds)
            viability_consistent &= bool(row.downstream_eligible) == (strict_count == folds)
            if str(row.role) != "OPTIONAL_STRESS":
                viability_consistent &= bool(row.downstream_eligible)
        convergence_ok = (
            required_diagnostics.strictly_valid.astype(bool).all()
            and required_diagnostics.converged.astype(bool).all()
            and diagnostics.monotonic.astype(bool).all()
            and np.isfinite(diagnostics.log_likelihood.astype(float)).all()
            and np.all(
                diagnostics.iterations.astype(int)
                <= int(config["population_inference"]["mixture"]["maximum_iterations"])
            )
            and viability_consistent
        )
        gates.append(
            gate(
                "fit_convergence_and_monotonicity",
                convergence_ok,
                "all nominal/required-sensitivity fits are strict PASS and optional-stress failures are explicitly quarantined",
            )
        )
        gates.append(
            gate(
                "component_weight_covariance_and_order",
                parameter_quality_ok and order_ok,
                "component weights, positive-definite covariances, and anonymous vrot ordering satisfy the frozen contract",
            )
        )

        restart_ok = len(restart_audit) == expected_models * int(
            config["population_inference"]["mixture"]["deterministic_restarts"]
        )
        namespace = str(config["population_inference"]["mixture"]["random_seed_namespace"])
        for (view, components, fold), group in restart_audit.groupby(["view", "k", "fold"], sort=False):
            variant = next(
                row
                for row in view_inventory(config)
                if row["name"] == view and row["components"] == int(components)
            )
            signature = _feature_signature(variant["features"], int(components), int(fold))
            restart_ok &= len(group) == int(config["population_inference"]["mixture"]["deterministic_restarts"])
            restart_ok &= group.restart.astype(int).nunique() == len(group)
            initial_refinements = int(
                config["population_inference"]["mixture"]["full_refinement_candidates"]
            )
            optional_components = {
                int(value)
                for value in config["population_inference"]["responsibility_policy"][
                    "optional_stress_components"
                ]
            }
            rescue_key = (
                "optional_stress_rescue_maximum_additional_refinements"
                if int(components) in optional_components
                else "validity_rescue_maximum_additional_refinements"
            )
            maximum_refinements = initial_refinements + int(
                config["population_inference"]["mixture"][rescue_key]
            )
            refined = group.selected_for_full_refinement.astype(bool)
            refined_count = int(refined.sum())
            restart_ok &= initial_refinements <= refined_count <= maximum_refinements
            rescue = group.validity_rescue_refinement.astype(bool)
            restart_ok &= int(rescue.sum()) == refined_count - initial_refinements
            restart_ok &= bool((~rescue | refined).all())
            restart_ok &= int(group.selected_final.astype(bool).sum()) == 1
            variant_valid = bool(
                viability.loc[
                    (viability.view == view)
                    & (viability.k.astype(int) == int(components)),
                    "downstream_eligible",
                ].iloc[0]
            )
            for row in group.itertuples():
                restart_ok &= int(row.seed) == stable_seed(
                    namespace, f"{signature}|RESTART|{int(row.restart)}"
                )
                restart_ok &= str(row.fit_signature) == signature
                if bool(row.selected_final):
                    restart_ok &= bool(row.selected_for_full_refinement)
                    if variant_valid:
                        restart_ok &= bool(row.full_converged) and bool(row.full_monotonic)
                        restart_ok &= float(row.full_minimum_component_fraction) >= float(
                            config["population_inference"]["mixture"]["minimum_component_fraction"]
                        )
        gates.append(
            gate(
                "deterministic_restart_and_selection_audit",
                restart_ok,
                "16 deterministic screens, two planned refinements, bounded validity rescue, and one strictly valid solution are recorded per view-fold model",
            )
        )

        expected_summary = _expected_summary(responsibility, viability, config)
        gates.append(
            gate(
                "responsibility_summary_identity",
                frame_matches(stored_summary, expected_summary, probability_tolerance),
                "component effective sizes, quantiles, entropy, and secure-threshold summaries reproduce",
            )
        )
        expected_stability = _expected_stability(parameters, feature_scaling, viability, config)
        stability_ok = frame_matches(stored_stability, expected_stability, tolerance)
        stability_ok &= (
            float(
                stored_stability.loc[
                    stored_stability.model_valid.astype(bool),
                    "maximum_standardized_centroid_distance",
                ].max()
            )
            <= float(config["validation"]["maximum_fold_centroid_distance"])
        )
        gates.append(
            gate(
                "crossfold_component_stability",
                stability_ok,
                "anonymous ordered components remain within the prespecified cross-fold centroid envelope",
                float(config["validation"]["maximum_fold_centroid_distance"]),
                float(
                    stored_stability.loc[
                        stored_stability.model_valid.astype(bool),
                        "maximum_standardized_centroid_distance",
                    ].max()
                ),
            )
        )
        expected_crossview = _expected_crossview(responsibility, config)
        gates.append(
            gate(
                "target_safe_crossview_stability_identity",
                frame_matches(stored_crossview, expected_crossview, probability_tolerance),
                "K=4 target-exclusion sensitivity is exactly summarized without declaring a canonical membership view",
            )
        )

        output_hashes = build_summary["output_sha256"]
        hashes_ok = True
        output_dir = project_path(root, config["paths"]["output_dir"])
        for filename, expected_hash in output_hashes.items():
            path = output_dir / filename
            hashes_ok &= path.is_file() and sha256_file(path) == expected_hash
        hashes_ok &= freeze.get("input_sha256") == expected_hashes
        hashes_ok &= freeze.get("candidate_id_sha256") == ids_sha256(all_ids)
        hashes_ok &= freeze.get("primary_id_sha256") == ids_sha256(primary_ids)
        hashes_ok &= freeze.get("counts") == build_summary.get("counts")
        for filename, expected_hash in freeze["output_sha256"].items():
            path = output_dir / filename
            hashes_ok &= path.is_file() and sha256_file(path) == expected_hash
        gates.append(
            gate(
                "output_hashes_build_and_freeze",
                hashes_ok,
                "science-output hashes, input hashes, counts, build summary, and freeze manifest are internally exact",
            )
        )
        method_ok = (
            method.get("protocol_version") == str(config["project"]["version"])
            and method.get("population_inference") == config["population_inference"]
            and method.get("input_sha256") == expected_hashes
            and method.get("science_boundary") == config["science_boundary"]
        )
        gates.append(
            gate(
                "method_definition_identity",
                method_ok,
                "the emitted method definition is an exact machine-readable copy of the frozen Stage 5B contract",
            )
        )
        forbidden_responsibility_tokens = ("population_label", "component_label", "membership")
        science_ok = (
            build_summary.get("science_boundary") == config["science_boundary"]
            and freeze.get("science_boundary") == config["science_boundary"]
            and not any(
                any(token in column.lower() for token in forbidden_responsibility_tokens)
                for column in responsibility.columns
            )
            and not any("gradient" in path.name.lower() for path in output_dir.iterdir() if path.is_file())
            and set(claims.status).issubset(
                {"ALLOWED_WITH_MODEL_SENSITIVITY", "ALLOWED_LATER", "FORBIDDEN"}
            )
            and int((claims.status == "FORBIDDEN").sum()) >= 5
        )
        gates.append(
            gate(
                "science_and_claim_boundary",
                science_ok,
                "Stage 5B emits soft empirical responsibilities but no hard/semantic memberships, gradients, or selection correction",
            )
        )

        payload = {
            "stage": "5B leakage-safe cross-fitted population inference",
            "protocol_version": str(config["project"]["version"]),
            "created_utc": str(config["project"]["frozen_created_utc"]),
            "overall_passed": bool(all(item["passed"] for item in gates)),
            "n_passed": int(sum(item["passed"] for item in gates)),
            "n_gates": int(len(gates)),
            "gates": gates,
        }
        expected_gate_count = int(config["validation"]["expected_gates"])
        if payload["n_gates"] != expected_gate_count:
            raise RuntimeError(
                f"Validator gate count changed: {payload['n_gates']} != {expected_gate_count}"
            )
        atomic_write_json(payload, paths["validation"])
        paths["validation_report"].write_text(
            validation_report(payload), encoding="utf-8", newline="\n"
        )
        logger.info(
            "Stage 5B validation passed=%s; gates=%s/%s",
            payload["overall_passed"],
            payload["n_passed"],
            payload["n_gates"],
        )
        print(
            f"Stage 5B validation passed={payload['overall_passed']}; "
            f"gates={payload['n_passed']}/{payload['n_gates']}"
        )
        return 0 if payload["overall_passed"] else 1
    finally:
        close_logger(logger)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        raise SystemExit(130)
