from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


ELEMENTS = ("fe_h", "mg_fe", "si_fe", "ca_fe", "ni_fe")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_config(path: str | os.PathLike[str]) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration is not a mapping: {config_path}")
    return config, config_path.parent.parent


def project_path(root: Path, value: str | os.PathLike[str]) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def setup_logger(path: Path, name: str) -> logging.Logger:
    path.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    file_handler = logging.FileHandler(path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream)
    logger.addHandler(file_handler)
    return logger


def atomic_write_json(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        temporary = Path(handle.name)
    os.replace(temporary, path)


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def sha256_file(path: Path, block_size: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(block_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def canonical_line_sha256(lines: Iterable[str]) -> str:
    digest = hashlib.sha256()
    for line in lines:
        digest.update(line.encode("ascii"))
    return digest.hexdigest()


def ids_sha256(values: Sequence[int] | np.ndarray | pd.Series) -> str:
    array = np.asarray(values, dtype=np.int64)
    return canonical_line_sha256(f"{int(value)}\n" for value in array)


def assignment_sha256(
    source_ids: Sequence[int] | np.ndarray | pd.Series,
    folds: Sequence[int] | np.ndarray | pd.Series,
) -> str:
    ids = np.asarray(source_ids, dtype=np.int64)
    fold_values = np.asarray(folds, dtype=np.int16)
    if len(ids) != len(fold_values):
        raise ValueError("ID and fold vectors have different lengths")
    return canonical_line_sha256(
        f"{int(source_id)},{int(fold)}\n"
        for source_id, fold in zip(ids, fold_values)
    )


def membership_sha256(
    source_ids: Sequence[int] | np.ndarray | pd.Series,
    membership: Sequence[bool] | np.ndarray | pd.Series,
) -> str:
    ids = np.asarray(source_ids, dtype=np.int64)
    mask = np.asarray(membership, dtype=bool)
    if len(ids) != len(mask):
        raise ValueError("ID and membership vectors have different lengths")
    return ids_sha256(ids[mask])


def coordinate_decision_sha256(frame: pd.DataFrame) -> str:
    required = (
        "gaia_dr3_source_id",
        "coordinate_status",
        "coordinate_primary_ok",
        "coordinate_sensitivity_ok",
    )
    ensure_columns(frame, required, "coordinate decision table")
    return canonical_line_sha256(
        (
            f"{int(row.gaia_dr3_source_id)},{row.coordinate_status},"
            f"{int(bool(row.coordinate_primary_ok))},"
            f"{int(bool(row.coordinate_sensitivity_ok))}\n"
        )
        for row in frame.loc[:, required].itertuples(index=False)
    )


def splitmix64(values: Sequence[int] | np.ndarray | pd.Series, seed: int) -> np.ndarray:
    z = np.asarray(values, dtype=np.uint64).copy()
    with np.errstate(over="ignore"):
        z += np.uint64(seed) + np.uint64(0x9E3779B97F4A7C15)
        z = (z ^ (z >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)
        z ^= z >> np.uint64(31)
    return z


def frozen_folds(
    source_ids: Sequence[int] | np.ndarray | pd.Series,
    seed: int,
    n_folds: int,
) -> tuple[np.ndarray, np.ndarray]:
    if n_folds < 2:
        raise ValueError("n_folds must be at least 2")
    ranks = splitmix64(source_ids, seed)
    folds = (ranks % np.uint64(n_folds)).astype(np.int8)
    return ranks, folds


def spherical_separation_arcsec(
    ra1_deg: Sequence[float] | np.ndarray | pd.Series,
    dec1_deg: Sequence[float] | np.ndarray | pd.Series,
    ra2_deg: Sequence[float] | np.ndarray | pd.Series,
    dec2_deg: Sequence[float] | np.ndarray | pd.Series,
) -> np.ndarray:
    ra1 = np.deg2rad(np.asarray(ra1_deg, dtype=float))
    dec1 = np.deg2rad(np.asarray(dec1_deg, dtype=float))
    ra2 = np.deg2rad(np.asarray(ra2_deg, dtype=float))
    dec2 = np.deg2rad(np.asarray(dec2_deg, dtype=float))
    delta_ra = (ra2 - ra1 + np.pi) % (2.0 * np.pi) - np.pi
    haversine = (
        np.sin((dec2 - dec1) / 2.0) ** 2
        + np.cos(dec1) * np.cos(dec2) * np.sin(delta_ra / 2.0) ** 2
    )
    angle = 2.0 * np.arcsin(np.sqrt(np.clip(haversine, 0.0, 1.0)))
    separation = np.rad2deg(angle) * 3600.0
    finite = np.isfinite(ra1) & np.isfinite(dec1) & np.isfinite(ra2) & np.isfinite(dec2)
    separation[~finite] = np.nan
    return separation


def coordinate_adjudication(
    frame: pd.DataFrame,
    pair_hard_mismatch_arcsec: float,
    gaia_confirmation_arcsec: float,
    gaia_far_arcsec: float,
) -> pd.DataFrame:
    required = (
        "apogee_ra",
        "apogee_dec",
        "galah_ra",
        "galah_dec",
        "gaia_ra",
        "gaia_dec",
    )
    ensure_columns(frame, required, "overlap coordinate table")
    result = pd.DataFrame(index=frame.index)
    result["apogee_galah_sep_arcsec"] = spherical_separation_arcsec(
        frame["apogee_ra"], frame["apogee_dec"], frame["galah_ra"], frame["galah_dec"]
    )
    result["apogee_gaia_sep_arcsec"] = spherical_separation_arcsec(
        frame["apogee_ra"], frame["apogee_dec"], frame["gaia_ra"], frame["gaia_dec"]
    )
    result["galah_gaia_sep_arcsec"] = spherical_separation_arcsec(
        frame["galah_ra"], frame["galah_dec"], frame["gaia_ra"], frame["gaia_dec"]
    )
    coordinate_complete = np.isfinite(
        result[
            [
                "apogee_galah_sep_arcsec",
                "apogee_gaia_sep_arcsec",
                "galah_gaia_sep_arcsec",
            ]
        ].to_numpy(dtype=float)
    ).all(axis=1)
    hard = coordinate_complete & result["apogee_galah_sep_arcsec"].gt(
        float(pair_hard_mismatch_arcsec)
    )
    apogee_close = result["apogee_gaia_sep_arcsec"].le(
        float(gaia_confirmation_arcsec)
    )
    galah_close = result["galah_gaia_sep_arcsec"].le(
        float(gaia_confirmation_arcsec)
    )
    apogee_far = result["apogee_gaia_sep_arcsec"].gt(float(gaia_far_arcsec))
    galah_far = result["galah_gaia_sep_arcsec"].gt(float(gaia_far_arcsec))
    apogee_confirmed = hard & apogee_close & galah_far & ~galah_close
    galah_confirmed = hard & galah_close & apogee_far & ~apogee_close

    status = np.full(len(frame), "IDENTITY_CONSISTENT", dtype=object)
    status[~coordinate_complete] = "GAIA_COORDINATE_INCOMPLETE"
    status[hard.to_numpy()] = "HARD_MISMATCH_UNRESOLVED"
    status[apogee_confirmed.to_numpy()] = "APOGEE_COORDINATE_CONFIRMED"
    status[galah_confirmed.to_numpy()] = "GALAH_COORDINATE_CONFIRMED"
    result["coordinate_complete"] = coordinate_complete
    result["coordinate_hard_mismatch"] = hard.to_numpy(dtype=bool)
    result["coordinate_status"] = pd.Series(status, index=frame.index, dtype="string")
    result["coordinate_preferred_survey"] = pd.Series(
        np.select(
            [apogee_confirmed, galah_confirmed, coordinate_complete & ~hard],
            ["APOGEE", "GALAH", "BOTH_IDENTITY_CONSISTENT"],
            default="UNRESOLVED",
        ),
        index=frame.index,
        dtype="string",
    )
    result["coordinate_primary_ok"] = coordinate_complete & ~hard.to_numpy(dtype=bool)
    result["coordinate_sensitivity_ok"] = (
        coordinate_complete & (~hard.to_numpy(dtype=bool) | apogee_confirmed | galah_confirmed)
    )
    return result


def add_support_flags(frame: pd.DataFrame, elements: Sequence[str]) -> pd.DataFrame:
    result = frame.copy()
    ensure_columns(
        result,
        (
            "apogee_broad_rg_and_quality",
            "galah_broad_rg_and_quality",
            "coordinate_primary_ok",
            "coordinate_sensitivity_ok",
        ),
        "Stage 2A overlap table",
    )
    joint = (
        result["apogee_broad_rg_and_quality"].fillna(False).astype(bool)
        & result["galah_broad_rg_and_quality"].fillna(False).astype(bool)
    )
    result["joint_broad_rg_and_quality"] = joint
    for element in elements:
        apogee_valid = f"apogee_valid_{element}"
        galah_valid = f"galah_valid_{element}"
        ensure_columns(result, (apogee_valid, galah_valid), f"{element} support")
        pre = (
            joint
            & result[apogee_valid].fillna(False).astype(bool)
            & result[galah_valid].fillna(False).astype(bool)
        )
        result[f"eligible_{element}_precoordinate"] = pre
        result[f"eligible_{element}_primary"] = (
            pre & result["coordinate_primary_ok"].astype(bool)
        )
        result[f"eligible_{element}_sensitivity"] = (
            pre & result["coordinate_sensitivity_ok"].astype(bool)
        )
    return result


def ensure_columns(frame: pd.DataFrame, required: Sequence[str], label: str) -> None:
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise KeyError(f"{label} is missing required columns: {missing}")


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    if path.suffix == ".parquet":
        frame.to_parquet(temporary, index=False, compression="zstd")
    elif path.suffix == ".csv":
        frame.to_csv(temporary, index=False)
    else:
        raise ValueError(f"Unsupported table format: {path}")
    os.replace(temporary, path)


def to_python(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if pd.isna(value):
        return None
    return value


def close_logger(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        handler.flush()
        handler.close()
        logger.removeHandler(handler)
