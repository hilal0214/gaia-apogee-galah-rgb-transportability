@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is unavailable in the active environment.
  exit /b 1
)
python src\stage6c3_build_flat_mnras.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C3B execution failed.
  exit /b 1
)
echo.
echo [OK] Stage-6C3B flat MNRAS package created.
echo Inspect outputs\stage6c3b_flat_mnras_hotfix\validation\stage6c3_validation.json
endlocal
