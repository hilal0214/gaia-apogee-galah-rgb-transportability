@echo off
setlocal
cd /d "%~dp0"
python src\stage6d4b_exact_production_fits.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D4B exact production fits completed.
echo Inspect outputs\stage6d4b_exact_production_fits\validation\stage6d4b_validation.json
endlocal
