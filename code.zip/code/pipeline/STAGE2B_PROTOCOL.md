# Stage 2B frozen protocol

Version: `0.3.0`  
Date: `2026-08-01`

## Scope

Stage 2B estimates and evaluates element-by-element APOGEE--GALAH abundance
offset functions on the overlap support frozen in Stage 2A. It produces
strictly held-out predictions for calibration assessment and separate
all-support deployable coefficients for the later catalogue-transport stage.

Stage 2B does not apply a correction to APOGEE-only or GALAH-only parent rows,
does not construct the final homogenised atlas, and does not fit Galactic
gradients or population models.

## Accepted upstream identity

The accepted upstream release is
`RGB_transportability_stage2a_outputs_v0_2_0.zip`, SHA-256
`6600ee4634e7a7d449a10813707e7a27c0c432604aa28ed1be49bc2de79d7385`.
The frozen 59,918-row overlap table has SHA-256
`02695b517bd3dcc23d01556bdba2bf050caf7a4677603d464a06f4a943ac14d2`.
The five SplitMix64 folds, seed `20260801`, and all primary/sensitivity
memberships are consumed exactly as written by Stage 2A; they are never
regenerated, shuffled, or re-stratified here.

## Calibration direction and predictors

For element `y`, the response is

`delta_y = y_GALAH - y_APOGEE`.

The fixed linear predictor is

`delta_hat_y = a0 + aT * (Teff_GALAH - 4800)/1000 + ag * (logg_GALAH - 2.5) + aFe * [Fe/H]_GALAH`.

GALAH-side predictors are used deliberately: the fitted mapping must later be
applicable to GALAH-only stars, for which APOGEE atmospheric parameters do not
exist. For `[Fe/H]`, the GALAH metallicity appearing as a predictor defines a
linear self-scale transformation rather than an independent covariate.

The corrected value on the APOGEE-like reference scale is

`y_GALAH,corr = y_GALAH - delta_hat_y`.

The model is fitted independently for `[Fe/H]`, `[Mg/Fe]`, `[Si/Fe]`,
`[Ca/Fe]`, and `[Ni/Fe]`. APOGEE labels are not transformed.

## Robust estimator

Coefficients are estimated with deterministic Huber iteratively reweighted
least squares. The Huber constant is `1.345`; the residual scale is
`1.482602218505602 * MAD`; the iteration cap is 200 and the coefficient
tolerance is `1e-9`. Formal label uncertainties remain in the output table but
are not used as inverse-variance weights because the two survey pipelines'
formal errors are not assumed to be mutually calibrated.

No clipping, polynomial terms, interactions, element-specific tuning, or
post-result model selection is permitted.

## Cross-fitting and deployable models

For each element and analysis set, fold `k` is predicted only by a model fitted
on folds other than `k`. Thus every reported calibration residual is held out.
After cross-fitted evaluation is complete, a separate deployable model is fit
to all support in that analysis set. Its training residuals are not used as the
headline validation statistic.

The primary set excludes all 381 hard survey-coordinate mismatches. The
sensitivity set reinstates only the Gaia-adjudicated mismatches allowed by the
Stage 2A freeze. The primary deployable model is the later transport default;
the sensitivity model is a robustness comparison only.

## Reported diagnostics

For each element and set, Stage 2B records the raw median offset, raw centred
MAD/RMSE, held-out residual median, held-out MAD/RMSE, foldwise metrics,
coefficient vectors, convergence information, design condition number, support
bounds, source-membership hashes, and exact prediction algebra.

The empirical held-out residual scatter is a cross-survey predictive scatter;
it is not interpreted as a pure astrophysical dispersion or as a formal
single-survey abundance uncertainty.

## Frozen boundary

Stage 2B ends with overlap calibration and held-out validation. Application to
the 1,509,277-source parent census, extrapolation flags, homogenised label
selection, gradients, and population inference belong to later audited stages.
