@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is not available in the active environment.
  exit /b 1
)
python src\stage6b_release_candidate.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6B failed. Inspect outputs\stage6b_release_candidate\validation\stage6b_validation.json
  exit /b 1
)
echo.
echo [OK] Stage-6B v0.13.1 Windows-safe release candidate completed.
echo Output: outputs\stage6b_release_candidate
endlocal
