@echo off
setlocal
call 99_stage2a_selftest.bat
if errorlevel 1 exit /b 1
call 07_build_stage2a.bat
if errorlevel 1 exit /b 1
call 08_validate_stage2a.bat
if errorlevel 1 exit /b 1
call 09_package_stage2a.bat
