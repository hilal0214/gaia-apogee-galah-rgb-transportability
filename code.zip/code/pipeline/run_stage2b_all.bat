@echo off
setlocal
call 99_stage2b_selftest.bat || exit /b %errorlevel%
call 10_run_stage2b.bat || exit /b %errorlevel%
call 11_validate_stage2b.bat || exit /b %errorlevel%
call 12_package_stage2b.bat || exit /b %errorlevel%
endlocal
