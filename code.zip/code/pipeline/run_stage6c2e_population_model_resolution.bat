@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is unavailable in the active environment.
  exit /b 1
)
python src\stage6c2e_population_model_resolution.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C2E execution failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6C2E population-model resolution audit completed.
echo Output: outputs\stage6c2e_population_model_resolution
endlocal
