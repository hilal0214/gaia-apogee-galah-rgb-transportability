@echo off
python scripts\selftest_stage3c.py

