@echo off
setlocal
cd /d "%~dp0"
python src\stage6d5b1_windows_pathlength_hotfix.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D5B1 Windows path-length archival hotfix completed.
echo Inspect outputs\stage6d5b1_windows_pathlength_hotfix\validation\stage6d5b1_validation.json
endlocal
