@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c7_fixedC_constrained_celltarget_calibration.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C7 fixed-C constrained cell-target calibration completed.
echo Inspect outputs\stage6d3c7_fixedC_constrained_celltarget_calibration\validation\stage6d3c7_validation.json
endlocal
