@echo off
setlocal
cd /d "%~dp0"
python src\stage6c2h2_exact_replay_inputfix.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C2H2 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6C2H2 completed.
echo Inspect outputs\stage6c2h2_exact_replay_inputfix\validation\stage6c2h2_validation.json
endlocal
