# Data provenance

## APOGEE DR17

Product:

`allStarLite-dr17-synspec_rev1.fits`

Official URL:

https://data.sdss.org/sas/dr17/apogee/spectro/aspcap/dr17/synspec_rev1/allStarLite-dr17-synspec_rev1.fits

Release documentation:

https://www.sdss4.org/dr17/irspec/spectro_data/

Data model:

https://data.sdss.org/datamodel/files/APOGEE_ASPCAP/APRED_VERS/ASPCAP_VERS/allStarLite.html

The `synspec_rev1` product is used because SDSS recommends the reprocessed
results that correct the LCO line-spread-function assignment issue. The
physical official file header contains
`TTYPE54 = 'GAIAEDR3_SOURCE_ID'`. This release-specific FITS column is used;
the generic data-model page's older `GAIA_SOURCE_ID` description is not used
to infer identifier semantics.

## GALAH DR4

Product:

`galah_dr4_allstar_240705.fits`

Official URL:

https://cloud.datacentral.org.au/teamdata/GALAH/public/GALAH_DR4/catalogs/galah_dr4_allstar_240705.fits

Catalogue documentation:

https://www.galah-survey.org/dr4/the_catalogues/

Best practices:

https://www.galah-survey.org/dr4/using_the_data/

The allstar product is the release-recommended one-row-per-star catalogue.
The release recommends `snr_px_ccd3 > 30`, `flag_sp == 0`, and
element-specific `flag_X_fe == 0`. It explicitly advises against using
`flag_fe_h` as a metallicity-reliability flag.

## Gaia EDR3/DR3 identifier compatibility and Gaia DR3 query

Gaia Archive:

https://gea.esac.esa.int/archive/

Astroquery TAP+ upload documentation:

https://astroquery.readthedocs.io/en/latest/gaia/gaia.html

Gaia DR3 release information:

https://www.cosmos.esa.int/web/gaia/dr3

The Gaia DR3 release documentation states that the Gaia EDR3 and DR3 source
lists are identical. The workflow therefore joins APOGEE
`GAIAEDR3_SOURCE_ID` and GALAH `gaiadr3_source_id` directly to
`gaiadr3.gaia_source` by exact source-ID equality. It does not perform a
DR2-to-DR3 or positional nearest-neighbour mapping.

## Distances

Product:

`external.gaiaedr3_distance`

Catalogue information:

https://www2.mpia-hd.mpg.de/~calj/gedr3_distances.html

Reference:

Bailer-Jones et al. (2021), AJ, 161, 147.

Both geometric and photogeometric posterior medians and their 16th/84th
percentiles are retrieved. Stage 1 counts missing distances and never removes
them silently.
