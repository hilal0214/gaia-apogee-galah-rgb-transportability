@echo off
setlocal
where conda >nul 2>nul
if errorlevel 1 (
  echo ERROR: conda topilmadi. Anaconda Prompt ichida ishga tushiring.
  exit /b 1
)
call conda env update -n rgb-transport-stage1 -f environment.yml --prune
if errorlevel 1 exit /b 1
call conda activate rgb-transport-stage1
python -c "import astropy,astroquery,pyarrow,pandas,yaml; print('Environment OK')"
if errorlevel 1 exit /b 1
python scripts\selftest_logic.py
if errorlevel 1 exit /b 1
echo Environment ready: rgb-transport-stage1
