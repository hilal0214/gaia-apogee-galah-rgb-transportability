# Stage-6C3 protocol

All textual LaTeX dependencies and the generated bibliography are flattened into main.tex. The unresolved T06 survey-origin coefficient product is omitted. Figures remain external binary assets. Human metadata is never invented.
