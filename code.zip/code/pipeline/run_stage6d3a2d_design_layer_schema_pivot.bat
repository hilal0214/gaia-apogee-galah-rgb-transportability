@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d_design_layer_schema_pivot.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2D failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2D design-layer schema adjudication completed.
echo Inspect outputs\stage6d3a2d_design_layer_schema_pivot\validation\stage6d3a2d_validation.json
endlocal
