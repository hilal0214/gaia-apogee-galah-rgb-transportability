@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2a_trace_bootstrap_source_assembly_hotfix.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2A failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2A trace-bootstrap recovery and source assembly completed.
echo Inspect outputs\stage6d3a2a_trace_bootstrap_source_assembly_hotfix\validation\stage6d3a2a_validation.json
endlocal
