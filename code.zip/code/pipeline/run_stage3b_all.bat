@echo off
setlocal
call 99_stage3b_selftest.bat || exit /b 1
call 19_build_stage3b.bat || exit /b 1
call 20_validate_stage3b.bat || exit /b 1
call 21_package_stage3b.bat || exit /b 1
endlocal

