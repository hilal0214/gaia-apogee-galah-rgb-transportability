@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python is unavailable in the active environment.
  exit /b 1
)
python src\stage6c2d_claimbounded_closure.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6C2D execution failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6C2D claim-bounded closure completed.
echo Inspect outputs\stage6c2d_claimbounded_closure\validation\stage6c2d_validation.json
endlocal
