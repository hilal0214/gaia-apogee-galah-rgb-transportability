@echo off
python scripts\26_validate_stage4a.py --config config\stage4a.yml
if errorlevel 1 exit /b %errorlevel%

