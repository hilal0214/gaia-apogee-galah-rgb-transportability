@echo off
call 99_stage5b_selftest.bat || exit /b 1
call 34_fit_stage5b.bat || exit /b 1
call 35_validate_stage5b.bat || exit /b 1
call 36_package_stage5b.bat || exit /b 1

