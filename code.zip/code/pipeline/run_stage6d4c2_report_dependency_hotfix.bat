@echo off
setlocal
cd /d "%~dp0"
python src\stage6d4c2_report_dependency_hotfix.py --project-root "%CD%"
if errorlevel 1 exit /b 1
endlocal
