# Stage 5B v0.11.0 protocol

## Purpose

Fit leakage-safe, spatially cross-fitted empirical population mixtures on the frozen Stage 5A primary cohort. This stage emits responsibilities and diagnostic stability products only; population-resolved abundance gradients remain out of scope.

## Frozen inputs

- Stage 4A v0.8.1 design layer: 393,834 rows, 173 columns, SHA-256 `df4a4007358f862842f24a222cd1a615ea66fc80e7287e57508da9a93ee7d3a4`.
- Stage 5A v0.10.0 release: SHA-256 `fc32af539b9369146ec130d49a4f0174869382d3cef8afa8699c5c46a7e149bf`, validator 20/20 PASS.
- Primary population-feature cohort: 323,087 rows in 7,729 HEALPix-5 blocks and five frozen folds.

## Model

- Fixed-degree-of-freedom multivariate Student-t mixture, df=5, full covariance.
- Nominal K=4 and required K=3 sensitivity; K=5 is a prespecified optional stress model for target-safe views. A K=5 view is downstream-eligible only when every fold satisfies the same convergence, monotonicity, covariance, and 1% component-floor gates. Otherwise the failure is retained in the viability ledger and all responsibility columns for that view/K are null.
- Sixteen deterministic training-only initialization screens; the best two candidates receive full-data refinement. If neither candidate both converges and satisfies the 1% component floor, candidates are refined in frozen screen-likelihood order, up to six additional refinements for required K=3/4 models and two for optional K=5 stress models, stopping at the first strictly valid solution. The tolerance and 300-iteration ceiling are never relaxed.
- Covariance regularization is `1e-4`; minimum component fraction is 0.01.
- Each held-out block is predicted only by a model trained without that fold.
- Median/MAD preprocessing is recomputed on the training folds only.
- Components are anonymous and deterministically ordered within each fold by ascending mean `v_rot`, followed by fixed feature tie-breakers.

## Views

- `DESCRIPTIVE_FULL`: catalogue description only; never used for an abundance gradient.
- `FE_H_TARGET_SAFE`: excludes Fe/H.
- `ALPHA3_TARGET_SAFE`: excludes alpha3.
- `OTHER_ELEMENTS_TARGET_SAFE`: for Mg, Si, Ca, and Ni.

All views exclude `R` and `abs(Z)`. Identical feature/K/fold fits are reused exactly rather than re-estimated under a different name.

## Interpretation boundary

Responsibilities are empirical held-out-fold mixture responsibilities. They are not calibrated physical membership probabilities. No hard component label or semantic population name is emitted. Common-support and frame-stable flags are carried only for later sensitivity filtering; no selection-function correction is claimed. Stage 5B contains no population-resolved gradient fit.

## Validation

The 26-gate validator checks frozen upstream bytes, candidate/cohort/fold identity, target leakage, responsibility schema and simplex, training-only scalers, independent predictions from stored parameters, convergence, covariance and weight constraints, deterministic restarts, component/cross-view stability summaries, hashes, and claim boundaries.
