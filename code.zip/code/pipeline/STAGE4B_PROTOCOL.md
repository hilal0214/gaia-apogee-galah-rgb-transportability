# Stage 4B protocol: robust global gradients and conditional survey transportability

Version: 0.9.0  
Date: 2026-08-03

## Purpose

Stage 4B is the first inferential layer after the outcome-free Stage 4A design
freeze. It fits global radial--vertical abundance planes for the six validated
transport labels and quantifies how the slopes change across prespecified
quality, support, distance-estimator, and survey-source tests. It does not fit
or assign Galactic populations.

The exact upstream dependency is
`RGB_transportability_stage4a_outputs_v0_8_1.zip`, SHA-256
`be1e24f1b8e93a0203b74b654b1e1c2bb30a1cf4be975af9bae54657ad6195a4`.
Its corrected 393,834-row design layer has SHA-256
`df4a4007358f862842f24a222cd1a615ea66fc80e7287e57508da9a93ee7d3a4`.

## Labels and nominal model

The only responses are homogenised [Fe/H], [Mg/Fe], [Si/Fe], [Ca/Fe],
[Ni/Fe], and the fixed three-element alpha3 mean. C/N, C, N, Al, Ti, and
other unvalidated abundance transports remain excluded.

For each label, the nominal Stage 4A PRIMARY cohort is fitted with

```text
y = beta_0 + beta_R (R_GC - 8.2 kpc) + beta_Z |Z_GC| + residual.
```

The estimator is an unweighted Huber M-estimator with tuning constant 1.345,
solved by deterministic iteratively reweighted least squares. The empirical
abundance error proxy is required to be finite and non-negative by Stage 4A,
but it is neither an inverse-variance weight nor an exact Gaussian draw scale.
The reported coefficients therefore describe the frozen cross-survey RGB
analysis sample.

## Spatial-cluster uncertainty

Stage 4B treats the frozen Gaia source-ID-derived HEALPix level-5 cells as
spatial resampling units. For a fitted Huber estimating equation, row scores
are summed inside each HEALPix cell. A finite-cluster-corrected sandwich
covariance is calculated from those block scores.

Uncertainty intervals use 4,096 deterministic antithetic Rademacher multiplier
draws applied to the same block-score linearisation. This is a spatial-cluster
multiplier bootstrap for the Huber M-estimator, not an ordinary independent-row
bootstrap and not 4,096 full nonlinear refits. The first paired 2,048 draws
form a nested convergence audit against the full ensemble. Stage 4B reports
16th--84th and 2.5th--97.5th percentile intervals plus sign stability.

The five largest first-order delete-one-block coefficient changes are retained
for every nominal and common-support interaction parameter. These are
influence diagnostics, not automatic exclusion rules.

## Prespecified sensitivity ladder

Every label is refitted on six Stage 4A cohorts:

- `PRIMARY`: nominal primary phase-space and abundance support;
- `CORE`: stricter calibration-support cohort;
- `COMMON_SUPPORT`: APOGEE/GALAH rectangular overlap in R, |Z|, Teff, and logg;
- `DISC5`: nominal cohort restricted to |Z| <= 5 kpc;
- `GEO_PAIRED`: paired geometric-distance coordinates and their radial domain;
- `SENSITIVITY`: the broader frozen phase-space/abundance sensitivity cohort.

All but `GEO_PAIRED` use the nominal photogeometric Galactocentric coordinates.
The ladder is descriptive model stress testing. Common support is not an
inverse-probability correction, and the geometric alternative is not an exact
distance-posterior propagation.

## Conditional APOGEE--GALAH transportability model

Within each label's frozen COMMON_SUPPORT cohort, Stage 4B excludes the few
`MIXED`/unavailable outcome-source rows and fits

```text
y = beta_0 + beta_R x_R + beta_Z |Z|
    + I_GALAH (delta_0 + delta_R x_R + delta_Z |Z|) + residual.
```

APOGEE_NATIVE is the reference group and GALAH_CORRECTED is the comparison
group. `delta_R` and `delta_Z` are conditional survey-slope contrasts on the
rectangular overlap domain. A 95-percent interval that excludes zero is
evidence of residual survey-dependent slope structure within this analysis
sample; it is not by itself a calibration failure, independent replication,
or selection-corrected Milky-Way gradient.

## Frozen boundary

Stage 4B produces global gradients, the sensitivity ladder, common-support
survey interactions, block-bootstrap draws, convergence diagnostics, and a
claim ledger. It does not create population labels or probabilities, fit
population-resolved gradients, estimate a survey selection function, create
inverse-probability weights, claim volume completeness, or propagate an exact
distance posterior that Stage 3C did not store.

Any manuscript text based on the earlier 89,323-star run, ordinary 1,000-row
bootstrap, C/N response, or old phase-space sign convention must be replaced by
the frozen Stage 1--4 results before submission.
