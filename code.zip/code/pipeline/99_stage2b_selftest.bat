@echo off
setlocal
python scripts\selftest_stage2b.py
if errorlevel 1 exit /b %errorlevel%
endlocal
