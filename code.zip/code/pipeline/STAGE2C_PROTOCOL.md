# Stage 2C frozen protocol

Version: 0.4.0  
Date: 2026-08-01

## Scope

Stage 2C applies the primary all-support calibration models frozen in Stage 2B to the complete 1,509,277-source spectroscopic census. It writes one deterministic row per positive Gaia DR3 source identifier, preserves both surveys' native label provenance, records the GALAH-to-APOGEE-like correction, and explicitly labels interpolation versus extrapolation.

This stage does not read the Stage 1 Gaia chunk cache and does not impose Gaia distance, astrometric, radial-velocity, or kinematic cuts. It does not construct Galactocentric phase space, fit Galactic gradients, or infer chemo-kinematic populations.

## Accepted upstream identity

The accepted releases are:

- Stage 1 v0.1.2, SHA-256 620ec1151aea23ff649ef198c437c9355852f1c6d2733830f905635728f54bee.
- Stage 2A v0.2.0, SHA-256 6600ee4634e7a7d449a10813707e7a27c0c432604aa28ed1be49bc2de79d7385.
- Stage 2B v0.3.0, SHA-256 a9d04675589e53976992a0a8f95605998a11372dc962867d92d9e2c083b41054.

The source master, coordinate-adjudicated overlap table, deploy model file, coefficient table, metric table, freeze manifests, and validation records are accepted only at their configured exact hashes. The two Stage 1 star-level tables are not distributed in the compact upstream archives; Stage 2C verifies their row counts, records their hashes, and requires their positive source-ID sets to equal the corresponding source-master memberships exactly.

## Transport eligibility

For APOGEE label y, native reference eligibility requires:

- the deterministic Stage 1 APOGEE star row;
- the frozen broad-RGB and APOGEE-quality gate;
- the frozen element-validity flag;
- finite y and a positive finite formal error.

For GALAH label y, transport eligibility requires:

- the deterministic Stage 1 GALAH star row;
- the frozen broad-RGB and GALAH-quality gate;
- the frozen element-validity flag;
- finite y and a positive finite formal error;
- finite GALAH Teff, log g, and [Fe/H] predictors.

The GALAH correction is computed from the primary deploy model:

delta_hat_y = a0 + aT (Teff_GALAH - 4800)/1000 + ag (logg_GALAH - 2.5) + aFe [Fe/H]_GALAH,

y_GALAH,corr = y_GALAH - delta_hat_y.

The calibrated elements are [Fe/H], [Mg/Fe], [Si/Fe], [Ca/Fe], and [Ni/Fe]. No unvalidated C, N, Al, Ti, or C/N transport is introduced.

## Calibration-support tiers

Every eligible GALAH label receives one of three transport tiers, defined separately for each element from the primary Stage 2B training support:

- CORE_99: all three predictors lie inside the rectangular q0.005--q0.995 training bounds.
- EDGE_OBSERVED: all predictors lie inside the full observed min--max bounds but at least one lies outside CORE_99.
- EXTRAPOLATED: at least one predictor lies outside the observed min--max bounds.

Ineligible rows receive NOT_ELIGIBLE. Primary GALAH use permits CORE_99 and EDGE_OBSERVED only. EXTRAPOLATED values are retained as sensitivity candidates but cannot enter the Stage 2C primary layer.

## Label provenance and overlap policy

For each source and element:

1. Use an eligible APOGEE native label when available.
2. Otherwise retain the eligible corrected GALAH label.
3. Otherwise leave the homogenised value undefined.

For an overlap source that falls in the Stage 2A coordinate-anomaly set, an APOGEE native label remains primary because Gaia confirmed the APOGEE coordinate. A GALAH fallback label is primary only when coordinate_primary_ok is true; coordinate_sensitivity_ok controls its sensitivity role. Single-survey rows receive a not-applicable coordinate status and are not penalised by the cross-survey coordinate audit.

## Empirical uncertainty descriptors

For each transported GALAH label, Stage 2C stores:

- the native formal error;
- the Stage 2B held-out cross-survey sigma_MAD;
- the standard deviation of predictions from the five primary cross-fit fold models;
- a conservative empirical proxy equal to the square root of the sum of their squared contributions.

This quantity is not a formal posterior uncertainty and is not used as an inverse-variance regression weight. APOGEE native labels retain their native formal errors without an added GALAH transport term.

## Fixed alpha proxy

The primary alpha3_hom diagnostic is the unweighted mean of homogenised [Mg/Fe], [Si/Fe], and [Ca/Fe]. All three element labels must be primary-valid. Its empirical error proxy is the quadrature sum of the three element proxies divided by three. A separate available-label mean is stored for descriptive auditing when at least two primary labels exist, but it is not the fixed alpha3 definition.

## Frozen boundary

Stage 2C ends with full-census spectroscopic label transport, provenance, support tiers, and alpha3 construction. Gaia clean selection, full phase space, Galactocentric transformations, gradients, bootstrap inference, and population modelling belong to later audited stages.

