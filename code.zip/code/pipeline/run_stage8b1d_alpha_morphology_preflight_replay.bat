@echo off
setlocal
cd /d "%~dp0"
python src\stage8b1d_alpha_morphology_preflight_replay.py --project-root "%CD%"
exit /b %ERRORLEVEL%
