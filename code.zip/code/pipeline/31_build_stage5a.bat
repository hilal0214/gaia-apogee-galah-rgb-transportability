@echo off
setlocal
cd /d "%~dp0"
python scripts\31_build_stage5a.py --config config\stage5a.yml
exit /b %errorlevel%
