@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2c_universal_io_trace_bundle.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2C failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2C universal trace and production-row-universe assembly completed.
echo Inspect outputs\stage6d3a2c_universal_io_trace_bundle\validation\stage6d3a2c_validation.json
endlocal
