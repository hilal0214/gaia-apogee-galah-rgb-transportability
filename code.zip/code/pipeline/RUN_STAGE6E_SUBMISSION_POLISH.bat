@echo off
setlocal
cd /d "%~dp0"
"%USERPROFILE%\miniconda3\envs\rgb-transport-stage1\python.exe" src\stage6e_submission_polish.py --project-root "%CD%"
exit /b %ERRORLEVEL%
