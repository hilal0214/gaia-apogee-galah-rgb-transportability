@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c6_corrected_gate_frontier_localization.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C6 corrected gate-frontier localization completed.
echo Inspect outputs\stage6d3c6_corrected_gate_frontier_localization\validation\stage6d3c6_validation.json
endlocal
