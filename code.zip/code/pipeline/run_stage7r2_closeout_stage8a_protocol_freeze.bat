@echo off
setlocal
cd /d "%~dp0"
python src\stage7r2_closeout_stage8a_protocol_freeze.py --project-root "%CD%"
exit /b %ERRORLEVEL%
