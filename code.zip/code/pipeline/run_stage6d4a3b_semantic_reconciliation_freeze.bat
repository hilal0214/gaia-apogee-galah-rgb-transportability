@echo off
setlocal
cd /d "%~dp0"
python src\stage6d4a3b_semantic_reconciliation_freeze.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D4A3B semantic reconciliation freeze completed.
echo Inspect outputs\stage6d4a3b_semantic_reconciliation_freeze\validation\stage6d4a3b_validation.json
endlocal
