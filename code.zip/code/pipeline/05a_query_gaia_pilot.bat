@echo off
setlocal
call conda activate rgb-transport-stage1
if errorlevel 1 exit /b 1
python scripts\04_query_gaia_dr3.py --config config\stage1.yml --mode pilot

