@echo off
setlocal
cd /d "%~dp0"
python scripts\selftest_stage5a.py --config config\stage5a.yml
exit /b %errorlevel%
