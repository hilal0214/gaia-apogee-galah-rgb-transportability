@echo off
setlocal
cd /d "%~dp0"
python scripts\32_validate_stage5a.py --config config\stage5a.yml
exit /b %errorlevel%
