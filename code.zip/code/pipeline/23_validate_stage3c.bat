@echo off
python scripts\23_validate_stage3c.py --config config\stage3c.yml

