@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d8c_internal_sobject_snr_companion_closure.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3A2D8C completed.
echo Inspect outputs\stage6d3a2d8c_internal_sobject_snr_companion_closure\validation\stage6d3a2d8c_validation.json
endlocal
