@echo off
setlocal
cd /d "%~dp0"
python src\stage8b1_alpha_morphology_preflight.py --project-root "%CD%"
exit /b %ERRORLEVEL%
