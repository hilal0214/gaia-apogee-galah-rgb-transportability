@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d3_survey_specific_snr_lineage.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2D3 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2D3 survey-specific S/N lineage completed.
echo Inspect outputs\stage6d3a2d3_survey_specific_snr_lineage\validation\stage6d3a2d3_validation.json
endlocal
