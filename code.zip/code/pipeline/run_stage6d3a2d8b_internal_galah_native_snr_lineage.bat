@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d8b_internal_galah_native_snr_lineage.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3A2D8B completed.
echo Inspect outputs\stage6d3a2d8b_internal_galah_native_snr_lineage\validation\stage6d3a2d8b_validation.json
endlocal
