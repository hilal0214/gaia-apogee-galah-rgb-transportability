@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c7a_numerical_stability_certification.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C7A1 cell-ID lookup hotfix completed.
echo Inspect outputs\stage6d3c7a1_numerical_stability_certification_hotfix\validation\stage6d3c7a_validation.json
endlocal
