@echo off
setlocal
cd /d "%~dp0"
python src\stage6d4a_science_model_preflight.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D4A science-model preflight completed.
echo Inspect outputs\stage6d4a_science_model_preflight\validation\stage6d4a_validation.json
endlocal
