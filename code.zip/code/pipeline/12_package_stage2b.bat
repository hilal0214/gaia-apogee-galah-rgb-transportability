@echo off
setlocal
python scripts\12_package_stage2b.py --config config\stage2b.yml
if errorlevel 1 exit /b %errorlevel%
endlocal
