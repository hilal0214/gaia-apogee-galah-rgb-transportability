@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d1_exact_wide_design_source_assembly.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2D1 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2D1 exact wide-design source assembly completed.
echo Inspect outputs\stage6d3a2d1_exact_wide_design_source_assembly\validation\stage6d3a2d1_validation.json
endlocal
