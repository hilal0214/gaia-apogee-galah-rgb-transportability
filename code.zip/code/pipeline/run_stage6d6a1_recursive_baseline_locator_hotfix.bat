@echo off
setlocal
cd /d "%~dp0"
python src\stage6d6a1_recursive_baseline_locator_hotfix.py --project-root "%CD%"
if errorlevel 1 exit /b 1
endlocal
