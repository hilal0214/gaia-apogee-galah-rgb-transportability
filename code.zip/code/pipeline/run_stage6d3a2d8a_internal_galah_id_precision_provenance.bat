@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d8a_internal_galah_id_precision_provenance.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3A2D8A completed.
echo Inspect outputs\stage6d3a2d8a_internal_galah_precision_audit\validation\stage6d3a2d8a_validation.json
endlocal
