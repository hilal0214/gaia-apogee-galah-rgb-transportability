@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2b_importpath_traced_bundle_hotfix.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2B failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2B import-path trace and source-bundle assembly completed.
echo Inspect outputs\stage6d3a2b_importpath_traced_bundle_hotfix\validation\stage6d3a2b_validation.json
endlocal
