@echo off
setlocal
cd /d "%~dp0"
python src\stage7b2a_fullgrid_power_runtime_pilot.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-7B2A full-grid power/runtime pilot completed.
echo Inspect outputs\stage7b2a_fullgrid_power_runtime_pilot\tables\stage7b2a_pilot_summary.csv
endlocal
