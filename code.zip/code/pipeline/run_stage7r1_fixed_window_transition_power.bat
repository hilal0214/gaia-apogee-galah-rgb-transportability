@echo off
setlocal
cd /d "%~dp0"
python src\stage7r1_fixed_window_transition_power.py --project-root "%CD%" --workers 4
exit /b %ERRORLEVEL%
