# Stage-6C2D protocol

Explicit sources only. T05/T06 reuse the frozen Stage-4B Huber model specification on the frozen Stage-4A design layer. No validation, design contract, claim ledger, manifest, sensitivity ladder, or bootstrap-draw table is promoted as a direct manuscript table.
