@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3b_common_footprint_construction.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3B1 coordinate-route fallback hotfix completed.
echo Inspect outputs\stage6d3b1_coordinate_route_fallback_hotfix\validation\stage6d3b_validation.json
endlocal
