@echo off
python scripts\36_package_stage5b.py --config config\stage5b.yml

