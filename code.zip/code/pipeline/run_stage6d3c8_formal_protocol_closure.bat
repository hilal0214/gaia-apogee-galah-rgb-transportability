@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c8_formal_protocol_closure.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C8 formal protocol closure completed.
echo Inspect outputs\stage6d3c8_formal_protocol_closure\validation\stage6d3c8_validation.json
endlocal
