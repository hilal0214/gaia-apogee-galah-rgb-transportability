@echo off
python scripts\19_build_stage3b.py --config config\stage3b.yml

