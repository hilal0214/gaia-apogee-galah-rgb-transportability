@echo off
setlocal
call 99_stage3a_selftest.bat || exit /b 1
call 16_build_stage3a.bat || exit /b 1
call 17_validate_stage3a.bat || exit /b 1
call 18_package_stage3a.bat || exit /b 1
endlocal
