@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2d2_row_origin_survey_identity_hotfix.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2D1 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2D2 row-origin survey identity hotfix completed.
echo Inspect outputs\stage6d3a2d2_row_origin_survey_identity_hotfix\validation\stage6d3a2d2_validation.json
endlocal
