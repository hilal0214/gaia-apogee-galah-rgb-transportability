@echo off
setlocal
cd /d "%~dp0"
python src\stage6d4c1_practical_equivalence_path_hotfix.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D4C1 practical-equivalence path hotfix completed.
echo Inspect outputs\stage6d4c1_practical_equivalence_path_hotfix\validation\stage6d4c1_validation.json
endlocal
