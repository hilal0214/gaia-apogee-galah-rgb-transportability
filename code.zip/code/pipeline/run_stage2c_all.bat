@echo off
setlocal
call 99_stage2c_selftest.bat || exit /b %errorlevel%
call 13_run_stage2c.bat || exit /b %errorlevel%
call 14_validate_stage2c.bat || exit /b %errorlevel%
call 15_package_stage2c.bat || exit /b %errorlevel%
endlocal
