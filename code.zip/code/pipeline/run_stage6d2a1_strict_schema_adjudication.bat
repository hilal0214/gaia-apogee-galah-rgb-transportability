@echo off
setlocal
cd /d "%~dp0"
python src\stage6d2a1_strict_schema_adjudication.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D2A1 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D2A1 strict schema adjudication completed.
echo Inspect outputs\stage6d2a1_strict_schema_adjudication\validation\stage6d2a1_validation.json
endlocal
