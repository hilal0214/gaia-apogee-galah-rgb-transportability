@echo off
python scripts\selftest_stage4b.py
if errorlevel 1 exit /b %errorlevel%

