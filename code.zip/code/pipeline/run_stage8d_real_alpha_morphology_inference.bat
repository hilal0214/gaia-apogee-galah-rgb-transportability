@echo off
setlocal
cd /d "%~dp0"
python src\stage8d_real_alpha_morphology_inference.py --project-root "%CD%" --workers 4
exit /b %ERRORLEVEL%
