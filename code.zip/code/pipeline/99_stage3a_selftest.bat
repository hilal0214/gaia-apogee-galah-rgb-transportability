@echo off
setlocal
python scripts\selftest_stage3a.py
exit /b %ERRORLEVEL%
