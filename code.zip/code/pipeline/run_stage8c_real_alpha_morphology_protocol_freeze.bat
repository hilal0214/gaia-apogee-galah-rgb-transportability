@echo off
setlocal
cd /d "%~dp0"
python src\stage8c_real_alpha_morphology_protocol_freeze.py --project-root "%CD%"
exit /b %ERRORLEVEL%
