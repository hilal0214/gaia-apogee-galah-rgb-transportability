@echo off
python scripts\20_validate_stage3b.py --config config\stage3b.yml

