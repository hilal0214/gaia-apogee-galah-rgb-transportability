@echo off
python scripts\29_validate_stage4b.py --config config\stage4b.yml
if errorlevel 1 exit /b %errorlevel%

