@echo off
setlocal
cd /d "%~dp0"
python src\stage6d5a_manuscript_claim_integration.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D5A manuscript/claim integration completed.
echo Inspect outputs\stage6d5a_manuscript_claim_integration\validation\stage6d5a_validation.json
endlocal
