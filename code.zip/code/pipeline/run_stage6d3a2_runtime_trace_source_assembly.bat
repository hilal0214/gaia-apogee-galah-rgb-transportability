@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3a2_runtime_trace_source_assembly.py --project-root "%CD%"
if errorlevel 1 (
  echo [ERROR] Stage-6D3A2 failed unexpectedly.
  exit /b 1
)
echo.
echo [OK] Stage-6D3A2 runtime trace and source assembly completed.
echo Inspect outputs\stage6d3a2_runtime_trace_source_assembly\validation\stage6d3a2_validation.json
endlocal
