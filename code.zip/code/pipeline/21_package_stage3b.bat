@echo off
python scripts\21_package_stage3b.py --config config\stage3b.yml

