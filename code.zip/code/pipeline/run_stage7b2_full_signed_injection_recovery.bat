@echo off
setlocal
cd /d "%~dp0"
python src\stage7b2_full_signed_injection_recovery.py --project-root "%CD%"
set RC=%ERRORLEVEL%
if %RC% EQU 0 echo [OK] Stage-7B2 formal calibration PASSED.
if %RC% EQU 2 echo [SCIENCE GATE NOT PASSED] Formal run completed; Stage-7C remains unauthorized.
if %RC% EQU 3 echo [RESUME REQUIRED] Re-run the same BAT; completed checkpoints will be reused.
exit /b %RC%
