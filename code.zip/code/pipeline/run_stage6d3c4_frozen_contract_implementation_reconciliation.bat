@echo off
setlocal
cd /d "%~dp0"
python src\stage6d3c4_frozen_contract_implementation_reconciliation.py --project-root "%CD%"
if errorlevel 1 exit /b 1
echo.
echo [OK] Stage-6D3C4 frozen-contract reconciliation completed.
echo Inspect outputs\stage6d3c4_frozen_contract_implementation_reconciliation\validation\stage6d3c4_validation.json
endlocal
