@echo off
setlocal
cd /d "%~dp0"
python src\stage7b2b1_null_literal_csv_hotfix.py --project-root "%CD%"
if errorlevel 1 exit /b 1
endlocal
