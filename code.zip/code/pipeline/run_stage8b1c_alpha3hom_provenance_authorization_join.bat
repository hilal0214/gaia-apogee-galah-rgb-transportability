@echo off
setlocal
cd /d "%~dp0"
python src\stage8b1c_alpha3hom_provenance_authorization_join.py --project-root "%CD%"
exit /b %ERRORLEVEL%
